import inspect
import pydoc
from pathlib import Path
from queue import Queue
from threading import Thread
from typing import Callable, List, Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F
from torch._dynamo import OptimizedModule
from tqdm import tqdm
from transformers import AutoConfig, AutoModel, AutoTokenizer

from acvl_utils.cropping_and_padding.bounding_boxes import insert_crop_into_image
from acvl_utils.cropping_and_padding.padding import pad_nd_image
from batchgenerators.utilities.file_and_folder_operations import join, load_json

from nnunetv2.inference.sliding_window_prediction import compute_gaussian, compute_steps_for_sliding_window
from nnunetv2.preprocessing.cropping.cropping import crop_to_nonzero
from nnunetv2.preprocessing.normalization.default_normalization_schemes import ZScoreNormalization
from nnunetv2.utilities.helpers import dummy_context, empty_cache

from voxtell.model.voxtell_model import VoxTellModel
from voxtell.model.voxtell_experimental import ExperimentalVoxTellModel
from voxtell.model.mome_core import MoMECoreConfig, MoMECoreVoxTellModel
from voxtell.model.mome_feature_residual import (
    MoMEFeatureResidualConfig,
    MoMEFeatureResidualVoxTellModel,
)
from voxtell.model.adaptive_rho import AdaptiveRhoGateAdapter
from voxtell.model.category_adaptive_s3 import (
    AttentionConditionedResidualLogitAdapter3D,
    CategoryContinuousAttentionRouter,
)
from voxtell.model.l2_final_residual_skip import (
    L2ToFinalResidualSkip3D,
    install_l2_to_final_residual_skip,
)
from voxtell.model.qwen_lora_bica import (
    QwenTop6LoRA,
    Stage3BidirectionalCrossAttention,
)
from voxtell.utils.text_embedding import last_token_pool, wrap_with_instruction


class VoxTellPredictor:
    """
    Predictor for VoxTell segmentation model.
    
    This class handles loading the VoxTell model, preprocessing images,
    embedding text prompts, and performing sliding window inference to generate
    segmentation masks based on free-text anatomical descriptions.
    
    Attributes:
        device: PyTorch device for inference.
        network: The VoxTell model.
        tokenizer: Text tokenizer for prompt encoding.
        text_backbone: Text embedding model.
        patch_size: Patch size for sliding window inference.
        tile_step_size: Step size for sliding window (default: 0.5 = 50% overlap).
        perform_everything_on_device: Keep all tensors on device during inference.
        max_text_length: Maximum text prompt length in tokens.
    """
    def __init__(self, model_dir: str, device: torch.device = torch.device('cuda'),
                 text_encoding_model: str = 'Qwen/Qwen3-Embedding-4B',
                 presence_logit_weight: float = 0.0,
                 presence_gating_mode: str = "none",
                 presence_gate_gamma: float = 1.0,
                 presence_gate_tau: float = 0.0,
                 checkpoint_path: str | None = None,
                 load_text_backbone: bool = True,
                 category_adapter_path: str | None = None,
                 prompt_adapter_path: str | None = None,
                 adaptive_rho_adapter_path: str | None = None,
                 category_attention_router_path: str | None = None,
                 target_attention_adapter_path: str | None = None,
                 l2_final_residual_skip_path: str | None = None,
                 text_representation: str = "qwen",
                 amp_dtype: str = "float16") -> None:
        """
        Initialize the VoxTell predictor.
        
        Args:
            model_dir: Path to model directory containing plans.json and checkpoint.
            device: PyTorch device to use for inference (default: cuda).
            text_encoding_model: Pretrained text encoding model (Qwen/Qwen3-Embedding-4B).
            
        Raises:
            FileNotFoundError: If model files are not found.
            RuntimeError: If model loading fails.
        """
        # Device setup
        self.device = device
        if text_representation not in {
            "qwen", "pubmedbert_cls", "pubmedbert_mean", "pubmedbert_token",
            "biomedclip_cls",
        }:
            raise ValueError(f"Unknown text_representation: {text_representation!r}")
        self.text_representation = text_representation
        if amp_dtype not in {"float16", "bfloat16"}:
            raise ValueError(f"Unknown inference amp_dtype: {amp_dtype!r}")
        self.amp_dtype = (
            torch.bfloat16 if amp_dtype == "bfloat16" else torch.float16
        )
        if device.type == 'cuda':
            torch.backends.cudnn.benchmark = True
        self.normalization = ZScoreNormalization(intensityproperties={})

        # Predictor settings
        self.tile_step_size = 0.5
        self.perform_everything_on_device = True
        self.presence_logit_weight = float(presence_logit_weight)
        if presence_gating_mode not in {"none", "multiply", "hard"}:
            raise ValueError(f"Unknown presence_gating_mode: {presence_gating_mode}")
        self.presence_gating_mode = presence_gating_mode
        self.presence_gate_gamma = float(presence_gate_gamma)
        self.presence_gate_tau = float(presence_gate_tau)
        self.spatial_attention_rho_scale = 1.0
        self.s2_attention_scale_factors = None

        # Embedding model. Inference audits that use the repository's versioned
        # embedding cache can skip loading the multi-billion-parameter text
        # backbone while still reusing this class's checkpoint and inference
        # implementation.
        self.tokenizer = None
        self.text_backbone = None
        if load_text_backbone:
            self.tokenizer = AutoTokenizer.from_pretrained(text_encoding_model, padding_side='left')
            self.text_backbone = AutoModel.from_pretrained(text_encoding_model).eval()
        self.max_text_length = 8192

        # Load network settings
        plans = load_json(join(model_dir, 'plans.json'))
        arch_kwargs = plans['configurations']['3d_fullres']['architecture']['arch_kwargs']
        self.patch_size = plans['configurations']['3d_fullres']['patch_size']

        arch_kwargs = dict(**arch_kwargs)
        for required_import_key in plans['configurations']['3d_fullres']['architecture']['_kw_requires_import']:
            if arch_kwargs[required_import_key] is not None:
                arch_kwargs[required_import_key] = pydoc.locate(arch_kwargs[required_import_key])

        resolved_checkpoint_path = checkpoint_path or join(model_dir, 'fold_0', 'checkpoint_final.pth')
        checkpoint = torch.load(
            resolved_checkpoint_path,
            map_location=torch.device('cpu'),
            weights_only=False
        )
        category_adapter = None
        self.category_to_index = None
        if category_adapter_path is not None:
            category_adapter = torch.load(
                category_adapter_path,
                map_location=torch.device('cpu'),
                weights_only=False,
            )
            if category_adapter.get("format_version") != "voxtell_rex_category_adapter.v1":
                raise ValueError(f"Unsupported category adapter: {category_adapter_path}")
            self.category_to_index = dict(category_adapter["category_to_index"])
        prompt_adapter = None
        if prompt_adapter_path is not None:
            if category_adapter_path is not None:
                raise ValueError("Category and prompt residual adapters cannot be combined")
            prompt_adapter = torch.load(
                prompt_adapter_path, map_location=torch.device('cpu'), weights_only=False
            )
            if prompt_adapter.get("format_version") != "voxtell_prompt_residual_adapter.v1":
                raise ValueError(f"Unsupported prompt residual adapter: {prompt_adapter_path}")
        adaptive_rho_payload = None
        if adaptive_rho_adapter_path is not None:
            adaptive_rho_payload = torch.load(
                adaptive_rho_adapter_path,
                map_location=torch.device('cpu'),
                weights_only=False,
            )
            if adaptive_rho_payload.get("format_version") != AdaptiveRhoGateAdapter.FORMAT_VERSION:
                raise ValueError(f"Unsupported adaptive-rho adapter: {adaptive_rho_adapter_path}")
            self.adaptive_rho_category_to_index = {
                category: index
                for index, category in enumerate(
                    adaptive_rho_payload["adapter_config"]["categories"]
                )
            }
        else:
            self.adaptive_rho_category_to_index = None
        category_router_payload = None
        if category_attention_router_path is not None:
            category_router_payload = torch.load(
                category_attention_router_path,
                map_location=torch.device('cpu'),
                weights_only=False,
            )
            if category_router_payload.get("format_version") != CategoryContinuousAttentionRouter.FORMAT_VERSION:
                raise ValueError(f"Unsupported category router: {category_attention_router_path}")
            self.category_attention_router_to_index = {
                category: index
                for index, category in enumerate(
                    category_router_payload["router_config"]["categories"]
                )
            }
        else:
            self.category_attention_router_to_index = None
        target_adapter_payload = None
        if target_attention_adapter_path is not None:
            target_adapter_payload = torch.load(
                target_attention_adapter_path,
                map_location=torch.device('cpu'),
                weights_only=False,
            )
            if target_adapter_payload.get("format_version") != AttentionConditionedResidualLogitAdapter3D.FORMAT_VERSION:
                raise ValueError(f"Unsupported target attention adapter: {target_attention_adapter_path}")
            self.target_attention_adapter_category = str(
                target_adapter_payload["adapter_config"]["target_category"]
            )
        else:
            self.target_attention_adapter_category = None
        l2_final_payload = None
        self.l2_final_residual_category_to_index = None
        if l2_final_residual_skip_path is not None:
            l2_final_payload = torch.load(
                l2_final_residual_skip_path,
                map_location=torch.device("cpu"),
                weights_only=False,
            )
            if (
                l2_final_payload.get("format_version")
                != L2ToFinalResidualSkip3D.FORMAT_VERSION
            ):
                raise ValueError(
                    f"Unsupported L2-final residual adapter: "
                    f"{l2_final_residual_skip_path}"
                )
            adapter_config = l2_final_payload["adapter_config"]
            self.l2_final_residual_category_to_index = {
                category: index
                for index, category in enumerate(adapter_config["categories"])
            }
        if sum(
            payload is not None
            for payload in (
                adaptive_rho_payload,
                category_router_payload,
                target_adapter_payload,
            )
        ) > 1:
            raise ValueError("Adaptive rho, category router, and target adapter are mutually exclusive")
        presence_weights = checkpoint.get('patch_presence_head_weights')
        self.patch_presence_head_enabled = presence_weights is not None
        experimental_config = dict(checkpoint.get('experimental_model_config', {}) or {})
        # Early C2/C3 checkpoints predate persistence of these newly added
        # architecture fields in ``experimental_model_config``. Their original
        # argparse values are nevertheless saved with every checkpoint.  Read
        # those as a backward-compatible fallback so inference reconstructs
        # the exact trained module topology rather than silently falling back
        # to baseline VoxTell.
        checkpoint_args = checkpoint.get('args', {}) or {}
        if not isinstance(checkpoint_args, dict):
            checkpoint_args = {}

        def config_value(name, default):
            return experimental_config.get(name, checkpoint_args.get(name, default))
        network_weights_for_detection = checkpoint.get('network_weights', {})
        if isinstance(network_weights_for_detection, dict):
            if (
                config_value('bidir_prompt_decoder_mode', 'none') == 'none'
                and any(
                    str(key).startswith('bidir_prompt_')
                    or str(key).startswith('bidir_no_fusion_decoder.')
                    for key in network_weights_for_detection
                )
            ):
                inferred_bidir_mode = (
                    'no_old_fusion'
                    if any(
                        str(key).startswith('bidir_no_fusion_decoder.')
                        for key in network_weights_for_detection
                    )
                    else 'old_fusion'
                )
                experimental_config['bidir_prompt_decoder_mode'] = inferred_bidir_mode
        specialist_payload = checkpoint.get('category_2d_specialist')
        dense_conversion_payload = checkpoint.get('category_2d_dense_conversion')
        if specialist_payload is not None and dense_conversion_payload is not None:
            raise ValueError('Checkpoint cannot contain both category-2d specialist variants')
        self.category_2d_dense_conversion_enabled = dense_conversion_payload is not None
        self.category_2d_specialist_enabled = (
            specialist_payload is not None or dense_conversion_payload is not None
        )
        routed_specialist_payload = (
            dense_conversion_payload
            if dense_conversion_payload is not None
            else specialist_payload
        )
        self.category_2d_specialist_category_to_index = (
            {} if routed_specialist_payload is None else routed_specialist_payload.get(
                'category_to_index', {'2d': 10}
            )
        )
        self.lobe_input_mode = str(experimental_config.get('lobe_input_mode', 'none'))
        if self.lobe_input_mode not in {
            'none', 'scalar', 'onehot', 'embedding', 'onehot_adapter'
        }:
            raise ValueError(f"Unknown checkpoint lobe_input_mode: {self.lobe_input_mode!r}")
        self.multiwindow_input = bool(experimental_config.get('multiwindow_input', False))
        self.mome_core_mode = str(experimental_config.get('mome_core_mode', 'none'))
        if self.mome_core_mode not in {'none', 'uniform', 'learned'}:
            raise ValueError(f"Unknown checkpoint mome_core_mode: {self.mome_core_mode!r}")
        self.mome_residual_mode = str(
            experimental_config.get('mome_residual_mode', 'none')
        )
        if self.mome_residual_mode not in {'none', 'uniform', 'learned'}:
            raise ValueError(
                f"Unknown checkpoint mome_residual_mode: {self.mome_residual_mode!r}"
            )
        if self.mome_core_mode != 'none' and self.mome_residual_mode != 'none':
            raise ValueError("Checkpoint cannot enable direct-head and feature-residual MoME")
        self.token_image_text_mode = str(
            experimental_config.get('token_image_text_mode', 'original')
        )
        self.fan_image_text_mode = str(
            experimental_config.get('fan_image_text_mode', 'none')
        )
        self.fan_pre_activation_mode = bool(
            config_value('fan_pre_activation_mode', False)
        )
        self.less_encoder_mode = str(config_value('less_encoder_mode', 'none'))
        self.less_semantic_alignment_mode = str(
            config_value('less_semantic_alignment_mode', 'none')
        )
        self.word_global_mode = str(config_value('word_global_mode', 'none'))
        if self.word_global_mode not in {'none', 'b1', 'b2', 'b3'}:
            raise ValueError(f"Unknown checkpoint word_global_mode: {self.word_global_mode!r}")
        self.bidir_prompt_decoder_mode = str(
            config_value('bidir_prompt_decoder_mode', 'none')
        )
        self.global_sentence_feedback_mode = str(
            config_value('global_sentence_feedback_mode', 'none')
        )
        self.encoder_propagation_mode = str(
            experimental_config.get('encoder_propagation_mode', 'none')
        )
        self.encoder_residual_film_mode = str(
            experimental_config.get('encoder_residual_film_mode', 'none')
        )
        self.encoder_token_spatial_mode = str(
            experimental_config.get('encoder_token_spatial_mode', 'none')
        )
        self.qwen_lora_mode = str(config_value('qwen_lora_mode', 'none'))
        if self.qwen_lora_mode not in {'none', 'global', 'bica_stage3'}:
            raise ValueError(f"Unknown checkpoint qwen_lora_mode: {self.qwen_lora_mode!r}")
        if self.qwen_lora_mode != 'none' and text_representation != 'qwen':
            raise ValueError("A Qwen-LoRA checkpoint requires text_representation='qwen'")
        self.medplex_mode = str(config_value('medplex_mode', 'none'))
        self.medplex_bifusion_enabled = bool(
            config_value('medplex_bifusion_enabled', True)
        )
        if self.medplex_mode not in {'none', 'pubmedbert', 'biomedclip'}:
            raise ValueError(f"Unknown checkpoint medplex_mode: {self.medplex_mode!r}")
        expected_medplex_representation = {
            'pubmedbert': 'pubmedbert_cls',
            'biomedclip': 'biomedclip_cls',
        }.get(self.medplex_mode)
        if (
            expected_medplex_representation is not None
            and text_representation != expected_medplex_representation
        ):
            raise ValueError(
                f"A {self.medplex_mode} MedPlex checkpoint requires "
                f"text_representation={expected_medplex_representation!r}"
            )
        self.multiwindow_center = float(experimental_config.get('multiwindow_center', -550.0))
        self.multiwindow_width = float(experimental_config.get('multiwindow_width', 1000.0))
        if self.multiwindow_input and self.lobe_input_mode != 'none':
            raise ValueError("Checkpoint cannot require both multi-window and lobe input")
        spatial_attention_weights = checkpoint.get('prompt_spatial_attention_weights')
        s2_attention_weights = checkpoint.get('s2_attention_weights')
        s3_attention_weights = checkpoint.get('s3_attention_weights')
        s3_extra_attention_weights = checkpoint.get('s3_extra_attention_weights')
        s3_decoder_feature_gate_weights = checkpoint.get('s3_decoder_feature_gate_weights')
        s3_fullres_refinement_weights = checkpoint.get('s3_fullres_refinement_weights')
        s3_joint_fusion_weights = checkpoint.get('s3_joint_fusion_weights')
        s3_fullres_alignment_weights = checkpoint.get('s3_fullres_alignment_weights')
        use_experimental_model = (
            experimental_config.get('presence_head_type', 'global') != 'global'
            or experimental_config.get('presence_detach_features', False)
            or experimental_config.get('enable_prompt_spatial_attention', False)
            or experimental_config.get('enable_s2_attention', False)
            or experimental_config.get('enable_s3_voxel_text_matching_attention', False)
            or experimental_config.get('enable_s3_decoder_feature_gate', False)
            or experimental_config.get('enable_s3_fullres_attention_refinement', False)
            or experimental_config.get('enable_s3_joint_residual_fusion', False)
            or experimental_config.get('enable_s3_fullres_sampled_alignment', False)
            or adaptive_rho_payload is not None
            or category_router_payload is not None
            or target_adapter_payload is not None
            or self.lobe_input_mode != 'none'
            or self.multiwindow_input
            or self.mome_core_mode != 'none'
            or self.mome_residual_mode != 'none'
            or self.token_image_text_mode != 'original'
            or self.fan_image_text_mode != 'none'
            or self.less_encoder_mode != 'none'
            or self.less_semantic_alignment_mode != 'none'
            or self.word_global_mode != 'none'
            or self.bidir_prompt_decoder_mode != 'none'
            or self.global_sentence_feedback_mode != 'none'
            or self.encoder_propagation_mode != 'none'
            or self.encoder_residual_film_mode != 'none'
            or self.encoder_token_spatial_mode != 'none'
            or self.qwen_lora_mode != 'none'
            or self.medplex_mode != 'none'
        )

        # Instantiate network
        if self.mome_core_mode != 'none':
            model_class = MoMECoreVoxTellModel
        elif self.mome_residual_mode != 'none':
            model_class = MoMEFeatureResidualVoxTellModel
        else:
            model_class = ExperimentalVoxTellModel if use_experimental_model else VoxTellModel
        experimental_kwargs = {}
        if use_experimental_model:
            experimental_kwargs = {
                'presence_head_type': experimental_config.get('presence_head_type', 'global'),
                'presence_detach_features': experimental_config.get('presence_detach_features', False),
                'presence_spatial_hidden_channels': experimental_config.get(
                    'presence_spatial_hidden_channels', 128
                ),
                'presence_spatial_topk_frac': experimental_config.get('presence_spatial_topk_frac', 0.01),
                'enable_prompt_spatial_attention': experimental_config.get(
                    'enable_prompt_spatial_attention', False
                ),
                'spatial_attention_hidden_channels': experimental_config.get(
                    'spatial_attention_hidden_channels', 128
                ),
                'spatial_attention_beta_init': experimental_config.get('spatial_attention_beta_init', -6.0),
                'spatial_attention_level': experimental_config.get('spatial_attention_level', 'auto_1over4'),
                'enable_s2_attention': experimental_config.get('enable_s2_attention', False),
                's2_attention_scales': experimental_config.get('s2_attention_scales', ['1/4', '1/2']),
                's2_attention_hidden_channels': experimental_config.get(
                    's2_attention_hidden_channels', 128
                ),
                's2_beta_init': experimental_config.get('s2_beta_init', -1.5),
                'enable_s3_voxel_text_matching_attention': experimental_config.get(
                    'enable_s3_voxel_text_matching_attention', False
                ),
                's3_attention_hidden_channels': experimental_config.get(
                    's3_attention_hidden_channels', 128
                ),
                's3_rho_mode': experimental_config.get('s3_rho_mode', 'fixed'),
                's3_rho_fixed': experimental_config.get('s3_rho_fixed', 0.25),
                's3_logit_scale_init': experimental_config.get('s3_logit_scale_init', 10.0),
                's3_attention_scales': experimental_config.get('s3_attention_scales', ['1/2']),
                'enable_s3_decoder_feature_gate': experimental_config.get(
                    'enable_s3_decoder_feature_gate', False
                ),
                's3_decoder_feature_gate_scales': experimental_config.get(
                    's3_decoder_feature_gate_scales', ['1/4']
                ),
                's3_decoder_feature_gate_strength_init': experimental_config.get(
                    's3_decoder_feature_gate_strength_init', 0.0
                ),
                'enable_s3_fullres_attention_refinement': experimental_config.get(
                    'enable_s3_fullres_attention_refinement', False
                ),
                's3_fullres_refinement_hidden_channels': experimental_config.get(
                    's3_fullres_refinement_hidden_channels', 64
                ),
                'enable_s3_joint_residual_fusion': experimental_config.get(
                    'enable_s3_joint_residual_fusion', False
                ),
                's3_joint_fusion_hidden_channels': experimental_config.get(
                    's3_joint_fusion_hidden_channels', 16
                ),
                's3_joint_fusion_detach_attention': experimental_config.get(
                    's3_joint_fusion_detach_attention', True
                ),
                'enable_s3_fullres_sampled_alignment': experimental_config.get(
                    'enable_s3_fullres_sampled_alignment', False
                ),
                's3_fullres_alignment_dim': experimental_config.get('s3_fullres_alignment_dim', 128),
                'lobe_input_mode': self.lobe_input_mode,
                'lobe_embedding_dim': experimental_config.get('lobe_embedding_dim', 4),
                'token_image_text_mode': self.token_image_text_mode,
                'token_image_text_hidden_dim': experimental_config.get(
                    'token_image_text_hidden_dim', 2048
                ),
                'token_image_text_heads': experimental_config.get(
                    'token_image_text_heads', 8
                ),
                'token_image_text_dropout': experimental_config.get(
                    'token_image_text_dropout', 0.1
                ),
                'token_image_text_init_seed': experimental_config.get(
                    'token_image_text_init_seed', 260806
                ),
                'token_image_text_identity_init': experimental_config.get(
                    'token_image_text_identity_init', False
                ),
                'token_image_text_output_init_scale': experimental_config.get(
                    'token_image_text_output_init_scale', 1.0
                ),
                'token_image_text_text_dim': experimental_config.get(
                    'token_image_text_text_dim',
                    768 if text_representation == "pubmedbert_token" else 2560,
                ),
                'fan_image_text_mode': self.fan_image_text_mode,
                'fan_image_text_levels': experimental_config.get(
                    'fan_image_text_levels', [4, 5]
                ),
                'fan_image_text_dim': experimental_config.get(
                    'fan_image_text_dim', 512
                ),
                'fan_image_text_heads': experimental_config.get(
                    'fan_image_text_heads', 8
                ),
                'fan_image_text_dropout': experimental_config.get(
                    'fan_image_text_dropout', 0.1
                ),
                'fan_image_text_init_seed': experimental_config.get(
                    'fan_image_text_init_seed', 260812
                ),
                'fan_image_text_preserve_epsilon': experimental_config.get(
                    'fan_image_text_preserve_epsilon', 1e-3
                ),
                'fan_pre_activation_mode': self.fan_pre_activation_mode,
                'fan_pre_activation_init_seed': config_value(
                    'fan_pre_activation_init_seed', 260821
                ),
                'fan_pre_activation_residual_scale': config_value(
                    'fan_pre_activation_residual_scale', 1e-3
                ),
                'bidir_prompt_decoder_mode': self.bidir_prompt_decoder_mode,
                'bidir_prompt_num_layers': experimental_config.get(
                    'bidir_prompt_num_layers', 6
                ),
                'bidir_prompt_heads': experimental_config.get(
                    'bidir_prompt_heads', 8
                ),
                'bidir_prompt_dropout': experimental_config.get(
                    'bidir_prompt_dropout', 0.1
                ),
                'bidir_prompt_init_seed': experimental_config.get(
                    'bidir_prompt_init_seed', 260815
                ),
                'bidir_prompt_residual_scale': experimental_config.get(
                    'bidir_prompt_residual_scale', 1e-3
                ),
                'global_sentence_feedback_mode': self.global_sentence_feedback_mode,
                'global_sentence_feedback_rank': config_value(
                    'global_sentence_feedback_rank', 128
                ),
                'global_sentence_feedback_init_scale': config_value(
                    'global_sentence_feedback_init_scale', 1e-3
                ),
                'global_sentence_feedback_init_seed': config_value(
                    'global_sentence_feedback_init_seed', 260823
                ),
                'encoder_propagation_mode': self.encoder_propagation_mode,
                'encoder_propagation_hidden_dim': experimental_config.get(
                    'encoder_propagation_hidden_dim', 2048
                ),
                'encoder_propagation_heads': experimental_config.get(
                    'encoder_propagation_heads', 8
                ),
                'encoder_propagation_dropout': experimental_config.get(
                    'encoder_propagation_dropout', 0.1
                ),
                'encoder_propagation_init_seed': experimental_config.get(
                    'encoder_propagation_init_seed', 260810
                ),
                'encoder_residual_film_mode': self.encoder_residual_film_mode,
                'encoder_residual_film_hidden_dim': experimental_config.get(
                    'encoder_residual_film_hidden_dim', 512
                ),
                'encoder_residual_film_groups': experimental_config.get(
                    'encoder_residual_film_groups', 32
                ),
                'encoder_residual_film_init_seed': experimental_config.get(
                    'encoder_residual_film_init_seed', 260811
                ),
                'encoder_residual_film_stage': experimental_config.get(
                    'encoder_residual_film_stage', 3
                ),
                'encoder_token_spatial_mode': self.encoder_token_spatial_mode,
                'encoder_token_spatial_stage': experimental_config.get(
                    'encoder_token_spatial_stage', 3
                ),
                'encoder_token_spatial_hidden_dim': experimental_config.get(
                    'encoder_token_spatial_hidden_dim', 256
                ),
                'encoder_token_spatial_heads': experimental_config.get(
                    'encoder_token_spatial_heads', 8
                ),
                'encoder_token_spatial_dropout': experimental_config.get(
                    'encoder_token_spatial_dropout', 0.0
                ),
                'encoder_token_spatial_init_seed': experimental_config.get(
                    'encoder_token_spatial_init_seed', 260813
                ),
                'encoder_token_spatial_connector_type': experimental_config.get(
                    'encoder_token_spatial_connector_type', 'dense'
                ),
                'encoder_token_spatial_connector_init_scale': experimental_config.get(
                    'encoder_token_spatial_connector_init_scale', 5e-4
                ),
                'encoder_token_spatial_conditioned_skip': experimental_config.get(
                    'encoder_token_spatial_conditioned_skip', False
                ),
                'encoder_token_spatial_skip_scale': experimental_config.get(
                    'encoder_token_spatial_skip_scale', 1.0
                ),
                'less_encoder_mode': self.less_encoder_mode,
                'less_encoder_levels': config_value(
                    'less_encoder_levels', [2, 3, 4, 5]
                ),
                'less_encoder_attention_dim': config_value(
                    'less_encoder_attention_dim', 256
                ),
                'less_encoder_heads': config_value('less_encoder_heads', 8),
                'less_encoder_dropout': config_value('less_encoder_dropout', 0.0),
                'less_encoder_query_chunk_size': config_value(
                    'less_encoder_query_chunk_size', 4096
                ),
                'less_encoder_prompt_chunk_size': config_value(
                    'less_encoder_prompt_chunk_size', 1
                ),
                'less_encoder_init_seed': config_value(
                    'less_encoder_init_seed', 260820
                ),
                'less_semantic_alignment_mode': self.less_semantic_alignment_mode,
                'less_semantic_alignment_dim': config_value(
                    'less_semantic_alignment_dim', 128
                ),
                'word_global_mode': self.word_global_mode,
                'word_global_bridge_checkpoint': config_value(
                    'word_global_bridge_checkpoint', None
                ),
                'word_global_lr': config_value('word_global_lr', None),
                'word_global_b1_alpha': config_value('word_global_b1_alpha', 0.01),
                'word_global_b1_decoder_stage': config_value(
                    'word_global_b1_decoder_stage', 2
                ),
                'word_global_b1_seed': config_value('word_global_b1_seed', 260901),
                'word_global_b3_candidates': config_value(
                    'word_global_b3_candidates', 4
                ),
                'word_global_b3_epsilon': config_value(
                    'word_global_b3_epsilon', 1e-3
                ),
                'word_global_b3_router_scale': config_value(
                    'word_global_b3_router_scale', 0.1
                ),
                'word_global_b3_aggregation': config_value(
                    'word_global_b3_aggregation', 'learned'
                ),
                'word_global_b3_seed': config_value('word_global_b3_seed', 260903),
                'medplex_mode': self.medplex_mode,
                'medplex_bifusion_enabled': self.medplex_bifusion_enabled,
                'medplex_heads': int(config_value('medplex_heads', 8)),
            }
        input_channels = {
            'none': 1,
            'scalar': 2,
            'onehot': 6,
            'embedding': 1,
            'onehot_adapter': 1,
        }[self.lobe_input_mode]
        if self.multiwindow_input:
            input_channels = 2
        mome_kwargs = {}
        if self.mome_core_mode != 'none':
            mome_kwargs = {
                'mome_core_config': MoMECoreConfig(
                    mode=self.mome_core_mode,
                    controller_width=int(experimental_config.get('mome_controller_width', 128)),
                    router_hidden_channels=int(
                        experimental_config.get('mome_router_hidden_channels', 32)
                    ),
                    router_normalization=str(
                        experimental_config.get('mome_router_normalization', 'softplus_l1')
                    ),
                    router_temperature=float(
                        experimental_config.get('mome_router_temperature', 1.0)
                    ),
                    router_epsilon=float(experimental_config.get('mome_router_epsilon', 1e-6)),
                    router_condition_text=bool(
                        experimental_config.get('mome_router_condition_text', True)
                    ),
                    integration=str(experimental_config.get('mome_integration', 'replace')),
                    capture_router_maps=False,
                )
            }
        elif self.mome_residual_mode != 'none':
            mome_kwargs = {
                'mome_residual_config': MoMEFeatureResidualConfig(
                    mode=self.mome_residual_mode,
                    controller_width=int(
                        experimental_config.get('mome_residual_controller_width', 128)
                    ),
                    router_hidden_channels=int(
                        experimental_config.get(
                            'mome_residual_router_hidden_channels', 32
                        )
                    ),
                    router_epsilon=float(
                        experimental_config.get('mome_residual_router_epsilon', 1e-6)
                    ),
                    capture_router_maps=False,
                )
            }
        network = model_class(
            input_channels=input_channels,
            **arch_kwargs,
            decoder_layer=4,
            text_embedding_dim=2560,
            input_text_dim=(
                768
                if text_representation in {
                    "pubmedbert_cls", "pubmedbert_mean", "biomedclip_cls"
                }
                else 2560
            ),
            num_maskformer_stages=5,
            num_heads=32,
            query_dim=2048,
            project_to_decoder_hidden_dim=2048,
            deep_supervision=False,
            enable_patch_presence_head=self.patch_presence_head_enabled,
            enable_category_embedding=category_adapter is not None,
            num_categories=(
                15 if category_adapter is None else len(category_adapter["category_to_index"])
            ),
            enable_prompt_residual_adapter=prompt_adapter is not None,
            prompt_residual_adapter_rank=(
                16 if prompt_adapter is None else int(prompt_adapter["architecture"]["rank"])
            ),
            **experimental_kwargs,
            **mome_kwargs,
        )

        # The 4B Qwen base is restored locally and frozen. Checkpoints contain
        # only LoRA (and optional BiCA) parameters, so attach the exact module
        # topology before loading state rather than silently treating C1/C2 as
        # a pooled-embedding baseline.
        if self.qwen_lora_mode != 'none':
            if not isinstance(network, ExperimentalVoxTellModel):
                raise RuntimeError("Qwen-LoRA checkpoints require ExperimentalVoxTellModel")
            network.qwen_lora_mode = self.qwen_lora_mode
            network.qwen_bica_stage = 3
            network.qwen_adapter = QwenTop6LoRA(
                top_k=int(config_value('qwen_lora_top_k', 6)),
                rank=int(config_value('qwen_lora_rank', 8)),
            )
            if self.qwen_lora_mode == 'bica_stage3':
                network.qwen_bica_block = Stage3BidirectionalCrossAttention(
                    image_dim=int(network.encoder.output_channels[3]),
                    attention_dim=int(config_value('qwen_bica_attention_dim', 256)),
                    heads=int(config_value('qwen_bica_heads', 8)),
                    init_seed=int(config_value('qwen_bica_init_seed', 260825)),
                )

        self.medplex_tokenizer = None
        self.medplex_max_length = int(config_value('medplex_max_length', 128))
        if self.medplex_mode != 'none':
            if not isinstance(network, ExperimentalVoxTellModel):
                raise RuntimeError("MedPlex checkpoints require ExperimentalVoxTellModel")
            rex_root = Path(__file__).resolve().parents[3]
            if self.medplex_mode == 'pubmedbert':
                medplex_root = (
                    rex_root
                    / 'model_assets/pubmedbert/e1354b7a3a09615f6aba48dfad4b7a613eef7062'
                )
                medplex_config = AutoConfig.from_pretrained(
                    medplex_root, local_files_only=True
                )
            else:
                medplex_root = (
                    rex_root
                    / 'model_assets/biomedclip/9f341de24bfb00180f1b847274256e9b65a3a32e'
                )
                medplex_config = AutoConfig.from_pretrained(
                    rex_root / 'model_assets/biomedclip/biomedbert_arch_config',
                    local_files_only=True,
                )
            self.medplex_tokenizer = AutoTokenizer.from_pretrained(
                medplex_root, local_files_only=True
            )
            network.configure_medplex_text_tower(AutoModel.from_config(medplex_config))

        if dense_conversion_payload is not None:
            if dense_conversion_payload.get('architecture_id') == 'shared_s3_dense_prior_joint_v1':
                from voxtell.model.category_2d_dense_joint import (
                    attach_category_2d_dense_joint,
                )

                attach_category_2d_dense_joint(
                    network,
                    bottleneck=int(dense_conversion_payload.get('bottleneck_channels', 16)),
                )
            else:
                from voxtell.model.category_2d_dense_conversion import (
                    attach_category_2d_dense_conversion,
                )

                attach_category_2d_dense_conversion(
                    network,
                    bottleneck=int(dense_conversion_payload.get('bottleneck_channels', 16)),
                )
        elif specialist_payload is not None:
            from voxtell.model.category_2d_specialist import attach_category_2d_specialist

            attach_category_2d_specialist(
                network,
                bottleneck=int(specialist_payload.get('bottleneck_channels', 16)),
                capture_detection_as_attention=bool(
                    specialist_payload.get('capture_detection_as_attention', True)
                ),
            )

        if not isinstance(network, OptimizedModule):
            incompatible = network.load_state_dict(
                checkpoint['network_weights'],
                strict=not (
                    self.patch_presence_head_enabled or use_experimental_model
                    or category_adapter is not None or prompt_adapter is not None
                ),
            )
            if category_adapter is not None:
                network.category_embedding.load_state_dict(
                    category_adapter["category_embedding_state"], strict=True
                )
            if prompt_adapter is not None:
                network.prompt_residual_adapter.load_state_dict(
                    prompt_adapter["adapter_state"], strict=True
                )
            if self.patch_presence_head_enabled:
                network.patch_presence_head.load_state_dict(presence_weights)
            if spatial_attention_weights is not None:
                network.prompt_spatial_attention_gate.load_state_dict(spatial_attention_weights)
            if s2_attention_weights is not None:
                network.s2_attention_gates.load_state_dict(s2_attention_weights)
            if s3_attention_weights is not None:
                network.s3_attention_gate.load_state_dict(s3_attention_weights)
            if s3_extra_attention_weights is not None:
                network.s3_extra_attention_gates.load_state_dict(s3_extra_attention_weights)
            if s3_decoder_feature_gate_weights is not None:
                network.s3_decoder_feature_gates.load_state_dict(s3_decoder_feature_gate_weights)
            if s3_fullres_refinement_weights is not None:
                network.s3_fullres_attention_refinement.load_state_dict(s3_fullres_refinement_weights)
            if s3_joint_fusion_weights is not None:
                network.s3_joint_fusion_head.load_state_dict(s3_joint_fusion_weights)
            if s3_fullres_alignment_weights is not None:
                network.s3_fullres_alignment_head.load_state_dict(s3_fullres_alignment_weights)
            if adaptive_rho_payload is not None:
                network.configure_adaptive_rho(
                    AdaptiveRhoGateAdapter.from_payload(adaptive_rho_payload)
                )
            if category_router_payload is not None:
                network.configure_category_attention_router(
                    CategoryContinuousAttentionRouter.from_payload(category_router_payload)
                )
            if target_adapter_payload is not None:
                network.configure_target_attention_adapter(
                    AttentionConditionedResidualLogitAdapter3D.from_payload(target_adapter_payload)
                )
        else:
            incompatible = network._orig_mod.load_state_dict(
                checkpoint['network_weights'],
                strict=not (
                    self.patch_presence_head_enabled or use_experimental_model
                    or category_adapter is not None or prompt_adapter is not None
                ),
            )
            if category_adapter is not None:
                network._orig_mod.category_embedding.load_state_dict(
                    category_adapter["category_embedding_state"], strict=True
                )
            if prompt_adapter is not None:
                network._orig_mod.prompt_residual_adapter.load_state_dict(
                    prompt_adapter["adapter_state"], strict=True
                )
            if self.patch_presence_head_enabled:
                network._orig_mod.patch_presence_head.load_state_dict(presence_weights)
            if spatial_attention_weights is not None:
                network._orig_mod.prompt_spatial_attention_gate.load_state_dict(spatial_attention_weights)
            if s2_attention_weights is not None:
                network._orig_mod.s2_attention_gates.load_state_dict(s2_attention_weights)
            if s3_attention_weights is not None:
                network._orig_mod.s3_attention_gate.load_state_dict(s3_attention_weights)
            if s3_extra_attention_weights is not None:
                network._orig_mod.s3_extra_attention_gates.load_state_dict(s3_extra_attention_weights)
            if s3_decoder_feature_gate_weights is not None:
                network._orig_mod.s3_decoder_feature_gates.load_state_dict(s3_decoder_feature_gate_weights)
            if s3_fullres_refinement_weights is not None:
                network._orig_mod.s3_fullres_attention_refinement.load_state_dict(s3_fullres_refinement_weights)
            if s3_joint_fusion_weights is not None:
                network._orig_mod.s3_joint_fusion_head.load_state_dict(s3_joint_fusion_weights)
            if s3_fullres_alignment_weights is not None:
                network._orig_mod.s3_fullres_alignment_head.load_state_dict(s3_fullres_alignment_weights)
            if adaptive_rho_payload is not None:
                network._orig_mod.configure_adaptive_rho(
                    AdaptiveRhoGateAdapter.from_payload(adaptive_rho_payload)
                )
            if category_router_payload is not None:
                network._orig_mod.configure_category_attention_router(
                    CategoryContinuousAttentionRouter.from_payload(category_router_payload)
                )
            if target_adapter_payload is not None:
                network._orig_mod.configure_target_attention_adapter(
                    AttentionConditionedResidualLogitAdapter3D.from_payload(target_adapter_payload)
                )
        invalid_missing = [
            key for key in incompatible.missing_keys
            if not key.startswith((
                'patch_presence_head.',
                'prompt_spatial_attention_gate.',
                's2_attention_gates.',
                's3_attention_gate.',
                's3_extra_attention_gates.',
                's3_decoder_feature_gates.',
                's3_fullres_attention_refinement.',
                's3_joint_fusion_head.',
                's3_fullres_alignment_head.',
                'category_embedding.',
                'prompt_residual_adapter.',
                'lobe_anatomy_adapter.',
                'token_image_text_block.',
                'fan_image_text_blocks.',
                'fan_image_text_fusion_projections.',
                'encoder_propagation_block.',
                'encoder_residual_film_block.',
                'encoder_token_spatial_block.',
                'qwen_adapter.backbone.',
            ))
        ]
        if invalid_missing or incompatible.unexpected_keys:
            raise RuntimeError(
                f"Checkpoint mismatch: missing={invalid_missing}, "
                f"unexpected={list(incompatible.unexpected_keys)}"
            )
        if l2_final_payload is not None:
            base_network = (
                network._orig_mod if isinstance(network, OptimizedModule) else network
            )
            install_l2_to_final_residual_skip(
                base_network,
                L2ToFinalResidualSkip3D.from_payload(l2_final_payload),
            )
        
        network.eval()
        self.network = network

    def preprocess(self, data: np.ndarray) -> Tuple[torch.Tensor, Tuple, Tuple[int, ...]]:
        """
        Preprocess a single image for inference.
        
        This function preprocesses an image already in RAS orientation by performing
        cropping to non-zero regions and z-score normalization.
        
        Args:
            data: Image data in RAS orientation (3D or 4D with channel dimension).
            
        Returns:
            Tuple containing:
                - Preprocessed image tensor
                - Bounding box of cropped region
                - Original image shape
        """

        if data.ndim == 3:
            data = data[None]  # add channel axis
        data = data.astype(np.float32)  # this creates a copy
        original_shape = data.shape[1:]
        data, _, bbox = crop_to_nonzero(data, None)
        data = self.normalization.run(data, None)
        data = torch.from_numpy(data)
        return data, bbox, original_shape
    
    def _internal_get_sliding_window_slicers(
        self,
        image_size: Tuple[int, ...],
        patch_size: Tuple[int, ...] | None = None,
    ) -> List[Tuple]:
        """
        Generate sliding window slicers for patch-based inference.
        
        Args:
            image_size: Shape of the input image.
            
        Returns:
            List of slice tuples for extracting patches.
        """
        slicers = []
        tile_size = tuple(self.patch_size if patch_size is None else patch_size)
        if len(tile_size) < len(image_size):
            assert len(tile_size) == len(image_size) - 1, (
                'if tile_size has less entries than image_size, '
                'len(tile_size) must be one shorter than len(image_size) '
                '(only dimension discrepancy of 1 allowed).'
            )
            steps = compute_steps_for_sliding_window(image_size[1:], tile_size,
                                                     self.tile_step_size)
            for d in range(image_size[0]):
                for sx in steps[0]:
                    for sy in steps[1]:
                        slicers.append(
                            tuple([slice(None), d, *[slice(si, si + ti) for si, ti in
                                                     zip((sx, sy), tile_size)]]))
        else:
            steps = compute_steps_for_sliding_window(image_size, tile_size,
                                                     self.tile_step_size)
            for sx in steps[0]:
                for sy in steps[1]:
                    for sz in steps[2]:
                        slicers.append(
                            tuple([slice(None), *[slice(si, si + ti) for si, ti in
                                                  zip((sx, sy, sz), tile_size)]]))
        return slicers
    
    @torch.inference_mode()
    def embed_text_prompts(self, text_prompts: Union[List[str], str]) -> torch.Tensor:
        """
        Embed text prompts into vector representations.
        
        This function converts free-text anatomical descriptions into embeddings
        using the text backbone model.
        
        Args:
            text_prompts: Single text prompt or list of text prompts.
            
        Returns:
            Text embeddings tensor of shape (1, num_prompts, embedding_dim).
        """
        if self.tokenizer is None or self.text_backbone is None:
            raise RuntimeError(
                "Text backbone loading was disabled for this predictor; provide "
                "precomputed embeddings or initialize with load_text_backbone=True."
            )
        if isinstance(text_prompts, str):
            text_prompts = [text_prompts]
        n_prompts = len(text_prompts)
        self.text_backbone = self.text_backbone.to(self.device)

        text_prompts = wrap_with_instruction(text_prompts)
        text_tokens = self.tokenizer(
            text_prompts,
            padding=True,
            truncation=True,
            max_length=self.max_text_length,
            return_tensors="pt",
        )
        text_tokens = {k: v.to(self.device) for k, v in text_tokens.items()}
        text_embed = self.text_backbone(**text_tokens)
        embeddings = last_token_pool(text_embed.last_hidden_state, text_tokens['attention_mask'])
        embeddings = embeddings.view(1, n_prompts, -1)
        self.text_backbone = self.text_backbone.to('cpu')
        empty_cache(self.device)
        return embeddings

    @torch.inference_mode()
    def predict_sliding_window_return_logits(
        self,
        input_image: torch.Tensor,
        text_embeddings: torch.Tensor,
        text_prompts: Union[List[str], None] = None,
        spatial_attention_rho_scale: Union[float, torch.Tensor, None] = None,
        s3_attention_gate_scales_by_scale: Union[dict[str, torch.Tensor], None] = None,
        s3_fullres_refinement_scale: Union[float, torch.Tensor, None] = None,
        s3_joint_fusion_scale: Union[float, torch.Tensor, None] = None,
        presence_diagnostic_target: Union[torch.Tensor, None] = None,
        presence_diagnostic_callback: Union[Callable[[list[dict]], None], None] = None,
        return_spatial_attention_maps: bool = False,
        return_spatial_attention_maps_by_scale: bool = False,
        return_native_response_maps: bool = False,
        inference_native_patch_size: Tuple[int, int, int] | None = None,
        category_indices: Union[torch.Tensor, None] = None,
        adaptive_rho_active_mask: Union[torch.Tensor, None] = None,
        anatomy_embeddings: Union[torch.Tensor, None] = None,
        anatomy_valid_mask: Union[torch.Tensor, None] = None,
        prompt_adapter_injection_mode: str = "shared",
        apply_prompt_residual_adapter: bool = True,
        token_features: Union[torch.Tensor, None] = None,
        token_valid_mask: Union[torch.Tensor, None] = None,
        encoder_residual_film_embedding: Union[torch.Tensor, None] = None,
        qwen_prefix_hidden: Union[torch.Tensor, None] = None,
        qwen_attention_mask: Union[torch.Tensor, None] = None,
        qwen_position_ids: Union[torch.Tensor, None] = None,
    ) -> Union[torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
        """
        Perform sliding window inference to generate segmentation logits.
        
        Args:
            input_image: Input image tensor of shape (C, X, Y, Z).
            text_embeddings: Text embeddings from embed_text_prompts.
            
        Returns:
            Predicted logits tensor.
            
        Raises:
            ValueError: If input_image is not 4D or not a torch.Tensor.
        """
        if not isinstance(input_image, torch.Tensor):
            raise ValueError(f"input_image must be a torch.Tensor, got {type(input_image)}")
        if input_image.ndim != 4:
            raise ValueError(
                f"input_image must be 4D (C, X, Y, Z), got shape {input_image.shape}"
            )
        
        self.network = self.network.to(self.device)
        text_embeddings = text_embeddings.to(self.device)
        if anatomy_embeddings is not None:
            anatomy_embeddings = anatomy_embeddings.to(self.device)
        if anatomy_valid_mask is not None:
            anatomy_valid_mask = anatomy_valid_mask.to(self.device)
        if token_features is not None:
            token_features = token_features.to(self.device)
        if token_valid_mask is not None:
            token_valid_mask = token_valid_mask.to(self.device, dtype=torch.bool)
        if encoder_residual_film_embedding is not None:
            encoder_residual_film_embedding = encoder_residual_film_embedding.to(
                self.device
            )
        if qwen_prefix_hidden is not None:
            if self.qwen_lora_mode == 'none':
                raise ValueError("Qwen prefix inputs require a Qwen-LoRA checkpoint")
            if qwen_attention_mask is None or qwen_position_ids is None:
                raise ValueError("Qwen prefix inputs require attention mask and position ids")
            qwen_prefix_hidden = qwen_prefix_hidden.to(self.device)
            qwen_attention_mask = qwen_attention_mask.to(self.device, dtype=torch.long)
            qwen_position_ids = qwen_position_ids.to(self.device, dtype=torch.long)
        medplex_input_ids = None
        medplex_attention_mask = None
        medplex_token_type_ids = None
        if self.medplex_mode != 'none':
            if self.medplex_tokenizer is None:
                raise RuntimeError("MedPlex checkpoint has no tokenizer")
            if text_prompts is None or len(text_prompts) != text_embeddings.shape[1]:
                raise ValueError(
                    "MedPlex inference requires one raw prompt per text embedding"
                )
            encoded = self.medplex_tokenizer(
                list(text_prompts),
                padding=True,
                truncation=True,
                max_length=self.medplex_max_length,
                return_tensors='pt',
            )
            medplex_input_ids = encoded['input_ids'].unsqueeze(0).to(self.device)
            medplex_attention_mask = encoded['attention_mask'].unsqueeze(0).to(
                self.device
            )
            token_types = encoded.get('token_type_ids')
            if token_types is not None:
                medplex_token_type_ids = token_types.unsqueeze(0).to(self.device)

        native_patch_size = (
            None
            if inference_native_patch_size is None
            else tuple(int(value) for value in inference_native_patch_size)
        )
        if native_patch_size is not None:
            if len(native_patch_size) != 3 or any(value <= 0 for value in native_patch_size):
                raise ValueError(
                    f"inference_native_patch_size must be three positive integers, got {native_patch_size}"
                )
            if (
                return_spatial_attention_maps
                or return_spatial_attention_maps_by_scale
                or return_native_response_maps
                or presence_diagnostic_callback is not None
            ):
                raise ValueError(
                    "Native zoom inference currently supports segmentation output only"
                )
        sliding_patch_size = native_patch_size or tuple(self.patch_size)

        empty_cache(self.device)
        with torch.autocast(
            self.device.type, enabled=True, dtype=self.amp_dtype
        ) if self.device.type == 'cuda' else dummy_context():

            # if input_image is smaller than tile_size we need to pad it to tile_size.
            data, slicer_revert_padding = pad_nd_image(input_image, sliding_patch_size,
                                                       'constant', {'value': 0}, True, None)
            diagnostic_target = None
            if presence_diagnostic_target is not None:
                diagnostic_target, _ = pad_nd_image(
                    presence_diagnostic_target,
                    sliding_patch_size,
                    'constant',
                    {'value': 0},
                    True,
                    None,
                )

            slicers = self._internal_get_sliding_window_slicers(
                data.shape[1:], patch_size=sliding_patch_size
            )

            model = self.network._orig_mod if isinstance(self.network, OptimizedModule) else self.network
            attention_enabled = bool(
                getattr(model, "enable_prompt_spatial_attention", False)
                or getattr(model, "enable_s2_attention", False)
                or getattr(model, "enable_s3_voxel_text_matching_attention", False)
            )
            attention_requested = (
                return_spatial_attention_maps or return_spatial_attention_maps_by_scale
            )
            if attention_requested and not attention_enabled:
                raise RuntimeError("Spatial attention maps requested from a model without spatial attention")
            if return_spatial_attention_maps_by_scale and return_native_response_maps:
                raise ValueError("Multiscale attention and native-response capture cannot be requested together")
            model.capture_spatial_attention_maps = bool(attention_requested)
            model.decoder.set_native_response_capture(return_native_response_maps)
            try:
                prediction_result = self._internal_predict_sliding_window_return_logits(
                    data,
                    text_embeddings,
                    slicers,
                    self.perform_everything_on_device,
                    spatial_attention_rho_scale=spatial_attention_rho_scale,
                    s3_attention_gate_scales_by_scale=s3_attention_gate_scales_by_scale,
                    s3_fullres_refinement_scale=s3_fullres_refinement_scale,
                    s3_joint_fusion_scale=s3_joint_fusion_scale,
                    presence_diagnostic_target=diagnostic_target,
                    presence_diagnostic_callback=presence_diagnostic_callback,
                    return_spatial_attention_maps=return_spatial_attention_maps,
                    return_spatial_attention_maps_by_scale=return_spatial_attention_maps_by_scale,
                    return_native_response_maps=return_native_response_maps,
                    inference_native_patch_size=native_patch_size,
                    category_indices=category_indices,
                    adaptive_rho_active_mask=adaptive_rho_active_mask,
                    anatomy_embeddings=anatomy_embeddings,
                    anatomy_valid_mask=anatomy_valid_mask,
                    prompt_adapter_injection_mode=prompt_adapter_injection_mode,
                    apply_prompt_residual_adapter=apply_prompt_residual_adapter,
                    token_features=token_features,
                    token_valid_mask=token_valid_mask,
                    encoder_residual_film_embedding=encoder_residual_film_embedding,
                    qwen_prefix_hidden=qwen_prefix_hidden,
                    qwen_attention_mask=qwen_attention_mask,
                    qwen_position_ids=qwen_position_ids,
                    medplex_input_ids=medplex_input_ids,
                    medplex_attention_mask=medplex_attention_mask,
                    medplex_token_type_ids=medplex_token_type_ids,
                )
            finally:
                model.capture_spatial_attention_maps = False
                model.decoder.set_native_response_capture(False)

            empty_cache(self.device)
            # Revert padding
            if return_spatial_attention_maps_by_scale:
                predicted_logits, attention_maps_by_scale = prediction_result
                predicted_logits = predicted_logits[(slice(None), *slicer_revert_padding[1:])]
                attention_maps_by_scale = {
                    scale: maps[(slice(None), *slicer_revert_padding[1:])]
                    for scale, maps in attention_maps_by_scale.items()
                }
                return predicted_logits, attention_maps_by_scale
            if return_spatial_attention_maps and return_native_response_maps:
                predicted_logits, attention_maps, native_response_maps = prediction_result
                predicted_logits = predicted_logits[(slice(None), *slicer_revert_padding[1:])]
                attention_maps = attention_maps[(slice(None), *slicer_revert_padding[1:])]
                native_response_maps = native_response_maps[(slice(None), *slicer_revert_padding[1:])]
                return predicted_logits, attention_maps, native_response_maps
            if return_spatial_attention_maps:
                predicted_logits, attention_maps = prediction_result
                predicted_logits = predicted_logits[(slice(None), *slicer_revert_padding[1:])]
                attention_maps = attention_maps[(slice(None), *slicer_revert_padding[1:])]
                return predicted_logits, attention_maps
            if return_native_response_maps:
                predicted_logits, native_response_maps = prediction_result
                predicted_logits = predicted_logits[(slice(None), *slicer_revert_padding[1:])]
                native_response_maps = native_response_maps[(slice(None), *slicer_revert_padding[1:])]
                return predicted_logits, native_response_maps
            predicted_logits = prediction_result[(slice(None), *slicer_revert_padding[1:])]
        return predicted_logits
    
    @torch.inference_mode()
    def _internal_predict_sliding_window_return_logits(
        self,
        data: torch.Tensor,
        text_embeddings: torch.Tensor,
        slicers: List[Tuple],
        do_on_device: bool = True,
        spatial_attention_rho_scale: Union[float, torch.Tensor, None] = None,
        s3_attention_gate_scales_by_scale: Union[dict[str, torch.Tensor], None] = None,
        s3_fullres_refinement_scale: Union[float, torch.Tensor, None] = None,
        s3_joint_fusion_scale: Union[float, torch.Tensor, None] = None,
        presence_diagnostic_target: Union[torch.Tensor, None] = None,
        presence_diagnostic_callback: Union[Callable[[list[dict]], None], None] = None,
        return_spatial_attention_maps: bool = False,
        return_spatial_attention_maps_by_scale: bool = False,
        return_native_response_maps: bool = False,
        inference_native_patch_size: Tuple[int, int, int] | None = None,
        category_indices: Union[torch.Tensor, None] = None,
        adaptive_rho_active_mask: Union[torch.Tensor, None] = None,
        anatomy_embeddings: Union[torch.Tensor, None] = None,
        anatomy_valid_mask: Union[torch.Tensor, None] = None,
        prompt_adapter_injection_mode: str = "shared",
        apply_prompt_residual_adapter: bool = True,
        token_features: Union[torch.Tensor, None] = None,
        token_valid_mask: Union[torch.Tensor, None] = None,
        encoder_residual_film_embedding: Union[torch.Tensor, None] = None,
        qwen_prefix_hidden: Union[torch.Tensor, None] = None,
        qwen_attention_mask: Union[torch.Tensor, None] = None,
        qwen_position_ids: Union[torch.Tensor, None] = None,
        medplex_input_ids: Union[torch.Tensor, None] = None,
        medplex_attention_mask: Union[torch.Tensor, None] = None,
        medplex_token_type_ids: Union[torch.Tensor, None] = None,
    ) -> Union[torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
        """
        Internal method for sliding window prediction with Gaussian weighting.
        
        Uses a producer-consumer pattern with threading to overlap data loading
        and model inference.
        
        Args:
            data: Preprocessed image data.
            text_embeddings: Text embeddings for prompts.
            slicers: List of slice tuples for patch extraction.
            do_on_device: If True, keep all tensors on GPU during computation.
            
        Returns:
            Aggregated prediction logits.
            
        Raises:
            RuntimeError: If inf values are encountered in predictions.
        """
        results_device = self.device if do_on_device else torch.device('cpu')

        def producer(data_tensor, slicer_list, queue):
            """Producer thread that loads patches into queue."""
            for slicer in slicer_list:
                patch = torch.clone(
                    data_tensor[slicer][None],
                    memory_format=torch.contiguous_format
                ).to(self.device)
                if inference_native_patch_size is not None:
                    patch = F.interpolate(
                        patch.float(),
                        size=tuple(self.patch_size),
                        mode="trilinear",
                        align_corners=False,
                    )
                queue.put((patch, slicer))
            queue.put('end')

        empty_cache(self.device)
        if spatial_attention_rho_scale is None:
            spatial_attention_rho_scale = self.spatial_attention_rho_scale
        if torch.is_tensor(spatial_attention_rho_scale):
            spatial_attention_rho_scale = spatial_attention_rho_scale.to(self.device)
        if s3_attention_gate_scales_by_scale is not None:
            s3_attention_gate_scales_by_scale = {
                scale: value.to(self.device) if torch.is_tensor(value) else value
                for scale, value in s3_attention_gate_scales_by_scale.items()
            }
        if torch.is_tensor(s3_fullres_refinement_scale):
            s3_fullres_refinement_scale = s3_fullres_refinement_scale.to(self.device)
        if torch.is_tensor(s3_joint_fusion_scale):
            s3_joint_fusion_scale = s3_joint_fusion_scale.to(self.device)
        if torch.is_tensor(category_indices):
            category_indices = category_indices.to(self.device, dtype=torch.long)
        if torch.is_tensor(adaptive_rho_active_mask):
            adaptive_rho_active_mask = adaptive_rho_active_mask.to(
                self.device, dtype=torch.bool
            )
        if torch.is_tensor(anatomy_embeddings):
            anatomy_embeddings = anatomy_embeddings.to(self.device)
        if torch.is_tensor(anatomy_valid_mask):
            anatomy_valid_mask = anatomy_valid_mask.to(self.device, dtype=torch.bool)
        if torch.is_tensor(token_features):
            token_features = token_features.to(self.device)
        if torch.is_tensor(token_valid_mask):
            token_valid_mask = token_valid_mask.to(self.device, dtype=torch.bool)
        if torch.is_tensor(encoder_residual_film_embedding):
            encoder_residual_film_embedding = encoder_residual_film_embedding.to(
                self.device
            )
        if torch.is_tensor(qwen_prefix_hidden):
            qwen_prefix_hidden = qwen_prefix_hidden.to(self.device)
        if torch.is_tensor(qwen_attention_mask):
            qwen_attention_mask = qwen_attention_mask.to(self.device, dtype=torch.long)
        if torch.is_tensor(qwen_position_ids):
            qwen_position_ids = qwen_position_ids.to(self.device, dtype=torch.long)
        if torch.is_tensor(medplex_input_ids):
            medplex_input_ids = medplex_input_ids.to(self.device, dtype=torch.long)
        if torch.is_tensor(medplex_attention_mask):
            medplex_attention_mask = medplex_attention_mask.to(
                self.device, dtype=torch.long
            )
        if torch.is_tensor(medplex_token_type_ids):
            medplex_token_type_ids = medplex_token_type_ids.to(
                self.device, dtype=torch.long
            )

        # move data to device
        data = data.to(results_device)
        queue = Queue(maxsize=2)
        t = Thread(target=producer, args=(data, slicers, queue))
        t.start()

        aggregate_probabilities = inference_native_patch_size is not None or (
            self.patch_presence_head_enabled
            and self.presence_gating_mode in {"multiply", "hard"}
        )
        accumulator_dtype = (
            torch.float32 if inference_native_patch_size is not None else torch.half
        )
        accumulator = torch.zeros((text_embeddings.shape[1], *data.shape[1:]),
                                  dtype=accumulator_dtype,
                                  device=results_device)
        attention_accumulator = None
        attention_accumulators_by_scale = None
        if return_spatial_attention_maps:
            attention_accumulator = torch.zeros_like(accumulator)
        if return_spatial_attention_maps_by_scale:
            attention_accumulators_by_scale = {}
        native_response_accumulator = None
        if return_native_response_maps:
            native_response_accumulator = torch.zeros_like(accumulator)
        n_predictions = torch.zeros(
            data.shape[1:], dtype=accumulator_dtype, device=results_device
        )
        if presence_diagnostic_target is not None:
            presence_diagnostic_target = presence_diagnostic_target.to(self.device)

        sliding_patch_size = (
            tuple(self.patch_size)
            if inference_native_patch_size is None
            else tuple(inference_native_patch_size)
        )
        gaussian = compute_gaussian(
            sliding_patch_size,
            sigma_scale=1. / 8,
            value_scaling_factor=10,
            dtype=accumulator_dtype,
            device=results_device
        )
        model = self.network._orig_mod if isinstance(self.network, OptimizedModule) else self.network
        forward_parameters = inspect.signature(model.forward).parameters

        with tqdm(desc=None, total=len(slicers)) as pbar:
            while True:
                item = queue.get()
                if item == 'end':
                    queue.task_done()
                    break
                patch, tile_slice = item
                forward_kwargs = {
                    "return_presence_logits": self.patch_presence_head_enabled,
                }
                if category_indices is not None:
                    l2_final_controller = getattr(
                        model, "_l2_final_residual_controller", None
                    )
                    if (
                        getattr(model, "category_2d_specialist", None) is not None
                        or getattr(model, "category_2d_dense_conversion", None) is not None
                        or getattr(model, "category_2d_dense_joint", None) is not None
                    ):
                        forward_kwargs["category_router_indices"] = category_indices
                    elif l2_final_controller is not None:
                        l2_final_controller.set_category_indices(
                            category_indices.to(device=patch.device, dtype=torch.long)
                        )
                    elif getattr(model, "adaptive_rho_adapter", None) is not None:
                        forward_kwargs["adaptive_rho_category_indices"] = category_indices
                        if adaptive_rho_active_mask is not None:
                            forward_kwargs["adaptive_rho_active_mask"] = (
                                adaptive_rho_active_mask
                            )
                    elif getattr(model, "category_attention_router", None) is not None:
                        forward_kwargs["category_router_indices"] = category_indices
                    elif getattr(model, "target_attention_adapter", None) is not None:
                        if adaptive_rho_active_mask is None:
                            raise ValueError("Target attention adapter requires a target-category mask")
                        forward_kwargs["target_attention_adapter_active_mask"] = (
                            adaptive_rho_active_mask
                        )
                    else:
                        forward_kwargs["category_indices"] = category_indices
                if (
                    getattr(model, "enable_prompt_spatial_attention", False)
                    or getattr(model, "enable_s2_attention", False)
                    or getattr(model, "enable_s3_voxel_text_matching_attention", False)
                ):
                    forward_kwargs["spatial_attention_rho_scale"] = spatial_attention_rho_scale
                if (
                    getattr(model, "enable_s3_voxel_text_matching_attention", False)
                    and s3_attention_gate_scales_by_scale is not None
                ):
                    forward_kwargs["s3_attention_gate_scales_by_scale"] = (
                        s3_attention_gate_scales_by_scale
                    )
                if getattr(model, "enable_s3_fullres_attention_refinement", False):
                    forward_kwargs["s3_fullres_refinement_scale"] = s3_fullres_refinement_scale
                if getattr(model, "enable_s3_joint_residual_fusion", False):
                    forward_kwargs["s3_joint_fusion_scale"] = s3_joint_fusion_scale
                if getattr(model, "enable_s2_attention", False):
                    forward_kwargs["s2_attention_scale_factors"] = self.s2_attention_scale_factors
                if anatomy_embeddings is not None:
                    forward_kwargs["anatomy_embedding"] = anatomy_embeddings
                    forward_kwargs["anatomy_valid_mask"] = anatomy_valid_mask
                if token_features is not None:
                    forward_kwargs["token_features"] = token_features
                    forward_kwargs["token_valid_mask"] = token_valid_mask
                if encoder_residual_film_embedding is not None:
                    forward_kwargs["encoder_residual_film_embedding"] = (
                        encoder_residual_film_embedding
                    )
                if qwen_prefix_hidden is not None:
                    forward_kwargs["qwen_prefix_hidden"] = qwen_prefix_hidden
                    forward_kwargs["qwen_attention_mask"] = qwen_attention_mask
                    forward_kwargs["qwen_position_ids"] = qwen_position_ids
                if medplex_input_ids is not None:
                    forward_kwargs["medplex_input_ids"] = medplex_input_ids
                    forward_kwargs["medplex_attention_mask"] = medplex_attention_mask
                    forward_kwargs["medplex_token_type_ids"] = medplex_token_type_ids
                # This option belongs to ExperimentalVoxTellModel. Keep the
                # predictor compatible with the standard VoxTellModel.
                if "prompt_adapter_injection_mode" in forward_parameters:
                    forward_kwargs["prompt_adapter_injection_mode"] = (
                        prompt_adapter_injection_mode
                    )
                forward_kwargs["apply_prompt_residual_adapter"] = (
                    apply_prompt_residual_adapter
                )
                model_output = self.network(
                    patch,
                    text_embeddings,
                    **forward_kwargs,
                )
                if return_spatial_attention_maps_by_scale:
                    model = self.network._orig_mod if isinstance(self.network, OptimizedModule) else self.network
                    maps_by_scale = getattr(model, "last_spatial_attention_maps_by_scale", None)
                    if not maps_by_scale:
                        raise RuntimeError("Expected multiscale spatial attention maps, but none were captured")
                    for scale, maps in maps_by_scale.items():
                        if len(maps) != text_embeddings.shape[1]:
                            raise RuntimeError(
                                f"Expected {text_embeddings.shape[1]} attention map(s) at {scale}, "
                                f"got {len(maps)}"
                            )
                        patch_attention = torch.cat([item[0] for item in maps], dim=0).squeeze(1)
                        patch_attention = F.interpolate(
                            patch_attention[:, None].float(),
                            size=tuple(self.patch_size),
                            mode="trilinear",
                            align_corners=False,
                        )[:, 0].to(device=results_device, dtype=torch.half)
                        if scale not in attention_accumulators_by_scale:
                            attention_accumulators_by_scale[scale] = torch.zeros_like(accumulator)
                        attention_accumulators_by_scale[scale][tile_slice] += patch_attention * gaussian
                elif return_spatial_attention_maps:
                    model = self.network._orig_mod if isinstance(self.network, OptimizedModule) else self.network
                    maps = getattr(model, "last_spatial_attention_maps", None)
                    if maps is None or len(maps) != text_embeddings.shape[1]:
                        raise RuntimeError(
                            f"Expected {text_embeddings.shape[1]} spatial attention map(s), "
                            f"got {0 if maps is None else len(maps)}"
                        )
                    patch_attention = torch.cat([item[0] for item in maps], dim=0).squeeze(1)
                    patch_attention = F.interpolate(
                        patch_attention[:, None].float(),
                        size=tuple(self.patch_size),
                        mode="trilinear",
                        align_corners=False,
                    )[:, 0].to(device=results_device, dtype=torch.half)
                    attention_accumulator[tile_slice] += patch_attention * gaussian
                if return_native_response_maps:
                    native_maps = getattr(model.decoder, "last_native_response_maps", None)
                    if native_maps is None or len(native_maps) != text_embeddings.shape[1]:
                        raise RuntimeError(
                            f"Expected {text_embeddings.shape[1]} native response map(s), "
                            f"got {0 if native_maps is None else len(native_maps)}"
                        )
                    # VoxTell uses all response channels by concatenating them into decoder features.
                    # This diagnostic uses a fixed channel mean, never a learned aggregator.
                    patch_native = torch.cat(native_maps, dim=0).mean(dim=1, keepdim=True)
                    patch_native = F.interpolate(
                        patch_native.float(), size=tuple(self.patch_size),
                        mode="trilinear", align_corners=False,
                    )[:, 0].to(device=results_device, dtype=torch.half)
                    native_response_accumulator[tile_slice] += patch_native * gaussian
                prediction_is_probability = False
                if self.patch_presence_head_enabled:
                    prediction, presence_logits = model_output
                    prediction = prediction[0]
                    presence_logits = presence_logits[0]
                    presence_prob = torch.sigmoid(presence_logits.float())
                    if self.presence_logit_weight != 0:
                        presence_offset = presence_logits.view(-1, 1, 1, 1)
                        prediction = prediction + self.presence_logit_weight * presence_offset
                    if self.presence_gating_mode in {"multiply", "hard"}:
                        probability = torch.sigmoid(prediction.float())
                        if self.presence_gating_mode == "multiply":
                            gate = presence_prob.pow(self.presence_gate_gamma).view(-1, 1, 1, 1)
                        else:
                            gate = (presence_prob >= self.presence_gate_tau).float().view(-1, 1, 1, 1)
                        prediction = probability * gate
                        prediction_is_probability = True
                    if presence_diagnostic_callback is not None:
                        records = []
                        spatial_slices = tile_slice[1:]
                        target_patch = None
                        if presence_diagnostic_target is not None:
                            target_patch = presence_diagnostic_target[(slice(None), *spatial_slices)]
                        pred_for_stats = torch.sigmoid(prediction.float()) if not aggregate_probabilities else prediction.float()
                        for prompt_idx in range(text_embeddings.shape[1]):
                            gt_voxels = 0
                            if target_patch is not None and prompt_idx < target_patch.shape[0]:
                                gt_voxels = int((target_patch[prompt_idx] > 0).sum().detach().cpu())
                            prompt_pred = pred_for_stats[prompt_idx]
                            records.append({
                                "prompt_index": int(prompt_idx),
                                "presence_logit": float(presence_logits[prompt_idx].detach().cpu()),
                                "presence_prob": float(presence_prob[prompt_idx].detach().cpu()),
                                "window_has_gt": bool(gt_voxels > 0),
                                "gt_voxels_in_window": gt_voxels,
                                "pred_prob_mean": float(prompt_pred.mean().detach().cpu()),
                                "pred_prob_max": float(prompt_pred.max().detach().cpu()),
                                "x0": int(spatial_slices[0].start),
                                "x1": int(spatial_slices[0].stop),
                                "y0": int(spatial_slices[1].start),
                                "y1": int(spatial_slices[1].stop),
                                "z0": int(spatial_slices[2].start),
                                "z1": int(spatial_slices[2].stop),
                            })
                        presence_diagnostic_callback(records)
                else:
                    prediction = model_output[0]
                if inference_native_patch_size is not None:
                    if not prediction_is_probability:
                        prediction = torch.sigmoid(prediction.float())
                    prediction = F.interpolate(
                        prediction[None].float(),
                        size=sliding_patch_size,
                        mode="trilinear",
                        align_corners=False,
                    )[0]
                prediction = prediction.to(device=results_device, dtype=accumulator.dtype)
                prediction *= gaussian
                accumulator[tile_slice] += prediction
                n_predictions[tile_slice[1:]] += gaussian
                queue.task_done()
                pbar.update()
        queue.join()

        # Normalize by number of predictions per voxel
        torch.div(accumulator, n_predictions, out=accumulator)
        if attention_accumulator is not None:
            torch.div(attention_accumulator, n_predictions, out=attention_accumulator)
        if attention_accumulators_by_scale is not None:
            for scale, scale_accumulator in attention_accumulators_by_scale.items():
                torch.div(scale_accumulator, n_predictions, out=scale_accumulator)
        if native_response_accumulator is not None:
            torch.div(native_response_accumulator, n_predictions, out=native_response_accumulator)
        if aggregate_probabilities:
            predicted_logits = torch.logit(accumulator.float().clamp(1e-6, 1 - 1e-6)).to(accumulator.dtype)
        else:
            predicted_logits = accumulator
        
        # Check for inf values
        if torch.any(torch.isinf(predicted_logits)):
            raise RuntimeError(
                'Encountered inf in predicted array. Aborting... '
                'If this problem persists, reduce value_scaling_factor in '
                'compute_gaussian or increase the dtype of predicted_logits to fp32.'
            )
        if attention_accumulators_by_scale is not None:
            return predicted_logits, attention_accumulators_by_scale
        if attention_accumulator is not None and native_response_accumulator is not None:
            return predicted_logits, attention_accumulator, native_response_accumulator
        if attention_accumulator is not None:
            return predicted_logits, attention_accumulator
        if native_response_accumulator is not None:
            return predicted_logits, native_response_accumulator
        return predicted_logits

    def predict_single_image(
        self,
        data: np.ndarray,
        text_prompts: Union[str, List[str]]
    ) -> np.ndarray:
        """
        Predict segmentation masks for a single image with text prompts.
        
        This is the main prediction method that orchestrates preprocessing,
        text embedding, sliding window inference, and postprocessing.
        
        Args:
            data: Image data in RAS orientation (3D or 4D with channel dimension).
            text_prompts: Single text prompt or list of text prompts describing
                anatomical structures to segment.
                
        Returns:
            Segmentation masks as numpy array of shape (num_prompts, X, Y, Z)
            with binary values (0 or 1) indicating the segmented regions.
        """

        # Preprocess image
        data, bbox, orig_shape = self.preprocess(data)

        # Embed text prompts
        embeddings = self.embed_text_prompts(text_prompts)

        # Predict segmentation logits
        prediction = self.predict_sliding_window_return_logits(data, embeddings).to('cpu')

        # Postprocess logits to get binary segmentation masks
        with torch.no_grad():
            prediction = torch.sigmoid(prediction.float()) > 0.5
        
        segmentation_reverted_cropping = np.zeros(
            [prediction.shape[0], *orig_shape],
            dtype=np.uint8
        )
        segmentation_reverted_cropping = insert_crop_into_image(
            segmentation_reverted_cropping, prediction, bbox
        )

        return segmentation_reverted_cropping


if __name__ == '__main__':
    from pathlib import Path
    from nnunetv2.imageio.nibabel_reader_writer import NibabelIOWithReorient

    # Default paths - modify these as needed
    DEFAULT_IMAGE_PATH = "/path/to/your/image.nii.gz"
    DEFAULT_MODEL_DIR = "/path/to/your/model/directory"
    
    # Configuration
    image_path = DEFAULT_IMAGE_PATH
    model_dir = DEFAULT_MODEL_DIR
    text_prompts = ["liver", "right kidney", "left kidney", "spleen"]
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    
    # Load image
    img, props = NibabelIOWithReorient().read_images([image_path])
    
    # Initialize predictor and run inference
    predictor = VoxTellPredictor(model_dir=model_dir, device=device)
    voxtell_seg = predictor.predict_single_image(img, text_prompts)
    
    # Visualize results, we reccommend using napari for 3D visualization
    import napari
    viewer = napari.Viewer()
    viewer.add_image(img, name='image')
    for i, prompt in enumerate(text_prompts):
        viewer.add_labels(voxtell_seg[i], name=f'voxtell_{prompt}')
    napari.run()
