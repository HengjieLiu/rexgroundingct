"""Conservative raw-HU input channel support for the multi-window pilot."""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch


DEFAULT_CENTER = -550.0
DEFAULT_WIDTH = 1000.0
DEFAULT_PREPROCESSING_VERSION = "rex_raw_ras_crop_nonzero_v1"


def hu_window(values: np.ndarray, center: float, width: float) -> np.ndarray:
    if width <= 0:
        raise ValueError("window width must be positive")
    lower = float(center) - float(width) / 2.0
    return np.clip((np.asarray(values, dtype=np.float32) - lower) / float(width), 0.0, 1.0)


def cache_key(case_id: str, center: float, width: float, preprocessing_version: str) -> str:
    identity = {
        "case_id": str(case_id),
        "center_hu": float(center),
        "width_hu": float(width),
        "preprocessing_version": str(preprocessing_version),
    }
    digest = hashlib.sha256(
        json.dumps(identity, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()[:16]
    stem = Path(str(case_id)).name.removesuffix(".nii.gz").removesuffix(".nii")
    return f"{stem}__c{center:g}_w{width:g}__{digest}"


class ConservativeWindowCache:
    """Separate, deterministic float16 cache built from true raw HU."""

    def __init__(
        self,
        cache_dir: Path,
        raw_image_dir: Path,
        center: float = DEFAULT_CENTER,
        width: float = DEFAULT_WIDTH,
        preprocessing_version: str = DEFAULT_PREPROCESSING_VERSION,
        lock_timeout_seconds: float = 900.0,
    ) -> None:
        self.cache_dir = Path(cache_dir)
        self.raw_image_dir = Path(raw_image_dir)
        self.center = float(center)
        self.width = float(width)
        self.preprocessing_version = str(preprocessing_version)
        self.lock_timeout_seconds = float(lock_timeout_seconds)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def path_for(self, case_id: str) -> Path:
        return self.cache_dir / f"{cache_key(case_id, self.center, self.width, self.preprocessing_version)}.npz"

    def _raw_path(self, case_id: str) -> Path:
        name = Path(str(case_id)).name
        candidates = [self.raw_image_dir / name]
        if not name.endswith(".nii.gz"):
            candidates.append(self.raw_image_dir / f"{name}.nii.gz")
        for candidate in candidates:
            if candidate.is_file():
                return candidate
        raise FileNotFoundError(f"Raw-HU NIfTI not found for {case_id}: {candidates}")

    def _read(self, path: Path, expected_shape: tuple[int, ...] | None) -> tuple[np.ndarray, dict[str, Any]]:
        try:
            with np.load(path, allow_pickle=False) as payload:
                channel = np.asarray(payload["window"], dtype=np.float16)
                metadata = json.loads(str(payload["metadata"].item()))
        except Exception as exc:
            raise RuntimeError(f"Failed to read conservative-window cache {path}: {exc}") from exc
        expected = {
            "center_hu": self.center,
            "width_hu": self.width,
            "preprocessing_version": self.preprocessing_version,
        }
        for key, value in expected.items():
            if metadata.get(key) != value:
                raise RuntimeError(f"Cache metadata mismatch in {path}: {key}")
        if expected_shape is not None and tuple(channel.shape) != tuple(expected_shape):
            raise RuntimeError(
                f"Cache shape mismatch for {path}: {channel.shape} != {tuple(expected_shape)}"
            )
        if not np.isfinite(channel).all() or float(channel.min()) < 0 or float(channel.max()) > 1:
            raise RuntimeError(f"Invalid window values in {path}")
        return channel, metadata

    def get(
        self, case_id: str, expected_shape: tuple[int, ...] | None = None
    ) -> tuple[np.ndarray, dict[str, Any]]:
        path = self.path_for(case_id)
        if path.is_file():
            return self._read(path, expected_shape)

        lock = path.with_suffix(path.suffix + ".lock")
        acquired = False
        deadline = time.monotonic() + self.lock_timeout_seconds
        while time.monotonic() < deadline:
            try:
                fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.close(fd)
                acquired = True
                break
            except FileExistsError:
                if path.is_file():
                    return self._read(path, expected_shape)
                time.sleep(0.2)
        if not acquired:
            raise TimeoutError(f"Timed out waiting for cache lock {lock}")

        try:
            if path.is_file():
                return self._read(path, expected_shape)
            # Import the audit implementation rather than duplicating its geometry.
            from tools.audit_lung_lesion_hu import load_raw_hu_in_training_geometry

            raw_path = self._raw_path(case_id)
            raw_hu, spacing, crop_bbox, header = load_raw_hu_in_training_geometry(raw_path)
            if expected_shape is not None and tuple(raw_hu.shape) != tuple(expected_shape):
                raise RuntimeError(
                    f"Raw-HU geometry mismatch for {case_id}: {raw_hu.shape} != {expected_shape}"
                )
            channel = hu_window(raw_hu, self.center, self.width).astype(np.float16)
            metadata = {
                "schema_version": 1,
                "case_id": str(case_id),
                "raw_path": str(raw_path),
                "center_hu": self.center,
                "width_hu": self.width,
                "lower_hu": self.center - self.width / 2.0,
                "upper_hu": self.center + self.width / 2.0,
                "preprocessing_version": self.preprocessing_version,
                "shape": list(channel.shape),
                "spacing": list(spacing),
                "crop_bbox": crop_bbox,
                "raw_header": header,
                "dtype": "float16",
                "minimum": float(channel.min()),
                "maximum": float(channel.max()),
            }
            temporary = path.with_suffix(path.suffix + f".tmp.{os.getpid()}.npz")
            np.savez_compressed(
                temporary,
                window=channel,
                metadata=np.asarray(json.dumps(metadata, sort_keys=True)),
            )
            os.replace(temporary, path)
            return self._read(path, expected_shape)
        except Exception as exc:
            raise RuntimeError(f"Failed to build conservative-window cache for {case_id}: {exc}") from exc
        finally:
            try:
                lock.unlink()
            except FileNotFoundError:
                pass


def inflate_stem_weights_strict(
    checkpoint_weights: dict[str, torch.Tensor],
    model_weights: dict[str, torch.Tensor],
) -> tuple[dict[str, torch.Tensor], list[dict[str, Any]]]:
    """Inflate only aliased encoder stem Conv3d keys from one to two channels."""
    adapted = dict(checkpoint_weights)
    changes: list[dict[str, Any]] = []
    mismatches: list[str] = []
    for key, target in model_weights.items():
        source = checkpoint_weights.get(key)
        if source is None:
            continue
        if tuple(source.shape) == tuple(target.shape):
            continue
        is_stem = (
            "encoder.stem" in key
            and source.ndim == target.ndim == 5
            and source.shape[1] == 1
            and target.shape[1] == 2
            and source.shape[0] == target.shape[0]
            and source.shape[2:] == target.shape[2:]
        )
        if not is_stem:
            mismatches.append(f"{key}: {tuple(source.shape)} -> {tuple(target.shape)}")
            continue
        expanded = torch.zeros(target.shape, dtype=source.dtype, device=source.device)
        expanded[:, 0].copy_(source[:, 0])
        adapted[key] = expanded
        changes.append(
            {
                "key": key,
                "old_shape": list(source.shape),
                "new_shape": list(target.shape),
                "initialization": "channel0=old_channel0; channel1=zeros",
            }
        )
    unexpected = sorted(set(checkpoint_weights) - set(model_weights))
    if mismatches or unexpected:
        raise RuntimeError(
            "Strict multi-window migration failed: "
            f"shape_mismatches={mismatches}, unexpected={unexpected}"
        )
    if not changes:
        raise RuntimeError("Strict multi-window migration found no 1->2 encoder stem key")
    return adapted, changes
