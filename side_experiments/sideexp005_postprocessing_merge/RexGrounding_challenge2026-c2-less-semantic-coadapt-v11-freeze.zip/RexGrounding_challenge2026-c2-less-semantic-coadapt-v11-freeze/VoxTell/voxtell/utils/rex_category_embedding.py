"""Fixed ReX category indices for the lightweight VoxTell category adapter."""

from __future__ import annotations

from collections.abc import Iterable

import torch


REX_CATEGORY_CODES = (
    "1a", "1b", "1c", "1d", "1e", "1f",
    "2a", "2b", "2c", "2d", "2e", "2f", "2g", "2h",
)
UNKNOWN_CATEGORY = "unknown"
CATEGORY_TO_INDEX = {
    UNKNOWN_CATEGORY: 0,
    **{code: index for index, code in enumerate(REX_CATEGORY_CODES, start=1)},
}
INDEX_TO_CATEGORY = {index: code for code, index in CATEGORY_TO_INDEX.items()}


def category_index(category: str | None) -> int:
    """Map dataset metadata to the fixed adapter index; unknown/padding is zero."""
    return CATEGORY_TO_INDEX.get(str(category), 0)


def category_indices(
    categories: Iterable[str | None],
    *,
    device: torch.device | str | None = None,
) -> torch.Tensor:
    return torch.tensor(
        [category_index(category) for category in categories],
        dtype=torch.long,
        device=device,
    )
