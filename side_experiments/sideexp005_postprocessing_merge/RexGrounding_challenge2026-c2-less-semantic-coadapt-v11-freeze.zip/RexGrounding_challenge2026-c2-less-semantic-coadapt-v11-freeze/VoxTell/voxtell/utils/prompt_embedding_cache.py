"""Read and validate legacy or versioned VoxTell prompt embedding caches."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch

from voxtell.utils.prompt_standardization import finding_id, text_hash


EmbeddingKey = tuple[str, str, int]


def record_key(record: dict[str, Any]) -> EmbeddingKey:
    return (record["split"], record.get("case", record.get("case_id")), int(record["finding_idx"]))


def load_embedding_cache(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Embedding cache not found: {path}")
    cache = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(cache, dict) or "embeddings" not in cache or "records" not in cache:
        raise ValueError(f"Malformed embedding cache: {path}")
    embeddings = cache["embeddings"].float()
    records = cache["records"]
    if embeddings.ndim != 2:
        raise ValueError(f"Expected 2D embeddings in {path}, got {tuple(embeddings.shape)}")
    if len(records) != embeddings.shape[0]:
        raise ValueError(f"Record/embedding count mismatch in {path}")
    mapping: dict[EmbeddingKey, torch.Tensor] = {}
    for index, record in enumerate(records):
        key = record_key(record)
        if key in mapping:
            raise ValueError(f"Duplicate embedding key {key} in {path}")
        mapping[key] = embeddings[index]
    return {
        **cache,
        "embeddings": embeddings,
        "mapping": mapping,
        "metadata": cache.get("metadata", {}),
        "legacy": "metadata" not in cache,
    }


def validate_embedding_cache(
    cache: dict[str, Any],
    expected_text: dict[EmbeddingKey, str],
    expected_dim: int = 2560,
) -> list[str]:
    errors: list[str] = []
    embeddings = cache["embeddings"]
    records = cache["records"]
    mapping = cache["mapping"]
    missing = sorted(expected_text.keys() - mapping.keys())
    unexpected = sorted(mapping.keys() - expected_text.keys())
    if missing:
        errors.append(f"missing {len(missing)} required findings; first={missing[0]}")
    if unexpected:
        errors.append(f"contains {len(unexpected)} unexpected findings; first={unexpected[0]}")
    if embeddings.shape[1] != expected_dim:
        errors.append(f"embedding dimension {embeddings.shape[1]} != {expected_dim}")
    if not torch.isfinite(embeddings).all():
        errors.append("embedding tensor contains NaN or Inf")
    seen_ids: set[str] = set()
    for record in records:
        key = record_key(record)
        stable_id = record.get("finding_id") or finding_id(*key)
        if stable_id in seen_ids:
            errors.append(f"duplicate finding_id {stable_id}")
        seen_ids.add(stable_id)
        expected = expected_text.get(key)
        if expected is None:
            continue
        actual = record.get("text", record.get("prompt"))
        if actual != expected:
            errors.append(f"text mismatch for {stable_id}")
        recorded_hash = record.get("text_hash")
        if recorded_hash is not None and recorded_hash != text_hash(expected):
            errors.append(f"text_hash mismatch for {stable_id}")
    return list(dict.fromkeys(errors))


class PromptEmbeddingSelector:
    """Select original/canonical embeddings without changing sample composition."""

    def __init__(
        self,
        original_mapping: dict[EmbeddingKey, torch.Tensor],
        canonical_mapping: dict[EmbeddingKey, torch.Tensor] | None = None,
        sidecar_records: dict[str, dict[str, Any]] | None = None,
        mode: str = "original",
        canonical_probability: float = 0.70,
        paired_consistency_probability: float = 0.25,
        fallback_confidence: float = 0.90,
    ) -> None:
        if mode not in {"original", "canonical", "random_mix", "paired_consistency"}:
            raise ValueError(f"Unknown prompt variant mode: {mode}")
        self.original_mapping = original_mapping
        self.canonical_mapping = canonical_mapping or {}
        self.sidecar_records = sidecar_records or {}
        self.mode = mode
        self.canonical_probability = float(canonical_probability)
        self.paired_consistency_probability = float(paired_consistency_probability)
        self.fallback_confidence = float(fallback_confidence)

    @staticmethod
    def _key(record: dict[str, Any]) -> EmbeddingKey:
        return (record["split"], record["case"], int(record["finding_idx"]))

    def canonical_status(self, record: dict[str, Any]) -> tuple[bool, str | None]:
        key = self._key(record)
        stable_id = finding_id(*key)
        if key not in self.canonical_mapping:
            return False, "missing_canonical_embedding"
        sidecar = self.sidecar_records.get(stable_id)
        if sidecar is None:
            return False, "missing_sidecar_record"
        qc = sidecar.get("quality_control") or {}
        confidence = float(qc.get("conversion_confidence", 0.0))
        if confidence < self.fallback_confidence:
            return False, "below_confidence_threshold"
        if not sidecar.get("canonical_visual_prompt", "").strip():
            return False, "invalid_canonical_prompt"
        return True, None

    def select_batch(
        self,
        records: list[dict[str, Any]],
        positive_flags: list[bool],
        rng,
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        if len(records) != len(positive_flags):
            raise ValueError("records and positive_flags must have equal length")
        selected = []
        variants = []
        fallback_reasons: list[str | None] = []
        paired_positions: list[int] = []
        paired_original = []
        paired_canonical = []
        selected_texts: list[str] = []
        for position, (record, is_positive) in enumerate(zip(records, positive_flags)):
            key = self._key(record)
            if key not in self.original_mapping:
                raise KeyError(f"Missing original embedding for {key}")
            canonical_ok, fallback_reason = self.canonical_status(record)
            use_canonical = False
            if self.mode == "canonical":
                use_canonical = canonical_ok
            elif self.mode in {"random_mix", "paired_consistency"}:
                # This random draw is intentionally absent in original mode so
                # the old sampler's RNG stream remains byte-for-byte compatible.
                use_canonical = canonical_ok and rng.random() < self.canonical_probability
            selected.append(self.canonical_mapping[key] if use_canonical else self.original_mapping[key])
            variants.append("canonical" if use_canonical else "original")
            sidecar = self.sidecar_records.get(finding_id(*key), {})
            selected_texts.append(
                sidecar.get("canonical_visual_prompt", record.get("prompt", ""))
                if use_canonical
                else record.get("prompt", sidecar.get("original_prompt", ""))
            )
            fallback_reasons.append(None if canonical_ok or self.mode == "original" else fallback_reason)
            if (
                self.mode == "paired_consistency"
                and is_positive
                and canonical_ok
                and rng.random() < self.paired_consistency_probability
            ):
                paired_positions.append(position)
                paired_original.append(self.original_mapping[key])
                paired_canonical.append(self.canonical_mapping[key])
        dimension = selected[0].shape[-1] if selected else 0
        empty = torch.empty((0, 1, dimension), dtype=torch.float32)
        positive_count = sum(bool(value) for value in positive_flags)
        negative_count = len(positive_flags) - positive_count
        fallback_positive_count = sum(
            reason is not None and is_positive
            for reason, is_positive in zip(fallback_reasons, positive_flags)
        )
        fallback_negative_count = sum(
            reason is not None and not is_positive
            for reason, is_positive in zip(fallback_reasons, positive_flags)
        )
        return torch.stack(selected).float()[:, None, :], {
            "selected_prompt_variants": variants,
            "selected_prompt_texts": selected_texts,
            "prompt_variant_fallback_reasons": fallback_reasons,
            "paired_positions": paired_positions,
            "paired_original_embeddings": torch.stack(paired_original).float()[:, None, :] if paired_original else empty,
            "paired_canonical_embeddings": torch.stack(paired_canonical).float()[:, None, :] if paired_canonical else empty,
            "prompt_variant_positive_count": positive_count,
            "prompt_variant_negative_count": negative_count,
            "prompt_variant_fallback_positive_count": fallback_positive_count,
            "prompt_variant_fallback_negative_count": fallback_negative_count,
            "prompt_variant_fallback_positive_rate": fallback_positive_count / max(positive_count, 1),
            "prompt_variant_fallback_negative_rate": fallback_negative_count / max(negative_count, 1),
        }
