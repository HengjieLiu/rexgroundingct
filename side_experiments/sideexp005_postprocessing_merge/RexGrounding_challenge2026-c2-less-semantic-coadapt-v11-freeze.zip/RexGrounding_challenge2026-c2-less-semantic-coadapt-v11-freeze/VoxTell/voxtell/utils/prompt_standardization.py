"""Versioned, conservative prompt variants for ReXGroundingCT findings."""

from __future__ import annotations

import hashlib
import json
import os
import re
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Protocol


SIDECAR_SCHEMA_VERSION = "rex_prompt_variants.v1"
RULE_CONVERTER_VERSION = "rule_only.v1.2"
PROMPT_TEMPLATE_VERSION = "canonical_visual.v1.2"
PROMPT_FIELDS = (
    "original_prompt",
    "canonical_full_prompt",
    "canonical_visual_prompt",
    "disease_only_prompt",
    "disease_anatomy_prompt",
)


def source_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def text_hash(text: str) -> str:
    return source_hash(text)


def finding_id(split: str, case_id: str, finding_idx: int | str) -> str:
    return f"{split}:{case_id}:finding_{int(finding_idx)}"


def normalize_space(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s+([,.;:])", r"\1", text)
    return text.strip(" ,;")


def sentence_case(text: str) -> str:
    text = normalize_space(text)
    if not text:
        return text
    text = text[0].upper() + text[1:]
    return text if text.endswith((".", "?", "!")) else text + "."


def _low(text: str) -> str:
    return normalize_space(text).lower()


def _has(text: str, pattern: str) -> bool:
    return re.search(pattern, text, flags=re.IGNORECASE) is not None


OBSERVATION_RULES: tuple[tuple[str, str, str], ...] = (
    ("calcified pulmonary nodule", r"(?:calcif\w*[^.;,]{0,35}nodul\w*|nodul\w*[^.;,]{0,35}calcif\w*)", "Calcified pulmonary nodule"),
    ("crazy-paving pattern", r"crazy[- ]paving", "Crazy-paving pattern"),
    ("ground-glass opacity", r"ground[- ]glass|\bggo\b", "Ground-glass opacity"),
    ("bronchiectasis", r"bronchiecta|bronchiolecta", "Bronchiectasis"),
    ("bronchial wall thickening", r"bronch(?:ial|us|i).*?(?:wall )?thicken|peribronchial thicken", "Bronchial wall thickening"),
    ("mosaic attenuation", r"mosaic attenuation", "Mosaic attenuation"),
    ("tree-in-bud opacity", r"tree[- ]in[- ]bud|budding tree", "Tree-in-bud opacity"),
    ("reticulonodular opacity", r"reticulonodular", "Reticulonodular opacity"),
    ("pleural effusion", r"pleural effusion|effusion.*pleur", "Pleural effusion"),
    ("pneumothorax", r"pneumothorax", "Pneumothorax"),
    ("emphysema", r"emphysem|centrilobular emphysema|paraseptal emphysema", "Emphysema"),
    ("atelectasis", r"atelecta", "Atelectasis"),
    ("scarring or fibrosis", r"fibro|fibrot|fibrosis|scar(?:ring)?|sequela", "Pulmonary scarring or fibrosis"),
    ("consolidation", r"consolid|pneumonic infiltrat", "Consolidation"),
    ("pulmonary nodule", r"\bnodul(?:e|es|ar)\b|pulmonary mass", "Pulmonary nodule"),
    ("pulmonary cyst", r"\b(?:air )?cyst(?:s|ic)?\b|\bbullae?\b", "Pulmonary cyst"),
    ("air trapping", r"air trapping", "Air trapping"),
    ("pulmonary opacity", r"\bopacit(?:y|ies)\b|\binfiltrat(?:e|es|ion|ions)\b|\bdensit(?:y|ies)\b", "Pulmonary opacity"),
    ("pleural thickening", r"pleural thicken", "Pleural thickening"),
    ("airway narrowing", r"luminal narrowing|airway narrowing|bronchial narrowing", "Airway narrowing"),
)


LOBE_PATTERNS: tuple[tuple[str, str], ...] = (
    ("RUL", r"right upper lobe|right lung upper lobe|upper lobe of (?:the )?right lung|\brul\b"),
    ("RML", r"right middle lobe|right lung middle lobe|middle lobe of (?:the )?right lung|\brml\b"),
    ("RLL", r"right lower lobe|right lung lower lobe|lower lobe of (?:the )?right lung|\brll\b"),
    ("LUL", r"left upper lobe|left lung upper lobe|upper lobe of (?:the )?left lung|\blingula(?:r)?\b|\blul\b"),
    ("LLL", r"left lower lobe|left lung lower lobe|lower lobe of (?:the )?left lung|\blll\b"),
)


SEGMENT_TERMS = (
    "anteromediobasal",
    "anteromedial basal",
    "anterolateral basal",
    "inferior lingular",
    "superior lingular",
    "lateral lingular",
    "lateral basal",
    "posterior basal",
    "apicoposterior",
    "posterobasal",
    "laterobasal",
    "mediobasal",
    "anterobasal",
    "anterior",
    "posterior",
    "apical",
    "superior",
    "inferior",
    "medial",
    "lateral",
    "lingular",
    "basal",
)
SEGMENT_TERM_PATTERN = "|".join(re.escape(value) for value in SEGMENT_TERMS)


RELATIVE_LOCATION_PATTERNS: tuple[tuple[str, str], ...] = (
    ("subpleural", r"subpleural"),
    ("peripheral", r"peripheral"),
    ("paramediastinal", r"paramediastinal"),
    ("paraspinal", r"paraspinal"),
    ("peribronchial", r"peribronchial"),
    ("adjacent to the diaphragm", r"adjacent to (?:the )?diaphragm"),
    ("adjacent to the pleura", r"adjacent to (?:the )?pleura"),
    ("posterior", r"\bposterior\b"),
    ("anterior", r"\banterior\b"),
)


MORPHOLOGY_PATTERNS: tuple[tuple[str, str], ...] = (
    ("calcified", r"calcif"),
    ("spiculated", r"spiculat"),
    ("irregular", r"irregular"),
    ("well-circumscribed", r"well[- ]circumscribed"),
    ("poorly circumscribed", r"poorly circumscribed|ill[- ]defined"),
    ("cavitary", r"cavitar|cavitation"),
    ("linear", r"\blinear\b"),
    ("nodular", r"\bnodular\b"),
    ("patchy", r"\bpatchy\b"),
)


ATTENUATION_PATTERNS: tuple[tuple[str, str], ...] = (
    ("ground-glass", r"ground[- ]glass"),
    ("calcified", r"calcif"),
    ("low attenuation", r"low attenuation|hypodense"),
)


TEMPORAL_PATTERNS: tuple[tuple[str, str], ...] = (
    ("stable", r"\bstable\b|unchanged|no (?:significant )?change"),
    ("new", r"\bnew(?:ly)?\b|newly developed|newly revealed|interval development"),
    ("increased", r"progress(?:ed|ive|ion)|increas(?:ed|ing)|worsen(?:ed|ing)"),
    ("decreased", r"regress(?:ed|ion)|decreas(?:ed|ing)|improv(?:ed|ement)"),
    ("resolved", r"resolv(?:ed|ing|ution)"),
)


DIAGNOSTIC_SPECULATION_PATTERNS = (
    r",?\s*(?:likely|probably|possibly)\s+(?:infectious|inflammatory|neoplastic|malignant)[^.;]*",
    r",?\s*(?:clinical|clinic(?:al)?[- ]lab) correlation[^.;]*",
    r",?\s*(?:follow[- ]?up|evaluation) is recommended[^.;]*",
)


NONVISUAL_STRIP_RULES: tuple[dict[str, Any], ...] = (
    {
        "rule_id": "TEMPORAL_NEWLY_DEVELOPED",
        "rule_category": "TEMPORAL_NEW",
        "pattern": r"\bnewly\s+(?:developed|developing|revealed|appearing|seen)\b",
        "replacement": " ",
        "removed_temporal_language": True,
    },
    {
        "rule_id": "TEMPORAL_NO_SIGNIFICANT_CHANGE_IN_ATTRIBUTE",
        "rule_category": "TEMPORAL_STABLE",
        "pattern": (
            r"\bno (?:significant )?change in (?:the )?"
            r"(?:size|amount|extent|number|appearance|density) of (?:the )?"
        ),
        "replacement": " ",
        "removed_temporal_language": True,
        "removed_comparison_language": True,
    },
    {
        "rule_id": "TEMPORAL_DIRECTIONAL_CHANGE",
        "rule_category": "TEMPORAL_CHANGE",
        "pattern": (
            r"\b(?:interval )?(?:increase|decrease|progression|regression|improvement|resolution) "
            r"(?:in|of) (?:the )?(?:(?:amount|size|extent|number|appearance) of (?:the )?)?"
        ),
        "replacement": " ",
        "removed_temporal_language": True,
    },
    {
        "rule_id": "TEMPORAL_INTERVAL_DEVELOPMENT",
        "rule_category": "TEMPORAL_NEW",
        "pattern": r"\binterval development of (?:the )?",
        "replacement": " ",
        "removed_temporal_language": True,
    },
    {
        "rule_id": "TEMPORAL_SINGLE_TOKEN",
        "rule_category": "TEMPORAL_STABLE_NEW_CHANGE",
        "pattern": (
            r"\b(?:stable|unchanged|new(?:ly)?|progressive|progressing|"
            r"recent(?:ly)?|regressed|regression of|improved|resolving|resolved)\b"
        ),
        "replacement": " ",
        "removed_temporal_language": True,
    },
    {
        "rule_id": "COMPARISON_PRIOR_EXAM",
        "rule_category": "COMPARISON_PRIOR",
        "pattern": r"\b(?:compared (?:with|to)|since) (?:the )?(?:prior|previous|last)[^,.;]*",
        "replacement": " ",
        "removed_comparison_language": True,
    },
    {
        "rule_id": "COMPARISON_CURRENT_PREVIOUS_EXAM",
        "rule_category": "COMPARISON_EXAM",
        "pattern": r"\bin (?:the )?(?:current|previous|prior) examination\b",
        "replacement": " ",
        "removed_comparison_language": True,
    },
    {
        "rule_id": "SPECULATION_COMPATIBLE_WITH_PREFIX",
        "rule_category": "SPECULATION_COMPATIBLE_WITH",
        "pattern": r"\b(?:findings? |appearance )?(?:consistent with|suggestive of|compatible with|in favor of)\s+",
        "replacement": "",
        "removed_speculation": True,
    },
    {
        "rule_id": "SPECULATION_LIKELY_DIAGNOSIS",
        "rule_category": "SPECULATION_LIKELY",
        "pattern": DIAGNOSTIC_SPECULATION_PATTERNS[0],
        "replacement": "",
        "removed_speculation": True,
    },
    {
        "rule_id": "RECOMMENDATION_CLINICAL_CORRELATION",
        "rule_category": "RECOMMENDATION_CORRELATION",
        "pattern": DIAGNOSTIC_SPECULATION_PATTERNS[1],
        "replacement": "",
        "removed_recommendation": True,
    },
    {
        "rule_id": "RECOMMENDATION_FOLLOWUP",
        "rule_category": "RECOMMENDATION_FOLLOWUP",
        "pattern": DIAGNOSTIC_SPECULATION_PATTERNS[2],
        "replacement": "",
        "removed_recommendation": True,
    },
)


def parse_laterality(text: str) -> str | None:
    low = text.lower()
    bilateral = _has(low, r"\bbilateral\b|\bboth lungs?\b|\bboth (?:upper|lower) lobes?\b")
    right = _has(low, r"\bright\b|\brul\b|\brml\b|\brll\b")
    left = _has(low, r"\bleft\b|\blingula(?:r)?\b|\blul\b|\blll\b")
    if bilateral or (left and right):
        return "bilateral"
    if right:
        return "right"
    if left:
        return "left"
    return None


def parse_lobes(text: str) -> list[str]:
    low = text.lower()
    lobes = [name for name, pattern in LOBE_PATTERNS if _has(low, pattern)]
    if _has(low, r"both upper lobes?"):
        lobes.extend(["RUL", "LUL"])
    if _has(low, r"both lower lobes?"):
        lobes.extend(["RLL", "LLL"])
    return list(dict.fromkeys(lobes))


def parse_segments(text: str) -> list[str]:
    segments = [
        f"{normalize_space(match.group(1).lower())} segment"
        for match in re.finditer(rf"\b({SEGMENT_TERM_PATTERN})\s+segments?\b", text, re.I)
    ]
    # Recover shared plural constructions such as "superior and posterobasal
    # segments", where only the second adjective is adjacent to "segments".
    for match in re.finditer(
        rf"\b({SEGMENT_TERM_PATTERN})\s+and\s+({SEGMENT_TERM_PATTERN})\s+segments?\b",
        text,
        re.I,
    ):
        segments.extend([
            f"{normalize_space(match.group(1).lower())} segment",
            f"{normalize_space(match.group(2).lower())} segment",
        ])
    return list(dict.fromkeys(segments))


def parse_measurements_mm(text: str) -> list[float]:
    values: list[float] = []
    pattern = r"(?<!\w)(\d+(?:\.\d+)?)\s*(mm|millimeters?|cm|centimeters?)\b"
    for value, unit in re.findall(pattern, text, flags=re.I):
        number = float(value)
        if unit.lower().startswith("cm") or unit.lower().startswith("centimeter"):
            number *= 10.0
        values.append(number)
    return values


def parse_temporal_change(text: str) -> str | None:
    for value, pattern in TEMPORAL_PATTERNS:
        if _has(text, pattern):
            return value
    return None


def parse_polarity(text: str) -> str:
    if _has(
        text,
        r"^no\b(?!\s+(?:significant\s+)?change\b)|"
        r"^(?:without|absence of)\b|\bnot (?:seen|detected|observed|present)\b",
    ):
        return "negative"
    if _has(text, r"\bpossible\b|\bsuspected\b|\bindeterminate\b|cannot exclude"):
        return "uncertain"
    return "positive"


def detect_observations(text: str) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    for key, pattern, display in OBSERVATION_RULES:
        if _has(text, pattern):
            if key == "pulmonary nodule" and any(item[0] == "calcified pulmonary nodule" for item in found):
                continue
            if key == "pulmonary opacity" and any(item[0] in {"ground-glass opacity", "consolidation"} for item in found):
                continue
            found.append((key, display))
    return found


def _content_flags(span: str) -> dict[str, bool]:
    return {
        "removed_uncertainty": _has(span, r"\bpossible\b|\bpossibly\b|\bprobably\b|\blikely\b|\bsuspected\b|cannot exclude"),
        "removed_visual_morphology": any(_has(span, pattern) for _, pattern in MORPHOLOGY_PATTERNS),
        "removed_visual_distribution": _has(span, r"\bdiffuse\b|multifocal|multiple|several|bilateral|all lobes"),
        "removed_anatomical_information": parse_laterality(span) is not None or bool(parse_lobes(span) or parse_segments(span)),
        "removed_severity": _has(span, r"\bminimal|mild|moderate|marked|severe|extensive\b"),
        "removed_count": _has(span, r"\b(single|solitary|one|two|three|few|several|multiple|numerous)\b"),
        "removed_size": bool(parse_measurements_mm(span)),
    }


def _apply_traceable_rule(
    text: str,
    rule: dict[str, Any],
    trace: list[dict[str, Any]],
) -> str:
    pattern = str(rule["pattern"])
    replacement = str(rule.get("replacement", ""))
    before = text
    matches = list(re.finditer(pattern, before, flags=re.I))
    if not matches:
        return text

    def replacement_fn(match: re.Match[str]) -> str:
        span = match.group(0)
        after_preview = before[: match.start()] + replacement + before[match.end() :]
        whitespace_only = normalize_space(span) == normalize_space(replacement)
        entry = {
            "rule_id": rule["rule_id"],
            "rule_category": rule["rule_category"],
            "source_span": span,
            "source_start": int(match.start()),
            "source_end": int(match.end()),
            "replacement_text": replacement,
            "text_before_operation": before,
            "text_after_operation": after_preview,
            "punctuation_or_whitespace_only": whitespace_only,
            "removed_temporal_language": bool(rule.get("removed_temporal_language", False)),
            "removed_comparison_language": bool(rule.get("removed_comparison_language", False)),
            "removed_speculation": bool(rule.get("removed_speculation", False)),
            "removed_recommendation": bool(rule.get("removed_recommendation", False)),
            "other_content_removed": False,
        }
        entry.update(_content_flags(span))
        trace.append(entry)
        return replacement

    return re.sub(pattern, replacement_fn, before, flags=re.I)


def _record_cleanup(before: str, after: str, rule_id: str, rule_category: str, trace: list[dict[str, Any]]) -> None:
    if before == after:
        return
    trace.append({
        "rule_id": rule_id,
        "rule_category": rule_category,
        "source_span": before,
        "source_start": 0,
        "source_end": len(before),
        "replacement_text": after,
        "text_before_operation": before,
        "text_after_operation": after,
        "punctuation_or_whitespace_only": normalize_space(before) == normalize_space(after),
        "removed_temporal_language": False,
        "removed_comparison_language": False,
        "removed_speculation": False,
        "removed_recommendation": False,
        "removed_uncertainty": False,
        "removed_visual_morphology": False,
        "removed_visual_distribution": False,
        "removed_anatomical_information": False,
        "removed_severity": False,
        "removed_count": False,
        "removed_size": False,
        "other_content_removed": False,
    })


def strip_nonvisual_language(text: str, return_trace: bool = False):
    trace: list[dict[str, Any]] = []
    initial = text
    out = normalize_space(text)
    _record_cleanup(initial, out, "CLEANUP_INITIAL_WHITESPACE", "CLEANUP_WHITESPACE", trace)

    # Remove complete comparison phrases before individual temporal tokens so
    # constructions such as "newly developed" do not leave "developed" behind.
    for rule in NONVISUAL_STRIP_RULES:
        out = _apply_traceable_rule(out, rule, trace)

    before = out
    out = normalize_space(out)
    _record_cleanup(before, out, "CLEANUP_NORMALIZE_SPACE", "CLEANUP_WHITESPACE", trace)

    before = out
    out = re.sub(r"\s+,", ",", out)
    _record_cleanup(before, out, "CLEANUP_SPACE_BEFORE_COMMA", "CLEANUP_PUNCTUATION", trace)

    before = out
    out = sentence_case(out)
    _record_cleanup(before, out, "CLEANUP_SENTENCE_CASE", "CLEANUP_SENTENCE_PREFIX", trace)
    if return_trace:
        return out, trace
    return out


def _anatomy_phrase(attributes: dict[str, Any]) -> str:
    lobes = attributes["lobe"]
    segments = attributes["segment"]
    laterality = attributes["laterality"]
    if lobes:
        labels = {
            "RUL": "right upper lobe", "RML": "right middle lobe", "RLL": "right lower lobe",
            "LUL": "left upper lobe", "LLL": "left lower lobe",
        }
        place = " and ".join(labels[value] for value in lobes)
    elif laterality == "bilateral":
        place = "both lungs"
    elif laterality in {"left", "right"}:
        place = f"the {laterality} lung"
    else:
        place = ""
    segment_phrase = " and ".join(segments)
    if segments and place:
        article = "" if place.startswith("the ") else "the "
        place = f"{segment_phrase} of {article}{place}"
    elif segments:
        place = segment_phrase
    return place


def structured_attributes(text: str) -> dict[str, Any]:
    observations = detect_observations(text)
    low = text.lower()
    if _has(low, r"\bdiffuse\b|throughout|all lobes|all segments"):
        distribution = "diffuse"
    elif _has(low, r"\bmultiple\b|\bseveral\b|\ba few\b|multifocal|bilateral"):
        distribution = "multifocal"
    elif observations:
        distribution = "focal"
    else:
        distribution = "unknown"
    count_match = re.search(r"\b(single|solitary|one|two|three|few|several|multiple|numerous)\b", low)
    severity_match = re.search(r"\b(minimal|mild|moderate|marked|severe|extensive)\b", low)
    return {
        "observation": observations[0][0] if observations else normalize_space(text).rstrip("."),
        "polarity": parse_polarity(text),
        "organ": "lung/pleura",
        "laterality": parse_laterality(text),
        "lobe": parse_lobes(text),
        "segment": parse_segments(text),
        "relative_location": [label for label, pattern in RELATIVE_LOCATION_PATTERNS if _has(text, pattern)],
        "size_values_mm": parse_measurements_mm(text),
        "count": count_match.group(1) if count_match else None,
        "morphology": [label for label, pattern in MORPHOLOGY_PATTERNS if _has(text, pattern)],
        "attenuation": [label for label, pattern in ATTENUATION_PATTERNS if _has(text, pattern)],
        "severity": severity_match.group(1) if severity_match else None,
        "distribution": distribution,
        "temporal_change": parse_temporal_change(text),
    }


def validate_record(record: dict[str, Any], strict_hash: bool = True) -> list[str]:
    errors: list[str] = []
    original = record.get("original_prompt", "")
    if not isinstance(original, str) or not original.strip():
        return ["empty original_prompt"]
    for field in PROMPT_FIELDS[1:]:
        value = record.get(field)
        if not isinstance(value, str) or not value.strip():
            errors.append(f"empty or malformed {field}")
    metadata = record.get("converter_metadata") or {}
    if strict_hash and metadata.get("source_hash") != source_hash(original):
        errors.append("source_hash mismatch")

    original_sizes = sorted(parse_measurements_mm(original))
    for field in ("canonical_full_prompt", "canonical_visual_prompt"):
        if sorted(parse_measurements_mm(record.get(field, ""))) != original_sizes:
            errors.append(f"measurement mismatch in {field}")

    source_side = parse_laterality(original)
    source_lobes = set(parse_lobes(original))
    source_polarity = parse_polarity(original)
    source_observations = {key for key, _ in detect_observations(original)}
    for field in ("canonical_full_prompt", "canonical_visual_prompt"):
        generated = record.get(field, "")
        generated_observations = {key for key, _ in detect_observations(generated)}
        if parse_laterality(generated) != source_side:
            errors.append(f"laterality mismatch in {field}")
        if not set(parse_lobes(generated)).issubset(source_lobes):
            errors.append(f"unsupported lobe in {field}")
        if parse_polarity(generated) != source_polarity:
            errors.append(f"polarity mismatch in {field}")
        if generated_observations - source_observations:
            errors.append(f"unsupported finding type in {field}")
    return list(dict.fromkeys(errors))


def make_rule_only_record(
    *,
    split: str,
    case_id: str,
    finding_idx: int,
    original_prompt: str,
    generated_at: str | None = None,
) -> dict[str, Any]:
    original = sentence_case(original_prompt)
    attrs = structured_attributes(original)
    observations = detect_observations(original)
    non_atomic = len(observations) > 1
    disease = observations[0][1] if observations else normalize_space(original).rstrip(".")
    anatomy = _anatomy_phrase(attrs)
    disease_only = sentence_case(disease)
    disease_anatomy = sentence_case(f"{disease} in {anatomy}" if anatomy else disease)
    visual = strip_nonvisual_language(original)
    confidence = 0.98 if len(observations) == 1 else (0.88 if observations else 0.70)
    record = {
        "finding_id": finding_id(split, case_id, finding_idx),
        "case_id": case_id,
        "finding_idx": int(finding_idx),
        "split": split,
        "original_prompt": original_prompt,
        "canonical_full_prompt": original,
        "canonical_visual_prompt": visual,
        "disease_only_prompt": disease_only,
        "disease_anatomy_prompt": disease_anatomy,
        "structured_attributes": attrs,
        "quality_control": {
            "conversion_confidence": confidence,
            "non_atomic_flag": non_atomic,
            "unsupported_added_information": [],
            "missing_original_information": [],
            "preserved_numeric_values": True,
            "preserved_laterality": True,
            "requires_review": non_atomic or confidence < 0.90,
        },
        "converter_metadata": {
            "converter_name": "rule_only",
            "converter_version": RULE_CONVERTER_VERSION,
            "prompt_template_version": PROMPT_TEMPLATE_VERSION,
            "generated_at": generated_at or datetime.now(timezone.utc).isoformat(),
            "source_hash": source_hash(original_prompt),
        },
    }
    errors = validate_record(record)
    qc = record["quality_control"]
    qc["preserved_numeric_values"] = not any("measurement mismatch" in value for value in errors)
    qc["preserved_laterality"] = not any("laterality mismatch" in value for value in errors)
    qc["unsupported_added_information"] = [value for value in errors if "unsupported" in value or "mismatch" in value]
    qc["requires_review"] = qc["requires_review"] or bool(errors)
    return record


class PromptConverter(Protocol):
    name: str

    def convert(self, source: dict[str, Any]) -> dict[str, Any]: ...


@dataclass
class RuleOnlyConverter:
    name: str = "rule_only"

    def convert(self, source: dict[str, Any]) -> dict[str, Any]:
        return make_rule_only_record(**source)


class ImportExistingJsonlConverter:
    name = "import_existing_jsonl"

    def __init__(self, path: Path):
        self.records, _ = load_sidecar(path)

    def convert(self, source: dict[str, Any]) -> dict[str, Any]:
        key = finding_id(source["split"], source["case_id"], source["finding_idx"])
        if key not in self.records:
            raise KeyError(f"Imported sidecar is missing {key}")
        record = self.records[key]
        if record.get("original_prompt") != source["original_prompt"]:
            raise ValueError(f"Imported sidecar source text differs for {key}")
        if (record.get("converter_metadata") or {}).get("source_hash") != source_hash(source["original_prompt"]):
            raise ValueError(f"Imported sidecar source hash is stale for {key}")
        return record


CONVERTER_SYSTEM_PROMPT = """You standardize one CT finding without adding medical facts.
Return exactly one JSON object with these keys: canonical_full_prompt,
canonical_visual_prompt, disease_only_prompt, disease_anatomy_prompt,
structured_attributes, quality_control. Preserve every numeric measurement,
laterality, lobe, segment, negation, count, morphology, and attenuation supported
by the source. canonical_visual_prompt removes temporal comparison, diagnostic
speculation, recommendations, and management language. Never split or merge the
finding. Set non_atomic_flag=true if independent abnormalities are combined.
Do not wrap the JSON in markdown."""


def _converter_user_prompt(source: dict[str, Any]) -> str:
    return json.dumps(
        {
            "finding_id": finding_id(source["split"], source["case_id"], source["finding_idx"]),
            "original_prompt": source["original_prompt"],
            "required_structured_attribute_keys": list(structured_attributes("").keys()),
            "required_quality_control_keys": [
                "conversion_confidence",
                "non_atomic_flag",
                "unsupported_added_information",
                "missing_original_information",
                "preserved_numeric_values",
                "preserved_laterality",
                "requires_review",
            ],
        },
        ensure_ascii=True,
    )


def _parse_strict_json_object(value: str) -> dict[str, Any]:
    value = value.strip()
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as error:
        raise ValueError("Converter did not return strict JSON") from error
    if not isinstance(parsed, dict):
        raise ValueError("Converter output must be one JSON object")
    return parsed


def _finalize_generated_record(
    generated: dict[str, Any],
    source: dict[str, Any],
    *,
    converter_name: str,
    converter_version: str,
) -> dict[str, Any]:
    """Bind generated fields to immutable source identity and fill schema defaults."""
    original = source["original_prompt"]
    fallback = make_rule_only_record(**source)
    attrs = generated.get("structured_attributes")
    if not isinstance(attrs, dict):
        attrs = fallback["structured_attributes"]
    else:
        attrs = {**fallback["structured_attributes"], **attrs}
    qc = generated.get("quality_control")
    if not isinstance(qc, dict):
        qc = {}
    qc = {**fallback["quality_control"], **qc}
    for key in ("unsupported_added_information", "missing_original_information"):
        if not isinstance(qc.get(key), list):
            qc[key] = [str(qc[key])] if qc.get(key) else []
    try:
        qc["conversion_confidence"] = float(qc["conversion_confidence"])
    except (TypeError, ValueError):
        qc["conversion_confidence"] = 0.0
        qc["requires_review"] = True
    record = {
        "finding_id": finding_id(source["split"], source["case_id"], source["finding_idx"]),
        "case_id": source["case_id"],
        "finding_idx": int(source["finding_idx"]),
        "split": source["split"],
        "original_prompt": original,
        "canonical_full_prompt": generated.get("canonical_full_prompt", ""),
        "canonical_visual_prompt": generated.get("canonical_visual_prompt", ""),
        "disease_only_prompt": generated.get("disease_only_prompt", ""),
        "disease_anatomy_prompt": generated.get("disease_anatomy_prompt", ""),
        "structured_attributes": attrs,
        "quality_control": qc,
        "converter_metadata": {
            "converter_name": converter_name,
            "converter_version": converter_version,
            "prompt_template_version": PROMPT_TEMPLATE_VERSION,
            "generated_at": source.get("generated_at") or datetime.now(timezone.utc).isoformat(),
            "source_hash": source_hash(original),
        },
    }
    errors = validate_record(record)
    if errors:
        record["quality_control"]["requires_review"] = True
        record["quality_control"]["unsupported_added_information"] = list(dict.fromkeys(
            [*record["quality_control"]["unsupported_added_information"], *errors]
        ))
    return record


@dataclass
class OpenAICompatibleConverter:
    """Optional Chat Completions-compatible converter with strict JSON output."""

    endpoint: str
    model: str
    api_key: str | None = None
    timeout_seconds: int = 120
    name: str = "openai_compatible"

    def __post_init__(self) -> None:
        self.endpoint = self.endpoint or os.environ.get("PROMPT_CONVERTER_ENDPOINT", "")
        self.model = self.model or os.environ.get("PROMPT_CONVERTER_MODEL", "")
        self.api_key = self.api_key or os.environ.get("PROMPT_CONVERTER_API_KEY")
        if not self.endpoint or not self.model:
            raise ValueError("openai_compatible requires endpoint and model")

    def convert(self, source: dict[str, Any]) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "temperature": 0,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": CONVERTER_SYSTEM_PROMPT},
                {"role": "user", "content": _converter_user_prompt(source)},
            ],
        }
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        request = urllib.request.Request(
            self.endpoint,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                body = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, json.JSONDecodeError) as error:
            raise RuntimeError(f"Prompt converter request failed: {error}") from error
        try:
            content = body["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as error:
            raise ValueError("Malformed Chat Completions response") from error
        generated = _parse_strict_json_object(content)
        return _finalize_generated_record(
            generated,
            source,
            converter_name=self.name,
            converter_version=f"{self.model}:temperature0",
        )


@dataclass
class LocalHuggingFaceConverter:
    """Optional local instruction-model converter; downloads are disabled by default."""

    model_name_or_path: str
    device: str = "cuda"
    local_files_only: bool = True
    max_new_tokens: int = 1600
    name: str = "local_huggingface"

    def __post_init__(self) -> None:
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_name_or_path,
            local_files_only=self.local_files_only,
        )
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_name_or_path,
            local_files_only=self.local_files_only,
            device_map={"": self.device},
        ).eval()

    def convert(self, source: dict[str, Any]) -> dict[str, Any]:
        import torch

        messages = [
            {"role": "system", "content": CONVERTER_SYSTEM_PROMPT},
            {"role": "user", "content": _converter_user_prompt(source)},
        ]
        try:
            rendered = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=False,
            )
        except TypeError:
            rendered = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )
        inputs = self.tokenizer(rendered, return_tensors="pt").to(self.model.device)
        with torch.inference_mode():
            output = self.model.generate(
                **inputs,
                do_sample=False,
                max_new_tokens=self.max_new_tokens,
            )
        content = self.tokenizer.decode(output[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)
        generated = _parse_strict_json_object(content)
        return _finalize_generated_record(
            generated,
            source,
            converter_name=self.name,
            converter_version=str(self.model_name_or_path),
        )


def load_sidecar(path: Path) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    records: dict[str, dict[str, Any]] = {}
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            record = json.loads(line)
            key = record.get("finding_id")
            if not key:
                raise ValueError(f"{path}:{line_number}: missing finding_id")
            if key in records:
                raise ValueError(f"{path}:{line_number}: duplicate finding_id {key}")
            records[key] = record
    meta_path = path.with_suffix(".meta.json")
    metadata = json.loads(meta_path.read_text()) if meta_path.exists() else {}
    return records, metadata


def write_sidecar(path: Path, records: Iterable[dict[str, Any]], metadata: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=True, sort_keys=True) + "\n")
    path.with_suffix(".meta.json").write_text(
        json.dumps({"schema_version": SIDECAR_SCHEMA_VERSION, **metadata}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def collect_rex_sources(rex_json: Path, splits: Iterable[str]) -> list[dict[str, Any]]:
    data = json.loads(rex_json.read_text(encoding="utf-8"))
    sources: list[dict[str, Any]] = []
    for split in splits:
        for case in data[split]:
            for idx, prompt in sorted(case["findings"].items(), key=lambda item: int(item[0])):
                sources.append(
                    {
                        "split": split,
                        "case_id": case["name"],
                        "finding_idx": int(idx),
                        "original_prompt": prompt,
                    }
                )
    return sources
