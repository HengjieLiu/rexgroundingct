"""ReXGroundingCT category-aware prompt helpers.

The category names mirror the ReXGroundingCT hierarchical finding tree for the
lung/airway/pleural categories used by the MICCAI challenge.
"""

from __future__ import annotations

import re


CATEGORY_NAME_BY_CODE: dict[str, str] = {
    "1a": "Bronchial wall thickening",
    "1b": "Bronchiectasis",
    "1c": "Emphysema (including Centrilobular, Paraseptal, Bullous)",
    "1d": "Septal thickening (including Interlobular, Reticulation)",
    "1e": "Micronodules (including Centrilobular, Tree-in-bud, Perilymphatic)",
    "1f": "Other",
    "2a": "Linear (including subsegmental atelectasis, scarring, fibrosis)",
    "2b": "Atelectasis, consolidation",
    "2c": "Groundglass opacity",
    "2d": "Pulmonary nodules/masses",
    "2e": "Pleural effusion or thickening",
    "2f": "Honeycombing",
    "2g": "Pneumothorax",
    "2h": "Other",
}


def normalize_prompt_whitespace(text: str) -> str:
    """Normalize accidental whitespace without changing wording."""
    return re.sub(r"\s+", " ", str(text)).strip()


def build_finding_prompt(
    original_text: str,
    category_code: str | None,
    category_name: str | None,
    prompt_mode: str,
) -> str:
    """Build the prompt text for one ReX finding.

    ``original`` returns the original finding text after whitespace cleanup.
    ``category_prefix`` prepends the dataset category while preserving the
    original finding text verbatim apart from whitespace cleanup.
    """
    original = normalize_prompt_whitespace(original_text)
    if prompt_mode == "original":
        return original
    if prompt_mode != "category_prefix":
        raise ValueError(f"Unknown prompt_mode: {prompt_mode}")

    code = normalize_prompt_whitespace(category_code or "")
    name = normalize_prompt_whitespace(category_name or "")
    if not code:
        raise ValueError("Missing ReX category code for category_prefix prompt")
    if not name:
        raise ValueError(f"Missing ReX category name for code {code!r}")
    return f"Category: {code}, {name}.\nFinding: {original}"


def category_name_for_code(category_code: str | None) -> str | None:
    code = normalize_prompt_whitespace(category_code or "")
    return CATEGORY_NAME_BY_CODE.get(code)
