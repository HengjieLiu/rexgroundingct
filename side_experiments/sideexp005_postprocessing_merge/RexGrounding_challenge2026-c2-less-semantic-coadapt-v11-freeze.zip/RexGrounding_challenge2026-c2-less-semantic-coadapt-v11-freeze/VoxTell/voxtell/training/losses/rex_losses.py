"""Explicit ReX/VoxTell loss functions.

All functions in this module accept logits and apply sigmoid internally exactly
once. The returned per-prompt tensors have shape ``(B, P)`` for inputs shaped
``(B, P, D, H, W)``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import distance_transform_edt


SPATIAL_DIMS = tuple(range(2, 5))


@dataclass(frozen=True)
class UnifiedFocalComponents:
    total: torch.Tensor
    asymmetric_focal_ce: torch.Tensor
    asymmetric_focal_tversky: torch.Tensor


def _check_shapes(logits: torch.Tensor, target: torch.Tensor) -> None:
    if logits.shape != target.shape:
        raise ValueError(f"logits shape {tuple(logits.shape)} != target shape {tuple(target.shape)}")
    if logits.ndim != 5:
        raise ValueError(f"expected logits/target shaped (B, P, D, H, W), got {tuple(logits.shape)}")


def _prompt_coefficient(
    value: float | torch.Tensor,
    reference: torch.Tensor,
    name: str,
) -> torch.Tensor:
    """Return a scalar or (B, P) coefficient on the reference device."""
    coefficient = torch.as_tensor(value, dtype=reference.dtype, device=reference.device)
    if coefficient.ndim == 0:
        return coefficient
    if coefficient.shape != reference.shape:
        raise ValueError(
            f"{name} must be scalar or shaped {tuple(reference.shape)}, got {tuple(coefficient.shape)}"
        )
    return coefficient


def resolve_category_tversky_parameters(
    categories: list[list[str]] | list[str],
    mapping: dict[str, dict[str, Any]],
    *,
    device: torch.device,
    dtype: torch.dtype = torch.float32,
) -> tuple[torch.Tensor, torch.Tensor, list[list[str]]]:
    """Resolve category labels to per-prompt alpha/beta with a safe mixed fallback."""
    normalized = categories if categories and isinstance(categories[0], list) else [categories]
    alpha_rows: list[list[float]] = []
    beta_rows: list[list[float]] = []
    group_rows: list[list[str]] = []
    for row in normalized:
        alpha_row: list[float] = []
        beta_row: list[float] = []
        group_row: list[str] = []
        for category in row:
            config = mapping.get(str(category), {})
            alpha_row.append(float(config.get("alpha_fp", 0.5)))
            beta_row.append(float(config.get("beta_fn", 0.5)))
            group_row.append(str(config.get("group", "mixed")))
        alpha_rows.append(alpha_row)
        beta_rows.append(beta_row)
        group_rows.append(group_row)
    return (
        torch.tensor(alpha_rows, device=device, dtype=dtype),
        torch.tensor(beta_rows, device=device, dtype=dtype),
        group_rows,
    )


def tversky_index_per_prompt_from_logits(
    logits: torch.Tensor,
    target: torch.Tensor,
    fp_weight: float | torch.Tensor = 0.3,
    fn_weight: float | torch.Tensor = 0.7,
    eps: float = 1e-6,
) -> torch.Tensor:
    """Binary foreground Tversky index per image-prompt pair."""
    _check_shapes(logits, target)
    prob = torch.sigmoid(logits.float())
    target = target.float()
    tp = (prob * target).sum(dim=SPATIAL_DIMS)
    fp = (prob * (1.0 - target)).sum(dim=SPATIAL_DIMS)
    fn = ((1.0 - prob) * target).sum(dim=SPATIAL_DIMS)
    alpha = _prompt_coefficient(fp_weight, tp, "fp_weight")
    beta = _prompt_coefficient(fn_weight, tp, "fn_weight")
    return (tp + eps) / (tp + alpha * fp + beta * fn + eps)


def tversky_loss_per_prompt_from_logits(
    logits: torch.Tensor,
    target: torch.Tensor,
    fp_weight: float | torch.Tensor = 0.3,
    fn_weight: float | torch.Tensor = 0.7,
    eps: float = 1e-6,
) -> torch.Tensor:
    return 1.0 - tversky_index_per_prompt_from_logits(
        logits,
        target,
        fp_weight=fp_weight,
        fn_weight=fn_weight,
        eps=eps,
    )


def focal_tversky_loss_per_prompt_from_logits(
    logits: torch.Tensor,
    target: torch.Tensor,
    fp_weight: float = 0.3,
    fn_weight: float = 0.7,
    gamma: float = 4.0 / 3.0,
    convention: str = "original_paper",
    eps: float = 1e-6,
) -> torch.Tensor:
    """Focal Tversky loss with explicit exponent convention.

    ``original_paper`` implements Abraham & Khan Eq. (4):
    ``(1 - TI) ** (1 / gamma)``.
    ``power`` implements the common alternative: ``(1 - TI) ** gamma``.
    """
    focal_floor = min(float(eps), 1e-8)
    base = tversky_loss_per_prompt_from_logits(
        logits,
        target,
        fp_weight=fp_weight,
        fn_weight=fn_weight,
        eps=eps,
    ).clamp_min(focal_floor)
    if convention == "original_paper":
        return base.pow(1.0 / float(gamma))
    if convention == "power":
        return base.pow(float(gamma))
    raise ValueError(f"Unsupported focal Tversky convention: {convention!r}")


def asymmetric_focal_ce_per_prompt_from_logits(
    logits: torch.Tensor,
    target: torch.Tensor,
    delta: float = 0.6,
    gamma: float = 0.5,
    eps: float = 1e-6,
) -> torch.Tensor:
    """Asymmetric focal cross-entropy from Unified Focal Loss Eq. (14).

    Foreground is the rare class. The focal factor is removed for foreground
    voxels and retained for background voxels.
    """
    _check_shapes(logits, target)
    prob = torch.sigmoid(logits.float()).clamp(eps, 1.0 - eps)
    target = target.float()
    foreground_ce = -float(delta) * target * torch.log(prob)
    background_ce = -(1.0 - float(delta)) * (1.0 - target) * prob.pow(float(gamma)) * torch.log(1.0 - prob)
    return (foreground_ce + background_ce).mean(dim=SPATIAL_DIMS)


def asymmetric_focal_tversky_per_prompt_from_logits(
    logits: torch.Tensor,
    target: torch.Tensor,
    delta: float = 0.6,
    gamma: float = 0.5,
    eps: float = 1e-6,
) -> torch.Tensor:
    """Asymmetric modified focal Tversky from Unified Focal Loss Eq. (15)."""
    _check_shapes(logits, target)
    prob_fg = torch.sigmoid(logits.float())
    target_fg = target.float()
    prob_bg = 1.0 - prob_fg
    target_bg = 1.0 - target_fg

    tp_fg = (prob_fg * target_fg).sum(dim=SPATIAL_DIMS)
    fn_fg = ((1.0 - prob_fg) * target_fg).sum(dim=SPATIAL_DIMS)
    fp_fg = (prob_fg * (1.0 - target_fg)).sum(dim=SPATIAL_DIMS)
    ti_fg = (tp_fg + eps) / (tp_fg + float(delta) * fn_fg + (1.0 - float(delta)) * fp_fg + eps)

    tp_bg = (prob_bg * target_bg).sum(dim=SPATIAL_DIMS)
    fn_bg = ((1.0 - prob_bg) * target_bg).sum(dim=SPATIAL_DIMS)
    fp_bg = (prob_bg * (1.0 - target_bg)).sum(dim=SPATIAL_DIMS)
    ti_bg = (tp_bg + eps) / (tp_bg + float(delta) * fn_bg + (1.0 - float(delta)) * fp_bg + eps)

    background_loss = 1.0 - ti_bg
    focal_floor = min(float(eps), 1e-8)
    foreground_loss = (1.0 - ti_fg).clamp_min(focal_floor).pow(1.0 - float(gamma))
    return 0.5 * (background_loss + foreground_loss)


def asymmetric_unified_focal_per_prompt_from_logits(
    logits: torch.Tensor,
    target: torch.Tensor,
    lambda_weight: float = 0.5,
    delta: float = 0.6,
    gamma: float = 0.5,
    eps: float = 1e-6,
) -> UnifiedFocalComponents:
    """Asymmetric Unified Focal loss per prompt.

    We follow the paper notation in Eq. (16):
    ``aUF = lambda * maF + (1 - lambda) * maFT``.
    """
    ce = asymmetric_focal_ce_per_prompt_from_logits(
        logits,
        target,
        delta=delta,
        gamma=gamma,
        eps=eps,
    )
    ft = asymmetric_focal_tversky_per_prompt_from_logits(
        logits,
        target,
        delta=delta,
        gamma=gamma,
        eps=eps,
    )
    total = float(lambda_weight) * ce + (1.0 - float(lambda_weight)) * ft
    return UnifiedFocalComponents(total=total, asymmetric_focal_ce=ce, asymmetric_focal_tversky=ft)


def signed_distance_map(mask: np.ndarray, normalize: bool = False) -> np.ndarray:
    """Return phi_G = distance_outside - distance_inside for a binary 3D mask."""
    mask_bool = np.asarray(mask).astype(bool)
    if not mask_bool.any():
        raise ValueError("signed_distance_map requires a non-empty mask")
    outside = distance_transform_edt(~mask_bool)
    inside = distance_transform_edt(mask_bool)
    sdf = outside.astype(np.float32) - inside.astype(np.float32)
    if normalize:
        max_abs = float(np.max(np.abs(sdf)))
        if max_abs > 0:
            sdf = sdf / max_abs
    return sdf.astype(np.float32, copy=False)


def signed_distance_maps_from_target(target: torch.Tensor, normalize: bool = False) -> torch.Tensor:
    """Build SDF maps for ``target``; empty prompt maps are zeros."""
    if target.ndim != 5:
        raise ValueError(f"expected target shaped (B, P, D, H, W), got {tuple(target.shape)}")
    target_cpu = target.detach().float().cpu().numpy()
    out = np.zeros_like(target_cpu, dtype=np.float32)
    batch, prompts = target_cpu.shape[:2]
    for b in range(batch):
        for p in range(prompts):
            mask = target_cpu[b, p] > 0.5
            if mask.any():
                out[b, p] = signed_distance_map(mask, normalize=normalize)
    return torch.as_tensor(out, dtype=target.dtype, device=target.device)


def boundary_loss_per_prompt_from_logits(
    logits: torch.Tensor,
    target: torch.Tensor,
    normalize_sdf: bool = False,
    band_radius: int = 0,
    eps: float = 1e-6,
) -> torch.Tensor:
    """Boundary loss ``mean(sigmoid(logits) * phi_G)`` per prompt.

    If ``band_radius > 0``, compute the mean only in the narrow band
    ``abs(phi_G) <= band_radius`` and clip/scale ``phi_G`` by the same radius.
    This avoids diluting small-lesion boundary gradients over the whole patch.
    """
    _check_shapes(logits, target)
    prob = torch.sigmoid(logits.float())
    if band_radius > 0:
        radius = float(band_radius)
        raw_sdf = signed_distance_maps_from_target(target, normalize=False).float()
        band = (raw_sdf.abs() <= radius).float()
        sdf = raw_sdf.clamp(min=-radius, max=radius) / radius
        return (prob * sdf * band).sum(dim=SPATIAL_DIMS) / band.sum(dim=SPATIAL_DIMS).clamp_min(eps)
    sdf = signed_distance_maps_from_target(target, normalize=normalize_sdf).float()
    return (prob * sdf).mean(dim=SPATIAL_DIMS)


def downsample_target_like(target: torch.Tensor, logits: torch.Tensor) -> torch.Tensor:
    if tuple(logits.shape[2:]) == tuple(target.shape[2:]):
        return target
    return F.interpolate(target, size=logits.shape[2:], mode="nearest")
