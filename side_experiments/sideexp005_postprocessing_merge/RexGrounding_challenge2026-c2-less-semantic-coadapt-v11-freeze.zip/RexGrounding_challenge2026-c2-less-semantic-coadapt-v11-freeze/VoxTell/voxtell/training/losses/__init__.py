"""Loss helpers for prompt-conditioned ReX fine-tuning."""

