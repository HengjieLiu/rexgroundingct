"""Frozen-S3 dual-head localization/extent prior for category-2d prompts."""

from __future__ import annotations

import math
import types
from typing import Any, List

import torch
import torch.nn.functional as F
from torch import nn

from .category_2d_dense_conversion import CATEGORY_2D_INDEX, _module_input


ARCHITECTURE_ID = "frozen_s3_category_2d_decoupled_loc_extent_v1"


def _separable_max_dilate(value: torch.Tensor, spacing_xyz: list[float], radius_mm: float = 8.0) -> torch.Tensor:
    spacing_zyx = list(map(float, spacing_xyz[::-1]))
    result = value
    for axis, spacing in enumerate(spacing_zyx):
        radius = max(1, int(math.ceil(radius_mm / spacing)))
        kernel = [1, 1, 1]
        kernel[axis] = 2 * radius + 1
        padding = [0, 0, 0]
        padding[axis] = radius
        result = F.max_pool3d(result, kernel_size=kernel, stride=1, padding=padding)
    return result


def _gaussian_kernel1d(sigma_voxels: float, device: torch.device) -> torch.Tensor:
    sigma = max(float(sigma_voxels), 0.35)
    radius = max(1, int(math.ceil(2.0 * sigma)))
    x = torch.arange(-radius, radius + 1, device=device, dtype=torch.float32)
    kernel = torch.exp(-0.5 * (x / sigma).square())
    return kernel / kernel.sum()


def _separable_gaussian(value: torch.Tensor, spacing_xyz: list[float], sigma_mm: float = 1.0) -> torch.Tensor:
    result = value.float()
    for axis, spacing in enumerate(map(float, spacing_xyz[::-1])):
        kernel = _gaussian_kernel1d(sigma_mm / spacing, result.device)
        shape = [1, 1, 1, 1, 1]
        shape[2 + axis] = kernel.numel()
        weight = kernel.reshape(shape)
        padding = [0, 0, 0]
        padding[axis] = kernel.numel() // 2
        result = F.conv3d(result, weight, padding=tuple(padding))
    return result


def predicted_support(q_loc: torch.Tensor, spacing_xyz: list[float]) -> tuple[torch.Tensor, bool]:
    expanded = _separable_max_dilate(q_loc.float(), spacing_xyz, radius_mm=8.0)
    expanded = _separable_gaussian(expanded, spacing_xyz, sigma_mm=1.0)
    maximum = expanded.flatten(1).amax(1).view(-1, 1, 1, 1, 1)
    support = (expanded / (maximum + 1e-6)).clamp_(0.0, 1.0)
    uniform = bool((support.flatten(1).std(dim=1, unbiased=False) < 1e-5).all())
    return support.detach(), uniform


class DecoupledPriorModule(nn.Module):
    """Shared feature trunk plus structurally gated localization/extent heads."""

    def __init__(self, half_input_channels: int, full_channels: int) -> None:
        super().__init__()
        self.half_trunk = nn.Sequential(
            nn.Conv3d(half_input_channels, 32, 1), nn.GroupNorm(4, 32), nn.GELU(),
            nn.Conv3d(32, 32, 3, padding=1, groups=32), nn.GELU(), nn.Conv3d(32, 16, 1),
        )
        full_input_channels = 16 + 4 * full_channels + 1
        self.full_trunk = nn.Sequential(
            nn.Conv3d(full_input_channels, 16, 1), nn.GroupNorm(4, 16), nn.GELU(),
            nn.Conv3d(16, 16, 3, padding=1, groups=16), nn.GELU(),
        )
        self.localization_head = nn.Sequential(
            nn.Conv3d(16, 16, 3, padding=1, groups=16), nn.GELU(), nn.Conv3d(16, 1, 1),
        )
        self.extent_head = nn.Sequential(
            nn.Conv3d(17, 16, 1), nn.GroupNorm(4, 16), nn.GELU(),
            nn.Conv3d(16, 16, 3, padding=1, groups=16), nn.GELU(), nn.Conv3d(16, 1, 1),
        )
        nn.init.zeros_(self.localization_head[-1].weight)
        nn.init.constant_(self.localization_head[-1].bias, math.log(0.01 / 0.99))
        nn.init.zeros_(self.extent_head[-1].weight)
        nn.init.zeros_(self.extent_head[-1].bias)

    def half_latent(self, half_input: torch.Tensor) -> torch.Tensor:
        return self.half_trunk(_module_input(half_input, self.half_trunk))

    def full_features(
        self, latent: torch.Tensor, previous: torch.Tensor, ungated: torch.Tensor,
        gated: torch.Tensor, attention: torch.Tensor,
    ) -> torch.Tensor:
        latent = F.interpolate(latent, size=previous.shape[2:], mode="trilinear", align_corners=False)
        value = torch.cat((latent, previous, ungated, gated, gated - ungated, attention), dim=1)
        return self.full_trunk(_module_input(value, self.full_trunk))

    def heads(
        self, features: torch.Tensor, spacing_xyz: list[float], oracle: torch.Tensor | None,
        alpha: float, support_override: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor | bool]:
        h_loc = self.localization_head(_module_input(features, self.localization_head))
        q_loc = h_loc.float().sigmoid()
        g_pred, uniform = predicted_support(q_loc, spacing_xyz)
        if support_override is not None:
            g_used = support_override.to(device=features.device, dtype=torch.float32)
            if g_used.shape != q_loc.shape:
                g_used = F.interpolate(g_used, size=q_loc.shape[2:], mode="trilinear", align_corners=False)
        elif oracle is not None and alpha > 0:
            g_oracle = oracle.to(device=features.device, dtype=torch.float32)
            if g_oracle.shape != q_loc.shape:
                g_oracle = F.interpolate(g_oracle, size=q_loc.shape[2:], mode="trilinear", align_corners=False)
            g_used = float(alpha) * g_oracle + (1.0 - float(alpha)) * g_pred
        else:
            g_used = g_pred
        g_used = g_used.clamp(0.0, 1.0)
        f_gated = features.float() * g_used
        extent_input = torch.cat((f_gated, g_used), dim=1)
        residual = self.extent_head(_module_input(extent_input, self.extent_head)).float()
        q_extent = g_used * residual.sigmoid()
        return {
            "h_loc": h_loc.float(), "q_loc": q_loc, "g_pred": g_pred,
            "g_used": g_used, "r_extent": residual, "q_extent": q_extent,
            "predicted_support_uniform": uniform,
        }


class Category2dDecoupledPrior(nn.Module):
    def __init__(self, model: nn.Module) -> None:
        super().__init__()
        self.half_stage_index = len(model.decoder.stages) - 2
        self.full_stage_index = len(model.decoder.stages) - 1
        self.module = DecoupledPriorModule(2 * int(model.encoder.output_channels[1]), int(model.encoder.output_channels[0]))
        self.execution_count = 0


def reset_decoupled_captures(model: nn.Module) -> None:
    for name in ("h_loc", "q_loc", "g_pred", "g_used", "r_extent", "q_extent"):
        setattr(model, f"last_category_2d_decoupled_{name}", [])
    model.last_category_2d_decoupled_uniform_support = []
    probe = getattr(model, "category_2d_decoupled_prior", None)
    if probe is not None:
        probe.execution_count = 0


def _forward_pre_hook(model: nn.Module, _args: tuple[Any, ...]) -> None:
    reset_decoupled_captures(model)


def _decode_prompt_with_decoupled_prior(
    self, skips: List[torch.Tensor], mask_embeddings: List[torch.Tensor], query: torch.Tensor,
    gate_scale: float | torch.Tensor = 1.0,
    gate_scales_by_scale: dict[str, float | torch.Tensor] | None = None,
    fullres_refinement_scale: float | torch.Tensor = 1.0,
    joint_fusion_scale: float | torch.Tensor = 0.0,
    adaptive_rho_category_indices: torch.Tensor | None = None,
    adaptive_rho_active_mask: torch.Tensor | None = None,
    category_router_indices: torch.Tensor | None = None,
    target_attention_adapter_active_mask: torch.Tensor | None = None,
) -> List[torch.Tensor]:
    del fullres_refinement_scale, joint_fusion_scale, adaptive_rho_category_indices
    del adaptive_rho_active_mask, target_attention_adapter_active_mask
    if any(getattr(self, name, None) is not None for name in (
        "adaptive_rho_adapter", "category_attention_router", "target_attention_adapter",
        "s3_fullres_attention_refinement", "s3_joint_fusion_head",
    )):
        raise RuntimeError("Decoupled prior requires the unmodified single-scale S3")
    batch = skips[0].shape[0]
    active = torch.zeros(batch, dtype=torch.bool, device=skips[0].device) if category_router_indices is None else category_router_indices.to(skips[0].device).long().reshape(batch, -1)[:, 0].eq(CATEGORY_2D_INDEX)
    if bool(active.any()) and not bool(active.all()):
        raise RuntimeError("Mixed category-2d/non-2d batches are unsupported")
    decoder, probe = self.decoder, self.category_2d_decoupled_prior
    lres_input, half_latent = skips[-1], None
    seg_outputs: list[torch.Tensor] = []
    reversed_embeddings = mask_embeddings[::-1]
    for stage_idx in range(len(decoder.stages)):
        coarse = decoder.transpconvs[stage_idx](lres_input)
        ungated = skips[-(stage_idx + 2)]
        skip, attention = ungated, None
        scale = self.s3_attention_decoder_stage_to_scale.get(stage_idx)
        stage_scale = gate_scale if gate_scales_by_scale is None else gate_scales_by_scale.get(scale, gate_scale)
        if scale is not None:
            gate = self.s3_attention_gate if scale == "1/2" else self.s3_extra_attention_gates[self._s2_scale_key(scale)]
            gated, attention = gate(skip, coarse, query, gate_scale=stage_scale)
            skip = gated[:, 0]
            self.last_s3_attention_maps[scale].append(attention)
            logits = getattr(gate, "last_attention_logits", None)
            if logits is not None:
                self.last_s3_attention_logits.setdefault(scale, []).append(logits)
        stage_input = torch.cat((coarse, skip), dim=1)
        if bool(active.all()) and stage_idx == probe.half_stage_index:
            half_latent = probe.module.half_latent(stage_input)
        if bool(active.all()) and stage_idx == probe.full_stage_index:
            if half_latent is None or attention is None or scale != "1/1":
                raise RuntimeError("Missing audited half/full features")
            context = getattr(self, "category_2d_decoupled_context", {}) or {}
            features = probe.module.full_features(half_latent, coarse, ungated, skip, attention[:, 0])
            result = probe.module.heads(
                features, list(context.get("spacing_xyz", (1.0, 1.0, 1.0))),
                context.get("oracle"), float(context.get("alpha", 0.0)), context.get("support_override"),
            )
            for name in ("h_loc", "q_loc", "g_pred", "g_used", "r_extent", "q_extent"):
                getattr(self, f"last_category_2d_decoupled_{name}").append(result[name])
            self.last_category_2d_decoupled_uniform_support.append(bool(result["predicted_support_uniform"]))
            probe.execution_count += 1
        x = decoder.stages[stage_idx](stage_input)
        if stage_idx == len(decoder.stages) - 1:
            seg_outputs.append(torch.einsum("b c h w d, b n c -> b n h w d", x, reversed_embeddings[-1]))
        elif stage_idx >= len(decoder.stages) - len(reversed_embeddings):
            embedding = reversed_embeddings.pop(0)
            reshaped = embedding.view(embedding.shape[0], decoder.num_heads, -1)
            fusion = torch.einsum("b c h w d, b n c -> b n h w d", x, reshaped)
            x = torch.cat((x, fusion), dim=1)
            seg_outputs.append(decoder.seg_layers[stage_idx](x))
        if scale is not None and self._s2_scale_key(scale) in self.s3_decoder_feature_gates:
            x = self.s3_decoder_feature_gates[self._s2_scale_key(scale)](x, attention, gate_scale=stage_scale)
        lres_input = x
    seg_outputs = seg_outputs[::-1]
    return seg_outputs if decoder.deep_supervision else seg_outputs[:1]


def attach_category_2d_decoupled_prior(model: nn.Module) -> nn.Module:
    if getattr(model, "category_2d_decoupled_prior", None) is None:
        model.category_2d_decoupled_prior = Category2dDecoupledPrior(model)
    object.__setattr__(model, "_decode_prompt_with_s3", types.MethodType(_decode_prompt_with_decoupled_prior, model))
    if getattr(model, "_category_2d_decoupled_hook", None) is None:
        object.__setattr__(model, "_category_2d_decoupled_hook", model.register_forward_pre_hook(_forward_pre_hook))
    reset_decoupled_captures(model)
    return model
