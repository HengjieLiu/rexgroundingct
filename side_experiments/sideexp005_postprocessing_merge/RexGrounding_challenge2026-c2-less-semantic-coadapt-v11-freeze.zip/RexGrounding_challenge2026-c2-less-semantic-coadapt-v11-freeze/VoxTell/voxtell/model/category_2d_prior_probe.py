"""Prior-head-only probe on frozen single-scale S3 decoder features.

This attachment is deliberately observational: it reproduces the ordinary S3
decoder exactly and exposes a fresh :class:`DensePriorHead2d` prediction for
category-2d prompts.  No feature adapter, copied decoder, or logit residual is
instantiated.
"""

from __future__ import annotations

import types
from typing import Any, List

import torch
from torch import nn

from .category_2d_dense_conversion import CATEGORY_2D_INDEX, DensePriorHead2d


ARCHITECTURE_ID = "frozen_s3_category_2d_prior_probe_v1"


class Category2dPriorProbe(nn.Module):
    """The exact prior head used by dense-joint, with no conversion modules."""

    def __init__(self, model: nn.Module) -> None:
        super().__init__()
        if len(model.decoder.stages) < 2:
            raise ValueError("Prior probe requires the final two decoder stages")
        self.half_stage_index = len(model.decoder.stages) - 2
        self.full_stage_index = len(model.decoder.stages) - 1
        full_channels = int(model.encoder.output_channels[0])
        half_channels = int(model.encoder.output_channels[1])
        self.dense_prior_head = DensePriorHead2d(2 * half_channels, full_channels)
        self.execution_count = 0


def reset_category_2d_prior_captures(model: nn.Module) -> None:
    model.last_category_2d_prior_logits = []
    model.last_category_2d_prior_probabilities = []
    model.last_category_2d_prior_prompt_indices = []
    probe = getattr(model, "category_2d_prior_probe", None)
    if probe is not None:
        probe.execution_count = 0


def _forward_pre_hook(model: nn.Module, _args: tuple[Any, ...]) -> None:
    reset_category_2d_prior_captures(model)
    model._category_2d_prior_prompt_cursor = 0


def _decode_prompt_with_prior_probe(
    self,
    skips: List[torch.Tensor],
    mask_embeddings: List[torch.Tensor],
    query: torch.Tensor,
    gate_scale: float | torch.Tensor = 1.0,
    gate_scales_by_scale: dict[str, float | torch.Tensor] | None = None,
    fullres_refinement_scale: float | torch.Tensor = 1.0,
    joint_fusion_scale: float | torch.Tensor = 0.0,
    adaptive_rho_category_indices: torch.Tensor | None = None,
    adaptive_rho_active_mask: torch.Tensor | None = None,
    category_router_indices: torch.Tensor | None = None,
    target_attention_adapter_active_mask: torch.Tensor | None = None,
) -> List[torch.Tensor]:
    del adaptive_rho_category_indices, adaptive_rho_active_mask
    del target_attention_adapter_active_mask
    if any(
        value is not None
        for value in (
            getattr(self, "adaptive_rho_adapter", None),
            getattr(self, "category_attention_router", None),
            getattr(self, "target_attention_adapter", None),
            getattr(self, "s3_fullres_attention_refinement", None),
            getattr(self, "s3_joint_fusion_head", None),
        )
    ):
        raise RuntimeError("Prior learnability probe requires unmodified single-scale S3")
    del fullres_refinement_scale, joint_fusion_scale

    batch = skips[0].shape[0]
    if category_router_indices is None:
        active = torch.zeros(batch, dtype=torch.bool, device=skips[0].device)
    else:
        active = (
            category_router_indices.to(skips[0].device)
            .long()
            .reshape(batch, -1)[:, 0]
            .eq(CATEGORY_2D_INDEX)
        )
    if bool(active.any()) and not bool(active.all()):
        raise RuntimeError("Mixed category-2d/non-2d batches are unsupported")

    prompt_index = int(getattr(self, "_category_2d_prior_prompt_cursor", 0))
    self._category_2d_prior_prompt_cursor = prompt_index + 1
    decoder = self.decoder
    probe = self.category_2d_prior_probe
    lres_input = skips[-1]
    seg_outputs: list[torch.Tensor] = []
    reversed_embeddings = mask_embeddings[::-1]
    half_latent = None

    for stage_idx in range(len(decoder.stages)):
        coarse_context = decoder.transpconvs[stage_idx](lres_input)
        ungated_skip = skips[-(stage_idx + 2)]
        skip = ungated_skip
        scale = self.s3_attention_decoder_stage_to_scale.get(stage_idx)
        attention = None
        stage_gate_scale = gate_scale
        if scale is not None:
            stage_gate_scale = (
                gate_scale
                if gate_scales_by_scale is None
                else gate_scales_by_scale.get(scale, gate_scale)
            )
            gate = (
                self.s3_attention_gate
                if scale == "1/2"
                else self.s3_extra_attention_gates[self._s2_scale_key(scale)]
            )
            gated, attention = gate(
                skip, coarse_context, query, gate_scale=stage_gate_scale
            )
            skip = gated[:, 0]
            self.last_s3_attention_maps[scale].append(attention)
            attention_logits = getattr(gate, "last_attention_logits", None)
            if attention_logits is not None:
                self.last_s3_attention_logits.setdefault(scale, []).append(
                    attention_logits
                )

        stage_input = torch.cat((coarse_context, skip), dim=1)
        if bool(active.all()) and stage_idx == probe.half_stage_index:
            probe.execution_count += 1
            half_latent = probe.dense_prior_head.half_latent(stage_input)
        if bool(active.all()) and stage_idx == probe.full_stage_index:
            if half_latent is None or attention is None or scale != "1/1":
                raise RuntimeError("Prior probe did not receive audited half/full S3 features")
            q_logits = probe.dense_prior_head.full_logits(
                half_latent, coarse_context, ungated_skip, skip, attention[:, 0]
            )
            self.last_category_2d_prior_logits.append(q_logits)
            self.last_category_2d_prior_probabilities.append(q_logits.sigmoid())
            self.last_category_2d_prior_prompt_indices.append(prompt_index)

        x = decoder.stages[stage_idx](stage_input)
        if stage_idx == len(decoder.stages) - 1:
            seg_outputs.append(
                torch.einsum(
                    "b c h w d, b n c -> b n h w d", x, reversed_embeddings[-1]
                )
            )
        elif stage_idx >= len(decoder.stages) - len(reversed_embeddings):
            embedding = reversed_embeddings.pop(0)
            batch_size, _, channels = embedding.shape
            reshaped = embedding.view(batch_size, decoder.num_heads, -1)
            fusion = torch.einsum(
                "b c h w d, b n c -> b n h w d", x, reshaped
            )
            x = torch.cat((x, fusion), dim=1)
            seg_outputs.append(decoder.seg_layers[stage_idx](x))
        if scale is not None and self._s2_scale_key(scale) in self.s3_decoder_feature_gates:
            decoder_gate = self.s3_decoder_feature_gates[self._s2_scale_key(scale)]
            x = decoder_gate(x, attention, gate_scale=stage_gate_scale)
        lres_input = x

    seg_outputs = seg_outputs[::-1]
    return seg_outputs if decoder.deep_supervision else seg_outputs[:1]


def attach_category_2d_prior_probe(model: nn.Module) -> nn.Module:
    if getattr(model, "category_2d_prior_probe", None) is None:
        model.category_2d_prior_probe = Category2dPriorProbe(model)
    object.__setattr__(
        model,
        "_decode_prompt_with_s3",
        types.MethodType(_decode_prompt_with_prior_probe, model),
    )
    model._category_2d_prior_prompt_cursor = 0
    if getattr(model, "_category_2d_prior_probe_hook", None) is None:
        object.__setattr__(
            model,
            "_category_2d_prior_probe_hook",
            model.register_forward_pre_hook(_forward_pre_hook),
        )
    reset_category_2d_prior_captures(model)
    return model
