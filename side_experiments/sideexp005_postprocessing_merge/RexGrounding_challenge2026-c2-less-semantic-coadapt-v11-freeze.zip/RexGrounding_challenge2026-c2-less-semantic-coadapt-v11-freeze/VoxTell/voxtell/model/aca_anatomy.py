"""ACA-style anatomy/text representation supervision for VoxTell.

The module in this file is deliberately independent of the existing prompt-location
containment loss.  It consumes a pure visual feature map, five transformed lobe
masks, and frozen finding embeddings.  It never changes the base network unless a
caller explicitly applies :class:`ACAContextProjection` to the normal VoxTell query.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Iterable, Sequence

import torch
from torch import nn
import torch.nn.functional as F


ANATOMY_NAMES = ("RUL", "RML", "RLL", "LUL", "LLL", "GLOBAL")
LOBE_NAMES = ANATOMY_NAMES[:5]
LOBE_LABEL_VALUES = (3, 4, 5, 1, 2)
LEFT_RIGHT_SWAP = (3, 1, 4, 0, 2, 5)
DEFAULT_LOBE_PERMUTATION = (1, 4, 0, 2, 3, 5)


def stable_id_hash(value: object) -> int:
    """Return a deterministic non-negative int64 identifier."""

    digest = hashlib.blake2b(str(value).encode("utf-8"), digest_size=8).digest()
    return int.from_bytes(digest, "little") & ((1 << 63) - 1)


def labels_to_lobe_masks(labels: torch.Tensor) -> torch.Tensor:
    """Convert uint8-like lobe labels to masks in RUL,RML,RLL,LUL,LLL order."""

    if labels.ndim == 5 and labels.shape[1] == 1:
        labels = labels[:, 0]
    if labels.ndim != 4:
        raise ValueError(f"Expected lobe labels [B,D,H,W], got {tuple(labels.shape)}")
    rounded = labels.round().long()
    if rounded.numel() and (rounded.min() < 0 or rounded.max() > 5):
        raise ValueError("Lobe labels must be in [0, 5]")
    return torch.stack([rounded == value for value in LOBE_LABEL_VALUES], dim=1)


class ProjectionHead(nn.Module):
    """Linear -> GELU -> LayerNorm -> Linear -> unit normalization."""

    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int = 256) -> None:
        super().__init__()
        self.layers = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return F.normalize(self.layers(value), dim=-1, eps=1e-6)


class LearnableTemperature(nn.Module):
    """Direct learnable temperature with an explicit safe range."""

    def __init__(
        self,
        initial: float = 0.07,
        minimum: float = 0.001,
        maximum: float = 0.5,
    ) -> None:
        super().__init__()
        if not minimum <= initial <= maximum:
            raise ValueError("Initial temperature must lie inside its clamp interval")
        self.value = nn.Parameter(torch.tensor(float(initial)))
        self.minimum = float(minimum)
        self.maximum = float(maximum)

    def forward(self) -> torch.Tensor:
        return self.value.clamp(self.minimum, self.maximum)


def lobe_centroid_spatial_features(
    lobe_masks: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return five normalized inter-lobe distances plus five presence flags.

    Coordinates are measured in the transformed patch coordinate system and
    distances are normalized by that patch's voxel-space diagonal.
    """

    if lobe_masks.ndim != 5 or lobe_masks.shape[1] != 5:
        raise ValueError(f"Expected lobe masks [B,5,D,H,W], got {tuple(lobe_masks.shape)}")
    masks = lobe_masks.float()
    batch, _, depth, height, width = masks.shape
    flat = masks.flatten(2)
    mass = flat.sum(-1)
    present = mass > 0
    z = torch.arange(depth, device=masks.device, dtype=masks.dtype)
    y = torch.arange(height, device=masks.device, dtype=masks.dtype)
    x = torch.arange(width, device=masks.device, dtype=masks.dtype)
    grid = torch.stack(torch.meshgrid(z, y, x, indexing="ij"), dim=-1).reshape(-1, 3)
    centroids = torch.einsum("bkn,nc->bkc", flat, grid)
    centroids = centroids / mass.clamp_min(1.0).unsqueeze(-1)
    distances = torch.linalg.vector_norm(
        centroids[:, :, None, :] - centroids[:, None, :, :], dim=-1
    )
    diagonal = float(max(((depth - 1) ** 2 + (height - 1) ** 2 + (width - 1) ** 2) ** 0.5, 1.0))
    distances = distances / diagonal
    pair_present = present[:, :, None] & present[:, None, :]
    distances = distances * pair_present.to(distances.dtype)
    destination_presence = present[:, None, :].expand(batch, 5, 5).to(distances.dtype)
    spatial = torch.cat((distances, destination_presence), dim=-1)
    spatial = spatial * present.unsqueeze(-1).to(spatial.dtype)
    return spatial, present


class ACAAnatomyEncoder(nn.Module):
    """Pool, contextualize, and project five lobe tokens plus a GLOBAL token."""

    def __init__(
        self,
        visual_dim: int = 320,
        text_dim: int = 2560,
        hidden_dim: int = 256,
        projection_dim: int = 256,
        transformer_layers: int = 2,
        attention_heads: int = 4,
        dropout: float = 0.1,
        tau_initial: float = 0.07,
        tau_route_initial: float = 0.07,
    ) -> None:
        super().__init__()
        if hidden_dim % attention_heads:
            raise ValueError("hidden_dim must be divisible by attention_heads")
        self.visual_dim = int(visual_dim)
        self.text_dim = int(text_dim)
        self.hidden_dim = int(hidden_dim)
        self.projection_dim = int(projection_dim)
        self.visual_projection = nn.Linear(visual_dim, hidden_dim)
        self.anatomy_type_embedding = nn.Embedding(len(ANATOMY_NAMES), hidden_dim)
        self.spatial_mlp = nn.Sequential(
            nn.Linear(10, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.global_spatial_embedding = nn.Parameter(torch.empty(hidden_dim))
        nn.init.normal_(self.global_spatial_embedding, std=0.02)
        layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=attention_heads,
            dim_feedforward=hidden_dim * 4,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.anatomy_transformer = nn.TransformerEncoder(
            layer,
            num_layers=transformer_layers,
            norm=nn.LayerNorm(hidden_dim),
        )
        self.image_projection_head = ProjectionHead(
            hidden_dim, hidden_dim, projection_dim
        )
        self.text_projection_head = ProjectionHead(
            text_dim, hidden_dim, projection_dim
        )
        self.temperature = LearnableTemperature(tau_initial)
        self.route_temperature = LearnableTemperature(tau_route_initial)

    @staticmethod
    def _pool_visual_tokens(
        feature: torch.Tensor,
        lobe_masks: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if feature.ndim != 5:
            raise ValueError(f"Expected feature [B,C,Df,Hf,Wf], got {tuple(feature.shape)}")
        if lobe_masks.ndim != 5 or lobe_masks.shape[:2] != (feature.shape[0], 5):
            raise ValueError(
                f"Expected masks [B,5,D,H,W] matching batch, got {tuple(lobe_masks.shape)}"
            )
        feature_shape = tuple(map(int, feature.shape[-3:]))
        pooled_masks = F.adaptive_max_pool3d(
            lobe_masks.float(), output_size=feature_shape
        )
        if tuple(pooled_masks.shape[-3:]) != feature_shape:
            raise AssertionError("Adaptive anatomy pooling returned the wrong feature grid")
        selected = pooled_masks > 0
        feature_flat = feature.flatten(2)
        selected_flat = selected.flatten(2).to(feature.dtype)
        counts = selected_flat.sum(-1)
        pooled = torch.einsum("bcn,bkn->bkc", feature_flat, selected_flat)
        pooled = pooled / counts.clamp_min(1.0).unsqueeze(-1)
        pooled = F.normalize(pooled, dim=-1, eps=1e-6)
        pooled = pooled * (counts > 0).unsqueeze(-1).to(pooled.dtype)
        global_token = F.normalize(feature_flat.mean(-1), dim=-1, eps=1e-6)
        visual = torch.cat((pooled, global_token[:, None]), dim=1)
        present = torch.cat(
            (
                counts > 0,
                torch.ones(feature.shape[0], 1, device=feature.device, dtype=torch.bool),
            ),
            dim=1,
        )
        return visual, present, pooled_masks

    def forward(
        self,
        feature: torch.Tensor,
        lobe_masks: torch.Tensor,
        text_embeddings: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        if text_embeddings.ndim == 4 and text_embeddings.shape[2] == 1:
            text_embeddings = text_embeddings.squeeze(2)
        if text_embeddings.ndim != 3 or text_embeddings.shape[0] != feature.shape[0]:
            raise ValueError(
                "Text embeddings must be [B,P,E] (or [B,P,1,E]) and match feature batch"
            )
        if text_embeddings.shape[-1] != self.text_dim:
            raise ValueError(
                f"Expected text dimension {self.text_dim}, got {text_embeddings.shape[-1]}"
            )
        visual, present, pooled_masks = self._pool_visual_tokens(feature, lobe_masks)
        spatial, centroid_present = lobe_centroid_spatial_features(lobe_masks)
        if not torch.equal(centroid_present, present[:, :5]):
            raise AssertionError("Full-resolution and feature-grid anatomy presence disagree")
        type_ids = torch.arange(6, device=feature.device)
        type_component = self.anatomy_type_embedding(type_ids)[None].expand(
            feature.shape[0], -1, -1
        )
        spatial_component = self.spatial_mlp(spatial)
        spatial_component = torch.cat(
            (
                spatial_component,
                self.global_spatial_embedding[None, None].expand(
                    feature.shape[0], 1, -1
                ),
            ),
            dim=1,
        )
        tokens = (
            self.visual_projection(visual)
            + type_component
            + spatial_component.to(type_component.dtype)
        )
        tokens = self.anatomy_transformer(
            tokens, src_key_padding_mask=~present
        )
        tokens = tokens * present.unsqueeze(-1).to(tokens.dtype)
        image_embeddings = self.image_projection_head(tokens)
        image_embeddings = image_embeddings * present.unsqueeze(-1).to(
            image_embeddings.dtype
        )
        text_projected = self.text_projection_head(text_embeddings)
        route_logits = torch.einsum(
            "bpc,bac->bpa", text_projected, image_embeddings
        ) / self.route_temperature()
        route_logits = route_logits.masked_fill(~present[:, None], -torch.inf)
        route_probabilities = torch.softmax(route_logits, dim=-1)
        context = torch.einsum("bpa,bah->bph", route_probabilities, tokens)
        return {
            "tokens": tokens,
            "image_embeddings": image_embeddings,
            "text_embeddings": text_projected,
            "present": present,
            "pooled_masks": pooled_masks,
            "route_logits": route_logits,
            "route_probabilities": route_probabilities,
            "context": context,
            "temperature": self.temperature(),
            "route_temperature": self.route_temperature(),
        }


class PerAnatomyQueue(nn.Module):
    """Checkpointable per-anatomy FIFO memory bank with detached entries."""

    def __init__(
        self,
        queue_length: int = 128,
        embedding_dim: int = 256,
        anatomy_count: int = 6,
    ) -> None:
        super().__init__()
        if queue_length < 1:
            raise ValueError("queue_length must be positive")
        self.queue_length = int(queue_length)
        self.embedding_dim = int(embedding_dim)
        self.anatomy_count = int(anatomy_count)
        self.register_buffer(
            "image_queue",
            torch.zeros(anatomy_count, queue_length, embedding_dim),
        )
        self.register_buffer(
            "text_queue",
            torch.zeros(anatomy_count, queue_length, embedding_dim),
        )
        self.register_buffer(
            "patient_queue",
            torch.full((anatomy_count, queue_length), -1, dtype=torch.long),
        )
        self.register_buffer(
            "finding_queue",
            torch.full((anatomy_count, queue_length), -1, dtype=torch.long),
        )
        self.register_buffer("write_pointer", torch.zeros(anatomy_count, dtype=torch.long))
        self.register_buffer("occupancy", torch.zeros(anatomy_count, dtype=torch.long))

    @torch.no_grad()
    def reset(self) -> None:
        self.image_queue.zero_()
        self.text_queue.zero_()
        self.patient_queue.fill_(-1)
        self.finding_queue.fill_(-1)
        self.write_pointer.zero_()
        self.occupancy.zero_()

    @torch.no_grad()
    def enqueue(
        self,
        anatomy_index: int,
        image_embeddings: torch.Tensor,
        text_embeddings: torch.Tensor,
        patient_ids: torch.Tensor,
        finding_ids: torch.Tensor,
    ) -> None:
        anatomy_index = int(anatomy_index)
        count = int(image_embeddings.shape[0])
        if not (
            text_embeddings.shape[0] == patient_ids.shape[0] == finding_ids.shape[0] == count
        ):
            raise ValueError("Queue insertion tensors must have the same leading dimension")
        for index in range(count):
            pointer = int(self.write_pointer[anatomy_index].item())
            self.image_queue[anatomy_index, pointer].copy_(
                image_embeddings[index].detach().to(self.image_queue)
            )
            self.text_queue[anatomy_index, pointer].copy_(
                text_embeddings[index].detach().to(self.text_queue)
            )
            self.patient_queue[anatomy_index, pointer] = patient_ids[index].detach()
            self.finding_queue[anatomy_index, pointer] = finding_ids[index].detach()
            self.write_pointer[anatomy_index] = (pointer + 1) % self.queue_length
            self.occupancy[anatomy_index] = min(
                int(self.occupancy[anatomy_index].item()) + 1,
                self.queue_length,
            )

    def entries(
        self, anatomy_index: int
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        count = int(self.occupancy[int(anatomy_index)].item())
        return (
            self.image_queue[int(anatomy_index), :count],
            self.text_queue[int(anatomy_index), :count],
            self.patient_queue[int(anatomy_index), :count],
            self.finding_queue[int(anatomy_index), :count],
        )


@dataclass
class ACALossResult:
    loss: torch.Tensor
    active_anatomies: int
    active_pairs: int
    anatomy_losses: dict[str, float]
    queue_occupancy: dict[str, int]


def _weighted_soft_cross_entropy(
    logits: torch.Tensor,
    targets: torch.Tensor,
    weights: torch.Tensor,
) -> torch.Tensor:
    row_loss = -(targets * F.log_softmax(logits, dim=-1)).sum(-1)
    return (row_loss * weights).sum() / weights.sum().clamp_min(1e-8)


def soft_target_cross_entropy_rows(
    logits: torch.Tensor,
    targets: torch.Tensor,
) -> torch.Tensor:
    """Soft-target CE that is safe when masked classes have ``-inf`` logits."""

    log_probabilities = F.log_softmax(logits, dim=-1)
    safe_log_probabilities = log_probabilities.masked_fill(targets == 0, 0.0)
    return -(targets * safe_log_probabilities).sum(-1)


def same_patient_soft_targets(
    current_patient: torch.Tensor,
    candidate_patient: torch.Tensor,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    """ACA target rows: paired item plus every other same-patient item."""

    targets = (current_patient[:, None] == candidate_patient[None, :]).to(dtype)
    return targets / targets.sum(-1, keepdim=True).clamp_min(1.0)


def aca_contrastive_loss(
    image_embeddings: torch.Tensor,
    text_embeddings: torch.Tensor,
    overlap_mass: torch.Tensor,
    nonempty: torch.Tensor,
    patient_ids: Sequence[Sequence[object]],
    finding_ids: Sequence[Sequence[object]],
    queue: PerAnatomyQueue,
    temperature: torch.Tensor,
    min_overlap_threshold: float = 0.05,
    update_queue: bool = True,
) -> ACALossResult:
    """Symmetric per-anatomy ACA loss with same-patient soft positives."""

    batch, prompts, anatomy_count = overlap_mass.shape
    if anatomy_count != len(ANATOMY_NAMES):
        raise ValueError("overlap_mass must contain six anatomy entries")
    if tuple(nonempty.shape) != (batch, prompts):
        raise ValueError("nonempty must match [B,P]")
    flat_patient = torch.tensor(
        [stable_id_hash(patient_ids[b][p]) for b in range(batch) for p in range(prompts)],
        device=image_embeddings.device,
        dtype=torch.long,
    )
    flat_finding = torch.tensor(
        [stable_id_hash(finding_ids[b][p]) for b in range(batch) for p in range(prompts)],
        device=image_embeddings.device,
        dtype=torch.long,
    )
    losses: list[torch.Tensor] = []
    anatomy_losses: dict[str, float] = {}
    active_pairs = 0
    for anatomy_index, anatomy_name in enumerate(ANATOMY_NAMES):
        active = (
            nonempty
            & (overlap_mass[:, :, anatomy_index] >= float(min_overlap_threshold))
        ).reshape(-1)
        indices = torch.nonzero(active, as_tuple=False).flatten()
        queue_image, queue_text, queue_patient, _ = queue.entries(anatomy_index)
        scan_image = image_embeddings[:, anatomy_index][:, None].expand(
            batch, prompts, -1
        ).reshape(batch * prompts, -1)
        current_image = scan_image[indices]
        current_text = text_embeddings.reshape(batch * prompts, -1)[indices]
        current_patient = flat_patient[indices]
        current_finding = flat_finding[indices]
        if indices.numel() < 2 and queue_image.shape[0] == 0:
            # The first singleton cannot define a contrastive denominator, but it
            # must seed the FIFO so the next singleton becomes usable.
            if update_queue and indices.numel():
                queue.enqueue(
                    anatomy_index,
                    current_image,
                    current_text,
                    current_patient,
                    current_finding,
                )
            continue
        candidate_text = torch.cat((current_text, queue_text.to(current_text)), dim=0)
        candidate_image = torch.cat((current_image, queue_image.to(current_image)), dim=0)
        candidate_patient = torch.cat(
            (current_patient, queue_patient.to(current_patient)), dim=0
        )
        targets = same_patient_soft_targets(
            current_patient, candidate_patient, current_image.dtype
        )
        weights = overlap_mass[:, :, anatomy_index].reshape(-1)[indices].to(
            current_image.dtype
        )
        image_to_text = current_image @ candidate_text.T / temperature
        text_to_image = current_text @ candidate_image.T / temperature
        anatomy_loss = 0.5 * (
            _weighted_soft_cross_entropy(image_to_text, targets, weights)
            + _weighted_soft_cross_entropy(text_to_image, targets, weights)
        )
        losses.append(anatomy_loss)
        anatomy_losses[anatomy_name] = float(anatomy_loss.detach().item())
        active_pairs += int(indices.numel())
        if update_queue and indices.numel():
            queue.enqueue(
                anatomy_index,
                current_image,
                current_text,
                current_patient,
                current_finding,
            )
    zero = image_embeddings.sum() * 0.0
    total = torch.stack(losses).mean() if losses else zero
    return ACALossResult(
        loss=total,
        active_anatomies=len(losses),
        active_pairs=active_pairs,
        anatomy_losses=anatomy_losses,
        queue_occupancy={
            name: int(queue.occupancy[index].item())
            for index, name in enumerate(ANATOMY_NAMES)
        },
    )


@dataclass
class RoutingLossResult:
    loss: torch.Tensor
    targets: torch.Tensor
    nonempty: torch.Tensor
    overlap_mass: torch.Tensor
    metrics: dict[str, float]


def routing_targets(
    target: torch.Tensor,
    lobe_masks: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if target.ndim != 5 or lobe_masks.ndim != 5:
        raise ValueError("target and lobe_masks must be [B,P,D,H,W] and [B,5,D,H,W]")
    target_float = target.float()
    lobes = lobe_masks.float()
    lobe_mass = torch.einsum("bpdwh,bkdwh->bpk", target_float, lobes)
    union = lobes.amax(dim=1)
    uncovered = torch.einsum("bpdwh,bdwh->bp", target_float, 1.0 - union)
    raw = torch.cat((lobe_mass, uncovered.unsqueeze(-1)), dim=-1)
    gt_mass = target_float.flatten(2).sum(-1)
    nonempty = gt_mass > 0
    targets = raw / raw.sum(-1, keepdim=True).clamp_min(1.0)
    overlap = lobe_mass / gt_mass.clamp_min(1.0).unsqueeze(-1)
    global_overlap = torch.ones_like(gt_mass)
    overlap = torch.cat((overlap, global_overlap.unsqueeze(-1)), dim=-1)
    overlap = overlap * nonempty.unsqueeze(-1).to(overlap.dtype)
    return targets, nonempty, overlap


def within_scan_routing_loss(
    route_logits: torch.Tensor,
    target: torch.Tensor,
    lobe_masks: torch.Tensor,
) -> RoutingLossResult:
    targets, nonempty, overlap = routing_targets(target, lobe_masks)
    if nonempty.any():
        selected_logits = route_logits[nonempty]
        selected_targets = targets[nonempty]
        row_loss = soft_target_cross_entropy_rows(
            selected_logits, selected_targets
        )
        loss = row_loss.mean()
        predictions = selected_logits.argmax(-1)
        dominant = selected_targets.argmax(-1)
        top1 = (predictions == dominant).float().mean()
        top2 = (
            selected_logits.topk(k=2, dim=-1).indices
            == dominant.unsqueeze(-1)
        ).any(-1).float().mean()
        probabilities = torch.softmax(selected_logits, dim=-1)
        overlap_probability = (
            probabilities * (selected_targets > 0).to(probabilities.dtype)
        ).sum(-1).mean()
        swapped_logits = selected_logits[:, list(LEFT_RIGHT_SWAP)]
        swapped_logits = torch.nan_to_num(
            swapped_logits, neginf=-1e4, posinf=1e4
        )
        swapped_loss = soft_target_cross_entropy_rows(
            swapped_logits, selected_targets
        ).mean()
        true_side = torch.stack(
            (
                selected_targets[:, 3:5].sum(-1),
                selected_targets[:, 0:3].sum(-1),
            ),
            dim=-1,
        )
        pred_side = torch.stack(
            (
                probabilities[:, 3:5].sum(-1),
                probabilities[:, 0:3].sum(-1),
            ),
            dim=-1,
        )
        side_eligible = true_side.sum(-1) > 0
        laterality = (
            (pred_side.argmax(-1) == true_side.argmax(-1))[side_eligible]
            .float()
            .mean()
            if side_eligible.any()
            else torch.zeros((), device=route_logits.device)
        )
        metrics = {
            "dominant_anatomy_accuracy": float(top1.detach().item()),
            "top2_accuracy": float(top2.detach().item()),
            "gt_overlap_probability_mass": float(overlap_probability.detach().item()),
            "laterality_accuracy": float(laterality.detach().item()),
            "correct_route_loss": float(loss.detach().item()),
            "left_right_swapped_route_loss": float(swapped_loss.detach().item()),
            "correct_minus_swapped_margin": float(
                (swapped_loss - loss).detach().item()
            ),
            "active_route_pairs": int(nonempty.sum().item()),
        }
    else:
        loss = route_logits.sum() * 0.0
        metrics = {
            "dominant_anatomy_accuracy": 0.0,
            "top2_accuracy": 0.0,
            "gt_overlap_probability_mass": 0.0,
            "laterality_accuracy": 0.0,
            "correct_route_loss": 0.0,
            "left_right_swapped_route_loss": 0.0,
            "correct_minus_swapped_margin": 0.0,
            "active_route_pairs": 0,
        }
    return RoutingLossResult(loss, targets, nonempty, overlap, metrics)


class ACAContextProjection(nn.Module):
    """Zero-initialized anatomy-context projection into VoxTell query space."""

    def __init__(self, hidden_dim: int = 256, query_dim: int = 2048) -> None:
        super().__init__()
        self.projection = nn.Linear(hidden_dim, query_dim)
        nn.init.zeros_(self.projection.weight)
        nn.init.zeros_(self.projection.bias)

    def forward(
        self,
        original_query: torch.Tensor,
        context: torch.Tensor,
        enabled: bool = True,
    ) -> torch.Tensor:
        if not enabled:
            return original_query
        if original_query.ndim != 3 or context.ndim != 3:
            raise ValueError("Queries must be [P,B,Q] and context must be [B,P,H]")
        residual = self.projection(context).permute(1, 0, 2)
        if residual.shape != original_query.shape:
            raise ValueError(
                f"Context residual {tuple(residual.shape)} != query {tuple(original_query.shape)}"
            )
        return original_query + residual.to(original_query.dtype)


def permute_lobe_masks(
    lobe_masks: torch.Tensor,
    condition: str,
) -> torch.Tensor:
    """Apply a documented causal anatomy-input corruption."""

    if condition in {"correct", "zero"}:
        return lobe_masks
    if condition == "left_right_swap":
        return lobe_masks[:, [3, 1, 4, 0, 2]]
    if condition == "lobe_permuted":
        return lobe_masks[:, list(DEFAULT_LOBE_PERMUTATION[:5])]
    raise ValueError(f"Unknown anatomy condition: {condition}")


class ACAVoxTellBridge(nn.Module):
    """Inject ACA context without changing the existing VoxTell source module.

    A pre-hook captures the exact pure visual tensor entering
    ``project_bottleneck_embed``.  A second pre-hook adds the zero-initialized
    context projection to the normal projected finding query immediately before
    VoxTell's prompt transformer.  Hooks are used so baseline checkpoint key names
    and all pre-existing experiment code remain untouched.
    """

    def __init__(
        self,
        voxtell: nn.Module,
        anatomy_encoder: ACAAnatomyEncoder,
        context_projection: ACAContextProjection,
    ) -> None:
        super().__init__()
        self.voxtell = voxtell
        self.anatomy_encoder = anatomy_encoder
        self.context_projection = context_projection
        self.last_aca_output: dict[str, torch.Tensor] | None = None
        self._current_masks: torch.Tensor | None = None
        self._current_text: torch.Tensor | None = None
        self._current_condition = "correct"
        self._capture_handle = self.voxtell.project_bottleneck_embed.register_forward_pre_hook(
            self._capture_visual_feature
        )
        self._inject_handle = self.voxtell.transformer_decoder.register_forward_pre_hook(
            self._inject_context, with_kwargs=True
        )

    def _capture_visual_feature(
        self,
        _module: nn.Module,
        inputs: tuple[torch.Tensor, ...],
    ) -> None:
        if self._current_masks is None or self._current_text is None:
            return
        projected_input = inputs[0]
        if projected_input.ndim != 5:
            raise ValueError("Unexpected VoxTell bottleneck projection input")
        # VoxTell rearranges B,C,D,H,W -> B,H,W,D,C before this module.
        pure_visual = projected_input.permute(0, 4, 3, 1, 2).contiguous()
        masks = permute_lobe_masks(self._current_masks, self._current_condition)
        self.last_aca_output = self.anatomy_encoder(
            pure_visual, masks, self._current_text
        )

    def _inject_context(
        self,
        _module: nn.Module,
        args: tuple[torch.Tensor, ...],
        kwargs: dict[str, torch.Tensor],
    ) -> tuple[tuple[torch.Tensor, ...], dict[str, torch.Tensor]]:
        if self.last_aca_output is None:
            return args, kwargs
        if "tgt" in kwargs:
            original_query = kwargs["tgt"]
            kwargs = dict(kwargs)
            kwargs["tgt"] = self.context_projection(
                original_query,
                self.last_aca_output["context"],
                enabled=self._current_condition != "zero",
            )
            return args, kwargs
        if not args:
            raise RuntimeError("VoxTell transformer received no target query")
        mutable = list(args)
        mutable[0] = self.context_projection(
            mutable[0],
            self.last_aca_output["context"],
            enabled=self._current_condition != "zero",
        )
        return tuple(mutable), kwargs

    def forward(
        self,
        image: torch.Tensor,
        text_embeddings: torch.Tensor,
        lobe_masks: torch.Tensor,
        anatomy_condition: str = "correct",
        **voxtell_kwargs: object,
    ) -> tuple[object, dict[str, torch.Tensor]]:
        self._current_masks = lobe_masks
        self._current_text = text_embeddings
        self._current_condition = anatomy_condition
        self.last_aca_output = None
        try:
            logits = self.voxtell(image, text_embeddings, **voxtell_kwargs)
        finally:
            self._current_masks = None
            self._current_text = None
        if self.last_aca_output is None:
            raise RuntimeError("ACA visual hook did not observe the selected VoxTell feature")
        return logits, self.last_aca_output

    def close(self) -> None:
        self._capture_handle.remove()
        self._inject_handle.remove()
