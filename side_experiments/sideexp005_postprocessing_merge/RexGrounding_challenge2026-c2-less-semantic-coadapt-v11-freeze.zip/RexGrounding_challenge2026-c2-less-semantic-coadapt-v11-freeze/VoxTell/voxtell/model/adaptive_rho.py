"""Frozen-feature adaptive S3 rho controllers for experiments B, C, and D."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import torch
from torch import nn


RHO_MAX = 0.5


def straight_through_clamp(value: torch.Tensor, low: float, high: float) -> torch.Tensor:
    """Clamp in the forward pass while preserving identity gradients."""
    bounded = value.clamp(low, high)
    return value + (bounded - value).detach()


class SampleAlphaPredictor(nn.Module):
    """Predict one sample-specific gate multiplier for one active S3 scale."""

    def __init__(self, feature_channels: int, prompt_dim: int, dropout: float = 0.1) -> None:
        super().__init__()
        self.image = nn.Sequential(
            nn.LayerNorm(feature_channels),
            nn.Linear(feature_channels, 32),
        )
        self.prompt = nn.Sequential(
            nn.LayerNorm(prompt_dim),
            nn.Linear(prompt_dim, 32),
        )
        self.head = nn.Sequential(
            nn.Linear(32 + 32 + 5, 32),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(32, 1),
        )
        nn.init.zeros_(self.head[-1].weight)
        nn.init.zeros_(self.head[-1].bias)

    @staticmethod
    def attention_statistics(attention: torch.Tensor) -> torch.Tensor:
        flat = attention.detach().float().flatten(start_dim=1)
        topk = max(1, int(round(flat.shape[1] * 0.01)))
        probability = flat.clamp(1e-6, 1.0 - 1e-6)
        entropy = -(
            probability * probability.log()
            + (1.0 - probability) * (1.0 - probability).log()
        ).mean(dim=1)
        return torch.stack(
            (
                flat.mean(dim=1),
                flat.std(dim=1, unbiased=False),
                flat.amax(dim=1),
                flat.topk(topk, dim=1).values.mean(dim=1),
                entropy,
            ),
            dim=1,
        )

    def forward(
        self,
        image_feature: torch.Tensor,
        prompt_embedding: torch.Tensor,
        attention: torch.Tensor,
    ) -> torch.Tensor:
        image_summary = image_feature.detach().float().mean(dim=(2, 3, 4))
        prompt_summary = prompt_embedding.detach().float()
        stats = self.attention_statistics(attention)
        z = self.head(
            torch.cat(
                (self.image(image_summary), self.prompt(prompt_summary), stats),
                dim=1,
            )
        ).squeeze(1)
        return 2.0 * torch.sigmoid(z)


class AdaptiveRhoScale(nn.Module):
    """Trainable rho parameters and optional D-stage alpha predictor."""

    def __init__(
        self,
        stage: str,
        rho_init: torch.Tensor,
        feature_channels: int,
        prompt_dim: int,
        rho_max: float,
    ) -> None:
        super().__init__()
        if stage not in {"B", "C", "D"}:
            raise ValueError(f"Unknown adaptive-rho stage: {stage}")
        if rho_init.ndim not in {1, 2}:
            raise ValueError(f"rho_init must be [category] or [category,channel], got {rho_init.shape}")
        if stage == "B" and rho_init.ndim != 1:
            raise ValueError("B requires scalar category-scale rho")
        if stage in {"C", "D"} and rho_init.shape != (rho_init.shape[0], feature_channels):
            raise ValueError(
                f"{stage} requires [{rho_init.shape[0]},{feature_channels}] rho, got {rho_init.shape}"
            )
        if bool((rho_init < 0).any()) or bool((rho_init > rho_max).any()):
            raise ValueError("rho initialization is outside the allowed bounds")
        self.stage = stage
        self.rho_max = float(rho_max)
        self.rho_raw = nn.Parameter(rho_init.detach().float().clone())
        self.register_buffer("rho_init", rho_init.detach().float().clone())
        self.alpha_predictor = (
            SampleAlphaPredictor(feature_channels, prompt_dim) if stage == "D" else None
        )
        self.last_alpha: torch.Tensor | None = None
        self.last_effective_rho: torch.Tensor | None = None

    def forward(
        self,
        category_indices: torch.Tensor,
        image_feature: torch.Tensor,
        prompt_embedding: torch.Tensor,
        attention: torch.Tensor,
    ) -> torch.Tensor:
        rho = straight_through_clamp(self.rho_raw, 0.0, self.rho_max)
        selected = rho[category_indices]
        alpha = None
        if self.alpha_predictor is not None:
            alpha = self.alpha_predictor(image_feature, prompt_embedding, attention)
            selected = straight_through_clamp(
                selected * alpha[:, None],
                0.0,
                self.rho_max,
            )
        self.last_alpha = None if alpha is None else alpha
        self.last_effective_rho = selected
        return selected

    @torch.no_grad()
    def project_(self) -> None:
        self.rho_raw.data.clamp_(0.0, self.rho_max)


class AdaptiveRhoGateAdapter(nn.Module):
    """Category, channel, and sample-adaptive S3 suppression strengths."""

    FORMAT_VERSION = "voxtell_s3_adaptive_rho.v1"

    def __init__(
        self,
        *,
        stage: str,
        categories: Sequence[str],
        scales: Sequence[str],
        channels_by_scale: Mapping[str, int],
        rho_init_by_scale: Mapping[str, torch.Tensor],
        prompt_dim: int,
        rho_max: float = RHO_MAX,
    ) -> None:
        super().__init__()
        if not categories or len(set(categories)) != len(categories):
            raise ValueError("categories must be a non-empty unique sequence")
        if not scales or len(set(scales)) != len(scales):
            raise ValueError("scales must be a non-empty unique sequence")
        if not 0 < rho_max <= RHO_MAX:
            raise ValueError(f"rho_max must be in (0,{RHO_MAX}]")
        self.stage = str(stage)
        self.categories = tuple(map(str, categories))
        self.category_to_index = {
            category: index for index, category in enumerate(self.categories)
        }
        self.scales = tuple(map(str, scales))
        self.channels_by_scale = {
            str(scale): int(channels_by_scale[scale]) for scale in self.scales
        }
        self.prompt_dim = int(prompt_dim)
        self.rho_max = float(rho_max)
        self.scale_modules = nn.ModuleDict(
            {
                self.scale_key(scale): AdaptiveRhoScale(
                    self.stage,
                    rho_init_by_scale[scale],
                    self.channels_by_scale[scale],
                    self.prompt_dim,
                    self.rho_max,
                )
                for scale in self.scales
            }
        )
        self.record_observations = False
        self.observations: list[dict[str, float | int | str]] = []

    @staticmethod
    def scale_key(scale: str) -> str:
        return str(scale).replace("/", "over")

    def forward(
        self,
        scale: str,
        category_indices: torch.Tensor,
        image_feature: torch.Tensor,
        prompt_embedding: torch.Tensor,
        attention: torch.Tensor,
        active_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        if scale not in self.scales:
            raise KeyError(f"Adaptive rho received inactive scale {scale!r}")
        if category_indices.ndim != 1 or category_indices.shape[0] != image_feature.shape[0]:
            raise ValueError(
                "category_indices must be [B], got "
                f"{tuple(category_indices.shape)} for batch {image_feature.shape[0]}"
            )
        if bool((category_indices < 0).any()) or bool(
            (category_indices >= len(self.categories)).any()
        ):
            raise IndexError("Adaptive-rho category index is out of range")
        module = self.scale_modules[self.scale_key(scale)]
        if active_mask is None:
            active_mask = torch.ones_like(category_indices, dtype=torch.bool)
        else:
            active_mask = active_mask.to(
                device=category_indices.device, dtype=torch.bool
            )
            if active_mask.shape != category_indices.shape:
                raise ValueError(
                    f"active_mask shape {tuple(active_mask.shape)} does not match "
                    f"category_indices {tuple(category_indices.shape)}"
                )
        if bool(active_mask.all()):
            effective_rho = module(
                category_indices,
                image_feature,
                prompt_embedding,
                attention,
            )
            active_indices = category_indices
            active_values = effective_rho
        else:
            output_shape = (
                (category_indices.shape[0],)
                if self.stage == "B"
                else (category_indices.shape[0], self.channels_by_scale[scale])
            )
            effective_rho = image_feature.new_zeros(output_shape, dtype=torch.float32)
            active_indices = category_indices[active_mask]
            if bool(active_mask.any()):
                active_values = module(
                    active_indices,
                    image_feature[active_mask],
                    prompt_embedding[active_mask],
                    attention[active_mask],
                )
                effective_rho[active_mask] = active_values
            else:
                active_values = effective_rho[:0]
                module.last_alpha = None
                module.last_effective_rho = active_values
        if self.record_observations and module.last_alpha is not None:
            alpha = module.last_alpha.detach().float().cpu()
            rho = active_values.detach().float().cpu()
            indices = active_indices.detach().cpu()
            for batch_index, category_index in enumerate(indices.tolist()):
                values = rho[batch_index]
                self.observations.append(
                    {
                        "category": self.categories[category_index],
                        "category_index": int(category_index),
                        "scale": scale,
                        "alpha": float(alpha[batch_index]),
                        "effective_rho_mean": float(values.mean()),
                        "effective_rho_min": float(values.min()),
                        "effective_rho_max": float(values.max()),
                    }
                )
        return effective_rho

    def enable_observation_recording(self, enabled: bool = True, *, clear: bool = True) -> None:
        self.record_observations = bool(enabled)
        if clear:
            self.observations.clear()

    @torch.no_grad()
    def project_(self) -> None:
        for module in self.scale_modules.values():
            module.project_()

    def rho_parameters(self) -> list[nn.Parameter]:
        return [module.rho_raw for module in self.scale_modules.values()]

    def alpha_parameters(self) -> list[nn.Parameter]:
        return [
            parameter
            for module in self.scale_modules.values()
            if module.alpha_predictor is not None
            for parameter in module.alpha_predictor.parameters()
        ]

    def config(self) -> dict[str, Any]:
        return {
            "stage": self.stage,
            "categories": list(self.categories),
            "scales": list(self.scales),
            "channels_by_scale": self.channels_by_scale,
            "prompt_dim": self.prompt_dim,
            "rho_max": self.rho_max,
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "AdaptiveRhoGateAdapter":
        if payload.get("format_version") != cls.FORMAT_VERSION:
            raise ValueError(f"Unsupported adaptive-rho payload: {payload.get('format_version')}")
        config = dict(payload["adapter_config"])
        state = payload["adapter_state"]
        rho_init_by_scale = {}
        for scale in config["scales"]:
            key = f"scale_modules.{cls.scale_key(scale)}.rho_init"
            rho_init_by_scale[scale] = state[key].detach().float()
        module = cls(rho_init_by_scale=rho_init_by_scale, **config)
        module.load_state_dict(state, strict=True)
        return module
