"""LESS-style repeated one-way word conditioning for VoxTell's 3-D encoder.

This module deliberately keeps text immutable: image queries attend to frozen
word tokens, then a bounded MLP residual is written only into image features.
Query chunking is mathematically exact because image-query attention has no
interaction between distinct query positions when K/V are the shared words.
"""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import nn


class LESSImageWordConditioning3D(nn.Module):
    """``V + tanh(MLP(LN(ImageToWordCA(V, T))))`` at one encoder stage."""

    def __init__(
        self,
        *,
        image_dim: int,
        text_dim: int,
        attention_dim: int,
        num_heads: int,
        query_chunk_size: int = 4096,
        dropout: float = 0.0,
        init_seed: int = 260820,
        output_init_scale: float = 1e-3,
    ) -> None:
        super().__init__()
        if attention_dim <= 0 or attention_dim % num_heads:
            raise ValueError("attention_dim must be positive and divisible by num_heads")
        if query_chunk_size <= 0:
            raise ValueError("query_chunk_size must be positive")
        if output_init_scale <= 0:
            raise ValueError("output_init_scale must be positive")
        self.image_dim = int(image_dim)
        self.text_dim = int(text_dim)
        self.attention_dim = int(attention_dim)
        self.num_heads = int(num_heads)
        self.head_dim = self.attention_dim // self.num_heads
        self.query_chunk_size = int(query_chunk_size)
        self.dropout = float(dropout)
        with torch.random.fork_rng(devices=[]):
            self.image_norm = nn.LayerNorm(self.image_dim)
            self.text_norm = nn.LayerNorm(self.text_dim)
            self.q_proj = nn.Linear(self.image_dim, self.attention_dim)
            self.k_proj = nn.Linear(self.text_dim, self.attention_dim)
            self.v_proj = nn.Linear(self.text_dim, self.attention_dim)
            self.attention_out = nn.Linear(self.attention_dim, self.image_dim)
            self.mlp_norm = nn.LayerNorm(self.image_dim)
            self.mlp = nn.Sequential(
                nn.Linear(self.image_dim, 4 * self.image_dim),
                nn.GELU(),
                nn.Dropout(self.dropout),
                nn.Linear(4 * self.image_dim, self.image_dim),
            )
        self._reset_deterministically(init_seed, float(output_init_scale))
        self.last_audit: dict[str, object] = {}
        self.last_delta: torch.Tensor | None = None

    def _reset_deterministically(self, seed: int, output_scale: float) -> None:
        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(seed))
        with torch.no_grad():
            for norm in (self.image_norm, self.text_norm, self.mlp_norm):
                norm.weight.fill_(1.0)
                norm.bias.zero_()
            for linear in (self.q_proj, self.k_proj, self.v_proj, self.attention_out, self.mlp[0], self.mlp[3]):
                nn.init.xavier_uniform_(linear.weight, generator=generator)
                linear.bias.zero_()
            # A small but nonzero final mapping preserves the pretrained encoder
            # at startup while allowing gradients through all LESS components.
            self.mlp[3].weight.mul_(output_scale)

    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())

    def forward(
        self,
        image_feature: torch.Tensor,
        text_tokens: torch.Tensor,
        valid_token_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Condition prompt-flattened features ``[BP,C,D,H,W]`` exactly."""
        if image_feature.ndim != 5 or text_tokens.ndim != 3 or valid_token_mask.ndim != 2:
            raise ValueError("Expected image [BP,C,D,H,W], tokens [BP,L,H], mask [BP,L]")
        bp, channels, depth, height, width = image_feature.shape
        if channels != self.image_dim or text_tokens.shape[0] != bp or text_tokens.shape[-1] != self.text_dim:
            raise ValueError("LESS input dimensions do not match the constructed stage")
        if valid_token_mask.shape != text_tokens.shape[:2] or not bool(valid_token_mask.any(dim=1).all()):
            raise ValueError("LESS token validity mask is invalid")
        n_image = depth * height * width
        n_text = text_tokens.shape[1]
        image_tokens = image_feature.permute(0, 2, 3, 4, 1).reshape(bp, n_image, channels)
        text_normalized = self.text_norm(text_tokens)
        key = self.k_proj(text_normalized).view(bp, n_text, self.num_heads, self.head_dim).transpose(1, 2)
        value = self.v_proj(text_normalized).view(bp, n_text, self.num_heads, self.head_dim).transpose(1, 2)
        invalid = ~valid_token_mask.to(dtype=torch.bool, device=image_feature.device)
        mask = torch.zeros((bp, 1, 1, n_text), dtype=image_feature.dtype, device=image_feature.device)
        mask = mask.masked_fill(invalid[:, None, None], torch.finfo(image_feature.dtype).min)
        outputs: list[torch.Tensor] = []
        for start in range(0, n_image, self.query_chunk_size):
            end = min(start + self.query_chunk_size, n_image)
            query = self.q_proj(self.image_norm(image_tokens[:, start:end]))
            query = query.view(bp, end - start, self.num_heads, self.head_dim).transpose(1, 2)
            attended = F.scaled_dot_product_attention(
                query, key, value, attn_mask=mask,
                dropout_p=self.dropout if self.training else 0.0,
            )
            attended = attended.transpose(1, 2).reshape(bp, end - start, self.attention_dim)
            outputs.append(self.attention_out(attended))
        cross = torch.cat(outputs, dim=1)
        residual = torch.tanh(self.mlp(self.mlp_norm(cross)))
        conditioned = image_tokens + residual
        self.last_delta = residual.reshape(bp, depth, height, width, channels).permute(0, 4, 1, 2, 3).detach()
        with torch.no_grad():
            self.last_audit = {
                "image_shape": list(image_feature.shape),
                "n_image": int(n_image),
                "n_text": int(n_text),
                "query_chunk_size": self.query_chunk_size,
                "num_query_chunks": int(math.ceil(n_image / self.query_chunk_size)),
                "attention_dim": self.attention_dim,
                "num_heads": self.num_heads,
                "delta_rms": float(residual.detach().float().square().mean().sqrt().item()),
                "base_rms": float(image_tokens.detach().float().square().mean().sqrt().item()),
            }
        return conditioned.reshape(bp, depth, height, width, channels).permute(0, 4, 1, 2, 3)
