"""Full-memory progressive BiCo; no pooling and no Qwen parameters."""
from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F

from voxtell.model.less_word_conditioning import LESSImageWordConditioning3D


class FullMemoryTextReadsImage(nn.Module):
    def __init__(self, image_dim, text_dim=2560, attention_dim=256,
                 num_heads=8, init_seed=260820, output_init_scale=1e-3):
        super().__init__()
        self.heads = num_heads
        self.head_dim = attention_dim // num_heads
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(init_seed)
            self.text_norm = nn.LayerNorm(text_dim)
            self.image_norm = nn.LayerNorm(image_dim)
            self.q_proj = nn.Linear(text_dim, attention_dim)
            self.k_proj = nn.Linear(image_dim, attention_dim)
            self.v_proj = nn.Linear(image_dim, attention_dim)
            self.out_proj = nn.Linear(attention_dim, text_dim)
            for layer in (self.q_proj, self.k_proj, self.v_proj, self.out_proj):
                nn.init.xavier_uniform_(layer.weight)
                nn.init.zeros_(layer.bias)
            with torch.no_grad():
                self.out_proj.weight.mul_(output_init_scale)

    def forward(self, image, tokens, valid):
        bp, _, d, h, w = image.shape
        memory = self.image_norm(image.flatten(2).transpose(1, 2))
        def heads(x):
            return x.reshape(bp, -1, self.heads, self.head_dim).transpose(1, 2)
        q = heads(self.q_proj(self.text_norm(tokens)))
        k, v = heads(self.k_proj(memory)), heads(self.v_proj(memory))
        attended = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0)
        attended = attended.transpose(1, 2).reshape(bp, tokens.shape[1], -1)
        delta = self.out_proj(attended) * valid[..., None].to(tokens.dtype)
        # Invalid text positions retain their input; they are excluded as image keys.
        return tokens + delta


class BiCoImageTextStage3D(nn.Module):
    """T'=T+CA(T,V); V'=LESS(V,T'). Caller carries BOTH to next stage."""
    def __init__(self, *, image_dim, text_dim, attention_dim, num_heads,
                 query_chunk_size=4096, dropout=0.0, init_seed=260820):
        super().__init__()
        if attention_dim != 256 or num_heads != 8 or dropout != 0:
            raise ValueError('BiCo E345 requires dim256, heads8, dropout0')
        self.text_reads_image = FullMemoryTextReadsImage(
            image_dim, text_dim, attention_dim, num_heads, init_seed + 1000)
        self.image_reads_text = LESSImageWordConditioning3D(
            image_dim=image_dim, text_dim=text_dim, attention_dim=attention_dim,
            num_heads=num_heads, query_chunk_size=query_chunk_size,
            dropout=dropout, init_seed=init_seed)
        self.last_audit = {}

    def forward(self, image, tokens, valid):
        updated_tokens = self.text_reads_image(image, tokens, valid)
        updated_image = self.image_reads_text(image, updated_tokens, valid)
        with torch.no_grad():
            mask = valid[..., None]
            self.last_audit = {
                **self.image_reads_text.last_audit,
                'text_rel_delta': float(((updated_tokens - tokens).float() * mask).norm()
                                        / (tokens.float() * mask).norm().clamp_min(1e-12)),
                'image_rel_delta': float((updated_image.float() - image.float()).norm()
                                         / image.float().norm().clamp_min(1e-12)),
                'full_memory_positions': int(image.shape[2] * image.shape[3] * image.shape[4]),
            }
        return updated_image, updated_tokens
