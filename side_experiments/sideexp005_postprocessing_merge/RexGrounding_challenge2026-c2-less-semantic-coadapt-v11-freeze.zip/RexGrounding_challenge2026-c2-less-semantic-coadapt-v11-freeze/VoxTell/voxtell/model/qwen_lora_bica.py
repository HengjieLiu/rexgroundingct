"""Frozen-prefix Qwen3 LoRA and Stage-3 bidirectional co-adaptation blocks.

The Qwen base model is loaded from the local Hugging Face snapshot at runtime.
Its parameters stay frozen and are deliberately excluded from ReX checkpoints;
only the rank-8 LoRA residuals and (for C2) the BiCA parameters are trainable.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from torch import nn
from transformers import AutoModel
from transformers.masking_utils import create_causal_mask


class LoRALinear(nn.Module):
    """Frozen linear layer plus a zero-initialized LoRA residual."""

    def __init__(self, base: nn.Linear, rank: int = 8) -> None:
        super().__init__()
        if rank <= 0:
            raise ValueError("LoRA rank must be positive")
        self.base = base
        for parameter in self.base.parameters():
            parameter.requires_grad_(False)
        self.rank = int(rank)
        self.lora_a = nn.Linear(base.in_features, self.rank, bias=False)
        self.lora_b = nn.Linear(self.rank, base.out_features, bias=False)
        # Plain (non-state-dict) inference control used only by causal audits.
        # Training and ordinary inference retain the exact historical value 1.
        self.inference_residual_scale = 1.0
        # A random A and zero B preserve the exact base-model function while
        # allowing B to receive a gradient at the first update.
        nn.init.kaiming_uniform_(self.lora_a.weight, a=math.sqrt(5))
        nn.init.zeros_(self.lora_b.weight)

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        residual = self.lora_b(self.lora_a(value))
        return self.base(value) + float(self.inference_residual_scale) * residual.to(
            dtype=value.dtype
        )


class QwenTop6LoRA(nn.Module):
    """Run Qwen3 layers 30--35 from a cached frozen-prefix hidden state."""

    MODEL_NAME = "Qwen/Qwen3-Embedding-4B"

    def __init__(
        self,
        *,
        model_name: str = MODEL_NAME,
        top_k: int = 6,
        rank: int = 8,
        dtype: torch.dtype = torch.bfloat16,
        local_files_only: bool = True,
    ) -> None:
        super().__init__()
        self.model_name = str(model_name)
        self.top_k = int(top_k)
        self.rank = int(rank)
        self.backbone = AutoModel.from_pretrained(
            self.model_name,
            local_files_only=local_files_only,
            torch_dtype=dtype,
        )
        self.backbone.eval()
        for parameter in self.backbone.parameters():
            parameter.requires_grad_(False)
        # AutoModel is a Qwen3Model in the installed Transformers version;
        # retain compatibility with versions that expose it through `.model`.
        model = getattr(self.backbone, "model", self.backbone)
        self.num_layers = int(model.config.num_hidden_layers)
        self.hidden_size = int(model.config.hidden_size)
        if self.top_k <= 0 or self.top_k >= self.num_layers:
            raise ValueError(f"top_k must be in [1,{self.num_layers - 1}], got {self.top_k}")
        self.prefix_layers = self.num_layers - self.top_k
        self.top_layer_indices = tuple(range(self.prefix_layers, self.num_layers))
        for index in self.top_layer_indices:
            layer = model.layers[index]
            for name in ("q_proj", "v_proj"):
                module = getattr(layer.self_attn, name, None)
                if not isinstance(module, nn.Linear):
                    raise TypeError(f"Qwen layer {index} has no nn.Linear {name}")
                # The frozen Qwen checkpoint is BF16.  Constructing a new
                # nn.Linear otherwise leaves its LoRA A/B weights in FP32,
                # which fails on the first BF16 attention input and is not an
                # intended mixed-precision policy for this small adapter.
                replacement = LoRALinear(module, rank=self.rank).to(
                    device=module.weight.device, dtype=module.weight.dtype
                )
                setattr(layer.self_attn, name, replacement)

    @property
    def lora_parameter_count(self) -> int:
        return sum(
            parameter.numel()
            for name, parameter in self.named_parameters()
            if ".lora_" in name
        )

    def train(self, mode: bool = True):  # type: ignore[override]
        # Qwen's pretrained path stays deterministic/frozen.  The LoRA modules
        # have no dropout, so this is also safe for training.
        super().train(mode)
        self.backbone.eval()
        return self

    def trainable_lora_state_dict(self) -> dict[str, torch.Tensor]:
        return {
            name: value.detach().cpu()
            for name, value in self.state_dict().items()
            if ".lora_" in name
        }

    def load_trainable_lora_state_dict(self, state: dict[str, torch.Tensor]) -> None:
        expected = set(self.trainable_lora_state_dict())
        received = set(state)
        if expected != received:
            raise RuntimeError(
                "Qwen LoRA state mismatch: "
                f"missing={sorted(expected - received)[:8]}, "
                f"unexpected={sorted(received - expected)[:8]}"
            )
        own = self.state_dict()
        for name, value in state.items():
            own[name].copy_(value.to(device=own[name].device, dtype=own[name].dtype))

    def _mask_and_positions(
        self,
        hidden: torch.Tensor,
        attention_mask: torch.Tensor,
        position_ids: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if hidden.ndim != 3 or hidden.shape[-1] != self.hidden_size:
            raise ValueError("prefix hidden states must have shape [B,L,2560]")
        if attention_mask.shape != hidden.shape[:2]:
            raise ValueError("attention_mask must match prefix hidden [B,L]")
        if position_ids.shape != hidden.shape[:2]:
            raise ValueError("position_ids must match prefix hidden [B,L]")
        attention_mask = attention_mask.to(device=hidden.device, dtype=torch.long)
        position_ids = position_ids.to(device=hidden.device, dtype=torch.long)
        cache_position = torch.arange(hidden.shape[1], device=hidden.device)
        causal_mask = create_causal_mask(
            config=self.backbone.config,
            input_embeds=hidden,
            attention_mask=attention_mask,
            cache_position=cache_position,
            past_key_values=None,
            position_ids=position_ids,
        )
        return causal_mask, position_ids, cache_position

    def forward_from_prefix(
        self,
        prefix_hidden: torch.Tensor,
        attention_mask: torch.Tensor,
        position_ids: torch.Tensor,
    ) -> torch.Tensor:
        """Resume exactly the final Qwen layers and apply Qwen's final norm."""
        model = getattr(self.backbone, "model", self.backbone)
        hidden = prefix_hidden.to(dtype=next(model.layers[-1].parameters()).dtype)
        causal_mask, position_ids, cache_position = self._mask_and_positions(
            hidden, attention_mask, position_ids
        )
        position_embeddings = model.rotary_emb(hidden, position_ids)
        for index in self.top_layer_indices:
            layer = model.layers[index]
            hidden = layer(
                hidden,
                attention_mask=causal_mask,
                position_ids=position_ids,
                past_key_values=None,
                use_cache=False,
                cache_position=cache_position,
                position_embeddings=position_embeddings,
            )
        return model.norm(hidden)

    @staticmethod
    def last_token_pool(hidden: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        # This is intentionally the exact VoxTell pooling convention.
        left_padding = bool((attention_mask[:, -1].sum() == attention_mask.shape[0]).item())
        if left_padding:
            return hidden[:, -1]
        sequence_lengths = attention_mask.sum(dim=1).to(torch.long) - 1
        return hidden[torch.arange(hidden.shape[0], device=hidden.device), sequence_lengths]


class Stage3BidirectionalCrossAttention(nn.Module):
    """One identity-initialized text→image→text Stage-3 interaction.

    The nonzero projections and zero output projections mean the branches are
    exactly identity at update zero, while each output projection receives a
    gradient on the first optimizer update.  Q/K/V then become trainable after
    the first nonzero residual update.
    """

    def __init__(
        self,
        image_dim: int,
        text_dim: int = 2560,
        attention_dim: int = 256,
        heads: int = 8,
        dropout: float = 0.0,
        init_seed: int = 260825,
    ) -> None:
        super().__init__()
        if attention_dim <= 0 or attention_dim % heads:
            raise ValueError("attention_dim must be positive and divisible by heads")
        self.image_dim = int(image_dim)
        self.text_dim = int(text_dim)
        self.attention_dim = int(attention_dim)
        self.heads = int(heads)
        self.head_dim = self.attention_dim // self.heads
        self.dropout = float(dropout)
        self.image_norm_t2i = nn.LayerNorm(self.image_dim)
        self.text_norm_t2i = nn.LayerNorm(self.text_dim)
        self.text_norm_i2t = nn.LayerNorm(self.text_dim)
        self.image_norm_i2t = nn.LayerNorm(self.image_dim)
        self.t2i_q = nn.Linear(self.image_dim, self.attention_dim)
        self.t2i_k = nn.Linear(self.text_dim, self.attention_dim)
        self.t2i_v = nn.Linear(self.text_dim, self.attention_dim)
        self.t2i_out = nn.Linear(self.attention_dim, self.image_dim)
        self.i2t_q = nn.Linear(self.text_dim, self.attention_dim)
        self.i2t_k = nn.Linear(self.image_dim, self.attention_dim)
        self.i2t_v = nn.Linear(self.image_dim, self.attention_dim)
        self.i2t_out = nn.Linear(self.attention_dim, self.text_dim)
        self._reset(init_seed)
        self.last_audit: dict[str, Any] = {}

    def _reset(self, seed: int) -> None:
        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(seed))
        with torch.no_grad():
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    if module in (self.t2i_out, self.i2t_out):
                        module.weight.zero_()
                        module.bias.zero_()
                    else:
                        nn.init.xavier_uniform_(module.weight, generator=generator)
                        module.bias.zero_()
                elif isinstance(module, nn.LayerNorm):
                    module.weight.fill_(1.0)
                    module.bias.zero_()

    def _project(self, value: torch.Tensor, projection: nn.Linear) -> torch.Tensor:
        batch, length, _ = value.shape
        return projection(value).view(batch, length, self.heads, self.head_dim).transpose(1, 2)

    def _mask(self, valid: torch.Tensor, dtype: torch.dtype) -> torch.Tensor:
        invalid = ~valid.to(dtype=torch.bool)
        return torch.zeros(
            (valid.shape[0], 1, 1, valid.shape[1]), device=valid.device, dtype=dtype
        ).masked_fill(invalid[:, None, None], torch.finfo(dtype).min)

    def forward(
        self,
        image_tokens: torch.Tensor,
        text_tokens: torch.Tensor,
        text_valid_mask: torch.Tensor,
        *,
        enable_text_to_image: bool = True,
        enable_image_to_text: bool = True,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if image_tokens.ndim != 3 or text_tokens.ndim != 3:
            raise ValueError("BiCA image/text tokens must be rank three")
        if image_tokens.shape[0] != text_tokens.shape[0]:
            raise ValueError("BiCA image/text batch axes must match")
        if image_tokens.shape[-1] != self.image_dim or text_tokens.shape[-1] != self.text_dim:
            raise ValueError("BiCA feature dimensions do not match configuration")
        if text_valid_mask.shape != text_tokens.shape[:2] or not bool(text_valid_mask.any(dim=1).all()):
            raise ValueError("Every BiCA text sequence requires one valid token")
        t2i_q = self._project(self.image_norm_t2i(image_tokens), self.t2i_q)
        t2i_k = self._project(self.text_norm_t2i(text_tokens), self.t2i_k)
        t2i_v = self._project(self.text_norm_t2i(text_tokens), self.t2i_v)
        t2i_context = F.scaled_dot_product_attention(
            t2i_q, t2i_k, t2i_v, attn_mask=self._mask(text_valid_mask, t2i_q.dtype),
            dropout_p=self.dropout if self.training else 0.0,
        )
        t2i_context = t2i_context.transpose(1, 2).reshape(
            image_tokens.shape[0], image_tokens.shape[1], self.attention_dim
        )
        delta_v = self.t2i_out(t2i_context)
        image_updated = image_tokens + (delta_v if enable_text_to_image else 0.0)
        i2t_q = self._project(self.text_norm_i2t(text_tokens), self.i2t_q)
        i2t_k = self._project(self.image_norm_i2t(image_updated), self.i2t_k)
        i2t_v = self._project(self.image_norm_i2t(image_updated), self.i2t_v)
        i2t_context = F.scaled_dot_product_attention(
            i2t_q, i2t_k, i2t_v,
            dropout_p=self.dropout if self.training else 0.0,
        )
        i2t_context = i2t_context.transpose(1, 2).reshape(
            text_tokens.shape[0], text_tokens.shape[1], self.attention_dim
        )
        delta_t = self.i2t_out(i2t_context)
        text_updated = text_tokens + (delta_t if enable_image_to_text else 0.0)
        # Padding queries cannot alter Qwen's downstream output.  Retain the
        # original padded states exactly, while their keys remain masked above.
        text_updated = torch.where(text_valid_mask[:, :, None], text_updated, text_tokens)
        # Report whole-representation relative norms.  In particular, exclude
        # padded text queries: their cached state is exactly zero, so averaging
        # per-token ratios would divide a harmless padded delta by 1e-12 and
        # produce a misleadingly huge diagnostic despite the padding being
        # restored immediately above.
        image_reference = image_tokens.detach().float()
        image_delta = delta_v.detach().float()
        valid_text = text_valid_mask[:, :, None]
        text_reference = torch.where(valid_text, text_tokens.detach().float(), 0.0)
        text_delta = torch.where(valid_text, delta_t.detach().float(), 0.0)
        self.last_audit = {
            "image_token_count": int(image_tokens.shape[1]),
            "text_token_count": int(text_tokens.shape[1]),
            "valid_text_tokens_min": int(text_valid_mask.sum(dim=1).min().item()),
            "valid_text_tokens_max": int(text_valid_mask.sum(dim=1).max().item()),
            "attention_dim": self.attention_dim,
            "heads": self.heads,
            "delta_v_rel_l2": float(
                image_delta.norm().div(image_reference.norm().clamp_min(1e-12)).item()
            ),
            "delta_t_rel_l2": float(
                text_delta.norm().div(text_reference.norm().clamp_min(1e-12)).item()
            ),
            "delta_v_max_abs": float(delta_v.detach().float().abs().amax().item()),
            "delta_t_max_abs": float(delta_t.detach().float().abs().amax().item()),
            "text_to_image_enabled": bool(enable_text_to_image),
            "image_to_text_enabled": bool(enable_image_to_text),
        }
        return image_updated, text_updated


def cache_key(record: dict[str, Any]) -> str:
    """Stable cache key for a wrapped prompt's frozen prefix representation."""
    prompt = str(record["prompt"])
    return hashlib.sha256(prompt.encode("utf-8")).hexdigest()


def load_prefix_index(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text())
    if payload.get("format_version") != "rex_qwen_frozen_prefix.v1":
        raise ValueError(f"Unsupported Qwen prefix cache: {path}")
    return payload


class IndexedFrozenPrefixCache:
    """On-demand cache reader; it never materializes all prompt states in RAM."""

    def __init__(self, index_path: Path) -> None:
        self.index_path = Path(index_path)
        self.root = self.index_path.parent
        self.index = load_prefix_index(self.index_path)
        self.entries = dict(self.index["entries"])
        self.hidden_size = int(self.index["hidden_size"])
        self.prefix_layers = int(self.index["prefix_layers"])

    def batch(
        self,
        records: list[dict[str, Any]],
        *,
        device: torch.device,
        dtype: torch.dtype,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        items = []
        for record in records:
            key = cache_key(record)
            relative = self.entries.get(key)
            if relative is None:
                raise KeyError(f"No Qwen prefix cache entry for prompt {record.get('prompt')!r}")
            item = torch.load(self.root / relative, map_location="cpu", weights_only=False)
            if item.get("prompt") != str(record["prompt"]):
                raise RuntimeError("Qwen prefix-cache key collision or corrupt entry")
            items.append(item)
        max_length = max(int(item["hidden"].shape[0]) for item in items)
        hidden = torch.zeros(
            (len(items), max_length, self.hidden_size), dtype=dtype, device=device
        )
        mask = torch.zeros((len(items), max_length), dtype=torch.long, device=device)
        positions = torch.zeros((len(items), max_length), dtype=torch.long, device=device)
        for row, item in enumerate(items):
            value = item["hidden"]
            length = int(value.shape[0])
            if value.ndim != 2 or value.shape[1] != self.hidden_size:
                raise RuntimeError("Invalid Qwen prefix hidden-state cache shape")
            if int(item.get("sequence_length", length)) != length:
                raise RuntimeError("Qwen prefix cache has an invalid sequence length")
            if int(item.get("last_valid_token_index", length - 1)) != length - 1:
                raise RuntimeError("Qwen prefix cache has an invalid last-token index")
            stored_mask = item.get("attention_mask")
            stored_positions = item.get("position_ids")
            if stored_mask is None or stored_positions is None:
                raise RuntimeError("Qwen prefix cache entry lacks mask/position metadata")
            if tuple(stored_mask.shape) != (length,) or tuple(stored_positions.shape) != (length,):
                raise RuntimeError("Qwen prefix cache mask/position metadata has invalid shape")
            start = max_length - length  # canonical Qwen tokenizer uses left padding
            hidden[row, start:] = value.to(device=device, dtype=dtype)
            mask[row, start:] = stored_mask.to(device=device, dtype=torch.long)
            positions[row, start:] = stored_positions.to(device=device, dtype=torch.long)
        return hidden, mask, positions
