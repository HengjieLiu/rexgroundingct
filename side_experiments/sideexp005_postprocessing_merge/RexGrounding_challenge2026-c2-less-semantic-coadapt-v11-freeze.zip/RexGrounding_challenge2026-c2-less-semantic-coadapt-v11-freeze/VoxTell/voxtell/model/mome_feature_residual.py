"""Identity-preserving multi-scale MoME feature residual for VoxTell.

Unlike :mod:`voxtell.model.mome_core`, this adapter never creates logits.  It
adds a zero-initialized residual to the native 32-channel final decoder feature
and lets VoxTell's existing finding-specific mask embedding produce logits.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import torch
import torch.nn.functional as F
from torch import nn

from voxtell.model.mome_core import (
    ConditionalVoxelRouter3D,
    DecoderExpertProjection3D,
    FindingImageController,
)
from voxtell.model.voxtell_experimental import ExperimentalVoxTellModel


@dataclass(frozen=True)
class MoMEFeatureResidualConfig:
    """Locked stage-2 feature-residual configuration."""

    mode: str = "uniform"
    expert_channels: int = 8
    output_channels: int = 32
    controller_width: int = 128
    router_hidden_channels: int = 32
    router_epsilon: float = 1e-6
    capture_router_maps: bool = False

    def validate(self) -> None:
        if self.mode not in {"uniform", "learned"}:
            raise ValueError(f"Residual mode must be uniform or learned, got {self.mode!r}")
        if self.expert_channels != 8:
            raise ValueError("The stage-2 protocol requires exactly 8 expert channels")
        if self.output_channels != 32:
            raise ValueError("The residual must target the native 32-channel feature")
        if self.controller_width <= 0 or self.router_hidden_channels <= 0:
            raise ValueError("Controller and router widths must be positive")
        if self.router_epsilon <= 0:
            raise ValueError("Router epsilon must be positive")


class MoMEFeatureResidualAdapter(nn.Module):
    """Stream five decoder experts into a native-feature residual.

    Forward hooks are used only to observe all native decoder stages and to
    replace the final 32-channel feature with ``feature + residual``.  The
    surrounding :class:`ExperimentalVoxTellModel` continues into its original
    finding-specific 32-D dot-product head unchanged.
    """

    STAGE_CHANNELS = (320, 256, 128, 64, 32)

    def __init__(self, config: MoMEFeatureResidualConfig) -> None:
        super().__init__()
        config.validate()
        self.config = config
        self.expert_projections = nn.ModuleList(
            DecoderExpertProjection3D(channels, config.expert_channels)
            for channels in self.STAGE_CHANNELS
        )
        # Always instantiate the conditional modules so the update-100 common
        # checkpoint can initialize both branches from an identical state.
        # The trainer freezes/excludes them from the uniform optimizer.
        self.controller = FindingImageController(
            finding_channels=2048,
            visual_channels=320,
            latent_channels=config.controller_width,
        )
        self.routers = nn.ModuleList(
            ConditionalVoxelRouter3D(
                config.expert_channels,
                config.controller_width,
                config.router_hidden_channels,
            )
            for _ in self.STAGE_CHANNELS
        )
        self.output_projection = nn.Conv3d(
            config.expert_channels, config.output_channels, 1, bias=True
        )
        nn.init.zeros_(self.output_projection.weight)
        nn.init.zeros_(self.output_projection.bias)
        self._initialize_experts()
        self._hooks: list[Any] = []
        self._bound = False
        self._reset_runtime()

    def _initialize_experts(self) -> None:
        # All five experts start independently active.  Exact parent identity
        # comes solely from the required zero 8->32 output projection.
        for projection in self.expert_projections:
            nn.init.kaiming_normal_(projection.projection.weight, nonlinearity="linear")
            nn.init.zeros_(projection.projection.bias)

    def bind(self, model: ExperimentalVoxTellModel) -> None:
        if self._bound:
            raise RuntimeError("MoME feature-residual adapter is already bound")
        if len(model.decoder.stages) != len(self.STAGE_CHANNELS):
            raise RuntimeError(
                f"Expected five native decoder stages, got {len(model.decoder.stages)}"
            )
        native_projection = model.project_to_decoder_channels[0]
        final_linear = native_projection[-1]
        if not isinstance(final_linear, nn.Linear) or final_linear.out_features != 32:
            raise RuntimeError("Native finding-specific head does not emit 32 channels")
        if getattr(model, "s3_fullres_attention_refinement", None) is not None:
            raise RuntimeError("Stage-2 residual forbids an additional full-resolution refiner")
        if getattr(model, "s3_joint_fusion_head", None) is not None:
            raise RuntimeError("Stage-2 residual forbids a logit-residual head")
        self._hooks.append(model.encoder.register_forward_hook(self._encoder_hook))
        self._hooks.append(model.project_text_embed.register_forward_hook(self._finding_hook))
        for stage_index, stage in enumerate(model.decoder.stages):
            self._hooks.append(
                stage.register_forward_hook(self._make_stage_hook(stage_index))
            )
        self._bound = True

    def _reset_runtime(self) -> None:
        self._deepest_visual: torch.Tensor | None = None
        self._finding_query: torch.Tensor | None = None
        self._condition: torch.Tensor | None = None
        self._prompt_index = 0
        self._numerator: torch.Tensor | None = None
        self._denominator: torch.Tensor | None = None
        self._current_stage_count = 0
        self._current_sampled_positive: list[torch.Tensor] = []
        self._current_sampled_logits: list[torch.Tensor] = []
        self._current_positive_maps: list[torch.Tensor] = []
        self._projection_rms: list[list[torch.Tensor]] = []
        self._current_projection_rms: list[torch.Tensor] = []
        self._prompt_sampled_weights: list[torch.Tensor] = []
        self._prompt_sampled_logits: list[torch.Tensor] = []
        self._prompt_router_maps: list[torch.Tensor] = []
        self._residual_relative_norms: list[torch.Tensor] = []
        self._residual_rms: list[torch.Tensor] = []
        self._parent_rms: list[torch.Tensor] = []
        self.last_router_stats: dict[str, torch.Tensor] = {}
        self.last_router_maps: torch.Tensor | None = None
        self.last_projection_rms: torch.Tensor | None = None
        self.last_residual_relative_norm: torch.Tensor | None = None
        self.last_residual_rms: torch.Tensor | None = None
        self.last_parent_rms: torch.Tensor | None = None
        self.last_prompt_count = 0

    def begin_forward(self) -> None:
        self._reset_runtime()

    def _encoder_hook(self, _module: nn.Module, _inputs: Any, output: Any) -> None:
        if not isinstance(output, (list, tuple)) or not output:
            raise RuntimeError("MoME residual expected encoder skips")
        deepest = output[-1]
        if deepest.ndim != 5 or deepest.shape[1] != 320:
            raise RuntimeError(f"Expected deepest visual [B,320,D,H,W], got {tuple(deepest.shape)}")
        self._deepest_visual = deepest

    def _finding_hook(self, _module: nn.Module, _inputs: Any, output: Any) -> None:
        if output.ndim != 3 or output.shape[-1] != 2048:
            raise RuntimeError(
                f"Expected full finding representation [P,B,2048], got {tuple(output.shape)}"
            )
        self._finding_query = output

    def _ensure_condition(self) -> None:
        if self._condition is not None or self.config.mode == "uniform":
            return
        if self._finding_query is None or self._deepest_visual is None:
            raise RuntimeError("Router did not receive finding/image features")
        visual = self._deepest_visual.mean(dim=(2, 3, 4))
        prompts, batch, finding_channels = self._finding_query.shape
        visual_by_prompt = visual[None].expand(prompts, -1, -1)
        condition, _ = self.controller(
            self._finding_query.reshape(prompts * batch, finding_channels),
            visual_by_prompt.reshape(prompts * batch, visual.shape[-1]),
        )
        self._condition = condition.reshape(prompts, batch, -1)

    def _make_stage_hook(self, stage_index: int):
        def hook(_module: nn.Module, _inputs: Any, output: torch.Tensor) -> torch.Tensor | None:
            return self._consume_stage(stage_index, output)

        return hook

    def _consume_stage(
        self, stage_index: int, feature: torch.Tensor
    ) -> torch.Tensor | None:
        if feature.ndim != 5 or feature.shape[1] != self.STAGE_CHANNELS[stage_index]:
            raise RuntimeError(
                f"Decoder stage {stage_index} expected channels {self.STAGE_CHANNELS[stage_index]}, "
                f"got {tuple(feature.shape)}"
            )
        if self._finding_query is None:
            raise RuntimeError("Decoder ran before the finding representation was captured")
        if self._prompt_index >= self._finding_query.shape[0]:
            raise RuntimeError("Decoder produced more prompt passes than finding queries")
        final_size = tuple(
            int(value * (2 ** (len(self.STAGE_CHANNELS) - 1 - stage_index)))
            for value in feature.shape[2:]
        )
        projected = self.expert_projections[stage_index](feature)
        if tuple(projected.shape[2:]) != final_size:
            projected = F.interpolate(
                projected, size=final_size, mode="trilinear", align_corners=False
            )
        self._current_projection_rms.append(
            projected.detach().float().square().mean(dim=(1, 2, 3, 4)).sqrt()
        )
        if self.config.mode == "uniform":
            contribution = projected / len(self.STAGE_CHANNELS)
            self._numerator = (
                contribution
                if self._numerator is None
                else self._numerator + contribution
            )
        else:
            self._ensure_condition()
            assert self._condition is not None
            score = self.routers[stage_index](
                projected, self._condition[self._prompt_index]
            )
            positive = F.softplus(score) + self.config.router_epsilon
            contribution = positive * projected
            self._numerator = (
                contribution
                if self._numerator is None
                else self._numerator + contribution
            )
            self._denominator = (
                positive if self._denominator is None else self._denominator + positive
            )
            self._current_sampled_positive.append(
                positive.detach().flatten(start_dim=2)[..., ::1729]
            )
            self._current_sampled_logits.append(
                score.detach().flatten(start_dim=2)[..., ::1729]
            )
            if self.config.capture_router_maps:
                self._current_positive_maps.append(positive.detach())
        self._current_stage_count += 1
        if stage_index != len(self.STAGE_CHANNELS) - 1:
            return None

        if self._current_stage_count != len(self.STAGE_CHANNELS):
            raise RuntimeError("Residual fusion did not receive all five decoder stages")
        if feature.shape[1] != self.config.output_channels:
            raise RuntimeError(
                f"F_parent_32 must have 32 channels, got {tuple(feature.shape)}"
            )
        assert self._numerator is not None
        if self.config.mode == "uniform":
            fused = self._numerator
        else:
            assert self._denominator is not None
            fused = self._numerator / self._denominator.clamp_min(
                self.config.router_epsilon
            )
            sampled_positive = torch.cat(self._current_sampled_positive, dim=1)
            sampled = sampled_positive / sampled_positive.sum(
                dim=1, keepdim=True
            ).clamp_min(self.config.router_epsilon)
            self._prompt_sampled_weights.append(sampled)
            self._prompt_sampled_logits.append(
                torch.cat(self._current_sampled_logits, dim=1)
            )
            if self.config.capture_router_maps:
                positive_maps = torch.cat(self._current_positive_maps, dim=1)
                weights = positive_maps / positive_maps.sum(
                    dim=1, keepdim=True
                ).clamp_min(self.config.router_epsilon)
                self._prompt_router_maps.append(weights.detach())

        delta = self.output_projection(fused)
        if delta.shape != feature.shape:
            raise RuntimeError(
                f"Delta_F_32 shape {tuple(delta.shape)} != F_parent_32 {tuple(feature.shape)}"
            )
        parent_float = feature.detach().float()
        delta_float = delta.detach().float()
        parent_norm = parent_float.flatten(start_dim=1).norm(dim=1)
        delta_norm = delta_float.flatten(start_dim=1).norm(dim=1)
        self._residual_relative_norms.append(delta_norm / parent_norm.clamp_min(1e-12))
        self._residual_rms.append(delta_float.square().mean(dim=(1, 2, 3, 4)).sqrt())
        self._parent_rms.append(parent_float.square().mean(dim=(1, 2, 3, 4)).sqrt())
        self._projection_rms.append(self._current_projection_rms)
        self._current_projection_rms = []
        self._numerator = None
        self._denominator = None
        self._current_stage_count = 0
        self._current_sampled_positive = []
        self._current_sampled_logits = []
        self._current_positive_maps = []
        self._prompt_index += 1
        # This is the only modified tensor.  The native finding-specific head
        # consumes it immediately after the hook returns.
        return feature + delta

    def finish_forward(self) -> None:
        if self._finding_query is None or self._prompt_index != self._finding_query.shape[0]:
            raise RuntimeError("Residual prompt count does not match finding count")
        if self._numerator is not None or self._denominator is not None:
            raise RuntimeError("Residual adapter ended with an incomplete prompt")
        self.last_prompt_count = self._prompt_index
        self.last_projection_rms = torch.stack(
            [torch.stack(values, dim=1) for values in self._projection_rms], dim=1
        )
        self.last_residual_relative_norm = torch.stack(
            self._residual_relative_norms, dim=1
        )
        self.last_residual_rms = torch.stack(self._residual_rms, dim=1)
        self.last_parent_rms = torch.stack(self._parent_rms, dim=1)
        if self._prompt_sampled_weights:
            sampled = torch.stack(self._prompt_sampled_weights, dim=1)
            sampled_logits = torch.stack(self._prompt_sampled_logits, dim=1)
            entropy = -(sampled.clamp_min(1e-12) * sampled.clamp_min(1e-12).log()).sum(dim=2)
            self.last_router_stats = {
                "mome_residual_router_weight_min": sampled.amin(),
                "mome_residual_router_weight_max": sampled.amax(),
                "mome_residual_router_entropy_mean": entropy.mean(),
                "mome_residual_router_logit_std": sampled_logits.float().std(),
                **{
                    f"mome_residual_router_weight_mean_stage_{stage}": sampled[:, :, stage].mean()
                    for stage in range(len(self.STAGE_CHANNELS))
                },
            }
        if self._prompt_router_maps:
            self.last_router_maps = torch.stack(self._prompt_router_maps, dim=1)

    def config_dict(self) -> dict[str, Any]:
        return asdict(self.config)


class MoMEFeatureResidualVoxTellModel(ExperimentalVoxTellModel):
    """VoxTell with an identity-preserving feature residual before its native head."""

    def __init__(
        self,
        *args: Any,
        mome_residual_config: MoMEFeatureResidualConfig,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        if not self.enable_s3_voxel_text_matching_attention:
            raise RuntimeError("Stage-2 requires the canonical all-category S3 parent")
        if tuple(self.s3_attention_scales) != ("1/1",):
            raise RuntimeError("Stage-2 requires the canonical single 1/1 S3 scale")
        # Residual parameter initialization must not shift the base model's
        # subsequent stochastic sequence relative to B0.
        cpu_rng_state = torch.get_rng_state()
        self.mome_residual = MoMEFeatureResidualAdapter(mome_residual_config)
        torch.set_rng_state(cpu_rng_state)
        self.mome_residual.bind(self)
        self.mome_residual_config = mome_residual_config
        # Explicit evidence that no replacement segmentation head exists.
        if hasattr(self.mome_residual, "dynamic_head"):
            raise RuntimeError("Feature-residual path must not instantiate a dynamic head")

    def forward(self, *args: Any, **kwargs: Any):
        self.mome_residual.begin_forward()
        output = super().forward(*args, **kwargs)
        self.mome_residual.finish_forward()
        self.last_auxiliary_stats.update(self.mome_residual.last_router_stats)
        self.last_auxiliary_stats["mome_residual_relative_norm"] = (
            self.mome_residual.last_residual_relative_norm.mean()
        )
        self.last_auxiliary_stats["mome_residual_rms"] = (
            self.mome_residual.last_residual_rms.mean()
        )
        self.last_auxiliary_stats["mome_parent_feature_rms"] = (
            self.mome_residual.last_parent_rms.mean()
        )
        for stage in range(len(self.mome_residual.STAGE_CHANNELS)):
            self.last_auxiliary_stats[f"mome_residual_projection_rms_stage_{stage}"] = (
                self.mome_residual.last_projection_rms[:, :, stage].mean()
            )
        return output
