"""Prompt-conditioned prior probe on a frozen ordinary VoxTell decoder.

The probe observes only native no-attention decoder tensors. It does not alter
the segmentation path or synthesize attention-like inputs.
"""

from __future__ import annotations

import math
import types
from typing import Any, List

import torch
import torch.nn.functional as F
from torch import nn


ARCHITECTURE_ID = "frozen_noattn_category_2d_prior_probe_v1"


def _module_input(value: torch.Tensor, module: nn.Module) -> torch.Tensor:
    return value if torch.is_autocast_enabled() else value.to(next(module.parameters()).dtype)


class NoAttentionPriorHead2d(nn.Module):
    """Fuse prompt-conditioned half-stage input and native full-stage input."""

    def __init__(self, half_input_channels: int, full_channels: int) -> None:
        super().__init__()
        self.half_path = nn.Sequential(
            nn.Conv3d(half_input_channels, 32, 1),
            nn.GroupNorm(4, 32),
            nn.GELU(),
            nn.Conv3d(32, 32, 3, padding=1, groups=32),
            nn.GELU(),
            nn.Conv3d(32, 16, 1),
        )
        # upsampled latent + full-resolution previous decoder tensor + native skip
        self.full_path = nn.Sequential(
            nn.Conv3d(16 + 2 * full_channels, 16, 1),
            nn.GroupNorm(4, 16),
            nn.GELU(),
            nn.Conv3d(16, 16, 3, padding=1, groups=16),
            nn.GELU(),
            nn.Conv3d(16, 1, 1),
        )
        nn.init.zeros_(self.full_path[-1].weight)
        nn.init.constant_(self.full_path[-1].bias, math.log(0.01 / 0.99))

    def half_latent(self, value: torch.Tensor) -> torch.Tensor:
        return self.half_path(_module_input(value, self.half_path))

    def full_logits(
        self, latent: torch.Tensor, previous: torch.Tensor, native_skip: torch.Tensor
    ) -> torch.Tensor:
        latent = F.interpolate(
            latent, size=previous.shape[2:], mode="trilinear", align_corners=False
        )
        value = torch.cat((latent, previous, native_skip), dim=1)
        return self.full_path(_module_input(value, self.full_path))


class Category2dNoAttentionPriorProbe(nn.Module):
    def __init__(self, model: nn.Module) -> None:
        super().__init__()
        if len(model.decoder.stages) < 2:
            raise ValueError("No-attention prior requires the final two decoder stages")
        self.half_stage_index = len(model.decoder.stages) - 2
        self.full_stage_index = len(model.decoder.stages) - 1
        full_channels = int(model.encoder.output_channels[0])
        half_channels = int(model.encoder.output_channels[1])
        self.dense_prior_head = NoAttentionPriorHead2d(2 * half_channels, full_channels)
        self.execution_count = 0
        self.feature_audit: dict[str, list[int]] = {}


def reset_category_2d_noattn_prior_captures(model: nn.Module) -> None:
    model.last_category_2d_prior_logits = []
    model.last_category_2d_prior_probabilities = []
    model.last_category_2d_prior_prompt_indices = []
    probe = getattr(model, "category_2d_prior_probe", None)
    if probe is not None:
        probe.execution_count = 0


def _forward_pre_hook(model: nn.Module, _args: tuple[Any, ...]) -> None:
    reset_category_2d_noattn_prior_captures(model)
    model._category_2d_prior_prompt_cursor = 0


def _decoder_forward_with_noattn_prior(
    self: nn.Module,
    skips: List[torch.Tensor],
    mask_embeddings: List[torch.Tensor],
) -> List[torch.Tensor]:
    owner = self._category_2d_noattn_prior_owner
    probe = owner.category_2d_prior_probe
    prompt_index = int(getattr(owner, "_category_2d_prior_prompt_cursor", 0))
    owner._category_2d_prior_prompt_cursor = prompt_index + 1
    lres_input = skips[-1]
    seg_outputs: list[torch.Tensor] = []
    reversed_embeddings = mask_embeddings[::-1]
    half_latent = None
    for stage_idx in range(len(self.stages)):
        previous = self.transpconvs[stage_idx](lres_input)
        native_skip = skips[-(stage_idx + 2)]
        stage_input = torch.cat((previous, native_skip), dim=1)
        if stage_idx == probe.half_stage_index:
            half_latent = probe.dense_prior_head.half_latent(stage_input)
            probe.feature_audit["half_stage_input"] = list(stage_input.shape)
        if stage_idx == probe.full_stage_index:
            if half_latent is None:
                raise RuntimeError("No-attention prior missed half-resolution feature")
            q_logits = probe.dense_prior_head.full_logits(
                half_latent, previous, native_skip
            )
            owner.last_category_2d_prior_logits.append(q_logits)
            owner.last_category_2d_prior_probabilities.append(q_logits.sigmoid())
            owner.last_category_2d_prior_prompt_indices.append(prompt_index)
            probe.execution_count += 1
            probe.feature_audit["full_previous"] = list(previous.shape)
            probe.feature_audit["full_native_skip"] = list(native_skip.shape)
            probe.feature_audit["prior_logits"] = list(q_logits.shape)
        x = self.stages[stage_idx](stage_input)
        if stage_idx == len(self.stages) - 1:
            seg_pred = torch.einsum(
                "b c h w d, b n c -> b n h w d", x, reversed_embeddings[-1]
            )
            if getattr(self, "capture_native_response_maps", False):
                self.last_native_final_logits.append(seg_pred)
            seg_outputs.append(seg_pred)
        elif stage_idx >= len(self.stages) - len(reversed_embeddings):
            embedding = reversed_embeddings.pop(0)
            batch_size, _, channels = embedding.shape
            reshaped = embedding.view(batch_size, self.num_heads, -1)
            fusion = torch.einsum(
                "b c h w d, b n c -> b n h w d", x, reshaped
            )
            if (
                getattr(self, "capture_native_response_maps", False)
                and stage_idx == len(self.stages) - 2
            ):
                self.last_native_response_maps.append(fusion)
            x = torch.cat((x, fusion), dim=1)
            seg_outputs.append(self.seg_layers[stage_idx](x))
        lres_input = x
    seg_outputs = seg_outputs[::-1]
    return seg_outputs if self.deep_supervision else seg_outputs[:1]


def attach_category_2d_noattn_prior_probe(model: nn.Module) -> nn.Module:
    forbidden = [
        "enable_prompt_spatial_attention",
        "enable_s2_attention",
        "enable_s3_voxel_text_matching_attention",
    ]
    if any(bool(getattr(model, name, False)) for name in forbidden):
        raise RuntimeError("No-attention prior probe refuses an attention-enabled model")
    if getattr(model, "category_2d_prior_probe", None) is None:
        model.category_2d_prior_probe = Category2dNoAttentionPriorProbe(model)
    decoder = model.decoder
    object.__setattr__(decoder, "_category_2d_noattn_prior_owner", model)
    if not hasattr(decoder, "_category_2d_noattn_original_forward"):
        object.__setattr__(decoder, "_category_2d_noattn_original_forward", decoder.forward)
        decoder.forward = types.MethodType(_decoder_forward_with_noattn_prior, decoder)
    if getattr(model, "_category_2d_noattn_prior_hook", None) is None:
        object.__setattr__(
            model,
            "_category_2d_noattn_prior_hook",
            model.register_forward_pre_hook(_forward_pre_hook),
        )
    reset_category_2d_noattn_prior_captures(model)
    return model
