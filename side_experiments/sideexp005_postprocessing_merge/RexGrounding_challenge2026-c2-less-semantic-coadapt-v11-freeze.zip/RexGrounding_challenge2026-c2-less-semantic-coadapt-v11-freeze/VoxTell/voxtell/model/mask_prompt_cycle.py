"""Predicted-mask ROI to prompt-embedding reconstruction for VoxTell."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import torch
import torch.nn.functional as F
from torch import nn


@dataclass
class CycleOutput:
    logits: torch.Tensor | list[torch.Tensor]
    primary_logits: torch.Tensor
    reconstructed: torch.Tensor
    target_embeddings: torch.Tensor
    roi_features: torch.Tensor
    pooling_mask: torch.Tensor
    alpha: float


def curriculum_alpha(
    update: int,
    *,
    gt_to_half_end: int = 50,
    half_to_pred_end: int = 150,
) -> float:
    """Piecewise-linear GT-to-predicted-mask curriculum."""
    if update <= gt_to_half_end:
        return 1.0 - 0.5 * max(update, 0) / max(gt_to_half_end, 1)
    if update <= half_to_pred_end:
        span = max(half_to_pred_end - gt_to_half_end, 1)
        return 0.5 * (half_to_pred_end - update) / span
    return 0.0


class MaskPromptCycle(nn.Module):
    """Auxiliary branch whose only input is mask-selected image evidence."""

    def __init__(
        self,
        voxtell: nn.Module,
        *,
        source_layer: int = 4,
        source_channels: int = 320,
        target_dim: int = 2560,
        hidden_dim: int = 1024,
        epsilon: float = 1e-6,
        curriculum_gt_to_half_end: int = 50,
        curriculum_half_to_pred_end: int = 150,
    ) -> None:
        super().__init__()
        self.voxtell = voxtell
        self.source_layer = int(source_layer)
        self.epsilon = float(epsilon)
        self.curriculum_gt_to_half_end = int(curriculum_gt_to_half_end)
        self.curriculum_half_to_pred_end = int(curriculum_half_to_pred_end)
        self.reconstruction_head = nn.Sequential(
            nn.LayerNorm(source_channels),
            nn.Linear(source_channels, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, target_dim),
        )
        self._last_skips: Sequence[torch.Tensor] | None = None
        self._hook = self.voxtell.encoder.register_forward_hook(self._capture_skips)

    def _capture_skips(self, _module, _inputs, output) -> None:
        self._last_skips = output

    @staticmethod
    def primary(logits: torch.Tensor | list[torch.Tensor]) -> torch.Tensor:
        return logits[0] if isinstance(logits, list) else logits

    def image_feature(self) -> torch.Tensor:
        if self._last_skips is None:
            raise RuntimeError("VoxTell encoder hook did not capture image features")
        feature = self._last_skips[self.source_layer]
        if feature.ndim != 5:
            raise ValueError(f"Expected 5D image feature, got {tuple(feature.shape)}")
        return feature

    def reconstruct_from_mask(
        self,
        image_feature: torch.Tensor,
        pooling_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if pooling_mask.shape[0] != image_feature.shape[0]:
            raise ValueError("Image feature and pooling mask batch sizes differ")
        resized = F.interpolate(
            pooling_mask.float(),
            size=image_feature.shape[2:],
            mode="trilinear",
            align_corners=False,
        )
        numerator = torch.einsum("bndhw,bcdhw->bnc", resized, image_feature)
        denominator = resized.sum(dim=(2, 3, 4)).unsqueeze(-1).clamp_min(self.epsilon)
        roi = numerator / denominator
        reconstructed = F.normalize(self.reconstruction_head(roi), dim=-1, eps=1e-6)
        return reconstructed, roi

    def forward(
        self,
        image: torch.Tensor,
        text_embeddings: torch.Tensor,
        target_masks: torch.Tensor,
        *,
        update: int,
        force_alpha: float | None = None,
    ) -> CycleOutput:
        self._last_skips = None
        logits = self.voxtell(image, text_embeddings)
        primary_logits = self.primary(logits)
        probability = primary_logits.sigmoid()
        alpha = (
            curriculum_alpha(
                update,
                gt_to_half_end=self.curriculum_gt_to_half_end,
                half_to_pred_end=self.curriculum_half_to_pred_end,
            )
            if force_alpha is None
            else float(force_alpha)
        )
        if not 0.0 <= alpha <= 1.0:
            raise ValueError(f"Cycle curriculum alpha must be in [0,1], got {alpha}")
        pooling_mask = alpha * target_masks.float() + (1.0 - alpha) * probability
        reconstructed, roi = self.reconstruct_from_mask(self.image_feature(), pooling_mask)
        target_embeddings = F.normalize(
            text_embeddings.squeeze(2).detach().float(), dim=-1, eps=1e-6
        )
        return CycleOutput(
            logits=logits,
            primary_logits=primary_logits,
            reconstructed=reconstructed,
            target_embeddings=target_embeddings,
            roi_features=roi,
            pooling_mask=pooling_mask,
            alpha=alpha,
        )


def same_case_cycle_loss(
    reconstructed: torch.Tensor,
    target_embeddings: torch.Tensor,
    target_masks: torch.Tensor,
    prompt_texts: Sequence[Sequence[str]],
    source_cases: Sequence[Sequence[str]],
    *,
    temperature: float = 0.07,
) -> tuple[torch.Tensor, dict[str, float | int]]:
    """InfoNCE over prompts, prioritizing nonduplicate same-case candidates."""
    if reconstructed.shape != target_embeddings.shape:
        raise ValueError(
            f"Reconstruction/target shape mismatch: {reconstructed.shape} != "
            f"{target_embeddings.shape}"
        )
    positive = target_masks.flatten(start_dim=2).any(dim=2)
    losses: list[torch.Tensor] = []
    correct_similarities: list[torch.Tensor] = []
    hardest_margins: list[torch.Tensor] = []
    top1: list[float] = []
    same_case_top1: list[float] = []
    same_case_count = 0

    for batch_idx in range(reconstructed.shape[0]):
        prompts = [str(value).strip().lower() for value in prompt_texts[batch_idx]]
        cases = [str(value) for value in source_cases[batch_idx]]
        for prompt_idx in torch.nonzero(positive[batch_idx], as_tuple=False).flatten().tolist():
            candidate_indices = [
                idx
                for idx in range(reconstructed.shape[1])
                if idx == prompt_idx or prompts[idx] != prompts[prompt_idx]
            ]
            if len(candidate_indices) < 2:
                continue
            candidate = torch.as_tensor(
                candidate_indices, device=reconstructed.device, dtype=torch.long
            )
            similarities = reconstructed[batch_idx, prompt_idx] @ target_embeddings[
                batch_idx, candidate
            ].T
            target_position = candidate_indices.index(prompt_idx)
            losses.append(
                F.cross_entropy(
                    (similarities / temperature).unsqueeze(0),
                    torch.tensor([target_position], device=reconstructed.device),
                )
            )
            correct = similarities[target_position]
            negatives = torch.cat(
                (similarities[:target_position], similarities[target_position + 1 :])
            )
            correct_similarities.append(correct)
            hardest_margins.append(correct - negatives.max())
            top1.append(float(int(similarities.argmax().item()) == target_position))

            same_indices = [
                idx
                for idx in candidate_indices
                if idx == prompt_idx or cases[idx] == cases[prompt_idx]
            ]
            if len(same_indices) > 1:
                same_case_count += 1
                same_candidate = torch.as_tensor(
                    same_indices, device=reconstructed.device, dtype=torch.long
                )
                same_sim = reconstructed[batch_idx, prompt_idx] @ target_embeddings[
                    batch_idx, same_candidate
                ].T
                same_case_top1.append(
                    float(int(same_sim.argmax().item()) == same_indices.index(prompt_idx))
                )

    if not losses:
        zero = reconstructed.sum() * 0.0
        return zero, {
            "cycle_items": 0,
            "cycle_top1": float("nan"),
            "same_case_items": 0,
            "same_case_top1": float("nan"),
            "cycle_margin": float("nan"),
            "correct_similarity": float("nan"),
        }
    return torch.stack(losses).mean(), {
        "cycle_items": len(losses),
        "cycle_top1": float(sum(top1) / len(top1)),
        "same_case_items": same_case_count,
        "same_case_top1": (
            float(sum(same_case_top1) / len(same_case_top1))
            if same_case_top1
            else float("nan")
        ),
        "cycle_margin": float(torch.stack(hardest_margins).detach().mean().item()),
        "correct_similarity": float(
            torch.stack(correct_similarities).detach().mean().item()
        ),
    }
