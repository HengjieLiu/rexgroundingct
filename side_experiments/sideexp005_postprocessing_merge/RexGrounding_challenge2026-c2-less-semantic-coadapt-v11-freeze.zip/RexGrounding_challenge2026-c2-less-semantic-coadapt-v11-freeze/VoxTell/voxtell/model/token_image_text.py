"""Token-level image-to-text attention used by the Phase-0 VoxTell pilot."""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import nn


class TokenImageToTextBlock(nn.Module):
    """Pre-norm image-query/text-key-value cross-attention with residual FFN.

    The explicit projections make the direction of attention auditable and avoid
    inheriting any weights from VoxTell's sentence-query transformer decoder.
    """

    def __init__(
        self,
        image_dim: int,
        text_dim: int,
        attention_dim: int = 2048,
        num_heads: int = 8,
        dropout: float = 0.1,
        init_seed: int = 260806,
        identity_init: bool = False,
        residual_output_init_scale: float = 1.0,
    ) -> None:
        super().__init__()
        if attention_dim % num_heads:
            raise ValueError("attention_dim must be divisible by num_heads")
        self.image_dim = int(image_dim)
        self.text_dim = int(text_dim)
        self.attention_dim = int(attention_dim)
        self.num_heads = int(num_heads)
        self.head_dim = self.attention_dim // self.num_heads
        self.scale = self.head_dim**-0.5

        # Module constructors perform their own default random initialization
        # before our explicit reset. Fork the CPU stream so even that discarded
        # initialization cannot perturb the experiment RNG used elsewhere.
        with torch.random.fork_rng(devices=[]):
            self.image_norm = nn.LayerNorm(self.image_dim)
            self.text_norm = nn.LayerNorm(self.text_dim)
            self.q_proj = nn.Linear(self.image_dim, self.attention_dim)
            self.k_proj = nn.Linear(self.text_dim, self.attention_dim)
            self.v_proj = nn.Linear(self.text_dim, self.attention_dim)
            self.out_proj = nn.Linear(self.attention_dim, self.image_dim)
            self.attention_dropout = float(dropout)
            self.output_dropout = nn.Dropout(dropout)
            self.ffn_norm = nn.LayerNorm(self.image_dim)
            self.ffn = nn.Sequential(
                nn.Linear(self.image_dim, 4 * self.image_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(4 * self.image_dim, self.image_dim),
            )
        self.capture_attention = False
        self.last_attention: torch.Tensor | None = None
        self.forward_count = 0
        self._reset_deterministically(init_seed)
        if identity_init:
            self.zero_initialize_residual_outputs()
        elif residual_output_init_scale != 1.0:
            self.scale_initialize_residual_outputs(residual_output_init_scale)

    def _reset_deterministically(self, seed: int) -> None:
        # A private CPU generator guarantees identical A1/A2 initialization and
        # does not perturb the experiment's sampler/model RNG stream.
        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(seed))
        for module in self.modules():
            if isinstance(module, nn.Linear):
                fan_in, fan_out = nn.init._calculate_fan_in_and_fan_out(module.weight)
                bound = math.sqrt(6.0 / (fan_in + fan_out))
                with torch.no_grad():
                    module.weight.uniform_(-bound, bound, generator=generator)
                    if module.bias is not None:
                        module.bias.zero_()
            elif isinstance(module, nn.LayerNorm):
                with torch.no_grad():
                    module.weight.fill_(1.0)
                    module.bias.zero_()

    def new_parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())

    def zero_initialize_residual_outputs(self) -> None:
        """Make the residual branch an exact identity at initialization.

        The block has two residual contributors: the attention output
        projection and the FFN's final projection.  Both must be zeroed for
        ``forward(image_tokens, ...)`` to return ``image_tokens`` exactly.
        """
        with torch.no_grad():
            self.out_proj.weight.zero_()
            if self.out_proj.bias is not None:
                self.out_proj.bias.zero_()
            final_ffn = self.ffn[-1]
            if not isinstance(final_ffn, nn.Linear):
                raise TypeError("Expected the final FFN module to be nn.Linear")
            final_ffn.weight.zero_()
            if final_ffn.bias is not None:
                final_ffn.bias.zero_()

    def scale_initialize_residual_outputs(self, scale: float) -> None:
        """Scale only the two residual-producing projections at initialization."""
        scale = float(scale)
        if not math.isfinite(scale) or scale < 0.0:
            raise ValueError("residual output initialization scale must be finite and non-negative")
        with torch.no_grad():
            self.out_proj.weight.mul_(scale)
            if self.out_proj.bias is not None:
                self.out_proj.bias.mul_(scale)
            final_ffn = self.ffn[-1]
            if not isinstance(final_ffn, nn.Linear):
                raise TypeError("Expected the final FFN module to be nn.Linear")
            final_ffn.weight.mul_(scale)
            if final_ffn.bias is not None:
                final_ffn.bias.mul_(scale)

    def forward(
        self,
        image_tokens: torch.Tensor,
        text_tokens: torch.Tensor,
        valid_token_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Condition ``[B,N_image,C]`` tokens on ``[B,N_text,H]`` tokens."""
        if image_tokens.ndim != 3 or text_tokens.ndim != 3:
            raise ValueError("image_tokens and text_tokens must both be rank three")
        if valid_token_mask.shape != text_tokens.shape[:2]:
            raise ValueError(
                "valid_token_mask must match text token axes: "
                f"{tuple(valid_token_mask.shape)} != {tuple(text_tokens.shape[:2])}"
            )
        if not bool(valid_token_mask.any(dim=1).all()):
            raise ValueError("Every prompt must contain at least one valid content token")

        batch, n_image, _ = image_tokens.shape
        n_text = text_tokens.shape[1]
        query = self.q_proj(self.image_norm(image_tokens))
        key = self.k_proj(self.text_norm(text_tokens))
        value = self.v_proj(self.text_norm(text_tokens))
        query = query.view(batch, n_image, self.num_heads, self.head_dim).transpose(1, 2)
        key = key.view(batch, n_text, self.num_heads, self.head_dim).transpose(1, 2)
        value = value.view(batch, n_text, self.num_heads, self.head_dim).transpose(1, 2)

        invalid = ~valid_token_mask.to(device=query.device, dtype=torch.bool)
        attention_mask = torch.zeros(
            (batch, 1, 1, n_text), device=query.device, dtype=query.dtype
        ).masked_fill(invalid[:, None, None], torch.finfo(query.dtype).min)
        if self.capture_attention:
            logits = torch.matmul(query, key.transpose(-2, -1)) * self.scale
            weights = torch.softmax(logits + attention_mask, dim=-1)
            if self.training and self.attention_dropout:
                applied = F.dropout(weights, p=self.attention_dropout)
            else:
                applied = weights
            attended = torch.matmul(applied, value)
            self.last_attention = weights.detach()
        else:
            attended = F.scaled_dot_product_attention(
                query,
                key,
                value,
                attn_mask=attention_mask,
                dropout_p=self.attention_dropout if self.training else 0.0,
            )
            self.last_attention = None
        attended = attended.transpose(1, 2).reshape(batch, n_image, self.attention_dim)
        output = image_tokens + self.output_dropout(self.out_proj(attended))
        output = output + self.output_dropout(self.ffn(self.ffn_norm(output)))
        self.forward_count += 1
        return output
