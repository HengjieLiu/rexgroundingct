"""Baseline-preserving token-to-spatial conditioning for a 3-D encoder stage."""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import nn


class EncoderTokenSpatialConditioning3D(nn.Module):
    """Image-query/text-key-value attention with a zero-initialized connector.

    Unlike the discarded EP scalar-gamma gate, only ``out_proj`` is initialized
    to zero. It therefore gets a gradient at the identity point. Q/K/V become
    trainable as soon as the connector leaves zero after the first optimizer
    update, while construction remains an exact residual identity.
    """

    def __init__(
        self,
        image_dim: int,
        text_dim: int,
        attention_dim: int = 256,
        num_heads: int = 8,
        dropout: float = 0.0,
        init_seed: int = 260812,
        connector_type: str = "dense",
        connector_init_scale: float = 5e-4,
    ) -> None:
        super().__init__()
        if attention_dim <= 0 or attention_dim % num_heads:
            raise ValueError("attention_dim must be positive and divisible by num_heads")
        self.image_dim = int(image_dim)
        self.text_dim = int(text_dim)
        self.attention_dim = int(attention_dim)
        self.num_heads = int(num_heads)
        self.head_dim = self.attention_dim // self.num_heads
        self.scale = self.head_dim**-0.5
        self.attention_dropout = float(dropout)
        if connector_type not in {"dense", "direct", "diagonal"}:
            raise ValueError("connector_type must be dense, direct, or diagonal")
        if connector_type in {"direct", "diagonal"} and self.attention_dim != self.image_dim:
            raise ValueError("Spatial-preserving connectors require attention_dim == image_dim")
        if connector_init_scale <= 0:
            raise ValueError("connector_init_scale must be positive to avoid a dead branch")
        self.connector_type = str(connector_type)
        self.connector_init_scale = float(connector_init_scale)
        with torch.random.fork_rng(devices=[]):
            self.image_norm = nn.LayerNorm(self.image_dim)
            self.text_norm = nn.LayerNorm(self.text_dim)
            self.q_proj = nn.Linear(self.image_dim, self.attention_dim)
            self.k_proj = nn.Linear(self.text_dim, self.attention_dim)
            self.v_proj = nn.Linear(self.text_dim, self.attention_dim)
            self.out_proj = nn.Linear(self.attention_dim, self.image_dim)
            self.alpha = nn.Parameter(torch.tensor(float(connector_init_scale))) if connector_type == "direct" else None
            self.channel_gain = nn.Parameter(torch.full((self.image_dim,), float(connector_init_scale))) if connector_type == "diagonal" else None
        self.forward_count = 0
        self.last_attention: torch.Tensor | None = None
        self.last_delta: torch.Tensor | None = None
        self.last_audit: dict[str, object] = {}
        self._reset_deterministically(init_seed)

    def _reset_deterministically(self, seed: int) -> None:
        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(seed))
        with torch.no_grad():
            self.image_norm.weight.fill_(1.0)
            self.image_norm.bias.zero_()
            self.text_norm.weight.fill_(1.0)
            self.text_norm.bias.zero_()
            for linear in (self.q_proj, self.k_proj, self.v_proj):
                fan_in, fan_out = nn.init._calculate_fan_in_and_fan_out(linear.weight)
                bound = math.sqrt(6.0 / (fan_in + fan_out))
                linear.weight.uniform_(-bound, bound, generator=generator)
                linear.bias.zero_()
            # Dense reference remains exact identity at startup. Direct and
            # diagonal variants deliberately use a tiny nonzero connector so
            # Q/K/V receive gradients on their first optimizer update.
            self.out_proj.weight.zero_()
            self.out_proj.bias.zero_()

    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())

    def forward(
        self,
        image_feature: torch.Tensor,
        text_tokens: torch.Tensor,
        valid_token_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if image_feature.ndim != 5:
            raise ValueError("image_feature must be [B,C,D,H,W]")
        if text_tokens.ndim != 4:
            raise ValueError("text_tokens must be [B,P,T,H]")
        if valid_token_mask.shape != text_tokens.shape[:3]:
            raise ValueError("valid_token_mask must match [B,P,T]")
        batch, channels, depth, height, width = image_feature.shape
        if channels != self.image_dim or text_tokens.shape[-1] != self.text_dim:
            raise ValueError("Unexpected image/text channel dimensions")
        prompts, n_text = text_tokens.shape[1:3]
        if not bool(valid_token_mask.any(dim=-1).all()):
            raise ValueError("Every prompt requires at least one valid text token")

        image_tokens = image_feature.permute(0, 2, 3, 4, 1).reshape(
            batch, depth * height * width, channels
        )
        n_image = image_tokens.shape[1]
        image_tokens = image_tokens[:, None].expand(batch, prompts, n_image, channels)
        flat_image = image_tokens.reshape(batch * prompts, n_image, channels)
        flat_text = text_tokens.reshape(batch * prompts, n_text, self.text_dim)
        flat_valid = valid_token_mask.reshape(batch * prompts, n_text).to(torch.bool)

        query = self.q_proj(self.image_norm(flat_image)).view(
            batch * prompts, n_image, self.num_heads, self.head_dim
        ).transpose(1, 2)
        normalized_text = self.text_norm(flat_text)
        key = self.k_proj(normalized_text).view(
            batch * prompts, n_text, self.num_heads, self.head_dim
        ).transpose(1, 2)
        value = self.v_proj(normalized_text).view(
            batch * prompts, n_text, self.num_heads, self.head_dim
        ).transpose(1, 2)
        invalid = ~flat_valid.to(device=query.device)
        attention_mask = torch.zeros(
            (batch * prompts, 1, 1, n_text), device=query.device, dtype=query.dtype
        ).masked_fill(invalid[:, None, None], torch.finfo(query.dtype).min)
        attended = F.scaled_dot_product_attention(
            query, key, value, attn_mask=attention_mask,
            dropout_p=self.attention_dropout if self.training else 0.0,
        )
        attended = attended.transpose(1, 2).reshape(
            batch * prompts, n_image, self.attention_dim
        )
        if self.connector_type == "dense":
            delta = self.out_proj(attended)
        elif self.connector_type == "direct":
            assert self.alpha is not None
            delta = self.alpha * attended
        else:
            assert self.channel_gain is not None
            delta = attended * self.channel_gain[None, None]
        conditioned = flat_image + delta
        delta_image = delta.reshape(batch, prompts, depth, height, width, channels).permute(
            0, 1, 5, 2, 3, 4
        )
        delta_float = delta.detach().float()
        image_float = flat_image.detach().float()
        self.last_delta = delta_image.detach()
        self.last_audit = {
            "image_tokens": int(n_image),
            "valid_text_tokens_min": int(flat_valid.sum(dim=-1).min().item()),
            "valid_text_tokens_max": int(flat_valid.sum(dim=-1).max().item()),
            "token_feature_shape": list(text_tokens.shape),
            "q_shape": list(query.shape),
            "k_shape": list(key.shape),
            "v_shape": list(value.shape),
            "attention_output_shape": list(attended.shape),
            "zero_connector_output_shape": list(delta.shape),
            "connector_type": self.connector_type,
            "connector_init_scale": self.connector_init_scale,
            "residual_to_feature_norm": float(
                (delta_float.norm(dim=-1) / image_float.norm(dim=-1).clamp_min(1e-12))
                .mean().item()
            ),
            "max_conditioned_minus_base": float(delta_float.abs().amax().item()),
        }
        if self.alpha is not None:
            self.last_audit["alpha"] = float(self.alpha.detach().float().item())
        if self.channel_gain is not None:
            gain = self.channel_gain.detach().float()
            self.last_audit.update({"gain_mean_absolute": float(gain.abs().mean()), "gain_max": float(gain.max()), "gain_min": float(gain.min()), "gain_absolute_cv": float(gain.abs().std(unbiased=False) / gain.abs().mean().clamp_min(1e-12))})
        self.forward_count += 1
        conditioned = conditioned.reshape(batch, prompts, depth, height, width, channels).permute(
            0, 1, 5, 2, 3, 4
        )
        return conditioned.reshape(batch * prompts, channels, depth, height, width), delta_image
