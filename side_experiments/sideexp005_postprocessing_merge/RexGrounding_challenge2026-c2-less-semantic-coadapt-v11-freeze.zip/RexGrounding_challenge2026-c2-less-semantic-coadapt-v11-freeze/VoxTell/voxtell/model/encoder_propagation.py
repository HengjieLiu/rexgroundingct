"""Token-conditioned 1/8 encoder propagation for the EP-1/8 pilot.

This module is intentionally independent of both the Phase-0 bottleneck
Image-to-Text block and the S3 decoder skip gates.
"""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import nn


class EncoderPropagationCrossAttention(nn.Module):
    """Image-query/text-key-value attention with a zero scalar residual gate."""

    def __init__(
        self,
        image_dim: int,
        text_dim: int,
        attention_dim: int = 2048,
        num_heads: int = 8,
        dropout: float = 0.1,
        init_seed: int = 260810,
    ) -> None:
        super().__init__()
        if attention_dim % num_heads:
            raise ValueError("attention_dim must be divisible by num_heads")
        self.image_dim = int(image_dim)
        self.text_dim = int(text_dim)
        self.attention_dim = int(attention_dim)
        self.num_heads = int(num_heads)
        self.head_dim = self.attention_dim // self.num_heads
        self.scale = self.head_dim**-0.5
        self.attention_dropout = float(dropout)

        # Isolate discarded constructor initialization and the explicit pilot
        # initialization from the experiment's model/sampler RNG streams.
        with torch.random.fork_rng(devices=[]):
            self.image_norm = nn.LayerNorm(self.image_dim)
            self.text_norm = nn.LayerNorm(self.text_dim)
            self.q_proj = nn.Linear(self.image_dim, self.attention_dim)
            self.k_proj = nn.Linear(self.text_dim, self.attention_dim)
            self.v_proj = nn.Linear(self.text_dim, self.attention_dim)
            self.out_proj = nn.Linear(self.attention_dim, self.image_dim)
        self.gamma = nn.Parameter(torch.zeros(()))
        self.capture_attention = False
        self.last_attention: torch.Tensor | None = None
        self.last_delta: torch.Tensor | None = None
        self.forward_count = 0
        self._reset_deterministically(init_seed)

    def _reset_deterministically(self, seed: int) -> None:
        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(seed))
        for module in self.modules():
            if isinstance(module, nn.Linear):
                fan_in, fan_out = nn.init._calculate_fan_in_and_fan_out(module.weight)
                bound = math.sqrt(6.0 / (fan_in + fan_out))
                with torch.no_grad():
                    module.weight.uniform_(-bound, bound, generator=generator)
                    if module.bias is not None:
                        module.bias.zero_()
            elif isinstance(module, nn.LayerNorm):
                with torch.no_grad():
                    module.weight.fill_(1.0)
                    module.bias.zero_()

    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())

    def forward(
        self,
        image_tokens: torch.Tensor,
        text_tokens: torch.Tensor,
        valid_token_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if image_tokens.ndim != 3 or text_tokens.ndim != 3:
            raise ValueError("image_tokens and text_tokens must be rank three")
        if image_tokens.shape[-1] != self.image_dim:
            raise ValueError(
                f"Expected {self.image_dim} image channels, got {image_tokens.shape[-1]}"
            )
        if text_tokens.shape[-1] != self.text_dim:
            raise ValueError(
                f"Expected {self.text_dim} text channels, got {text_tokens.shape[-1]}"
            )
        if valid_token_mask.shape != text_tokens.shape[:2]:
            raise ValueError("valid_token_mask must match the text token axes")
        if not bool(valid_token_mask.any(dim=1).all()):
            raise ValueError("Every prompt must contain at least one valid token")

        batch, n_image, _ = image_tokens.shape
        n_text = text_tokens.shape[1]
        query = self.q_proj(self.image_norm(image_tokens))
        normalized_text = self.text_norm(text_tokens)
        key = self.k_proj(normalized_text)
        value = self.v_proj(normalized_text)
        query = query.view(batch, n_image, self.num_heads, self.head_dim).transpose(1, 2)
        key = key.view(batch, n_text, self.num_heads, self.head_dim).transpose(1, 2)
        value = value.view(batch, n_text, self.num_heads, self.head_dim).transpose(1, 2)

        invalid = ~valid_token_mask.to(device=query.device, dtype=torch.bool)
        attention_mask = torch.zeros(
            (batch, 1, 1, n_text), device=query.device, dtype=query.dtype
        ).masked_fill(invalid[:, None, None], torch.finfo(query.dtype).min)
        if self.capture_attention:
            weights = torch.softmax(
                torch.matmul(query, key.transpose(-2, -1)) * self.scale
                + attention_mask,
                dim=-1,
            )
            applied = (
                F.dropout(weights, p=self.attention_dropout)
                if self.training and self.attention_dropout
                else weights
            )
            attended = torch.matmul(applied, value)
            self.last_attention = weights.detach()
        else:
            attended = F.scaled_dot_product_attention(
                query,
                key,
                value,
                attn_mask=attention_mask,
                dropout_p=self.attention_dropout if self.training else 0.0,
            )
            self.last_attention = None
        attended = attended.transpose(1, 2).reshape(batch, n_image, self.attention_dim)
        delta = self.out_proj(attended)
        conditioned = image_tokens + self.gamma.to(image_tokens.dtype) * delta
        self.last_delta = delta.detach()
        self.forward_count += 1
        return conditioned, delta
