"""Native-weight staged execution for 12-layer BERT text towers.

This does not reimplement BERT.  It calls the exact embedding module and exact
``BertLayer`` objects held by a loaded Hugging Face BERT model, but exposes the
five MedPlex groups.  With no inter-stage modification it is numerically the
same operation as ``BertModel.forward`` in evaluation mode.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import torch
from torch import nn
from transformers.modeling_attn_mask_utils import _prepare_4d_attention_mask_for_sdpa


STAGE_BOUNDARIES: tuple[int, ...] = (1, 6, 8, 10, 12)


@dataclass(frozen=True)
class StagedBertState:
    """Full token state and its original BERT attention context."""

    hidden: torch.Tensor
    attention_mask: torch.Tensor
    token_type_ids: torch.Tensor | None
    position_ids: torch.Tensor | None


class StagedBert(nn.Module):
    """Advance a standard 12-layer Hugging Face ``BertModel`` by MedPlex stage.

    ``backbone`` may be a ``BertModel`` directly or an object exposing it under
    ``.bert``.  The wrapper deliberately retains the underlying module rather
    than copying its parameters, so the trainable tower is checkpointed exactly
    once by the owning experiment model.
    """

    def __init__(self, backbone: nn.Module, boundaries: Sequence[int] = STAGE_BOUNDARIES) -> None:
        super().__init__()
        base = getattr(backbone, "bert", backbone)
        if not all(hasattr(base, item) for item in ("embeddings", "encoder", "get_extended_attention_mask")):
            raise TypeError("StagedBert requires a Hugging Face BertModel-compatible backbone")
        if not hasattr(base.encoder, "layer"):
            raise TypeError("BERT backbone lacks encoder.layer")
        self.backbone = base
        self.boundaries = tuple(int(value) for value in boundaries)
        if self.boundaries != STAGE_BOUNDARIES:
            raise ValueError(f"This experiment requires MedPlex boundaries {STAGE_BOUNDARIES}, got {self.boundaries}")
        if len(base.encoder.layer) != self.boundaries[-1]:
            raise ValueError(
                f"Expected a 12-layer BERT, found {len(base.encoder.layer)} layers"
            )
        if int(base.config.hidden_size) != 768:
            raise ValueError(f"Expected 768-D BERT states, found {base.config.hidden_size}")

    @property
    def hidden_size(self) -> int:
        return int(self.backbone.config.hidden_size)

    def _extended_mask(self, mask: torch.Tensor, hidden: torch.Tensor) -> torch.Tensor:
        # Mirror BertModel.forward exactly.  Passing the generic additive mask
        # instead of this SDPA-specific mask changes the attention kernel and
        # measurably breaks the staged-vs-native identity check in BF16.
        if (
            getattr(self.backbone, "attn_implementation", None) == "sdpa"
            and getattr(self.backbone, "position_embedding_type", None) == "absolute"
            and mask.ndim == 2
        ):
            return _prepare_4d_attention_mask_for_sdpa(mask, hidden.dtype, tgt_len=hidden.shape[1])
        return self.backbone.get_extended_attention_mask(mask, hidden.shape[:2], hidden.device)

    def _run_layers(self, stage: int, hidden: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        if not 0 <= stage < len(self.boundaries):
            raise ValueError(f"stage must be in [0,{len(self.boundaries)}), got {stage}")
        extended_mask = self._extended_mask(mask, hidden)
        start = 0 if stage == 0 else self.boundaries[stage - 1]
        end = self.boundaries[stage]
        for layer in self.backbone.encoder.layer[start:end]:
            hidden = layer(hidden, attention_mask=extended_mask, output_attentions=False)[0]
        return hidden

    def stage0(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: torch.Tensor | None = None,
        position_ids: torch.Tensor | None = None,
    ) -> StagedBertState:
        if input_ids.ndim != 2 or attention_mask.shape != input_ids.shape:
            raise ValueError("input_ids and attention_mask must both be [B,L]")
        embeddings = self.backbone.embeddings(
            input_ids=input_ids,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
        )
        return StagedBertState(
            hidden=self._run_layers(0, embeddings, attention_mask),
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
        )

    def advance(self, stage: int, state: StagedBertState) -> StagedBertState:
        if stage == 0:
            raise ValueError("Use stage0() to execute stage 0")
        return StagedBertState(
            hidden=self._run_layers(stage, state.hidden, state.attention_mask),
            attention_mask=state.attention_mask,
            token_type_ids=state.token_type_ids,
            position_ids=state.position_ids,
        )

    def full_staged(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: torch.Tensor | None = None,
        position_ids: torch.Tensor | None = None,
    ) -> StagedBertState:
        state = self.stage0(input_ids, attention_mask, token_type_ids, position_ids)
        for stage in range(1, len(self.boundaries)):
            state = self.advance(stage, state)
        return state
