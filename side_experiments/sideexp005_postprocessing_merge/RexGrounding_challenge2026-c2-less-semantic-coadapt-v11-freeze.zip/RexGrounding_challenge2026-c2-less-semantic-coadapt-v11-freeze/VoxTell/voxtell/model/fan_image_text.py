"""FAN-inspired hierarchical image/word fusion for VoxTell pilots."""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from einops import rearrange
from positional_encodings.torch_encodings import PositionalEncoding3D
from torch import nn


class FANPreActivationImageWordBlock3D(nn.Module):
    """FAN-style pre-VPM Image-to-Word activation for one 3-D feature level.

    This is intentionally separate from :class:`FANImageWordFusionBlock3D`.
    It creates the activated visual tokens consumed by the existing VPM body;
    it is not a Preserve/writeback projection.
    """

    def __init__(
        self,
        *,
        visual_dim: int,
        text_dim: int,
        multimodal_dim: int,
        num_heads: int,
        spatial_shape: tuple[int, int, int],
        dropout: float = 0.1,
        init_seed: int = 260821,
        residual_scale: float = 1e-3,
    ) -> None:
        super().__init__()
        if multimodal_dim % num_heads:
            raise ValueError("multimodal_dim must be divisible by num_heads")
        self.visual_dim = int(visual_dim)
        self.text_dim = int(text_dim)
        self.multimodal_dim = int(multimodal_dim)
        self.num_heads = int(num_heads)
        self.spatial_shape = tuple(map(int, spatial_shape))
        self.residual_scale = float(residual_scale)
        with torch.random.fork_rng(devices=[]):
            self.visual_norm = nn.LayerNorm(self.visual_dim)
            self.text_norm = nn.LayerNorm(self.text_dim)
            self.visual_projection = nn.Linear(self.visual_dim, self.multimodal_dim)
            self.text_projection = nn.Linear(self.text_dim, self.multimodal_dim)
            self.query_norm = nn.LayerNorm(self.multimodal_dim)
            self.text_key_value_norm = nn.LayerNorm(self.multimodal_dim)
            self.cross_attention = nn.MultiheadAttention(
                self.multimodal_dim, self.num_heads, dropout=dropout, batch_first=True
            )
            self.dropout = nn.Dropout(dropout)
            self.output_norm = nn.LayerNorm(self.multimodal_dim)
            self.output_projection = nn.Linear(self.multimodal_dim, self.visual_dim)
        position = PositionalEncoding3D(self.multimodal_dim)(
            torch.zeros(1, *self.spatial_shape, self.multimodal_dim)
        )
        self.register_buffer(
            "visual_position",
            rearrange(position, "1 d h w c -> 1 (d h w) c"),
            persistent=True,
        )
        self._reset_deterministically(init_seed)
        self.last_audit: dict[str, object] = {}

    def _reset_deterministically(self, seed: int) -> None:
        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(seed))
        with torch.no_grad():
            for module in self.modules():
                if isinstance(module, nn.LayerNorm):
                    module.weight.fill_(1.0)
                    module.bias.zero_()
                elif isinstance(module, nn.Linear):
                    nn.init.xavier_uniform_(module.weight, generator=generator)
                    module.bias.zero_()
                elif isinstance(module, nn.MultiheadAttention):
                    nn.init.xavier_uniform_(module.in_proj_weight, generator=generator)
                    module.in_proj_bias.zero_()
                    nn.init.xavier_uniform_(module.out_proj.weight, generator=generator)
                    module.out_proj.bias.zero_()

    def forward(
        self,
        visual_tokens: torch.Tensor,
        text_tokens: torch.Tensor,
        valid_token_mask: torch.Tensor,
    ) -> torch.Tensor:
        if visual_tokens.ndim != 3 or text_tokens.ndim != 3:
            raise ValueError("pre-activation visual/text tokens must be rank three")
        if visual_tokens.shape[-1] != self.visual_dim or text_tokens.shape[-1] != self.text_dim:
            raise ValueError("pre-activation feature dimensions do not match")
        if valid_token_mask.shape != text_tokens.shape[:2]:
            raise ValueError("pre-activation valid-token mask has the wrong shape")
        batch, n_image, _ = visual_tokens.shape
        if n_image != math.prod(self.spatial_shape):
            raise ValueError("pre-activation visual token count does not match its scale")
        visual = self.visual_projection(self.visual_norm(visual_tokens))
        visual = visual + self.visual_position.to(dtype=visual.dtype)
        text = self.text_projection(self.text_norm(text_tokens))
        delta, _ = self.cross_attention(
            self.query_norm(visual),
            self.text_key_value_norm(text),
            self.text_key_value_norm(text),
            key_padding_mask=~valid_token_mask.to(dtype=torch.bool),
            need_weights=False,
        )
        activated_shared = visual + self.dropout(delta)
        activated = self.output_projection(self.output_norm(activated_shared))
        # This is a bounded startup bridge into an otherwise Direct FAN path,
        # not a Preserve concatenation projection.  The VPM never sees raw V.
        output = visual_tokens + self.residual_scale * (activated - visual_tokens)
        self.last_audit = {
            "n_image": int(n_image),
            "n_text": int(text_tokens.shape[1]),
            "attention_shape": [batch, self.num_heads, n_image, int(text_tokens.shape[1])],
            "residual_scale": self.residual_scale,
        }
        return output


class FANImageWordFusionBlock3D(nn.Module):
    """Joint multimodal self-attention followed by Image-to-Word attention.

    The block transforms a visual feature rather than adding an independently
    gated external branch. Residual connections are internal Transformer
    residuals in the shared multimodal space.
    """

    def __init__(
        self,
        *,
        visual_dim: int,
        text_dim: int,
        multimodal_dim: int,
        num_heads: int,
        spatial_shape: tuple[int, int, int],
        dropout: float = 0.1,
        init_seed: int = 260812,
    ) -> None:
        super().__init__()
        if multimodal_dim % num_heads:
            raise ValueError("multimodal_dim must be divisible by num_heads")
        if any(int(size) <= 0 for size in spatial_shape):
            raise ValueError("spatial_shape values must be positive")
        self.visual_dim = int(visual_dim)
        self.text_dim = int(text_dim)
        self.multimodal_dim = int(multimodal_dim)
        self.num_heads = int(num_heads)
        self.spatial_shape = tuple(map(int, spatial_shape))

        # Keep construction and explicit initialization private to the module so
        # adding this arm cannot perturb the common sampler/model RNG stream.
        with torch.random.fork_rng(devices=[]):
            self.visual_norm = nn.LayerNorm(self.visual_dim)
            self.text_norm = nn.LayerNorm(self.text_dim)
            self.visual_projection = nn.Linear(self.visual_dim, self.multimodal_dim)
            self.text_projection = nn.Linear(self.text_dim, self.multimodal_dim)
            self.joint_norm = nn.LayerNorm(self.multimodal_dim)
            self.joint_attention = nn.MultiheadAttention(
                self.multimodal_dim,
                self.num_heads,
                dropout=dropout,
                batch_first=True,
            )
            self.joint_dropout = nn.Dropout(dropout)
            self.joint_ffn_norm = nn.LayerNorm(self.multimodal_dim)
            self.joint_ffn = nn.Sequential(
                nn.Linear(self.multimodal_dim, 4 * self.multimodal_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(4 * self.multimodal_dim, self.multimodal_dim),
            )
            self.cross_query_norm = nn.LayerNorm(self.multimodal_dim)
            self.cross_text_norm = nn.LayerNorm(self.multimodal_dim)
            self.cross_attention = nn.MultiheadAttention(
                self.multimodal_dim,
                self.num_heads,
                dropout=dropout,
                batch_first=True,
            )
            self.cross_dropout = nn.Dropout(dropout)
            self.cross_ffn_norm = nn.LayerNorm(self.multimodal_dim)
            self.cross_ffn = nn.Sequential(
                nn.Linear(self.multimodal_dim, 4 * self.multimodal_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(4 * self.multimodal_dim, self.multimodal_dim),
            )
            self.output_norm = nn.LayerNorm(self.multimodal_dim)
            self.output_projection = nn.Linear(self.multimodal_dim, self.visual_dim)

        position = PositionalEncoding3D(self.multimodal_dim)(
            torch.zeros(1, *self.spatial_shape, self.multimodal_dim)
        )
        self.register_buffer(
            "visual_position",
            rearrange(position, "1 d h w c -> 1 (d h w) c"),
            persistent=True,
        )
        self.capture_attention = False
        self.capture_cross_attention_logits = False
        # Audit-only switches. Defaults preserve the trained E3 forward path.
        self.joint_cross_modal_ablation = False
        self.explicit_cross_ablation = False
        self.last_joint_attention: torch.Tensor | None = None
        self.last_cross_attention: torch.Tensor | None = None
        self.last_cross_attention_logits: torch.Tensor | None = None
        self.last_joint_visual: torch.Tensor | None = None
        self.last_joint_text: torch.Tensor | None = None
        self.last_fused_visual: torch.Tensor | None = None
        self.last_audit: dict[str, object] = {}
        self.forward_count = 0
        self._reset_deterministically(init_seed)

    def _reset_deterministically(self, seed: int) -> None:
        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(seed))
        with torch.no_grad():
            for module in self.modules():
                if isinstance(module, nn.LayerNorm):
                    module.weight.fill_(1.0)
                    if module.bias is not None:
                        module.bias.zero_()
                elif isinstance(module, nn.Linear):
                    nn.init.xavier_uniform_(module.weight, generator=generator)
                    if module.bias is not None:
                        module.bias.zero_()
                elif isinstance(module, nn.MultiheadAttention):
                    if module.in_proj_weight is not None:
                        nn.init.xavier_uniform_(module.in_proj_weight, generator=generator)
                    if module.in_proj_bias is not None:
                        module.in_proj_bias.zero_()
                    nn.init.xavier_uniform_(module.out_proj.weight, generator=generator)
                    if module.out_proj.bias is not None:
                        module.out_proj.bias.zero_()

    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())

    def forward(
        self,
        visual_tokens: torch.Tensor,
        text_tokens: torch.Tensor,
        valid_token_mask: torch.Tensor,
    ) -> torch.Tensor:
        if visual_tokens.ndim != 3 or text_tokens.ndim != 3:
            raise ValueError("visual_tokens and text_tokens must be rank three")
        if visual_tokens.shape[0] != text_tokens.shape[0]:
            raise ValueError("visual/text batch dimensions must match")
        if visual_tokens.shape[-1] != self.visual_dim:
            raise ValueError(
                f"Expected visual dimension {self.visual_dim}, got {visual_tokens.shape[-1]}"
            )
        if text_tokens.shape[-1] != self.text_dim:
            raise ValueError(
                f"Expected text dimension {self.text_dim}, got {text_tokens.shape[-1]}"
            )
        if valid_token_mask.shape != text_tokens.shape[:2]:
            raise ValueError("valid_token_mask must match the text token axes")
        if not bool(valid_token_mask.any(dim=1).all()):
            raise ValueError("Every prompt must contain a valid content token")
        expected_visual_tokens = math.prod(self.spatial_shape)
        if visual_tokens.shape[1] != expected_visual_tokens:
            raise ValueError(
                f"Expected {expected_visual_tokens} visual tokens for {self.spatial_shape}, "
                f"got {visual_tokens.shape[1]}"
            )

        batch, n_image, _ = visual_tokens.shape
        n_text = int(text_tokens.shape[1])
        visual = self.visual_projection(self.visual_norm(visual_tokens))
        visual = visual + self.visual_position.to(dtype=visual.dtype)
        text = self.text_projection(self.text_norm(text_tokens))
        joint = torch.cat((visual, text), dim=1)
        joint_padding_mask = torch.cat(
            (
                torch.zeros(
                    batch,
                    n_image,
                    device=valid_token_mask.device,
                    dtype=torch.bool,
                ),
                ~valid_token_mask.to(dtype=torch.bool),
            ),
            dim=1,
        )
        joint_input = self.joint_norm(joint)
        joint_attn_mask = None
        if self.joint_cross_modal_ablation:
            # Keep I->I and T->T communication while blocking only I<->T.
            joint_attn_mask = torch.zeros(
                n_image + n_text,
                n_image + n_text,
                device=joint_input.device,
                dtype=joint_input.dtype,
            )
            joint_attn_mask[:n_image, n_image:] = torch.finfo(joint_input.dtype).min
            joint_attn_mask[n_image:, :n_image] = torch.finfo(joint_input.dtype).min
        joint_delta, joint_attention = self.joint_attention(
            joint_input,
            joint_input,
            joint_input,
            key_padding_mask=joint_padding_mask,
            attn_mask=joint_attn_mask,
            need_weights=self.capture_attention,
            average_attn_weights=False,
        )
        joint = joint + self.joint_dropout(joint_delta)
        joint = joint + self.joint_ffn(self.joint_ffn_norm(joint))
        visual_joint = joint[:, :n_image]
        text_joint = joint[:, n_image:]
        self.last_joint_visual = visual_joint.detach() if self.capture_attention else None
        self.last_joint_text = text_joint.detach() if self.capture_attention else None

        cross_query = self.cross_query_norm(visual_joint)
        cross_key_value = self.cross_text_norm(text_joint)
        cross_logits = None
        if self.capture_cross_attention_logits:
            # Pre-softmax image->word compatibility logits used by the explicit
            # semantic grounding loss.  This mirrors nn.MultiheadAttention's
            # QK^T/sqrt(head_dim) computation for the existing cross-attention
            # module without changing the forward attention output.
            embed_dim = self.cross_attention.embed_dim
            head_dim = embed_dim // self.cross_attention.num_heads
            q_weight = self.cross_attention.in_proj_weight[:embed_dim]
            k_weight = self.cross_attention.in_proj_weight[embed_dim : 2 * embed_dim]
            if self.cross_attention.in_proj_bias is None:
                q_bias = k_bias = None
            else:
                q_bias = self.cross_attention.in_proj_bias[:embed_dim]
                k_bias = self.cross_attention.in_proj_bias[embed_dim : 2 * embed_dim]
            q = F.linear(cross_query, q_weight, q_bias)
            k = F.linear(cross_key_value, k_weight, k_bias)
            q = rearrange(
                q,
                "b n (h d) -> b h n d",
                h=self.cross_attention.num_heads,
            )
            k = rearrange(
                k,
                "b n (h d) -> b h n d",
                h=self.cross_attention.num_heads,
            )
            cross_logits = torch.einsum("bhid,bhjd->bhij", q, k) / math.sqrt(
                head_dim
            )
            invalid = ~valid_token_mask.to(dtype=torch.bool)
            if invalid.any():
                cross_logits = cross_logits.masked_fill(
                    invalid[:, None, None, :],
                    torch.finfo(cross_logits.dtype).min,
                )
        if self.explicit_cross_ablation:
            cross_delta = torch.zeros_like(visual_joint)
            cross_attention = None
        else:
            cross_delta, cross_attention = self.cross_attention(
                cross_query,
                cross_key_value,
                cross_key_value,
                key_padding_mask=~valid_token_mask.to(dtype=torch.bool),
                need_weights=self.capture_attention,
                average_attn_weights=False,
            )
        fused_shared = visual_joint + self.cross_dropout(cross_delta)
        fused_shared = fused_shared + self.cross_ffn(
            self.cross_ffn_norm(fused_shared)
        )
        fused_visual = self.output_projection(self.output_norm(fused_shared))
        self.last_fused_visual = fused_visual.detach() if self.capture_attention else None

        visual_float = visual_tokens.detach().float()
        fused_float = fused_visual.detach().float()
        before_rms = float(visual_float.square().mean().sqrt().item())
        after_rms = float(fused_float.square().mean().sqrt().item())
        self.last_audit = {
            "spatial_shape": list(self.spatial_shape),
            "n_image": n_image,
            "n_text": n_text,
            "joint_sequence_tokens": n_image + n_text,
            "joint_attention_shape": [
                batch,
                self.num_heads,
                n_image + n_text,
                n_image + n_text,
            ],
            "cross_attention_shape": [
                batch,
                self.num_heads,
                n_image,
                n_text,
            ],
            "feature_rms_before": before_rms,
            "feature_rms_after": after_rms,
            "feature_rms_ratio": after_rms / max(before_rms, 1e-30),
            "cosine_before_after": float(
                F.cosine_similarity(
                    visual_float.reshape(batch, -1),
                    fused_float.reshape(batch, -1),
                    dim=1,
                ).mean().item()
            ),
        }
        self.last_joint_attention = (
            None if joint_attention is None else joint_attention.detach()
        )
        self.last_cross_attention = (
            None if cross_attention is None else cross_attention.detach()
        )
        self.last_cross_attention_logits = cross_logits
        self.forward_count += 1
        return fused_visual


class FANPreserveFusionProjection3D(nn.Module):
    """Identity-dominant projection for the FAN preserve branch.

    The projection consumes the original visual feature and the FAN feature as
    two explicit paths.  Its visual slice starts as channel identity while the
    FAN slice starts at a small nonzero random scale, so the pretrained pathway
    dominates update 0 and the FAN branch still receives gradients.
    """

    def __init__(
        self,
        *,
        visual_dim: int,
        fan_dim: int,
        epsilon: float = 1e-3,
        init_seed: int = 260912,
    ) -> None:
        super().__init__()
        if visual_dim <= 0 or fan_dim <= 0:
            raise ValueError("visual_dim and fan_dim must be positive")
        if epsilon < 0:
            raise ValueError("epsilon must be non-negative")
        self.visual_dim = int(visual_dim)
        self.fan_dim = int(fan_dim)
        self.epsilon = float(epsilon)
        with torch.random.fork_rng(devices=[]):
            self.projection = nn.Conv3d(
                self.visual_dim + self.fan_dim,
                self.visual_dim,
                kernel_size=1,
                bias=True,
            )
        self.last_audit: dict[str, object] = {}
        self._reset_deterministically(init_seed)

    def _reset_deterministically(self, seed: int) -> None:
        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(seed))
        with torch.no_grad():
            self.projection.weight.zero_()
            eye = torch.eye(
                self.visual_dim,
                dtype=self.projection.weight.dtype,
                device=self.projection.weight.device,
            )
            self.projection.weight[:, : self.visual_dim, 0, 0, 0].copy_(eye)
            fan_weight = torch.empty(
                self.visual_dim,
                self.fan_dim,
                dtype=self.projection.weight.dtype,
                device=self.projection.weight.device,
            )
            nn.init.xavier_uniform_(fan_weight, generator=generator)
            self.projection.weight[:, self.visual_dim :, 0, 0, 0].copy_(
                self.epsilon * fan_weight
            )
            if self.projection.bias is not None:
                self.projection.bias.zero_()

    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())

    def forward(self, visual_feature: torch.Tensor, fan_feature: torch.Tensor) -> torch.Tensor:
        if visual_feature.ndim != 5 or fan_feature.ndim != 5:
            raise ValueError("visual_feature and fan_feature must be rank five")
        if visual_feature.shape[0] != fan_feature.shape[0]:
            raise ValueError("visual/FAN batch dimensions must match")
        if visual_feature.shape[1] != self.visual_dim:
            raise ValueError(
                f"Expected visual channels {self.visual_dim}, got {visual_feature.shape[1]}"
            )
        if fan_feature.shape[1] != self.fan_dim:
            raise ValueError(f"Expected FAN channels {self.fan_dim}, got {fan_feature.shape[1]}")
        if tuple(visual_feature.shape[2:]) != tuple(fan_feature.shape[2:]):
            raise ValueError("visual_feature and fan_feature spatial shapes must match")
        projected = self.projection(torch.cat((visual_feature, fan_feature), dim=1))
        alpha = float(getattr(self, "inference_alpha", 1.0))
        enriched = visual_feature + alpha * (projected - visual_feature)

        visual_float = visual_feature.detach().float()
        enriched_float = enriched.detach().float()
        delta = enriched_float - visual_float
        visual_norm = visual_float.norm().clamp_min(1e-30)
        visual_rms = visual_float.square().mean().sqrt().clamp_min(1e-30)
        enriched_rms = enriched_float.square().mean().sqrt()
        self.last_audit = {
            "input_visual_shape": list(visual_feature.shape),
            "input_fan_shape": list(fan_feature.shape),
            "output_feature_shape": list(enriched.shape),
            "relative_delta_norm": float((delta.norm() / visual_norm).item()),
            "cosine_visual_enriched": float(
                F.cosine_similarity(
                    visual_float.reshape(visual_float.shape[0], -1),
                    enriched_float.reshape(enriched_float.shape[0], -1),
                    dim=1,
                ).mean().item()
            ),
            "rms_enriched_over_visual": float((enriched_rms / visual_rms).item()),
            "visual_weight_norm": float(
                self.projection.weight[:, : self.visual_dim].detach().float().norm().item()
            ),
            "fan_weight_norm": float(
                self.projection.weight[:, self.visual_dim :].detach().float().norm().item()
            ),
            "epsilon": self.epsilon,
            "inference_alpha": alpha,
        }
        return enriched
