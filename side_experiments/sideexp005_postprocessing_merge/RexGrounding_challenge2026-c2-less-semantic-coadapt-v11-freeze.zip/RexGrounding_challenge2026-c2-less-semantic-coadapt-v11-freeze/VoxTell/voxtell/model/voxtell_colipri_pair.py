"""Frozen CoLiPri encoder pair with learned pyramid and VoxTell decoder."""

from __future__ import annotations

from typing import Sequence

import torch
from einops import rearrange, repeat
from torch import nn


class ConvBlock3d(nn.Module):
    def __init__(self, input_channels: int, output_channels: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv3d(input_channels, output_channels, 3, padding=1, bias=False),
            nn.InstanceNorm3d(output_channels, affine=True),
            nn.LeakyReLU(negative_slope=0.01, inplace=True),
            nn.Conv3d(output_channels, output_channels, 3, padding=1, bias=False),
            nn.InstanceNorm3d(output_channels, affine=True),
            nn.LeakyReLU(negative_slope=0.01, inplace=True),
        )

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return self.block(value)


class ColipriFeaturePyramid(nn.Module):
    """Learn a real six-level hierarchy from Primus-M's native 24^3 grid."""

    output_channels = (32, 64, 128, 256, 320, 320)
    expected_shapes = (
        (192, 192, 192),
        (96, 96, 96),
        (48, 48, 48),
        (24, 24, 24),
        (12, 12, 12),
        (6, 6, 6),
    )

    def __init__(self, input_channels: int = 864) -> None:
        super().__init__()
        self.at_24 = nn.Sequential(
            nn.Conv3d(input_channels, 256, 1, bias=False),
            ConvBlock3d(256, 256),
        )
        self.down_12 = nn.Sequential(
            nn.Conv3d(256, 320, 3, stride=2, padding=1, bias=False),
            ConvBlock3d(320, 320),
        )
        self.down_6 = nn.Sequential(
            nn.Conv3d(320, 320, 3, stride=2, padding=1, bias=False),
            ConvBlock3d(320, 320),
        )
        self.up_48 = nn.Sequential(
            nn.ConvTranspose3d(256, 128, 2, stride=2, bias=False),
            ConvBlock3d(128, 128),
        )
        self.up_96 = nn.Sequential(
            nn.ConvTranspose3d(128, 64, 2, stride=2, bias=False),
            ConvBlock3d(64, 64),
        )
        self.up_192 = nn.Sequential(
            nn.ConvTranspose3d(64, 32, 2, stride=2, bias=False),
            ConvBlock3d(32, 32),
        )
        self.apply(self._initialize)

    @staticmethod
    def _initialize(module: nn.Module) -> None:
        if isinstance(module, (nn.Conv3d, nn.ConvTranspose3d)):
            nn.init.kaiming_normal_(module.weight, a=0.01)

    def forward(self, dense: torch.Tensor) -> list[torch.Tensor]:
        if tuple(dense.shape[1:]) != (864, 24, 24, 24):
            raise ValueError(
                "Primus-M native grid must be [B,864,24,24,24], got "
                f"{tuple(dense.shape)}"
            )
        level_24 = self.at_24(dense)
        level_12 = self.down_12(level_24)
        level_6 = self.down_6(level_12)
        level_48 = self.up_48(level_24)
        level_96 = self.up_96(level_48)
        level_192 = self.up_192(level_96)
        skips = [level_192, level_96, level_48, level_24, level_12, level_6]
        for index, (feature, channels, shape) in enumerate(
            zip(skips, self.output_channels, self.expected_shapes)
        ):
            if feature.shape[1] != channels or tuple(feature.shape[2:]) != shape:
                raise RuntimeError(
                    f"Pyramid level {index} contract mismatch: {tuple(feature.shape)}; "
                    f"expected [B,{channels},{','.join(map(str, shape))}]"
                )
        return skips


class ColipriEncoderPairVoxTell(nn.Module):
    """Use both native CoLiPri encoders and the pretrained VoxTell decoder."""

    def __init__(
        self,
        pretrained_voxtell: nn.Module,
        colipri_image_encoder: nn.Module,
        colipri_text_encoder: nn.Module,
        tokenizer,
    ) -> None:
        super().__init__()
        self.colipri_image_encoder = colipri_image_encoder
        self.colipri_text_encoder = colipri_text_encoder
        self.tokenizer = tokenizer
        self.pyramid = ColipriFeaturePyramid(864)
        self.text_projection = nn.Linear(768, 2560)

        self.project_bottleneck_embed = pretrained_voxtell.project_bottleneck_embed
        self.project_text_embed = pretrained_voxtell.project_text_embed
        self.transformer_decoder = pretrained_voxtell.transformer_decoder
        self.project_to_decoder_channels = pretrained_voxtell.project_to_decoder_channels
        self.decoder = pretrained_voxtell.decoder
        self.deep_supervision = pretrained_voxtell.deep_supervision
        self.register_buffer("pos_embed", pretrained_voxtell.pos_embed.detach().clone())

        self.colipri_image_encoder.requires_grad_(False).eval()
        self.colipri_text_encoder.requires_grad_(False).eval()

    def train(self, mode: bool = True):
        super().train(mode)
        self.colipri_image_encoder.eval()
        self.colipri_text_encoder.eval()
        return self

    def encode_text(
        self, prompt_texts: Sequence[Sequence[str]], device: torch.device
    ) -> torch.Tensor:
        prompt_count = len(prompt_texts[0])
        if any(len(row) != prompt_count for row in prompt_texts):
            raise ValueError("Every image must have the same prompt count")
        flat = [prompt for row in prompt_texts for prompt in row]
        encoded = self.tokenizer(
            flat,
            max_length=512,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        with torch.no_grad():
            text = self.colipri_text_encoder(
                encoded["input_ids"].to(device),
                encoded["attention_mask"].to(device),
                pool=True,
                normalize=True,
            )
        text = text.reshape(len(prompt_texts), prompt_count, 768)
        return self.text_projection(text).unsqueeze(2)

    def forward(
        self,
        image: torch.Tensor,
        prompt_texts: Sequence[Sequence[str]] | None = None,
        text_embedding: torch.Tensor | None = None,
    ) -> torch.Tensor | list[torch.Tensor]:
        if (prompt_texts is None) == (text_embedding is None):
            raise ValueError("Provide exactly one of prompt_texts or text_embedding")
        with torch.no_grad():
            dense = self.colipri_image_encoder(
                image, project=False, pool=False, normalize=False
            )
        skips = self.pyramid(dense.detach())
        if text_embedding is None:
            text_embedding = self.encode_text(prompt_texts, image.device)
        elif text_embedding.ndim != 4 or text_embedding.shape[2:] != (1, 2560):
            raise ValueError(
                "Qwen text_embedding must be [B,N,1,2560], got "
                f"{tuple(text_embedding.shape)}"
            )

        selected = skips[4]
        memory = rearrange(selected, "b c d h w -> b h w d c")
        memory = self.project_bottleneck_embed(memory)
        memory = rearrange(memory, "b h w d c -> (h w d) b c")

        text = repeat(text_embedding.squeeze(2), "b n dim -> n b dim")
        text = self.project_text_embed(text)
        mask_embedding, _ = self.transformer_decoder(
            tgt=text,
            memory=memory,
            pos=self.pos_embed,
            memory_key_padding_mask=None,
        )
        mask_embedding = repeat(mask_embedding, "n b dim -> b n dim")
        mask_embeddings = [
            projection(mask_embedding) for projection in self.project_to_decoder_channels
        ]
        prompt_outputs = []
        for prompt_index in range(text_embedding.shape[1]):
            per_stage = [
                value[:, prompt_index : prompt_index + 1]
                for value in mask_embeddings
            ]
            prompt_outputs.append(self.decoder(skips, per_stage))
        outputs = [
            torch.cat(scale_outputs, dim=1)
            for scale_outputs in zip(*prompt_outputs)
        ]
        return outputs if self.deep_supervision else outputs[0]

    def frozen_encoder_gradient_audit(self) -> dict[str, int]:
        return {
            "image_encoder_trainable": sum(
                parameter.requires_grad
                for parameter in self.colipri_image_encoder.parameters()
            ),
            "text_encoder_trainable": sum(
                parameter.requires_grad
                for parameter in self.colipri_text_encoder.parameters()
            ),
            "image_encoder_gradients": sum(
                parameter.grad is not None
                for parameter in self.colipri_image_encoder.parameters()
            ),
            "text_encoder_gradients": sum(
                parameter.grad is not None
                for parameter in self.colipri_text_encoder.parameters()
            ),
        }


class ColipriTextVoxTell(nn.Module):
    """Use CoLiPri text with the native VoxTell image encoder and decoder."""

    def __init__(
        self,
        pretrained_voxtell: nn.Module,
        colipri_text_encoder: nn.Module,
        tokenizer,
    ) -> None:
        super().__init__()
        self.voxtell = pretrained_voxtell
        self.colipri_text_encoder = colipri_text_encoder
        self.tokenizer = tokenizer
        self.text_projection = nn.Linear(768, 2560)
        self.colipri_text_encoder.requires_grad_(False).eval()

    def train(self, mode: bool = True):
        super().train(mode)
        self.colipri_text_encoder.eval()
        return self

    def encode_text(
        self, prompt_texts: Sequence[Sequence[str]], device: torch.device
    ) -> torch.Tensor:
        prompt_count = len(prompt_texts[0])
        if any(len(row) != prompt_count for row in prompt_texts):
            raise ValueError("Every image must have the same prompt count")
        flat = [prompt for row in prompt_texts for prompt in row]
        encoded = self.tokenizer(
            flat,
            max_length=512,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        with torch.no_grad():
            text = self.colipri_text_encoder(
                encoded["input_ids"].to(device),
                encoded["attention_mask"].to(device),
                pool=True,
                normalize=True,
            )
        text = text.reshape(len(prompt_texts), prompt_count, 768)
        return self.text_projection(text).unsqueeze(2)

    def forward(
        self, image: torch.Tensor, prompt_texts: Sequence[Sequence[str]]
    ) -> torch.Tensor | list[torch.Tensor]:
        return self.voxtell(image, self.encode_text(prompt_texts, image.device))

    def frozen_encoder_gradient_audit(self) -> dict[str, int]:
        return {
            "text_encoder_trainable": sum(
                parameter.requires_grad
                for parameter in self.colipri_text_encoder.parameters()
            ),
            "text_encoder_gradients": sum(
                parameter.grad is not None
                for parameter in self.colipri_text_encoder.parameters()
            ),
        }
