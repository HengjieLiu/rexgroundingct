"""Shared-decoder category-2d dense-prior joint-training path.

Unlike the earlier conversion specialist, this module owns no decoder or prompt
head copy.  It predicts a dense prior and injects zero-initialized residuals
into the final two stages of the ordinary S3 decoder.  Non-category-2d prompts
execute the ordinary decoder without invoking any module defined here.
"""

from __future__ import annotations

import types
from typing import Any, List

import torch
import torch.nn.functional as F
from torch import nn

from .category_2d_dense_conversion import (
    CATEGORY_2D_INDEX,
    DENSE_CONVERSION_CONDITIONS,
    DensePriorHead2d,
    PriorFeatureAdapter2d,
    PriorLogitResidual2d,
)


ARCHITECTURE_ID = "shared_s3_dense_prior_joint_v1"


class Category2dDenseJoint(nn.Module):
    """Only the new dense head and residual adapters; no copied base weights."""

    def __init__(self, model: nn.Module, bottleneck: int = 16) -> None:
        super().__init__()
        if len(model.decoder.stages) < 2:
            raise ValueError("Dense joint path requires at least two decoder stages")
        self.half_stage_index = len(model.decoder.stages) - 2
        self.full_stage_index = len(model.decoder.stages) - 1
        full_channels = int(model.encoder.output_channels[0])
        half_channels = int(model.encoder.output_channels[1])
        self.half_channels = half_channels
        self.full_channels = full_channels
        self.dense_prior_head = DensePriorHead2d(2 * half_channels, full_channels)
        self.half_adapter = PriorFeatureAdapter2d(2 * half_channels, bottleneck)
        self.full_adapter = PriorFeatureAdapter2d(2 * full_channels, bottleneck)
        self.logit_residual = PriorLogitResidual2d(full_channels, bottleneck)
        self.execution_count = 0


def reset_dense_joint_captures(model: nn.Module) -> None:
    model.last_2d_dense_prior_logits = []
    model.last_2d_dense_prior_probabilities = []
    model.last_2d_dense_priors_used = []
    model.last_2d_dense_residuals = {}
    model.last_2d_dense_features = {}
    model.last_2d_dense_condition_diagnostics = None
    model.last_2d_dense_prompt_indices = []
    joint = getattr(model, "category_2d_dense_joint", None)
    if joint is not None:
        joint.execution_count = 0


def _forward_pre_hook(model: nn.Module, _args: tuple[Any, ...]) -> None:
    reset_dense_joint_captures(model)
    model._category_2d_dense_joint_prompt_cursor = 0
    context = getattr(model, "category_2d_dense_joint_context", None)
    if context is not None:
        context["cursor"] = 0


def _context_value(
    model: nn.Module,
    key: str,
    prompt_index: int,
    predicted: torch.Tensor,
) -> torch.Tensor:
    context = model.category_2d_dense_joint_context
    value = context[key]
    if bool(context.get("prompt_axis", False)):
        value = value[:, prompt_index : prompt_index + 1]
    value = value.to(device=predicted.device, dtype=predicted.dtype)
    if value.shape != predicted.shape:
        value = F.interpolate(
            value, size=predicted.shape[2:], mode="trilinear", align_corners=False
        )
    return value


def _condition_priors(
    model: nn.Module, predicted: torch.Tensor, prompt_index: int
) -> tuple[tuple[str, ...], tuple[torch.Tensor, ...]]:
    context = getattr(model, "category_2d_dense_joint_context", None)
    if context is None:
        return ("learned",), (predicted,)
    mode = context["mode"]
    if mode == "teacher":
        target = _context_value(model, "target", prompt_index, predicted)
        alpha = float(context["alpha"])
        return ("teacher",), (alpha * target + (1.0 - alpha) * predicted,)
    if mode == "override":
        return ("override",), (_context_value(model, "prior", prompt_index, predicted),)
    if mode == "conditions":
        oracle = _context_value(model, "oracle", prompt_index, predicted)
        shifted = _context_value(model, "shifted_oracle", prompt_index, predicted)
        return DENSE_CONVERSION_CONDITIONS, (
            predicted,
            torch.zeros_like(predicted),
            oracle,
            shifted,
        )
    raise ValueError(f"Unknown dense-joint context mode: {mode!r}")


def _decode_prompt_with_dense_joint(
    self,
    skips: List[torch.Tensor],
    mask_embeddings: List[torch.Tensor],
    query: torch.Tensor,
    gate_scale: float | torch.Tensor = 1.0,
    gate_scales_by_scale: dict[str, float | torch.Tensor] | None = None,
    fullres_refinement_scale: float | torch.Tensor = 1.0,
    joint_fusion_scale: float | torch.Tensor = 0.0,
    adaptive_rho_category_indices: torch.Tensor | None = None,
    adaptive_rho_active_mask: torch.Tensor | None = None,
    category_router_indices: torch.Tensor | None = None,
    target_attention_adapter_active_mask: torch.Tensor | None = None,
) -> List[torch.Tensor]:
    del fullres_refinement_scale, joint_fusion_scale, adaptive_rho_category_indices
    del adaptive_rho_active_mask, target_attention_adapter_active_mask
    if any(
        value is not None
        for value in (
            getattr(self, "adaptive_rho_adapter", None),
            getattr(self, "category_attention_router", None),
            getattr(self, "target_attention_adapter", None),
            getattr(self, "s3_fullres_attention_refinement", None),
            getattr(self, "s3_joint_fusion_head", None),
        )
    ):
        raise RuntimeError("Dense joint requires the unmodified single-scale S3 path")
    batch = skips[0].shape[0]
    if category_router_indices is None:
        active = torch.zeros(batch, dtype=torch.bool, device=skips[0].device)
    else:
        active = (
            category_router_indices.to(skips[0].device)
            .long()
            .reshape(batch, -1)[:, 0]
            .eq(CATEGORY_2D_INDEX)
        )
    if bool(active.any()) and not bool(active.all()):
        raise RuntimeError("Mixed category-2d/non-2d items in one decoder call are unsupported")

    context = getattr(self, "category_2d_dense_joint_context", None)
    prompt_index = int(getattr(self, "_category_2d_dense_joint_prompt_cursor", 0))
    self._category_2d_dense_joint_prompt_cursor = prompt_index + 1
    if context is not None:
        context["cursor"] = prompt_index + 1

    decoder = self.decoder
    joint = self.category_2d_dense_joint
    lres_input = skips[-1]
    seg_outputs: list[torch.Tensor] = []
    reversed_embeddings = mask_embeddings[::-1]
    half_input = None
    half_latent = None
    half_embedding = None
    half_seg_output_index = None

    for stage_idx in range(len(decoder.stages)):
        previous = decoder.transpconvs[stage_idx](lres_input)
        ungated = skips[-(stage_idx + 2)]
        skip = ungated
        scale = self.s3_attention_decoder_stage_to_scale.get(stage_idx)
        attention = None
        gate = None
        stage_scale = gate_scale
        if scale is not None:
            stage_scale = (
                gate_scale
                if gate_scales_by_scale is None
                else gate_scales_by_scale.get(scale, gate_scale)
            )
            gate = (
                self.s3_attention_gate
                if scale == "1/2"
                else self.s3_extra_attention_gates[self._s2_scale_key(scale)]
            )
            gated, attention = gate(skip, previous, query, gate_scale=stage_scale)
            skip = gated[:, 0]
            self.last_s3_attention_maps[scale].append(attention)
            attention_logits = getattr(gate, "last_attention_logits", None)
            if attention_logits is not None:
                self.last_s3_attention_logits.setdefault(scale, []).append(attention_logits)

        stage_input = torch.cat((previous, skip), dim=1)
        x = decoder.stages[stage_idx](stage_input)
        if bool(active.all()) and stage_idx == joint.half_stage_index:
            joint.execution_count += 1
            half_input = stage_input
            half_latent = joint.dense_prior_head.half_latent(half_input)

        if stage_idx == joint.full_stage_index:
            if not bool(active.any()):
                seg_outputs.append(
                    torch.einsum(
                        "b c h w d, b n c -> b n h w d", x, reversed_embeddings[-1]
                    )
                )
            else:
                if half_input is None or half_latent is None or attention is None or gate is None:
                    raise RuntimeError("Dense joint path did not receive half/full S3 features")
                q_logits = joint.dense_prior_head.full_logits(
                    half_latent, previous, ungated, skip, attention[:, 0]
                )
                q_pred = q_logits.sigmoid()
                condition_names, priors = _condition_priors(self, q_pred, prompt_index)
                condition_logits: list[torch.Tensor] = []
                condition_r_half: list[torch.Tensor] = []
                condition_r_full: list[torch.Tensor] = []
                condition_delta_z: list[torch.Tensor] = []
                first_full_input = None
                first_feature = None
                for condition_index, q_used in enumerate(priors):
                    r_half = joint.half_adapter(half_input, q_used)
                    current_half = decoder.stages[joint.half_stage_index](half_input + r_half)
                    if half_embedding is not None:
                        fusion = torch.einsum(
                            "b c h w d, b n c -> b n h w d", current_half, half_embedding
                        )
                        current_half = torch.cat((current_half, fusion), dim=1)
                    current_previous = decoder.transpconvs[stage_idx](current_half)
                    current_gated, current_attention = gate(
                        ungated, current_previous, query, gate_scale=stage_scale
                    )
                    current_skip = current_gated[:, 0]
                    full_input = torch.cat((current_previous, current_skip), dim=1)
                    r_full = joint.full_adapter(full_input, q_used)
                    feature = decoder.stages[stage_idx](full_input + r_full)
                    base_logit = torch.einsum(
                        "b c h w d, b n c -> b n h w d",
                        feature,
                        reversed_embeddings[-1],
                    )
                    delta_z = joint.logit_residual(feature, q_used)
                    condition_logits.append(base_logit + delta_z)
                    condition_r_half.append(r_half)
                    condition_r_full.append(r_full)
                    condition_delta_z.append(delta_z)
                    if condition_index == 0:
                        first_full_input = full_input
                        first_feature = feature
                        # Expose the attention actually consumed by the learned/teacher path.
                        self.last_s3_attention_maps[scale][-1] = current_attention
                        attention_logits = getattr(gate, "last_attention_logits", None)
                        if attention_logits is not None:
                            self.last_s3_attention_logits.setdefault(scale, [])[-1] = attention_logits
                        if half_seg_output_index is not None:
                            self.last_2d_dense_features["half_deep_supervision_replaced"] = True
                            seg_outputs[half_seg_output_index] = decoder.seg_layers[
                                joint.half_stage_index
                            ](current_half)
                seg_outputs.append(torch.cat(condition_logits, dim=1))
                self.last_2d_dense_prior_logits.append(q_logits)
                self.last_2d_dense_prior_probabilities.append(q_pred)
                self.last_2d_dense_priors_used.append(torch.cat(priors, dim=1))
                self.last_2d_dense_prompt_indices.append(prompt_index)
                self.last_2d_dense_residuals.update(
                    {
                        "R_half": condition_r_half[0],
                        "R_full": condition_r_full[0],
                        "delta_z": condition_delta_z[0],
                    }
                )
                self.last_2d_dense_features.update(
                    {
                        "F_half": half_input,
                        "F_full": first_full_input,
                        "F_out": first_feature,
                    }
                )
                if len(priors) > 1:
                    self.last_2d_dense_condition_diagnostics = {
                        "condition_names": condition_names,
                        "Q_pred": q_pred.detach(),
                        "Q_used": torch.cat(priors, dim=1).detach(),
                        "delta_z": torch.cat(condition_delta_z, dim=1).detach(),
                    }
        elif stage_idx >= len(decoder.stages) - len(reversed_embeddings):
            embedding = reversed_embeddings.pop(0)
            batch_size, _, channels = embedding.shape
            reshaped = embedding.view(batch_size, decoder.num_heads, -1)
            fusion = torch.einsum("b c h w d, b n c -> b n h w d", x, reshaped)
            x = torch.cat((x, fusion), dim=1)
            seg_outputs.append(decoder.seg_layers[stage_idx](x))
            if bool(active.all()) and stage_idx == joint.half_stage_index:
                half_embedding = reshaped
                half_seg_output_index = len(seg_outputs) - 1
        lres_input = x
    seg_outputs = seg_outputs[::-1]
    return seg_outputs if decoder.deep_supervision else seg_outputs[:1]


def attach_category_2d_dense_joint(model: nn.Module, *, bottleneck: int = 16) -> nn.Module:
    if getattr(model, "category_2d_dense_joint", None) is None:
        model.category_2d_dense_joint = Category2dDenseJoint(model, bottleneck)
    object.__setattr__(
        model,
        "_decode_prompt_with_s3",
        types.MethodType(_decode_prompt_with_dense_joint, model),
    )
    model.category_2d_dense_joint_context = None
    model._category_2d_dense_joint_prompt_cursor = 0
    if getattr(model, "_category_2d_dense_joint_hook", None) is None:
        object.__setattr__(
            model,
            "_category_2d_dense_joint_hook",
            model.register_forward_pre_hook(_forward_pre_hook),
        )
    reset_dense_joint_captures(model)
    return model


def set_dense_joint_teacher_context(model: nn.Module, target: torch.Tensor, alpha: float) -> None:
    if not 0.0 <= alpha <= 1.0:
        raise ValueError(alpha)
    model.category_2d_dense_joint_context = {
        "mode": "teacher",
        "target": target,
        "alpha": float(alpha),
        "prompt_axis": True,
        "cursor": 0,
    }


def set_dense_joint_override_context(model: nn.Module, prior: torch.Tensor) -> None:
    model.category_2d_dense_joint_context = {
        "mode": "override",
        "prior": prior,
        "prompt_axis": bool(prior.ndim == 5 and prior.shape[1] > 1),
        "cursor": 0,
    }


def set_dense_joint_condition_context(
    model: nn.Module, oracle: torch.Tensor, shifted_oracle: torch.Tensor
) -> None:
    model.category_2d_dense_joint_context = {
        "mode": "conditions",
        "oracle": oracle,
        "shifted_oracle": shifted_oracle,
        "prompt_axis": False,
        "cursor": 0,
    }


def clear_dense_joint_context(model: nn.Module) -> None:
    model.category_2d_dense_joint_context = None
