"""Prompt-conditioned 3D proposal head used by the P0-B experiment."""

from __future__ import annotations

from dataclasses import asdict, dataclass

import torch
from torch import nn


@dataclass(frozen=True)
class PromptProposalHeadConfig:
    """Serializable architecture configuration.

    The input is already prompt-conditioned by the frozen S3 gate.  A learned
    1x1 projection is the only feature adapter introduced by P0-B.
    """

    input_channels: int
    hidden_channels: int = 64
    feature_scale: str = "1/4"
    grid_stride: int = 4
    heatmap_bias: float = -2.19

    def to_dict(self) -> dict:
        return asdict(self)


class PromptConditionedProposalHead3D(nn.Module):
    """Predict center heatmap, sub-grid offset, and log box extent."""

    def __init__(self, config: PromptProposalHeadConfig) -> None:
        super().__init__()
        if min(
            config.input_channels,
            config.hidden_channels,
            config.grid_stride,
        ) <= 0:
            raise ValueError("Proposal-head channels and grid_stride must be positive")
        groups = min(8, config.hidden_channels)
        while config.hidden_channels % groups:
            groups -= 1
        self.config = config
        self.input_projection = nn.Sequential(
            nn.Conv3d(config.input_channels, config.hidden_channels, 1, bias=False),
            nn.GroupNorm(groups, config.hidden_channels),
            nn.GELU(),
        )
        self.trunk = nn.Sequential(
            nn.Conv3d(
                config.hidden_channels,
                config.hidden_channels,
                3,
                padding=1,
                bias=False,
            ),
            nn.GroupNorm(groups, config.hidden_channels),
            nn.GELU(),
            nn.Conv3d(
                config.hidden_channels,
                config.hidden_channels,
                3,
                padding=1,
                bias=False,
            ),
            nn.GroupNorm(groups, config.hidden_channels),
        )
        self.activation = nn.GELU()
        self.center_heatmap = nn.Conv3d(config.hidden_channels, 1, 1)
        self.center_offset = nn.Conv3d(config.hidden_channels, 3, 1)
        self.log_extent = nn.Conv3d(config.hidden_channels, 3, 1)
        nn.init.constant_(self.center_heatmap.bias, config.heatmap_bias)
        nn.init.zeros_(self.center_offset.weight)
        nn.init.zeros_(self.center_offset.bias)
        nn.init.zeros_(self.log_extent.weight)
        nn.init.zeros_(self.log_extent.bias)

    def forward(self, feature: torch.Tensor) -> dict[str, torch.Tensor]:
        if feature.ndim != 5 or feature.shape[1] != self.config.input_channels:
            raise ValueError(
                "Expected proposal feature [B,C,D,H,W] with "
                f"C={self.config.input_channels}, got {tuple(feature.shape)}"
            )
        projected = self.input_projection(feature)
        hidden = self.activation(projected + self.trunk(projected))
        return {
            "center_logits": self.center_heatmap(hidden),
            "offset": torch.sigmoid(self.center_offset(hidden)),
            "log_extent": self.log_extent(hidden),
        }
