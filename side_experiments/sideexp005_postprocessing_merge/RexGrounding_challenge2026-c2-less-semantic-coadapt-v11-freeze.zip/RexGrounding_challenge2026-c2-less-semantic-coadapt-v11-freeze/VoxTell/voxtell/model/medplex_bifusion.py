"""Mask-aware MedPlex-style two-way image/text fusion for 3-D encoder stages."""

from __future__ import annotations

import torch
from torch import nn


class MedPlexBiFusion(nn.Module):
    """One SAM/TwoWay-inspired update with zero-gated image and text residuals.

    Inputs are batch-first ``[N,S,C]`` image and ``[N,L,768]`` BERT tokens.
    ``valid`` is True for lexical/special BERT tokens that are not padding.
    The zero gates make this an exact identity at construction while leaving
    each gate differentiable on the first optimization step.
    """

    def __init__(self, image_dim: int, heads: int = 8) -> None:
        super().__init__()
        if image_dim % heads:
            raise ValueError("image_dim must divide evenly by heads")
        self.text_in = nn.Linear(768, image_dim)
        self.text_out = nn.Linear(image_dim, 768)
        self.text_self = nn.MultiheadAttention(image_dim, heads, batch_first=True)
        self.text_to_image = nn.MultiheadAttention(image_dim, heads, batch_first=True)
        self.image_to_text = nn.MultiheadAttention(image_dim, heads, batch_first=True)
        self.text_ffn = nn.Sequential(nn.Linear(image_dim, image_dim * 2), nn.GELU(), nn.Linear(image_dim * 2, image_dim))
        self.image_ffn = nn.Sequential(nn.Linear(image_dim, image_dim * 2), nn.GELU(), nn.Linear(image_dim * 2, image_dim))
        self.text_norm = nn.ModuleList([nn.LayerNorm(image_dim) for _ in range(3)])
        self.image_norm = nn.ModuleList([nn.LayerNorm(image_dim) for _ in range(2)])
        self.gamma_image = nn.Parameter(torch.zeros(()))
        self.gamma_text = nn.Parameter(torch.zeros(()))
        self.last_audit: dict[str, float | int] = {}

    def forward(
        self,
        image: torch.Tensor,
        text: torch.Tensor,
        valid: torch.Tensor,
        *,
        enable_text_to_image: bool = True,
        enable_image_to_text: bool = True,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        text_stage = self.text_in(text)
        padding = ~valid.to(torch.bool)
        t, _ = self.text_self(self.text_norm[0](text_stage), self.text_norm[0](text_stage), self.text_norm[0](text_stage), key_padding_mask=padding, need_weights=False)
        text_stage = text_stage + t
        # ``text_to_image`` has text queries and image keys/values, hence it is
        # the Image->Text direction.  ``image_to_text`` is Text->Image.
        if enable_image_to_text:
            t, _ = self.text_to_image(self.text_norm[1](text_stage), image, image, need_weights=False)
            text_stage = text_stage + t + self.text_ffn(self.text_norm[2](text_stage))
        else:
            # A directional causal ablation must remove the effective text-side
            # update, rather than leave a learned intra-block residual behind.
            text_stage = self.text_in(text)
        if enable_text_to_image:
            v, _ = self.image_to_text(self.image_norm[0](image), text_stage, text_stage, key_padding_mask=padding, need_weights=False)
            image_stage = image + v + self.image_ffn(self.image_norm[1](image + v))
        else:
            image_stage = image
        # Gates are deliberately outside the blocks: their initial value makes
        # both stages exact no-ops but the gated residual drives gate gradients.
        image_out = image + self.gamma_image * (image_stage - image)
        # Keep the small zero-gated text residual addition in FP32.  Under
        # BF16 autocast, early 1e-6-scale residuals can round back to the exact
        # input and prevent later BERT groups from observing the interaction.
        text_residual = self.text_out(text_stage - self.text_in(text))
        text_out = text.float() + self.gamma_text.float() * text_residual.float()
        with torch.no_grad():
            image_norm = image.detach().float().flatten(1).norm(dim=1).clamp_min(1e-12)
            text_norm = text.detach().float().flatten(1).norm(dim=1).clamp_min(1e-12)
            image_delta = (image_out.detach().float() - image.detach().float()).flatten(1)
            text_delta = (text_out.detach().float() - text.detach().float()).flatten(1)
            self.last_audit = {
                "image_tokens": int(image.shape[1]),
                "text_tokens": int(text.shape[1]),
                "gamma_image": float(self.gamma_image.detach()),
                "gamma_text": float(self.gamma_text.detach()),
                "text_to_image_enabled": bool(enable_text_to_image),
                "image_to_text_enabled": bool(enable_image_to_text),
                "image_relative_l2": float((image_delta.norm(dim=1) / image_norm).mean()),
                "text_relative_l2": float((text_delta.norm(dim=1) / text_norm).mean()),
            }
        return image_out, text_out
