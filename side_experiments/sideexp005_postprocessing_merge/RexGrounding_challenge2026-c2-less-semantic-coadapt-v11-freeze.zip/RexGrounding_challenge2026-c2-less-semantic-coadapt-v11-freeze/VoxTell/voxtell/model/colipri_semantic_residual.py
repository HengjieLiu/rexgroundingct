"""Qwen-preserving CoLiPri semantic residual fusion for VoxTell."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

import torch
from torch import nn


@dataclass
class SemanticResidualDiagnostics:
    qwen_norm: float
    colipri_norm: float
    delta_norm: float
    scaled_residual_norm: float
    fused_norm: float
    cosine_qwen_colipri: float
    effective_rho: float


class ColipriSemanticResidualFusion(nn.Module):
    """Fuse Qwen and adapted CoLiPri embeddings without replacing Qwen."""

    def __init__(
        self,
        colipri_text_encoder: nn.Module,
        tokenizer: Any,
        colipri_adapter: nn.Module,
        *,
        rho_init: float = 0.0,
        rho_max: float = 0.5,
    ) -> None:
        super().__init__()
        if rho_max <= 0:
            raise ValueError("rho_max must be positive")
        if abs(rho_init) >= rho_max:
            raise ValueError("abs(rho_init) must be smaller than rho_max")
        self.colipri_text_encoder = colipri_text_encoder
        self.tokenizer = tokenizer
        self.colipri_adapter = colipri_adapter
        self.register_buffer("rho_max", torch.tensor(float(rho_max)))
        normalized_init = torch.tensor(float(rho_init / rho_max))
        self.raw_rho = nn.Parameter(torch.atanh(normalized_init))
        self.colipri_text_encoder.requires_grad_(False).eval()
        self.colipri_forward_count = 0
        self.qwen_use_count = 0
        self.last_diagnostics: SemanticResidualDiagnostics | None = None

    @property
    def effective_rho(self) -> torch.Tensor:
        return self.rho_max * torch.tanh(self.raw_rho)

    def train(self, mode: bool = True):
        super().train(mode)
        self.colipri_text_encoder.eval()
        return self

    def encode_colipri(
        self,
        prompt_texts: Sequence[Sequence[str]],
        device: torch.device,
    ) -> torch.Tensor:
        if not prompt_texts or not prompt_texts[0]:
            raise ValueError("prompt_texts must have shape [batch, prompts]")
        prompt_count = len(prompt_texts[0])
        if any(len(row) != prompt_count for row in prompt_texts):
            raise ValueError("All batch items must contain the same number of prompts")
        flat = [prompt for row in prompt_texts for prompt in row]
        encoded = self.tokenizer(
            flat,
            max_length=512,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        self.colipri_forward_count += 1
        with torch.no_grad():
            text = self.colipri_text_encoder(
                encoded["input_ids"].to(device),
                encoded["attention_mask"].to(device),
                pool=True,
                normalize=True,
            )
        return text.reshape(len(prompt_texts), prompt_count, -1)

    @staticmethod
    def _canonical_qwen(qwen_embeddings: torch.Tensor) -> tuple[torch.Tensor, bool]:
        if qwen_embeddings.ndim == 3:
            return qwen_embeddings.unsqueeze(2), True
        if qwen_embeddings.ndim == 4 and qwen_embeddings.shape[2] == 1:
            return qwen_embeddings, False
        raise ValueError(
            "qwen_embeddings must be [B,N,D] or [B,N,1,D], got "
            f"{tuple(qwen_embeddings.shape)}"
        )

    def fuse(
        self,
        qwen_embeddings: torch.Tensor,
        prompt_texts: Sequence[Sequence[str]],
    ) -> torch.Tensor:
        qwen, remove_singleton = self._canonical_qwen(qwen_embeddings)
        if len(prompt_texts) != qwen.shape[0] or any(
            len(row) != qwen.shape[1] for row in prompt_texts
        ):
            raise ValueError("Prompt text shape does not match Qwen embedding shape")
        self.qwen_use_count += 1
        colipri = self.encode_colipri(prompt_texts, qwen.device)
        adapted = self.colipri_adapter(colipri).unsqueeze(2).to(qwen.dtype)
        if adapted.shape != qwen.shape:
            raise ValueError(
                f"Adapted CoLiPri/Qwen shape mismatch: {adapted.shape} != {qwen.shape}"
            )

        # rho=0 is the exact Qwen baseline; rho=1 is direct CoLiPri replacement.
        delta_q = adapted - qwen
        scaled_residual = self.effective_rho.to(qwen.dtype) * delta_q
        fused = qwen + scaled_residual
        with torch.no_grad():
            qwen_flat = qwen.detach().float().flatten(0, 2)
            colipri_flat = adapted.detach().float().flatten(0, 2)
            cosine = torch.nn.functional.cosine_similarity(
                qwen_flat, colipri_flat, dim=-1
            )
            self.last_diagnostics = SemanticResidualDiagnostics(
                qwen_norm=float(qwen_flat.norm(dim=-1).mean().item()),
                colipri_norm=float(colipri_flat.norm(dim=-1).mean().item()),
                delta_norm=float(delta_q.detach().float().flatten(0, 2).norm(dim=-1).mean().item()),
                scaled_residual_norm=float(
                    scaled_residual.detach().float().flatten(0, 2).norm(dim=-1).mean().item()
                ),
                fused_norm=float(fused.detach().float().flatten(0, 2).norm(dim=-1).mean().item()),
                cosine_qwen_colipri=float(cosine.mean().item()),
                effective_rho=float(self.effective_rho.detach().item()),
            )
        return fused.squeeze(2) if remove_singleton else fused


class SemanticResidualHybridVoxTell(nn.Module):
    """Run unchanged VoxTell with Qwen plus a gated CoLiPri semantic residual."""

    def __init__(
        self,
        voxtell: nn.Module,
        fusion: ColipriSemanticResidualFusion,
    ) -> None:
        super().__init__()
        self.voxtell = voxtell
        self.fusion = fusion

    def forward(
        self,
        image: torch.Tensor,
        qwen_embeddings: torch.Tensor,
        prompt_texts: Sequence[Sequence[str]],
    ):
        fused = self.fusion.fuse(qwen_embeddings, prompt_texts)
        return self.voxtell(image, fused)
