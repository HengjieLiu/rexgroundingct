"""Final-decoder category-2d specialist for the matched L/LD screen.

The specialist is attached to an already initialized ExperimentalVoxTellModel.
It deliberately leaves every original module intact and replaces only the bound
S3 decode helper.  A fixed category index selects the copied final decoder/head;
all other prompts execute and return the original S3 result.
"""

from __future__ import annotations

import copy
import math
import types
from typing import List

import torch
from torch import nn


CATEGORY_2D_INDEX = 10
ORACLE_CONDITION_NAMES = (
    "learned",
    "zero",
    "oracle_025",
    "oracle_050",
    "oracle_100",
    "shifted_025",
    "shifted_050",
    "shifted_100",
)


class SkipFusion2d(nn.Module):
    def __init__(self, channels: int, bottleneck: int = 16) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv3d(3 * channels + 1, bottleneck, 1),
            nn.GELU(),
            nn.Conv3d(bottleneck, bottleneck, 3, padding=1, groups=bottleneck),
            nn.GELU(),
            nn.Conv3d(bottleneck, channels, 1),
        )
        nn.init.zeros_(self.network[-1].weight)
        nn.init.zeros_(self.network[-1].bias)

    def forward(
        self,
        ungated_skip: torch.Tensor,
        gated_skip: torch.Tensor,
        attention: torch.Tensor,
    ) -> torch.Tensor:
        delta = gated_skip - ungated_skip
        value = torch.cat((ungated_skip, gated_skip, delta, attention), dim=1)
        # The frozen VoxTell trunk emits BF16 activations on the cluster while
        # the small trainable residual heads intentionally retain FP32 master
        # parameters.  Run the inexpensive heads in their parameter dtype and
        # cast only the residual back before adding it to the frozen path.
        value = value.to(dtype=self.network[0].weight.dtype)
        return self.network(value).to(dtype=gated_skip.dtype)


class DetectionHeatmap2d(nn.Module):
    def __init__(self, channels: int, bottleneck: int = 16, foreground_prior: float = 0.01) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv3d(4 * channels + 1, bottleneck, 1),
            nn.GroupNorm(4, bottleneck),
            nn.GELU(),
            nn.Conv3d(bottleneck, bottleneck, 3, padding=1, groups=bottleneck),
            nn.GELU(),
            nn.Conv3d(bottleneck, 1, 1),
        )
        nn.init.zeros_(self.network[-1].weight)
        nn.init.constant_(self.network[-1].bias, math.log(foreground_prior / (1.0 - foreground_prior)))

    def forward(
        self,
        previous_feature: torch.Tensor,
        ungated_skip: torch.Tensor,
        gated_skip: torch.Tensor,
        attention: torch.Tensor,
    ) -> torch.Tensor:
        delta = gated_skip - ungated_skip
        value = torch.cat(
            (previous_feature, ungated_skip, gated_skip, delta, attention), dim=1
        )
        return self.network(value.to(dtype=self.network[0].weight.dtype))


class DetectionCoupling2d(nn.Module):
    def __init__(self, channels: int, bottleneck: int = 16) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv3d(channels + 1, bottleneck, 1),
            nn.GELU(),
            nn.Conv3d(bottleneck, channels, 1),
        )
        nn.init.zeros_(self.network[-1].weight)
        nn.init.zeros_(self.network[-1].bias)

    def forward(self, probability: torch.Tensor, base_skip: torch.Tensor) -> torch.Tensor:
        value = torch.cat((probability, base_skip * probability), dim=1)
        value = value.to(dtype=self.network[0].weight.dtype)
        return self.network(value).to(dtype=base_skip.dtype)


class Category2dSpecialist(nn.Module):
    """Copied final decoder/head plus zero-initialized residual additions."""

    def __init__(self, model: nn.Module, bottleneck: int = 16) -> None:
        super().__init__()
        channels = int(model.encoder.output_channels[0])
        self.channels = channels
        self.final_decoder = copy.deepcopy(model.decoder.stages[-1])
        # VoxTell's consumed full-resolution segmentation head projects the
        # prompt query to the channel vector used by the final einsum.
        self.segmentation_head = copy.deepcopy(model.project_to_decoder_channels[0])
        self.fusion = SkipFusion2d(channels, bottleneck)
        self.detection_head = DetectionHeatmap2d(channels, bottleneck)
        self.detection_coupling = DetectionCoupling2d(channels, bottleneck)


def _decode_prompt_with_s3_specialist(
    self,
    skips: List[torch.Tensor],
    mask_embeddings: List[torch.Tensor],
    query: torch.Tensor,
    gate_scale: float | torch.Tensor = 1.0,
    gate_scales_by_scale: dict[str, float | torch.Tensor] | None = None,
    fullres_refinement_scale: float | torch.Tensor = 1.0,
    joint_fusion_scale: float | torch.Tensor = 0.0,
    adaptive_rho_category_indices: torch.Tensor | None = None,
    adaptive_rho_active_mask: torch.Tensor | None = None,
    category_router_indices: torch.Tensor | None = None,
    target_attention_adapter_active_mask: torch.Tensor | None = None,
) -> List[torch.Tensor]:
    if any(
        value is not None
        for value in (
            getattr(self, "adaptive_rho_adapter", None),
            getattr(self, "category_attention_router", None),
            getattr(self, "target_attention_adapter", None),
            getattr(self, "s3_fullres_attention_refinement", None),
            getattr(self, "s3_joint_fusion_head", None),
        )
    ):
        raise RuntimeError("The category-2d specialist requires the exact unmodified S3@9000 path")
    if category_router_indices is None:
        active = torch.zeros(skips[0].shape[0], dtype=torch.bool, device=skips[0].device)
    else:
        active = category_router_indices.to(device=skips[0].device, dtype=torch.long).eq(
            CATEGORY_2D_INDEX
        )

    decoder = self.decoder
    specialist = self.category_2d_specialist
    lres_input = skips[-1]
    seg_outputs: list[torch.Tensor] = []
    reversed_embeddings = mask_embeddings[::-1]
    for stage_idx in range(len(decoder.stages)):
        previous_feature = decoder.transpconvs[stage_idx](lres_input)
        ungated_skip = skips[-(stage_idx + 2)]
        skip = ungated_skip
        scale = self.s3_attention_decoder_stage_to_scale.get(stage_idx)
        attention = None
        if scale is not None:
            stage_gate_scale = gate_scale if gate_scales_by_scale is None else gate_scales_by_scale.get(scale, gate_scale)
            gate = self.s3_attention_gate if scale == "1/2" else self.s3_extra_attention_gates[self._s2_scale_key(scale)]
            gated, attention = gate(skip, previous_feature, query, gate_scale=stage_gate_scale)
            skip = gated[:, 0]
            self.last_s3_attention_maps[scale].append(attention)
            attention_logits = getattr(gate, "last_attention_logits", None)
            if attention_logits is not None:
                self.last_s3_attention_logits.setdefault(scale, []).append(attention_logits)

        original_feature = decoder.stages[stage_idx](torch.cat((previous_feature, skip), dim=1))
        if stage_idx == len(decoder.stages) - 1:
            if scale != "1/1" or attention is None:
                raise RuntimeError("The category-2d specialist did not receive the full-resolution S3 gate")
            original_logit = torch.einsum(
                "b c h w d, b n c -> b n h w d", original_feature, reversed_embeddings[-1]
            )
            if not bool(active.any()):
                # The non-2d contract is a true bypass: no specialist module is
                # executed, and the untouched original tensor is returned.
                seg_outputs.append(original_logit)
            else:
                attention_channel = attention[:, 0]
                fused_base = skip + specialist.fusion(ungated_skip, skip, attention_channel)
                detection_logit = specialist.detection_head(
                    previous_feature, ungated_skip, skip, attention_channel
                )
                detection_probability = detection_logit.sigmoid()
                specialist_embedding = specialist.segmentation_head(query)
                oracle_context = getattr(self, "category_2d_oracle_context", None)
                if oracle_context is None:
                    specialist_skip = fused_base + specialist.detection_coupling(
                        detection_probability, fused_base
                    )
                    specialist_feature = specialist.final_decoder(
                        torch.cat((previous_feature, specialist_skip), dim=1)
                    )
                    specialist_logit = torch.einsum(
                        "b c h w d, b n c -> b n h w d",
                        specialist_feature,
                        specialist_embedding,
                    )
                    selector = active[:, None, None, None, None]
                    final_logit = torch.where(selector, specialist_logit, original_logit)
                else:
                    if not bool(active.all()):
                        raise RuntimeError(
                            "Oracle conversion mode requires an all-category-2d batch"
                        )
                    oracle = oracle_context["oracle"].to(
                        device=fused_base.device, dtype=detection_probability.dtype
                    )
                    shifted = oracle_context["shifted"].to(
                        device=fused_base.device, dtype=detection_probability.dtype
                    )
                    if oracle.shape != detection_probability.shape or shifted.shape != detection_probability.shape:
                        raise ValueError(
                            "Oracle maps must match learned detection probability: "
                            f"{tuple(oracle.shape)}, {tuple(shifted.shape)}, "
                            f"{tuple(detection_probability.shape)}"
                        )
                    probabilities = (
                        detection_probability,
                        torch.zeros_like(detection_probability),
                        torch.lerp(detection_probability, oracle, 0.25).clamp_(0, 1),
                        torch.lerp(detection_probability, oracle, 0.50).clamp_(0, 1),
                        oracle.clamp(0, 1),
                        torch.lerp(detection_probability, shifted, 0.25).clamp_(0, 1),
                        torch.lerp(detection_probability, shifted, 0.50).clamp_(0, 1),
                        shifted.clamp(0, 1),
                    )
                    condition_logits = []
                    residual_mean_abs = []
                    residual_max_abs = []
                    residual_l2_sq = []
                    residual_difference_mean_abs = []
                    learned_residual = None
                    for probability in probabilities:
                        residual = specialist.detection_coupling(probability, fused_base)
                        if learned_residual is None:
                            learned_residual = residual
                        specialist_feature = specialist.final_decoder(
                            torch.cat((previous_feature, fused_base + residual), dim=1)
                        )
                        condition_logits.append(
                            torch.einsum(
                                "b c h w d, b n c -> b n h w d",
                                specialist_feature,
                                specialist_embedding,
                            )
                        )
                        residual_float = residual.float()
                        residual_mean_abs.append(residual_float.abs().mean(dim=1, keepdim=True))
                        residual_max_abs.append(residual_float.abs().amax(dim=1, keepdim=True))
                        residual_l2_sq.append(residual_float.square().sum(dim=1, keepdim=True))
                        residual_difference_mean_abs.append(
                            (residual_float - learned_residual.float()).abs().mean(
                                dim=1, keepdim=True
                            )
                        )
                    final_logit = torch.cat(condition_logits, dim=1)
                    self.last_2d_oracle_diagnostics = {
                        "condition_names": ORACLE_CONDITION_NAMES,
                        "learned_detection_probability": detection_probability.detach(),
                        "residual_mean_abs": torch.cat(residual_mean_abs, dim=1).detach(),
                        "residual_max_abs": torch.cat(residual_max_abs, dim=1).detach(),
                        "residual_l2_sq": torch.cat(residual_l2_sq, dim=1).detach(),
                        "residual_difference_mean_abs": torch.cat(
                            residual_difference_mean_abs, dim=1
                        ).detach(),
                        "base_skip_l2_sq": fused_base.float().square().sum(
                            dim=1, keepdim=True
                        ).detach(),
                        "shared_feature_token": (
                            int(previous_feature.data_ptr()),
                            int(ungated_skip.data_ptr()),
                            int(skip.data_ptr()),
                            int(attention_channel.data_ptr()),
                            int(fused_base.data_ptr()),
                        ),
                    }
                seg_outputs.append(final_logit)
                self.last_2d_detection_logits.append(detection_logit)
                self.last_2d_specialist_active.append(active.detach())
                if getattr(self, "capture_2d_detection_as_attention", False):
                    attention_selector = active[:, None, None, None, None, None]
                    self.last_s3_attention_maps["1/1"][-1] = torch.where(
                        attention_selector, detection_probability[:, None], attention
                    )
        elif stage_idx >= len(decoder.stages) - len(reversed_embeddings):
            embedding = reversed_embeddings.pop(0)
            batch_size, _, channels = embedding.shape
            reshaped = embedding.view(batch_size, decoder.num_heads, -1)
            fusion = torch.einsum(
                "b c h w d, b n c -> b n h w d", original_feature, reshaped
            )
            original_feature = torch.cat((original_feature, fusion), dim=1)
            seg_outputs.append(decoder.seg_layers[stage_idx](original_feature))
        lres_input = original_feature
    seg_outputs = seg_outputs[::-1]
    return seg_outputs if decoder.deep_supervision else seg_outputs[:1]


def attach_category_2d_specialist(
    model: nn.Module,
    *,
    bottleneck: int = 16,
    capture_detection_as_attention: bool = False,
) -> nn.Module:
    """Attach the specialist once and install its prompt decode method."""
    if getattr(model, "category_2d_specialist", None) is None:
        model.category_2d_specialist = Category2dSpecialist(model, bottleneck=bottleneck)
    object.__setattr__(
        model,
        "_decode_prompt_with_s3",
        types.MethodType(_decode_prompt_with_s3_specialist, model),
    )
    model.capture_2d_detection_as_attention = bool(capture_detection_as_attention)
    model.category_2d_oracle_context = None
    model.last_2d_detection_logits = []
    model.last_2d_specialist_active = []
    model.last_2d_oracle_diagnostics = None
    return model


def reset_specialist_captures(model: nn.Module) -> None:
    model.last_2d_detection_logits = []
    model.last_2d_specialist_active = []
    model.last_2d_oracle_diagnostics = None


def set_category_2d_oracle_context(
    model: nn.Module,
    oracle: torch.Tensor,
    shifted: torch.Tensor,
) -> None:
    """Install patch-aligned inference-only maps at the coupling input."""
    model.category_2d_oracle_context = {"oracle": oracle, "shifted": shifted}


def clear_category_2d_oracle_context(model: nn.Module) -> None:
    model.category_2d_oracle_context = None
