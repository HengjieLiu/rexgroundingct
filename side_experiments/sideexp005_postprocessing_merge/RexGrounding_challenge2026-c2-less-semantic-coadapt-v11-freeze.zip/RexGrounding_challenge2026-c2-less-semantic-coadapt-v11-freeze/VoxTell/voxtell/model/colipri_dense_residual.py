"""Baseline-preserving single-scale CoLiPri residual for frozen VoxTell logits."""

from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn


def affine_resample_xyz_to_voxtell_dhw(
    source_xyz: torch.Tensor,
    source_affine: torch.Tensor,
    target_affine: torch.Tensor,
    target_dhw: tuple[int, int, int],
) -> torch.Tensor:
    """Resample a differentiable CXYZ field into VoxTell's CDHW=(CZ,Y,X)."""
    if source_xyz.ndim != 5:
        raise ValueError(f"source_xyz must be [B,C,X,Y,Z], got {source_xyz.shape}")
    batch, channels, sx, sy, sz = source_xyz.shape
    if source_affine.ndim == 2:
        source_affine = source_affine[None].expand(batch, -1, -1)
    if target_affine.ndim == 2:
        target_affine = target_affine[None].expand(batch, -1, -1)
    if source_affine.shape != (batch, 4, 4) or target_affine.shape != (batch, 4, 4):
        raise ValueError("Affine batch shape mismatch")

    td, th, tw = map(int, target_dhw)
    x = torch.arange(tw, device=source_xyz.device, dtype=torch.float32)
    y = torch.arange(th, device=source_xyz.device, dtype=torch.float32)
    z = torch.arange(td, device=source_xyz.device, dtype=torch.float32)
    xx, yy, zz = torch.meshgrid(x, y, z, indexing="ij")
    target_indices = torch.stack(
        (xx, yy, zz, torch.ones_like(xx)), dim=-1
    ).reshape(-1, 4).T
    transform = torch.linalg.solve(
        source_affine.float(), target_affine.float()
    )
    source_indices = torch.einsum("bij,jn->bin", transform, target_indices)
    source_indices = source_indices[:, :3].reshape(batch, 3, tw, th, td)

    def normalize(values: torch.Tensor, size: int) -> torch.Tensor:
        return 2.0 * values / max(size - 1, 1) - 1.0

    # grid_sample input dimensions are D=X, H=Y, W=Z. Its grid coordinate
    # order is therefore (Z, Y, X).
    grid = torch.stack(
        (
            normalize(source_indices[:, 2], sz),
            normalize(source_indices[:, 1], sy),
            normalize(source_indices[:, 0], sx),
        ),
        dim=-1,
    )
    sampled_xyz = F.grid_sample(
        source_xyz.float(), grid, mode="bilinear", padding_mode="zeros", align_corners=True
    )
    return sampled_xyz.permute(0, 1, 4, 3, 2).contiguous()


class ColipriDenseResidual(nn.Module):
    """Prompt-conditioned residual; the final zero init preserves base logits."""

    def __init__(
        self,
        image_dim: int = 768,
        text_dim: int = 768,
        hidden_dim: int = 32,
    ) -> None:
        super().__init__()
        if image_dim != text_dim:
            raise ValueError(
                "B2 compatibility requires image/text features in the same native joint space"
            )
        self.image_adapter = nn.Sequential(
            nn.Conv3d(image_dim, hidden_dim, 1, bias=False),
            nn.GroupNorm(8, hidden_dim),
            nn.GELU(),
        )
        self.text_conditioner = nn.Sequential(
            nn.Linear(text_dim, hidden_dim * 2),
            nn.Tanh(),
        )
        self.residual_body = nn.Sequential(
            nn.Conv3d(hidden_dim + 1, hidden_dim, 3, padding=1, bias=False),
            nn.GroupNorm(8, hidden_dim),
            nn.GELU(),
        )
        self.output_head = nn.Conv3d(hidden_dim, 1, 1, bias=True)
        nn.init.zeros_(self.output_head.weight)
        nn.init.zeros_(self.output_head.bias)

    def dense_logits(
        self,
        image_features: torch.Tensor,
        text_features: torch.Tensor,
        *,
        text_enabled: bool = True,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if image_features.ndim != 5 or text_features.ndim != 3:
            raise ValueError("Expected image [B,C,X,Y,Z] and text [B,N,C]")
        image_unit = F.normalize(image_features.float(), dim=1, eps=1e-6)
        text_unit = F.normalize(text_features.float(), dim=-1, eps=1e-6)
        compatibility = torch.einsum("bcxyz,bnc->bnxyz", image_unit, text_unit)
        visual = self.image_adapter(image_features.float())
        batch, prompts = text_features.shape[:2]
        visual = visual[:, None].expand(-1, prompts, -1, -1, -1, -1)
        if text_enabled:
            scale, bias = self.text_conditioner(text_features.float()).chunk(2, dim=-1)
            scale = 1.0 + scale
        else:
            compatibility = torch.zeros_like(compatibility)
            scale = torch.ones(
                batch, prompts, visual.shape[2], device=visual.device, dtype=visual.dtype
            )
            bias = torch.zeros_like(scale)
        conditioned = visual * scale[..., None, None, None] + bias[..., None, None, None]
        fused = torch.cat((conditioned, compatibility[:, :, None]), dim=2)
        fused = fused.reshape(batch * prompts, fused.shape[2], *fused.shape[-3:])
        delta = self.output_head(self.residual_body(fused))
        return delta.reshape(batch, prompts, *delta.shape[-3:]), compatibility

    def forward(
        self,
        base_logits: torch.Tensor,
        image_features: torch.Tensor,
        text_features: torch.Tensor,
        source_affine: torch.Tensor,
        target_affine: torch.Tensor,
        *,
        text_enabled: bool = True,
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        delta_low, compatibility = self.dense_logits(
            image_features, text_features, text_enabled=text_enabled
        )
        batch, prompts = delta_low.shape[:2]
        source_size = tuple(int(value) * 8 for value in delta_low.shape[-3:])
        delta_xyz = F.interpolate(
            delta_low.reshape(batch * prompts, 1, *delta_low.shape[-3:]),
            size=source_size,
            mode="trilinear",
            align_corners=False,
        ).reshape(batch, prompts, *source_size)
        delta_dhw = affine_resample_xyz_to_voxtell_dhw(
            delta_xyz,
            source_affine,
            target_affine,
            tuple(base_logits.shape[-3:]),
        )
        final = base_logits.float() + delta_dhw
        return final, {
            "delta_low": delta_low,
            "delta_logits": delta_dhw,
            "compatibility": compatibility,
        }

    def trainable_counts(self) -> dict[str, int]:
        return {
            "image_adapter": sum(p.numel() for p in self.image_adapter.parameters()),
            "text_conditioner": sum(p.numel() for p in self.text_conditioner.parameters()),
            "residual_body": sum(p.numel() for p in self.residual_body.parameters()),
            "output_head": sum(p.numel() for p in self.output_head.parameters()),
            "total": sum(p.numel() for p in self.parameters()),
        }
