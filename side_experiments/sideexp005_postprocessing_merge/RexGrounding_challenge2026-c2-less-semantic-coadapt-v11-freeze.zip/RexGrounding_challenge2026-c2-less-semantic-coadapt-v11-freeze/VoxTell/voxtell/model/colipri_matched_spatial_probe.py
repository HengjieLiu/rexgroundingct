"""Matched lightweight prompt-conditioned decoder for frozen spatial probes."""

from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn


class ConvNormAct(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__(
            nn.Conv3d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.GroupNorm(min(8, out_channels), out_channels),
            nn.GELU(),
        )


class MatchedPromptSpatialProbe(nn.Module):
    """Map a 24^3 spatial grid and one embedding per prompt to 192^3 logits.

    The image and text adapters are the only source-specific layers. Every
    branch shares the same conditioning and spatial decoder design.
    """

    def __init__(
        self,
        image_channels: int,
        text_dim: int,
        common_dim: int = 128,
        image_only: bool = False,
        spatial_size: int = 24,
    ) -> None:
        super().__init__()
        self.image_channels = int(image_channels)
        self.text_dim = int(text_dim)
        self.common_dim = int(common_dim)
        self.image_only = bool(image_only)
        self.spatial_size = int(spatial_size)
        self.image_adapter = nn.Sequential(
            nn.Conv3d(image_channels, common_dim, 1, bias=False),
            nn.GroupNorm(8, common_dim),
            nn.GELU(),
        )
        self.text_projection = nn.Linear(text_dim, common_dim * 2)
        self.conditioning = ConvNormAct(common_dim, common_dim)
        self.decoder = nn.Sequential(
            nn.ConvTranspose3d(common_dim, 64, 2, stride=2, bias=False),
            ConvNormAct(64, 64),
            nn.ConvTranspose3d(64, 32, 2, stride=2, bias=False),
            ConvNormAct(32, 32),
            nn.ConvTranspose3d(32, 16, 2, stride=2, bias=False),
            ConvNormAct(16, 16),
            nn.Conv3d(16, 1, 1),
        )
        self.reset_parameters()

    def reset_parameters(self) -> None:
        for module in self.modules():
            if isinstance(module, (nn.Conv3d, nn.ConvTranspose3d)):
                nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
            elif isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                nn.init.zeros_(module.bias)

    def forward(self, image_features: torch.Tensor, text_features: torch.Tensor) -> torch.Tensor:
        if image_features.ndim != 5:
            raise ValueError(f"image_features must be [B,C,D,H,W], got {tuple(image_features.shape)}")
        if text_features.ndim != 3:
            raise ValueError(f"text_features must be [B,N,T], got {tuple(text_features.shape)}")
        if image_features.shape[0] != text_features.shape[0]:
            raise ValueError("Image/text batch sizes differ")
        spatial_shape = (self.spatial_size,) * 3
        if tuple(image_features.shape[2:]) != spatial_shape:
            image_features = F.interpolate(
                image_features.float(), size=spatial_shape, mode="trilinear", align_corners=False
            ).to(image_features.dtype)
        visual = self.image_adapter(image_features)
        batch, prompts = text_features.shape[:2]
        visual = visual[:, None].expand(-1, prompts, -1, -1, -1, -1)
        if self.image_only:
            scale = torch.ones(
                batch, prompts, self.common_dim, device=visual.device, dtype=visual.dtype
            )
            bias = torch.zeros_like(scale)
        else:
            scale, bias = self.text_projection(text_features).chunk(2, dim=-1)
            scale = 1.0 + torch.tanh(scale)
        fused = visual * scale[..., None, None, None] + bias[..., None, None, None]
        fused = fused.reshape(batch * prompts, self.common_dim, *spatial_shape)
        fused = self.conditioning(fused)
        logits = self.decoder(fused)
        return logits.reshape(batch, prompts, *logits.shape[-3:])

    def parameter_counts(self) -> dict[str, int]:
        adapter = sum(p.numel() for p in self.image_adapter.parameters())
        text = sum(p.numel() for p in self.text_projection.parameters())
        decoder = sum(p.numel() for p in self.conditioning.parameters()) + sum(
            p.numel() for p in self.decoder.parameters()
        )
        return {
            "image_adapter": adapter,
            "text_projection": text,
            "decoder": decoder,
            "total_trainable": sum(p.numel() for p in self.parameters() if p.requires_grad),
        }


def dice_bce_loss(logits: torch.Tensor, target: torch.Tensor) -> tuple[torch.Tensor, dict[str, float]]:
    target = target.to(dtype=logits.dtype)
    bce = F.binary_cross_entropy_with_logits(logits, target)
    probability = logits.sigmoid()
    reduce_dims = tuple(range(2, logits.ndim))
    intersection = (probability * target).sum(dim=reduce_dims)
    denominator = probability.sum(dim=reduce_dims) + target.sum(dim=reduce_dims)
    dice_loss = (1.0 - (2.0 * intersection + 1e-5) / (denominator + 1e-5)).mean()
    loss = bce + dice_loss
    return loss, {"bce": float(bce.detach()), "dice_loss": float(dice_loss.detach())}


def binary_dice(logits: torch.Tensor, target: torch.Tensor, threshold: float = 0.5) -> torch.Tensor:
    prediction = logits.sigmoid() >= threshold
    truth = target.bool()
    dims = tuple(range(2, logits.ndim))
    intersection = (prediction & truth).sum(dim=dims).float()
    denominator = prediction.sum(dim=dims) + truth.sum(dim=dims)
    return torch.where(denominator > 0, 2 * intersection / denominator, torch.ones_like(intersection))
