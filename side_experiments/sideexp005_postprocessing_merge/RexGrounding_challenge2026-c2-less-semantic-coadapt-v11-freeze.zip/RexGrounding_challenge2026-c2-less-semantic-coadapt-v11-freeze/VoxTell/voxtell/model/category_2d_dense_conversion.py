"""Two-level dense-prior conversion specialist for category 2d.

The module is attached after loading the frozen S3 checkpoint.  Non-category-2d
prompts execute the untouched decoder.  Category-2d prompts use exact copies of
the final two decoder stages and prompt head, with three zero-initialized prior
conversion residuals.  Consequently the category-2d result is bit-identical to
the original S3 result at attachment time.
"""

from __future__ import annotations

import copy
import math
import types
from typing import List

import torch
import torch.nn.functional as F
from torch import nn


CATEGORY_2D_INDEX = 10
DENSE_CONVERSION_CONDITIONS = ("learned", "zero", "oracle", "shifted_oracle")


def _parameter_dtype(module: nn.Module) -> torch.dtype:
    return next(module.parameters()).dtype


def _module_input(value: torch.Tensor, module: nn.Module) -> torch.Tensor:
    # Under CUDA autocast, retaining BF16 at the large spatial resolutions
    # avoids materializing multi-gigabyte FP32 concatenations; Conv3d still
    # accumulates gradients into FP32 master parameters.  CPU/unit-test and
    # non-autocast inference use the parameter dtype directly.
    return value if torch.is_autocast_enabled() else value.to(_parameter_dtype(module))


class DensePriorHead2d(nn.Module):
    """Half-resolution latent followed by a full-resolution dense prior."""

    def __init__(self, half_input_channels: int, full_channels: int) -> None:
        super().__init__()
        self.half_path = nn.Sequential(
            nn.Conv3d(half_input_channels, 32, 1),
            nn.GroupNorm(4, 32),
            nn.GELU(),
            nn.Conv3d(32, 32, 3, padding=1, groups=32),
            nn.GELU(),
            nn.Conv3d(32, 16, 1),
        )
        # latent + previous + ungated skip + gated skip + delta + attention
        full_input_channels = 16 + 4 * full_channels + 1
        self.full_path = nn.Sequential(
            nn.Conv3d(full_input_channels, 16, 1),
            nn.GroupNorm(4, 16),
            nn.GELU(),
            nn.Conv3d(16, 16, 3, padding=1, groups=16),
            nn.GELU(),
            nn.Conv3d(16, 1, 1),
        )
        nn.init.zeros_(self.full_path[-1].weight)
        nn.init.constant_(self.full_path[-1].bias, math.log(0.01 / 0.99))

    def half_latent(self, half_input: torch.Tensor) -> torch.Tensor:
        return self.half_path(_module_input(half_input, self.half_path))

    def full_logits(
        self,
        latent: torch.Tensor,
        previous: torch.Tensor,
        ungated_skip: torch.Tensor,
        gated_skip: torch.Tensor,
        attention: torch.Tensor,
    ) -> torch.Tensor:
        latent = F.interpolate(
            latent, size=previous.shape[2:], mode="trilinear", align_corners=False
        )
        value = torch.cat(
            (
                latent,
                previous,
                ungated_skip,
                gated_skip,
                gated_skip - ungated_skip,
                attention,
            ),
            dim=1,
        )
        return self.full_path(_module_input(value, self.full_path))


class PriorFeatureAdapter2d(nn.Module):
    def __init__(self, channels: int, bottleneck: int = 16) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv3d(2 * channels + 1, bottleneck, 1),
            nn.GELU(),
            nn.Conv3d(bottleneck, bottleneck, 3, padding=1, groups=bottleneck),
            nn.GELU(),
            nn.Conv3d(bottleneck, channels, 1),
        )
        nn.init.zeros_(self.network[-1].weight)
        nn.init.zeros_(self.network[-1].bias)

    def forward(self, feature: torch.Tensor, prior: torch.Tensor) -> torch.Tensor:
        if prior.shape[2:] != feature.shape[2:]:
            prior = F.interpolate(
                prior.float(), size=feature.shape[2:], mode="trilinear", align_corners=False
            )
        prior = prior.to(dtype=feature.dtype)
        value = torch.cat((feature, prior, feature * prior), dim=1)
        return self.network(_module_input(value, self.network)).to(feature.dtype)


class PriorLogitResidual2d(nn.Module):
    def __init__(self, channels: int, bottleneck: int = 16) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv3d(2 * channels + 1, bottleneck, 1),
            nn.GELU(),
            nn.Conv3d(bottleneck, bottleneck, 3, padding=1, groups=bottleneck),
            nn.GELU(),
            nn.Conv3d(bottleneck, 1, 1),
        )
        nn.init.zeros_(self.network[-1].weight)
        nn.init.zeros_(self.network[-1].bias)

    def forward(self, feature: torch.Tensor, prior: torch.Tensor) -> torch.Tensor:
        if prior.shape[2:] != feature.shape[2:]:
            prior = F.interpolate(
                prior.float(), size=feature.shape[2:], mode="trilinear", align_corners=False
            )
        prior = prior.to(dtype=feature.dtype)
        value = torch.cat((feature, prior, feature * prior), dim=1)
        return self.network(_module_input(value, self.network)).to(feature.dtype)


class Category2dDenseConversion(nn.Module):
    """Copied D_half/D_full/H plus dense head and conversion residuals."""

    def __init__(self, model: nn.Module, bottleneck: int = 16) -> None:
        super().__init__()
        if len(model.decoder.stages) < 2:
            raise ValueError("Dense conversion requires at least two decoder stages")
        self.half_stage_index = len(model.decoder.stages) - 2
        self.full_stage_index = len(model.decoder.stages) - 1
        full_channels = int(model.encoder.output_channels[0])
        half_channels = int(model.encoder.output_channels[1])
        self.half_channels = half_channels
        self.full_channels = full_channels
        self.D_2d_half = copy.deepcopy(model.decoder.stages[self.half_stage_index])
        self.D_2d_full = copy.deepcopy(model.decoder.stages[self.full_stage_index])
        self.H_2d = copy.deepcopy(model.project_to_decoder_channels[0])
        self.dense_prior_head = DensePriorHead2d(2 * half_channels, full_channels)
        self.half_adapter = PriorFeatureAdapter2d(2 * half_channels, bottleneck)
        self.full_adapter = PriorFeatureAdapter2d(2 * full_channels, bottleneck)
        self.logit_residual = PriorLogitResidual2d(full_channels, bottleneck)


def _selected_prior(model: nn.Module, predicted: torch.Tensor) -> torch.Tensor:
    context = getattr(model, "category_2d_dense_conversion_context", None)
    if context is None:
        return predicted
    mode = context.get("mode")
    if mode == "teacher":
        target = context["target"].to(device=predicted.device, dtype=predicted.dtype)
        if target.shape != predicted.shape:
            target = F.interpolate(target, size=predicted.shape[2:], mode="trilinear", align_corners=False)
        alpha = float(context["alpha"])
        return alpha * target + (1.0 - alpha) * predicted
    if mode == "override":
        override = context["prior"].to(device=predicted.device, dtype=predicted.dtype)
        if override.shape != predicted.shape:
            override = F.interpolate(override, size=predicted.shape[2:], mode="trilinear", align_corners=False)
        return override
    raise ValueError(f"Unknown dense conversion context mode: {mode!r}")


def _condition_priors(
    model: nn.Module, predicted: torch.Tensor
) -> tuple[tuple[str, ...], tuple[torch.Tensor, ...]]:
    context = getattr(model, "category_2d_dense_conversion_context", None)
    if context is None or context.get("mode") != "conditions":
        return ("single",), (_selected_prior(model, predicted),)
    values = []
    for key in ("oracle", "shifted_oracle"):
        value = context[key].to(device=predicted.device, dtype=predicted.dtype)
        if value.shape != predicted.shape:
            value = F.interpolate(
                value, size=predicted.shape[2:], mode="trilinear", align_corners=False
            )
        values.append(value)
    return DENSE_CONVERSION_CONDITIONS, (
        predicted, torch.zeros_like(predicted), values[0], values[1]
    )


def _decode_prompt_with_dense_conversion(
    self,
    skips: List[torch.Tensor],
    mask_embeddings: List[torch.Tensor],
    query: torch.Tensor,
    gate_scale: float | torch.Tensor = 1.0,
    gate_scales_by_scale: dict[str, float | torch.Tensor] | None = None,
    fullres_refinement_scale: float | torch.Tensor = 1.0,
    joint_fusion_scale: float | torch.Tensor = 0.0,
    adaptive_rho_category_indices: torch.Tensor | None = None,
    adaptive_rho_active_mask: torch.Tensor | None = None,
    category_router_indices: torch.Tensor | None = None,
    target_attention_adapter_active_mask: torch.Tensor | None = None,
) -> List[torch.Tensor]:
    del fullres_refinement_scale, joint_fusion_scale, adaptive_rho_category_indices
    del adaptive_rho_active_mask, target_attention_adapter_active_mask
    if any(
        value is not None
        for value in (
            getattr(self, "adaptive_rho_adapter", None),
            getattr(self, "category_attention_router", None),
            getattr(self, "target_attention_adapter", None),
            getattr(self, "s3_fullres_attention_refinement", None),
            getattr(self, "s3_joint_fusion_head", None),
        )
    ):
        raise RuntimeError("Dense conversion requires the exact unmodified S3@9000 path")
    if category_router_indices is None:
        active = torch.zeros(skips[0].shape[0], dtype=torch.bool, device=skips[0].device)
    else:
        active = category_router_indices.to(skips[0].device).long().reshape(skips[0].shape[0], -1)[:, 0].eq(CATEGORY_2D_INDEX)
    if bool(active.any()) and not bool(active.all()):
        raise RuntimeError("Mixed category-2d/non-2d batches are unsupported")

    decoder = self.decoder
    specialist = self.category_2d_dense_conversion
    lres_input = skips[-1]
    specialist_half = None
    specialist_half_embedding = None
    half_latent = None
    seg_outputs: list[torch.Tensor] = []
    reversed_embeddings = mask_embeddings[::-1]
    for stage_idx in range(len(decoder.stages)):
        previous = decoder.transpconvs[stage_idx](lres_input)
        ungated = skips[-(stage_idx + 2)]
        skip = ungated
        scale = self.s3_attention_decoder_stage_to_scale.get(stage_idx)
        attention = None
        if scale is not None:
            stage_scale = gate_scale if gate_scales_by_scale is None else gate_scales_by_scale.get(scale, gate_scale)
            gate = self.s3_attention_gate if scale == "1/2" else self.s3_extra_attention_gates[self._s2_scale_key(scale)]
            gated, attention = gate(skip, previous, query, gate_scale=stage_scale)
            skip = gated[:, 0]
            self.last_s3_attention_maps[scale].append(attention)
            attention_logits = getattr(gate, "last_attention_logits", None)
            if attention_logits is not None:
                self.last_s3_attention_logits.setdefault(scale, []).append(attention_logits)

        original_feature = decoder.stages[stage_idx](torch.cat((previous, skip), dim=1))
        if bool(active.all()) and stage_idx == specialist.half_stage_index:
            half_input = torch.cat((previous, skip), dim=1)
            half_latent = specialist.dense_prior_head.half_latent(half_input)
            # At update 0 this is an exact copied-stage call because R_half=0.
            q_seed = torch.full(
                (half_input.shape[0], 1, *half_input.shape[2:]),
                0.01, device=half_input.device, dtype=half_input.dtype,
            )
            r_half = specialist.half_adapter(half_input, q_seed)
            specialist_half = specialist.D_2d_half(half_input + r_half)
            self.last_2d_dense_residuals["R_half"] = r_half
            self.last_2d_dense_features["F_half"] = half_input

        if stage_idx == specialist.full_stage_index:
            original_logit = torch.einsum(
                "b c h w d, b n c -> b n h w d", original_feature, reversed_embeddings[-1]
            )
            if not bool(active.any()):
                seg_outputs.append(original_logit)
            else:
                if specialist_half is None or half_latent is None:
                    raise RuntimeError("Specialist half-resolution branch was not constructed")
                specialist_previous = decoder.transpconvs[stage_idx](specialist_half)
                specialist_skip = ungated
                specialist_attention = attention
                if scale is not None:
                    stage_scale = gate_scale if gate_scales_by_scale is None else gate_scales_by_scale.get(scale, gate_scale)
                    gate = self.s3_attention_gate if scale == "1/2" else self.s3_extra_attention_gates[self._s2_scale_key(scale)]
                    gated, specialist_attention = gate(
                        ungated, specialist_previous, query, gate_scale=stage_scale
                    )
                    specialist_skip = gated[:, 0]
                    # Expose the actually consumed category-2d attention.
                    self.last_s3_attention_maps[scale][-1] = specialist_attention
                    attention_logits = getattr(gate, "last_attention_logits", None)
                    if attention_logits is not None:
                        self.last_s3_attention_logits.setdefault(scale, [])[-1] = attention_logits
                if specialist_attention is None:
                    specialist_attention = torch.ones(
                        (ungated.shape[0], 1, 1, *ungated.shape[2:]),
                        device=ungated.device, dtype=ungated.dtype,
                    )
                attention_channel = specialist_attention[:, 0]
                q_logits = specialist.dense_prior_head.full_logits(
                    half_latent, specialist_previous, ungated, specialist_skip, attention_channel
                )
                q_pred = q_logits.sigmoid()
                condition_names, priors = _condition_priors(self, q_pred)
                condition_logits = []
                condition_delta_z = []
                condition_r_half = []
                condition_r_full = []
                embedding = specialist.H_2d(query)
                half_input = self.last_2d_dense_features["F_half"]
                for q_used in priors:
                    # Recompute the copied half stage with the selected prior.
                    r_half = specialist.half_adapter(half_input, q_used)
                    current_half = specialist.D_2d_half(half_input + r_half)
                    if specialist_half_embedding is not None:
                        half_fusion = torch.einsum(
                            "b c h w d, b n c -> b n h w d",
                            current_half,
                            specialist_half_embedding,
                        )
                        current_half = torch.cat((current_half, half_fusion), dim=1)
                    current_previous = decoder.transpconvs[stage_idx](current_half)
                    current_skip = ungated
                    if scale is not None:
                        gated, _ = gate(
                            ungated, current_previous, query, gate_scale=stage_scale
                        )
                        current_skip = gated[:, 0]
                    full_input = torch.cat((current_previous, current_skip), dim=1)
                    r_full = specialist.full_adapter(full_input, q_used)
                    specialist_feature = specialist.D_2d_full(full_input + r_full)
                    base_logit = torch.einsum(
                        "b c h w d, b n c -> b n h w d", specialist_feature, embedding
                    )
                    delta_z = specialist.logit_residual(specialist_feature, q_used)
                    condition_logits.append(base_logit + delta_z)
                    condition_delta_z.append(delta_z)
                    condition_r_half.append(r_half)
                    condition_r_full.append(r_full)
                final_logit = torch.cat(condition_logits, dim=1)
                seg_outputs.append(final_logit)
                self.last_2d_dense_prior_logits.append(q_logits)
                self.last_2d_dense_prior_probabilities.append(q_pred)
                self.last_2d_dense_priors_used.append(torch.cat(priors, dim=1))
                self.last_2d_dense_residuals.update(
                    {
                        "R_half": condition_r_half[0],
                        "R_full": condition_r_full[0],
                        "delta_z": condition_delta_z[0],
                    }
                )
                self.last_2d_dense_features.update(
                    {"F_full": full_input, "F_out": specialist_feature}
                )
                if len(priors) > 1:
                    self.last_2d_dense_condition_diagnostics = {
                        "condition_names": condition_names,
                        "Q_pred": q_pred.detach(),
                        "Q_used": torch.cat(priors, dim=1).detach(),
                        "delta_z": torch.cat(condition_delta_z, dim=1).detach(),
                    }
        elif stage_idx >= len(decoder.stages) - len(reversed_embeddings):
            embedding = reversed_embeddings.pop(0)
            batch_size, _, channels = embedding.shape
            reshaped = embedding.view(batch_size, decoder.num_heads, -1)
            if bool(active.all()) and stage_idx == specialist.half_stage_index:
                specialist_half_embedding = reshaped
                specialist_fusion = torch.einsum(
                    "b c h w d, b n c -> b n h w d", specialist_half, reshaped
                )
                specialist_half = torch.cat(
                    (specialist_half, specialist_fusion), dim=1
                )
            fusion = torch.einsum("b c h w d, b n c -> b n h w d", original_feature, reshaped)
            original_feature = torch.cat((original_feature, fusion), dim=1)
            seg_outputs.append(decoder.seg_layers[stage_idx](original_feature))
        lres_input = original_feature
    seg_outputs = seg_outputs[::-1]
    return seg_outputs if decoder.deep_supervision else seg_outputs[:1]


def attach_category_2d_dense_conversion(model: nn.Module, *, bottleneck: int = 16) -> nn.Module:
    if getattr(model, "category_2d_dense_conversion", None) is None:
        model.category_2d_dense_conversion = Category2dDenseConversion(model, bottleneck)
    object.__setattr__(
        model,
        "_decode_prompt_with_s3",
        types.MethodType(_decode_prompt_with_dense_conversion, model),
    )
    model.category_2d_dense_conversion_context = None
    reset_dense_conversion_captures(model)
    return model


def reset_dense_conversion_captures(model: nn.Module) -> None:
    model.last_2d_dense_prior_logits = []
    model.last_2d_dense_prior_probabilities = []
    model.last_2d_dense_priors_used = []
    model.last_2d_dense_residuals = {}
    model.last_2d_dense_features = {}
    model.last_2d_dense_condition_diagnostics = None


def set_dense_conversion_teacher_context(
    model: nn.Module, target: torch.Tensor, alpha: float
) -> None:
    if not 0.0 <= alpha <= 1.0:
        raise ValueError(alpha)
    model.category_2d_dense_conversion_context = {
        "mode": "teacher", "target": target, "alpha": float(alpha)
    }


def set_dense_conversion_override_context(model: nn.Module, prior: torch.Tensor) -> None:
    model.category_2d_dense_conversion_context = {"mode": "override", "prior": prior}


def set_dense_conversion_condition_context(
    model: nn.Module, oracle: torch.Tensor, shifted_oracle: torch.Tensor
) -> None:
    model.category_2d_dense_conversion_context = {
        "mode": "conditions", "oracle": oracle, "shifted_oracle": shifted_oracle
    }


def clear_dense_conversion_context(model: nn.Module) -> None:
    model.category_2d_dense_conversion_context = None
