"""Opt-in experimental prompt-grounding modules for VoxTell.

The released VoxTell implementation remains in ``voxtell_model.py``. This
module subclasses it so architecture experiments can be removed without
touching the baseline model.
"""

from __future__ import annotations

from typing import List

import torch
import torch.nn.functional as F
import torch.utils.checkpoint
from einops import rearrange, repeat
from torch import nn

from voxtell.model.adaptive_rho import AdaptiveRhoGateAdapter
from voxtell.model.category_adaptive_s3 import (
    AttentionConditionedResidualLogitAdapter3D,
    CategoryContinuousAttentionRouter,
)
from voxtell.model.dvsm_tie_probe import DVSMTieProbeAdapter
from voxtell.model.encoder_propagation import EncoderPropagationCrossAttention
from voxtell.model.encoder_residual_film import EncoderResidualFiLM3D
from voxtell.model.encoder_token_spatial import EncoderTokenSpatialConditioning3D
from voxtell.model.fan_image_text import (
    FANPreActivationImageWordBlock3D,
    FANImageWordFusionBlock3D,
    FANPreserveFusionProjection3D,
)
from voxtell.model.less_word_conditioning import LESSImageWordConditioning3D
from voxtell.model.bico_e345 import BiCoImageTextStage3D
from voxtell.model.medplex_staged_bert import StagedBert, StagedBertState
from voxtell.model.medplex_bifusion import MedPlexBiFusion
from voxtell.model.qwen_lora_bica import Stage3BidirectionalCrossAttention
from voxtell.model.token_image_text import TokenImageToTextBlock
from voxtell.model.voxtell_model import VoxTellModel, VoxTellNoFusionDecoder
from voxtell.model.word_global_interface import (
    LateWordCrossAttention3D,
    MultiCandidateWordBridge,
    SentenceCandidateRouter,
    load_fitted_bridge,
)


class LESSRepresentationAlignmentHead(nn.Module):
    """Small trainable metric space for C2 representation-alignment pilots.

    It never feeds a feature back into the segmentation path: the pilot loss
    reads native C2 features through this projection only.  This separation is
    intentional so any segmentation change is due to the auxiliary gradient
    into the intended C2 representation, not an added writeback module.
    """

    def __init__(self, image_dim: int, text_dim: int, alignment_dim: int) -> None:
        super().__init__()
        self.visual_projection = nn.Conv3d(image_dim, alignment_dim, 1, bias=False)
        self.text_projection = nn.Linear(text_dim, alignment_dim, bias=False)
        nn.init.xavier_uniform_(self.visual_projection.weight)
        nn.init.xavier_uniform_(self.text_projection.weight)

    def visual_map(self, feature: torch.Tensor) -> torch.Tensor:
        return self.visual_projection(feature)

    def text_vector(self, tokens: torch.Tensor) -> torch.Tensor:
        return F.normalize(self.text_projection(tokens.float()), dim=-1, eps=1e-8)


class BidirectionalPromptDecoderLayer(nn.Module):
    """One E1/E2 prompt-decoder layer with text<->image cross-attention.

    The original VoxTell prompt decoder has a Text->Image cross-attention path.
    This opt-in layer keeps that direction, adds non-causal text self-attention
    over [GLOBAL, token_1, ...], and adds an Image->Text branch so the selected
    image memory can become prompt-specific.
    """

    def __init__(
        self,
        d_model: int,
        nhead: int,
        dim_feedforward: int = 2048,
        dropout: float = 0.1,
        residual_scale: float = 1e-3,
        use_text_self_attention: bool = True,
        use_image_ffn: bool = True,
    ) -> None:
        super().__init__()
        self.use_text_self_attention = bool(use_text_self_attention)
        self.use_image_ffn = bool(use_image_ffn)
        self.text_self_attn = (
            nn.MultiheadAttention(d_model, nhead, dropout=dropout)
            if self.use_text_self_attention else None
        )
        self.text_to_image_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)
        self.image_to_text_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)

        self.text_linear1 = nn.Linear(d_model, dim_feedforward)
        self.text_linear2 = nn.Linear(dim_feedforward, d_model)
        self.image_linear1 = (
            nn.Linear(d_model, dim_feedforward) if self.use_image_ffn else None
        )
        self.image_linear2 = (
            nn.Linear(dim_feedforward, d_model) if self.use_image_ffn else None
        )

        self.text_self_norm = nn.LayerNorm(d_model) if self.use_text_self_attention else None
        self.text_cross_norm = nn.LayerNorm(d_model)
        self.text_ffn_norm = nn.LayerNorm(d_model)
        self.image_cross_norm = nn.LayerNorm(d_model)
        self.image_text_norm = nn.LayerNorm(d_model)
        self.image_ffn_norm = nn.LayerNorm(d_model) if self.use_image_ffn else None

        self.dropout = nn.Dropout(dropout)
        self.dropout_text_self = nn.Dropout(dropout)
        self.dropout_text_cross = nn.Dropout(dropout)
        self.dropout_text_ffn = nn.Dropout(dropout)
        self.dropout_image_cross = nn.Dropout(dropout)
        self.dropout_image_ffn = nn.Dropout(dropout)
        self.activation = nn.GELU()
        self.residual_scale = float(residual_scale)

    @staticmethod
    def _with_pos(tensor: torch.Tensor, pos: torch.Tensor | None) -> torch.Tensor:
        return tensor if pos is None else tensor + pos

    def forward(
        self,
        text: torch.Tensor,
        image: torch.Tensor,
        *,
        pos: torch.Tensor | None = None,
        text_key_padding_mask: torch.Tensor | None = None,
        capture_attention: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor, dict[str, torch.Tensor]]:
        attn: dict[str, torch.Tensor] = {}

        if self.text_self_attn is not None:
            assert self.text_self_norm is not None
            text_norm = self.text_self_norm(text)
            text_delta, text_self_weights = self.text_self_attn(
                text_norm,
                text_norm,
                text_norm,
                key_padding_mask=text_key_padding_mask,
                need_weights=capture_attention,
                average_attn_weights=False,
            )
            text = text + self.residual_scale * self.dropout_text_self(text_delta)
            if capture_attention:
                attn["text_self"] = text_self_weights.detach()

        text_norm = self.text_cross_norm(text)
        image_with_pos = self._with_pos(image, pos)
        text_delta, text_to_image_weights = self.text_to_image_attn(
            text_norm,
            image_with_pos,
            image,
            need_weights=capture_attention,
            average_attn_weights=False,
        )
        text = text + self.dropout_text_cross(text_delta)
        if capture_attention:
            attn["text_to_image"] = text_to_image_weights.detach()

        text_norm = self.text_ffn_norm(text)
        text_delta = self.text_linear2(
            self.dropout(self.activation(self.text_linear1(text_norm)))
        )
        text = text + self.dropout_text_ffn(text_delta)

        image_norm = self.image_cross_norm(image)
        text_for_image = self.image_text_norm(text)
        image_delta, image_to_text_weights = self.image_to_text_attn(
            self._with_pos(image_norm, pos),
            text_for_image,
            text,
            key_padding_mask=text_key_padding_mask,
            need_weights=capture_attention,
            average_attn_weights=False,
        )
        image = image + self.residual_scale * self.dropout_image_cross(image_delta)
        if capture_attention:
            attn["image_to_text"] = image_to_text_weights.detach()

        if self.image_linear1 is not None:
            assert self.image_linear2 is not None and self.image_ffn_norm is not None
            image_norm = self.image_ffn_norm(image)
            image_delta = self.image_linear2(
                self.dropout(self.activation(self.image_linear1(image_norm)))
            )
            image = image + self.residual_scale * self.dropout_image_ffn(image_delta)
        return text, image, attn


class BidirectionalPromptDecoder(nn.Module):
    """Stack of bidirectional prompt decoder layers used by E1/E2."""

    def __init__(
        self,
        *,
        d_model: int,
        nhead: int,
        num_layers: int = 6,
        dim_feedforward: int = 2048,
        dropout: float = 0.1,
        residual_scale: float = 1e-3,
        legacy_decoder: nn.Module | None = None,
        use_text_self_attention: bool = True,
        use_image_ffn: bool = True,
    ) -> None:
        super().__init__()
        self.layers = nn.ModuleList(
            [
                BidirectionalPromptDecoderLayer(
                    d_model=d_model,
                    nhead=nhead,
                    dim_feedforward=dim_feedforward,
                    dropout=dropout,
                    residual_scale=residual_scale,
                    use_text_self_attention=use_text_self_attention,
                    use_image_ffn=use_image_ffn,
                )
                for _ in range(num_layers)
            ]
        )
        self.text_norm = nn.LayerNorm(d_model)
        self.image_norm = nn.LayerNorm(d_model)
        self.capture_attention = False
        self.forward_count = 0
        self.last_attention: list[dict[str, torch.Tensor]] = []
        self.last_audit: dict[str, object] = {}
        if legacy_decoder is not None:
            self.copy_text_to_image_initialization(legacy_decoder)

    def copy_text_to_image_initialization(self, legacy_decoder: nn.Module) -> None:
        legacy_layers = list(getattr(legacy_decoder, "layers", []))
        for idx, layer in enumerate(self.layers):
            if idx >= len(legacy_layers):
                break
            legacy_layer = legacy_layers[idx]
            layer.text_to_image_attn.load_state_dict(legacy_layer.multihead_attn.state_dict())
            layer.text_cross_norm.load_state_dict(legacy_layer.norm2.state_dict())
            layer.text_ffn_norm.load_state_dict(legacy_layer.norm3.state_dict())
            layer.text_linear1.load_state_dict(legacy_layer.linear1.state_dict())
            layer.text_linear2.load_state_dict(legacy_layer.linear2.state_dict())
        legacy_norm = getattr(legacy_decoder, "norm", None)
        if legacy_norm is not None:
            self.text_norm.load_state_dict(legacy_norm.state_dict())

    def forward(
        self,
        text: torch.Tensor,
        image: torch.Tensor,
        *,
        pos: torch.Tensor | None = None,
        text_key_padding_mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        self.forward_count += 1
        self.last_attention = []
        capture_attention = bool(self.capture_attention)
        for layer in self.layers:
            text, image, attn = layer(
                text,
                image,
                pos=pos,
                text_key_padding_mask=text_key_padding_mask,
                capture_attention=capture_attention,
            )
            if capture_attention:
                self.last_attention.append(attn)
        text = self.text_norm(text)
        image = self.image_norm(image)
        self.last_audit = {
            "forward_count": int(self.forward_count),
            "text_shape": list(text.shape),
            "image_shape": list(image.shape),
            "layers": len(self.layers),
            "capture_attention": capture_attention,
        }
        return text, image


class SpatialGroundedPresenceHead(nn.Module):
    """Predict prompt presence from prompt-conditioned spatial evidence."""

    def __init__(
        self,
        feature_channels: int,
        query_dim: int,
        hidden_channels: int = 128,
        topk_frac: float = 0.01,
    ) -> None:
        super().__init__()
        if not 0 < topk_frac <= 1:
            raise ValueError(f"topk_frac must be in (0, 1], got {topk_frac}")
        self.feature_projection = nn.Conv3d(feature_channels, hidden_channels, 1)
        self.query_projection = nn.Linear(query_dim, hidden_channels)
        self.evidence_projection = nn.Linear(hidden_channels, 1)
        self.topk_frac = float(topk_frac)

    def forward(
        self,
        spatial_features: torch.Tensor,
        query_features: torch.Tensor,
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        if query_features.ndim == 4 and query_features.shape[2] == 1:
            query_features = query_features.squeeze(2)
        if spatial_features.ndim != 5 or query_features.ndim != 3:
            raise ValueError(
                "Expected spatial_features [B,C,D,H,W] and query_features [B,P,C], "
                f"got {tuple(spatial_features.shape)} and {tuple(query_features.shape)}"
            )
        spatial = self.feature_projection(spatial_features)[:, None]
        query = self.query_projection(query_features)[..., None, None, None]
        evidence = self.evidence_projection(
            torch.relu(spatial + query).movedim(2, -1)
        ).squeeze(-1)
        flat = evidence.flatten(start_dim=2)
        k = max(1, int(self.topk_frac * flat.shape[-1]))
        logits = flat.topk(k, dim=-1).values.mean(dim=-1)
        stats = {
            "presence_evidence_mean": evidence.detach().mean(),
            "presence_evidence_std": evidence.detach().std(),
            "presence_evidence_min": evidence.detach().amin(),
            "presence_evidence_max": evidence.detach().amax(),
            "presence_topk_mean": logits.detach().mean(),
        }
        return logits, stats


class PromptConditionedResidualSpatialAttentionGate3D(nn.Module):
    """Near-identity, prompt-conditioned suppression gate for one 3D skip."""

    def __init__(
        self,
        skip_channels: int,
        context_channels: int,
        query_dim: int,
        hidden_channels: int = 128,
        beta_init: float = -6.0,
    ) -> None:
        super().__init__()
        self.skip_projection = nn.Conv3d(skip_channels, hidden_channels, 1)
        self.context_projection = nn.Conv3d(context_channels, hidden_channels, 1)
        self.query_projection = nn.Linear(query_dim, hidden_channels)
        self.attention_projection = nn.Conv3d(hidden_channels, 1, 1)
        self.beta = nn.Parameter(torch.tensor(float(beta_init)))

    def forward(
        self,
        skip: torch.Tensor,
        context: torch.Tensor,
        query: torch.Tensor,
        rho_scale: float | torch.Tensor = 1.0,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if query.ndim == 4 and query.shape[2] == 1:
            query = query.squeeze(2)
        if query.ndim != 3:
            raise ValueError(f"Expected query [B,P,C], got {tuple(query.shape)}")
        if context.shape[2:] != skip.shape[2:]:
            context = F.interpolate(context, size=skip.shape[2:], mode="trilinear", align_corners=False)
        skip_projected = self.skip_projection(skip)[:, None]
        context_projected = self.context_projection(context)[:, None]
        query_projected = self.query_projection(query)[..., None, None, None]
        evidence = torch.relu(skip_projected + context_projected + query_projected)
        batch, prompts, channels, depth, height, width = evidence.shape
        attention = torch.sigmoid(
            self.attention_projection(evidence.reshape(batch * prompts, channels, depth, height, width))
            .reshape(batch, prompts, 1, depth, height, width)
        )
        rho = torch.sigmoid(self.beta)
        if not torch.is_tensor(rho_scale):
            rho_scale = torch.tensor(float(rho_scale), device=skip.device, dtype=skip.dtype)
        else:
            rho_scale = rho_scale.to(device=skip.device, dtype=skip.dtype)
        rho = rho * rho_scale
        while rho.ndim < attention.ndim:
            rho = rho.view(*rho.shape, *([1] * (attention.ndim - rho.ndim)))
        gated = skip[:, None] * (1 - rho * (1 - attention))
        return gated, attention


class LocalizedMultiScaleAttentionGate3D(nn.Module):
    """S2 additive attention using local, coarse-decoder, and prompt features."""

    def __init__(
        self,
        skip_channels: int,
        context_channels: int,
        query_dim: int,
        hidden_channels: int = 128,
        beta_init: float = -1.5,
    ) -> None:
        super().__init__()
        # Names mirror the additive-attention equation used in the S2 design.
        self.theta_x = nn.Conv3d(skip_channels, hidden_channels, 1)
        self.phi_g = nn.Conv3d(context_channels, hidden_channels, 1)
        self.w_t = nn.Linear(query_dim, hidden_channels)
        self.psi = nn.Conv3d(hidden_channels, 1, 1)
        self.beta = nn.Parameter(torch.tensor(float(beta_init)))

    def forward(
        self,
        skip: torch.Tensor,
        coarse_context: torch.Tensor,
        query: torch.Tensor,
        gate_scale: float | torch.Tensor = 1.0,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if query.ndim == 4 and query.shape[2] == 1:
            query = query.squeeze(2)
        if query.ndim != 3:
            raise ValueError(f"Expected query [B,P,C], got {tuple(query.shape)}")
        if coarse_context.shape[2:] != skip.shape[2:]:
            coarse_context = F.interpolate(
                coarse_context,
                size=skip.shape[2:],
                mode="trilinear",
                align_corners=False,
            )
        local = self.theta_x(skip)[:, None]
        coarse = self.phi_g(coarse_context)[:, None]
        prompt = self.w_t(query)[..., None, None, None]
        evidence = torch.relu(local + coarse + prompt)
        batch, prompts, channels, depth, height, width = evidence.shape
        attention = torch.sigmoid(
            self.psi(evidence.reshape(batch * prompts, channels, depth, height, width)).reshape(
                batch, prompts, 1, depth, height, width
            )
        )
        rho = torch.sigmoid(self.beta)
        if not torch.is_tensor(gate_scale):
            gate_scale = torch.tensor(float(gate_scale), device=skip.device, dtype=skip.dtype)
        else:
            gate_scale = gate_scale.to(device=skip.device, dtype=skip.dtype)
        rho = rho * gate_scale
        while rho.ndim < attention.ndim:
            rho = rho.view(*rho.shape, *([1] * (attention.ndim - rho.ndim)))
        gated = skip[:, None] * (1 - rho * (1 - attention))
        return gated, attention


class VoxelTextMatchingAttentionGate3D(nn.Module):
    """S3 cosine matching between each visual voxel and one text query."""

    def __init__(
        self,
        skip_channels: int,
        context_channels: int,
        query_dim: int,
        hidden_channels: int = 128,
        rho_mode: str = "fixed",
        rho_fixed: float = 0.25,
        logit_scale_init: float = 10.0,
    ) -> None:
        super().__init__()
        if rho_mode != "fixed":
            raise ValueError(f"S3 currently supports rho_mode='fixed' only, got {rho_mode!r}")
        if not 0.0 <= rho_fixed <= 1.0:
            raise ValueError(f"rho_fixed must be in [0, 1], got {rho_fixed}")
        if logit_scale_init <= 0:
            raise ValueError("logit_scale_init must be positive")
        self.skip_projection = nn.Conv3d(skip_channels, hidden_channels, 1)
        self.context_projection = nn.Conv3d(context_channels, hidden_channels, 1)
        self.visual_projection = nn.Conv3d(hidden_channels, hidden_channels, 1)
        self.text_projection = nn.Linear(query_dim, hidden_channels)
        self.logit_scale = nn.Parameter(torch.tensor(float(logit_scale_init)).log())
        self.bias = nn.Parameter(torch.zeros(()))
        self.rho_mode = rho_mode
        self.rho_fixed = float(rho_fixed)
        self.last_attention_logits: torch.Tensor | None = None

    def compute_attention(
        self,
        skip: torch.Tensor,
        coarse_context: torch.Tensor,
        query: torch.Tensor,
    ) -> torch.Tensor:
        if query.ndim == 4 and query.shape[2] == 1:
            query = query.squeeze(2)
        if query.ndim != 3:
            raise ValueError(f"Expected query [B,P,C], got {tuple(query.shape)}")
        if coarse_context.shape[2:] != skip.shape[2:]:
            coarse_context = F.interpolate(
                coarse_context,
                size=skip.shape[2:],
                mode="trilinear",
                align_corners=False,
            )

        visual = torch.relu(
            self.skip_projection(skip) + self.context_projection(coarse_context)
        )
        visual = F.normalize(self.visual_projection(visual), dim=1, eps=1e-6)
        text = F.normalize(self.text_projection(query), dim=-1, eps=1e-6)
        similarity = torch.einsum("bcdhw,bpc->bpdhw", visual, text)
        scale = self.logit_scale.exp().clamp(max=50.0)
        attention_logits = (scale * similarity + self.bias)[:, :, None]
        self.last_attention_logits = attention_logits
        return torch.sigmoid(attention_logits)

    def apply_attention(
        self,
        skip: torch.Tensor,
        attention: torch.Tensor,
        gate_scale: float | torch.Tensor = 1.0,
        rho_override: torch.Tensor | None = None,
    ) -> torch.Tensor:
        if rho_override is not None:
            rho = rho_override.to(device=skip.device, dtype=skip.dtype)
            if rho.ndim == 1:
                rho = rho[:, None]
            if rho.ndim != 2 or rho.shape[0] != skip.shape[0] or rho.shape[1] not in {
                1,
                skip.shape[1],
            }:
                raise ValueError(
                    "rho_override must be [B], [B,1], or [B,C], got "
                    f"{tuple(rho.shape)} for skip {tuple(skip.shape)}"
                )
            rho = rho[:, None, :, None, None, None]
            # Preserve the baseline gate's arithmetic order for exact FP16
            # step-0 equivalence. This is algebraically identical to
            # 1 - rho * (1 - attention), and remains suppression-only.
            return skip[:, None] * ((1.0 - rho) + rho * attention)
        if not torch.is_tensor(gate_scale):
            gate_scale = torch.tensor(float(gate_scale), device=skip.device, dtype=skip.dtype)
        else:
            gate_scale = gate_scale.to(device=skip.device, dtype=skip.dtype)
        rho = self.rho_fixed * gate_scale
        while rho.ndim < attention.ndim:
            rho = rho.view(*rho.shape, *([1] * (attention.ndim - rho.ndim)))
        return skip[:, None] * ((1.0 - rho) + rho * attention)

    def forward(
        self,
        skip: torch.Tensor,
        coarse_context: torch.Tensor,
        query: torch.Tensor,
        gate_scale: float | torch.Tensor = 1.0,
        rho_override: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        attention = self.compute_attention(skip, coarse_context, query)
        return (
            self.apply_attention(
                skip,
                attention,
                gate_scale=gate_scale,
                rho_override=rho_override,
            ),
            attention,
        )


class DecoderFeatureResidualSpatialGate3D(nn.Module):
    """Residually gate one decoder feature before it feeds the next decoder stage.

    ``strength`` is deliberately a direct, projected scalar rather than a
    sigmoid parameter. Initializing it to zero makes this branch an exact
    identity, which lets an existing S3 checkpoint be used as a controlled
    baseline. The training loop projects it to [0, 1] after every optimizer
    update so the module can only suppress low-attention regions.
    """

    def __init__(self, strength_init: float = 0.0) -> None:
        super().__init__()
        if not 0.0 <= strength_init <= 1.0:
            raise ValueError(f"strength_init must be in [0, 1], got {strength_init}")
        self.strength = nn.Parameter(torch.tensor(float(strength_init)))

    def forward(
        self,
        feature: torch.Tensor,
        attention: torch.Tensor,
        gate_scale: float | torch.Tensor = 1.0,
    ) -> torch.Tensor:
        if attention.ndim != 6 or attention.shape[1:3] != (1, 1):
            raise ValueError(
                "Decoder feature gating expects attention [B, 1, 1, D, H, W], "
                f"got {tuple(attention.shape)}"
            )
        if tuple(attention.shape[3:]) != tuple(feature.shape[2:]):
            attention = F.interpolate(
                attention[:, 0],
                size=feature.shape[2:],
                mode="trilinear",
                align_corners=False,
            )[:, None]
        attention = attention[:, 0]
        if not torch.is_tensor(gate_scale):
            gate_scale = torch.tensor(float(gate_scale), device=feature.device, dtype=feature.dtype)
        else:
            gate_scale = gate_scale.to(device=feature.device, dtype=feature.dtype)
        strength = self.strength.to(device=feature.device, dtype=feature.dtype) * gate_scale
        strength = strength.clamp(min=0.0, max=1.0)
        while strength.ndim < feature.ndim:
            strength = strength.view(*strength.shape, *([1] * (feature.ndim - strength.ndim)))
        return feature * ((1.0 - strength) + strength * attention)

    @torch.no_grad()
    def project_strength_(self) -> None:
        self.strength.clamp_(0.0, 1.0)


class FullResolutionAttentionConditionedRefinement3D(nn.Module):
    """Learn a prompt-conditioned residual update to final decoder features.

    The full-resolution S3 map is concatenated as one additional feature
    channel. The last projection is initialized to zero, so a newly attached
    module is an exact identity and can be compared fairly with its source
    S3 checkpoint.
    """

    def __init__(self, feature_channels: int, hidden_channels: int = 64) -> None:
        super().__init__()
        if feature_channels < 1 or hidden_channels < 1:
            raise ValueError("feature_channels and hidden_channels must be positive")
        self.input_projection = nn.Conv3d(feature_channels + 1, hidden_channels, 1)
        self.output_projection = nn.Conv3d(hidden_channels, feature_channels, 1)
        nn.init.zeros_(self.output_projection.weight)
        nn.init.zeros_(self.output_projection.bias)

    def forward(
        self,
        feature: torch.Tensor,
        attention: torch.Tensor,
        refinement_scale: float | torch.Tensor = 1.0,
    ) -> torch.Tensor:
        if feature.ndim != 5:
            raise ValueError(f"Expected feature [B,C,D,H,W], got {tuple(feature.shape)}")
        if attention.ndim != 6 or attention.shape[1:3] != (1, 1):
            raise ValueError(
                "Full-resolution refinement expects attention [B,1,1,D,H,W], "
                f"got {tuple(attention.shape)}"
            )
        attention = attention[:, 0]
        if tuple(attention.shape[2:]) != tuple(feature.shape[2:]):
            attention = F.interpolate(
                attention, size=feature.shape[2:], mode="trilinear", align_corners=False
            )
        if attention.shape[0] != feature.shape[0]:
            raise ValueError("Feature and attention batch dimensions must match")

        residual = self.output_projection(F.gelu(self.input_projection(torch.cat((feature, attention), dim=1))))
        if not torch.is_tensor(refinement_scale):
            refinement_scale = torch.tensor(
                float(refinement_scale), device=feature.device, dtype=feature.dtype
            )
        else:
            refinement_scale = refinement_scale.to(device=feature.device, dtype=feature.dtype)
        if refinement_scale.ndim == 1:
            if refinement_scale.shape[0] != feature.shape[0]:
                raise ValueError("Per-item refinement scale must have one value per batch item")
            refinement_scale = refinement_scale[:, None, None, None, None]
        elif refinement_scale.ndim != 0:
            raise ValueError("refinement_scale must be scalar or [B]")
        return feature + refinement_scale * residual


class S3JointResidualLogitFusion3D(nn.Module):
    """Late residual fusion of native segmentation and S3 attention logits.

    Unlike the S3 skip gates, this module never replaces or multiplicatively
    suppresses the baseline path.  It learns a zero-initialized correction from
    segmentation/attention agreement and disagreement features.  The attention
    input is detached by default so segmentation training cannot destroy the
    already useful S3 localization ranking.
    """

    def __init__(
        self,
        hidden_channels: int = 16,
        detach_attention: bool = True,
    ) -> None:
        super().__init__()
        if hidden_channels < 1:
            raise ValueError("hidden_channels must be positive")
        self.detach_attention = bool(detach_attention)
        # [seg_logit, calibrated_attention, interaction, rescue, suppress]
        self.input_projection = nn.Conv3d(5, hidden_channels, 1)
        self.context_projection = nn.Conv3d(hidden_channels, hidden_channels, 3, padding=1)
        self.output_projection = nn.Conv3d(hidden_channels, 1, 1)
        # Monotone per-head calibration. softplus(scale_raw) is always positive,
        # so this changes the operating point without reversing attention ranks.
        self.attention_scale_raw = nn.Parameter(torch.tensor(0.5413248546))
        self.attention_bias = nn.Parameter(torch.zeros(()))
        nn.init.zeros_(self.output_projection.weight)
        nn.init.zeros_(self.output_projection.bias)

    def forward(
        self,
        segmentation_logit: torch.Tensor,
        attention_logit: torch.Tensor,
        fusion_scale: float | torch.Tensor = 0.0,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if segmentation_logit.ndim != 5 or segmentation_logit.shape[1] != 1:
            raise ValueError(
                "Joint S3 fusion expects segmentation_logit [B,1,D,H,W], "
                f"got {tuple(segmentation_logit.shape)}"
            )
        if attention_logit.ndim == 6 and attention_logit.shape[1:3] == (1, 1):
            attention_logit = attention_logit[:, 0]
        if attention_logit.ndim != 5 or attention_logit.shape[1] != 1:
            raise ValueError(
                "Joint S3 fusion expects attention_logit [B,1,1,D,H,W] or [B,1,D,H,W], "
                f"got {tuple(attention_logit.shape)}"
            )
        if tuple(attention_logit.shape[2:]) != tuple(segmentation_logit.shape[2:]):
            attention_logit = F.interpolate(
                attention_logit.float(),
                size=segmentation_logit.shape[2:],
                mode="trilinear",
                align_corners=False,
            ).to(dtype=segmentation_logit.dtype)
        if self.detach_attention:
            attention_logit = attention_logit.detach()

        # Work in FP32 for stable calibration and disagreement features, then
        # return the correction in the native decoder dtype.
        seg = segmentation_logit.float()
        att_logit = attention_logit.float()
        monotone_scale = F.softplus(self.attention_scale_raw.float())
        calibrated = 2.0 * torch.sigmoid(
            monotone_scale * att_logit + self.attention_bias.float()
        ) - 1.0
        probability = torch.sigmoid(seg)
        positive_attention = calibrated.clamp_min(0.0)
        negative_attention = (-calibrated).clamp_min(0.0)
        features = torch.cat(
            (
                seg,
                calibrated,
                seg * calibrated,
                positive_attention * (1.0 - probability),
                negative_attention * probability,
            ),
            dim=1,
        )
        hidden = F.gelu(self.input_projection(features))
        hidden = F.gelu(self.context_projection(hidden))
        correction = self.output_projection(hidden)

        if not torch.is_tensor(fusion_scale):
            fusion_scale = torch.tensor(
                float(fusion_scale), device=seg.device, dtype=seg.dtype
            )
        else:
            fusion_scale = fusion_scale.to(device=seg.device, dtype=seg.dtype)
        if fusion_scale.ndim == 1:
            if fusion_scale.shape[0] != seg.shape[0]:
                raise ValueError("Per-item fusion scale must have one value per batch item")
            fusion_scale = fusion_scale[:, None, None, None, None]
        elif fusion_scale.ndim != 0:
            raise ValueError("fusion_scale must be scalar or [B]")
        applied_correction = fusion_scale * correction
        fused = seg + applied_correction
        return fused.to(dtype=segmentation_logit.dtype), applied_correction


class SampledFullResTextAlignmentHead3D(nn.Module):
    """Project high-resolution decoder features and prompt query into one metric space."""

    def __init__(
        self,
        feature_channels: int,
        query_dim: int,
        embedding_dim: int = 128,
    ) -> None:
        super().__init__()
        self.feature_projection = nn.Conv3d(feature_channels, embedding_dim, 1)
        self.query_projection = nn.Linear(query_dim, embedding_dim)
        self.forward_count = 0

    def sampled_cosine(
        self,
        sampled_features: torch.Tensor,
        query_features: torch.Tensor,
    ) -> torch.Tensor:
        """Project sampled voxels only; do not materialize a dense 3D map."""
        if query_features.ndim == 3:
            if query_features.shape[1] != 1:
                raise ValueError(f"Expected one prompt query, got {tuple(query_features.shape)}")
            query_features = query_features[:, 0]
        weight = self.feature_projection.weight.flatten(1)
        image = F.linear(sampled_features.float(), weight.float(), self.feature_projection.bias.float())
        query = self.query_projection(query_features.float())
        image = F.normalize(image, dim=-1, eps=1e-6)
        query = F.normalize(query, dim=-1, eps=1e-6)
        self.forward_count += 1
        return torch.einsum("bsc,bc->bs", image, query)

    def forward(
        self,
        spatial_features: torch.Tensor,
        query_features: torch.Tensor,
    ) -> torch.Tensor:
        if query_features.ndim == 4 and query_features.shape[2] == 1:
            query_features = query_features.squeeze(2)
        if query_features.ndim == 3:
            if query_features.shape[1] != 1:
                raise ValueError(
                    "Full-res S3 alignment expects one prompt query per decoder pass; "
                    f"got {tuple(query_features.shape)}"
                )
            query_features = query_features[:, 0]
        if spatial_features.ndim != 5 or query_features.ndim != 2:
            raise ValueError(
                "Expected spatial_features [B,C,D,H,W] and query_features [B,C], "
                f"got {tuple(spatial_features.shape)} and {tuple(query_features.shape)}"
            )
        image = F.normalize(self.feature_projection(spatial_features).float(), dim=1, eps=1e-6)
        query = F.normalize(self.query_projection(query_features).float(), dim=1, eps=1e-6)
        return torch.einsum("b c d h w, b c -> b d h w", image, query)


class OneHotLobeAdapter3D(nn.Sequential):
    """Small baseline-preserving five-lobe residual adapter."""

    def __init__(self, output_channels: int, hidden_channels: int = 16) -> None:
        if output_channels <= 0 or hidden_channels <= 0:
            raise ValueError("Adapter channel counts must be positive")
        super().__init__(
            nn.Conv3d(5, hidden_channels, kernel_size=1, bias=True),
            nn.GELU(),
            nn.Conv3d(
                hidden_channels,
                output_channels,
                kernel_size=1,
                bias=True,
            ),
        )
        # Do not add a second zero gate: this zero projection preserves the
        # baseline exactly while still receiving gradients on backward #1.
        nn.init.zeros_(self[2].weight)
        nn.init.zeros_(self[2].bias)


class GlobalSentenceImageFeedback(nn.Module):
    """One-sentence Image<-Text value update used between native decoder layers.

    With a single text key, scaled dot-product attention assigns probability one
    to that key for every image query.  The attention output is therefore a
    projected text value broadcast across image locations.  This low-rank value
    projection is algebraically equivalent while avoiding an unnecessary
    materialized [image_tokens, 1] attention map.
    """

    def __init__(self, dim: int, rank: int, init_scale: float) -> None:
        super().__init__()
        self.value_down = nn.Linear(dim, rank, bias=False)
        self.value_up = nn.Linear(rank, dim, bias=False)
        self.alpha = nn.Parameter(torch.tensor(float(init_scale)))
        self.forward_count = 0
        self.last_audit: dict[str, float | bool] = {}

    def forward(
        self,
        image_memory: torch.Tensor,
        sentence: torch.Tensor,
        *,
        enabled: bool,
    ) -> torch.Tensor:
        if image_memory.ndim != 3 or sentence.ndim != 3 or sentence.shape[0] != 1:
            raise ValueError(
                "Expected image memory [S,B,C] and one sentence [1,B,C], got "
                f"{tuple(image_memory.shape)} and {tuple(sentence.shape)}"
            )
        if image_memory.shape[1:] != sentence.shape[1:]:
            raise ValueError("Image-memory and sentence batch/channel dimensions must match")
        delta = self.value_up(self.value_down(sentence)).expand_as(image_memory)
        residual = self.alpha.to(dtype=image_memory.dtype) * delta
        applied = residual if enabled else torch.zeros_like(residual)
        output = image_memory + applied
        before = image_memory.detach().float()
        residual_float = applied.detach().float()
        after = output.detach().float()
        self.last_audit = {
            "alpha": float(self.alpha.detach().float().item()),
            "enabled": bool(enabled),
            "feedback_rel_l2": float(
                residual_float.norm().item() / max(before.norm().item(), 1e-12)
            ),
            "cosine_pre_post": float(
                F.cosine_similarity(
                    before.reshape(1, -1), after.reshape(1, -1), dim=1, eps=1e-12
                ).item()
            ),
            "delta_rms": float(residual_float.square().mean().sqrt().item()),
        }
        self.forward_count += 1
        return output


class ExperimentalVoxTellModel(VoxTellModel):
    """VoxTell with opt-in Presence V2 and residual spatial attention."""

    def __init__(
        self,
        *args,
        presence_head_type: str = "global",
        presence_detach_features: bool = False,
        presence_spatial_hidden_channels: int = 128,
        presence_spatial_topk_frac: float = 0.01,
        enable_prompt_spatial_attention: bool = False,
        spatial_attention_hidden_channels: int = 128,
        spatial_attention_beta_init: float = -6.0,
        spatial_attention_level: str | int = "auto_1over4",
        enable_s2_attention: bool = False,
        s2_attention_scales: tuple[str, ...] | list[str] = ("1/4", "1/2"),
        s2_attention_hidden_channels: int = 128,
        s2_beta_init: float = -1.5,
        enable_s3_voxel_text_matching_attention: bool = False,
        s3_attention_hidden_channels: int = 128,
        s3_rho_mode: str = "fixed",
        s3_rho_fixed: float = 0.25,
        s3_logit_scale_init: float = 10.0,
        s3_attention_scales: tuple[str, ...] | list[str] = ("1/2",),
        enable_s3_decoder_feature_gate: bool = False,
        s3_decoder_feature_gate_scales: tuple[str, ...] | list[str] = ("1/4",),
        s3_decoder_feature_gate_strength_init: float = 0.0,
        enable_s3_fullres_attention_refinement: bool = False,
        s3_fullres_refinement_hidden_channels: int = 64,
        enable_s3_joint_residual_fusion: bool = False,
        s3_joint_fusion_hidden_channels: int = 16,
        s3_joint_fusion_detach_attention: bool = True,
        enable_s3_fullres_sampled_alignment: bool = False,
        s3_fullres_alignment_dim: int = 128,
        dvsm_tie_probe: str = "none",
        dvsm_probe_dim: int = 128,
        dvsm_probe_depth: int = 2,
        dvsm_probe_heads: int = 4,
        dvsm_probe_pool_size: int = 12,
        dvsm_probe_zero_init: bool = True,
        lobe_input_mode: str = "none",
        lobe_embedding_dim: int = 4,
        token_image_text_mode: str = "original",
        token_image_text_hidden_dim: int = 2048,
        token_image_text_heads: int = 8,
        token_image_text_dropout: float = 0.1,
        token_image_text_init_seed: int = 260806,
        token_image_text_identity_init: bool = False,
        token_image_text_output_init_scale: float = 1.0,
        token_image_text_text_dim: int | None = None,
        fan_image_text_mode: str = "none",
        fan_image_text_levels: tuple[int, ...] | list[int] = (4, 5),
        fan_image_text_dim: int = 512,
        fan_image_text_heads: int = 8,
        fan_image_text_dropout: float = 0.1,
        fan_image_text_init_seed: int = 260812,
        fan_image_text_preserve_epsilon: float = 1e-3,
        fan_pre_activation_mode: bool = False,
        fan_pre_activation_init_seed: int = 260821,
        fan_pre_activation_residual_scale: float = 1e-3,
        bidir_prompt_decoder_mode: str = "none",
        bidir_prompt_num_layers: int = 6,
        bidir_prompt_heads: int = 8,
        bidir_prompt_dropout: float = 0.1,
        bidir_prompt_init_seed: int = 260815,
        bidir_prompt_residual_scale: float = 1e-3,
        bidir_prompt_lr: float | None = None,
        global_sentence_feedback_mode: str = "none",
        global_sentence_feedback_rank: int = 128,
        global_sentence_feedback_init_scale: float = 1e-3,
        global_sentence_feedback_init_seed: int = 260823,
        encoder_propagation_mode: str = "none",
        encoder_propagation_hidden_dim: int = 2048,
        encoder_propagation_heads: int = 8,
        encoder_propagation_dropout: float = 0.1,
        encoder_propagation_init_seed: int = 260810,
        encoder_residual_film_mode: str = "none",
        encoder_residual_film_hidden_dim: int = 512,
        encoder_residual_film_groups: int = 32,
        encoder_residual_film_init_seed: int = 260811,
        encoder_residual_film_gradient_checkpointing: bool = False,
        encoder_residual_film_stage: int = 3,
        encoder_token_spatial_mode: str = "none",
        encoder_token_spatial_stage: int = 3,
        encoder_token_spatial_hidden_dim: int = 256,
        encoder_token_spatial_heads: int = 8,
        encoder_token_spatial_dropout: float = 0.0,
        encoder_token_spatial_init_seed: int = 260813,
        encoder_token_spatial_connector_type: str = "dense",
        encoder_token_spatial_connector_init_scale: float = 5e-4,
        encoder_token_spatial_conditioned_skip: bool = False,
        encoder_token_spatial_skip_scale: float = 1.0,
        less_encoder_mode: str = "none",
        less_encoder_levels: tuple[int, ...] | list[int] = (2, 3, 4, 5),
        less_encoder_attention_dim: int = 256,
        less_encoder_heads: int = 8,
        less_encoder_dropout: float = 0.0,
        less_encoder_query_chunk_size: int = 4096,
        less_encoder_prompt_chunk_size: int = 1,
        less_encoder_init_seed: int = 260820,
        less_semantic_alignment_mode: str = "none",
        less_semantic_alignment_dim: int = 128,
        word_global_mode: str = "none",
        word_global_bridge_checkpoint: str | None = None,
        word_global_lr: float | None = None,
        word_global_b1_alpha: float = 0.01,
        word_global_b1_decoder_stage: int = 2,
        word_global_b1_seed: int = 260901,
        word_global_b3_candidates: int = 4,
        word_global_b3_epsilon: float = 1e-3,
        word_global_b3_router_scale: float = 0.1,
        word_global_b3_aggregation: str = "learned",
        word_global_b3_seed: int = 260903,
        medplex_mode: str = "none",
        medplex_bifusion_enabled: bool = True,
        medplex_heads: int = 8,
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)
        if medplex_mode not in {"none", "pubmedbert", "biomedclip"}:
            raise ValueError(f"Unknown MedPlex mode: {medplex_mode!r}")
        self.medplex_mode = str(medplex_mode)
        self.medplex_bifusion_enabled = bool(medplex_bifusion_enabled)
        self.medplex_staged_text: StagedBert | None = None
        self.medplex_fusions = nn.ModuleList(
            [MedPlexBiFusion(channels, heads=medplex_heads) for channels in (128, 256, 320, 320)]
        ) if self.medplex_mode != "none" and self.medplex_bifusion_enabled else nn.ModuleList()
        # Inference-only controls.  They are plain attributes, never checkpointed
        # or trainable, and default to the exact trained execution path.
        self.medplex_bifusion_stage_enabled = [True] * len(self.medplex_fusions)
        self.medplex_bifusion_text_to_image_enabled = True
        self.medplex_bifusion_image_to_text_enabled = True
        # Update-0 evaluation uses this scalar only as a trained-state sentinel:
        # zero selects the exact static-anchor bypass, while the first training
        # backward pass wakes it.  The active training path consumes online CLS
        # directly; attenuating it by this near-zero scalar would make the
        # supposedly trainable P0/B0 BERT controls functionally frozen.
        self.medplex_cls_gate = (
            nn.Parameter(torch.zeros(())) if self.medplex_mode != "none" else None
        )
        self.last_medplex_audit: dict[str, object] = {}
        if lobe_input_mode not in {
            "none",
            "scalar",
            "onehot",
            "embedding",
            "onehot_adapter",
        }:
            raise ValueError(f"Unknown lobe_input_mode: {lobe_input_mode!r}")
        self.lobe_input_mode = str(lobe_input_mode)
        self.lobe_embedding = None
        self.lobe_embedding_projection = None
        self.lobe_anatomy_adapter = None
        self.last_lobe_adapter_output_stats = {}
        if self.lobe_input_mode == "embedding":
            if lobe_embedding_dim <= 0:
                raise ValueError("lobe_embedding_dim must be positive")
            self.lobe_embedding = nn.Embedding(
                num_embeddings=6,
                embedding_dim=int(lobe_embedding_dim),
            )
            self.lobe_embedding_projection = nn.Conv3d(
                int(lobe_embedding_dim),
                self.encoder.output_channels[0],
                kernel_size=1,
                bias=True,
            )
            # Exact baseline-preserving initialization: the embedding can learn
            # immediately, while its spatial contribution starts at zero.
            nn.init.zeros_(self.lobe_embedding_projection.weight)
            nn.init.zeros_(self.lobe_embedding_projection.bias)
        elif self.lobe_input_mode == "onehot_adapter":
            self.lobe_anatomy_adapter = OneHotLobeAdapter3D(
                output_channels=self.encoder.output_channels[0],
                hidden_channels=16,
            )
        if presence_head_type not in {"global", "spatial_grounded"}:
            raise ValueError(f"Unknown presence_head_type: {presence_head_type}")
        self.presence_head_type = presence_head_type
        self.presence_detach_features = bool(presence_detach_features)
        self.enable_prompt_spatial_attention = bool(enable_prompt_spatial_attention)
        self.enable_s2_attention = bool(enable_s2_attention)
        self.enable_s3_voxel_text_matching_attention = bool(enable_s3_voxel_text_matching_attention)
        self.enable_s3_decoder_feature_gate = bool(enable_s3_decoder_feature_gate)
        self.enable_s3_fullres_attention_refinement = bool(enable_s3_fullres_attention_refinement)
        self.enable_s3_joint_residual_fusion = bool(enable_s3_joint_residual_fusion)
        self.enable_s3_fullres_sampled_alignment = bool(enable_s3_fullres_sampled_alignment)
        if dvsm_tie_probe not in {"none", "independent", "shared"}:
            raise ValueError(f"Unknown dvsm_tie_probe mode: {dvsm_tie_probe!r}")
        self.dvsm_tie_probe = str(dvsm_tie_probe)
        enabled_attention_modes = sum(
            (
                self.enable_prompt_spatial_attention,
                self.enable_s2_attention,
                self.enable_s3_voxel_text_matching_attention,
            )
        )
        if enabled_attention_modes > 1:
            raise ValueError("S1, S2, and S3 attention modes are mutually exclusive")
        self.last_auxiliary_stats: dict[str, torch.Tensor] = {}
        self.capture_spatial_attention_maps = False
        self.last_spatial_attention_maps: list[torch.Tensor] = []
        self.last_s2_attention_maps: dict[str, list[torch.Tensor]] = {}
        self.last_s3_attention_maps: dict[str, list[torch.Tensor]] = {}
        self.last_s3_attention_logits: dict[str, list[torch.Tensor]] = {}
        self.last_s3_fullres_similarity_maps: dict[str, list[torch.Tensor]] = {}
        self.last_s3_fullres_alignment_inputs: list[tuple[torch.Tensor, torch.Tensor]] = []
        self.last_s3_joint_fusion_corrections: list[torch.Tensor] = []
        self.last_target_attention_residuals: list[torch.Tensor] = []

        # Opt-in capture for lightweight frozen-backbone spatial heads.  The
        # captured tensor is the prompt-conditioned decoder feature immediately
        # after the S3-gated skip has been fused, before mask-logit projection.
        # Keeping this disabled by default preserves the existing training and
        # inference memory footprint.
        self.capture_proposal_features = False
        self.proposal_feature_scale = "1/4"
        self.last_proposal_features: list[torch.Tensor] = []
        self.adaptive_rho_adapter: AdaptiveRhoGateAdapter | None = None
        self.category_attention_router: CategoryContinuousAttentionRouter | None = None
        self.target_attention_adapter: AttentionConditionedResidualLogitAdapter3D | None = None
        self.capture_category_router_diagnostics = False
        self.last_category_router_diagnostics: list[dict[str, torch.Tensor]] = []

        valid_token_modes = {
            "original",
            "replace_image_to_text",
            "add_image_to_text",
        }
        if token_image_text_mode not in valid_token_modes:
            raise ValueError(
                f"token_image_text_mode must be one of {sorted(valid_token_modes)}, "
                f"got {token_image_text_mode!r}"
            )
        self.token_image_text_mode = str(token_image_text_mode)
        self.token_image_text_identity_init = bool(token_image_text_identity_init)
        self.token_image_text_output_init_scale = float(token_image_text_output_init_scale)
        self.token_image_text_block = None
        self.capture_token_image_text_attention = False
        self.last_token_image_text_attention: list[torch.Tensor] = []
        self.original_cross_attention_forward_count = 0
        if self.token_image_text_mode != "original":
            selected_channels = self.DECODER_CONFIGS[self.selected_decoder_layer]["channels"]
            self.token_image_text_block = TokenImageToTextBlock(
                image_dim=selected_channels,
                text_dim=int(token_image_text_text_dim or self.text_embedding_dim),
                attention_dim=token_image_text_hidden_dim,
                num_heads=token_image_text_heads,
                dropout=token_image_text_dropout,
                init_seed=token_image_text_init_seed,
                identity_init=self.token_image_text_identity_init,
                residual_output_init_scale=self.token_image_text_output_init_scale,
            )

        valid_fan_modes = {"none", "hierarchical", "preserve"}
        if fan_image_text_mode not in valid_fan_modes:
            raise ValueError(
                f"fan_image_text_mode must be one of {sorted(valid_fan_modes)}, "
                f"got {fan_image_text_mode!r}"
            )
        self.fan_image_text_mode = str(fan_image_text_mode)
        self.fan_image_text_levels = tuple(sorted(set(map(int, fan_image_text_levels))))
        self.fan_image_text_blocks = nn.ModuleDict()
        self.fan_pre_activation_blocks = nn.ModuleDict()
        self.fan_image_text_fusion_projections = nn.ModuleDict()
        self.fan_image_text_preserve_epsilon = float(fan_image_text_preserve_epsilon)
        self.fan_pre_activation_mode = bool(fan_pre_activation_mode)
        if self.fan_pre_activation_mode and self.fan_image_text_mode != "hierarchical":
            raise ValueError("faithful FAN pre-activation requires direct/hierarchical FAN mode")
        self.capture_fan_image_text_attention = False
        self.capture_fan_image_text_logits = False
        self.capture_fan_image_text_residuals = False
        self.fan_joint_cross_modal_ablation = False
        self.fan_explicit_cross_ablation = False
        self.last_fan_image_text_audits: dict[str, dict[str, object]] = {}
        self.last_fan_image_text_attention: dict[str, dict[str, torch.Tensor]] = {}
        self.last_fan_image_text_logits: dict[str, torch.Tensor] = {}
        self.last_fan_image_text_residuals: dict[str, torch.Tensor] = {}
        self.last_fan_image_text_features: dict[str, dict[str, torch.Tensor]] = {}
        # Read-only diagnostic captures for inference-only FAN writeback audits.
        # They are populated only while FAN attention capture is enabled.
        self.last_fan_prompt_memory: torch.Tensor | None = None
        self.last_fan_decoder_feature: torch.Tensor | None = None
        if self.fan_image_text_mode != "none":
            if self.token_image_text_mode != "original":
                raise ValueError(
                    "FAN hierarchical fusion and the Phase-0 token_image_text_block "
                    "are mutually exclusive"
                )
            if self.selected_decoder_layer not in self.fan_image_text_levels:
                raise ValueError(
                    "FAN levels must include the selected VoxTell sentence-fusion "
                    f"level {self.selected_decoder_layer}"
                )
            invalid_levels = [
                level for level in self.fan_image_text_levels
                if level not in self.DECODER_CONFIGS
            ]
            if invalid_levels:
                raise ValueError(f"Unknown FAN encoder levels: {invalid_levels}")
            if fan_image_text_dim <= 0 or fan_image_text_dim % fan_image_text_heads:
                raise ValueError(
                    "fan_image_text_dim must be positive and divisible by "
                    "fan_image_text_heads"
                )
            for offset, level in enumerate(self.fan_image_text_levels):
                config = self.DECODER_CONFIGS[level]
                self.fan_image_text_blocks[f"level{level}"] = (
                    FANImageWordFusionBlock3D(
                        visual_dim=config["channels"],
                        text_dim=self.text_embedding_dim,
                        multimodal_dim=fan_image_text_dim,
                        num_heads=fan_image_text_heads,
                        spatial_shape=tuple(config["shape"]),
                        dropout=fan_image_text_dropout,
                        init_seed=fan_image_text_init_seed + offset,
                    )
                )
                if self.fan_pre_activation_mode:
                    self.fan_pre_activation_blocks[f"level{level}"] = (
                        FANPreActivationImageWordBlock3D(
                            visual_dim=config["channels"],
                            text_dim=self.text_embedding_dim,
                            multimodal_dim=fan_image_text_dim,
                            num_heads=fan_image_text_heads,
                            spatial_shape=tuple(config["shape"]),
                            dropout=fan_image_text_dropout,
                            init_seed=fan_pre_activation_init_seed + offset,
                            residual_scale=fan_pre_activation_residual_scale,
                        )
                    )
                if self.fan_image_text_mode == "preserve":
                    self.fan_image_text_fusion_projections[f"level{level}"] = (
                        FANPreserveFusionProjection3D(
                            visual_dim=config["channels"],
                            fan_dim=config["channels"],
                            epsilon=self.fan_image_text_preserve_epsilon,
                            init_seed=fan_image_text_init_seed + 10_000 + offset,
                        )
                    )

        valid_bidir_prompt_modes = {
            "none",
            "old_fusion",
            "global_image_to_text_old_fusion",
            "no_old_fusion",
            "no_old_fusion_reuse_decoder",
        }
        if bidir_prompt_decoder_mode not in valid_bidir_prompt_modes:
            raise ValueError(
                "bidir_prompt_decoder_mode must be one of "
                f"{sorted(valid_bidir_prompt_modes)}, got "
                f"{bidir_prompt_decoder_mode!r}"
            )
        self.bidir_prompt_decoder_mode = str(bidir_prompt_decoder_mode)
        self.bidir_prompt_lr = bidir_prompt_lr
        self.bidir_prompt_decoder = None
        self.bidir_prompt_token_projection = None
        self.bidir_prompt_image_writeback = None
        self.bidir_no_fusion_decoder = None
        self.bidir_prompt_residual_scale = float(bidir_prompt_residual_scale)
        self.capture_bidir_prompt_attention = False
        self.last_bidir_prompt_audit: dict[str, object] = {}
        self.last_bidir_prompt_attention: list[dict[str, torch.Tensor]] = []
        if self.bidir_prompt_decoder_mode != "none":
            if self.token_image_text_mode != "original" or self.fan_image_text_mode != "none":
                raise ValueError(
                    "Bidirectional Prompt Decoder E1/E2 is isolated from A1 token "
                    "Image-to-Text and A2-FAN modes"
                )
            if self.query_dim % bidir_prompt_heads:
                raise ValueError("bidir_prompt_heads must divide the VoxTell query dimension")
            if bidir_prompt_num_layers <= 0:
                raise ValueError("bidir_prompt_num_layers must be positive")
            if not 0 <= bidir_prompt_dropout < 1:
                raise ValueError("bidir_prompt_dropout must be in [0, 1)")
            if self.bidir_prompt_residual_scale < 0:
                raise ValueError("bidir_prompt_residual_scale must be non-negative")
            torch_state = torch.random.get_rng_state()
            torch.manual_seed(int(bidir_prompt_init_seed))
            global_image_to_text_only = (
                self.bidir_prompt_decoder_mode == "global_image_to_text_old_fusion"
            )
            if not global_image_to_text_only:
                self.bidir_prompt_token_projection = nn.Sequential(
                    nn.Linear(self.text_embedding_dim, self.project_to_decoder_hidden_dim),
                    nn.GELU(),
                    nn.Linear(self.project_to_decoder_hidden_dim, self.query_dim),
                )
            self.bidir_prompt_decoder = BidirectionalPromptDecoder(
                d_model=self.query_dim,
                nhead=int(bidir_prompt_heads),
                num_layers=int(bidir_prompt_num_layers),
                dim_feedforward=self.project_to_decoder_hidden_dim,
                dropout=float(bidir_prompt_dropout),
                residual_scale=self.bidir_prompt_residual_scale,
                legacy_decoder=self.transformer_decoder,
                # The global-only ablation intentionally adds only the
                # Image->Text route to native VoxTell's Text->Image decoder.
                # It has no word-token sequence, no text self-attention, and
                # no added image FFN.
                use_text_self_attention=not global_image_to_text_only,
                use_image_ffn=not global_image_to_text_only,
            )
            selected_channels = self.DECODER_CONFIGS[self.selected_decoder_layer]["channels"]
            self.bidir_prompt_image_writeback = nn.Sequential(
                nn.LayerNorm(self.query_dim),
                nn.Linear(self.query_dim, selected_channels),
            )
            if self.bidir_prompt_decoder_mode in {
                "no_old_fusion",
                "no_old_fusion_reuse_decoder",
            }:
                self.bidir_no_fusion_decoder = VoxTellNoFusionDecoder(
                    self.encoder,
                    1,
                    self.n_conv_per_stage_decoder,
                    self.deep_supervision,
                )
            torch.random.set_rng_state(torch_state)

        # Feasibility pilot: retain VoxTell's released six-layer prompt decoder
        # verbatim and insert only a residual image-memory update *between* its
        # existing layers.  A single sentence key makes conventional
        # Image->Text attention's softmax identically one, so the equivalent
        # operation is a sentence-value projection broadcast to every image
        # token.  There is intentionally no new text-side decoder, image self
        # attention, image FFN, or final writeback path.
        if global_sentence_feedback_mode not in {"none", "image_feedback"}:
            raise ValueError(
                "global_sentence_feedback_mode must be 'none' or 'image_feedback'"
            )
        if global_sentence_feedback_rank <= 0:
            raise ValueError("global_sentence_feedback_rank must be positive")
        if global_sentence_feedback_init_scale < 0:
            raise ValueError("global_sentence_feedback_init_scale must be non-negative")
        self.global_sentence_feedback_mode = str(global_sentence_feedback_mode)
        self.global_sentence_feedback_enabled = True
        self.global_sentence_feedback_blocks = nn.ModuleList()
        self.capture_global_sentence_feedback = False
        self.last_global_sentence_feedback_audits: list[dict[str, object]] = []
        self.last_global_sentence_feedback_final_memory: torch.Tensor | None = None
        if self.global_sentence_feedback_mode != "none":
            if (
                self.token_image_text_mode != "original"
                or self.fan_image_text_mode != "none"
                or self.bidir_prompt_decoder_mode != "none"
                or less_encoder_mode != "none"
            ):
                raise ValueError(
                    "Global sentence image feedback is isolated from token, FAN, "
                    "LESS, and bidirectional-decoder experiments"
                )
            torch_state = torch.random.get_rng_state()
            torch.manual_seed(int(global_sentence_feedback_init_seed))
            for _ in range(self.transformer_decoder.num_layers):
                self.global_sentence_feedback_blocks.append(
                    GlobalSentenceImageFeedback(
                        dim=self.query_dim,
                        rank=int(global_sentence_feedback_rank),
                        init_scale=float(global_sentence_feedback_init_scale),
                    )
                )
            torch.random.set_rng_state(torch_state)

        valid_encoder_propagation_modes = {"none", "text", "null"}
        if encoder_propagation_mode not in valid_encoder_propagation_modes:
            raise ValueError(
                "encoder_propagation_mode must be one of "
                f"{sorted(valid_encoder_propagation_modes)}, got "
                f"{encoder_propagation_mode!r}"
            )
        if encoder_propagation_mode != "none" and (
            self.token_image_text_mode != "original"
            or self.fan_image_text_mode != "none"
            or self.bidir_prompt_decoder_mode != "none"
        ):
            raise ValueError(
                "EP-1/8 is isolated from the token-attention architecture pilots"
            )
        if encoder_propagation_mode != "none" and self.lobe_input_mode != "none":
            raise ValueError("EP-1/8 currently supports the matched one-channel CT path only")
        self.encoder_propagation_mode = str(encoder_propagation_mode)
        self.encoder_propagation_stage = 3
        self.encoder_propagation_block = None
        self.last_encoder_propagation_attention: torch.Tensor | None = None
        self.last_encoder_propagation_audit: dict[str, object] = {}
        self.last_encoder_propagation_deep_skips: list[torch.Tensor] | None = None
        if self.encoder_propagation_mode != "none":
            if len(self.encoder.output_channels) != 6:
                raise ValueError("EP-1/8 expects the six-stage VoxTell encoder")
            if self.encoder.output_channels[self.encoder_propagation_stage] != 256:
                raise ValueError("EP-1/8 expected 256 channels at encoder stage index 3")
            self.encoder_propagation_block = EncoderPropagationCrossAttention(
                image_dim=self.encoder.output_channels[self.encoder_propagation_stage],
                text_dim=self.text_embedding_dim,
                attention_dim=encoder_propagation_hidden_dim,
                num_heads=encoder_propagation_heads,
                dropout=encoder_propagation_dropout,
                init_seed=encoder_propagation_init_seed,
            )
            null_axis = torch.arange(self.text_embedding_dim, dtype=torch.float32)
            fixed_null = torch.sin(null_axis / 17.0) + torch.cos(null_axis / 43.0)
            self.register_buffer(
                "encoder_propagation_fixed_null_token",
                fixed_null[None, None],
                persistent=False,
            )

        valid_film_modes = {"none", "text"}
        if encoder_residual_film_mode not in valid_film_modes:
            raise ValueError(
                "encoder_residual_film_mode must be one of "
                f"{sorted(valid_film_modes)}, got {encoder_residual_film_mode!r}"
            )
        if encoder_residual_film_mode != "none" and (
            self.encoder_propagation_mode != "none"
            or self.token_image_text_mode != "original"
            or self.fan_image_text_mode != "none"
            or self.bidir_prompt_decoder_mode != "none"
        ):
            raise ValueError(
                "Residual FiLM is isolated from EP and token-attention pilots"
            )
        if encoder_residual_film_mode != "none" and self.lobe_input_mode != "none":
            raise ValueError(
                "Residual FiLM supports the matched one-channel CT path only"
            )
        self.encoder_residual_film_mode = str(encoder_residual_film_mode)
        self.encoder_residual_film_gradient_checkpointing = bool(
            encoder_residual_film_gradient_checkpointing
        )
        self.encoder_residual_film_stage = int(encoder_residual_film_stage)
        self.encoder_residual_film_block: EncoderResidualFiLM3D | None = None
        self.last_encoder_residual_film_audit: dict[str, object] = {}
        self.last_encoder_residual_film_deep_skips: list[torch.Tensor] | None = None
        if self.encoder_residual_film_mode != "none":
            if len(self.encoder.output_channels) != 6:
                raise ValueError("Residual FiLM expects the six-stage encoder")
            if self.encoder_residual_film_stage not in {2, 3, 4}:
                raise ValueError("Residual FiLM stage must be 2 (1/4), 3 (1/8), or 4 (1/16)")
            image_dim = self.encoder.output_channels[self.encoder_residual_film_stage]
            self.encoder_residual_film_block = EncoderResidualFiLM3D(
                image_dim=image_dim,
                text_dim=self.text_embedding_dim,
                hidden_dim=encoder_residual_film_hidden_dim,
                num_groups=encoder_residual_film_groups,
                init_seed=encoder_residual_film_init_seed,
            )

        if encoder_token_spatial_mode not in {"none", "text"}:
            raise ValueError("encoder_token_spatial_mode must be 'none' or 'text'")
        if encoder_token_spatial_mode != "none" and (
            self.encoder_propagation_mode != "none"
            or self.encoder_residual_film_mode != "none"
            or self.token_image_text_mode != "original"
            or self.fan_image_text_mode != "none"
            or self.bidir_prompt_decoder_mode != "none"
            or self.lobe_input_mode != "none"
        ):
            raise ValueError("Token-spatial encoder conditioning is an isolated matched arm")
        self.encoder_token_spatial_mode = str(encoder_token_spatial_mode)
        self.encoder_token_spatial_stage = int(encoder_token_spatial_stage)
        self.encoder_token_spatial_conditioned_skip = bool(
            encoder_token_spatial_conditioned_skip
        )
        self.encoder_token_spatial_skip_scale = float(encoder_token_spatial_skip_scale)
        if self.encoder_token_spatial_skip_scale < 0:
            raise ValueError("encoder_token_spatial_skip_scale must be non-negative")
        self.encoder_token_spatial_block: EncoderTokenSpatialConditioning3D | None = None
        self.last_encoder_token_spatial_audit: dict[str, object] = {}
        self.last_encoder_token_spatial_deep_skips: list[torch.Tensor] | None = None
        self.last_encoder_token_spatial_conditioned_skip: torch.Tensor | None = None
        if self.encoder_token_spatial_mode != "none":
            if len(self.encoder.output_channels) != 6 or self.encoder_token_spatial_stage != 3:
                raise ValueError("The token-spatial screen is restricted to stage 3 (1/8) of the six-stage encoder")
            self.encoder_token_spatial_block = EncoderTokenSpatialConditioning3D(
                image_dim=self.encoder.output_channels[self.encoder_token_spatial_stage],
                text_dim=self.text_embedding_dim,
                attention_dim=encoder_token_spatial_hidden_dim,
                num_heads=encoder_token_spatial_heads,
                dropout=encoder_token_spatial_dropout,
                init_seed=encoder_token_spatial_init_seed,
                connector_type=encoder_token_spatial_connector_type,
                connector_init_scale=encoder_token_spatial_connector_init_scale,
            )

        if less_encoder_mode not in {"none", "word", "bico_e345"}:
            raise ValueError("less_encoder_mode must be none, word or bico_e345")
        if less_encoder_mode == "bico_e345" and (
            tuple(sorted(set(less_encoder_levels))) != (3, 4, 5)
            or word_global_mode != "b3" or less_semantic_alignment_mode != "none"
        ):
            raise ValueError("BiCo requires E345, B3, and no semantic alignment")
        if less_encoder_mode != "none" and (
            self.encoder_propagation_mode != "none"
            or self.encoder_residual_film_mode != "none"
            or self.encoder_token_spatial_mode != "none"
            or self.token_image_text_mode != "original"
            or self.fan_image_text_mode != "none"
            or self.bidir_prompt_decoder_mode != "none"
            or self.lobe_input_mode != "none"
        ):
            raise ValueError("LESS encoder conditioning is an isolated matched arm")
        self.less_encoder_mode = str(less_encoder_mode)
        self.less_encoder_bypass = False
        self.less_encoder_levels = tuple(sorted(set(map(int, less_encoder_levels))))
        self.less_encoder_prompt_chunk_size = int(less_encoder_prompt_chunk_size)
        self.less_encoder_blocks = nn.ModuleDict()
        self.last_less_encoder_audit: dict[str, object] = {}
        self.last_less_prompt_skips: dict[int, torch.Tensor] | None = None
        self.last_less_decoder_stage2: torch.Tensor | None = None
        self.last_less_decoder_stage3: torch.Tensor | None = None
        self.less_semantic_alignment_mode = str(less_semantic_alignment_mode)
        self.less_semantic_alignment_heads = nn.ModuleDict()
        if self.less_encoder_mode != "none":
            if not self.less_encoder_levels:
                raise ValueError("LESS requires at least one encoder level")
            if any(level < 0 or level >= len(self.encoder.output_channels) for level in self.less_encoder_levels):
                raise ValueError("LESS levels must be valid VoxTell encoder stages")
            if self.selected_decoder_layer not in self.less_encoder_levels:
                raise ValueError("LESS levels must include the selected Prompt Decoder level")
            if self.less_encoder_prompt_chunk_size <= 0:
                raise ValueError("LESS prompt chunk size must be positive")
            for offset, level in enumerate(self.less_encoder_levels):
                conditioning_class = (
                    BiCoImageTextStage3D if self.less_encoder_mode == "bico_e345"
                    else LESSImageWordConditioning3D
                )
                self.less_encoder_blocks[f"level{level}"] = conditioning_class(
                    image_dim=self.encoder.output_channels[level],
                    text_dim=self.text_embedding_dim,
                    attention_dim=less_encoder_attention_dim,
                    num_heads=less_encoder_heads,
                    query_chunk_size=less_encoder_query_chunk_size,
                    dropout=less_encoder_dropout,
                    init_seed=less_encoder_init_seed + offset,
                )
        if self.less_semantic_alignment_mode not in {
            "none", "anatomy", "pathology", "medplex", "samecase"
        }:
            raise ValueError(
                "less_semantic_alignment_mode must be none, anatomy, pathology, medplex, or samecase"
            )
        if self.less_semantic_alignment_mode != "none":
            if self.less_encoder_mode != "word":
                raise ValueError("LESS semantic alignment requires LESS word conditioning")
            if less_semantic_alignment_dim <= 0:
                raise ValueError("less_semantic_alignment_dim must be positive")
            if self.less_semantic_alignment_mode == "anatomy":
                self.less_semantic_alignment_heads["anatomy"] = LESSRepresentationAlignmentHead(
                    self.encoder.output_channels[4], self.text_embedding_dim,
                    int(less_semantic_alignment_dim),
                )
            elif self.less_semantic_alignment_mode == "pathology":
                # Decoder stage index 3 is the requested decoder_stage3 in the
                # pilot nomenclature: 96^3 with 64 channels.
                self.less_semantic_alignment_heads["pathology"] = LESSRepresentationAlignmentHead(
                    self.encoder.output_channels[1], self.text_embedding_dim,
                    int(less_semantic_alignment_dim),
                )
            elif self.less_semantic_alignment_mode == "medplex":
                # Decoder stage index 2 is decoder_stage2: 48^3 with 128C.
                self.less_semantic_alignment_heads["medplex"] = LESSRepresentationAlignmentHead(
                    self.encoder.output_channels[2], self.text_embedding_dim,
                    int(less_semantic_alignment_dim),
                )

        valid_word_global_modes = {"none", "b1", "b2", "b3"}
        if word_global_mode not in valid_word_global_modes:
            raise ValueError(
                f"word_global_mode must be one of {sorted(valid_word_global_modes)}, "
                f"got {word_global_mode!r}"
            )
        self.word_global_mode = str(word_global_mode)
        self.word_global_bridge_checkpoint = word_global_bridge_checkpoint
        self.word_global_lr = None if word_global_lr is None else float(word_global_lr)
        self.word_global_b1_alpha = float(word_global_b1_alpha)
        self.word_global_b1_decoder_stage = int(word_global_b1_decoder_stage)
        self.word_global_b1_bypass = False
        self.word_global_b1_block: LateWordCrossAttention3D | None = None
        self.word_global_bridge = None
        self.word_global_candidate_bridge = None
        self.word_global_router = None
        self.word_global_b3_candidates = int(word_global_b3_candidates)
        self.word_global_b3_epsilon = float(word_global_b3_epsilon)
        self.word_global_b3_router_scale = float(word_global_b3_router_scale)
        if word_global_b3_aggregation not in {"learned", "uniform", "first"}:
            raise ValueError(
                f"Unknown B3 candidate aggregation: {word_global_b3_aggregation!r}"
            )
        self.word_global_b3_aggregation = str(word_global_b3_aggregation)
        self.capture_word_global_features = False
        self.last_word_global_audit: dict[str, object] = {}
        self.last_word_global_features: dict[str, torch.Tensor] = {}
        self._word_global_tokens: torch.Tensor | None = None
        self._word_global_valid_mask: torch.Tensor | None = None
        self._word_global_b1_prompt_index = 0
        self._word_global_b1_hook_handle = None

        if self.word_global_mode != "none":
            conflicting_modes = {
                "MedPlex": self.medplex_mode != "none",
                "token_image_text": self.token_image_text_mode != "original",
                "FAN": self.fan_image_text_mode != "none",
                "bidirectional_prompt_decoder": self.bidir_prompt_decoder_mode != "none",
                "encoder_propagation": self.encoder_propagation_mode != "none",
                "encoder_residual_film": self.encoder_residual_film_mode != "none",
                "encoder_token_spatial": self.encoder_token_spatial_mode != "none",
                # B3+LESS is a deliberate combined arm: contextual word tokens
                # generate the B3 queries and independently condition the
                # prompt-specific encoder streams. B1/B2 remain isolated.
                "LESS": (
                    self.less_encoder_mode != "none"
                    and self.word_global_mode != "b3"
                ),
                "lobe_input": self.lobe_input_mode != "none",
            }
            active_conflicts = [name for name, active in conflicting_modes.items() if active]
            if active_conflicts:
                raise ValueError(
                    "B1/B2/B3 word-global pilots are isolated matched arms; "
                    f"conflicting modes: {active_conflicts}"
                )
            if not word_global_bridge_checkpoint:
                raise ValueError("B1/B2/B3 require the frozen fitted bridge checkpoint")

        if self.word_global_mode == "b1":
            if not 0 <= self.word_global_b1_decoder_stage < len(self.decoder.stages):
                raise ValueError("B1 decoder stage is out of range")
            b1_channels = int(self.encoder.output_channels[2])
            self.word_global_b1_block = LateWordCrossAttention3D(
                image_dim=b1_channels,
                token_dim=self.text_embedding_dim,
                attention_dim=b1_channels,
                num_heads=4,
                seed=int(word_global_b1_seed),
            )

            def _b1_decoder_hook(_module, _inputs, output):
                if self.word_global_b1_bypass:
                    return output
                if self._word_global_tokens is None or self._word_global_valid_mask is None:
                    raise RuntimeError("B1 decoder hook ran without prompt token context")
                prompt_index = self._word_global_b1_prompt_index
                if prompt_index >= self._word_global_tokens.shape[1]:
                    raise RuntimeError("B1 decoder hook prompt index overflow")
                tokens = self._word_global_tokens[:, prompt_index]
                valid = self._word_global_valid_mask[:, prompt_index]
                assert self.word_global_b1_block is not None
                conditioned = self.word_global_b1_block(
                    output, tokens, valid, self.word_global_b1_alpha
                )
                self._word_global_b1_prompt_index += 1
                if self.capture_word_global_features:
                    self.last_word_global_features[
                        f"b1_stage_prompt{prompt_index}_input"
                    ] = output.detach()
                    self.last_word_global_features[
                        f"b1_stage_prompt{prompt_index}_output"
                    ] = conditioned.detach()
                return conditioned

            self._word_global_b1_hook_handle = self.decoder.stages[
                self.word_global_b1_decoder_stage
            ].register_forward_hook(_b1_decoder_hook)
        elif self.word_global_mode == "b2":
            self.word_global_bridge = load_fitted_bridge(
                str(word_global_bridge_checkpoint)
            )
        elif self.word_global_mode == "b3":
            fitted_bridge = load_fitted_bridge(str(word_global_bridge_checkpoint))
            self.word_global_candidate_bridge = MultiCandidateWordBridge(
                fitted_bridge,
                candidates=self.word_global_b3_candidates,
                epsilon=self.word_global_b3_epsilon,
                seed=int(word_global_b3_seed),
            )
            self.word_global_router = SentenceCandidateRouter(
                mask_dim=self.query_dim,
                sentence_dim=self.text_embedding_dim,
                scale=self.word_global_b3_router_scale,
                seed=int(word_global_b3_seed) + 1,
            )

        self.dvsm_probe_adapter = None
        if self.dvsm_tie_probe != "none":
            selected_channels = self.DECODER_CONFIGS[self.selected_decoder_layer]["channels"]
            self.dvsm_probe_adapter = DVSMTieProbeAdapter(
                image_channels=selected_channels,
                text_dim=self.text_embedding_dim,
                dim=dvsm_probe_dim,
                depth=dvsm_probe_depth,
                heads=dvsm_probe_heads,
                pool_size=dvsm_probe_pool_size,
                zero_init=dvsm_probe_zero_init,
            )
            if self.dvsm_tie_probe == "shared":
                self.dvsm_probe_adapter.disable_unused_shared_parameters()

        if self.enable_patch_presence_head and presence_head_type == "spatial_grounded":
            selected_channels = self.DECODER_CONFIGS[self.selected_decoder_layer]["channels"]
            self.patch_presence_head = SpatialGroundedPresenceHead(
                selected_channels,
                self.query_dim,
                presence_spatial_hidden_channels,
                presence_spatial_topk_frac,
            )

        self.prompt_spatial_attention_gate = None
        self.spatial_attention_encoder_level = None
        self.spatial_attention_decoder_stage = None
        if self.enable_prompt_spatial_attention:
            if spatial_attention_level == "auto_1over4":
                encoder_level = 2
            else:
                encoder_level = int(spatial_attention_level)
            n_stages = len(self.encoder.output_channels)
            if not 0 <= encoder_level < n_stages - 1:
                raise ValueError(f"spatial_attention_level must select a non-bottleneck encoder stage, got {encoder_level}")
            decoder_stage = n_stages - 2 - encoder_level
            channels = self.encoder.output_channels[encoder_level]
            self.spatial_attention_encoder_level = encoder_level
            self.spatial_attention_decoder_stage = decoder_stage
            self.prompt_spatial_attention_gate = PromptConditionedResidualSpatialAttentionGate3D(
                channels,
                channels,
                self.query_dim,
                spatial_attention_hidden_channels,
                spatial_attention_beta_init,
            )

        valid_s2_scales = {"1/4": 2, "1/2": 1}
        self.s2_attention_scales = tuple(str(scale) for scale in s2_attention_scales)
        unknown_s2_scales = sorted(set(self.s2_attention_scales) - set(valid_s2_scales))
        if unknown_s2_scales:
            raise ValueError(f"Unsupported S2 attention scale(s): {unknown_s2_scales}")
        if self.enable_s2_attention and not self.s2_attention_scales:
            raise ValueError("S2 attention requires at least one scale")
        self.s2_attention_gates = nn.ModuleDict()
        self.s2_attention_decoder_stage_to_scale: dict[int, str] = {}
        if self.enable_s2_attention:
            n_stages = len(self.encoder.output_channels)
            for scale in self.s2_attention_scales:
                encoder_level = valid_s2_scales[scale]
                if encoder_level >= n_stages - 1:
                    raise ValueError(
                        f"S2 scale {scale} maps to unavailable encoder level {encoder_level}"
                    )
                decoder_stage = n_stages - 2 - encoder_level
                channels = self.encoder.output_channels[encoder_level]
                key = self._s2_scale_key(scale)
                self.s2_attention_gates[key] = LocalizedMultiScaleAttentionGate3D(
                    channels,
                    channels,
                    self.query_dim,
                    s2_attention_hidden_channels,
                    s2_beta_init,
                )
                self.s2_attention_decoder_stage_to_scale[decoder_stage] = scale

        # Keep the original 1/2 gate attribute for checkpoint compatibility. Extra
        # S3 gates are optional and let an experiment gate decoder skips at 1/4
        # and/or 1/1 resolution as well.
        valid_s3_scales = {"1/4": 2, "1/2": 1, "1/1": 0}
        self.s3_attention_scales = tuple(str(scale) for scale in s3_attention_scales)
        unknown_s3_scales = sorted(set(self.s3_attention_scales) - set(valid_s3_scales))
        if unknown_s3_scales:
            raise ValueError(f"Unsupported S3 attention scale(s): {unknown_s3_scales}")
        if self.enable_s3_voxel_text_matching_attention and not self.s3_attention_scales:
            raise ValueError("S3 attention requires at least one scale")
        self.s3_attention_gate = None
        self.s3_extra_attention_gates = nn.ModuleDict()
        self.s3_attention_decoder_stage_to_scale: dict[int, str] = {}
        self.s3_decoder_feature_gate_scales = tuple(
            str(scale) for scale in s3_decoder_feature_gate_scales
        )
        invalid_decoder_feature_scales = sorted(
            set(self.s3_decoder_feature_gate_scales) - {"1/4", "1/2"}
        )
        if invalid_decoder_feature_scales:
            raise ValueError(
                "Decoder feature gates can only feed a later decoder stage; "
                f"unsupported scale(s): {invalid_decoder_feature_scales}"
            )
        if self.enable_s3_decoder_feature_gate and not self.enable_s3_voxel_text_matching_attention:
            raise ValueError("S3 decoder feature gating requires S3 voxel-text attention")
        if self.enable_s3_fullres_attention_refinement and not self.enable_s3_voxel_text_matching_attention:
            raise ValueError("S3 full-resolution refinement requires S3 voxel-text attention")
        if self.enable_s3_fullres_attention_refinement and "1/1" not in self.s3_attention_scales:
            raise ValueError("S3 full-resolution refinement requires the 1/1 S3 attention scale")
        if self.enable_s3_joint_residual_fusion and not self.enable_s3_voxel_text_matching_attention:
            raise ValueError("S3 joint residual fusion requires S3 voxel-text attention")
        if self.enable_s3_joint_residual_fusion and "1/1" not in self.s3_attention_scales:
            raise ValueError("S3 joint residual fusion requires the 1/1 S3 attention scale")
        if self.enable_s3_decoder_feature_gate and not set(self.s3_decoder_feature_gate_scales).issubset(
            set(self.s3_attention_scales)
        ):
            raise ValueError(
                "S3 decoder feature gate scales must be a subset of s3_attention_scales"
            )
        self.s3_decoder_feature_gates = nn.ModuleDict()
        if self.enable_s3_decoder_feature_gate:
            self.s3_decoder_feature_gates = nn.ModuleDict(
                {
                    self._s2_scale_key(scale): DecoderFeatureResidualSpatialGate3D(
                        s3_decoder_feature_gate_strength_init
                    )
                    for scale in self.s3_decoder_feature_gate_scales
                }
            )
        self.s3_fullres_attention_refinement = None
        if self.enable_s3_fullres_attention_refinement:
            self.s3_fullres_attention_refinement = FullResolutionAttentionConditionedRefinement3D(
                self.encoder.output_channels[0], s3_fullres_refinement_hidden_channels
            )
        self.s3_joint_fusion_head = None
        if self.enable_s3_joint_residual_fusion:
            self.s3_joint_fusion_head = S3JointResidualLogitFusion3D(
                s3_joint_fusion_hidden_channels,
                detach_attention=s3_joint_fusion_detach_attention,
            )
        self.s3_fullres_alignment_head = None
        if self.enable_s3_voxel_text_matching_attention:
            n_stages = len(self.encoder.output_channels)
            for scale in self.s3_attention_scales:
                encoder_level = valid_s3_scales[scale]
                if encoder_level >= n_stages - 1:
                    raise ValueError(f"S3 scale {scale} is unavailable")
                decoder_stage = n_stages - 2 - encoder_level
                channels = self.encoder.output_channels[encoder_level]
                gate = VoxelTextMatchingAttentionGate3D(
                    channels,
                    channels,
                    self.query_dim,
                    s3_attention_hidden_channels,
                    s3_rho_mode,
                    s3_rho_fixed,
                    s3_logit_scale_init,
                )
                if scale == "1/2":
                    self.s3_attention_gate = gate
                else:
                    self.s3_extra_attention_gates[self._s2_scale_key(scale)] = gate
                self.s3_attention_decoder_stage_to_scale[decoder_stage] = scale
            if self.enable_s3_fullres_sampled_alignment:
                self.s3_fullres_alignment_head = SampledFullResTextAlignmentHead3D(
                    self.encoder.output_channels[0],
                    self.query_dim,
                    s3_fullres_alignment_dim,
                )

    def initialize_bidir_no_fusion_decoder_from_old_decoder(self) -> dict[str, object]:
        """Warm-start the E2b no-fusion decoder from the loaded VoxTell decoder."""

        if self.bidir_prompt_decoder_mode != "no_old_fusion_reuse_decoder":
            return {
                "applied": False,
                "reason": f"mode={self.bidir_prompt_decoder_mode}",
            }
        if self.bidir_no_fusion_decoder is None:
            raise RuntimeError("E2b requested but bidir_no_fusion_decoder is not initialized")
        audit = self.bidir_no_fusion_decoder.initialize_from_mask_fusion_decoder(
            self.decoder
        )
        self.last_bidir_prompt_audit = {
            **self.last_bidir_prompt_audit,
            "no_fusion_decoder_init": audit,
        }
        return audit

    @staticmethod
    def _s2_scale_key(scale: str) -> str:
        return scale.replace("/", "over")

    def _decode_prompt_with_s2(
        self,
        skips: List[torch.Tensor],
        mask_embeddings: List[torch.Tensor],
        query: torch.Tensor,
        gate_scale: float | torch.Tensor = 1.0,
        scale_factors: dict[str, float] | None = None,
    ) -> List[torch.Tensor]:
        decoder = self.decoder
        lres_input = skips[-1]
        seg_outputs = []
        mask_embeddings = mask_embeddings[::-1]
        for stage_idx in range(len(decoder.stages)):
            coarse_context = decoder.transpconvs[stage_idx](lres_input)
            skip = skips[-(stage_idx + 2)]
            scale = self.s2_attention_decoder_stage_to_scale.get(stage_idx)
            if scale is not None:
                gate = self.s2_attention_gates[self._s2_scale_key(scale)]
                scale_factor = 1.0 if scale_factors is None else float(scale_factors.get(scale, 1.0))
                gated, attention = gate(
                    skip,
                    coarse_context,
                    query,
                    gate_scale=gate_scale * scale_factor,
                )
                skip = gated[:, 0]
                self.last_s2_attention_maps[scale].append(attention)
            x = decoder.stages[stage_idx](torch.cat((coarse_context, skip), dim=1))
            if stage_idx == len(decoder.stages) - 1:
                if self.s3_fullres_alignment_head is not None:
                    similarity = self.s3_fullres_alignment_head(x, query)
                    self.last_s3_fullres_similarity_maps.setdefault("1/1", []).append(similarity)
                seg_outputs.append(torch.einsum("b c h w d, b n c -> b n h w d", x, mask_embeddings[-1]))
            elif stage_idx >= len(decoder.stages) - len(mask_embeddings):
                mask_embedding = mask_embeddings.pop(0)
                batch_size, _, channels = mask_embedding.shape
                reshaped = mask_embedding.view(batch_size, decoder.num_heads, -1)
                fusion = torch.einsum("b c h w d, b n c -> b n h w d", x, reshaped)
                x = torch.cat((x, fusion), dim=1)
                seg_outputs.append(decoder.seg_layers[stage_idx](x))
            lres_input = x
        seg_outputs = seg_outputs[::-1]
        return seg_outputs if decoder.deep_supervision else seg_outputs[:1]

    def _record_s2_attention_stats(self) -> None:
        for scale, maps in self.last_s2_attention_maps.items():
            if not maps:
                continue
            attention = torch.cat(maps, dim=1)
            gate = self.s2_attention_gates[self._s2_scale_key(scale)]
            self.last_auxiliary_stats.update(
                {
                    f"s2_attention_mean_{scale}": attention.detach().mean(),
                    f"s2_attention_std_{scale}": attention.detach().std(),
                    f"s2_attention_min_{scale}": attention.detach().amin(),
                    f"s2_attention_max_{scale}": attention.detach().amax(),
                    f"rho_{scale}": torch.sigmoid(gate.beta.detach()),
                }
            )
        if self.capture_spatial_attention_maps and self.last_s2_attention_maps:
            diagnostic_scale = "1/2" if "1/2" in self.last_s2_attention_maps else self.s2_attention_scales[0]
            self.last_spatial_attention_maps = [
                attention.detach() for attention in self.last_s2_attention_maps[diagnostic_scale]
            ]

    def _decode_prompt_with_s3(
        self,
        skips: List[torch.Tensor],
        mask_embeddings: List[torch.Tensor],
        query: torch.Tensor,
        gate_scale: float | torch.Tensor = 1.0,
        gate_scales_by_scale: dict[str, float | torch.Tensor] | None = None,
        fullres_refinement_scale: float | torch.Tensor = 1.0,
        joint_fusion_scale: float | torch.Tensor = 0.0,
        adaptive_rho_category_indices: torch.Tensor | None = None,
        adaptive_rho_active_mask: torch.Tensor | None = None,
        category_router_indices: torch.Tensor | None = None,
        target_attention_adapter_active_mask: torch.Tensor | None = None,
    ) -> List[torch.Tensor]:
        decoder = self.decoder
        lres_input = skips[-1]
        seg_outputs = []
        mask_embeddings = mask_embeddings[::-1]
        for stage_idx in range(len(decoder.stages)):
            coarse_context = decoder.transpconvs[stage_idx](lres_input)
            skip = skips[-(stage_idx + 2)]
            scale = self.s3_attention_decoder_stage_to_scale.get(stage_idx)
            if scale is not None:
                stage_gate_scale = (
                    gate_scale
                    if gate_scales_by_scale is None
                    else gate_scales_by_scale.get(scale, gate_scale)
                )
                gate = (
                    self.s3_attention_gate
                    if scale == "1/2"
                    else self.s3_extra_attention_gates[self._s2_scale_key(scale)]
                )
                if self.category_attention_router is not None:
                    if category_router_indices is None:
                        raise ValueError("Category router requires one category index per sample")
                    gated_s3, attention = gate(
                        skip,
                        coarse_context,
                        query,
                        gate_scale=stage_gate_scale,
                    )
                    category_gate = self.category_attention_router(
                        category_router_indices
                    ).to(device=skip.device, dtype=skip.dtype)
                    while category_gate.ndim < gated_s3.ndim:
                        category_gate = category_gate[..., None]
                    ungated = skip[:, None]
                    interpolated = ungated + category_gate * (gated_s3 - ungated)
                    # Preserve bitwise update-0 and g=0 forward endpoints while
                    # retaining the interpolation derivative at both bounds.
                    endpoint_exact = torch.where(
                        category_gate == 1,
                        gated_s3,
                        torch.where(category_gate == 0, ungated, interpolated),
                    )
                    gated = interpolated + (endpoint_exact - interpolated).detach()
                    if self.capture_category_router_diagnostics:
                        delta = gated_s3.float() - ungated.float()
                        skip_norm = ungated.float().norm().clamp_min(1e-12)
                        self.last_category_router_diagnostics.append(
                            {
                                "gamma": category_gate.detach().float().mean(),
                                "attention_mean": attention.detach().float().mean(),
                                "attention_std": attention.detach().float().std(),
                                "relative_attention_delta": (
                                    delta.detach().norm() / skip_norm.detach()
                                ),
                                "effective_relative_attention_delta": (
                                    (category_gate.float() * delta).detach().norm()
                                    / skip_norm.detach()
                                ),
                                "maximum_s_out_difference_from_original": (
                                    gated.detach().float() - gated_s3.detach().float()
                                ).abs().max(),
                            }
                        )
                elif self.adaptive_rho_adapter is None:
                    gated, attention = gate(
                        skip,
                        coarse_context,
                        query,
                        gate_scale=stage_gate_scale,
                    )
                else:
                    if adaptive_rho_category_indices is None:
                        raise ValueError("Adaptive rho requires one category index per sample")
                    attention = gate.compute_attention(skip, coarse_context, query)
                    rho_override = self.adaptive_rho_adapter(
                        scale,
                        adaptive_rho_category_indices,
                        skip,
                        query[:, 0],
                        attention[:, 0],
                        active_mask=adaptive_rho_active_mask,
                    )
                    gated = gate.apply_attention(
                        skip,
                        attention,
                        rho_override=rho_override,
                    )
                skip = gated[:, 0]
                self.last_s3_attention_maps[scale].append(attention)
                attention_logits = getattr(gate, "last_attention_logits", None)
                if attention_logits is not None:
                    self.last_s3_attention_logits.setdefault(scale, []).append(attention_logits)
            x = decoder.stages[stage_idx](torch.cat((coarse_context, skip), dim=1))
            if (
                self.capture_proposal_features
                and scale == self.proposal_feature_scale
            ):
                self.last_proposal_features.append(x.detach())
            if stage_idx == len(decoder.stages) - 1:
                if self.s3_fullres_attention_refinement is not None:
                    if scale != "1/1":
                        raise RuntimeError("S3 full-resolution refinement did not receive a 1/1 attention map")
                    x = self.s3_fullres_attention_refinement(
                        x, attention, refinement_scale=fullres_refinement_scale
                    )
                    self.last_auxiliary_stats["s3_fullres_refinement_scale"] = (
                        fullres_refinement_scale.detach().mean()
                        if torch.is_tensor(fullres_refinement_scale)
                        else torch.tensor(float(fullres_refinement_scale), device=x.device)
                    )
                if self.s3_fullres_alignment_head is not None:
                    # The sampled loss gathers voxels from x later. This keeps
                    # full-resolution cosine computation sparse and differentiable.
                    self.last_s3_fullres_alignment_inputs.append((x, query))
                final_logit = torch.einsum("b c h w d, b n c -> b n h w d", x, mask_embeddings[-1])
                if self.target_attention_adapter is not None:
                    if scale != "1/1":
                        raise RuntimeError(
                            "Target attention adapter did not receive the 1/1 S3 map"
                        )
                    correction = self.target_attention_adapter(
                        x,
                        attention,
                        active_mask=target_attention_adapter_active_mask,
                    )
                    final_logit = final_logit + correction
                    self.last_target_attention_residuals.append(correction)
                if self.s3_joint_fusion_head is not None:
                    if scale != "1/1" or attention_logits is None:
                        raise RuntimeError("S3 joint residual fusion did not receive 1/1 attention logits")
                    final_logit, correction = self.s3_joint_fusion_head(
                        final_logit,
                        attention_logits,
                        fusion_scale=joint_fusion_scale,
                    )
                    self.last_s3_joint_fusion_corrections.append(correction)
                    self.last_auxiliary_stats["s3_joint_fusion_correction_abs_mean"] = (
                        correction.detach().abs().mean()
                    )
                seg_outputs.append(final_logit)
            elif stage_idx >= len(decoder.stages) - len(mask_embeddings):
                mask_embedding = mask_embeddings.pop(0)
                batch_size, _, channels = mask_embedding.shape
                reshaped = mask_embedding.view(batch_size, decoder.num_heads, -1)
                fusion = torch.einsum("b c h w d, b n c -> b n h w d", x, reshaped)
                x = torch.cat((x, fusion), dim=1)
                seg_outputs.append(decoder.seg_layers[stage_idx](x))
            if scale is not None and self._s2_scale_key(scale) in self.s3_decoder_feature_gates:
                decoder_gate = self.s3_decoder_feature_gates[self._s2_scale_key(scale)]
                x = decoder_gate(x, attention, gate_scale=stage_gate_scale)
                suffix = scale.replace("/", "over")
                self.last_auxiliary_stats[f"s3_decoder_feature_gate_strength_{suffix}"] = (
                    decoder_gate.strength.detach()
                )
            lres_input = x
        seg_outputs = seg_outputs[::-1]
        return seg_outputs if decoder.deep_supervision else seg_outputs[:1]

    def _record_s3_attention_stats(self) -> None:
        for scale, maps in self.last_s3_attention_maps.items():
            if not maps:
                continue
            attention = torch.cat(maps, dim=1)
            gate = (
                self.s3_attention_gate
                if scale == "1/2"
                else self.s3_extra_attention_gates[self._s2_scale_key(scale)]
            )
            suffix = scale.replace("/", "over")
            self.last_auxiliary_stats.update(
                {
                    f"s3_attention_mean_{suffix}": attention.detach().mean(),
                    f"s3_attention_std_{suffix}": attention.detach().std(),
                    f"s3_attention_min_{suffix}": attention.detach().amin(),
                    f"s3_attention_max_{suffix}": attention.detach().amax(),
                    f"s3_logit_scale_{suffix}": gate.logit_scale.detach().exp().clamp(max=50.0),
                    f"s3_bias_{suffix}": gate.bias.detach(),
                    f"s3_rho_{suffix}": torch.tensor(gate.rho_fixed, device=attention.device),
                }
            )
        if self.capture_spatial_attention_maps:
            # Keep all scales for multiscale diagnostics. The legacy list remains
            # available for callers that expect a single attention scale.
            self.last_spatial_attention_maps_by_scale = {
                scale: [item.detach() for item in scale_maps]
                for scale, scale_maps in self.last_s3_attention_maps.items()
                if scale_maps
            }
            if self.last_spatial_attention_maps_by_scale:
                diagnostic_scale = (
                    "1/2"
                    if "1/2" in self.last_spatial_attention_maps_by_scale
                    else next(iter(self.last_spatial_attention_maps_by_scale))
                )
                self.last_spatial_attention_maps = self.last_spatial_attention_maps_by_scale[
                    diagnostic_scale
                ]

    @torch.no_grad()
    def project_s3_decoder_feature_gate_strengths_(self) -> None:
        """Project direct gate strengths after an optimizer update."""
        for gate in self.s3_decoder_feature_gates.values():
            gate.project_strength_()

    def set_proposal_feature_capture(
        self,
        enabled: bool,
        scale: str = "1/4",
    ) -> None:
        """Capture one prompt-conditioned decoder feature per prompt.

        P0-B intentionally uses the 1/4 feature (48^3 for a 192^3 patch).
        Other instantiated S3 scales remain available for bounded diagnostics.
        """
        scale = str(scale)
        if scale not in self.s3_attention_scales:
            raise ValueError(
                f"Proposal feature scale {scale!r} is not in "
                f"s3_attention_scales={self.s3_attention_scales}"
            )
        self.capture_proposal_features = bool(enabled)
        self.proposal_feature_scale = scale
        self.last_proposal_features = []

    def configure_adaptive_rho(self, adapter: AdaptiveRhoGateAdapter) -> None:
        if not self.enable_s3_voxel_text_matching_attention:
            raise ValueError("Adaptive rho requires S3 attention")
        if tuple(adapter.scales) != tuple(self.s3_attention_scales):
            raise ValueError(
                f"Adaptive scales {adapter.scales} do not match S3 scales {self.s3_attention_scales}"
            )
        expected_channels = {
            scale: int(
                (
                    self.s3_attention_gate
                    if scale == "1/2"
                    else self.s3_extra_attention_gates[self._s2_scale_key(scale)]
                ).skip_projection.in_channels
            )
            for scale in self.s3_attention_scales
        }
        if adapter.channels_by_scale != expected_channels:
            raise ValueError(
                f"Adaptive channel map {adapter.channels_by_scale} != model {expected_channels}"
            )
        self.adaptive_rho_adapter = adapter

    def configure_category_attention_router(
        self, router: CategoryContinuousAttentionRouter
    ) -> None:
        if not self.enable_s3_voxel_text_matching_attention:
            raise ValueError("Category attention routing requires S3 attention")
        if tuple(self.s3_attention_scales) != ("1/1",):
            raise ValueError("The first category router requires single-scale 1/1 S3")
        if self.adaptive_rho_adapter is not None:
            raise ValueError("Category router and adaptive rho are mutually exclusive")
        self.category_attention_router = router

    def configure_target_attention_adapter(
        self, adapter: AttentionConditionedResidualLogitAdapter3D
    ) -> None:
        if not self.enable_s3_voxel_text_matching_attention:
            raise ValueError("Target attention adapter requires S3 attention")
        if "1/1" not in self.s3_attention_scales:
            raise ValueError("Target attention adapter requires the 1/1 S3 map")
        expected = int(self.encoder.output_channels[0])
        if adapter.feature_channels != expected:
            raise ValueError(
                f"Adapter feature channels {adapter.feature_channels} != decoder {expected}"
            )
        self.target_attention_adapter = adapter

    @staticmethod
    def _prompt_gate_scale(
        gate_scale: float | torch.Tensor,
        prompt_idx: int,
        batch_size: int,
    ) -> float | torch.Tensor:
        """Select one prompt's scale from scalar, [P], or [B,P] input."""
        if not torch.is_tensor(gate_scale) or gate_scale.ndim == 0:
            return gate_scale
        if gate_scale.ndim == 1:
            if gate_scale.shape[0] == batch_size:
                return gate_scale
            return gate_scale[prompt_idx]
        if gate_scale.ndim == 2:
            return gate_scale[:, prompt_idx]
        raise ValueError(
            "Attention gate scale must be scalar, [P], or [B,P], "
            f"got {tuple(gate_scale.shape)}"
        )

    def _decode_prompt_with_attention(
        self,
        skips: List[torch.Tensor],
        mask_embeddings: List[torch.Tensor],
        query: torch.Tensor,
        rho_scale: float | torch.Tensor = 1.0,
    ) -> List[torch.Tensor]:
        decoder = self.decoder
        lres_input = skips[-1]
        seg_outputs = []
        mask_embeddings = mask_embeddings[::-1]
        attention = None
        for stage_idx in range(len(decoder.stages)):
            x = decoder.transpconvs[stage_idx](lres_input)
            skip = skips[-(stage_idx + 2)]
            if stage_idx == self.spatial_attention_decoder_stage:
                gated, attention = self.prompt_spatial_attention_gate(skip, x, query, rho_scale=rho_scale)
                skip = gated[:, 0]
            x = decoder.stages[stage_idx](torch.cat((x, skip), dim=1))
            if stage_idx == len(decoder.stages) - 1:
                seg_outputs.append(torch.einsum("b c h w d, b n c -> b n h w d", x, mask_embeddings[-1]))
            elif stage_idx >= len(decoder.stages) - len(mask_embeddings):
                mask_embedding = mask_embeddings.pop(0)
                batch_size, _, channels = mask_embedding.shape
                reshaped = mask_embedding.view(batch_size, decoder.num_heads, -1)
                fusion = torch.einsum("b c h w d, b n c -> b n h w d", x, reshaped)
                x = torch.cat((x, fusion), dim=1)
                seg_outputs.append(decoder.seg_layers[stage_idx](x))
            lres_input = x
        if attention is not None:
            if self.capture_spatial_attention_maps:
                self.last_spatial_attention_maps.append(attention.detach())
            self.last_auxiliary_stats.update(
                {
                    "spatial_attention_mean": attention.detach().mean(),
                    "spatial_attention_std": attention.detach().std(),
                    "spatial_attention_min": attention.detach().amin(),
                    "spatial_attention_max": attention.detach().amax(),
                    "spatial_attention_beta": self.prompt_spatial_attention_gate.beta.detach(),
                    "spatial_attention_rho": torch.sigmoid(self.prompt_spatial_attention_gate.beta.detach()),
                    "spatial_attention_rho_scale": (
                        rho_scale.detach().mean() if torch.is_tensor(rho_scale)
                        else torch.tensor(float(rho_scale), device=attention.device)
                    ),
                }
            )
        seg_outputs = seg_outputs[::-1]
        return seg_outputs if decoder.deep_supervision else seg_outputs[:1]

    def _forward_encoder_residual_film(
        self,
        img: torch.Tensor,
        text_embedding: torch.Tensor,
    ) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
        """Apply prompt-specific residual FiLM only to encoder stages 4--5."""
        block = self.encoder_residual_film_block
        if block is None:
            raise RuntimeError("Encoder residual FiLM block is not initialized")
        if text_embedding.ndim == 4 and text_embedding.shape[2] == 1:
            text_embedding = text_embedding.squeeze(2)
        if text_embedding.ndim != 3:
            raise ValueError("FiLM text_embedding must be [B,P,H] or [B,P,1,H]")
        if text_embedding.shape[0] != img.shape[0]:
            raise ValueError("FiLM image and text batch axes must match")

        if self.encoder.stem is None:
            x = img
        elif self.training and self.encoder_residual_film_gradient_checkpointing:
            x = torch.utils.checkpoint.checkpoint(
                self.encoder.stem,
                img,
                use_reentrant=False,
                preserve_rng_state=True,
            )
        else:
            x = self.encoder.stem(img)
        shallow_skips: list[torch.Tensor] = []
        for stage_index in range(self.encoder_residual_film_stage + 1):
            stage = self.encoder.stages[stage_index]
            if self.training and self.encoder_residual_film_gradient_checkpointing:
                x = torch.utils.checkpoint.checkpoint(
                    stage, x, use_reentrant=False, preserve_rng_state=True
                )
            else:
                x = stage(x)
            shallow_skips.append(x)
        condition_feature = x
        batch, channels, depth, height, width = condition_feature.shape
        prompts = text_embedding.shape[1]
        z_hat, _ = block(condition_feature, text_embedding)
        prompt_deep_skips: list[torch.Tensor] = []
        deeper = z_hat
        for stage_index in range(
            self.encoder_residual_film_stage + 1, len(self.encoder.stages)
        ):
            stage = self.encoder.stages[stage_index]
            if self.training and self.encoder_residual_film_gradient_checkpointing:
                deeper = torch.utils.checkpoint.checkpoint(
                    stage, deeper, use_reentrant=False, preserve_rng_state=True
                )
            else:
                deeper = stage(deeper)
            prompt_deep_skips.append(
                rearrange(
                    deeper,
                    "(b p) c d h w -> b p c d h w",
                    b=batch,
                    p=prompts,
                )
            )
        # The decoder's 1/8 skip is the exact original tensor.  Prompt zero is
        # used only for deeper placeholders that are replaced in each decoder
        # pass below.
        skips = shallow_skips + [item[:, 0] for item in prompt_deep_skips]
        self.last_encoder_residual_film_deep_skips = prompt_deep_skips
        self.last_encoder_residual_film_audit = {
            "input_image_shape": list(img.shape),
            "conditioning_stage": int(self.encoder_residual_film_stage),
            "conditioning_feature_shape": list(condition_feature.shape),
            "z_1_8_shape": list(condition_feature.shape),
            "channel_count": int(channels),
            **block.last_audit,
            "z_hat_shape": list(z_hat.shape),
            "next_encoder_input_shape": list(z_hat.shape),
            "decoder_skip_shape": list(
                skips[self.encoder_residual_film_stage].shape
            ),
            "decoder_skip_is_original": bool(
                skips[self.encoder_residual_film_stage].data_ptr()
                == condition_feature.data_ptr()
            ),
            "deep_skip_shapes": [list(item.shape) for item in prompt_deep_skips],
        }
        return skips, prompt_deep_skips

    def _forward_encoder_token_spatial(
        self,
        img: torch.Tensor,
        token_features: torch.Tensor,
        token_valid_mask: torch.Tensor,
    ) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
        """Condition only deeper stage-4/5 paths; retain the exact 1/8 skip."""
        block = self.encoder_token_spatial_block
        if block is None:
            raise RuntimeError("Encoder token-spatial block is not initialized")
        if token_features.ndim != 4 or token_valid_mask.shape != token_features.shape[:3]:
            raise ValueError("Token-spatial inputs must be [B,P,T,H] and [B,P,T]")
        if token_features.shape[0] != img.shape[0]:
            raise ValueError("Token-spatial image and token batch axes must match")
        x = self.encoder.stem(img) if self.encoder.stem is not None else img
        shallow_skips: list[torch.Tensor] = []
        for stage_index in range(self.encoder_token_spatial_stage + 1):
            x = self.encoder.stages[stage_index](x)
            shallow_skips.append(x)
        z_1_8 = x
        batch, channels, depth, height, width = z_1_8.shape
        prompts = token_features.shape[1]
        z_hat, delta = block(z_1_8, token_features, token_valid_mask)
        conditioned_skip = None
        if self.encoder_token_spatial_conditioned_skip:
            conditioned_skip = z_1_8[:, None] + (
                self.encoder_token_spatial_skip_scale * delta
            )
        prompt_deep_skips: list[torch.Tensor] = []
        deeper = z_hat
        for stage_index in range(self.encoder_token_spatial_stage + 1, len(self.encoder.stages)):
            deeper = self.encoder.stages[stage_index](deeper)
            prompt_deep_skips.append(
                rearrange(deeper, "(b p) c d h w -> b p c d h w", b=batch, p=prompts)
            )
        skips = shallow_skips + [item[:, 0] for item in prompt_deep_skips]
        self.last_encoder_token_spatial_deep_skips = prompt_deep_skips
        self.last_encoder_token_spatial_conditioned_skip = conditioned_skip
        conditioned_skip_ratio = 0.0
        if conditioned_skip is not None:
            skip_delta = (
                conditioned_skip.detach().float() - z_1_8[:, None].detach().float()
            ).permute(0, 1, 3, 4, 5, 2).reshape(-1, channels)
            skip_base = (
                z_1_8.detach().float().permute(0, 2, 3, 4, 1)[:, None]
                .expand(batch, prompts, depth, height, width, channels)
                .reshape(-1, channels)
            )
            conditioned_skip_ratio = float(
                (skip_delta.norm(dim=-1) / skip_base.norm(dim=-1).clamp_min(1e-12))
                .mean()
                .item()
            )
        self.last_encoder_token_spatial_audit = {
            "input_image_shape": list(img.shape),
            "conditioning_stage": int(self.encoder_token_spatial_stage),
            "z_1_8_shape": list(z_1_8.shape),
            "channel_count": int(channels),
            **block.last_audit,
            "z_hat_shape": list(z_hat.shape),
            "next_encoder_input_shape": list(z_hat.shape),
            "decoder_skip_shape": list(skips[self.encoder_token_spatial_stage].shape),
            "decoder_skip_is_original": bool(
                skips[self.encoder_token_spatial_stage].data_ptr() == z_1_8.data_ptr()
            ),
            "conditioned_skip_enabled": self.encoder_token_spatial_conditioned_skip,
            "conditioned_skip_scale": self.encoder_token_spatial_skip_scale,
            "conditioned_skip_shape": (
                None if conditioned_skip is None else list(conditioned_skip.shape)
            ),
            "conditioned_skip_residual_to_feature_norm": conditioned_skip_ratio,
            "deep_skip_shapes": [list(item.shape) for item in prompt_deep_skips],
        }
        return skips, prompt_deep_skips

    def _forward_less_encoder(
        self,
        img: torch.Tensor,
        token_features: torch.Tensor,
        token_valid_mask: torch.Tensor,
    ) -> tuple[list[torch.Tensor], dict[int, torch.Tensor]]:
        """Run repeated, one-way word conditioning inside the encoder hierarchy.

        Stages before the first LESS level are shared.  From that level onward,
        prompt chunks travel through the normal later encoder stages, with a
        fresh image-query/text-key-value update at each configured level.
        """
        if token_features.ndim != 4 or token_valid_mask.shape != token_features.shape[:3]:
            raise ValueError("LESS inputs must be tokens [B,P,T,H] and mask [B,P,T]")
        batch, prompts, n_text, text_dim = token_features.shape
        if batch != img.shape[0] or text_dim != self.text_embedding_dim:
            raise ValueError("LESS image/token dimensions do not match")
        first_level = min(self.less_encoder_levels)
        x = self.encoder.stem(img) if self.encoder.stem is not None else img
        shared_skips: list[torch.Tensor] = []
        for level in range(first_level):
            x = self.encoder.stages[level](x)
            shared_skips.append(x)
        base = x
        prompt_outputs: dict[int, list[torch.Tensor]] = {level: [] for level in range(first_level, len(self.encoder.stages))}
        stage_audits: dict[str, list[dict[str, object]]] = {f"level{level}": [] for level in self.less_encoder_levels}
        final_token_chunks = []
        for prompt_start in range(0, prompts, self.less_encoder_prompt_chunk_size):
            prompt_end = min(prompt_start + self.less_encoder_prompt_chunk_size, prompts)
            p_chunk = prompt_end - prompt_start
            current = repeat(base, "b c d h w -> (b p) c d h w", p=p_chunk)
            flat_tokens = token_features[:, prompt_start:prompt_end].reshape(batch * p_chunk, n_text, text_dim)
            if self.less_encoder_mode == "bico_e345":
                # Only the cached starting state is detached. T3/T4/T5 stay live.
                flat_tokens = flat_tokens.detach()
            flat_mask = token_valid_mask[:, prompt_start:prompt_end].reshape(batch * p_chunk, n_text)
            for level in range(first_level, len(self.encoder.stages)):
                current = self.encoder.stages[level](current)
                if level in self.less_encoder_levels:
                    block = self.less_encoder_blocks[f"level{level}"]
                    if self.less_encoder_mode == "bico_e345":
                        current, flat_tokens = block(current, flat_tokens, flat_mask)
                    else:
                        current = block(current, flat_tokens, flat_mask)
                    stage_audits[f"level{level}"].append(dict(block.last_audit))
                prompt_outputs[level].append(
                    rearrange(current, "(b p) c d h w -> b p c d h w", b=batch, p=p_chunk)
                )
            if self.less_encoder_mode == "bico_e345":
                final_token_chunks.append(flat_tokens.reshape(batch, p_chunk, n_text, text_dim))
        if self.less_encoder_mode == "bico_e345":
            self._word_global_tokens = torch.cat(final_token_chunks, dim=1)
            self._word_global_valid_mask = token_valid_mask
        prompt_skips = {
            level: torch.cat(parts, dim=1)
            for level, parts in prompt_outputs.items()
        }
        skips = shared_skips + [prompt_skips[level][:, 0] for level in range(first_level, len(self.encoder.stages))]
        self.last_less_prompt_skips = prompt_skips
        self.last_less_encoder_audit = {
            "levels": list(self.less_encoder_levels),
            "prompt_chunk_size": self.less_encoder_prompt_chunk_size,
            "input_image_shape": list(img.shape),
            "prompt_skip_shapes": {str(level): list(value.shape) for level, value in prompt_skips.items()},
            "stage_audits": stage_audits,
        }
        return skips, prompt_skips

    def _forward_encoder_propagation(
        self,
        img: torch.Tensor,
        token_features: torch.Tensor,
        token_valid_mask: torch.Tensor,
    ) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
        """Run stage 0--3 once and stages 4--5 once per prompt.

        The returned ordinary skip list keeps the original unmodified 1/8
        tensor at index 3. Prompt-specific deeper tensors are returned
        separately and are installed only for that prompt's decoder pass.
        """
        block = self.encoder_propagation_block
        if block is None:
            raise RuntimeError("Encoder propagation block is not initialized")
        if token_features.ndim != 4:
            raise ValueError("EP token_features must be [B,P,T,H]")
        if token_valid_mask.shape != token_features.shape[:3]:
            raise ValueError("EP token_valid_mask must match [B,P,T]")
        if token_features.shape[0] != img.shape[0]:
            raise ValueError("EP image and token batch axes must match")

        x = self.encoder.stem(img) if self.encoder.stem is not None else img
        shallow_skips: list[torch.Tensor] = []
        for stage_index in range(self.encoder_propagation_stage + 1):
            x = self.encoder.stages[stage_index](x)
            shallow_skips.append(x)
        z_1_8 = x
        batch, channels, depth, height, width = z_1_8.shape
        prompts, n_text, token_dim = token_features.shape[1:]
        image_tokens = rearrange(z_1_8, "b c d h w -> b (d h w) c")
        image_tokens = repeat(image_tokens, "b s c -> (b p) s c", p=prompts)
        flat_tokens = token_features.reshape(batch * prompts, n_text, token_dim)
        flat_mask = token_valid_mask.reshape(batch * prompts, n_text)
        if self.encoder_propagation_mode == "null":
            # This nonconstant, non-parameterized token carries no finding
            # information but survives LayerNorm, allowing EP-Null to control
            # for a trainable image-stream residual rather than a dead branch.
            flat_tokens = self.encoder_propagation_fixed_null_token.to(
                device=flat_tokens.device, dtype=flat_tokens.dtype
            ).expand(batch * prompts, 1, token_dim)
            flat_mask = torch.ones(
                (batch * prompts, 1), device=flat_mask.device, dtype=torch.bool
            )
        conditioned_tokens, delta = block(image_tokens, flat_tokens, flat_mask)
        z_hat = rearrange(
            conditioned_tokens,
            "(b p) (d h w) c -> (b p) c d h w",
            b=batch,
            p=prompts,
            d=depth,
            h=height,
            w=width,
        )
        prompt_deep_skips: list[torch.Tensor] = []
        deeper = z_hat
        for stage_index in range(self.encoder_propagation_stage + 1, len(self.encoder.stages)):
            deeper = self.encoder.stages[stage_index](deeper)
            prompt_deep_skips.append(
                rearrange(deeper, "(b p) c d h w -> b p c d h w", b=batch, p=prompts)
            )
        # Place prompt zero only in otherwise-unused deeper placeholders. The
        # prompt loop below replaces both deeper tensors for every decoder pass.
        skips = shallow_skips + [item[:, 0] for item in prompt_deep_skips]
        delta_float = delta.detach().float()
        z_float = image_tokens.detach().float()
        z_hat_tokens = conditioned_tokens.detach().float()
        z_norm = z_float.norm(dim=-1).clamp_min(1e-12)
        cosine = F.cosine_similarity(z_float, z_hat_tokens, dim=-1, eps=1e-12)
        self.last_encoder_propagation_attention = block.last_attention
        self.last_encoder_propagation_deep_skips = prompt_deep_skips
        self.last_encoder_propagation_audit = {
            "input_image_shape": list(img.shape),
            "z_1_8_shape": list(z_1_8.shape),
            "image_tokens": int(depth * height * width),
            "q_shape": [batch * prompts, depth * height * width, block.attention_dim],
            "text_token_shape": list(flat_tokens.shape),
            "k_shape": [batch * prompts, flat_tokens.shape[1], block.attention_dim],
            "v_shape": [batch * prompts, flat_tokens.shape[1], block.attention_dim],
            "attention_output_shape": list(delta.shape),
            "gamma": float(block.gamma.detach().float().item()),
            "deeper_encoder_input_shape": list(z_hat.shape),
            "decoder_skip_shape": list(skips[self.encoder_propagation_stage].shape),
            "decoder_skip_is_original": bool(
                skips[self.encoder_propagation_stage].data_ptr() == z_1_8.data_ptr()
            ),
            "delta_rms": float(delta_float.square().mean().sqrt().item()),
            "delta_to_feature_norm": float(
                (delta_float.norm(dim=-1) / z_norm).mean().item()
            ),
            "applied_residual_to_feature_norm": float(
                ((z_hat_tokens - z_float).norm(dim=-1) / z_norm).mean().item()
            ),
            "z_to_z_hat_cosine": float(cosine.mean().item()),
            "deep_skip_shapes": [list(item.shape) for item in prompt_deep_skips],
        }
        return skips, prompt_deep_skips

    def _forward_qwen_bica_encoder(
        self,
        img: torch.Tensor,
        prefix_tokens: torch.Tensor,
        token_valid_mask: torch.Tensor,
        *,
        enable_text_to_image: bool,
        enable_image_to_text: bool,
    ) -> tuple[list[torch.Tensor], list[torch.Tensor], torch.Tensor]:
        """Run the requested Stage-3 text→image→text interaction.

        The encoder's first four stages are shared.  Stage 3 is then expanded
        one stream per prompt, updated by the C2 text→image residual, and fed
        through the native stages 4--5.  The corresponding image→text update
        is returned to Qwen's final six causal layers by the caller.
        """
        block = getattr(self, "qwen_bica_block", None)
        if not isinstance(block, Stage3BidirectionalCrossAttention):
            raise RuntimeError("Qwen BiCA was requested without qwen_bica_block")
        if prefix_tokens.ndim != 4 or token_valid_mask.shape != prefix_tokens.shape[:3]:
            raise ValueError("Qwen BiCA tokens must be [B,P,T,2560] plus [B,P,T] mask")
        stage = int(getattr(self, "qwen_bica_stage", 3))
        if stage != 3 or stage >= len(self.encoder.stages):
            raise ValueError("The first Qwen BiCA experiment is fixed to encoder stage 3")
        x = self.encoder.stem(img) if self.encoder.stem is not None else img
        shallow_skips: list[torch.Tensor] = []
        for stage_index in range(stage + 1):
            x = self.encoder.stages[stage_index](x)
            shallow_skips.append(x)
        base_stage3 = x
        batch, channels, depth, height, width = base_stage3.shape
        prompts, n_text, text_dim = prefix_tokens.shape[1:]
        if channels != block.image_dim or text_dim != block.text_dim:
            raise ValueError("Qwen BiCA stage-3/text dimensions do not match the initialized block")
        image_tokens = rearrange(base_stage3, "b c d h w -> b (d h w) c")
        flat_image = repeat(image_tokens, "b s c -> (b p) s c", p=prompts)
        flat_text = prefix_tokens.reshape(batch * prompts, n_text, text_dim)
        flat_mask = token_valid_mask.reshape(batch * prompts, n_text)
        conditioned_image, conditioned_text = block(
            flat_image,
            flat_text,
            flat_mask,
            enable_text_to_image=enable_text_to_image,
            enable_image_to_text=enable_image_to_text,
        )
        conditioned_stage3 = rearrange(
            conditioned_image,
            "(b p) (d h w) c -> b p c d h w",
            b=batch,
            p=prompts,
            d=depth,
            h=height,
            w=width,
        )
        # Keep the exact residual that is actually written into the Stage-3
        # image stream.  Unlike the block's detached diagnostics, this tensor
        # retains its graph so an opt-in auxiliary objective can supervise the
        # spatial writeback without changing the forward architecture.
        self.last_qwen_bica_effective_image_residual = (
            conditioned_stage3 - base_stage3[:, None]
        )
        prompt_deep_skips: list[torch.Tensor] = []
        deeper = rearrange(conditioned_stage3, "b p c d h w -> (b p) c d h w")
        for stage_index in range(stage + 1, len(self.encoder.stages)):
            deeper = self.encoder.stages[stage_index](deeper)
            prompt_deep_skips.append(
                rearrange(deeper, "(b p) c d h w -> b p c d h w", b=batch, p=prompts)
            )
        skips = shallow_skips + [item[:, 0] for item in prompt_deep_skips]
        self.last_qwen_bica_conditioned_stage3 = conditioned_stage3
        self.last_qwen_bica_updated_prefix_tokens = rearrange(
            conditioned_text, "(b p) t c -> b p t c", b=batch, p=prompts
        )
        self.last_qwen_bica_audit = {
            "stage": stage,
            "base_stage3_shape": list(base_stage3.shape),
            "conditioned_stage3_shape": list(conditioned_stage3.shape),
            "updated_prefix_shape": list(self.last_qwen_bica_updated_prefix_tokens.shape),
            "deep_skip_shapes": [list(item.shape) for item in prompt_deep_skips],
            **block.last_audit,
        }
        return skips, prompt_deep_skips, self.last_qwen_bica_updated_prefix_tokens

    def configure_medplex_text_tower(self, backbone: nn.Module) -> None:
        """Attach the native trainable BERT tower after loading a static anchor."""
        if self.medplex_mode == "none":
            raise RuntimeError("Cannot attach a MedPlex tower when medplex_mode is none")
        self.medplex_staged_text = StagedBert(backbone)

    def _forward_medplex_encoder(
        self,
        img: torch.Tensor,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: torch.Tensor | None,
    ) -> tuple[list[torch.Tensor], list[torch.Tensor], torch.Tensor]:
        """Interleave native BERT groups and native image stages 2--5.

        Image stages 0--1 are the shared pre-V1 stem.  Each fused V_s is the
        actual input to the next encoder stage; prompt streams only expand at
        V1, so no later feature is post-hoc extracted from a static encoder.
        """
        if self.medplex_staged_text is None:
            raise RuntimeError("MedPlex mode requires an attached staged BERT text tower")
        if input_ids.ndim != 3 or attention_mask.shape != input_ids.shape:
            raise ValueError("MedPlex ids and attention mask must be [B,P,L]")
        batch, prompts, length = input_ids.shape
        flat_ids = input_ids.reshape(batch * prompts, length)
        flat_mask = attention_mask.reshape(batch * prompts, length)
        flat_types = None if token_type_ids is None else token_type_ids.reshape(batch * prompts, length)
        state = self.medplex_staged_text.stage0(flat_ids, flat_mask, flat_types)
        state = self.medplex_staged_text.advance(1, state)
        x = self.encoder.stem(img) if self.encoder.stem is not None else img
        skips: list[torch.Tensor] = []
        for stage_index in range(2):
            x = self.encoder.stages[stage_index](x)
            skips.append(x)
        prompt_skips: list[torch.Tensor] = []
        x_prompt: torch.Tensor | None = None
        for fusion_index, image_stage in enumerate(range(2, 6)):
            if fusion_index:
                state = self.medplex_staged_text.advance(fusion_index + 1, state)
                assert x_prompt is not None
                x_prompt = self.encoder.stages[image_stage](x_prompt)
            else:
                x = self.encoder.stages[image_stage](x)
                x_prompt = x.repeat_interleave(prompts, dim=0)
            channels, depth, height, width = x_prompt.shape[1:]
            image_tokens = x_prompt.flatten(2).transpose(1, 2)
            stage_enabled = bool(
                getattr(self, "medplex_bifusion_stage_enabled", [True] * len(self.medplex_fusions))[fusion_index]
            )
            if stage_enabled:
                image_tokens, text_hidden = self.medplex_fusions[fusion_index](
                    image_tokens,
                    state.hidden,
                    state.attention_mask.to(torch.bool),
                    enable_text_to_image=bool(getattr(self, "medplex_bifusion_text_to_image_enabled", True)),
                    enable_image_to_text=bool(getattr(self, "medplex_bifusion_image_to_text_enabled", True)),
                )
            else:
                text_hidden = state.hidden
                self.medplex_fusions[fusion_index].last_audit = {
                    "stage_enabled": False,
                    "image_tokens": int(image_tokens.shape[1]),
                    "text_tokens": int(state.hidden.shape[1]),
                    "image_relative_l2": 0.0,
                    "text_relative_l2": 0.0,
                }
            x_prompt = image_tokens.transpose(1, 2).reshape(-1, channels, depth, height, width)
            state = StagedBertState(text_hidden, state.attention_mask, state.token_type_ids, state.position_ids)
            prompt_skips.append(x_prompt.reshape(batch, prompts, channels, depth, height, width))
        skips.extend(item[:, 0] for item in prompt_skips)
        self.last_medplex_audit = {
            "image_stage_shapes": [list(item.shape) for item in prompt_skips],
            "gamma_image": [float(item.gamma_image.detach()) for item in self.medplex_fusions],
            "gamma_text": [float(item.gamma_text.detach()) for item in self.medplex_fusions],
            "stage_enabled": list(getattr(self, "medplex_bifusion_stage_enabled", [])),
            "text_to_image_enabled": bool(getattr(self, "medplex_bifusion_text_to_image_enabled", True)),
            "image_to_text_enabled": bool(getattr(self, "medplex_bifusion_image_to_text_enabled", True)),
            "stages": [dict(item.last_audit) for item in self.medplex_fusions],
        }
        return skips, prompt_skips, state.hidden[:, 0].reshape(batch, prompts, 768)

    def _forward_medplex_text_control(
        self,
        img: torch.Tensor,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: torch.Tensor | None,
    ) -> tuple[list[torch.Tensor], torch.Tensor]:
        """Run the trainable full BERT tower without image--text BiFusion.

        P0/B0 use the ordinary native image encoder and the exact same staged
        BERT wrapper as M1/M2.  ``full_staged`` is numerically equivalent to a
        normal Hugging Face BERT forward; keeping the wrapper shared makes the
        text-tower parameterization and checkpoint namespace pair-matched.
        """
        if self.medplex_staged_text is None:
            raise RuntimeError("Trainable-text control requires an attached BERT tower")
        if input_ids.ndim != 3 or attention_mask.shape != input_ids.shape:
            raise ValueError("MedPlex ids and attention mask must be [B,P,L]")
        batch, prompts, length = input_ids.shape
        flat_ids = input_ids.reshape(batch * prompts, length)
        flat_mask = attention_mask.reshape(batch * prompts, length)
        flat_types = (
            None
            if token_type_ids is None
            else token_type_ids.reshape(batch * prompts, length)
        )
        state = self.medplex_staged_text.full_staged(flat_ids, flat_mask, flat_types)
        self.last_medplex_audit = {
            "bifusion_enabled": False,
            "image_stage_shapes": [],
            "gamma_image": [],
            "gamma_text": [],
            "stages": [],
        }
        return self.encoder(img), state.hidden[:, 0].reshape(batch, prompts, 768)

    def forward(
        self,
        img,
        text_embedding=None,
        return_presence_logits=False,
        spatial_attention_rho_scale: float | torch.Tensor | None = None,
        s2_attention_gate_scale: float | torch.Tensor | None = None,
        s2_attention_scale_factors: dict[str, float] | None = None,
        s3_attention_gate_scale: float | torch.Tensor | None = None,
        s3_attention_gate_scales_by_scale: dict[str, float | torch.Tensor] | None = None,
        s3_fullres_refinement_scale: float | torch.Tensor | None = None,
        s3_joint_fusion_scale: float | torch.Tensor | None = None,
        adaptive_rho_category_indices: torch.Tensor | None = None,
        adaptive_rho_active_mask: torch.Tensor | None = None,
        category_router_indices: torch.Tensor | None = None,
        target_attention_adapter_active_mask: torch.Tensor | None = None,
        apply_prompt_residual_adapter: bool = True,
        prompt_adapter_injection_mode: str = "shared",
        anatomy_embedding: torch.Tensor | None = None,
        anatomy_valid_mask: torch.Tensor | None = None,
        apply_anatomy_residual_adapter: bool = True,
        token_features: torch.Tensor | None = None,
        token_valid_mask: torch.Tensor | None = None,
        less_token_features: torch.Tensor | None = None,
        less_token_valid_mask: torch.Tensor | None = None,
        word_global_token_features: torch.Tensor | None = None,
        word_global_token_valid_mask: torch.Tensor | None = None,
        encoder_residual_film_embedding: torch.Tensor | None = None,
        qwen_prefix_hidden: torch.Tensor | None = None,
        qwen_attention_mask: torch.Tensor | None = None,
        qwen_position_ids: torch.Tensor | None = None,
        qwen_bica_text_to_image_enabled: bool = True,
        qwen_bica_image_to_text_enabled: bool = True,
        medplex_input_ids: torch.Tensor | None = None,
        medplex_attention_mask: torch.Tensor | None = None,
        medplex_token_type_ids: torch.Tensor | None = None,
    ):
        self.last_auxiliary_stats = {}
        self.last_spatial_attention_maps = []
        self.last_spatial_attention_maps_by_scale = {}
        self.last_s2_attention_maps = {scale: [] for scale in self.s2_attention_scales}
        self.last_s3_attention_maps = {scale: [] for scale in self.s3_attention_scales}
        self.last_s3_attention_logits = {scale: [] for scale in self.s3_attention_scales}
        self.last_s3_fullres_similarity_maps = {"1/1": []}
        self.last_s3_fullres_alignment_inputs = []
        self.last_s3_joint_fusion_corrections = []
        self.last_target_attention_residuals = []
        self.last_proposal_features = []
        self.last_token_image_text_attention = []
        self.last_fan_image_text_audits = {}
        self.last_fan_image_text_attention = {}
        self.last_fan_image_text_logits = {}
        self.last_fan_image_text_residuals = {}
        self.last_fan_image_text_features = {}
        self.last_fan_prompt_memory = None
        self.last_fan_decoder_feature = None
        self.last_bidir_prompt_audit = {}
        self.last_bidir_prompt_attention = []
        self.last_encoder_propagation_attention = None
        self.last_encoder_propagation_audit = {}
        self.last_encoder_propagation_deep_skips = None
        self.last_encoder_residual_film_audit = {}
        self.last_encoder_residual_film_deep_skips = None
        self.last_encoder_token_spatial_audit = {}
        self.last_encoder_token_spatial_deep_skips = None
        self.last_encoder_token_spatial_conditioned_skip = None
        self.last_less_encoder_audit = {}
        self.last_less_prompt_skips = None
        self.last_less_decoder_stage2 = None
        self.last_qwen_bica_audit = {}
        self.last_qwen_bica_conditioned_stage3 = None
        self.last_qwen_bica_effective_image_residual = None
        self.last_qwen_bica_updated_prefix_tokens = None
        self.last_qwen_pooled_embedding = None
        self.last_word_global_audit = {}
        self.last_word_global_features = {}
        self._word_global_b1_prompt_index = 0
        effective_word_global_tokens = (
            token_features
            if word_global_token_features is None
            else word_global_token_features
        )
        effective_word_global_mask = (
            token_valid_mask
            if word_global_token_valid_mask is None
            else word_global_token_valid_mask
        )
        effective_less_tokens = (
            token_features if less_token_features is None else less_token_features
        )
        effective_less_mask = (
            token_valid_mask
            if less_token_valid_mask is None
            else less_token_valid_mask
        )
        if self.word_global_mode != "none":
            if effective_word_global_tokens is None or effective_word_global_mask is None:
                raise ValueError(
                    f"word_global_mode={self.word_global_mode} requires contextual "
                    "token_features and token_valid_mask"
                )
            if (
                effective_word_global_tokens.ndim != 4
                or effective_word_global_mask.shape
                != effective_word_global_tokens.shape[:3]
            ):
                raise ValueError(
                    "word-global tokens must be [B,P,L,D] with mask [B,P,L]"
                )
            if effective_word_global_tokens.shape[-1] != self.text_embedding_dim:
                raise ValueError(
                    f"word-global token dim {effective_word_global_tokens.shape[-1]} != "
                    f"expected {self.text_embedding_dim}"
                )
            self._word_global_tokens = effective_word_global_tokens
            self._word_global_valid_mask = effective_word_global_mask.to(torch.bool)
        else:
            self._word_global_tokens = None
            self._word_global_valid_mask = None
        if self.s3_fullres_alignment_head is not None:
            self.s3_fullres_alignment_head.forward_count = 0
        if self.decoder.capture_native_response_maps:
            self.decoder.reset_native_response_capture()
        prompt_deep_skips = None
        less_prompt_skips = None
        qwen_lora_mode = str(getattr(self, "qwen_lora_mode", "none"))
        medplex_requested = medplex_input_ids is not None
        medplex_identity_bypass = bool(
            medplex_requested
            and not self.training
            and self.medplex_cls_gate is not None
            and float(self.medplex_cls_gate.detach()) == 0.0
            and all(
                float(block.gamma_image.detach()) == 0.0
                and float(block.gamma_text.detach()) == 0.0
                for block in self.medplex_fusions
            )
        )
        medplex_active = medplex_requested and not medplex_identity_bypass
        medplex_bifusion_active = bool(
            medplex_active and self.medplex_bifusion_enabled
        )
        medplex_static_embedding = text_embedding if medplex_requested else None
        if medplex_identity_bypass:
            # At the update-0 evaluation gate, execute exactly the mature
            # static anchor path.  Although zero residuals are mathematically
            # identities, running later encoder stages as a repeated
            # prompt-batch can select different floating-point kernels.  The
            # training path never bypasses, so all residual gates still get a
            # first-step gradient and wake normally.
            skips = self.encoder(img)
            self.last_medplex_audit = {
                "identity_bypass": True,
                "cls_gate": 0.0,
                "cls_relative_l2": 0.0,
                "gamma_image": [0.0] * len(self.medplex_fusions),
                "gamma_text": [0.0] * len(self.medplex_fusions),
                "stages": [],
            }
        elif medplex_active:
            if self.medplex_mode == "none" or medplex_attention_mask is None:
                raise ValueError("MedPlex inputs require enabled MedPlex mode and an attention mask")
            if self.medplex_bifusion_enabled:
                skips, prompt_deep_skips, pooled = self._forward_medplex_encoder(
                    img, medplex_input_ids, medplex_attention_mask, medplex_token_type_ids
                )
            else:
                skips, pooled = self._forward_medplex_text_control(
                    img, medplex_input_ids, medplex_attention_mask, medplex_token_type_ids
                )
            text_embedding = pooled.unsqueeze(2)
        elif qwen_prefix_hidden is not None:
            if qwen_lora_mode not in {"global", "bica_stage3"}:
                raise ValueError("Qwen prefix inputs require qwen_lora_mode global or bica_stage3")
            if qwen_attention_mask is None or qwen_position_ids is None:
                raise ValueError("Qwen prefix inputs require attention mask and position ids")
            qwen_adapter = getattr(self, "qwen_adapter", None)
            if qwen_adapter is None:
                raise RuntimeError("Qwen prefix inputs require a loaded qwen_adapter")
            if qwen_prefix_hidden.ndim != 4:
                raise ValueError("Qwen prefix hidden states must be [B,P,T,2560]")
            if qwen_lora_mode == "bica_stage3":
                enable_t2i = bool(qwen_bica_text_to_image_enabled) and bool(
                    getattr(self, "qwen_bica_text_to_image_enabled", True)
                )
                enable_i2t = bool(qwen_bica_image_to_text_enabled) and bool(
                    getattr(self, "qwen_bica_image_to_text_enabled", True)
                )
                skips, prompt_deep_skips, qwen_prefix_hidden = self._forward_qwen_bica_encoder(
                    img,
                    qwen_prefix_hidden,
                    qwen_attention_mask.to(torch.bool),
                    enable_text_to_image=enable_t2i,
                    enable_image_to_text=enable_i2t,
                )
            else:
                skips = self.encoder(img)
            batch, prompts, n_text, hidden = qwen_prefix_hidden.shape
            flat_hidden = qwen_prefix_hidden.reshape(batch * prompts, n_text, hidden)
            flat_mask = qwen_attention_mask.reshape(batch * prompts, n_text)
            flat_positions = qwen_position_ids.reshape(batch * prompts, n_text)
            qwen_hidden = qwen_adapter.forward_from_prefix(
                flat_hidden, flat_mask, flat_positions
            )
            pooled = qwen_adapter.last_token_pool(qwen_hidden, flat_mask)
            self.last_qwen_pooled_embedding = rearrange(
                pooled.detach(), "(b p) c -> b p c", b=batch, p=prompts
            )
            text_embedding = rearrange(pooled, "(b p) c -> b p 1 c", b=batch, p=prompts)
        elif self.encoder_propagation_mode != "none":
            if token_features is None or token_valid_mask is None:
                raise ValueError(
                    f"EP-{self.encoder_propagation_mode} requires token_features and "
                    "token_valid_mask"
                )
            skips, prompt_deep_skips = self._forward_encoder_propagation(
                img, token_features, token_valid_mask
            )
        elif self.encoder_token_spatial_mode != "none":
            if token_features is None or token_valid_mask is None:
                raise ValueError("Token-spatial conditioning requires token_features and token_valid_mask")
            skips, prompt_deep_skips = self._forward_encoder_token_spatial(
                img, token_features, token_valid_mask
            )
        elif self.less_encoder_mode != "none":
            if effective_less_tokens is None or effective_less_mask is None:
                raise ValueError("LESS conditioning requires token_features and token_valid_mask")
            if self.less_encoder_bypass:
                skips = self.encoder(img)
                less_prompt_skips = None
                self.last_less_encoder_audit = {
                    "levels": list(self.less_encoder_levels),
                    "bypass": True,
                    "input_image_shape": list(img.shape),
                }
            else:
                skips, less_prompt_skips = self._forward_less_encoder(
                    img, effective_less_tokens, effective_less_mask
                )
        elif self.encoder_residual_film_mode != "none":
            film_embedding = (
                text_embedding
                if encoder_residual_film_embedding is None
                else encoder_residual_film_embedding
            )
            if film_embedding is None:
                raise ValueError("Residual FiLM requires a pooled text embedding")
            skips, prompt_deep_skips = self._forward_encoder_residual_film(
                img, film_embedding
            )
        elif self.lobe_input_mode in {"embedding", "onehot_adapter"}:
            if img.ndim != 5 or img.shape[1] != 2:
                raise ValueError(
                    f"{self.lobe_input_mode} lobe input expects [B,2,D,H,W] "
                    "containing CT and uint8-like label; "
                    f"got {tuple(img.shape)}"
                )
            lobe_label = img[:, 1].round().long().clamp_(0, 5)
            skips = self.encoder(img[:, :1])
            if self.lobe_input_mode == "embedding":
                assert self.lobe_embedding is not None
                assert self.lobe_embedding_projection is not None
                lobe_features = self.lobe_embedding(lobe_label).permute(0, 4, 1, 2, 3)
                lobe_residual = self.lobe_embedding_projection(
                    lobe_features.to(skips[0].dtype)
                )
            else:
                assert self.lobe_anatomy_adapter is not None
                lobe_onehot = F.one_hot(lobe_label, num_classes=6)[..., 1:]
                lobe_onehot = lobe_onehot.permute(0, 4, 1, 2, 3).to(skips[0].dtype)
                if tuple(lobe_onehot.shape[2:]) != tuple(skips[0].shape[2:]):
                    lobe_onehot = F.interpolate(
                        lobe_onehot,
                        size=skips[0].shape[2:],
                        mode="nearest",
                    )
                lobe_residual = self.lobe_anatomy_adapter(lobe_onehot)
            if tuple(lobe_residual.shape[2:]) != tuple(skips[0].shape[2:]):
                lobe_residual = F.interpolate(
                    lobe_residual,
                    size=skips[0].shape[2:],
                    mode="trilinear",
                    align_corners=False,
                )
            if self.lobe_input_mode == "onehot_adapter":
                residual_stats = lobe_residual.detach().float()
                self.last_lobe_adapter_output_stats = {
                    "lobe_adapter_output_mean": float(residual_stats.mean().item()),
                    "lobe_adapter_output_std": float(residual_stats.std().item()),
                    "lobe_adapter_output_rms": float(
                        residual_stats.square().mean().sqrt().item()
                    ),
                }
            skips[0] = skips[0] + lobe_residual
        else:
            skips = self.encoder(img)
        selected_feature = skips[self.selected_decoder_layer]
        text_embedding = text_embedding.squeeze(2)
        if medplex_requested:
            if medplex_active:
                if medplex_static_embedding is None or self.medplex_cls_gate is None:
                    raise RuntimeError("MedPlex identity anchor or CLS gate is missing")
                static_cls = medplex_static_embedding.squeeze(2).to(text_embedding.dtype)
                online_cls = text_embedding
                # Forward value is exactly online_cls.  The zero-valued
                # straight-through term gives the sentinel a gradient so later
                # evaluation leaves the update-0 static bypass, without ever
                # scaling the BERT gradient by a tiny transition coefficient.
                sentinel_wake = self.medplex_cls_gate.to(text_embedding.dtype)
                sentinel_wake = sentinel_wake - sentinel_wake.detach()
                text_embedding = online_cls + sentinel_wake * (
                    online_cls - static_cls
                ).detach()
                self.last_medplex_audit["cls_gate"] = float(
                    self.medplex_cls_gate.detach()
                )
                with torch.no_grad():
                    cls_norm = static_cls.detach().float().flatten(1).norm(dim=1).clamp_min(1e-12)
                    cls_delta = (online_cls.detach().float() - static_cls.detach().float()).flatten(1)
                    self.last_medplex_audit["cls_relative_l2"] = float(
                        (cls_delta.norm(dim=1) / cls_norm).mean()
                    )
            if self.text_input_adapter is None:
                raise RuntimeError(
                    "MedPlex pooled CLS requires the anchor's 768-to-2560 text adapter"
                )
            text_embedding = self.text_input_adapter(text_embedding)
        text_embed = repeat(text_embedding, "b n dim -> n b dim")
        text_embed = self.project_text_embed(text_embed)
        base_text_embed = text_embed
        self.last_prompt_adapter_base_query = text_embed.detach()
        self.last_prompt_adapter_residual = None
        self.last_anatomy_adapter_base_query = None
        self.last_anatomy_adapter_residual = None
        self.last_anatomy_valid_mask = None
        self.last_category_router_diagnostics = []
        if apply_prompt_residual_adapter and self.prompt_residual_adapter is not None:
            prompt_residual = self.prompt_residual_adapter(text_embed)
            self.last_prompt_adapter_residual = prompt_residual.detach()
            text_embed = text_embed + prompt_residual
        valid_prompt_adapter_injection_modes = {"shared", "s3_only", "decoder_only"}
        if prompt_adapter_injection_mode not in valid_prompt_adapter_injection_modes:
            raise ValueError(
                "prompt_adapter_injection_mode must be one of "
                f"{sorted(valid_prompt_adapter_injection_modes)}, got "
                f"{prompt_adapter_injection_mode!r}"
            )
        if (
            prompt_adapter_injection_mode != "shared"
            and anatomy_embedding is not None
            and apply_anatomy_residual_adapter
        ):
            raise ValueError(
                "Diagnostic prompt-adapter path separation is incompatible with "
                "anatomy residual injection"
            )
        if (
            apply_anatomy_residual_adapter
            and getattr(self, "anatomy_residual_adapter", None) is not None
            and anatomy_embedding is not None
        ):
            anatomy_embedding = anatomy_embedding.squeeze(2)
            if anatomy_embedding.shape[:2] != text_embedding.shape[:2]:
                raise ValueError(
                    "anatomy_embedding must match text_embedding batch/prompt shape: "
                    f"{tuple(anatomy_embedding.shape[:2])} != {tuple(text_embedding.shape[:2])}"
                )
            anatomy_embed = repeat(anatomy_embedding, "b n dim -> n b dim")
            anatomy_embed = self.project_text_embed(anatomy_embed)
            if anatomy_valid_mask is None:
                valid_mask = torch.ones(
                    text_embedding.shape[:2],
                    device=anatomy_embed.device,
                    dtype=anatomy_embed.dtype,
                )
            else:
                if anatomy_valid_mask.ndim == 1:
                    anatomy_valid_mask = anatomy_valid_mask.unsqueeze(0)
                if tuple(anatomy_valid_mask.shape) != tuple(text_embedding.shape[:2]):
                    raise ValueError(
                        "anatomy_valid_mask must match text_embedding batch/prompt shape: "
                        f"{tuple(anatomy_valid_mask.shape)} != {tuple(text_embedding.shape[:2])}"
                    )
                valid_mask = anatomy_valid_mask.to(device=anatomy_embed.device, dtype=anatomy_embed.dtype)
            anatomy_residual = self.anatomy_residual_adapter(anatomy_embed)
            anatomy_residual = anatomy_residual * repeat(valid_mask, "b n -> n b 1")
            self.last_anatomy_adapter_base_query = anatomy_embed.detach()
            self.last_anatomy_adapter_residual = anatomy_residual.detach()
            self.last_anatomy_valid_mask = valid_mask.detach()
            text_embed = text_embed + self.gamma_anatomy.to(dtype=text_embed.dtype) * anatomy_residual
        # The native text decoder always consumes its selected decoder layer
        # (normally stage 4, C=320).  BiCA itself is injected at stage 3
        # (C=256), so its prompt-specific stage-4 continuation—not the raw
        # stage-3 residual—is the compatible decoder memory.
        if medplex_bifusion_active:
            assert prompt_deep_skips is not None
            conditioned_selected_features = prompt_deep_skips[self.selected_decoder_layer - 2]
        elif qwen_lora_mode == "bica_stage3":
            if prompt_deep_skips is None:
                raise RuntimeError("Qwen BiCA did not produce prompt-specific deep skips")
            qwen_stage = int(getattr(self, "qwen_bica_stage", 3))
            qwen_deep_index = self.selected_decoder_layer - (qwen_stage + 1)
            if not 0 <= qwen_deep_index < len(prompt_deep_skips):
                raise RuntimeError(
                    "Qwen BiCA cannot provide the selected decoder-layer memory: "
                    f"selected={self.selected_decoder_layer}, injection={qwen_stage}"
                )
            conditioned_selected_features = prompt_deep_skips[qwen_deep_index]
        else:
            conditioned_selected_features = None
        fan_conditioned_skips: dict[int, torch.Tensor] | None = None
        if self.bidir_prompt_decoder_mode != "none":
            global_image_to_text_only = (
                self.bidir_prompt_decoder_mode == "global_image_to_text_old_fusion"
            )
            if not global_image_to_text_only:
                if token_features is None or token_valid_mask is None:
                    raise ValueError(
                        "Bidirectional Prompt Decoder requires token_features and "
                        "token_valid_mask"
                    )
                if token_features.ndim != 4:
                    raise ValueError(
                        "token_features must be [B,P,T,H], got "
                        f"{tuple(token_features.shape)}"
                    )
                batch, prompts, n_text, token_dim = token_features.shape
                if token_features.shape[:2] != text_embedding.shape[:2]:
                    raise ValueError(
                        "token features must match the pooled prompt batch/prompt axes"
                    )
                expected_mask_shape = (batch, prompts, n_text)
                if tuple(token_valid_mask.shape) != expected_mask_shape:
                    raise ValueError(
                        "token_valid_mask must have shape "
                        f"{expected_mask_shape}, got {tuple(token_valid_mask.shape)}"
                    )
            if prompt_adapter_injection_mode != "shared":
                raise ValueError(
                    "Separated prompt-adapter injection is not supported by "
                    "Bidirectional Prompt Decoder E1/E2"
                )
            assert self.bidir_prompt_decoder is not None
            assert self.bidir_prompt_image_writeback is not None
            batch, prompts = text_embedding.shape[:2]
            _, channels, depth, height, width = selected_feature.shape

            projected_image = self.project_bottleneck_embed(
                rearrange(selected_feature, "b c d h w -> b h w d c")
            )
            image_state = repeat(
                rearrange(projected_image, "b h w d c -> (h w d) b c"),
                "s b c -> s (b p) c",
                p=prompts,
            )
            global_token = rearrange(text_embed, "p b c -> 1 (b p) c")
            if global_image_to_text_only:
                text_state = global_token
                text_key_padding_mask = None
                token_feature_shape: list[int] | None = None
                token_valid_fraction: float | None = None
            else:
                assert token_features is not None and token_valid_mask is not None
                assert self.bidir_prompt_token_projection is not None
                flat_tokens = rearrange(
                    token_features.to(device=text_embed.device, dtype=text_embed.dtype),
                    "b p t c -> (b p) t c",
                )
                token_state = self.bidir_prompt_token_projection(flat_tokens)
                token_state = rearrange(token_state, "bp t c -> t bp c")
                text_state = torch.cat((global_token, token_state), dim=0)
                flat_valid = rearrange(
                    token_valid_mask.to(device=text_embed.device, dtype=torch.bool),
                    "b p t -> (b p) t",
                )
                global_padding = torch.zeros(
                    flat_valid.shape[0],
                    1,
                    device=flat_valid.device,
                    dtype=torch.bool,
                )
                text_key_padding_mask = torch.cat((global_padding, ~flat_valid), dim=1)
                token_feature_shape = list(token_features.shape)
                token_valid_fraction = float(flat_valid.float().mean().item())
            self.bidir_prompt_decoder.capture_attention = bool(
                self.capture_bidir_prompt_attention
            )
            bidir_text, bidir_image = self.bidir_prompt_decoder(
                text_state,
                image_state,
                pos=repeat(self.pos_embed, "s 1 c -> s bp c", bp=batch * prompts),
                text_key_padding_mask=text_key_padding_mask,
            )
            conditioned_mask_embedding = rearrange(
                bidir_text[0],
                "(b p) c -> b p c",
                b=batch,
                p=prompts,
            )
            image_grid = rearrange(
                bidir_image,
                "(h w d) (b p) c -> b p h w d c",
                b=batch,
                p=prompts,
                h=height,
                w=width,
                d=depth,
            )
            image_delta = self.bidir_prompt_image_writeback(image_grid)
            image_delta = rearrange(
                image_delta,
                "b p h w d c -> b p c d h w",
            )
            conditioned_selected_features = repeat(
                selected_feature,
                "b c d h w -> b p c d h w",
                p=prompts,
            ) + self.bidir_prompt_residual_scale * image_delta
            selected_feature_float = selected_feature.detach().float()
            delta_float = (
                self.bidir_prompt_residual_scale * image_delta.detach().float()
            )
            self.last_bidir_prompt_audit = {
                **self.bidir_prompt_decoder.last_audit,
                "mode": self.bidir_prompt_decoder_mode,
                "input_selected_feature_shape": list(selected_feature.shape),
                "conditioned_selected_feature_shape": list(
                    conditioned_selected_features.shape
                ),
                "mask_embedding_shape": list(conditioned_mask_embedding.shape),
                "token_feature_shape": token_feature_shape,
                "token_valid_fraction": token_valid_fraction,
                "image_writeback_residual_scale": float(
                    self.bidir_prompt_residual_scale
                ),
                "image_writeback_delta_rms": float(
                    delta_float.square().mean().sqrt().item()
                ),
                "selected_feature_rms": float(
                    selected_feature_float.square().mean().sqrt().item()
                ),
                "uses_old_decoder_fusion": self.bidir_prompt_decoder_mode in {
                    "old_fusion", "global_image_to_text_old_fusion"
                },
                "uses_no_fusion_decoder": self.bidir_prompt_decoder_mode in {
                    "no_old_fusion",
                    "no_old_fusion_reuse_decoder",
                },
            }
            self.last_bidir_prompt_attention = list(
                self.bidir_prompt_decoder.last_attention
            )
        elif self.global_sentence_feedback_mode != "none":
            # Keep every released TransformerDecoderLayer intact.  We replicate
            # the complete query set once per finding stream so native query
            # self-attention remains within the original prompt set, while each
            # stream receives only its own one-sentence image-memory feedback.
            # When feedback is disabled all memory copies are equal, making the
            # diagonal output exactly the native decoder output in eval mode.
            if prompt_adapter_injection_mode != "shared":
                raise ValueError(
                    "Separated prompt-adapter injection is not supported by global "
                    "sentence image feedback"
                )
            batch, prompts = text_embedding.shape[:2]
            _, channels, depth, height, width = selected_feature.shape
            projected = self.project_bottleneck_embed(
                rearrange(selected_feature, "b c d h w -> b h w d c")
            )
            initial_memory = rearrange(projected, "b h w d c -> (h w d) b c")
            memory = repeat(initial_memory, "s b c -> s (b p) c", p=prompts)
            output = (
                text_embed[:, :, None, :]
                .expand(prompts, batch, prompts, text_embed.shape[-1])
                .reshape(prompts, batch * prompts, text_embed.shape[-1])
            )
            pos = repeat(self.pos_embed, "s 1 c -> s bp c", bp=batch * prompts)
            self.last_global_sentence_feedback_audits = []
            for layer_index, (layer, feedback) in enumerate(
                zip(self.transformer_decoder.layers, self.global_sentence_feedback_blocks)
            ):
                output, _ = layer(
                    output,
                    memory,
                    pos=pos,
                    memory_key_padding_mask=None,
                    residual=True,
                )
                output_by_query_stream = output.reshape(
                    prompts, batch, prompts, output.shape[-1]
                )
                sentence = torch.stack(
                    [output_by_query_stream[prompt, :, prompt] for prompt in range(prompts)],
                    dim=1,
                )
                sentence = rearrange(sentence, "b p c -> 1 (b p) c")
                memory = feedback(
                    memory,
                    sentence,
                    enabled=bool(self.global_sentence_feedback_enabled),
                )
                self.last_global_sentence_feedback_audits.append(
                    {"layer": int(layer_index + 1), **feedback.last_audit}
                )
            if self.transformer_decoder.norm is not None:
                output = self.transformer_decoder.norm(output)
            output_by_query_stream = output.reshape(
                prompts, batch, prompts, output.shape[-1]
            )
            conditioned_mask_embedding = torch.stack(
                [output_by_query_stream[prompt, :, prompt] for prompt in range(prompts)],
                dim=1,
            )
            if self.capture_global_sentence_feedback:
                self.last_global_sentence_feedback_final_memory = memory.detach()
            else:
                self.last_global_sentence_feedback_final_memory = None
            self.original_cross_attention_forward_count += 1
        elif self.fan_image_text_mode != "none":
            if token_features is None or token_valid_mask is None:
                raise ValueError(
                    "FAN hierarchical fusion requires token_features and "
                    "token_valid_mask"
                )
            if token_features.ndim != 4:
                raise ValueError(
                    "token_features must be [B,P,T,H], got "
                    f"{tuple(token_features.shape)}"
                )
            batch, prompts, n_text, token_dim = token_features.shape
            if token_features.shape[:2] != text_embedding.shape[:2]:
                raise ValueError(
                    "token features must match the pooled prompt batch/prompt axes"
                )
            expected_mask_shape = (batch, prompts, n_text)
            if tuple(token_valid_mask.shape) != expected_mask_shape:
                raise ValueError(
                    "token_valid_mask must have shape "
                    f"{expected_mask_shape}, got {tuple(token_valid_mask.shape)}"
                )
            flat_tokens = token_features.reshape(batch * prompts, n_text, token_dim)
            flat_mask = token_valid_mask.reshape(batch * prompts, n_text)
            fan_conditioned_skips = {}
            for level in self.fan_image_text_levels:
                block = self.fan_image_text_blocks[f"level{level}"]
                feature = skips[level]
                _, channels, depth, height, width = feature.shape
                image_tokens = rearrange(feature, "b c d h w -> b (d h w) c")
                image_tokens = repeat(
                    image_tokens, "b s c -> (b p) s c", p=prompts
                )
                block.capture_attention = bool(
                    self.capture_fan_image_text_attention
                )
                block.capture_cross_attention_logits = bool(
                    self.capture_fan_image_text_logits
                )
                block.joint_cross_modal_ablation = bool(
                    self.fan_joint_cross_modal_ablation
                )
                block.explicit_cross_ablation = bool(
                    self.fan_explicit_cross_ablation
                )
                if self.fan_pre_activation_mode:
                    activation = self.fan_pre_activation_blocks[f"level{level}"]
                    image_tokens = activation(image_tokens, flat_tokens, flat_mask)
                fused_tokens = block(image_tokens, flat_tokens, flat_mask)
                fan_feature = rearrange(
                    fused_tokens,
                    "(b p) (d h w) c -> b p c d h w",
                    b=batch,
                    p=prompts,
                    d=depth,
                    h=height,
                    w=width,
                )
                preserve_audit: dict[str, object] = {}
                if self.fan_image_text_mode == "preserve":
                    projection = self.fan_image_text_fusion_projections[f"level{level}"]
                    visual_feature = repeat(
                        feature,
                        "b c d h w -> b p c d h w",
                        p=prompts,
                    )
                    enriched = projection(
                        rearrange(visual_feature, "b p c d h w -> (b p) c d h w"),
                        rearrange(fan_feature, "b p c d h w -> (b p) c d h w"),
                    )
                    fan_conditioned_skips[level] = rearrange(
                        enriched,
                        "(b p) c d h w -> b p c d h w",
                        b=batch,
                        p=prompts,
                    )
                    preserve_audit = dict(projection.last_audit)
                    if self.capture_fan_image_text_residuals:
                        self.last_fan_image_text_residuals[f"level{level}"] = (
                            fan_conditioned_skips[level] - visual_feature
                        )
                else:
                    fan_conditioned_skips[level] = fan_feature
                self.last_fan_image_text_audits[f"level{level}"] = {
                    **block.last_audit,
                    "preserve_projection": preserve_audit,
                    "input_feature_shape": list(feature.shape),
                    "output_feature_shape": list(
                        fan_conditioned_skips[level].shape
                    ),
                    "forward_count": int(block.forward_count),
                }
                if block.last_joint_attention is not None:
                    self.last_fan_image_text_attention[f"level{level}"] = {
                        "joint": rearrange(
                            block.last_joint_attention,
                            "(b p) heads q k -> b p heads q k",
                            b=batch,
                            p=prompts,
                        ),
                        "image_to_word": rearrange(
                            block.last_cross_attention,
                            "(b p) heads q k -> b p heads q k",
                            b=batch,
                            p=prompts,
                        ),
                    }
                if self.capture_fan_image_text_attention:
                    self.last_fan_image_text_features[f"level{level}"] = {
                        "joint_visual": block.last_joint_visual,
                        "joint_text": block.last_joint_text,
                        "fused_visual": block.last_fused_visual,
                        "preserve_visual": visual_feature,
                        "preserve_enriched": fan_conditioned_skips[level],
                    }
                if block.last_cross_attention_logits is not None:
                    self.last_fan_image_text_logits[f"level{level}"] = rearrange(
                        block.last_cross_attention_logits,
                        "(b p) heads q k -> b p heads q k",
                        b=batch,
                        p=prompts,
                    )

            # Keep the released whole-sentence Text-to-Image transformer as a
            # separate path, but give each prompt the FAN-refined level-4 image
            # memory. Replicating all sentence queries per prompt stream and
            # selecting the diagonal preserves the original query self-attention.
            fine_grounded = fan_conditioned_skips[self.selected_decoder_layer]
            projected = self.project_bottleneck_embed(
                rearrange(fine_grounded, "b p c d h w -> (b p) h w d c")
            )
            prompt_memory = rearrange(
                projected,
                "(b p) h w d c -> (h w d) (b p) c",
                b=batch,
                p=prompts,
            )
            if self.capture_fan_image_text_attention:
                self.last_fan_prompt_memory = prompt_memory.detach()
            replicated_text = (
                text_embed[:, :, None, :]
                .expand(prompts, batch, prompts, text_embed.shape[-1])
                .reshape(prompts, batch * prompts, text_embed.shape[-1])
            )
            conditioned_all, _ = self.transformer_decoder(
                tgt=replicated_text,
                memory=prompt_memory,
                pos=repeat(self.pos_embed, "s 1 c -> s bp c", bp=batch * prompts),
                memory_key_padding_mask=None,
            )
            conditioned_all = conditioned_all.reshape(
                prompts, batch, prompts, conditioned_all.shape[-1]
            )
            conditioned_mask_embedding = torch.stack(
                [conditioned_all[prompt, :, prompt] for prompt in range(prompts)],
                dim=1,
            )
            if self.capture_fan_image_text_attention:
                self.last_fan_decoder_feature = conditioned_mask_embedding.detach()
            self.original_cross_attention_forward_count += 1
        elif self.token_image_text_mode == "original":
            if self.word_global_mode in {"b2", "b3"}:
                if self._word_global_tokens is None or self._word_global_valid_mask is None:
                    raise RuntimeError("word-derived Prompt Decoder queries require tokens")
                word_global_tokens = self._word_global_tokens
                word_global_mask = self._word_global_valid_mask
                batch, prompts, _, _ = word_global_tokens.shape
                bottleneck_embed = rearrange(
                    selected_feature, "b c d h w -> b h w d c"
                )
                bottleneck_embed = self.project_bottleneck_embed(bottleneck_embed)
                bottleneck_embed = rearrange(
                    bottleneck_embed, "b h w d c -> (h w d) b c"
                )
                if self.word_global_mode == "b2":
                    if self.word_global_bridge is None:
                        raise RuntimeError("B2 word-query bridge is missing")
                    word_queries = self.word_global_bridge(
                        word_global_tokens, word_global_mask
                    )
                    conditioned_mask_embedding, _ = self.transformer_decoder(
                        tgt=rearrange(word_queries, "b p d -> p b d"),
                        memory=bottleneck_embed,
                        pos=self.pos_embed,
                        memory_key_padding_mask=None,
                    )
                    conditioned_mask_embedding = rearrange(
                        conditioned_mask_embedding, "p b d -> b p d"
                    )
                    self.last_word_global_audit = {
                        "mode": "b2",
                        "direct_global_sentence_to_prompt_decoder": False,
                        "word_query_shape": list(word_queries.shape),
                        "bridge_checkpoint": self.word_global_bridge_checkpoint,
                    }
                    if self.capture_word_global_features:
                        self.last_word_global_features["word_query"] = word_queries.detach()
                        self.last_word_global_features[
                            "decoder_input_mask_embedding"
                        ] = conditioned_mask_embedding.detach()
                else:
                    if self.word_global_candidate_bridge is None or self.word_global_router is None:
                        raise RuntimeError("B3 candidate bridge/router is missing")
                    candidate_queries = self.word_global_candidate_bridge(
                        word_global_tokens, word_global_mask
                    )
                    candidates = candidate_queries.shape[2]
                    if less_prompt_skips is None:
                        candidate_masks, _ = self.transformer_decoder(
                            tgt=rearrange(candidate_queries, "b p k d -> (p k) b d"),
                            memory=bottleneck_embed,
                            pos=self.pos_embed,
                            memory_key_padding_mask=None,
                        )
                        candidate_masks = rearrange(
                            candidate_masks,
                            "(p k) b d -> b p k d",
                            p=prompts,
                            k=candidates,
                        )
                        b3_prompt_memory = bottleneck_embed
                    else:
                        # Preserve B3's complete P*K query self-attention while
                        # associating each prompt's candidate outputs with that
                        # prompt's LESS-conditioned level-4 memory. Each of the
                        # P memory streams receives the same complete candidate
                        # query set; selecting the prompt diagonal is identical
                        # to the established LESS/native-query routing rule.
                        conditioned_memory = less_prompt_skips[
                            self.selected_decoder_layer
                        ]
                        batch, memory_prompts, _, _, _, _ = conditioned_memory.shape
                        if memory_prompts != prompts:
                            raise RuntimeError(
                                "B3+LESS prompt-memory count does not match query count"
                            )
                        projected_memory = self.project_bottleneck_embed(
                            rearrange(
                                conditioned_memory,
                                "b p c d h w -> (b p) h w d c",
                            )
                        )
                        b3_prompt_memory = rearrange(
                            projected_memory,
                            "(b p) h w d c -> (h w d) (b p) c",
                            b=batch,
                            p=prompts,
                        )
                        queries_per_memory = (
                            candidate_queries[:, None]
                            .expand(batch, prompts, prompts, candidates, candidate_queries.shape[-1])
                            .reshape(batch * prompts, prompts * candidates, candidate_queries.shape[-1])
                        )
                        all_candidate_masks, _ = self.transformer_decoder(
                            tgt=rearrange(queries_per_memory, "bp q d -> q bp d"),
                            memory=b3_prompt_memory,
                            pos=repeat(self.pos_embed, "s 1 c -> s bp c", bp=batch * prompts),
                            memory_key_padding_mask=None,
                        )
                        all_candidate_masks = rearrange(
                            all_candidate_masks,
                            "(pq k) (b pm) d -> b pm pq k d",
                            b=batch,
                            pm=prompts,
                            pq=prompts,
                            k=candidates,
                        )
                        candidate_masks = torch.stack(
                            [
                                all_candidate_masks[:, prompt, prompt]
                                for prompt in range(prompts)
                            ],
                            dim=1,
                        )
                    conditioned_mask_embedding, router_weights = self.word_global_router(
                        candidate_masks,
                        text_embedding,
                        aggregation=self.word_global_b3_aggregation,
                    )
                    normalized = F.normalize(candidate_masks.float(), dim=-1, eps=1e-8)
                    pairwise = torch.einsum("bpkd,bpjd->bpkj", normalized, normalized)
                    off_diagonal = ~torch.eye(
                        candidates, device=pairwise.device, dtype=torch.bool
                    )[None, None]
                    diversity = (1.0 - pairwise)[off_diagonal.expand_as(pairwise)].mean()
                    entropy = self.word_global_router.last_entropy
                    assert entropy is not None
                    selection = router_weights.argmax(dim=-1)
                    self.last_auxiliary_stats.update(
                        {
                            "word_global_b3_candidate_cosine_diversity": diversity,
                            "word_global_b3_router_entropy": entropy.mean(),
                        }
                    )
                    self.last_word_global_audit = {
                        "mode": "b3",
                        "direct_global_sentence_to_prompt_decoder": False,
                        "router_uses_global_sentence_only": True,
                        "candidate_aggregation": self.word_global_b3_aggregation,
                        "less_conditioned_prompt_memory": less_prompt_skips is not None,
                        "candidate_query_shape": list(candidate_queries.shape),
                        "candidate_mask_shape": list(candidate_masks.shape),
                        "prompt_memory_shape": list(b3_prompt_memory.shape),
                        "router_entropy_mean": float(entropy.detach().mean().item()),
                        "candidate_cosine_diversity": float(diversity.detach().item()),
                        "router_selection_frequency": [
                            float((selection == index).float().mean().detach().item())
                            for index in range(candidates)
                        ],
                        "bridge_checkpoint": self.word_global_bridge_checkpoint,
                    }
                    if self.capture_word_global_features:
                        self.last_word_global_features.update(
                            {
                                "candidate_queries": candidate_queries.detach(),
                                "candidate_masks": candidate_masks.detach(),
                                "router_weights": router_weights.detach(),
                                "prompt_decoder_memory": b3_prompt_memory.detach(),
                                "decoder_input_mask_embedding": conditioned_mask_embedding.detach(),
                            }
                        )
                self.original_cross_attention_forward_count += 1
            elif (
                self.encoder_propagation_mode == "none"
                and self.encoder_token_spatial_mode == "none"
                and self.less_encoder_mode == "none"
                and self.word_global_mode == "none"
                and (token_features is not None or token_valid_mask is not None)
            ):
                raise ValueError("original mode does not accept contextual token features")
            # The native VoxTell text decoder reads stage 4 (1/16) memory.
            # For a stage-4 FiLM injection only stage 5 is deeper/conditioned;
            # retain the original stage-4 memory rather than substituting the
            # incompatible 1/32 tensor for the fixed 1/16 positional grid.
            elif (
                not medplex_bifusion_active
                and qwen_lora_mode != "bica_stage3"
                and less_prompt_skips is None
                and (prompt_deep_skips is None or self.selected_decoder_layer <= (
                self.encoder_residual_film_stage
                if self.encoder_residual_film_mode != "none"
                else (
                    self.encoder_token_spatial_stage
                    if self.encoder_token_spatial_mode != "none"
                    else self.encoder_propagation_stage
                )
            ))
            ):
                bottleneck_embed = rearrange(selected_feature, "b c d h w -> b h w d c")
                bottleneck_embed = self.project_bottleneck_embed(bottleneck_embed)
                bottleneck_embed = rearrange(bottleneck_embed, "b h w d c -> (h w d) b c")
                conditioned_mask_embedding, _ = self.transformer_decoder(
                    tgt=text_embed,
                    memory=bottleneck_embed,
                    pos=self.pos_embed,
                    memory_key_padding_mask=None,
                )
                conditioned_mask_embedding = repeat(
                    conditioned_mask_embedding, "n b dim -> b n dim"
                )
            else:
                if medplex_bifusion_active:
                    if conditioned_selected_features is None:
                        raise RuntimeError("MedPlex did not produce selected decoder-layer memory")
                elif qwen_lora_mode == "bica_stage3":
                    if conditioned_selected_features is None:
                        raise RuntimeError("Qwen BiCA did not produce selected decoder-layer memory")
                elif less_prompt_skips is not None:
                    conditioned_selected_features = less_prompt_skips[
                        self.selected_decoder_layer
                    ]
                else:
                    conditioning_stage = (
                        self.encoder_residual_film_stage
                        if self.encoder_residual_film_mode != "none"
                        else (
                            self.encoder_token_spatial_stage
                            if self.encoder_token_spatial_mode != "none"
                            else self.encoder_propagation_stage
                        )
                    )
                    deep_index = self.selected_decoder_layer - (conditioning_stage + 1)
                    conditioned_selected_features = prompt_deep_skips[deep_index]
                batch, prompts, channels, depth, height, width = (
                    conditioned_selected_features.shape
                )
                projected = self.project_bottleneck_embed(
                    rearrange(
                        conditioned_selected_features,
                        "b p c d h w -> (b p) h w d c",
                    )
                )
                prompt_memory = rearrange(
                    projected,
                    "(b p) h w d c -> (h w d) (b p) c",
                    b=batch,
                    p=prompts,
                )
                # Every conditioned stream receives the complete original set
                # of prompt queries. Selecting the diagonal preserves VoxTell's
                # prompt-query self-attention and is baseline-equivalent at
                # gamma=0 while associating each output with its own EP stream.
                replicated_text = (
                    text_embed[:, :, None, :]
                    .expand(prompts, batch, prompts, text_embed.shape[-1])
                    .reshape(prompts, batch * prompts, text_embed.shape[-1])
                )
                conditioned_all, _ = self.transformer_decoder(
                    tgt=replicated_text,
                    memory=prompt_memory,
                    pos=repeat(self.pos_embed, "s 1 c -> s bp c", bp=batch * prompts),
                    memory_key_padding_mask=None,
                )
                conditioned_all = conditioned_all.reshape(
                    prompts, batch, prompts, conditioned_all.shape[-1]
                )
                conditioned_mask_embedding = torch.stack(
                    [conditioned_all[prompt, :, prompt] for prompt in range(prompts)],
                    dim=1,
                )
            self.original_cross_attention_forward_count += 1
        else:
            if token_features is None or token_valid_mask is None:
                raise ValueError(
                    f"{self.token_image_text_mode} requires token_features and token_valid_mask"
                )
            if token_features.ndim != 4:
                raise ValueError(
                    "token_features must be [B,P,T,H], got "
                    f"{tuple(token_features.shape)}"
                )
            expected = (*text_embedding.shape[:2], token_features.shape[2])
            if tuple(token_valid_mask.shape) != expected:
                raise ValueError(
                    f"token_valid_mask must have shape {expected}, got "
                    f"{tuple(token_valid_mask.shape)}"
                )
            if token_features.shape[:2] != text_embedding.shape[:2]:
                raise ValueError("token features must match the pooled prompt batch/prompt axes")
            assert self.token_image_text_block is not None
            batch, prompts, n_text, token_dim = token_features.shape
            _, channels, depth, height, width = selected_feature.shape
            image_tokens = rearrange(
                selected_feature, "b c d h w -> b (h w d) c"
            )
            image_tokens = repeat(image_tokens, "b s c -> (b p) s c", p=prompts)
            flat_tokens = token_features.reshape(batch * prompts, n_text, token_dim)
            flat_mask = token_valid_mask.reshape(batch * prompts, n_text)
            self.token_image_text_block.capture_attention = bool(
                self.capture_token_image_text_attention
            )
            conditioned_tokens = self.token_image_text_block(
                image_tokens, flat_tokens, flat_mask
            )
            if self.token_image_text_block.last_attention is not None:
                captured = self.token_image_text_block.last_attention.reshape(
                    batch, prompts, self.token_image_text_block.num_heads,
                    height * width * depth, n_text,
                )
                self.last_token_image_text_attention = [
                    captured[:, prompt].detach() for prompt in range(prompts)
                ]
            conditioned_selected_features = rearrange(
                conditioned_tokens,
                "(b p) (h w d) c -> b p c d h w",
                b=batch,
                p=prompts,
                h=height,
                w=width,
                d=depth,
            )
            projected_conditioned = self.project_bottleneck_embed(
                rearrange(
                    conditioned_selected_features,
                    "b p c d h w -> (b p) h w d c",
                )
            )
            if self.token_image_text_mode == "replace_image_to_text":
                # The replacement arm derives its mask query from the
                # language-conditioned image tokens; the old sentence-query
                # transformer decoder is not called.
                conditioned_mask_embedding = projected_conditioned.mean(dim=(1, 2, 3))
                conditioned_mask_embedding = rearrange(
                    conditioned_mask_embedding, "(b p) c -> b p c", b=batch, p=prompts
                )
            else:
                memory = rearrange(
                    projected_conditioned,
                    "(b p) h w d c -> (h w d) (b p) c",
                    b=batch,
                    p=prompts,
                )
                per_prompt_text = rearrange(text_embed, "p b c -> 1 (b p) c")
                conditioned_mask_embedding, _ = self.transformer_decoder(
                    tgt=per_prompt_text,
                    memory=memory,
                    pos=repeat(self.pos_embed, "s 1 c -> s bp c", bp=batch * prompts),
                    memory_key_padding_mask=None,
                )
                self.original_cross_attention_forward_count += 1
                conditioned_mask_embedding = rearrange(
                    conditioned_mask_embedding,
                    "1 (b p) c -> b p c",
                    b=batch,
                    p=prompts,
                )
        mask_embedding = conditioned_mask_embedding
        s3_mask_embedding = conditioned_mask_embedding
        using_bidir_no_old_fusion = self.bidir_prompt_decoder_mode in {
            "no_old_fusion",
            "no_old_fusion_reuse_decoder",
        }
        if (
            apply_prompt_residual_adapter
            and self.prompt_residual_adapter is not None
            and prompt_adapter_injection_mode != "shared"
        ):
            if (
                self.token_image_text_mode != "original"
                or self.bidir_prompt_decoder_mode != "none"
            ):
                raise ValueError(
                    "Separated prompt-adapter injection is not supported by token "
                    "or Bidirectional Prompt Decoder pilots"
                )
            base_mask_embedding, _ = self.transformer_decoder(
                tgt=base_text_embed,
                memory=bottleneck_embed,
                pos=self.pos_embed,
                memory_key_padding_mask=None,
            )
            self.original_cross_attention_forward_count += 1
            base_mask_embedding = repeat(base_mask_embedding, "n b dim -> b n dim")
            if prompt_adapter_injection_mode == "s3_only":
                mask_embedding = base_mask_embedding
            else:
                s3_mask_embedding = base_mask_embedding
        mask_embeddings = (
            None
            if using_bidir_no_old_fusion
            else [
                projection(mask_embedding)
                for projection in self.project_to_decoder_channels
            ]
        )

        # The pathology pilot reads the native 96^3/64C decoder feature.  The
        # decoder capture is observational: it neither substitutes nor detaches
        # the feature used by segmentation.
        self.last_less_decoder_stage2 = None
        self.last_less_decoder_stage3 = None
        self.decoder.capture_stage_features = bool(
            self.less_semantic_alignment_mode in {"pathology", "medplex"}
        )
        decoder_stage2_by_prompt: list[torch.Tensor] = []
        decoder_stage3_by_prompt: list[torch.Tensor] = []
        outs = []
        if spatial_attention_rho_scale is None:
            spatial_attention_rho_scale = 1.0
        elif torch.is_tensor(spatial_attention_rho_scale):
            spatial_attention_rho_scale = spatial_attention_rho_scale.to(device=img.device, dtype=img.dtype)
        if s3_attention_gate_scales_by_scale is not None:
            s3_attention_gate_scales_by_scale = {
                scale: (
                    value.to(device=img.device, dtype=img.dtype)
                    if torch.is_tensor(value)
                    else value
                )
                for scale, value in s3_attention_gate_scales_by_scale.items()
            }
        if adaptive_rho_category_indices is not None:
            adaptive_rho_category_indices = adaptive_rho_category_indices.to(
                device=img.device, dtype=torch.long
            )
            if adaptive_rho_category_indices.shape != text_embedding.shape[:2]:
                raise ValueError(
                    "adaptive_rho_category_indices must match [B,P]: "
                    f"{tuple(adaptive_rho_category_indices.shape)} != {tuple(text_embedding.shape[:2])}"
                )
        if adaptive_rho_active_mask is not None:
            adaptive_rho_active_mask = adaptive_rho_active_mask.to(
                device=img.device, dtype=torch.bool
            )
            if adaptive_rho_active_mask.shape != text_embedding.shape[:2]:
                raise ValueError(
                    "adaptive_rho_active_mask must match [B,P]: "
                    f"{tuple(adaptive_rho_active_mask.shape)} != "
                    f"{tuple(text_embedding.shape[:2])}"
                )
            if adaptive_rho_category_indices is None:
                raise ValueError(
                    "adaptive_rho_active_mask requires adaptive_rho_category_indices"
                )
        if category_router_indices is not None:
            category_router_indices = category_router_indices.to(
                device=img.device, dtype=torch.long
            )
            if category_router_indices.shape != text_embedding.shape[:2]:
                raise ValueError("category_router_indices must match [B,P]")
        if target_attention_adapter_active_mask is not None:
            target_attention_adapter_active_mask = (
                target_attention_adapter_active_mask.to(
                    device=img.device, dtype=torch.bool
                )
            )
            if target_attention_adapter_active_mask.shape != text_embedding.shape[:2]:
                raise ValueError(
                    "target_attention_adapter_active_mask must match [B,P]"
                )
        for prompt_idx in range(text_embedding.shape[1]):
            prompt_skips = skips
            if fan_conditioned_skips is not None:
                prompt_skips = list(skips)
                for level, conditioned_skip in fan_conditioned_skips.items():
                    prompt_skips[level] = conditioned_skip[:, prompt_idx]
            elif less_prompt_skips is not None:
                prompt_skips = list(skips)
                for level, conditioned_skip in less_prompt_skips.items():
                    prompt_skips[level] = conditioned_skip[:, prompt_idx]
            elif prompt_deep_skips is not None:
                prompt_skips = list(skips)
                conditioning_stage = (
                    # MedPlex prompt_deep_skips contains absolute encoder
                    # stages 2, 3, 4, and 5.  The generic replacement loop
                    # writes at conditioning_stage + 1 + offset, so its
                    # pre-conditioning stage is 1 (not the first fused stage
                    # itself).  Using 2 here shifted every replacement by one
                    # and attempted to write stage 6 for the final skip.
                    1 if medplex_bifusion_active else int(getattr(self, "qwen_bica_stage", 3))
                    if qwen_lora_mode == "bica_stage3"
                    else (
                        self.encoder_residual_film_stage
                        if self.encoder_residual_film_mode != "none"
                        else (
                            self.encoder_token_spatial_stage
                            if self.encoder_token_spatial_mode != "none"
                            else self.encoder_propagation_stage
                        )
                    )
                )
                for deep_offset, deep_skip in enumerate(prompt_deep_skips):
                    prompt_skips[
                        conditioning_stage + 1 + deep_offset
                    ] = deep_skip[:, prompt_idx]
                if qwen_lora_mode == "bica_stage3":
                    conditioned_skip = self.last_qwen_bica_conditioned_stage3
                    if conditioned_skip is None:
                        raise RuntimeError("Qwen BiCA conditioned stage-3 skip was not captured")
                    prompt_skips[int(getattr(self, "qwen_bica_stage", 3))] = conditioned_skip[:, prompt_idx]
                if self.encoder_token_spatial_mode != "none" and self.encoder_token_spatial_conditioned_skip:
                    conditioned_skip = self.last_encoder_token_spatial_conditioned_skip
                    if conditioned_skip is None:
                        raise RuntimeError("Token-spatial conditioned skip was not captured")
                    prompt_skips[self.encoder_token_spatial_stage] = conditioned_skip[:, prompt_idx]
            elif conditioned_selected_features is not None:
                prompt_skips = list(skips)
                prompt_skips[self.selected_decoder_layer] = (
                    conditioned_selected_features[:, prompt_idx]
                )
            if using_bidir_no_old_fusion:
                if (
                    self.enable_s3_voxel_text_matching_attention
                    or self.enable_s2_attention
                    or self.enable_prompt_spatial_attention
                ):
                    raise ValueError(
                        "E2 no-old-fusion decoder is isolated from S1/S2/S3 "
                        "decoder attention paths"
                    )
                if self.bidir_no_fusion_decoder is None:
                    raise RuntimeError("No-fusion decoder is not initialized")
                outs.append(self.bidir_no_fusion_decoder(prompt_skips))
                continue
            assert mask_embeddings is not None
            prompt_embeds = [m[:, prompt_idx:prompt_idx + 1] for m in mask_embeddings]
            if self.enable_s3_voxel_text_matching_attention:
                effective_s3_scale = (
                    spatial_attention_rho_scale
                    if s3_attention_gate_scale is None
                    else s3_attention_gate_scale
                )
                prompt_gate_scale = self._prompt_gate_scale(
                    effective_s3_scale,
                    prompt_idx,
                    img.shape[0],
                )
                prompt_gate_scales_by_scale = None
                if s3_attention_gate_scales_by_scale is not None:
                    prompt_gate_scales_by_scale = {
                        scale: self._prompt_gate_scale(value, prompt_idx, img.shape[0])
                        for scale, value in s3_attention_gate_scales_by_scale.items()
                    }
                prompt_refinement_scale = self._prompt_gate_scale(
                    1.0 if s3_fullres_refinement_scale is None else s3_fullres_refinement_scale,
                    prompt_idx,
                    img.shape[0],
                )
                prompt_joint_fusion_scale = self._prompt_gate_scale(
                    0.0 if s3_joint_fusion_scale is None else s3_joint_fusion_scale,
                    prompt_idx,
                    img.shape[0],
                )
                if self.training and self.encoder_residual_film_gradient_checkpointing:
                    skip_count = len(prompt_skips)
                    embed_count = len(prompt_embeds)

                    def checkpointed_s3_decoder(
                        *flat_inputs: torch.Tensor,
                        gate_scale=prompt_gate_scale,
                        gate_scales_by_scale=prompt_gate_scales_by_scale,
                        fullres_refinement_scale=prompt_refinement_scale,
                        joint_fusion_scale=prompt_joint_fusion_scale,
                        adaptive_indices=(
                            None
                            if adaptive_rho_category_indices is None
                            else adaptive_rho_category_indices[:, prompt_idx]
                        ),
                        adaptive_mask=(
                            None
                            if adaptive_rho_active_mask is None
                            else adaptive_rho_active_mask[:, prompt_idx]
                        ),
                        router_indices=(
                            None
                            if category_router_indices is None
                            else category_router_indices[:, prompt_idx]
                        ),
                        target_mask=(
                            None
                            if target_attention_adapter_active_mask is None
                            else target_attention_adapter_active_mask[:, prompt_idx]
                        ),
                    ):
                        return self._decode_prompt_with_s3(
                            list(flat_inputs[:skip_count]),
                            list(flat_inputs[skip_count:skip_count + embed_count]),
                            flat_inputs[-1],
                            gate_scale=gate_scale,
                            gate_scales_by_scale=gate_scales_by_scale,
                            fullres_refinement_scale=fullres_refinement_scale,
                            joint_fusion_scale=joint_fusion_scale,
                            adaptive_rho_category_indices=adaptive_indices,
                            adaptive_rho_active_mask=adaptive_mask,
                            category_router_indices=router_indices,
                            target_attention_adapter_active_mask=target_mask,
                        )

                    outs.append(
                        torch.utils.checkpoint.checkpoint(
                            checkpointed_s3_decoder,
                            *prompt_skips,
                            *prompt_embeds,
                            s3_mask_embedding[:, prompt_idx:prompt_idx + 1],
                            use_reentrant=False,
                            preserve_rng_state=True,
                        )
                    )
                else:
                    outs.append(self._decode_prompt_with_s3(
                        prompt_skips,
                        prompt_embeds,
                        s3_mask_embedding[:, prompt_idx:prompt_idx + 1],
                        gate_scale=prompt_gate_scale,
                        gate_scales_by_scale=prompt_gate_scales_by_scale,
                        fullres_refinement_scale=prompt_refinement_scale,
                        joint_fusion_scale=prompt_joint_fusion_scale,
                        adaptive_rho_category_indices=(
                            None
                            if adaptive_rho_category_indices is None
                            else adaptive_rho_category_indices[:, prompt_idx]
                        ),
                        adaptive_rho_active_mask=(
                            None
                            if adaptive_rho_active_mask is None
                            else adaptive_rho_active_mask[:, prompt_idx]
                        ),
                        category_router_indices=(
                            None
                            if category_router_indices is None
                            else category_router_indices[:, prompt_idx]
                        ),
                        target_attention_adapter_active_mask=(
                            None
                            if target_attention_adapter_active_mask is None
                            else target_attention_adapter_active_mask[:, prompt_idx]
                        ),
                    ))
            elif self.enable_s2_attention:
                effective_s2_scale = (
                    spatial_attention_rho_scale
                    if s2_attention_gate_scale is None
                    else s2_attention_gate_scale
                )
                prompt_gate_scale = self._prompt_gate_scale(
                    effective_s2_scale,
                    prompt_idx,
                    img.shape[0],
                )
                outs.append(
                    self._decode_prompt_with_s2(
                        prompt_skips,
                        prompt_embeds,
                        mask_embedding[:, prompt_idx:prompt_idx + 1],
                        gate_scale=prompt_gate_scale,
                        scale_factors=s2_attention_scale_factors,
                    )
                )
            elif self.enable_prompt_spatial_attention:
                prompt_rho_scale = self._prompt_gate_scale(
                    spatial_attention_rho_scale,
                    prompt_idx,
                    img.shape[0],
                )
                outs.append(
                    self._decode_prompt_with_attention(
                        prompt_skips,
                        prompt_embeds,
                        mask_embedding[:, prompt_idx:prompt_idx + 1],
                        rho_scale=prompt_rho_scale,
                    )
                )
            else:
                outs.append(self.decoder(prompt_skips, prompt_embeds))
                if self.less_semantic_alignment_mode in {"pathology", "medplex"}:
                    if self.less_semantic_alignment_mode == "medplex":
                        if len(self.decoder.last_stage_features) <= 2:
                            raise RuntimeError("Native decoder did not expose 48^3 stage-2 feature")
                        decoder_stage2_by_prompt.append(self.decoder.last_stage_features[2])
                    if self.less_semantic_alignment_mode == "pathology":
                        if len(self.decoder.last_stage_features) <= 3:
                            raise RuntimeError("Native decoder did not expose 96^3 stage-3 feature")
                        # Decoder stages run coarse-to-fine: index 3 is the
                        # requested decoder_stage3 feature (96^3, 64 channels).
                        decoder_stage3_by_prompt.append(self.decoder.last_stage_features[3])
        if decoder_stage2_by_prompt:
            self.last_less_decoder_stage2 = torch.stack(decoder_stage2_by_prompt, dim=1)
        if decoder_stage3_by_prompt:
            self.last_less_decoder_stage3 = torch.stack(decoder_stage3_by_prompt, dim=1)
        if self.word_global_mode == "b1":
            expected_prompts = int(text_embedding.shape[1])
            if not self.word_global_b1_bypass and self._word_global_b1_prompt_index != expected_prompts:
                raise RuntimeError(
                    "B1 late decoder block did not execute exactly once per prompt: "
                    f"{self._word_global_b1_prompt_index} != {expected_prompts}"
                )
            assert self.word_global_b1_block is not None
            self.last_word_global_audit = {
                "mode": "b1",
                "decoder_stage": self.word_global_b1_decoder_stage,
                "alpha": self.word_global_b1_alpha,
                "bypass": bool(self.word_global_b1_bypass),
                "prompt_forward_count": self._word_global_b1_prompt_index,
                "block_forward_count": self.word_global_b1_block.forward_count,
                **dict(self.word_global_b1_block.last_audit),
            }
        if self.enable_s2_attention:
            self._record_s2_attention_stats()
        if self.enable_s3_voxel_text_matching_attention:
            self._record_s3_attention_stats()
        outs = [torch.cat(scale_outs, dim=1) for scale_outs in zip(*outs)]
        if self.capture_word_global_features:
            self.last_word_global_features["final_logits"] = outs[0].detach()
        if self.dvsm_probe_adapter is not None:
            outs[0], correction, residual_raw = self.dvsm_probe_adapter.add_to_logits(
                outs[0], selected_feature, text_embedding, self.dvsm_tie_probe
            )
            correction_float = correction.detach().float()
            residual_raw_float = residual_raw.detach().float()
            self.last_auxiliary_stats.update(
                {
                    "dvsm_probe_gamma": self.dvsm_probe_adapter.gamma.detach().float(),
                    "dvsm_probe_residual_mean": correction_float.mean(),
                    "dvsm_probe_residual_std": correction_float.std(),
                    "dvsm_probe_residual_max_abs": correction_float.abs().amax(),
                    "dvsm_probe_residual_raw_mean": residual_raw_float.mean(),
                    "dvsm_probe_residual_raw_std": residual_raw_float.std(),
                    "dvsm_probe_residual_raw_max_abs": residual_raw_float.abs().amax(),
                }
            )
        if not self.deep_supervision:
            outs = outs[0]

        if return_presence_logits:
            if self.patch_presence_head is None:
                raise RuntimeError("return_presence_logits=True requires enable_patch_presence_head=True")
            query_for_presence = mask_embedding.detach() if self.presence_detach_features else mask_embedding
            if self.presence_head_type == "spatial_grounded":
                spatial_for_presence = selected_feature.detach() if self.presence_detach_features else selected_feature
                presence_logits, stats = self.patch_presence_head(spatial_for_presence, query_for_presence)
                self.last_auxiliary_stats.update(stats)
            else:
                presence_logits = self.patch_presence_head(query_for_presence).squeeze(-1)
            return outs, presence_logits
        return outs
