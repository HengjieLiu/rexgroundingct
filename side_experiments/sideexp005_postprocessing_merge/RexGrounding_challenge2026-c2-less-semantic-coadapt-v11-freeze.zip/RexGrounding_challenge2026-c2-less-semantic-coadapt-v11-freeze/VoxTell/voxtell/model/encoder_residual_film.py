"""Baseline-preserving residual FiLM conditioning for the 1/8 encoder stage."""

from __future__ import annotations

import math

import torch
from torch import nn


class EncoderResidualFiLM3D(nn.Module):
    """Condition a 3-D image feature with a pooled sentence embedding.

    Only the final scale and shift heads are zero initialized.  Consequently
    the module is an exact identity at construction, while both output heads
    receive gradients on the first backward pass.  There is deliberately no
    additional scalar residual gate.
    """

    def __init__(
        self,
        image_dim: int,
        text_dim: int,
        hidden_dim: int = 512,
        num_groups: int = 32,
        init_seed: int = 260811,
    ) -> None:
        super().__init__()
        if image_dim <= 0 or text_dim <= 0 or hidden_dim <= 0:
            raise ValueError("image_dim, text_dim, and hidden_dim must be positive")
        if num_groups <= 0 or image_dim % num_groups:
            raise ValueError("num_groups must divide image_dim")
        self.image_dim = int(image_dim)
        self.text_dim = int(text_dim)
        self.hidden_dim = int(hidden_dim)
        self.num_groups = int(num_groups)

        # affine=False keeps the normalization itself parameter-free: all new
        # conditioning capacity is explicitly attributable to the text MLP and
        # its channel-wise scale/shift outputs.
        self.image_norm = nn.GroupNorm(self.num_groups, self.image_dim, affine=False)
        with torch.random.fork_rng(devices=[]):
            self.text_norm = nn.LayerNorm(self.text_dim)
            self.text_projection = nn.Linear(self.text_dim, self.hidden_dim)
            self.activation = nn.SiLU()
            self.scale_head = nn.Linear(self.hidden_dim, self.image_dim)
            self.shift_head = nn.Linear(self.hidden_dim, self.image_dim)
        self.forward_count = 0
        self.last_scale: torch.Tensor | None = None
        self.last_shift: torch.Tensor | None = None
        self.last_delta: torch.Tensor | None = None
        self.last_audit: dict[str, object] = {}
        self._reset_deterministically(init_seed)

    def _reset_deterministically(self, seed: int) -> None:
        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(seed))
        fan_in, fan_out = nn.init._calculate_fan_in_and_fan_out(
            self.text_projection.weight
        )
        bound = math.sqrt(6.0 / (fan_in + fan_out))
        with torch.no_grad():
            self.text_norm.weight.fill_(1.0)
            self.text_norm.bias.zero_()
            self.text_projection.weight.uniform_(-bound, bound, generator=generator)
            self.text_projection.bias.zero_()
            # The sole identity-preserving initialization.  The internal text
            # projection remains nonzero and can learn as soon as these heads
            # leave zero.
            self.scale_head.weight.zero_()
            self.scale_head.bias.zero_()
            self.shift_head.weight.zero_()
            self.shift_head.bias.zero_()

    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())

    def forward(
        self,
        image_feature: torch.Tensor,
        text_embedding: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if image_feature.ndim != 5:
            raise ValueError("image_feature must be [B,C,D,H,W]")
        if text_embedding.ndim != 3:
            raise ValueError("text_embedding must be [B,P,H]")
        if image_feature.shape[0] != text_embedding.shape[0]:
            raise ValueError("image and text batch axes must match")
        if image_feature.shape[1] != self.image_dim:
            raise ValueError(
                f"Expected {self.image_dim} image channels, got {image_feature.shape[1]}"
            )
        if text_embedding.shape[-1] != self.text_dim:
            raise ValueError(
                f"Expected {self.text_dim} text channels, got {text_embedding.shape[-1]}"
            )

        batch, channels, depth, height, width = image_feature.shape
        prompts = text_embedding.shape[1]
        normalized = self.image_norm(image_feature)
        normalized = normalized[:, None].expand(
            batch, prompts, channels, depth, height, width
        )
        base = image_feature[:, None].expand_as(normalized)
        hidden = self.activation(self.text_projection(self.text_norm(text_embedding)))
        scale = self.scale_head(hidden)[..., None, None, None]
        shift = self.shift_head(hidden)[..., None, None, None]
        delta = scale * normalized + shift
        conditioned = base + delta

        scale_float = scale.detach().float()
        shift_float = shift.detach().float()
        delta_float = delta.detach().float()
        base_float = base.detach().float()
        feature_norm = base_float.flatten(2).norm(dim=-1).clamp_min(1e-12)
        modulation_norm = delta_float.flatten(2).norm(dim=-1)
        self.last_scale = scale.detach()
        self.last_shift = shift.detach()
        self.last_delta = delta.detach()
        self.last_audit = {
            "text_embedding_shape": list(text_embedding.shape),
            "scale_shape": list(scale.shape),
            "shift_shape": list(shift.shape),
            "conditioned_shape": list(conditioned.shape),
            "scale_mean_absolute": float(scale_float.abs().mean().item()),
            "scale_max_absolute": float(scale_float.abs().amax().item()),
            "shift_mean_absolute": float(shift_float.abs().mean().item()),
            "shift_max_absolute": float(shift_float.abs().amax().item()),
            "modulation_to_feature_norm": float(
                (modulation_norm / feature_norm).mean().item()
            ),
            "max_conditioned_minus_base": float(
                (conditioned.detach().float() - base_float).abs().amax().item()
            ),
        }
        self.forward_count += 1
        return conditioned.reshape(
            batch * prompts, channels, depth, height, width
        ), delta
