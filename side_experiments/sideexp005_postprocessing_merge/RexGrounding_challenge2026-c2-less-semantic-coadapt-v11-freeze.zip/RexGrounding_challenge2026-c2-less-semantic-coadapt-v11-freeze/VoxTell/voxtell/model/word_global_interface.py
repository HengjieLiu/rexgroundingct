"""Word/global interfaces used by the B1/B2/B3 VoxTell scientific pilot.

The modules in this file are deliberately small and checkpoint-native.  They
consume cached, frozen contextual Qwen token features; Qwen itself is never
instantiated or optimized here.
"""

from __future__ import annotations

import math

import torch
from torch import nn


def masked_softmax(logits: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    if logits.shape != mask.shape:
        raise ValueError(f"mask/logit shape mismatch: {mask.shape} != {logits.shape}")
    if not bool(mask.any(dim=-1).all()):
        raise ValueError("every word sequence must contain at least one valid token")
    return torch.softmax(
        logits.masked_fill(~mask, torch.finfo(logits.dtype).min), dim=-1
    )


class WordQueryBridge(nn.Module):
    """Attention-pool contextual Qwen tokens into the native PD query space."""

    def __init__(
        self,
        token_dim: int = 2560,
        attention_dim: int = 256,
        value_dim: int = 512,
        query_dim: int = 2048,
    ) -> None:
        super().__init__()
        self.token_dim = int(token_dim)
        self.query_dim = int(query_dim)
        self.token_norm = nn.LayerNorm(token_dim)
        self.score_projection = nn.Linear(token_dim, attention_dim)
        self.score_vector = nn.Parameter(torch.empty(attention_dim))
        self.value_projection = nn.Linear(token_dim, value_dim)
        self.output_projection = nn.Linear(value_dim, query_dim)
        nn.init.normal_(self.score_vector, std=attention_dim ** -0.5)
        self.last_attention: torch.Tensor | None = None

    def forward(self, tokens: torch.Tensor, valid_mask: torch.Tensor) -> torch.Tensor:
        if tokens.ndim != 4 or valid_mask.shape != tokens.shape[:3]:
            raise ValueError("word bridge expects [B,P,L,D] tokens and [B,P,L] mask")
        if tokens.shape[-1] != self.token_dim:
            raise ValueError(f"expected token dim {self.token_dim}, got {tokens.shape[-1]}")
        normalized = self.token_norm(tokens.float())
        hidden = torch.tanh(self.score_projection(normalized))
        logits = torch.einsum("bpla,a->bpl", hidden, self.score_vector)
        attention = masked_softmax(logits, valid_mask.bool())
        values = self.value_projection(normalized)
        pooled = torch.einsum("bpl,bplv->bpv", attention, values)
        self.last_attention = attention.detach()
        return self.output_projection(pooled)


class LateWordCrossAttention3D(nn.Module):
    """B1 Transformer-style late image-query to word-key/value update."""

    def __init__(
        self,
        image_dim: int = 128,
        token_dim: int = 2560,
        attention_dim: int = 128,
        num_heads: int = 4,
        ffn_ratio: int = 4,
        seed: int = 260901,
    ) -> None:
        super().__init__()
        if attention_dim % num_heads:
            raise ValueError("attention_dim must be divisible by num_heads")
        self.image_dim = int(image_dim)
        self.token_dim = int(token_dim)
        self.attention_dim = int(attention_dim)
        self.num_heads = int(num_heads)
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed)
            self.image_norm = nn.LayerNorm(image_dim)
            self.token_norm = nn.LayerNorm(token_dim)
            self.query_projection = nn.Linear(image_dim, attention_dim)
            self.key_projection = nn.Linear(token_dim, attention_dim)
            self.value_projection = nn.Linear(token_dim, attention_dim)
            self.attention_output = nn.Linear(attention_dim, image_dim)
            self.ffn_norm = nn.LayerNorm(image_dim)
            hidden = ffn_ratio * image_dim
            self.ffn = nn.Sequential(
                nn.Linear(image_dim, hidden), nn.GELU(), nn.Linear(hidden, image_dim)
            )
        self.forward_count = 0
        self.last_attention_output: torch.Tensor | None = None
        self.last_post_block: torch.Tensor | None = None
        self.last_audit: dict[str, float] = {}

    def forward(
        self,
        feature: torch.Tensor,
        tokens: torch.Tensor,
        valid_mask: torch.Tensor,
        alpha: float,
    ) -> torch.Tensor:
        if feature.ndim != 5 or tokens.ndim != 3 or valid_mask.shape != tokens.shape[:2]:
            raise ValueError("B1 expects [B,C,D,H,W], [B,L,D], [B,L]")
        batch, channels, depth, height, width = feature.shape
        if channels != self.image_dim or tokens.shape[-1] != self.token_dim:
            raise ValueError("B1 feature/token channel mismatch")
        image = feature.flatten(2).transpose(1, 2)
        image_norm = self.image_norm(image.float())
        token_norm = self.token_norm(tokens.float())
        query = self.query_projection(image_norm)
        key = self.key_projection(token_norm)
        value = self.value_projection(token_norm)
        head_dim = self.attention_dim // self.num_heads

        def heads(x: torch.Tensor) -> torch.Tensor:
            return x.reshape(batch, -1, self.num_heads, head_dim).transpose(1, 2)

        q, k, v = heads(query), heads(key), heads(value)
        logits = torch.matmul(q, k.transpose(-1, -2)) / math.sqrt(head_dim)
        mask = valid_mask[:, None, None, :].bool()
        attention = torch.softmax(
            logits.masked_fill(~mask, torch.finfo(logits.dtype).min), dim=-1
        )
        attended = (
            torch.matmul(attention, v)
            .transpose(1, 2)
            .reshape(batch, -1, self.attention_dim)
        )
        residual = self.attention_output(attended).to(dtype=image.dtype)
        hidden = image + float(alpha) * residual
        ffn_residual = self.ffn(self.ffn_norm(hidden.float())).to(dtype=hidden.dtype)
        output = hidden + float(alpha) * ffn_residual
        output_3d = output.transpose(1, 2).reshape(
            batch, channels, depth, height, width
        )
        self.forward_count += 1
        self.last_attention_output = residual.transpose(1, 2).reshape(
            batch, channels, depth, height, width
        )
        self.last_post_block = output_3d
        base_rms = image.detach().float().square().mean().sqrt()
        residual_rms = residual.detach().float().square().mean().sqrt()
        self.last_audit = {
            "alpha": float(alpha),
            "x_rms": float(base_rms.item()),
            "ca_output_rms": float(residual_rms.item()),
            "ca_over_x_rms": float((residual_rms / base_rms.clamp_min(1e-12)).item()),
        }
        return output_3d


class MultiCandidateWordBridge(nn.Module):
    """B3 K-head word query generator initialized around the fitted B2 bridge."""

    def __init__(
        self,
        bridge: WordQueryBridge,
        candidates: int = 4,
        epsilon: float = 1e-3,
        seed: int = 260903,
    ) -> None:
        super().__init__()
        if candidates < 2:
            raise ValueError("B3 requires at least two candidates")
        self.candidates = int(candidates)
        self.initial_epsilon = float(epsilon)
        self.token_norm = bridge.token_norm
        self.score_projection = bridge.score_projection
        self.value_projection = bridge.value_projection
        self.output_projection = bridge.output_projection
        base = bridge.score_vector.detach().clone()
        generator = torch.Generator(device="cpu").manual_seed(seed)
        directions = torch.randn(candidates, base.numel(), generator=generator)
        directions[0].zero_()
        directions[1:] = directions[1:] / directions[1:].norm(
            dim=-1, keepdim=True
        ).clamp_min(1e-12)
        # The offsets are part of the trainable head parameters. Candidate 1 is
        # the exact B2 bridge anchor; candidates 2--4 begin at the smallest
        # feasibility-tested nonzero diversification scale.
        initial_vectors = base.repeat(candidates, 1) + float(epsilon) * directions
        self.score_vectors = nn.Parameter(initial_vectors)
        self.last_attention: torch.Tensor | None = None

    def forward(self, tokens: torch.Tensor, valid_mask: torch.Tensor) -> torch.Tensor:
        if tokens.ndim != 4 or valid_mask.shape != tokens.shape[:3]:
            raise ValueError("candidate bridge expects [B,P,L,D] tokens")
        normalized = self.token_norm(tokens.float())
        hidden = torch.tanh(self.score_projection(normalized))
        logits = torch.einsum("bpla,ka->bpkl", hidden, self.score_vectors)
        mask = valid_mask[:, :, None, :].expand_as(logits).bool()
        attention = masked_softmax(logits, mask)
        values = self.value_projection(normalized)
        pooled = torch.einsum("bpkl,bplv->bpkv", attention, values)
        self.last_attention = attention.detach()
        return self.output_projection(pooled)


class SentenceCandidateRouter(nn.Module):
    """Whole-sentence-only router over B3 word-generated mask embeddings."""

    def __init__(
        self,
        mask_dim: int = 2048,
        sentence_dim: int = 2560,
        router_dim: int = 256,
        scale: float = 0.1,
        seed: int = 260904,
    ) -> None:
        super().__init__()
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed)
            self.mask_projection = nn.Linear(mask_dim, router_dim, bias=False)
            self.sentence_projection = nn.Linear(sentence_dim, router_dim, bias=False)
        self.scale = float(scale)
        self.last_weights: torch.Tensor | None = None
        self.last_entropy: torch.Tensor | None = None
        self.last_scores: torch.Tensor | None = None

    def forward(
        self,
        candidate_masks: torch.Tensor,
        sentence: torch.Tensor,
        aggregation: str = "learned",
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if candidate_masks.ndim != 4 or sentence.shape != candidate_masks.shape[:2] + (2560,):
            raise ValueError("router expects masks [B,P,K,2048] and sentence [B,P,2560]")
        mask_key = self.mask_projection(candidate_masks.float())
        sentence_key = self.sentence_projection(sentence.float())
        scores = torch.einsum("bpkd,bpd->bpk", mask_key, sentence_key)
        scores = self.scale * scores / math.sqrt(mask_key.shape[-1])
        if aggregation == "learned":
            weights = torch.softmax(scores, dim=-1)
        elif aggregation == "uniform":
            weights = torch.full_like(scores, 1.0 / candidate_masks.shape[2])
        elif aggregation == "first":
            weights = torch.zeros_like(scores)
            weights[..., 0] = 1.0
        else:
            raise ValueError(f"Unknown candidate aggregation: {aggregation!r}")
        final = torch.einsum("bpk,bpkd->bpd", weights, candidate_masks)
        entropy = -(weights.clamp_min(1e-12) * weights.clamp_min(1e-12).log()).sum(-1)
        self.last_weights = weights.detach()
        self.last_entropy = entropy.detach()
        self.last_scores = scores.detach()
        return final, weights


def load_fitted_bridge(path: str) -> WordQueryBridge:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    architecture = dict(payload.get("architecture", {}))
    bridge = WordQueryBridge(**architecture)
    bridge.load_state_dict(payload["state_dict"], strict=True)
    return bridge
