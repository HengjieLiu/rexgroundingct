"""Experimental coarse-to-fine VoxTell wrapper.

This module keeps the public VoxTell model untouched. A lightweight low-res,
prompt-conditioned branch predicts a coarse spatial mask for each prompt. The
coarse probability is then fused into the high-res VoxTell branch through a
1x1 adapter initialized to ignore the coarse channel.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F
from torch import nn
from einops import rearrange
from positional_encodings.torch_encodings import PositionalEncoding3D


def _conv_block(in_channels: int, out_channels: int) -> nn.Sequential:
    return nn.Sequential(
        nn.Conv3d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
        nn.InstanceNorm3d(out_channels, affine=True),
        nn.LeakyReLU(negative_slope=1e-2, inplace=True),
        nn.Conv3d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
        nn.InstanceNorm3d(out_channels, affine=True),
        nn.LeakyReLU(negative_slope=1e-2, inplace=True),
    )


class LowResPromptUNet(nn.Module):
    """Small prompt-conditioned 3D UNet for coarse spatial localization."""

    def __init__(
        self,
        in_channels: int = 1,
        base_channels: int = 16,
        text_embedding_dim: int = 2560,
    ) -> None:
        super().__init__()
        self.enc1 = _conv_block(in_channels, base_channels)
        self.down1 = nn.Conv3d(base_channels, base_channels * 2, kernel_size=3, stride=2, padding=1, bias=False)
        self.enc2 = _conv_block(base_channels * 2, base_channels * 2)
        self.down2 = nn.Conv3d(base_channels * 2, base_channels * 4, kernel_size=3, stride=2, padding=1, bias=False)
        self.bottleneck = _conv_block(base_channels * 4, base_channels * 4)
        self.up2 = nn.ConvTranspose3d(base_channels * 4, base_channels * 2, kernel_size=2, stride=2)
        self.dec2 = _conv_block(base_channels * 4, base_channels * 2)
        self.up1 = nn.ConvTranspose3d(base_channels * 2, base_channels, kernel_size=2, stride=2)
        self.dec1 = _conv_block(base_channels * 2, base_channels)

        self.text_film = nn.Sequential(
            nn.Linear(text_embedding_dim, base_channels * 4),
            nn.GELU(),
            nn.Linear(base_channels * 4, base_channels * 2),
        )
        self.out = nn.Conv3d(base_channels, 1, kernel_size=1)

    def forward(self, image: torch.Tensor, text_embedding: torch.Tensor) -> torch.Tensor:
        """Return low-res logits with shape ``[B, N, d, h, w]``."""
        if image.ndim != 5:
            raise ValueError(f"image must be [B, C, D, H, W], got {tuple(image.shape)}")
        if text_embedding.ndim == 4:
            text_embedding = text_embedding.squeeze(2)
        if text_embedding.ndim != 3:
            raise ValueError(
                "text_embedding must be [B, N, E] or [B, N, 1, E], "
                f"got {tuple(text_embedding.shape)}"
            )

        x1 = self.enc1(image)
        x2 = self.enc2(self.down1(x1))
        xb = self.bottleneck(self.down2(x2))

        x = self.up2(xb)
        if x.shape[2:] != x2.shape[2:]:
            x = F.interpolate(x, size=x2.shape[2:], mode="trilinear", align_corners=False)
        x = self.dec2(torch.cat([x, x2], dim=1))
        x = self.up1(x)
        if x.shape[2:] != x1.shape[2:]:
            x = F.interpolate(x, size=x1.shape[2:], mode="trilinear", align_corners=False)
        features = self.dec1(torch.cat([x, x1], dim=1))

        batch_size, num_prompts, _ = text_embedding.shape
        gamma_beta = self.text_film(text_embedding)
        gamma, beta = gamma_beta.chunk(2, dim=-1)
        gamma = gamma.view(batch_size, num_prompts, -1, 1, 1, 1)
        beta = beta.view(batch_size, num_prompts, -1, 1, 1, 1)
        prompt_features = features[:, None] * (1 + gamma) + beta

        flat_features = prompt_features.reshape(batch_size * num_prompts, features.shape[1], *features.shape[2:])
        logits = self.out(flat_features)
        return logits.reshape(batch_size, num_prompts, *features.shape[2:])


@dataclass
class VoxTellCoarseToFineOutput:
    logits: torch.Tensor | list[torch.Tensor]
    lowres_logits: torch.Tensor
    lowres_prob: torch.Tensor
    coarse_up: torch.Tensor
    prob: torch.Tensor | None = None


class VoxTellCoarseToFine(nn.Module):
    """Two-stage prompt-conditioned VoxTell prototype."""

    VALID_FUSION_MODES = ("input_concat_2ch", "adapter_2to1")
    VALID_LOWRES_BRANCHES = ("small_unet", "voxtell", "truncated_voxtell")

    def __init__(
        self,
        highres_voxtell: nn.Module,
        lowres_size: int | tuple[int, int, int] = 64,
        text_embedding_dim: int = 2560,
        lowres_base_channels: int = 16,
        lowres_branch_type: str = "small_unet",
        lowres_voxtell: nn.Module | None = None,
        fusion_mode: str = "input_concat_2ch",
        print_fusion_shapes: bool = False,
    ) -> None:
        super().__init__()
        if fusion_mode not in self.VALID_FUSION_MODES:
            raise ValueError(f"fusion_mode must be one of {self.VALID_FUSION_MODES}, got {fusion_mode!r}")
        if lowres_branch_type not in self.VALID_LOWRES_BRANCHES:
            raise ValueError(
                f"lowres_branch_type must be one of {self.VALID_LOWRES_BRANCHES}, got {lowres_branch_type!r}"
            )
        if isinstance(lowres_size, int):
            lowres_size = (lowres_size, lowres_size, lowres_size)
        self.highres_voxtell = highres_voxtell
        self.lowres_size = tuple(int(x) for x in lowres_size)
        self.lowres_branch_type = lowres_branch_type
        self.fusion_mode = fusion_mode
        self.print_fusion_shapes = print_fusion_shapes
        self._printed_fusion_shapes = False
        self._printed_logits_shape = False
        if self.lowres_branch_type in {"voxtell", "truncated_voxtell"}:
            if lowres_voxtell is None:
                raise ValueError(f"lowres_branch_type={lowres_branch_type!r} requires lowres_voxtell.")
            self.lowres_voxtell = lowres_voxtell
            self.lowres_branch = None
        else:
            self.lowres_voxtell = None
            self.lowres_branch = LowResPromptUNet(
                in_channels=1,
                base_channels=lowres_base_channels,
                text_embedding_dim=text_embedding_dim,
            )
        self.highres_adapter = nn.Conv3d(2, 1, kernel_size=1, bias=True)
        self.reset_adapter()
        if self.fusion_mode == "input_concat_2ch":
            self._expand_highres_first_conv_to_2ch()
        print(f"VoxTellCoarseToFine fusion_mode={self.fusion_mode}; lowres_branch={self.lowres_branch_type}")

    def reset_adapter(self) -> None:
        with torch.no_grad():
            self.highres_adapter.weight.zero_()
            self.highres_adapter.weight[:, 0] = 1.0
            self.highres_adapter.bias.zero_()

    def _find_first_conv3d(self) -> tuple[nn.Module, str, nn.Conv3d, str, nn.Module]:
        search_roots: list[tuple[str, nn.Module]] = []
        encoder = getattr(self.highres_voxtell, "encoder", None)
        stem = getattr(encoder, "stem", None)
        if isinstance(stem, nn.Module):
            search_roots.append(("encoder.stem", stem))
        search_roots.append(("", self.highres_voxtell))

        for root_name, root in search_roots:
            for module_name, module in root.named_modules(remove_duplicate=False):
                for child_name, child in module.named_children():
                    if isinstance(child, nn.Conv3d):
                        full_name = ".".join(part for part in [root_name, module_name, child_name] if part)
                        return module, child_name, child, full_name, root
        raise RuntimeError("Could not find a Conv3d layer in the high-res VoxTell branch.")

    @staticmethod
    def _replace_all_module_references(root: nn.Module, old: nn.Module, new: nn.Module) -> int:
        replacements = 0
        for module in root.modules():
            for child_name, child in list(module._modules.items()):
                if child is old:
                    module._modules[child_name] = new
                    replacements += 1
        return replacements

    def _expand_highres_first_conv_to_2ch(self) -> None:
        parent, child_name, conv, conv_name, search_root = self._find_first_conv3d()
        if conv.in_channels == 2:
            return
        if conv.in_channels != 1:
            raise RuntimeError(
                "input_concat_2ch expects the pretrained high-res first Conv3d to have "
                f"one input channel before expansion, got {conv.in_channels}."
            )

        expanded = nn.Conv3d(
            in_channels=2,
            out_channels=conv.out_channels,
            kernel_size=conv.kernel_size,
            stride=conv.stride,
            padding=conv.padding,
            dilation=conv.dilation,
            groups=conv.groups,
            bias=conv.bias is not None,
            padding_mode=conv.padding_mode,
            device=conv.weight.device,
            dtype=conv.weight.dtype,
        )
        with torch.no_grad():
            expanded.weight.zero_()
            expanded.weight[:, :1].copy_(conv.weight)
            if conv.bias is not None:
                expanded.bias.copy_(conv.bias)
        replacements = self._replace_all_module_references(search_root, conv, expanded)
        if replacements == 0:
            parent._modules[child_name] = expanded
            replacements = 1
        print(
            f"Expanded high-res first Conv3d for coarse fusion: {conv_name} 1ch -> 2ch "
            f"({replacements} module reference(s) updated)"
        )

    @staticmethod
    def _refresh_voxtell_pos_embed_for_feature(voxtell: nn.Module, selected_feature: torch.Tensor) -> None:
        """Adapt VoxTell's fixed positional encoding to a low-res input shape."""
        query_dim = int(getattr(voxtell, "query_dim"))
        spatial_shape = tuple(int(x) for x in selected_feature.shape[2:])
        current = getattr(voxtell, "pos_embed")
        expected_tokens = spatial_shape[0] * spatial_shape[1] * spatial_shape[2]
        if (
            isinstance(current, torch.Tensor)
            and current.shape[0] == expected_tokens
            and current.shape[-1] == query_dim
            and current.device == selected_feature.device
            and current.dtype == selected_feature.dtype
        ):
            return
        pos_encoding = PositionalEncoding3D(query_dim).to(device=selected_feature.device, dtype=selected_feature.dtype)
        pos_embed = pos_encoding(
            torch.zeros(1, *spatial_shape, query_dim, device=selected_feature.device, dtype=selected_feature.dtype)
        )
        voxtell.pos_embed = rearrange(pos_embed, "b h w d c -> (h w d) b c")

    def _forward_lowres_voxtell(self, lowres_image: torch.Tensor, text_embedding: torch.Tensor) -> torch.Tensor:
        if self.lowres_voxtell is None:
            raise RuntimeError("lowres_voxtell is not initialized.")
        selected_layer = int(getattr(self.lowres_voxtell, "selected_decoder_layer"))
        with torch.no_grad():
            skips = self.lowres_voxtell.encoder(lowres_image)
        self._refresh_voxtell_pos_embed_for_feature(self.lowres_voxtell, skips[selected_layer])
        lowres_logits = self.lowres_voxtell(lowres_image, text_embedding=text_embedding)
        if isinstance(lowres_logits, list):
            lowres_logits = lowres_logits[0]
        return lowres_logits

    def forward(
        self,
        image: torch.Tensor,
        text: None = None,
        text_embedding: torch.Tensor | None = None,
        lowres_image: torch.Tensor | None = None,
        return_lowres: bool = True,
        **kwargs,
    ) -> dict[str, torch.Tensor | list[torch.Tensor] | None]:
        del text, kwargs
        if text_embedding is None:
            raise ValueError("VoxTellCoarseToFine requires precomputed text_embedding.")
        if image.ndim != 5:
            raise ValueError(f"image must be [B, C, D, H, W], got {tuple(image.shape)}")
        if image.shape[1] != 1:
            raise ValueError(f"Expected one CT channel before coarse fusion, got C={image.shape[1]}")
        if text_embedding.ndim == 3:
            text_embedding = text_embedding[:, :, None, :]
        if text_embedding.ndim != 4:
            raise ValueError(
                "text_embedding must be [B, N, 1, E] or [B, N, E], "
                f"got {tuple(text_embedding.shape)}"
            )

        if lowres_image is None:
            lowres_image = F.interpolate(image.float(), size=self.lowres_size, mode="trilinear", align_corners=False)
        if lowres_image.ndim != 5 or lowres_image.shape[:2] != image.shape[:2]:
            raise ValueError(
                f"lowres_image must be [B, C, d, h, w] with B,C={tuple(image.shape[:2])}, "
                f"got {tuple(lowres_image.shape)}"
            )

        if self.lowres_branch_type in {"voxtell", "truncated_voxtell"}:
            lowres_logits = self._forward_lowres_voxtell(lowres_image, text_embedding)
        else:
            if self.lowres_branch is None:
                raise RuntimeError("lowres_branch is not initialized.")
            lowres_logits = self.lowres_branch(lowres_image, text_embedding)
        lowres_prob = torch.sigmoid(lowres_logits)
        coarse_up = F.interpolate(
            lowres_prob,
            size=image.shape[2:],
            mode="trilinear",
            align_corners=False,
        )
        if coarse_up.shape[:2] != text_embedding.shape[:2] or coarse_up.shape[2:] != image.shape[2:]:
            raise RuntimeError(
                f"coarse_up shape {tuple(coarse_up.shape)} is inconsistent with "
                f"text {tuple(text_embedding.shape)} and image {tuple(image.shape)}"
            )

        per_prompt_outputs: list[torch.Tensor | list[torch.Tensor]] = []
        num_prompts = text_embedding.shape[1]
        for prompt_idx in range(num_prompts):
            prompt_coarse = coarse_up[:, prompt_idx : prompt_idx + 1]
            highres_input = torch.cat([image, prompt_coarse], dim=1)
            if highres_input.shape[1] != 2:
                raise RuntimeError(f"HR input must be [B, 2, D, H, W], got {tuple(highres_input.shape)}")
            if self.print_fusion_shapes and not self._printed_fusion_shapes:
                print(
                    "VoxTellCoarseToFine fusion shapes: "
                    f"CT={tuple(image.shape)}; "
                    f"coarse_up_prompt={tuple(prompt_coarse.shape)}; "
                    f"HR input={tuple(highres_input.shape)}"
                )
                self._printed_fusion_shapes = True
            if self.fusion_mode == "input_concat_2ch":
                highres_branch_input = highres_input
            elif self.fusion_mode == "adapter_2to1":
                highres_branch_input = self.highres_adapter(highres_input)
            else:
                raise RuntimeError(f"Unexpected fusion mode: {self.fusion_mode}")
            prompt_embedding = text_embedding[:, prompt_idx : prompt_idx + 1]
            prompt_output = self.highres_voxtell(highres_branch_input, prompt_embedding)
            if self.print_fusion_shapes and prompt_idx == 0 and not self._printed_logits_shape:
                prompt_primary = prompt_output[0] if isinstance(prompt_output, list) else prompt_output
                print(f"VoxTellCoarseToFine fusion shapes: logits={tuple(prompt_primary.shape)}")
                self._printed_logits_shape = True
            per_prompt_outputs.append(prompt_output)

        first = per_prompt_outputs[0]
        if isinstance(first, list):
            final_logits: torch.Tensor | list[torch.Tensor] = []
            for scale_idx in range(len(first)):
                final_logits.append(torch.cat([out[scale_idx] for out in per_prompt_outputs], dim=1))
        else:
            final_logits = torch.cat(per_prompt_outputs, dim=1)  # type: ignore[arg-type]

        primary_logits = final_logits[0] if isinstance(final_logits, list) else final_logits
        out: dict[str, torch.Tensor | list[torch.Tensor] | None] = {
            "logits": final_logits,
            "lowres_logits": lowres_logits,
            "lowres_prob": lowres_prob if return_lowres else None,
            "coarse_up": coarse_up if return_lowres else None,
            "prob": torch.sigmoid(primary_logits),
        }
        return out
