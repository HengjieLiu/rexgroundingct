"""MoME-Core adaptation for free-text, instance-specific 3D grounding.

This module is deliberately isolated from the released VoxTell implementation.
It reuses every native decoder stage, the projected full finding query, and the
deepest visual feature while replacing only the final full-resolution logit.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import torch
import torch.nn.functional as F
from torch import nn

from voxtell.model.voxtell_experimental import ExperimentalVoxTellModel


DYNAMIC_PARAMETER_COUNT = 8 * 8 + 8 + 8 * 8 + 8 + 1 * 8 + 1


@dataclass(frozen=True)
class MoMECoreConfig:
    """Configuration shared by common-uniform and learned-router arms."""

    mode: str = "uniform"
    expert_channels: int = 8
    controller_width: int = 128
    router_hidden_channels: int = 32
    router_normalization: str = "softplus_l1"
    router_temperature: float = 1.0
    router_epsilon: float = 1e-6
    router_condition_text: bool = True
    integration: str = "replace"
    capture_router_maps: bool = False

    def validate(self) -> None:
        if self.mode not in {"uniform", "learned"}:
            raise ValueError(f"MoME mode must be uniform or learned, got {self.mode!r}")
        if self.expert_channels != 8:
            raise ValueError("The stage-1 MoME-Core protocol requires exactly 8 expert channels")
        if self.controller_width <= 0 or self.router_hidden_channels <= 0:
            raise ValueError("Controller and router widths must be positive")
        if self.router_normalization not in {"softplus_l1", "softmax"}:
            raise ValueError(
                "router_normalization must be 'softplus_l1' or 'softmax'"
            )
        if self.router_temperature <= 0 or self.router_epsilon <= 0:
            raise ValueError("Router temperature and epsilon must be positive")
        if self.integration not in {"replace", "residual"}:
            raise ValueError("integration must be 'replace' or 'residual'")


class DecoderExpertProjection3D(nn.Module):
    """Small-batch-stable norm -> GELU -> voxel-wise 1x1x1 projection."""

    def __init__(self, input_channels: int, output_channels: int = 8) -> None:
        super().__init__()
        self.norm = nn.InstanceNorm3d(input_channels, affine=True, eps=1e-5)
        self.activation = nn.GELU()
        self.projection = nn.Conv3d(input_channels, output_channels, 1, bias=True)

    def forward(self, feature: torch.Tensor) -> torch.Tensor:
        return self.projection(self.activation(self.norm(feature)))


class FindingImageController(nn.Module):
    """Fuse separately normalized/projected finding and global visual features."""

    def __init__(
        self,
        finding_channels: int,
        visual_channels: int,
        latent_channels: int,
    ) -> None:
        super().__init__()
        self.finding_norm = nn.LayerNorm(finding_channels)
        self.finding_projection = nn.Linear(finding_channels, latent_channels)
        self.visual_norm = nn.LayerNorm(visual_channels)
        self.visual_projection = nn.Linear(visual_channels, latent_channels)
        self.fusion = nn.Sequential(
            nn.Linear(2 * latent_channels, latent_channels),
            nn.GELU(),
            nn.LayerNorm(latent_channels),
        )

    def forward(
        self,
        finding: torch.Tensor,
        visual: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        q = self.finding_projection(self.finding_norm(finding))
        v = self.visual_projection(self.visual_norm(visual))
        return self.fusion(torch.cat((q, v), dim=-1)), v


class ConditionalVoxelRouter3D(nn.Module):
    """Mathematically equivalent MLP on [local expert feature, condition]."""

    def __init__(
        self,
        feature_channels: int,
        condition_channels: int,
        hidden_channels: int,
    ) -> None:
        super().__init__()
        self.feature_projection = nn.Conv3d(
            feature_channels, hidden_channels, 1, bias=False
        )
        self.condition_projection = nn.Linear(
            condition_channels, hidden_channels, bias=False
        )
        self.hidden_bias = nn.Parameter(torch.zeros(hidden_channels))
        self.score = nn.Conv3d(hidden_channels, 1, 1, bias=True)
        # Zero logits make both supported normalizations exactly uniform.
        nn.init.zeros_(self.score.weight)
        nn.init.zeros_(self.score.bias)

    def forward(
        self,
        feature: torch.Tensor,
        condition: torch.Tensor,
    ) -> torch.Tensor:
        conditional = self.condition_projection(condition)[..., None, None, None]
        hidden = F.gelu(
            self.feature_projection(feature)
            + conditional
            + self.hidden_bias[None, :, None, None, None]
        )
        return self.score(hidden)


def parse_dynamic_parameters(
    parameters: torch.Tensor,
    channels: int = 8,
) -> tuple[tuple[torch.Tensor, torch.Tensor], ...]:
    """Parse 153 generated values into three per-sample 1x1x1 convolutions."""

    expected = channels * channels + channels
    expected += channels * channels + channels
    expected += channels + 1
    if parameters.ndim != 2 or parameters.shape[1] != expected:
        raise ValueError(
            f"Expected dynamic parameters [B,{expected}], got {tuple(parameters.shape)}"
        )
    batch = parameters.shape[0]
    offset = 0
    parsed: list[tuple[torch.Tensor, torch.Tensor]] = []
    for output_channels, input_channels in (
        (channels, channels),
        (channels, channels),
        (1, channels),
    ):
        weight_count = output_channels * input_channels
        weight = parameters[:, offset : offset + weight_count].reshape(
            batch, output_channels, input_channels, 1, 1, 1
        )
        offset += weight_count
        bias = parameters[:, offset : offset + output_channels]
        offset += output_channels
        parsed.append((weight, bias))
    if offset != expected:
        raise AssertionError(f"Dynamic parameter parser stopped at {offset}, expected {expected}")
    return tuple(parsed)


def _grouped_dynamic_conv3d(
    feature: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
) -> torch.Tensor:
    batch, input_channels, depth, height, width = feature.shape
    if weight.shape[0] != batch or weight.shape[2] != input_channels:
        raise ValueError("Dynamic weight batch/input channels do not match feature")
    output_channels = weight.shape[1]
    result = F.conv3d(
        feature.reshape(1, batch * input_channels, depth, height, width),
        weight.reshape(batch * output_channels, input_channels, 1, 1, 1),
        bias.reshape(batch * output_channels),
        groups=batch,
    )
    return result.reshape(batch, output_channels, depth, height, width)


class ConditionalDynamicHead3D(nn.Module):
    """Base-plus-conditional 8->8->8->1 dynamic segmentation head."""

    def __init__(self, condition_channels: int, channels: int = 8) -> None:
        super().__init__()
        if channels != 8:
            raise ValueError("The stage-1 protocol fixes the dynamic head width at 8")
        self.channels = channels
        self.parameter_count = DYNAMIC_PARAMETER_COUNT
        self.base_parameters = nn.Parameter(torch.empty(self.parameter_count))
        self.hypernetwork = nn.Sequential(
            nn.LayerNorm(condition_channels),
            nn.Linear(condition_channels, condition_channels),
            nn.GELU(),
            nn.Linear(condition_channels, self.parameter_count),
        )
        self.reset_parameters()

    def reset_parameters(self) -> None:
        # A shared static head is active at initialization; all finding-specific
        # deltas are exactly zero as required by the protocol.
        nn.init.normal_(self.base_parameters, mean=0.0, std=0.02)
        final = self.hypernetwork[-1]
        assert isinstance(final, nn.Linear)
        nn.init.zeros_(final.weight)
        nn.init.zeros_(final.bias)

    def generated_parameters(self, condition: torch.Tensor) -> torch.Tensor:
        return self.base_parameters[None] + self.hypernetwork(condition)

    def forward(
        self,
        feature: torch.Tensor,
        condition: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        parameters = self.generated_parameters(condition)
        layers = parse_dynamic_parameters(parameters, self.channels)
        output = feature
        for layer_index, (weight, bias) in enumerate(layers):
            output = _grouped_dynamic_conv3d(output, weight, bias)
            if layer_index < 2:
                output = F.relu(output)
        return output, parameters


class MoMECoreAdapter(nn.Module):
    """Streaming all-stage expert fusion attached to a native VoxTell decoder."""

    STAGE_CHANNELS = (320, 256, 128, 64, 32)

    def __init__(self, config: MoMECoreConfig) -> None:
        super().__init__()
        config.validate()
        self.config = config
        self.expert_projections = nn.ModuleList(
            DecoderExpertProjection3D(channels, config.expert_channels)
            for channels in self.STAGE_CHANNELS
        )
        self.controller = FindingImageController(
            finding_channels=2048,
            visual_channels=320,
            latent_channels=config.controller_width,
        )
        self.routers = (
            nn.ModuleList(
                ConditionalVoxelRouter3D(
                    config.expert_channels,
                    config.controller_width,
                    config.router_hidden_channels,
                )
                for _ in self.STAGE_CHANNELS
            )
            if config.mode == "learned"
            else None
        )
        self.dynamic_head = ConditionalDynamicHead3D(
            config.controller_width, config.expert_channels
        )
        self._hooks: list[Any] = []
        self._bound = False
        self._reset_runtime()
        self._initialize_experts()

    def _initialize_experts(self) -> None:
        # Non-final experts start silent. The final expert is multiplied by L
        # to compensate uniform averaging, so the initial fused scale is not
        # artificially reduced solely by the number of experts.
        for projection in self.expert_projections[:-1]:
            nn.init.zeros_(projection.projection.weight)
            nn.init.zeros_(projection.projection.bias)
        final = self.expert_projections[-1].projection
        nn.init.kaiming_normal_(final.weight, nonlinearity="linear")
        nn.init.zeros_(final.bias)
        with torch.no_grad():
            final.weight.mul_(len(self.STAGE_CHANNELS))

    def bind(self, model: ExperimentalVoxTellModel) -> None:
        if self._bound:
            raise RuntimeError("MoME-Core adapter is already bound")
        self._hooks.append(model.encoder.register_forward_hook(self._encoder_hook))
        self._hooks.append(
            model.project_text_embed.register_forward_hook(self._finding_hook)
        )
        for stage_index, stage in enumerate(model.decoder.stages):
            self._hooks.append(
                stage.register_forward_hook(self._make_stage_hook(stage_index))
            )
        self._bound = True

    def _reset_runtime(self) -> None:
        self._deepest_visual: torch.Tensor | None = None
        self._finding_query: torch.Tensor | None = None
        self._theta: torch.Tensor | None = None
        self._visual_condition: torch.Tensor | None = None
        self._prompt_index = 0
        self._numerator: torch.Tensor | None = None
        self._denominator: torch.Tensor | None = None
        self._online_max: torch.Tensor | None = None
        self._prompt_logits: list[torch.Tensor] = []
        self._prompt_parameters: list[torch.Tensor] = []
        self._projection_rms: list[list[torch.Tensor]] = []
        self._current_projection_rms: list[torch.Tensor] = []
        self._raw_router_values: list[torch.Tensor] = []
        self._prompt_router_maps: list[torch.Tensor] = []
        self._router_samples: list[torch.Tensor] = []
        self._prompt_router_sample_weights: list[torch.Tensor] = []
        self.last_router_stats: dict[str, torch.Tensor] = {}
        self.last_theta: torch.Tensor | None = None
        self.last_dynamic_parameters: torch.Tensor | None = None
        self.last_router_maps: torch.Tensor | None = None
        self.last_projection_rms: torch.Tensor | None = None

    def begin_forward(self) -> None:
        self._reset_runtime()

    def _encoder_hook(self, _module: nn.Module, _inputs: Any, output: Any) -> None:
        if not isinstance(output, (list, tuple)) or not output:
            raise RuntimeError("MoME-Core expected encoder skips")
        self._deepest_visual = output[-1]

    def _finding_hook(self, _module: nn.Module, _inputs: Any, output: Any) -> None:
        if output.ndim != 3:
            raise RuntimeError(
                f"MoME-Core expected projected finding [P,B,C], got {tuple(output.shape)}"
            )
        self._finding_query = output

    def _ensure_conditions(self) -> None:
        if self._theta is not None:
            return
        if self._finding_query is None or self._deepest_visual is None:
            raise RuntimeError("MoME-Core hooks did not capture finding/image features")
        visual = self._deepest_visual.mean(dim=(2, 3, 4))
        prompts, batch, channels = self._finding_query.shape
        visual_by_prompt = visual[None].expand(prompts, -1, -1)
        theta, visual_condition = self.controller(
            self._finding_query.reshape(prompts * batch, channels),
            visual_by_prompt.reshape(prompts * batch, visual.shape[-1]),
        )
        self._theta = theta.reshape(prompts, batch, -1)
        self._visual_condition = visual_condition.reshape(prompts, batch, -1)

    def _make_stage_hook(self, stage_index: int):
        def hook(_module: nn.Module, _inputs: Any, output: torch.Tensor) -> None:
            self._consume_stage(stage_index, output)

        return hook

    def _consume_stage(self, stage_index: int, feature: torch.Tensor) -> None:
        self._ensure_conditions()
        assert self._theta is not None
        prompt_index = self._prompt_index
        if prompt_index >= self._theta.shape[0]:
            raise RuntimeError("Decoder produced more prompt passes than finding queries")
        projected = self.expert_projections[stage_index](feature)
        self._current_projection_rms.append(
            projected.detach().float().square().mean(dim=(1, 2, 3, 4)).sqrt()
        )
        final_size = feature.shape[2:] if stage_index == len(self.STAGE_CHANNELS) - 1 else None
        if final_size is None:
            # Canonical geometry is fixed at 192^3. Infer it from the known
            # stage stride so tests with smaller power-of-two tensors also work.
            scale = 2 ** (len(self.STAGE_CHANNELS) - 1 - stage_index)
            final_size = tuple(int(value * scale) for value in feature.shape[2:])
        if tuple(projected.shape[2:]) != tuple(final_size):
            projected = F.interpolate(
                projected, size=final_size, mode="trilinear", align_corners=False
            )

        if self.config.mode == "uniform":
            contribution = projected / len(self.STAGE_CHANNELS)
            self._numerator = (
                contribution
                if self._numerator is None
                else self._numerator + contribution
            )
        else:
            assert self.routers is not None
            condition = (
                self._theta[prompt_index]
                if self.config.router_condition_text
                else self._visual_condition[prompt_index]
            )
            score = self.routers[stage_index](projected, condition)
            if self.config.router_normalization == "softplus_l1":
                positive = F.softplus(score) + self.config.router_epsilon
                self._router_samples.append(
                    positive.detach().flatten(start_dim=2)[..., ::1729]
                )
                self._numerator = (
                    positive * projected
                    if self._numerator is None
                    else self._numerator + positive * projected
                )
                self._denominator = (
                    positive
                    if self._denominator is None
                    else self._denominator + positive
                )
                if self.config.capture_router_maps:
                    self._raw_router_values.append(positive.detach())
            else:
                scaled = score / self.config.router_temperature
                self._router_samples.append(
                    scaled.detach().flatten(start_dim=2)[..., ::1729]
                )
                if self._online_max is None:
                    self._online_max = scaled
                    self._denominator = torch.ones_like(scaled)
                    self._numerator = projected
                else:
                    new_max = torch.maximum(self._online_max, scaled)
                    old_factor = torch.exp(self._online_max - new_max)
                    new_factor = torch.exp(scaled - new_max)
                    self._numerator = self._numerator * old_factor + projected * new_factor
                    self._denominator = self._denominator * old_factor + new_factor
                    self._online_max = new_max
                if self.config.capture_router_maps:
                    self._raw_router_values.append(scaled.detach())

        if stage_index == len(self.STAGE_CHANNELS) - 1:
            assert self._numerator is not None
            fused = (
                self._numerator
                if self.config.mode == "uniform"
                else self._numerator / self._denominator.clamp_min(
                    self.config.router_epsilon
                )
            )
            logit, parameters = self.dynamic_head(fused, self._theta[prompt_index])
            self._prompt_logits.append(logit)
            self._prompt_parameters.append(parameters)
            self._projection_rms.append(self._current_projection_rms)
            self._current_projection_rms = []
            if self.config.capture_router_maps and self.config.mode == "learned":
                assert self._denominator is not None
                raw = self._raw_router_values
                if self.config.router_normalization == "softplus_l1":
                    weights = torch.cat(
                        [value / self._denominator.detach() for value in raw], dim=1
                    )
                else:
                    weights = torch.softmax(
                        torch.cat(raw, dim=1), dim=1
                    )
                self._prompt_router_maps.append(weights)
                entropy = -(weights.clamp_min(1e-12) * weights.clamp_min(1e-12).log()).sum(dim=1)
                self.last_router_stats = {
                    "mome_router_weight_min": weights.amin(),
                    "mome_router_weight_max": weights.amax(),
                    "mome_router_entropy_mean": entropy.mean(),
                    "mome_router_sum_error_max": (weights.sum(dim=1) - 1).abs().amax(),
                }
                self._raw_router_values = []
            elif self.config.mode == "learned":
                # Zero scoring layers imply uniform weights at initialization.
                self.last_router_stats = {
                    "mome_router_denominator_min": self._denominator.detach().amin(),
                    "mome_router_denominator_max": self._denominator.detach().amax(),
                }
            if self.config.mode == "learned":
                sampled = torch.cat(self._router_samples, dim=1)
                sampled_weights = (
                    sampled / sampled.sum(dim=1, keepdim=True).clamp_min(
                        self.config.router_epsilon
                    )
                    if self.config.router_normalization == "softplus_l1"
                    else torch.softmax(sampled, dim=1)
                )
                self._prompt_router_sample_weights.append(sampled_weights)
                self._router_samples = []
            self._prompt_index += 1
            self._numerator = None
            self._denominator = None
            self._online_max = None

    def finish_forward(self) -> torch.Tensor:
        if not self._prompt_logits:
            raise RuntimeError("MoME-Core did not receive decoder stage outputs")
        if self._finding_query is None or len(self._prompt_logits) != self._finding_query.shape[0]:
            raise RuntimeError("MoME-Core prompt output count does not match finding count")
        self.last_theta = self._theta
        self.last_dynamic_parameters = torch.stack(self._prompt_parameters, dim=1)
        self.last_projection_rms = torch.stack(
            [torch.stack(values, dim=1) for values in self._projection_rms], dim=1
        )
        if self._prompt_router_maps:
            self.last_router_maps = torch.stack(self._prompt_router_maps, dim=1)
        if self._prompt_router_sample_weights:
            sampled_weights = torch.stack(
                self._prompt_router_sample_weights, dim=1
            )
            sampled_entropy = -(
                sampled_weights.clamp_min(1e-12)
                * sampled_weights.clamp_min(1e-12).log()
            ).sum(dim=2)
            self.last_router_stats.update(
                {
                    "mome_router_weight_min": sampled_weights.amin(),
                    "mome_router_weight_max": sampled_weights.amax(),
                    "mome_router_entropy_mean": sampled_entropy.mean(),
                    "mome_router_sum_error_max": (
                        sampled_weights.sum(dim=2) - 1
                    ).abs().amax(),
                    **{
                        f"mome_router_weight_mean_stage_{stage}": sampled_weights[
                            :, :, stage
                        ].mean()
                        for stage in range(len(self.STAGE_CHANNELS))
                    },
                }
            )
        return torch.cat(self._prompt_logits, dim=1)

    def config_dict(self) -> dict[str, Any]:
        return asdict(self.config)


class MoMECoreVoxTellModel(ExperimentalVoxTellModel):
    """Experimental VoxTell subclass with an isolated MoME-Core endpoint."""

    def __init__(self, *args: Any, mome_core_config: MoMECoreConfig, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.mome_core = MoMECoreAdapter(mome_core_config)
        self.mome_core.bind(self)
        self.mome_core_config = mome_core_config

    def forward(self, *args: Any, **kwargs: Any):
        self.mome_core.begin_forward()
        baseline_output = super().forward(*args, **kwargs)
        mome_logit = self.mome_core.finish_forward()

        def replace(output: Any):
            primary = output[0] if isinstance(output, list) else output
            endpoint = (
                mome_logit + primary
                if self.mome_core_config.integration == "residual"
                else mome_logit
            )
            if isinstance(output, list):
                return [endpoint, *output[1:]]
            return endpoint

        if isinstance(baseline_output, tuple):
            segmentation, *rest = baseline_output
            replaced = replace(segmentation)
            baseline_output = (replaced, *rest)
        else:
            replaced = replace(baseline_output)
            baseline_output = replaced
        self.last_auxiliary_stats.update(self.mome_core.last_router_stats)
        if self.mome_core.last_projection_rms is not None:
            for stage in range(len(self.mome_core.STAGE_CHANNELS)):
                self.last_auxiliary_stats[f"mome_projection_rms_stage_{stage}"] = (
                    self.mome_core.last_projection_rms[:, :, stage].mean()
                )
        if self.mome_core.last_theta is not None:
            self.last_auxiliary_stats["mome_theta_std"] = self.mome_core.last_theta.detach().float().std()
        if self.mome_core.last_dynamic_parameters is not None:
            base = self.mome_core.dynamic_head.base_parameters.detach()
            self.last_auxiliary_stats["mome_dynamic_delta_rms"] = (
                self.mome_core.last_dynamic_parameters.detach().float()
                - base.float()[None, None]
            ).square().mean().sqrt()
        return baseline_output
