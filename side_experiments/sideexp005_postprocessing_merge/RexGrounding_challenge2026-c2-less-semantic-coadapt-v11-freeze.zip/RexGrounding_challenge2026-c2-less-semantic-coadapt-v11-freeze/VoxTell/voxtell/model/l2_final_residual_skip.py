"""Small category-gated L2-to-final residual skip used by P0-I-lite.

The adapter is intentionally external to the native VoxTell architecture.  It
is attached with forward hooks to decoder stages 3 and 4 so a zero gate is an
exact endpoint and old checkpoints/inference paths remain unchanged.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import torch
import torch.nn.functional as F
from torch import nn


@dataclass
class ResidualNormRecord:
    category_index: int
    projected_l2_norm: float
    gated_residual_norm: float
    original_final_norm: float
    residual_to_final_ratio: float


class L2ToFinalResidualSkip3D(nn.Module):
    FORMAT_VERSION = "voxtell_l2_to_final_residual_skip.v1"

    def __init__(
        self,
        categories: Iterable[str],
        in_channels: int = 64,
        out_channels: int = 32,
    ) -> None:
        super().__init__()
        normalized = tuple(str(value) for value in categories)
        if "unknown" not in normalized:
            normalized = ("unknown", *normalized)
        if len(set(normalized)) != len(normalized):
            raise ValueError(f"Duplicate categories: {normalized}")
        self.categories = normalized
        self.category_to_index = {
            category: index for index, category in enumerate(self.categories)
        }
        self.unknown_index = self.category_to_index["unknown"]
        self.projection = nn.Conv3d(
            int(in_channels), int(out_channels), kernel_size=1, bias=True
        )
        self.gates = nn.Parameter(torch.zeros(len(self.categories), dtype=torch.float32))

    def config(self) -> dict:
        return {
            "categories": list(self.categories),
            "in_channels": int(self.projection.in_channels),
            "out_channels": int(self.projection.out_channels),
            "upsampling": {
                "mode": "trilinear",
                "align_corners": False,
                "target": "decoder.stages.4 output shape",
            },
            "l2_stage": 3,
            "final_stage": 4,
            "unknown_index": int(self.unknown_index),
        }

    def category_indices(
        self, categories: Iterable[str], device: torch.device | None = None
    ) -> torch.Tensor:
        return torch.tensor(
            [
                self.category_to_index.get(str(category), self.unknown_index)
                for category in categories
            ],
            dtype=torch.long,
            device=device,
        )

    @classmethod
    def from_payload(cls, payload: dict) -> "L2ToFinalResidualSkip3D":
        if payload.get("format_version") != cls.FORMAT_VERSION:
            raise ValueError(
                f"Unsupported L2-final adapter format: {payload.get('format_version')}"
            )
        config = payload["adapter_config"]
        module = cls(
            config["categories"],
            in_channels=int(config["in_channels"]),
            out_channels=int(config["out_channels"]),
        )
        module.load_state_dict(payload["adapter_state"], strict=True)
        return module


class L2ToFinalResidualController:
    """Owns hook state for one complete model forward at a time."""

    def __init__(
        self,
        model: nn.Module,
        adapter: L2ToFinalResidualSkip3D,
    ) -> None:
        self.model = model
        self.adapter = adapter
        self.category_indices: torch.Tensor | None = None
        self.prompt_index = 0
        self.l2: torch.Tensor | None = None
        self.capture_norms = False
        self.norm_records: list[ResidualNormRecord] = []
        if len(model.decoder.stages) < 5:
            raise ValueError("P0-I requires at least five decoder stages")
        # Register the adapter as a model child so model.to(device), parameter
        # enumeration, and checkpoint audits see it.
        model.l2_to_final_residual_skip = adapter
        model._l2_final_residual_controller = self
        self.handles = (
            model.decoder.stages[3].register_forward_hook(self._capture_l2),
            model.decoder.stages[4].register_forward_hook(self._inject_final),
        )

    def set_category_indices(self, value: torch.Tensor) -> None:
        if value.ndim == 1:
            value = value.unsqueeze(0)
        if value.ndim != 2:
            raise ValueError(
                f"L2-final category indices must be [B,P], got {tuple(value.shape)}"
            )
        self.category_indices = value
        self.prompt_index = 0
        self.l2 = None
        self.norm_records = []

    def set_categories(self, categories: list[str], device: torch.device) -> None:
        self.set_category_indices(
            self.adapter.category_indices(categories, device=device).unsqueeze(0)
        )

    def _capture_l2(
        self, _module: nn.Module, _inputs: tuple[torch.Tensor, ...], output: torch.Tensor
    ) -> None:
        self.l2 = output

    def _inject_final(
        self, _module: nn.Module, _inputs: tuple[torch.Tensor, ...], output: torch.Tensor
    ) -> torch.Tensor:
        if self.category_indices is None:
            raise RuntimeError("L2-final category indices were not set before forward")
        if self.l2 is None:
            raise RuntimeError("decoder.stages.4 ran without a captured stage-3 output")
        if self.prompt_index >= self.category_indices.shape[1]:
            raise RuntimeError("More decoder prompts than configured category indices")
        indices = self.category_indices[:, self.prompt_index].to(
            device=output.device, dtype=torch.long
        )
        if indices.shape[0] != output.shape[0]:
            raise ValueError(
                f"Category batch {indices.shape[0]} != decoder batch {output.shape[0]}"
            )
        upsampled = F.interpolate(
            self.l2,
            size=tuple(output.shape[2:]),
            mode="trilinear",
            align_corners=False,
        )
        projected = self.adapter.projection(upsampled)
        gate = self.adapter.gates[indices].to(dtype=output.dtype)
        gate_view = gate.view(-1, 1, 1, 1, 1)
        residual = gate_view * projected
        candidate = output + residual
        # Exact zero-gate endpoint with the derivative of the residual path.
        exact = torch.where(gate_view == 0, output, candidate)
        result = candidate + (exact - candidate).detach()
        if self.capture_norms:
            with torch.no_grad():
                projected_f = projected.float().flatten(1)
                residual_f = residual.float().flatten(1)
                output_f = output.float().flatten(1)
                for batch_index in range(output.shape[0]):
                    projected_norm = float(projected_f[batch_index].norm())
                    residual_norm = float(residual_f[batch_index].norm())
                    final_norm = float(output_f[batch_index].norm())
                    self.norm_records.append(
                        ResidualNormRecord(
                            category_index=int(indices[batch_index]),
                            projected_l2_norm=projected_norm,
                            gated_residual_norm=residual_norm,
                            original_final_norm=final_norm,
                            residual_to_final_ratio=(
                                residual_norm / max(final_norm, 1e-12)
                            ),
                        )
                    )
        self.prompt_index += 1
        self.l2 = None
        return result

    def close(self) -> None:
        for handle in self.handles:
            handle.remove()


def install_l2_to_final_residual_skip(
    model: nn.Module, adapter: L2ToFinalResidualSkip3D
) -> L2ToFinalResidualController:
    return L2ToFinalResidualController(model, adapter)
