"""Category-adaptive modules for the frozen single-S3 overnight experiment."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import torch
import torch.nn.functional as F
from torch import nn


def straight_through_unit_clamp(value: torch.Tensor) -> torch.Tensor:
    """Use a bounded forward value while retaining an identity backward path."""
    bounded = value.clamp(0.0, 1.0)
    return value + (bounded - value).detach()


class CategoryContinuousAttentionRouter(nn.Module):
    """One directly optimized [0, 1] interpolation gate per ReX category."""

    FORMAT_VERSION = "voxtell_s3_category_continuous_router.v1"

    def __init__(self, categories: Sequence[str]) -> None:
        super().__init__()
        categories = tuple(map(str, categories))
        if not categories or len(categories) != len(set(categories)):
            raise ValueError("categories must be a non-empty unique sequence")
        self.categories = categories
        self.category_to_index = {
            category: index for index, category in enumerate(categories)
        }
        self.g_raw = nn.Parameter(torch.ones(len(categories), dtype=torch.float32))

    def forward(self, category_indices: torch.Tensor) -> torch.Tensor:
        if category_indices.ndim != 1:
            raise ValueError(
                f"category_indices must be [B], got {tuple(category_indices.shape)}"
            )
        if bool((category_indices < 0).any()) or bool(
            (category_indices >= len(self.categories)).any()
        ):
            raise IndexError("Router category index is out of range")
        return straight_through_unit_clamp(self.g_raw)[category_indices]

    @torch.no_grad()
    def project_(self) -> None:
        self.g_raw.data.clamp_(0.0, 1.0)

    def config(self) -> dict[str, Any]:
        return {"categories": list(self.categories)}

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "CategoryContinuousAttentionRouter":
        if payload.get("format_version") != cls.FORMAT_VERSION:
            raise ValueError("Unsupported category-router checkpoint")
        module = cls(payload["router_config"]["categories"])
        module.load_state_dict(payload["router_state"], strict=True)
        return module


class AttentionConditionedResidualLogitAdapter3D(nn.Module):
    """Small signed residual-logit head conditioned on decoder feature and S3 map."""

    FORMAT_VERSION = "voxtell_s3_target_attention_residual_adapter.v1"

    def __init__(
        self,
        feature_channels: int,
        target_category: str,
        bottleneck_channels: int = 16,
    ) -> None:
        super().__init__()
        if feature_channels < 1 or bottleneck_channels < 1:
            raise ValueError("channel counts must be positive")
        self.feature_channels = int(feature_channels)
        self.target_category = str(target_category)
        self.bottleneck_channels = int(bottleneck_channels)
        # GroupNorm(1, C, affine=False) is stable for batch-size-one 3D patches.
        self.feature_norm = nn.GroupNorm(1, feature_channels, affine=False)
        self.input_projection = nn.Conv3d(
            2 * feature_channels + 1, bottleneck_channels, kernel_size=1
        )
        self.context = nn.Conv3d(
            bottleneck_channels,
            bottleneck_channels,
            kernel_size=3,
            padding=1,
            groups=bottleneck_channels,
        )
        self.output_projection = nn.Conv3d(
            bottleneck_channels, 1, kernel_size=1
        )
        nn.init.zeros_(self.output_projection.weight)
        nn.init.zeros_(self.output_projection.bias)
        self.last_residual: torch.Tensor | None = None

    def forward(
        self,
        feature: torch.Tensor,
        attention: torch.Tensor,
        active_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        if feature.ndim != 5:
            raise ValueError(f"feature must be [B,C,D,H,W], got {tuple(feature.shape)}")
        if feature.shape[1] != self.feature_channels:
            raise ValueError(
                f"feature has {feature.shape[1]} channels, expected {self.feature_channels}"
            )
        if attention.ndim == 6 and attention.shape[1:3] == (1, 1):
            attention = attention[:, 0]
        if attention.ndim != 5 or attention.shape[1] != 1:
            raise ValueError(
                "attention must be [B,1,1,D,H,W] or [B,1,D,H,W], "
                f"got {tuple(attention.shape)}"
            )
        if attention.shape[0] != feature.shape[0]:
            raise ValueError("feature and attention batch dimensions must match")
        if tuple(attention.shape[2:]) != tuple(feature.shape[2:]):
            attention = F.interpolate(
                attention.float(),
                size=feature.shape[2:],
                mode="trilinear",
                align_corners=False,
            ).to(dtype=feature.dtype)
        normalized = self.feature_norm(feature.float()).to(dtype=feature.dtype)
        x = torch.cat((normalized, attention, normalized * attention), dim=1)
        residual = self.output_projection(
            F.gelu(self.context(F.gelu(self.input_projection(x))))
        )
        if active_mask is not None:
            active_mask = active_mask.to(device=residual.device, dtype=residual.dtype)
            if active_mask.shape != (feature.shape[0],):
                raise ValueError(
                    f"active_mask must be [B], got {tuple(active_mask.shape)}"
                )
            residual = residual * active_mask[:, None, None, None, None]
        self.last_residual = residual
        return residual

    def config(self) -> dict[str, Any]:
        return {
            "feature_channels": self.feature_channels,
            "target_category": self.target_category,
            "bottleneck_channels": self.bottleneck_channels,
            "normalization": "GroupNorm(groups=1, affine=False)",
        }

    @classmethod
    def from_payload(
        cls, payload: dict[str, Any]
    ) -> "AttentionConditionedResidualLogitAdapter3D":
        if payload.get("format_version") != cls.FORMAT_VERSION:
            raise ValueError("Unsupported target-attention adapter checkpoint")
        adapter_config = dict(payload["adapter_config"])
        normalization = adapter_config.pop(
            "normalization", "GroupNorm(groups=1, affine=False)"
        )
        if normalization != "GroupNorm(groups=1, affine=False)":
            raise ValueError(
                f"Unsupported target-attention adapter normalization: {normalization}"
            )
        module = cls(**adapter_config)
        module.load_state_dict(payload["adapter_state"], strict=True)
        return module
