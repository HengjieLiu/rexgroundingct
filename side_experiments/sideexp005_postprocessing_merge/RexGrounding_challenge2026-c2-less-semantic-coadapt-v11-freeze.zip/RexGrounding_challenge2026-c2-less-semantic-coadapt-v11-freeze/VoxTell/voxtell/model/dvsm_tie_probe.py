"""Minimal shared-vs-independent two-pass residual logit probe.

This is intentionally a small feasibility module, not a full DVSM
implementation.  It consumes one existing low-resolution image feature and
the prompt embeddings, then predicts a zero-gated residual for the native
VoxTell logits.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn


class DVSMProbeBlock(nn.Module):
    """Pre-norm attention plus FFN, usable for self- or cross-attention."""

    def __init__(self, dim: int, heads: int) -> None:
        super().__init__()
        self.query_norm = nn.LayerNorm(dim)
        self.memory_norm = nn.LayerNorm(dim)
        self.attention = nn.MultiheadAttention(
            dim, heads, dropout=0.0, batch_first=True
        )
        self.ffn_norm = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, 4 * dim),
            nn.GELU(),
            nn.Linear(4 * dim, dim),
        )

    def forward(self, x: torch.Tensor, memory: torch.Tensor) -> torch.Tensor:
        query = self.query_norm(x)
        key_value = self.memory_norm(memory)
        attended, _ = self.attention(
            query, key_value, key_value, need_weights=False
        )
        x = x + attended
        return x + self.ffn(self.ffn_norm(x))


class DVSMTieProbeAdapter(nn.Module):
    """Two-pass context/query adapter with optional block weight tying."""

    VALID_MODES = {"independent", "shared"}

    def __init__(
        self,
        image_channels: int,
        text_dim: int,
        dim: int = 128,
        depth: int = 2,
        heads: int = 4,
        pool_size: int = 12,
        zero_init: bool = True,
    ) -> None:
        super().__init__()
        if dim <= 0 or depth <= 0 or pool_size <= 0:
            raise ValueError("dim, depth, and pool_size must be positive")
        if dim % heads:
            raise ValueError(f"dim={dim} must be divisible by heads={heads}")

        self.dim = int(dim)
        self.depth = int(depth)
        self.pool_size = int(pool_size)
        self.image_projection = nn.Conv3d(image_channels, dim, kernel_size=1)
        self.text_projection = nn.Linear(text_dim, dim)
        self.position_projection = nn.Linear(3, dim, bias=False)
        self.context_blocks = nn.ModuleList(
            DVSMProbeBlock(dim, heads) for _ in range(depth)
        )
        self.query_blocks = nn.ModuleList(
            DVSMProbeBlock(dim, heads) for _ in range(depth)
        )
        self.output_norm = nn.LayerNorm(dim)
        self.output_projection = nn.Linear(dim, 1)
        self.gamma = nn.Parameter(torch.zeros(()) if zero_init else torch.ones(()))

        coordinates = torch.linspace(-1.0, 1.0, pool_size)
        grid = torch.stack(
            torch.meshgrid(coordinates, coordinates, coordinates, indexing="ij"),
            dim=-1,
        ).reshape(1, pool_size**3, 3)
        self.register_buffer("coordinates", grid, persistent=False)

    def _tokens(
        self,
        image_feature: torch.Tensor,
        text_embedding: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        pooled = F.adaptive_avg_pool3d(
            image_feature,
            output_size=(self.pool_size,) * 3,
        )
        context = self.image_projection(pooled).flatten(2).transpose(1, 2)
        position = self.position_projection(
            self.coordinates.to(dtype=context.dtype)
        )
        context = context + position

        if text_embedding.ndim == 4 and text_embedding.shape[2] == 1:
            text_embedding = text_embedding.squeeze(2)
        if text_embedding.ndim != 3:
            raise ValueError(
                "Expected text embeddings [B,P,C] or [B,P,1,C], got "
                f"{tuple(text_embedding.shape)}"
            )
        prompt = self.text_projection(text_embedding)
        query = prompt[:, :, None, :] + position[:, None, :, :]
        return context, query

    def residual_lowres(
        self,
        image_feature: torch.Tensor,
        text_embedding: torch.Tensor,
        mode: str,
    ) -> torch.Tensor:
        if mode not in self.VALID_MODES:
            raise ValueError(f"Unknown DVSM tie probe mode: {mode!r}")
        context, query = self._tokens(image_feature, text_embedding)

        if mode == "shared":
            # The exact same attention/norm/FFN parameters are called in both
            # passes.  The query pass cross-attends to the cached context.
            blocks = self.context_blocks
            for block in blocks:
                context = block(context, context)
            batch, prompts, tokens, channels = query.shape
            query = query.reshape(batch * prompts, tokens, channels)
            memory = context[:, None].expand(-1, prompts, -1, -1).reshape(
                batch * prompts, tokens, channels
            )
            for block in blocks:
                query = block(query, memory)
        else:
            for block in self.context_blocks:
                context = block(context, context)
            batch, prompts, tokens, channels = query.shape
            query = query.reshape(batch * prompts, tokens, channels)
            memory = context[:, None].expand(-1, prompts, -1, -1).reshape(
                batch * prompts, tokens, channels
            )
            for block in self.query_blocks:
                query = block(query, memory)

        residual = self.output_projection(self.output_norm(query))
        residual = residual.reshape(
            batch,
            prompts,
            self.pool_size,
            self.pool_size,
            self.pool_size,
        )
        return residual

    def add_to_logits(
        self,
        logits: torch.Tensor,
        image_feature: torch.Tensor,
        text_embedding: torch.Tensor,
        mode: str,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        residual = self.residual_lowres(image_feature, text_embedding, mode)
        batch, prompts = residual.shape[:2]
        upsampled = F.interpolate(
            residual.reshape(batch * prompts, 1, *residual.shape[2:]),
            size=logits.shape[2:],
            mode="trilinear",
            align_corners=False,
        ).reshape(batch, prompts, *logits.shape[2:])
        correction = self.gamma.to(dtype=upsampled.dtype) * upsampled
        return logits + correction, correction, upsampled

    def trainable_parameter_count(self, mode: str) -> int:
        """Count only parameters used by the selected mode."""
        if mode not in self.VALID_MODES:
            raise ValueError(f"Unknown DVSM tie probe mode: {mode!r}")
        unused_prefix = "query_blocks." if mode == "shared" else None
        return sum(
            parameter.numel()
            for name, parameter in self.named_parameters()
            if unused_prefix is None or not name.startswith(unused_prefix)
        )

    def disable_unused_shared_parameters(self) -> None:
        """Remove the second block list when shared mode uses context blocks twice."""
        self.query_blocks = nn.ModuleList()
