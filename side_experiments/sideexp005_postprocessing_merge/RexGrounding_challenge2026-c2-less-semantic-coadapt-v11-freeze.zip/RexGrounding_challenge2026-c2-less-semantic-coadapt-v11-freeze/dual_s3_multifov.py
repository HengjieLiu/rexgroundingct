"""Coordinate-safe utilities for Dual-S3 / Multi-FOV training.

The repository stores preprocessed arrays in ``(D, H, W)`` order.  These
helpers deliberately keep that order throughout and use PyTorch's 5-D
interpolation API without any axis permutation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np
import torch
import torch.nn.functional as F


@dataclass(frozen=True)
class DualS3Geometry:
    context_start: tuple[int, int, int]
    context_stop: tuple[int, int, int]
    zoom_start: tuple[int, int, int]
    zoom_stop: tuple[int, int, int]
    context_center_twice: tuple[int, int, int]
    zoom_center_twice: tuple[int, int, int]
    central_context_start: tuple[int, int, int]
    central_context_stop: tuple[int, int, int]


def _triple(values: Sequence[int], name: str) -> tuple[int, int, int]:
    result = tuple(int(value) for value in values)
    if len(result) != 3 or any(value <= 0 for value in result):
        raise ValueError(f"{name} must contain three positive integers, got {values}")
    return result


def dual_s3_geometry(
    context_start: Sequence[int],
    context_size: Sequence[int],
    zoom_size: Sequence[int],
) -> DualS3Geometry:
    """Return exact same-center context/zoom bboxes in padded-volume coordinates."""
    start_tuple = tuple(int(value) for value in context_start)
    if len(start_tuple) != 3 or any(value < 0 for value in start_tuple):
        raise ValueError(f"context_start must contain three non-negative integers, got {context_start}")
    start = np.asarray(start_tuple, dtype=np.int64)
    context = np.asarray(_triple(context_size, "context_size"), dtype=np.int64)
    zoom = np.asarray(_triple(zoom_size, "zoom_size"), dtype=np.int64)
    delta = context - zoom
    if np.any(delta < 0):
        raise ValueError(f"zoom_size {tuple(zoom)} must not exceed context_size {tuple(context)}")
    if np.any(delta % 2):
        raise ValueError(
            "context_size - zoom_size must be even on every axis to preserve the exact center"
        )
    local_start = delta // 2
    zoom_start = start + local_start
    context_stop = start + context
    zoom_stop = zoom_start + zoom
    context_center_twice = 2 * start + context
    zoom_center_twice = 2 * zoom_start + zoom
    if not np.array_equal(context_center_twice, zoom_center_twice):
        raise AssertionError("Dual-S3 context and zoom centers differ")
    return DualS3Geometry(
        context_start=tuple(map(int, start)),
        context_stop=tuple(map(int, context_stop)),
        zoom_start=tuple(map(int, zoom_start)),
        zoom_stop=tuple(map(int, zoom_stop)),
        context_center_twice=tuple(map(int, context_center_twice)),
        zoom_center_twice=tuple(map(int, zoom_center_twice)),
        central_context_start=tuple(map(int, local_start)),
        central_context_stop=tuple(map(int, local_start + zoom)),
    )


def extract_native_zoom(
    padded_image: np.ndarray,
    padded_masks: np.ndarray,
    context_start: Sequence[int],
    context_size: Sequence[int],
    zoom_size: Sequence[int],
) -> tuple[np.ndarray, np.ndarray, DualS3Geometry]:
    """Extract zoom directly from the padded original preprocessed volume."""
    if padded_image.ndim != 3 or padded_masks.ndim != 4:
        raise ValueError("Expected image (D,H,W) and masks (P,D,H,W)")
    if tuple(padded_masks.shape[1:]) != tuple(padded_image.shape):
        raise ValueError("Image and masks have different spatial shapes")
    geometry = dual_s3_geometry(context_start, context_size, zoom_size)
    if any(stop > size for stop, size in zip(geometry.zoom_stop, padded_image.shape)):
        raise ValueError(
            f"zoom bbox {geometry.zoom_start}:{geometry.zoom_stop} exceeds {padded_image.shape}"
        )
    slices = tuple(slice(start, stop) for start, stop in zip(geometry.zoom_start, geometry.zoom_stop))
    image = np.ascontiguousarray(padded_image[slices])
    masks = np.ascontiguousarray(padded_masks[(slice(None), *slices)])
    expected = _triple(zoom_size, "zoom_size")
    if image.shape != expected or masks.shape[1:] != expected:
        raise AssertionError(f"Unexpected native zoom shapes: {image.shape}, {masks.shape}")
    return image, masks, geometry


def upsample_native_zoom(
    native_image: np.ndarray | torch.Tensor,
    native_masks: np.ndarray | torch.Tensor,
    output_size: Sequence[int],
) -> tuple[torch.Tensor, torch.Tensor]:
    """Upsample CT trilinearly (align_corners=False) and masks by nearest neighbor."""
    output = _triple(output_size, "output_size")
    image = torch.as_tensor(native_image, dtype=torch.float32)
    masks = torch.as_tensor(native_masks, dtype=torch.float32)
    if image.ndim == 3:
        image = image[None]
    if image.ndim != 4 or image.shape[0] != 1 or masks.ndim != 4:
        raise ValueError("Expected image (1,D,H,W) and masks (P,D,H,W)")
    image_up = F.interpolate(
        image[None], size=output, mode="trilinear", align_corners=False
    )[0]
    masks_up = F.interpolate(masks[None], size=output, mode="nearest")[0]
    if image_up.shape != (1, *output) or masks_up.shape != (masks.shape[0], *output):
        raise AssertionError("Dual-S3 interpolation produced an unexpected shape")
    return image_up.contiguous(), masks_up.contiguous()


def is_focal_category(category: object) -> bool:
    """Use the repository's established category-2 == focal grouping."""
    return str(category or "").lower().startswith("2")


def eligible_zoom_positions(
    roles: Sequence[str],
    categories: Sequence[object],
    context_target_voxels: Sequence[int],
    native_zoom_target_voxels: Sequence[int],
    policy: str,
    min_positive_voxels: int = 1,
) -> list[int]:
    if policy not in {"focal_only", "all_positive"}:
        raise ValueError(f"Unknown Dual-S3 policy: {policy}")
    lengths = {
        len(roles), len(categories), len(context_target_voxels), len(native_zoom_target_voxels)
    }
    if len(lengths) != 1:
        raise ValueError("Dual-S3 prompt metadata lengths do not match")
    result = []
    for index, (role, category, context_count, zoom_count) in enumerate(
        zip(roles, categories, context_target_voxels, native_zoom_target_voxels)
    ):
        positive = "positive" in str(role).lower()
        nonempty = int(context_count) >= min_positive_voxels and int(zoom_count) >= min_positive_voxels
        routed = policy == "all_positive" or is_focal_category(category)
        if positive and nonempty and routed:
            result.append(index)
    return result


def crop_context_probability_to_native_zoom(
    context_probability: torch.Tensor,
    geometry: DualS3Geometry,
) -> torch.Tensor:
    """Crop ``(B,P,D,H,W)`` context probabilities onto the native zoom grid."""
    if context_probability.ndim != 5:
        raise ValueError("context_probability must be (B,P,D,H,W)")
    slices = tuple(
        slice(start, stop)
        for start, stop in zip(geometry.central_context_start, geometry.central_context_stop)
    )
    return context_probability[(slice(None), slice(None), *slices)]


def zoom_probability_to_native(
    zoom_probability: torch.Tensor, zoom_size: Sequence[int]
) -> torch.Tensor:
    if zoom_probability.ndim != 5:
        raise ValueError("zoom_probability must be (B,P,D,H,W)")
    return F.interpolate(
        zoom_probability, size=_triple(zoom_size, "zoom_size"), mode="trilinear", align_corners=False
    )


def foreground_sensitive_consistency_loss(
    context_probability: torch.Tensor,
    detached_zoom_teacher: torch.Tensor,
    native_zoom_target: torch.Tensor,
    foreground_weight: float = 3.0,
    background_weight: float = 1.0,
    eps: float = 1e-6,
) -> torch.Tensor:
    """Balanced foreground/background L1 plus teacher-target soft Dice loss."""
    if context_probability.shape != detached_zoom_teacher.shape:
        raise ValueError("Context and teacher probability shapes differ")
    if native_zoom_target.shape != context_probability.shape:
        raise ValueError("Native zoom target shape differs from consistency tensors")
    if foreground_weight <= 0 or background_weight < 0:
        raise ValueError("Invalid consistency foreground/background weights")
    teacher = detached_zoom_teacher.detach()
    target = native_zoom_target > 0.5
    absolute = (context_probability - teacher).abs()
    fg_count = target.sum().clamp_min(1)
    bg_count = (~target).sum().clamp_min(1)
    fg_l1 = (absolute * target).sum() / fg_count
    bg_l1 = (absolute * (~target)).sum() / bg_count
    weighted_l1 = (
        foreground_weight * fg_l1 + background_weight * bg_l1
    ) / (foreground_weight + background_weight)

    dims = tuple(range(2, context_probability.ndim))
    intersection = (context_probability * teacher).sum(dim=dims)
    denominator = context_probability.sum(dim=dims) + teacher.sum(dim=dims)
    soft_dice_loss = (1.0 - (2.0 * intersection + eps) / (denominator + eps)).mean()
    loss = 0.5 * weighted_l1 + 0.5 * soft_dice_loss
    if not torch.isfinite(loss):
        raise FloatingPointError("Non-finite Dual-S3 consistency loss")
    return loss
