# Coarse-To-Fine VoxTell Prototype

## Purpose

This is an experimental ReXGroundingCT path for:

```text
CT patch + original ReX finding prompt -> low-res coarse mask -> high-res final mask
```

It does not modify the text prompt, does not rewrite findings, and does not depend on TotalSegmentator. The public VoxTell baseline path is left untouched.

## Architecture

```text
CT patch
  |\
  | \-- downsample to 64^3
  |       + Qwen/VoxTell prompt embedding
  |       -> lightweight prompt-conditioned 3D UNet
  |       -> lowres_logits / lowres_prob
  |
  \-- concat CT with upsampled lowres_prob for each prompt
          -> [CT, coarse_up] two-channel high-res input
          -> pretrained high-res VoxTell with expanded first Conv3d
          -> final_logits
```

The high-res branch reuses the original VoxTell model. Because each prompt has a different coarse mask, the wrapper runs the high-res VoxTell branch once per prompt and concatenates the outputs back to `[B, N, ...]`.

Default fusion is paper-like channel concatenation:

```text
fusion_mode = input_concat_2ch
high-res input = concat([CT_highres, coarse_prob_upsampled], dim=1)
```

The first visual `Conv3d` in VoxTell is expanded from one input channel to two:

- original CT channel weights are copied from the pretrained checkpoint
- new coarse-prior channel weights are initialized to zero
- original bias is preserved

This preserves baseline behavior at initialization while allowing training to learn from the coarse prior. The previous `Conv3d(2,1,kernel_size=1)` compression adapter remains available with:

```text
--fusion-mode adapter_2to1
```

## Loss

```text
L_total =
  lambda_final * DiceBCE(final_logits, high_res_gt)
  + lambda_lowres * DiceBCE(lowres_logits, downsampled_gt)
  + lambda_consistency * MSE(downsample(final_prob), lowres_prob)
```

Defaults:

```text
lambda_final = 1.0
lambda_lowres = 0.3
lambda_consistency = 0.0
lowres_size = 64
fusion_mode = input_concat_2ch
```

The final loss reuses the same deep-supervision Dice + BCE style as the current ReX fine-tuning script.

## Main Files

- `VoxTell/voxtell/model/voxtell_coarse_to_fine.py`
- `scripts/train_voxtell_coarse_to_fine.py`
- `scripts/infer_voxtell_coarse_to_fine.py`
- `scripts/evaluate_coarse_to_fine.py`
- `scripts/debug_coarse_to_fine_shapes.py`

## Debug Shape Test

```bash
python scripts/debug_coarse_to_fine_shapes.py \
  --data-mode preprocessed \
  --preprocessed-dir data/rex_voxtell_preprocessed_v1 \
  --model-dir VoxTell/voxtell_v1.1 \
  --highres-init-checkpoint outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500/checkpoints/checkpoint_step_2000.pth \
  --overfit-n 2 \
  --lowres-size 64 \
  --device cuda \
  --gpu 0
```

This prints image/text/target/logit shapes, verifies finite output/loss, runs one backward pass, and writes:

```text
outputs/coarse_to_fine_debug/debug_overlay_prompt0.png
```

## Tiny Overfit Training

```bash
python scripts/train_voxtell_coarse_to_fine.py \
  --data-mode preprocessed \
  --preprocessed-dir data/rex_voxtell_preprocessed_v1 \
  --model-dir VoxTell/voxtell_v1.1 \
  --highres-init-checkpoint outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500/checkpoints/checkpoint_step_2000.pth \
  --output-dir outputs/voxtell_rex_coarse_to_fine_overfit2 \
  --overfit-n 2 \
  --steps 20 \
  --val-every 5 \
  --save-every 10 \
  --positive-prompts 2 \
  --negative-prompts 1 \
  --lowres-size 64 \
  --fusion-mode input_concat_2ch \
  --lambda-lowres 0.3 \
  --train-mode full \
  --device cuda \
  --gpu 0
```

For DDP:

```bash
torchrun --nproc_per_node 3 scripts/train_voxtell_coarse_to_fine.py \
  --data-mode preprocessed \
  --preprocessed-dir data/rex_voxtell_preprocessed_v1 \
  --model-dir VoxTell/voxtell_v1.1 \
  --highres-init-checkpoint outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500/checkpoints/checkpoint_step_2000.pth \
  --output-dir outputs/voxtell_rex_coarse_to_fine_smoke \
  --max-train-cases 200 \
  --max-val-cases 50 \
  --steps 100 \
  --val-every 25 \
  --save-every 50 \
  --positive-prompts 2 \
  --negative-prompts 1 \
  --lowres-size 64 \
  --fusion-mode input_concat_2ch \
  --lambda-lowres 0.3 \
  --train-mode full \
  --device cuda
```

## Inference

```bash
python scripts/infer_voxtell_coarse_to_fine.py \
  --checkpoint outputs/voxtell_rex_coarse_to_fine_smoke/checkpoints/checkpoint_best_val_dice.pth \
  --model-dir VoxTell/voxtell_v1.1 \
  --splits val \
  --image-dir data/ct_rate_volumes_fixed \
  --reference-mask-dir data/segmentations \
  --output-dir outputs/voxtell_rex_coarse_to_fine_smoke/fullvol_val \
  --limit 2 \
  --lowres-size 64 \
  --fusion-mode input_concat_2ch \
  --device cuda \
  --gpu 0
```

Outputs:

```text
outputs/.../fullvol_val/final/<case>.nii.gz
outputs/.../fullvol_val/coarse_up/<case>.nii.gz
```

## Evaluation

```bash
python scripts/evaluate_coarse_to_fine.py \
  --splits val \
  --gt-dir data/segmentations \
  --pred-dir outputs/voxtell_rex_coarse_to_fine_smoke/fullvol_val/final \
  --coarse-dir outputs/voxtell_rex_coarse_to_fine_smoke/fullvol_val/coarse_up \
  --baseline-pred-dir outputs/threshold_sweeps/hardneg_weightedbce_r10_step1000_thr0p7_fullvol_val_predictions \
  --out-dir outputs/voxtell_rex_coarse_to_fine_smoke/eval
```

Key metrics are Dice, hit rate, FP voxels, and prediction/GT volume ratio.

## Current Limitations

- Full-volume inference currently computes the coarse mask per sliding-window patch. The ideal version should compute a whole-volume coarse mask once per case and crop the aligned coarse channel for each high-res tile.
- The low-res branch is intentionally lightweight and new; it is not initialized from VoxTell.
- Checkpoints from this experiment are not directly loadable by the original VoxTell inference script. Use `scripts/infer_voxtell_coarse_to_fine.py`.
- TotalSegmentator/lobe priors are not included in this experiment; they can be added later as extra spatial channels.
