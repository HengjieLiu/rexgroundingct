# medcomposeCT experiment

`medcomposeCT experiment` is the canonical name for the focused full-validation
follow-up of the completed normal-VoxTell category-embedding pilot.

The experiment is evaluation-only. It must not modify or retrain the model,
continue training, sweep learning rates, or expand into an unrestricted set of
models. It evaluates exactly the step-3800 baseline and category adapters at
updates 50, 100, and 200 on three established metadata cohorts:

- category code exactly `2a`;
- category code exactly `2c`;
- diffuse/non-focal findings, using the existing rule that category codes
  beginning with `1` are diffuse/non-focal.

The released validation source cohort is 200 cases / 381 findings. The focused
union is 181 findings across 123 cases: 69 category-2a, 60 category-2c, and 52
diffuse findings. Finding sets are disjoint. Case overlaps are recorded in the
union manifest.

Canonical output:

```text
outputs/category_embedding_normal_voxtell_step3800_pilot/focused_fullval_followup/
```

Preparation and launch:

```bash
source ./miniconda3/etc/profile.d/conda.sh
conda activate voxtell
python scripts/prepare_medcomposect_followup.py
sbatch scripts/evaluate_medcomposect_focused_followup_4gpu.sbatch
```

The inference runner receives only target prompts and restores their predictions
to the original ReX finding-channel indices before using the existing global-only
evaluator. This preserves canonical IDs and avoids duplicate volume inference.
