# Zoom-In Inference Stage 1

## Experiment identity and status

- Canonical name: **Zoom-In Inference Stage 1**
- Short aliases: `zoom-in stage 1`, `two-stage zoom96`
- Status: **implemented; smoke passed; formal run 5247526 launched**
- Recorded: 2026-07-21
- Model family: Dual-S3 / Multi-FOV S3 (not Presence V1 or HNT)

This name refers specifically to the simple two-stage inference experiment
defined below. Later zoom-in experiments must use a different stage number and
must not silently add more elaborate proposal or fusion logic to Stage 1.

## Motivation and fixed prior evidence

Dual-S3 update-2000 produced the following paired evidence:

- Oracle-localized tiny findings (`GT <100` voxels): context Dice `0.4392`,
  native-96 zoom Dice `0.5713`, delta `+0.1321`.
- Dense full-volume native-96 zoom: tiny Dice `0.2081 -> 0.1711`; all-finding
  Dice on the selected cases `0.2434 -> 0.1631`.

Interpretation: native-96 zoom contains useful information after correct
localization, but it must not replace native-192 context inference globally.

## Stage 0: resolve the exact checkpoint and pipeline

Before a formal run:

1. Select the best **completed** Dual-S3 checkpoint using native-192
   context-only full-volume validation, not oracle zoom performance.
2. Record the exact standard full-volume command, threshold, and
   postprocessing.
3. Check whether full-volume logits or sigmoid probabilities from that exact
   checkpoint already exist.
4. Reuse the crop, interpolation, padding, and coordinate-restoration
   conventions validated by the prior zoom96 experiments.
5. Report the selected checkpoint before launching the formal experiment.

At formal launch, update-2000 remained the only Dual-S3 checkpoint with a
complete 200-case context-only evaluation; update-2500 existed but had not been
evaluated. The selected checkpoint and validation evidence are recorded in
`outputs/dual_s3_two_stage_zoom96/selected_checkpoint.json`.

## Launch record

- Two-case tiny/diffuse smoke: Slurm job `5247522`, completed successfully.
- Smoke probability reproduction: exact for both cases against the completed
  update-2000 native192 baseline.
- Formal 200-case two-GPU run: Slurm job `5247526`, launched 2026-07-21.
- Formal launcher: `scripts/run_zoom_in_stage1_formal_2gpu.sbatch`.

## Stage 1: native-192 context probability generation

Run the selected checkpoint once using exact native-192 full-volume
context-only inference. Reuse existing probabilities only if their provenance
and geometry can be verified exactly.

If probabilities must be generated, add an inference option that:

- saves foreground sigmoid probabilities before thresholding;
- uses float16 or another sufficiently accurate compressed format;
- preserves preprocessed-volume shape and geometry;
- stores case ID, finding ID, and prompt metadata;
- verifies that applying the existing final threshold exactly reproduces the
  current binary baseline;
- avoids rerunning context inference for each proposal threshold.

This probability-generation pass is the `Stage 1` context pass inside the
overall experiment named **Zoom-In Inference Stage 1**.

## Stage 2A: offline proposal threshold audit

Sweep proposal thresholds:

`0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40`

For each finding and threshold:

1. Set `candidate_mask = context_probability >= proposal_threshold`.
2. Extract 3D connected components with 26-connectivity.
3. Initially retain every non-empty component, including one-voxel components,
   and record component size.
4. Center one native `96^3` proposal ROI on the maximum-probability voxel in
   each component. Do not use GT or the component centroid.
5. Apply the established volume-boundary padding convention.
6. If a component bounding box exceeds 96 voxels on any axis, mark it as a
   large proposal. Do not force it into one zoom crop; retain native-192 output
   there and include it in proposal statistics.

For each threshold, report:

- finding-level ROI recall: at least one ROI overlaps GT;
- GT-centroid coverage;
- fraction of GT voxels covered by the union of proposal ROIs;
- mean/median ROI count per finding;
- mean/median union ROI volume as a fraction of full-volume size;
- findings with no candidates;
- large-proposal count;
- component-size distribution.

Stratify by all findings, focal/diffuse, tiny `<100`, existing
small/medium/large bins, and category where metadata permits.

### Predeclared proposal-threshold selection

1. Find maximum finding-level ROI recall across the sweep.
2. Keep thresholds within one percentage point of that maximum.
3. Select the highest remaining threshold.
4. If tied, choose lower union ROI-volume coverage.
5. Select before zoom inference and never use final two-stage Dice to choose.

The complete recall/cost table must be preserved.

## Stage 2B: local native-96 zoom inference

For each selected candidate ROI:

1. Crop native `96x96x96` from the original preprocessed CT, not from a
   previously resampled context tensor.
2. Upsample CT to `192x192x192` using trilinear interpolation with the exact
   Dual-S3 convention (`align_corners=False` unless Stage 0 finds a documented
   change).
3. Run the same selected checkpoint and finding prompt.
4. Convert foreground output to sigmoid probability.
5. Map probability back to native `96^3` with the validated inverse transform.
6. Insert it at the exact full-volume coordinates.

For overlapping zoom ROIs, use one full-volume zoom-probability canvas and
voxelwise maximum, with a separate valid-zoom coverage mask. Never average
overlapping zoom predictions.

Keep proposal and final segmentation thresholds separate. Use the same final
threshold and postprocessing as the native-192 baseline.

## Exactly three evaluated outputs

1. **Baseline:** native-192 context probability.
2. **ROI replacement:** zoom probability inside valid zoom coverage; context
   probability elsewhere.
3. **Baseline-preserving max fusion:** `max(context, zoom)` inside valid zoom
   coverage; context probability elsewhere.

## Explicit Stage-1 exclusions

Do not add any of the following to this experiment:

- dense full-volume native-96 replacement;
- top-K peak detection;
- local-maximum NMS;
- variance gating;
- learned gating;
- crop-offset ensembling;
- global context/zoom averaging.

## Primary evaluation

At the unchanged final threshold, report for all three outputs:

- mean Dice per finding and hit count;
- improved/tied/worsened findings;
- tiny `<100`, existing size bins, focal/diffuse, and category results;
- newly recovered baseline misses and lost baseline hits;
- predicted-volume changes;
- paired bootstrap 95% confidence intervals for Dice delta;
- candidate ROI recall, mean ROI count, and ROI volume coverage;
- separate Stage-1 context and Stage-2 zoom runtimes.

For tiny findings, directly compare to the prior oracle-localized result to
quantify the remaining localization gap.

## Required smoke tests

Before the formal run:

1. Saved context probabilities threshold back to the existing binary baseline
   exactly.
2. At least one tiny finding passes the complete proposal/crop/map-back path.
3. At least one diffuse finding passes the same path.

Use exactly two GPUs for model inference and modest CPU resources.

## Required output layout

```text
outputs/dual_s3_two_stage_zoom96/
  context_probabilities/
  threshold_audit/
  selected_threshold/
  zoom_predictions/
  paired_comparison/
  visualizations/
  REPORT.md
```

Required files include:

- `threshold_audit.csv`
- `threshold_summary.json`
- `selected_threshold.json`
- `per_candidate.csv`
- `paired_per_finding.csv`
- `summary.json`
- `REPORT.md`

Visualizations must cover a successful rescue, replacement degradation of a
baseline hit, max-fusion preservation, a missed proposal, a low-threshold large
component, and best/worst Dice changes.
