# Zoom-Out Training

Canonical experiment name: **Zoom-Out Training**.

Status: implemented, smoke-tested, and formally submitted (2026-07-21).

## Scientific intervention

The matched control retains the existing single native `192^3` crop. The intervention makes one FOV decision per shared image patch: eligible samples use a native `256^3` crop with probability `0.5`, then resize it to the unchanged `192^3` VoxTell input. Image interpolation is trilinear with `align_corners=False`; masks use nearest-neighbor interpolation. There is one model forward, no 96^3 zoom-in branch, no consistency loss, no auxiliary branch, and no change in prompt count.

Eligibility is `diffuse OR large`:

- focal: existing `is_focal_category`, i.e. category `2*`
- diffuse: non-focal category, currently category `1*`
- tiny: GT voxels `<100`
- small: `100–999`
- medium: `1,000–9,999`
- large: `>=10,000`

For same-prompt-empty patches, B is the positive finding that causes the crop and therefore controls FOV routing. For anchor-positive and enforced dual-positive patches, A controls routing. All prompts sharing the image tensor use that one crop.

## Common starting state

Both jobs use exactly:

`outputs/dual_s3_multifov/from_s3_step6000_update1500_focal96_bf16_2h100_to_update6500/checkpoints/checkpoint_update_2000.pth`

- checkpoint micro-step: `10000`
- optimizer update: `2000`
- native-192 context-only full-volume Dice/finding: `0.2742377446`
- hits: `261`
- resume mode: true network + optimizer resume; S3 has no Dual-S3-only parameters, so disabling the second view does not change optimizer compatibility
- current stored optimizer LRs at the checkpoint: encoder `2.6267264e-8`, decoder `2.6267264e-7`, S3 `2.6267264e-5`
- scheduler continuation: origin micro-step `6000`, polynomial horizon `40000` micro-steps, LR floor `0.10` of continuation base LR

The selected state is the best completed checkpoint for which native-192 context-only full-volume validation is available. A later update-2500 file exists but has no matching completed full-volume result and is therefore not used.

## Matched training configuration

- sampler: `anchor85_hardneg70`; anchor-positive `0.85`, same-case-empty `0.15`, semantic hard-negative probability `0.70`
- prompt construction: two same-case prompt records plus one real cross-case negative; prompt count unchanged
- segmentation: category-adaptive Tversky, weight `1.0`, `configs/category_adaptive_tversky/anchor85_step3800_category_map.json`
- S3: scales `1/4 1/2 1/1`, rho `0.25`, hidden channels `128`, weak-diffuse/category gamma config `configs/s3_category_gamma_weakdiffuse_1a_to_1d_plus_2b2c.json`
- S3 localization weight `0.05`, hard-background weight `0.02`, wrong-prompt weight `0`
- optimizer: SGD, Nesterov, momentum `0.99`; true optimizer state resume
- nominal CLI LRs: encoder `1e-7`, decoder `1e-6`, S3 `1e-4`; true stored LRs above take precedence on resume
- BF16 AMP
- two GPUs, gradient accumulation `8`, effective batch size `16`
- seed `2026`
- exactly `5000` additional micro-steps, from micro-step `10000` to `15000`
- gradient accumulation `8` gives `625` additional optimizer updates, from update `2000` to `2625`
- no patch or full-volume validation during training; full-volume evaluation is deferred until both training jobs finish
- checkpoints at update `2500` and final update `2625`

## Paths

- crop audit: `outputs/zoom_out_256_matched/crop_smoke/`
- 2-GPU smoke: `outputs/zoom_out_256_matched/train_smoke/`
- common starting summaries: `outputs/zoom_out_256_matched/starting_checkpoint/`
- control: `outputs/zoom_out_256_matched/control_192_only_5000microsteps/control_from_duals3_step10000_native192_zoomoutp0_add5000microsteps/`
- zoom-out: `outputs/zoom_out_256_matched/zoomout_256mix_5000microsteps/zoomout_from_duals3_step10000_native256_to192_p0.5_add5000microsteps/`
- deferred validation inference: `outputs/zoom_out_256_matched/fullvol_evaluation/`
- final paired analysis: `outputs/zoom_out_256_matched/comparison/`
- common formal driver: `scripts/run_zoom_out_matched_5000updates.sh`
- control submission: `scripts/train_zoom_out_control_5000updates_2gpu.sbatch`
- zoom-out submission: `scripts/train_zoom_out_256mix_5000updates_2gpu.sbatch`

Formal submission was gated on, and followed, the passing crop and sequential 2-GPU training smokes.

## Submission record

- crop/interpolation smoke: PASS; five representative cohorts; all positives survived downsampling; random anchor offsets confirm crops are not forced to center
- focused regression tests: `13 passed` across Zoom-Out, Anchor85, and Dual-S3 tests; final Zoom-Out rerun `3 passed`
- 2-GPU training smoke: job `5247543`, COMPLETED exit `0:0` in `00:36:48` on 2×A100-80GB (H200/H100 were unavailable as a two-card single-node allocation; L40S is insufficient for the measured ~53 GiB/rank peak)
- Zoom-Out smoke: exactly 20 updates to update `2020`; finite losses/gradients; checkpoint reload at `2010`; eligible `52.5%` of items, native-256 used `25.0%` of all items, six safe fallbacks
- control smoke: exactly 10 updates to update `2010`; finite losses/gradients; checkpoint reload at `2005`; native-256 use `0`
- superseded H200 submissions: control job `5247690` and Zoom-Out job `5247691`; both canceled while still pending with zero runtime after the experiment was corrected to 5000 micro-steps and validation was deferred
- active formal control: job `5247716`, requested 2×A100-80GB + 4 CPUs + 160GB, 16-hour limit
- active formal Zoom-Out: job `5247717`, requested 2×H100 + 4 CPUs + 160GB, 12-hour limit
- active formal logs: `logs/zoom_out_control_a100_5kms_5247716.log`, `logs/zoom_out_256mix_h100_5kms_5247717.log`
- active formal errors: `errors/zoom_out_control_a100_5kms_5247716.err`, `errors/zoom_out_256mix_h100_5kms_5247717.err`
