# Matched-Control High-LR Continuation

Status: running as Slurm job `5251656` on 2×H100 (`esplhpc-cp088`), submitted 2026-07-22.

## Resume and target

- resume checkpoint: `outputs/zoom_out_256_matched/control_192_only_5000microsteps/control_from_duals3_step10000_native192_zoomoutp0_add5000microsteps/checkpoints/checkpoint_update_2625.pth`
- start: micro-step `15000`, optimizer update `2625`
- target: exactly 5000 additional micro-steps, ending at micro-step `20000`, optimizer update `3250`
- two GPUs, gradient accumulation `8`, effective batch `16`
- restored network and SGD optimizer/momentum; optimizer is not reset
- seed `2027` because the checkpoint format does not store RNG state and reusing `2026` would repeat the prior continuation's sampling sequence
- no patch validation or full-volume validation during training

## Explicit restored-LR override

- encoder: `1e-6`
- decoder: `1e-5`
- S3 attention: `1e-5`
- new polynomial-continuation origin: micro-step `15000`
- continuation horizon: `40000` micro-steps
- polynomial power: `0.9`
- LR floor: `0.10`
- expected final LRs at micro-step `20000`: approximately `8.87e-7`, `8.87e-6`, `8.87e-6`

The first recorded values at micro-step `15001` were `9.999775e-7`, `9.999775e-6`, and `9.999775e-6`. The first optimizer update at micro-step `15008` had finite loss `0.356868`, finite gradient norm `3.873585`, and peak allocation about `53.02 GiB` per rank.

## Paths

- driver: `scripts/run_matched_control_highlr_continue_5000microsteps.sh`
- submission: `scripts/train_matched_control_highlr_continue_2h100.sbatch`
- output: `outputs/zoom_out_256_matched/control_highlr_continue_5000microsteps/control_from_step15000_e1e-6_d1e-5_s3e1e-5_add5000microsteps/`
- log: `logs/matched_control_highlr_5kms_5251656.log`
- error log: `errors/matched_control_highlr_5kms_5251656.err`
