# VoxTell ReX Anchor85 Loss Ablation

## Anchor85 Control Configuration

Completed matched control:

- Primary output: `outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000`
- Initial checkpoint for the matched 4xL40S control: `outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500/checkpoints/checkpoint_step_2000.pth`
- Control run log: `logs/rex_anchor_l40s_5208022.log`
- Resume-to-finish log: `logs/rex_anchor_l40s_5208455.log`
- Saved args: `outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000/args.json`

Matched settings recovered from the control:

| Setting | Value |
| --- | --- |
| Training script | `scripts/train_voxtell_rex_full_nnunet_aug.py` |
| Sbatch template | `scripts/run_voxtell_rex_anchor85_samecase15_4l40s.sbatch` via `run_voxtell_rex_anchor85_samecase15_3h200.sbatch` |
| Data mode | `preprocessed` |
| Preprocessed dir | `data/rex_voxtell_preprocessed_v1` |
| Train/val split | `train` / `val` |
| Max val cases | `200` |
| Training mode | `full` |
| GPUs | `4 x L40S` for the completed matched control |
| Steps | resume from step `2000`, train to `4000` |
| Save every | `500` |
| Validate every | `100` |
| Validation batches | `50` |
| Patch size | `192 x 192 x 192` |
| Prompt setup | `2` positive + `1` negative |
| Prompt loss weights | positive `1.0`, negative `1.0` |
| Sampler | `anchor85_samecase15` |
| Anchor-positive probability | `0.85` |
| Deliberate same-case-negative probability | `0.15` |
| Prompt order | shuffled |
| Cross-case negatives | source prompt must have non-empty foreground in its source case |
| Empty-target loss | `BCEWithLogits` only |
| Empty-target loss weight | `0.5` |
| Augmentation | disabled (`--no-nnunet-augmentation`, `--no-aug-intensity`, `--no-aug-spatial`) |
| Voxel BCE weighting | enabled |
| Voxel Dice weighting | disabled |
| BCE foreground/boundary/background | `1.0 / 1.5 / 0.5` |
| BCE boundary radius | `10` full-res patch voxels |
| Optimizer | SGD + Nesterov |
| Decoder LR | `1e-6` |
| Encoder LR | `1e-7` |
| Momentum | `0.99` |
| Weight decay | `3e-5` |
| LR schedule | warmup `100` steps, polynomial decay power `0.9` |
| Grad accumulation | `4` |
| AMP | enabled |
| Seed | `2026` |
| Deep supervision | enabled in VoxTell model |

Control full-volume validation references:

- `outputs/voxtell_rex_anchor85_samecase15_step3000_bestpos_fullvol_val_predictions`: mean global Dice per finding `0.266750`, hit rate `0.648294`.
- `outputs/voxtell_rex_anchor85_step3800_bestval_fullvol_val_predictions`: mean global Dice per finding `0.267057`, hit rate `0.650919`.

## Existing Loss Pipeline Audit

- BCE receives logits through `torch.nn.functional.binary_cross_entropy_with_logits`.
- The model returns logits; sigmoid is applied in the loss/metrics, not in the model output.
- Current Dice is soft foreground Dice:
  `1 - (2 * sum(sigmoid(logits) * target) + eps) / (sum(sigmoid(logits)) + sum(target) + eps)`.
- Losses are computed independently per `(image, prompt)` channel, producing tensors of shape `B x P`.
- Crop-level empty targets are detected after target resizing by `scaled_target.reshape(B, P, -1).sum(dim=2) > 0.5`.
- Non-empty prompt loss in the control is `BCE + Dice`.
- Empty prompt loss in anchor85 is `BCE` only, multiplied by `0.5`.
- Prompt aggregation uses `prompt_weights`; all anchor85 prompt weights are `1.0`.
- Deep-supervision outputs are ordered with `scale0` as the final/highest-resolution output.
- Deep-supervision weights are `[1, 1/2, 1/4, 1/8, 0]` normalized to `[0.533333, 0.266667, 0.133333, 0.066667, 0]`.
- Targets are resized to each decoder scale using nearest-neighbor interpolation.

## Implemented Formulas

### Tversky

Source equation: Unified Focal Loss paper Eq. (8), equivalent to Tversky loss paper; Focal Tversky paper Eq. (3) uses the same index with different alpha/beta naming.

Implementation:

```text
TP = sum(p * y)
FP = sum(p * (1 - y))
FN = sum((1 - p) * y)
TI = (TP + eps) / (TP + fp_weight * FP + fn_weight * FN + eps)
L_Tversky = 1 - TI
```

Symbol mapping:

| Paper symbol | Code |
| --- | --- |
| `p` / foreground probability | `torch.sigmoid(logits)` |
| `g` / `y` / foreground target | `target` |
| false-positive coefficient | `fp_weight=0.3` |
| false-negative coefficient | `fn_weight=0.7` |
| `epsilon` | `eps=1e-6` |

### Focal Tversky

Source equation: Abraham & Khan Focal Tversky paper Eq. (4):

```text
L_FT = (1 - TI) ** (1 / gamma)
```

The main experiment uses `convention=original_paper`, `gamma=4/3`. The code also implements `convention=power` for tests:

```text
L_FT_power = (1 - TI) ** gamma
```

Deep supervision for the Focal Tversky ablation:

- `scale0` final/highest-resolution output: `BCEWithLogits + ordinary Tversky`.
- Intermediate outputs: `BCEWithLogits + Focal Tversky`.
- Empty prompt channels: `BCEWithLogits` only, weighted by the control's `0.5`.

### Asymmetric Unified Focal

Source equations: Unified Focal Loss paper Eq. (14) modified asymmetric Focal loss, Eq. (15) modified asymmetric Focal Tversky, Eq. (16) asymmetric Unified Focal.

Foreground is the rare class. For the binary prompt mask adaptation:

```text
maF =
  mean(
    -delta * y * log(p)
    -(1 - delta) * (1 - y) * p ** gamma * log(1 - p)
  )

mTI_fg =
  (TP_fg + eps) / (TP_fg + delta * FN_fg + (1 - delta) * FP_fg + eps)

mTI_bg =
  (TP_bg + eps) / (TP_bg + delta * FN_bg + (1 - delta) * FP_bg + eps)

maFT =
  0.5 * ((1 - mTI_bg) + (1 - mTI_fg) ** (1 - gamma))

aUF =
  lambda * maF + (1 - lambda) * maFT
```

Symbol mapping:

| Paper symbol | Code |
| --- | --- |
| `p_t,r`, rare/foreground probability | `p = sigmoid(logits)` where `y=1` |
| background probability | `1 - p` where `y=0` |
| rare class `r` | ReX finding foreground mask |
| `lambda` | `unified_focal_lambda=0.5` |
| `delta` | `unified_focal_delta=0.6` |
| `gamma` | `unified_focal_gamma=0.5` |
| asymmetric CE term | `asymmetric_focal_ce_per_prompt_from_logits` |
| asymmetric Tversky term | `asymmetric_focal_tversky_per_prompt_from_logits` |

Note: the official Keras code places its `weight` variable on the Focal Tversky term, while the paper Eq. (16) writes `lambda * maF + (1 - lambda) * maFT`. This implementation follows the paper's lambda semantics. The main experiment uses `lambda=0.5`, so the two conventions are numerically equivalent for training.

### Boundary Loss

Source equation: Kervadec et al. boundary loss, implemented for ReX as:

```text
phi_G = distance_transform_edt(~gt) - distance_transform_edt(gt)
L_boundary = mean(sigmoid(logits) * phi_G)
```

Sign convention:

- `phi_G < 0` inside GT.
- `phi_G ~= 0` at the boundary.
- `phi_G > 0` outside GT.

Boundary handling:

- Non-empty prompt targets only.
- Final/highest-resolution output (`scale0`) only.
- Empty prompts receive no boundary loss.
- SDF uses voxel distance with optional max-absolute normalization; current default is normalized SDF because patch spacing is not present in sampler batches.
- Warmup: first `20%` of training linearly ramps from `0` to the selected max weight.
- Max allowed without approval: `0.1`.

## Tests

Test file: `tests/test_rex_loss_ablation.py`

Mandatory checks included:

- Hand-calculated Tversky example.
- FN-heavy loss greater than comparable FP-heavy loss when `fn_weight > fp_weight`, and reversed when weights are swapped.
- Empty GT finite behavior.
- Focal Tversky original-paper and power exponent conventions.
- Unified Focal lambda isolation, focal hard/easy behavior, finite gradients.
- Independent NumPy references for Tversky, Focal Tversky, and Unified Focal on `100` random small tensors with absolute error `< 1e-6`.
- Signed-distance sign and magnitude checks.
- Boundary gradient direction checks.
- Empty/non-empty prompt aggregation and deep-supervision integration.

Pytest output:

```text
6 passed, 5 warnings in 26.76s
```

Saved at: `outputs/loss_debug/loss_correctness_tests.txt`.

## Real-Batch Dry Run

Pending/expected outputs:

- `outputs/loss_debug/real_batch_loss_scale.csv`
- `outputs/loss_debug/real_batch_loss_report.md`

The dry run uses:

- Same anchor85 sampler.
- Same initialization checkpoint.
- Same patch size and prompt setup.
- No optimizer step.
- 20 real batches per loss mode.

## Experiment Scripts

Prepared scripts:

| Experiment | Script | Output |
| --- | --- | --- |
| Focal Tversky | `scripts/run_voxtell_rex_anchor85_loss_focal_tversky_4l40s.sbatch` | `outputs/voxtell_rex_anchor85_loss_focal_tversky` |
| Asymmetric Unified Focal | `scripts/run_voxtell_rex_anchor85_loss_unified_focal_4l40s.sbatch` | `outputs/voxtell_rex_anchor85_loss_unified_focal` |
| Asymmetric Unified Focal + Boundary | `scripts/run_voxtell_rex_anchor85_loss_unified_focal_boundary_4l40s.sbatch` | `outputs/voxtell_rex_anchor85_loss_unified_focal_boundary` |

The Boundary script intentionally refuses to run unless `BOUNDARY_LOSS_MAX_WEIGHT` is set from the real-batch dry run.

## Current Status

- Loss code implemented.
- Unit tests passed.
- Dry-run script prepared.
- Long training scripts prepared but not yet submitted until dry-run passes and Boundary weight is selected.

