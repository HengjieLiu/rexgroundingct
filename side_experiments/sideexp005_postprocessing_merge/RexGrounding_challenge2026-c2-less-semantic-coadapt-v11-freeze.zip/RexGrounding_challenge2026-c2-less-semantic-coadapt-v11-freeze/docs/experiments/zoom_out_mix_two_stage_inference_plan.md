# Zoom-In Inference Stage 2: Zoom-Out Mix

Status: planned, not launched.

This experiment applies proposal-driven native-96 zoom inference to the final
Zoom-Out-mix model. It is named Stage 2 to keep it distinct from the completed
`Zoom-In Inference Stage 1` experiment on Dual-S3 update-2000.

## Scientific question

Does training with mixed native-192 and native-256-to-192 context improve the
quality or calibration of the context probability map enough for local
native-96 zoom inference to help tiny/focal findings without degrading the
full 200-case result?

The selected model is fixed before any two-stage evaluation:

`outputs/zoom_out_256_matched/zoomout_256mix_5000microsteps/zoomout_from_duals3_step10000_native256_to192_p0.5_add5000microsteps/checkpoints/checkpoint_update_2625.pth`

Its standard full-volume context result is also fixed:

- mean Dice/finding: `0.2745761507`
- hits: `261 / 381`
- final segmentation threshold: `0.5`

The primary baseline for two-stage fusion is this same model's context output,
not the starting Dual-S3 checkpoint and not the matched training control.

## Prior failure that the design must address

Stage 1 selected proposal threshold `0.2` without looking at final Dice, but it
still generated a mean of `184.2` native-96 ROIs per finding. Raw replacement
increased mean predicted volume from `112,538` to `443,722` voxels and reduced
mean Dice by `0.0520`. Raw max fusion increased predicted volume to `475,726`
voxels and reduced Dice by `0.0334`.

Therefore Stage 2 must separate two questions:

1. **Exact-transfer branch:** does the new model improve the original Stage-1
   proposal and fusion pipeline under an apples-to-apples protocol?
2. **Safe-fusion branch:** can a bounded proposal budget and support-gated
   zoom additions retain the tiny-lesion signal without the prior FP explosion?

## Phase 0: provenance and context probabilities

1. Create a VoxTell-compatible model directory that resolves exactly to the
   mix `checkpoint_update_2625.pth` and its `plans.json`.
2. Run the same native-192 full-volume inference with original prompts, the
   established S3 category-gamma file, and final threshold `0.5`.
3. Save float16 foreground probabilities with geometry and finding metadata.
4. Verify that thresholding the saved probabilities reproduces all existing
   mix binary masks exactly. Stop if any binary mask differs.

Context inference is performed once and reused for every proposal and fusion
analysis.

## Phase 1: proposal audit

Repeat the Stage-1 proposal-threshold sweep on the mix probabilities:

`0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40`

Use 26-connectivity, retain one-voxel components, place a native `96^3` ROI at
the maximum-probability voxel, and mark components whose bounding box exceeds
96 voxels on any axis as non-zoomable. Proposal selection must not use final
two-stage Dice.

Report all Stage-1 recall/cost measures, with special emphasis on:

- tiny `<100` and small `100–999` findings;
- category `2d` and all focal `2*` findings;
- mean/median proposal count before and after the safe proposal budget;
- GT coverage and missed-proposal causes.

The exact-transfer threshold uses the original Stage-1 rule: choose the
highest threshold within one percentage point of maximum all-finding ROI
recall.

## Phase 2: feasibility gate before full local inference

Run the existing oracle-centered native-96 diagnostic on all tiny findings and
a deterministic sample of small findings using the mix checkpoint. GT is used
only for this diagnostic and never for proposal placement or fusion.

Proceed to full local inference if both conditions hold:

- tiny mean zoom-minus-context Dice is positive;
- at least 25% of tiny findings improve under oracle localization.

If this fails, the mix checkpoint has no usable local-zoom signal and the
proposal-driven experiment stops.

## Phase 3A: exact-transfer branch

For the selected threshold, run the same native-96 crop, trilinear
`96 -> 192` CT transform, model forward, and trilinear `192 -> 96`
probability transform used in Stage 1. Evaluate exactly:

1. mix native-192 context baseline;
2. ROI replacement;
3. baseline-preserving raw probability max.

This branch is diagnostic and preserves comparability with Stage 1. It is not
the expected deployment candidate.

## Phase 3B: bounded proposals for safe fusion

Safe fusion is limited to focal `2*` findings. Diffuse `1*` findings retain the
mix context output because local native-96 inference is poorly matched to
diffuse disease and caused large FP inflation in Stage 1.

For each focal finding:

1. discard non-zoomable components;
2. rank components by peak context probability, breaking ties by component
   size;
3. apply 3D non-maximum suppression with a 48-voxel center distance;
4. keep at most three ROIs per finding.

The cap of three is fixed before final evaluation. The uncapped branch remains
available only for exact-transfer diagnostics.

## Phase 4: support-gated, baseline-preserving fusion

Raw replacement and raw max are not candidates for the final rule. The safe
rule starts from the binary mix context mask and may only add voxels:

1. threshold the local zoom probability at the unchanged final threshold
   `0.5`;
2. retain only the zoom connected component containing the proposal seed, or
   the component containing the zoom maximum if the seed is negative;
3. restrict additions to the proposal component dilated in native coordinates;
4. reject an ROI if the accepted zoom component exceeds a calibrated volume
   cap relative to its proposal component;
5. fuse with binary OR, so no baseline-positive voxel can be removed.

The proposal threshold, dilation radius, and relative volume cap are offline
selection/fusion parameters; no additional model inference is required to test
them once the candidate local predictions have been cached. Candidate values
are:

- proposal threshold: `0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40`;
- dilation radius: `4, 8, 12` native voxels;
- maximum zoom/proposal component volume ratio: `2, 4, 8`;
- optional absolute zoom-component cap: `512, 2048, 8192` voxels.

Select these parameters by deterministic five-fold case-level cross-fitting.
For each held-out fold, tune only on the other four folds and apply the frozen
choice to the held-out cases. Threshold selection inside each training fold
uses the predeclared recall/cost rule and never held-out Dice. This yields one
out-of-fold prediction for all 200 cases and avoids choosing a favorable
proposal threshold or gate on the same findings used for its final score.

## Evaluation and decision criteria

Primary comparison: cross-fitted safe fusion versus the mix model's native-192
context baseline, paired over the same 381 findings.

Report:

- overall Dice/finding, Dice/case, hits, and predicted volume;
- tiny, small, medium, large, focal/diffuse, and per-category results;
- improved/tied/worsened findings and gained/lost hits;
- case-clustered bootstrap 95% confidence intervals;
- proposal recall, crop count, crop coverage, and inference runtime;
- exact-transfer results beside the completed Stage-1 results.

The safe-fusion rule advances only if all conditions hold:

1. no lost baseline hits, verified empirically at finding level; binary OR
   preserves baseline true-positive voxels but can still lower Dice through
   added false-positive voxels;
2. overall mean Dice delta is non-negative and its case-bootstrap lower bound
   is no worse than `-0.001`;
3. tiny mean Dice improves by at least `+0.01` or at least one new tiny hit is
   recovered without a tiny hit loss;
4. mean predicted-volume inflation is at most 5%;
5. mean local-inference budget is at most three ROIs per focal finding.

Matched control update-2625 is analyzed separately. It determines whether
Zoom-Out training itself helped context segmentation, but it is not substituted
for the same-model context baseline in the two-stage fusion comparison.

## Expected outputs

```text
outputs/zoom_out_256_matched/two_stage_zoom96_mix_update2625/
  resolved_config.json
  context_probabilities/
  context_reproduction/
  proposal_audit/
  oracle_feasibility/
  exact_transfer/
  local_zoom_probabilities/
  safe_fusion_crossfit/
  paired_comparison/
  visualizations/
  REPORT.md
```

## Resource estimate

Use exactly two GPUs, preferring H200, then H100, then L40S. Context and local
inference shard cases across GPUs; each rank loads the complete model. Based on
Stage 1, the uncapped exact-transfer branch is the expensive part. The bounded
safe branch reuses the same local predictions and adds only CPU-side fusion and
evaluation.
