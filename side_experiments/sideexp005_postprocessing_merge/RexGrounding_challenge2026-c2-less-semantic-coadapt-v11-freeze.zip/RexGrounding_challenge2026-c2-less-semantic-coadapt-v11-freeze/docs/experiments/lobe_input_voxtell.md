# VoxTell lobe-input comparison

Status snapshot: 2026-07-27.

## Baseline and matched protocol

- Initialization: `outputs/azure_ckpt_sync_stage/s3_allcategory_1over1_step6000/fold_0/checkpoint_final.pth`
- Reference raw validation: Dice `0.3031991044`, HIT `274/381`
- Reference raw + whole-lung 10 mm clipping: Dice `0.3137673095`
- Model: all-category S3, `1/1` full attention
- Patch: `192^3`
- Sampler: `anchor85_hardneg70`
- Prompts: 2 positive + 1 negative, original text, weights 1/1
- Loss: category-adaptive Tversky plus the existing S3 localization objective
- Optimizer: matched SGD configuration, encoder LR `1e-6`, decoder/S3 LR `1e-5`
- Run length/resources: 1000 optimizer updates, 2 GPUs, batch/GPU 1, grad accumulation 1
- Augmentation: off, matching the baseline
- Seed: 2027 for all variants

## Encodings

- `scalar_lobe_input`: CT + `lobe_label.float()/5`; two-input-channel stem.
- `onehot_lobe_input`: CT + labels 1–5 as five one-hot channels; background all zero.
- `embedding_lobe_input`: unchanged CT stem plus `Embedding(6,4)` and a zero-initialized
  1x1x1 projection added to the first encoder feature level.

For scalar/one-hot variants, checkpoint CT stem weights are copied to channel 0,
new anatomy slices are zero, and bias is preserved. The embedding projection is
zero at initialization. Thus all three step-0 paths preserve the baseline output.

## Anatomy-label audit

The aligned label convention is:

`0=background, 1=LUL, 2=LLL, 3=RUL, 4=RML, 5=RLL`.

Existing source-mask coverage found in the workspace:

- validation: 200/200 complete five-lobe TotalSegmentator cases;
- training: 0/2992 complete cases.

Validation conversion job `5297264` completed successfully. All 200 output maps
contain only values 0–5; every value is present in every case; no source-lobe
overlaps were found in newly written cases. Sampled three-plane overlays are in:

`outputs/voxtell_lobe_input_from_allcat1over1_step6000/qc_overlays/`

## Submitted jobs

Formal training jobs are submitted but deliberately held until the training
five-lobe masks are supplied:

- scalar: `5297265`
- one-hot: `5297266`
- embedding: `5297267`

Dependent full-validation jobs:

- scalar: `5297661`
- one-hot: `5297662`
- embedding: `5297663`

Each validation job runs all 200 cases / 381 findings, reports raw threshold 0.5
and whole-lung 10 mm clipped results, and summarizes mean Dice, HIT count,
predicted volume, both requested deltas, and the explicit-lobe subgroup.

## Unblocking

Once a root containing all training and validation TotalSegmentator lobe masks is
available:

```bash
python scripts/prepare_rex_lobe_label_maps.py \
  --prior-dir /path/to/lung_priors \
  --output-dir data/rex_lobe_labels_preprocessed_v1 \
  --splits train val \
  --workers 12 \
  --require-complete

scontrol release 5297265 5297266 5297267
```

Do not release the jobs before the preparation command reports complete coverage.
