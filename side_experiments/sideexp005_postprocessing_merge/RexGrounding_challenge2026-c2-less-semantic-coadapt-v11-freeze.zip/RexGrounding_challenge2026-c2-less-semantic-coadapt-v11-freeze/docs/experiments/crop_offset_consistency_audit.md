# S3 crop-offset consistency audit

This is an inference-only audit. It does not alter training or checkpoint
weights.

## Reused pipeline

- Current full-volume entrypoint: `scripts/run_voxtell_rex_inference.py`
- Model/checkpoint loader and single-window inference:
  `VoxTell/voxtell/inference/predictor.py`
- Preprocessing cache: RAS reader, nonzero crop, z-score normalization from
  `scripts/prepare_rex_voxtell_preprocessed.py`
- Crop boundary convention: symmetric zero-padding only when a volume dimension
  is smaller than the patch, followed by a clamped crop start, matching
  `RexPreprocessedSampler._pad_to_patch` and `_crop`
- Main evaluation threshold/postprocessing: sigmoid threshold 0.5, with no
  connected-component postprocessing in the global-only path

## Audited model

- Config:
  `outputs/s3d_multiscale_2b2c_train_nowrong_from_adaptive_step600/args.json`
- Checkpoint:
  `outputs/s3d_multiscale_2b2c_train_nowrong_from_adaptive_step600/checkpoints/checkpoint_step_400.pth`
- Inference category policy:
  `outputs/s3d_multiscale_2b2c_train_nowrong_from_adaptive_step600/full_volume_step400_globalonly_2b2c/category_gamma.json`
- Existing full-volume validation result: Dice/finding `0.2710225483` at
  threshold 0.5.

## Coordinate and evaluation choices

All offsets are `(D, H, W)` voxels in the cached preprocessed volume. The
deterministic original center is the GT foreground voxel nearest the finding's
GT bounding-box center. This is the reproducible counterpart of the training
sampler's random-foreground-point positive crop and guarantees that the
original crop contains target foreground.

Each probability patch is restored with its valid-coverage mask. Pairwise
metrics use the two crops' coverage intersection. The ensemble uses the sum of
available probabilities divided by the voxelwise coverage count; uncovered
corners of the rectangular union are stored as `NaN`, never as zero.

For a fair fixed-threshold baseline/ensemble comparison, Dice, IoU, and
predicted volume use the intersection of valid coverage across all requested
offsets. Full GT voxel count is also retained separately. The optional
ensemble threshold sweep is labeled as calibration-only.

## Commands

Dry run:

```bash
conda run -n voxtell python scripts/evaluate_crop_offset_consistency.py \
  --dry-run --max-cases 3 --patch-size 192 192 192 \
  --offset-magnitude 12 --offsets axial6_plus_center
```

Three-case smoke through Slurm:

```bash
sbatch --export=ALL,MAX_CASES=3,SAVE_VISUALIZATIONS=1,OUTPUT_DIR=./outputs/crop_offset_audit/s3d_step400_axial6_shift12_smoke3_final \
  scripts/run_crop_offset_audit_full.sbatch
```

Full validation audit:

```bash
sbatch scripts/run_crop_offset_audit_full.sbatch
```

Primary outputs are `per_finding_metrics.csv`, `summary.json`, and
`crop_metadata.jsonl` under the selected output directory. Compact probability
artifacts are under `probabilities/`, and ranked panels are under
`visualizations/`.

## Validated smoke

The final 3-case smoke was Slurm job `5240638` and completed 12 findings. The
zero-offset repeat had max absolute logit difference 0.0. All 12 common
coverage regions contained GT. The fixed-threshold smoke mean Dice was
0.203919 for baseline and 0.205439 for the ensemble; this small subset is a
pipeline check, not an efficacy claim.
