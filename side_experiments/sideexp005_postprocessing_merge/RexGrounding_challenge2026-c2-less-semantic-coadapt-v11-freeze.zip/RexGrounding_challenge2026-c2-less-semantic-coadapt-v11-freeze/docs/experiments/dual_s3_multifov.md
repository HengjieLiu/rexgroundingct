# Dual-S3 / Multi-FOV S3

The planned two-stage candidate-proposal successor is recorded separately as
[`Zoom-In Inference Stage 1`](zoom_in_inference_stage_1.md). That name does not
refer to the completed dense native-96 or oracle-crop diagnostics below.

## Selected baseline

The repository contains a newer full-200 validation result than the earlier
step-400 result (0.271022548 Dice/finding), so this experiment starts from:

- checkpoint: `outputs/s3d_matched_continue_from_weakdiffuse_control_step1000/control_2b2c_multiscale_to_step6000/checkpoints/checkpoint_step_6000.pth`
- full-volume result: 381 findings, Dice/finding 0.274019719, 259 hits,
  hit rate 0.679790026
- model: `VoxTell/voxtell_v1.1`
- sampler: `anchor85_hardneg70`, two positive prompts plus one unchanged
  semantic/cross-case negative, shuffled prompt order
- S3: shared 1/4, 1/2, 1/1 gates; category-gamma policy from
  `configs/s3_category_gamma_weakdiffuse_1a_to_1d_plus_2b2c.json`; supervised
  categories 2b/2c
- losses: category-adaptive Tversky segmentation, S3 localization 0.05,
  hard background 0.02, wrong-prompt 0.0
- saved optimizer: SGD Nesterov, momentum 0.99, weight decay 3e-5; checkpoint
  LRs encoder 2.887995953e-8, decoder 2.887995953e-7, S3 2.887995953e-5

The old trainer called each micro-batch a `step`. With `grad_accum=4`, legacy
checkpoint micro-step 6000 represents 1500 actual optimizer updates. Dual-S3
persists both counters explicitly. On exactly two GPUs it uses `grad_accum=8`,
preserving the baseline effective batch size of 16.

## Design

The context path is unchanged. The zoom source is the central 96x96x96 region
of the same padded original preprocessed `(D,H,W)` volume and has exactly the
same center as the 192x192x192 context bbox. CT uses trilinear interpolation
with `align_corners=False`; masks use nearest interpolation. No axis is
permuted. Network weights and prompt embeddings are shared.

Only crop-nonempty, native-zoom-nonempty positive prompts are eligible.
`focal_only` reuses the established repository grouping `category.startswith("2")`.
All negative prompts and category-1 non-focal/diffuse prompts remain
context-only. Standard patch validation and full-volume inference are also
context-only.

For eligible samples, zoom is forwarded and backpropagated first. Only its
detached native-grid foreground probability remains. Context is then forwarded
and backpropagated. The supervised gradient is exactly

`(L_context + 0.5 * L_zoom) / 1.5`.

The additional 0.05 consistency term is the mean of foreground/background
balanced L1 and soft Dice between the central native context probability and
the detached native-grid zoom teacher. Foreground/background L1 weights are
3/1. There is one optimizer step after both backward calls.

H100 FP16 smoke exposed a finite-loss but non-finite decoder gradient in an
otherwise context-only sample. Dual-S3 therefore explicitly uses H100-native
BF16 and aborts on any non-finite update. The default non-Dual trainer remains
FP16 for backward compatibility.

## Crop smoke

`scripts/debug_dual_s3_crops.py` wrote four inspected examples under
`outputs/dual_s3_smoke/crop_debug`: small focal, medium focal,
non-focal/diffuse large, and a boundary case with symmetric D padding 4+4.
For all four:

- native image/mask equal the exact context `[48:144]^3` source region;
- context and zoom doubled-coordinate centers match;
- nearest upsample/downsample mask round trip is exact;
- foreground remains nonempty and 2x nearest upsampling multiplies voxels by 8;
- prompt and finding ID match;
- overlays show consistent D/H/W orientation without an axis swap.

Unit tests are in `tests/test_dual_s3_multifov.py`.

## Two-GPU smoke and formal run

The smoke script is `scripts/train_dual_s3_smoke_2gpu.sbatch`. It runs ten true
optimizer updates, saves/reloads update 1510, runs ten more, then runs a
one-update Dual-off control. It requests two H100s, four CPUs, 160 GB host RAM,
zero DataLoader workers (manual cached sampler), BF16, and effective batch 16.

The formal script is `scripts/train_dual_s3_multifov_5000updates_2gpu.sbatch`.
It trains in ten exact 500-update chunks, preserving optimizer and LR
continuation state. After each chunk it runs the existing two-rank full-volume
context-only evaluator at threshold 0.5 and writes overall, category,
focal/non-focal, and tiny/small/medium/large tables. The endpoints are optimizer
updates 2000 through 6500, corresponding to micro-steps 10000 through 46000.
There is no early stopping.

The authoritative BF16 smoke was Slurm job 5243656 and passed all 20 Dual-S3
updates, checkpoint reload, and the one-update Dual-off control. Its exact
per-rank peak allocated memory was 53.045/53.047 GiB (reserved
61.266/61.297 GiB), with all losses and gradients finite. Mean wall time was
37.90 seconds per optimizer update.

The effective formal run is Slurm job 5243710, launched 2026-07-20 11:34:20
on `esplhpc-cp089` with exactly two H100s, four CPUs, and 160 GB RAM. Startup
validation confirmed the intended formal output directory, resume at
micro-step 6000 / optimizer update 1500, effective batch 16, and finite first
updates. A prior launch check (5243702) was cancelled before any optimizer
update because the child process did not inherit `OUTPUT_DIR`; its five
micro-batch-only artifacts were moved under `outputs/dual_s3_smoke/aborted_runs`
and are not part of the formal experiment.
