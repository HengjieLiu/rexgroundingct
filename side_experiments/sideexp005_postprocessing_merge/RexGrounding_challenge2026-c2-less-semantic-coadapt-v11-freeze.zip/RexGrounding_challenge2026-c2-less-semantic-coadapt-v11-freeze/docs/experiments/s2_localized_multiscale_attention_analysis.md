# S2 Localized Multiscale Attention Analysis

Date: 2026-07-14

## Scope

This record consolidates the S2 localized multiscale spatial-attention
experiment, including its implementation, training behavior, full-volume
validation, strict attention ON/OFF ablation, localization diagnostic, S1
comparison, and the category-2c phenotype and mask-size analysis.

Two comparisons must be kept separate:

1. `S2 step 1000 attention ON` versus `Anchor85 step 3800` includes both
   continued segmentation fine-tuning and the S2 mechanism.
2. `S2 step 1000 attention ON` versus `S2 step 1000 attention OFF` uses the
   same trained checkpoint and isolates the inference-time effect of S2
   attention more directly.

## Initialization and Training Configuration

The S2 model was initialized from:

```text
outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000/
  checkpoints/checkpoint_best_val_dice_step_3800.pth
```

The optimizer and training step were reset to step zero. The complete saved
configuration is in:

```text
outputs/archived_experiment_records/20260730/result_folder_second_wave/
  s2_localized_multiscale_attention_2c_anchor85_step3800/args.json
```

### S2 Architecture

- Prompt-conditioned attention gates were added at `1/4` and `1/2` spatial
  resolution.
- For a `192 x 192 x 192` patch, these maps have spatial shapes `48^3` and
  `96^3`.
- Each gate combines an encoder skip feature, the corresponding decoder
  feature, and a projected prompt-conditioned transformer query.
- The residual gate is:

```text
gated_skip = skip * ((1 - rho) + rho * attention)
rho = sigmoid(beta)
```

- `beta_init=-1.5`, so the initial `rho=0.1824255`.
- The attention localization objective was an enrichment-margin loss with
  weight `0.02` and margin `0.05`.
- Explicit localization supervision was applied only to non-empty category-2c
  prompts.
- Category 2d and focal categories were disabled by the inference category
  policy.

The category policy used for the primary S2 full-volume run was:

| Attention ON | Attention OFF |
| --- | --- |
| `1a`, `1b`, `1c`, `1d`, `1e` | `1f` |
| `2a`, `2b`, `2c`, `2h` | `2d`, `2e`, `2g` |

Configuration file:

```text
configs/spatial_attention_category_gamma_focaloff_2c_on.json
```

### Matched Fine-Tuning Settings

| Setting | Value |
| --- | --- |
| Data | `data/rex_voxtell_preprocessed_v1` |
| Patch | `192 x 192 x 192` |
| Sampler | `anchor85_samecase15` |
| Prompts | 2 positive + 1 cross-case negative |
| Positive/negative prompt weights | `1.0 / 1.0` |
| Augmentation | none |
| Segmentation loss | deep-supervision Dice + weighted BCE |
| BCE foreground/boundary/background | `1.0 / 1.5 / 0.5` |
| BCE boundary radius | `10` full-resolution voxels |
| Empty-target loss | BCE only, weight `0.5` |
| Decoder/S2 LR | `1e-6` |
| Encoder LR | `1e-7` |
| Optimizer | SGD, Nesterov, momentum `0.99` |
| Gradient accumulation | `4` |
| Training length | `1000` optimizer steps |
| Patch validation | every `100` steps, 50 batches |
| Saved checkpoints | every `500` steps |

## Jobs and Artifacts

| Purpose | Job | Result |
| --- | ---: | --- |
| S2 real `192^3` smoke test | `5220272` | passed |
| S2 training | `5220273` | completed on 4 H200 GPUs |
| Step-500 full-volume validation | `5220274` | completed |
| Step-1000 full-volume validation | `5220275` | completed |
| Initial localization diagnostic | `5220276` | incomplete; selection only |
| Corrected S2 localization diagnostic | `5222441` | completed |
| Step-1000 attention-all-OFF validation | `5222461` | completed |

The smoke test confirmed a real forward, localization loss, segmentation loss,
and backward pass. Only the newly introduced `s2_attention_gates.*` keys were
missing when loading the Anchor85 checkpoint; there were no unexpected keys.

Smoke report:

```text
outputs/s2_localized_multiscale_attention_smoke_test/smoke_test_report.json
```

## Patch-Validation Behavior

| Step | Val Dice | Val Positive Dice | 1/4 Enrichment | 1/2 Enrichment |
| ---: | ---: | ---: | ---: | ---: |
| 0 | 0.4579 | 0.2730 | -0.0102 | +0.0238 |
| 100 | 0.4779 | 0.2159 | -0.0120 | +0.0244 |
| 400 | **0.5539** | 0.2254 | -0.0054 | +0.0244 |
| 600 | 0.4915 | **0.2891** | -0.0193 | +0.0292 |
| 1000 | 0.4941 | 0.2269 | -0.0085 | +0.0309 |

Observations:

- Best patch `val_dice` was at step 400.
- Best patch `val_positive_dice` was at step 600.
- Patch-validation metrics fluctuated substantially and did not select the
  full-volume-evaluated step 1000 checkpoint.
- The learned `rho` remained effectively fixed at `0.1824` at both scales.
- The 1/4 branch had negative validation enrichment at every recorded step.
- The 1/2 branch had a consistently positive but small enrichment of about
  `+0.02` to `+0.03`.
- Direct 2c localization supervision was sparse: only about `0.2-0.3`
  supervised 2c prompts appeared per validation batch.
- Steps 400 and 600 have not received full-volume validation.

Training history:

```text
outputs/archived_experiment_records/20260730/result_folder_second_wave/
  s2_localized_multiscale_attention_2c_anchor85_step3800/history.jsonl
```

## Full-Volume Validation

All runs below use the same 200 validation cases, 381 findings, global-only ReX
evaluation, and a hit threshold of Dice `>=0.1`.

| Configuration | Finding Dice | Case Dice | Hit Rate | Hits |
| --- | ---: | ---: | ---: | ---: |
| Anchor85 step 3800 | 0.267057 | not recorded | 0.650919 | 248/381 |
| S2 step 500, attention ON | 0.268094 | 0.278950 | 0.656168 | 250/381 |
| S2 step 1000, attention ON | **0.268380** | **0.279011** | **0.664042** | **253/381** |
| S2 step 1000, attention all OFF | 0.267769 | 0.278164 | 0.661417 | 252/381 |

### S2 Step 1000 ON Versus Anchor85

- Mean finding Dice: `+0.001323`.
- Five hits were gained and none were lost.
- Numerical changes: 182 findings improved, 177 worsened, and 22 were
  unchanged.
- At `|delta Dice| >=0.02`, 47 improved and 37 worsened.

This comparison includes continued fine-tuning and cannot attribute the full
improvement to attention.

### Strict S2 Attention ON Versus OFF

- Mean finding Dice: `+0.000611`.
- Mean case Dice: `+0.000847`.
- Hit rate: `+0.002625`.
- Three misses became hits, while two hits became misses: net `+1` hit.
- 142 findings improved, 162 worsened, and 77 were unchanged.
- At `|delta Dice| >0.001`, 92 improved, 100 worsened, and 189 were effectively
  unchanged.
- Median per-finding Dice change was zero.

Therefore, most of the S2 checkpoint's gain over Anchor85 came from continued
fine-tuning. Enabling attention at inference contributed only `+0.000611` Dice
and one net hit.

Primary output directories:

```text
outputs/s2_localized_multiscale_attention_2c_step500_fullvol_val_predictions
outputs/s2_localized_multiscale_attention_2c_step1000_fullvol_val_predictions
outputs/s2_localized_multiscale_attention_2c_step1000_attention_alloff_fullvol_val_predictions
```

## S2 Step 1000 ON Versus Anchor85 Subgroup Analysis

### GT Mask Size

| Size | n | Mean Delta Dice | Hit Gain/Loss |
| --- | ---: | ---: | ---: |
| Large, `>=10k` voxels | 145 | +0.00332 | +4 / 0 |
| Medium, `1k-10k` | 99 | +0.00341 | +1 / 0 |
| Small, `100-1k` | 114 | -0.00229 | 0 / 0 |
| Tiny, `<100` | 23 | -0.00232 | 0 / 0 |

### Prompt Keyword

| Keyword group | Mean Delta Dice |
| --- | ---: |
| Emphysema | +0.0081 |
| Effusion | +0.0077 |
| Consolidation/opacity | +0.0045 |
| Atelectasis | +0.0028 |
| Ground glass | +0.0022 |
| Scarring/fibrosis | +0.0018 |
| Nodule | -0.0004 |
| Bronchiectasis | -0.0005 |
| Calcification | -0.0082 |

The combined fine-tuning plus S2 change favored medium/large abnormalities and
diffuse opacity-related findings more than small focal findings.

Detailed paired report:

```text
outputs/analysis_s2_step1000_vs_anchor85_step3800/report.md
```

## Strict ON/OFF Category Effects

These values isolate the inference-time attention effect within the same S2
step-1000 checkpoint.

| Category | Attention ON minus OFF Dice | Hit Effect |
| --- | ---: | --- |
| 1a | -0.00764 | unchanged |
| 1b | -0.00496 | unchanged |
| 1c | +0.00131 | unchanged |
| 1d | +0.00009 | unchanged |
| 1e | -0.00253 | unchanged |
| 2a | -0.00103 | one hit lost |
| 2b | +0.00225 | one hit gained |
| 2c | **+0.00538** | one hit gained |
| 2h | -0.00585 | unchanged |

Categories `1f`, `2d`, `2e`, and `2g` were disabled in the primary ON policy
and were effectively unchanged. The clearest attention benefit was in 2c,
followed by a smaller benefit in 2b. Category 1 did not benefit overall.

## S2 Attention Localization Diagnostic

The corrected diagnostic evaluated the S2 `1/2` attention map on 47 findings
from 42 cases and compared each correct prompt with a shuffled prompt.

| Metric | Result |
| --- | ---: |
| Median correct-prompt enrichment | 1.1459 |
| Median shuffled-prompt enrichment | 1.0562 |
| Median correct minus shuffled | +0.0373 |
| Correct prompt better than shuffled | 35/47, 74.5% |
| One-sided sign-test p-value | 0.000544 |
| Pointing accuracy | 0% |
| Median GT-sized top-k precision | 0 |
| Median peak-to-GT distance | 246.9 voxels |
| Median voxel AUROC | 0.787 |
| Median voxel AUPRC | 0.00037 |
| Correct/shuffled map correlation | 0.883 |
| Enrichment versus Dice Spearman correlation | 0.130 |

The diagnostic shows statistically significant prompt specificity, but not
precise lesion localization. Attention peaks never fell inside the GT, GT-sized
top-k precision was effectively zero, and correct/shuffled maps remained highly
correlated. S2 attention is best interpreted as a broad anatomical bias with a
weak prompt-dependent modulation.

Diagnostic outputs:

```text
outputs/s2_step1000_attention_localization_diagnostic_v2/report.md
outputs/s2_step1000_attention_localization_diagnostic_v2/summary.json
outputs/s2_step1000_attention_localization_diagnostic_v2/attention_localization_per_finding.csv
outputs/s2_step1000_attention_localization_diagnostic_v2/attention_localization_by_category.csv
```

The earlier `outputs/s2_step1000_attention_localization_diagnostic` directory
is incomplete and contains only the selected-finding list; it must not be used
as the final diagnostic result.

## Localization by Category

### Category 2c

- Eight diagnostic examples were selected.
- Correct-prompt enrichment exceeded shuffled-prompt enrichment in all 8/8.
- Median correct-minus-shuffled enrichment was `+0.117`.
- Pointing accuracy was still zero.

Thus, 2c had the strongest prompt-specific signal, but its attention remained
spatially broad rather than lesion precise.

### Category 2d

- Eight diagnostic examples were selected.
- Median correct enrichment was `0.829`, below the uniform-map expectation of
  `1.0`.
- Median voxel AUROC was approximately `0.240`.
- Pointing accuracy was zero.

This supports disabling S2 attention for small nodule-dominated category 2d.

### Category 1

- The diagnostic included 18 findings, three from each category `1a-1f`.
- Mean segmentation Dice was `0.159`, but median Dice was only `0.026`.
- Correct attention beat shuffled attention in 11/18, or 61%.
- Median correct enrichment was `1.170`; shuffled enrichment was `1.089`.
- Pointing accuracy was zero.
- Correct/shuffled map correlation was `0.900`.
- Categories 1b and 1c had the clearest prompt specificity.
- Categories 1a and 1e had negative correct-minus-shuffled enrichment.
- Full-volume ON/OFF evaluation showed that attention harmed 1a, 1b, and 1e.

## Category-2c Phenotype and Mask-Size Analysis

This section uses the strict S2 step-1000 attention ON/OFF comparison and is
therefore the most direct analysis of whether attention itself helps a 2c
finding. Phenotype tags overlap and should be treated as exploratory rather
than mutually exclusive disease classes.

### Prompt Phenotype

| 2c phenotype tag | n | Mean ON-OFF Dice | Median | Improved/Worsened |
| --- | ---: | ---: | ---: | ---: |
| Diffuse/bilateral/multifocal | 23 | **+0.0153** | +0.0106 | 15 / 8 |
| Focal/nodular/subcentimeter | 17 | **-0.0109** | -0.0101 | 8 / 9 |
| Peripheral/subpleural | 18 | **+0.0145** | +0.0095 | 10 / 8 |
| Patchy | 11 | +0.0087 | -0.0038 | 5 / 6 |
| Crazy-paving/septal thickening | 5 | +0.0382 | +0.0025 | 4 / 1 |
| Consolidation-associated | 3 | +0.0010 | -0.0020 | 1 / 2 |

### GT Mask Size Within 2c

| GT mask size | n | Mean ON-OFF Dice | Median | Improved/Worsened |
| --- | ---: | ---: | ---: | ---: |
| Large, `>=10k` voxels | 40 | **+0.0141** | +0.0139 | 28 / 12 |
| Medium, `1k-10k` | 16 | **-0.0087** | -0.0060 | 4 / 12 |
| Small, `100-1k` | 4 | **-0.0255** | -0.0128 | 1 / 3 |

The strongest and most stable 2c pattern is mask extent: S2 attention tends to
help large, spatially extensive abnormalities and harm medium/small focal or
nodular abnormalities. This is consistent with a broad regional attention map
that cannot precisely isolate a small lesion.

### Representative Attention Benefits

| Case/finding | Description | ON-OFF Dice |
| --- | --- | ---: |
| `train_13284_a_2`, finding 0 | Bilateral peripheral/subpleural GGO with septal thickening | +0.114 |
| `train_2639_a_1`, finding 0 | Multi-lobar peripheral/subpleural crazy paving | +0.074 |
| `train_18416_a_1`, finding 0 | Patchy GGO in both lungs | +0.048 |
| `train_19452_a_2`, finding 1 | Patchy left-lower-lobe GGO | +0.039 |
| `train_18414_a_2`, finding 1 | Bilateral peripheral/subpleural GGO | +0.036 |

### Representative Attention Regressions

| Case/finding | Description | ON-OFF Dice |
| --- | --- | ---: |
| `train_19190_a_2`, finding 2 | 287-voxel paraspinal nodular GGO | -0.079 |
| `train_18442_a_1`, finding 0 | Multiple subcentimeter peripheral GGO | -0.057 |
| `train_2532_a_2`, finding 0 | Patchy nodular subpleural GGO | -0.027 |
| `train_3008_a_1`, finding 0 | Mild dependent basal GGO | -0.028 |
| `train_13577_a_2`, finding 0 | Small focal GGO | -0.026 |

Because GT mask size is unavailable at inference, a practical gating policy
would need to infer expected lesion extent from prompt language. Candidate ON
terms include `diffuse`, `bilateral`, `throughout`, `all lobes`, `multifocal`,
and `extensive`. Candidate OFF terms include `focal`, `nodular`,
`subcentimeter`, explicit millimeter measurements, and single-segment small
lesions.

## Approximate S1 Versus S2 Localization Comparison

The S1 and S2 diagnostic selections differ slightly, so this is not a strict
paired comparison.

| Metric | S1 | S2 |
| --- | ---: | ---: |
| Correct enrichment | 1.241 | 1.146 |
| Shuffled enrichment | 1.140 | 1.056 |
| Correct minus shuffled | +0.035 | +0.037 |
| Correct better fraction | 70.2% | 74.5% |
| Pointing accuracy | 0% | 0% |
| Peak-to-GT distance | 344.4 | 246.9 |
| Voxel AUROC | 0.900 | 0.787 |
| Voxel AUPRC | 0.00048 | 0.00037 |
| Correct/shuffled map correlation | 0.748 | 0.883 |
| Enrichment-Dice correlation | 0.217 | 0.130 |

S2 had a slightly higher correct-prompt win fraction and shorter peak distance,
but worse AUROC/AUPRC, substantially higher correct/shuffled correlation, and a
weaker relationship with segmentation Dice. S2 is not clearly more spatially
precise than S1.

## Conclusions

1. S2 learned a weak but statistically significant prompt-dependent spatial
   signal.
2. It did not learn reliable lesion-level localization.
3. Most improvement over Anchor85 came from continued segmentation
   fine-tuning, not from inference-time attention.
4. The strict inference-time attention contribution was only `+0.000611` mean
   finding Dice and one net hit.
5. The current attention is most useful for large, diffuse category-2c findings
   and possibly category 2b.
6. It tends to harm category 1, category 2a, category 2h, and medium/small focal
   or nodular 2c findings.
7. Category-only gating is too coarse for 2c; prompt-derived extent gating is a
   better next inference ablation.
8. The 1/4 branch appears ineffective, the beta/rho parameters barely moved,
   and direct 2c localization supervision was sparse.

## Recommended Next Ablations

Inference-only, requiring no retraining:

1. Enable attention only for category 2c.
2. Enable attention only for categories 2b and 2c.
3. Within 2c, enable attention only for prompts indicating diffuse, bilateral,
   multifocal, or otherwise extensive disease.

Potential future retraining:

1. Remove the ineffective 1/4 branch and supervise only the 1/2 branch.
2. Increase beta learning rate or directly control rho.
3. Increase the sampling frequency of supervised category-2c prompts.
4. Replace mean enrichment alone with a stronger lesion-level localization
   objective.
5. Do not enable attention for categories that receive no appropriate
   localization supervision.
