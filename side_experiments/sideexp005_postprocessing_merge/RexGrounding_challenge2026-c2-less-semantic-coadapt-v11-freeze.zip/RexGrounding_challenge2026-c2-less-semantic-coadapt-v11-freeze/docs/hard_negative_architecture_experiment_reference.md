# Hard-Negative Architecture Experiment Reference

## H-B0-existing

The existing hard-negative continuation reference is:

```text
outputs/voxtell_rex_hard_negative_triplet_preprocessed_4l40s_to4000/checkpoints/checkpoint_step_4000.pth
```

It is the best full-volume checkpoint among the hard-negative continuation
checkpoints already evaluated:

| Checkpoint | Mean global Dice/finding | Mean global Dice/case | Hit rate |
|---|---:|---:|---:|
| step 2400 | 0.266043 | 0.277362 | 0.648294 |
| step 3000 | 0.266365 | 0.277734 | 0.648294 |
| step 4000 | **0.266604** | **0.277936** | 0.648294 |

The metrics come from the corresponding
`outputs/voxtell_rex_hardneg_step*_fullvol_val_predictions/` directories.
Do not rerun H-B0 unless its protocol is later found to be incompatible.

## Matched Configuration

H-B0-existing and H-P1/H-S1/H-PS1 use the same:

- initialization checkpoint:
  `outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500/checkpoints/checkpoint_step_2000.pth`
- `sampler_mode=hard_negative_triplet`
- preprocessed cache: `data/rex_voxtell_preprocessed_v1`
- 2 positive prompts + 1 negative prompt
- no nnU-Net, intensity, or spatial augmentation
- Dice + voxel-weighted BCE segmentation loss
- BCE voxel weights: foreground 1.0, boundary 1.5, background 0.5, radius 10
- empty-target BCE-only loss with weight 0.5
- no voxel-weighted Dice
- encoder LR `1e-7` and decoder LR `1e-6`
- 2000 new training steps with the displayed step reset to 0
- a fresh 100-step warmup to the configured base LR, followed by polynomial
  decay over the full 2000-step architecture run
- patch validation every 100 steps on 50 batches from 200 validation cases
- checkpoint interval 500 steps

The optimizer and LR schedule intentionally differ from H-B0. H-B0 restored
the optimizer state from its initialization checkpoint. The architecture
experiments add new parameter groups, so they reset both the optimizer and the
displayed training step. This gives all parameter groups a fresh 100-step
warmup to their configured base LR instead of entering the inherited schedule
near 0.55 times base LR. This user-requested difference must be reported with
the results.

## Full-Volume Comparison Protocol

Use the same validation cases and standard VoxTell full-volume sliding-window
inference with:

- raw validation CT as inference input
- standard predictor preprocessing
- threshold 0.5
- global-only ReX metrics
- presence-logit inference gating disabled (`presence_logit_weight=0`)

Checkpoint selection for the final comparison must be based on full-volume
`mean_global_dice_per_finding`, not patch Dice alone. Patch-validation best
checkpoints and regular saved checkpoints are candidates for full-volume
evaluation.

The comparison is explicitly:

```text
H-B0-existing best checkpoint
versus
H-P1 / H-S1 / H-PS1 best full-volume validation checkpoints
```

## Prepared Training Wrappers

- `scripts/run_voxtell_rex_p1_spatial_presence_hardneg_4h200.sbatch`
- `scripts/run_voxtell_rex_s1_spatial_attention_hardneg_4h200.sbatch`
- `scripts/run_voxtell_rex_ps1_presence_attention_hardneg_4h200.sbatch`

These wrappers are prepared only. They must not be submitted until the real
192-cubed forward/loss/backward smoke tests pass.
