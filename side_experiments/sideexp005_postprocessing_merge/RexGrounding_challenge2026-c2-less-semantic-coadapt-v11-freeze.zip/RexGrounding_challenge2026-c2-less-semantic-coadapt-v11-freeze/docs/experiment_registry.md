# Experiment registry

| Experiment name | Output directory | Primary implementation | Status |
|---|---|---|---|
| lung lobe soft prior | `outputs/prompt_lobe_soft_component_selector/` | `scripts/evaluate_lung_lobe_soft_prior.py` | CPU-only feasibility experiment; baseline-preserving low-confidence component selection |
