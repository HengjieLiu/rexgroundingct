# Anatomy Prior Diagnostic For VoxTell/ReXGroundingCT

This diagnostic checks whether VoxTell over-segmentation is mostly outside the lung or inside the lung before changing the model architecture.

The pipeline:

1. Run TotalSegmentator on CT volumes.
2. Combine lung lobes into whole-lung, left-lung, right-lung masks.
3. Create spacing-aware dilated lung masks at 5, 10, and 15 mm.
4. Compare original predictions with hard whole-lung anatomy-constrained predictions:

```text
pred_constrained = pred AND lung_dilated_{N}mm
```

5. Report Dice, false-positive volume, pred/GT volume ratio, and whether false positives are inside or outside the lung.
6. Parse finding text for laterality and mentioned lobes, then report whether intra-lung predictions violate the described side/lobe.

The priors are used at three levels:

```text
whole_lung / dilated whole_lung:
  Determines whether false positives leave the lung and whether hard lung clipping helps.

left_lung / right_lung:
  Determines whether predictions violate side/laterality implied by text.

five lobe masks:
  Diagnostic only for now. Reports whether prediction/FP spreads outside mentioned lobes.
  The pipeline does not hard-clip by lobe yet.
```

## Environment

Install the required packages in the same environment used for image analysis:

```bash
pip install TotalSegmentator SimpleITK nibabel pandas numpy scipy matplotlib tqdm
```

TotalSegmentator does not require cloning GitHub for normal use. `pip install TotalSegmentator` is enough. The first run downloads model weights automatically. If the HPC compute node has no internet, run TotalSegmentator once on a machine with internet and copy `~/.totalsegmentator`, or use `totalseg_download_weights`.

## 1. Generate Lung Priors

Example for validation CTs:

```bash
python scripts/run_totalseg_lung_priors.py \
  --ct_dir data/ct_rate_volumes_fixed \
  --out_dir data/lung_priors_totalseg \
  --scan_list_csv data/csv_exports/MICCAI_challenge_dataset.en.csv \
  --scan-id-column case \
  --splits val \
  --num_workers 1 \
  --device gpu \
  --skip_existing \
  --fast
```

Outputs are written as:

```text
data/lung_priors_totalseg/<scan_id>/totalseg/
data/lung_priors_totalseg/<scan_id>/whole_lung.nii.gz
data/lung_priors_totalseg/<scan_id>/left_lung.nii.gz
data/lung_priors_totalseg/<scan_id>/right_lung.nii.gz
data/lung_priors_totalseg/<scan_id>/lung_upper_lobe_left.nii.gz
data/lung_priors_totalseg/<scan_id>/lung_lower_lobe_left.nii.gz
data/lung_priors_totalseg/<scan_id>/lung_upper_lobe_right.nii.gz
data/lung_priors_totalseg/<scan_id>/lung_middle_lobe_right.nii.gz
data/lung_priors_totalseg/<scan_id>/lung_lower_lobe_right.nii.gz
data/lung_priors_totalseg/<scan_id>/lung_dilated_5mm.nii.gz
data/lung_priors_totalseg/<scan_id>/lung_dilated_10mm.nii.gz
data/lung_priors_totalseg/<scan_id>/lung_dilated_15mm.nii.gz
```

Dilation is in physical millimeters using CT spacing, not fixed voxel counts.

## 2. Run The Diagnostic

Use the current VoxTell prediction directory, GT masks, lung priors, and findings CSV:

```bash
python scripts/evaluate_anatomy_prior_diagnostic.py \
  --pred_dir outputs/voxtell_rex_hardneg_weightedbce_r10_step1000_fullvol_val_predictions \
  --gt_dir data/segmentations \
  --ct_dir data/ct_rate_volumes_fixed \
  --prior_dir data/lung_priors_totalseg \
  --findings_csv data/csv_exports/MICCAI_challenge_dataset.en.csv \
  --out_dir outputs/anatomy_prior_diagnostic_hardneg_step1000 \
  --splits val \
  --dilation_mm 10
```

If predictions are probability maps instead of binary masks, add:

```bash
--prediction_is_probability --threshold 0.5
```

Main outputs:

```text
per_finding_metrics.csv
summary_by_group.csv
summary_by_laterality.csv
summary_by_lobe_mentioned.csv
summary_by_category_if_available.csv
worst_cases_outside_lung.csv
worst_cases_inside_lung.csv
worst_cases_laterality_violation.csv
worst_cases_lobe_violation.csv
failed_cases.csv
plots/boxplot_fp_outside_fraction_by_group.png
plots/boxplot_volume_ratio_before_after_by_group.png
plots/scatter_fp_inside_vs_outside.png
plots/scatter_dice_delta_vs_outside_fp_fraction.png
plots/boxplot_fp_outside_laterality_fraction_by_group.png
plots/boxplot_fp_outside_lobe_fraction_by_group.png
plots/scatter_inside_lung_fp_vs_lobe_violation.png
```

## 3. Visual QA

Render representative overlays from the worst-case CSVs:

```bash
python scripts/visualize_anatomy_prior_cases.py \
  --cases_csv outputs/anatomy_prior_diagnostic_hardneg_step1000/worst_cases_inside_lung.csv \
  --ct_dir data/ct_rate_volumes_fixed \
  --pred_dir outputs/voxtell_rex_hardneg_weightedbce_r10_step1000_fullvol_val_predictions \
  --gt_dir data/segmentations \
  --prior_dir data/lung_priors_totalseg \
  --out_dir outputs/anatomy_prior_diagnostic_hardneg_step1000/visual_qa_inside \
  --rank_by fp_inside \
  --num_cases 20 \
  --dilation_mm 10
```

For side/lobe violations, use:

```bash
python scripts/visualize_anatomy_prior_cases.py \
  --cases_csv outputs/anatomy_prior_diagnostic_hardneg_step1000/worst_cases_lobe_violation.csv \
  --ct_dir data/ct_rate_volumes_fixed \
  --pred_dir outputs/voxtell_rex_hardneg_weightedbce_r10_step1000_fullvol_val_predictions \
  --gt_dir data/segmentations \
  --prior_dir data/lung_priors_totalseg \
  --out_dir outputs/anatomy_prior_diagnostic_hardneg_step1000/visual_qa_lobe_violation \
  --rank_by lobe_violation \
  --num_cases 20 \
  --dilation_mm 10
```

Contours:

```text
green  = GT
red    = original prediction
yellow = constrained prediction
blue   = lung prior
```

Each selected finding gets axial, coronal, and sagittal views around the GT centroid and false-positive centroid when available.

## Interpretation

Do not judge the prior only by Dice. Focus on false-positive volume and pred/GT volume ratio.

Case A: high outside-lung FP

```text
fp_outside_whole_lung_fraction high
delta_dice positive after clipping
pred_gt_volume_ratio decreases
```

Interpretation: a lung prior is likely useful immediately. Next step can be an anatomy prior channel or outside-lung penalty.

Case B: high inside-lung FP

```text
fp_inside_whole_lung_fraction high
fp_outside_whole_lung_fraction low
pred_gt_volume_ratio high
```

Interpretation: hard whole-lung clipping is not enough. The next step should be low-resolution coarse-to-fine localization or lobe/text-derived priors.

Case C: laterality/lobe violation

```text
fp_outside_whole_lung_fraction low
fp_outside_laterality_fraction or fp_outside_mentioned_lobes_fraction high
```

Interpretation: over-segmentation is intra-lung but spreads beyond the described side or lobe. Lobe-level or text-derived anatomical priors are a better next step than broad whole-lung clipping.

Case D: constrained Dice drops

```text
delta_dice negative
fn_volume_constrained_mm3 increases
```

Interpretation: the prior may be too strict, TotalSegmentator may have failed, or the finding may legitimately touch pleura/chest wall. Prefer a soft prior instead of hard clipping.

## Notes

- The scripts never silently drop failures. Check `failed_cases.csv`.
- Masks are resampled with nearest-neighbor interpolation when geometry differs.
- ReX 4D masks are supported when the finding channel is either the first axis or last axis.
- The grouping into `diffuse`, `focal`, `mixed`, and `unknown` is intentionally simple regex-based logic for this first diagnostic.
