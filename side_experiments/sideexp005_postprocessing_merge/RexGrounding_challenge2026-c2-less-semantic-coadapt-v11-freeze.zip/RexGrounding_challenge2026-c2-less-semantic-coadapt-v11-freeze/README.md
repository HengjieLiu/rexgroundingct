# RexGroundingCT

Code for prompt-conditioned 3D CT segmentation experiments built on local
copies of VoxTell and nnU-Net.

This repository intentionally contains source code, tests, configurations and
documentation only. It does **not** distribute datasets, patient metadata,
preprocessed caches, checkpoints, predictions, logs, or experiment outputs.

## Installation

Use Python 3.10 or newer and install the two local packages from the repository
root:

```bash
git clone <repository-url>
cd RexGroundingCT
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ./nnUNet
python -m pip install -e ./VoxTell
```

Install a PyTorch build appropriate for the local CUDA or CPU environment
before running GPU jobs. Package dependencies are declared in
`nnUNet/pyproject.toml` and `VoxTell/pyproject.toml`.

## Local inputs

Place or link private inputs outside the repository, then pass their locations
explicitly to the relevant script. A typical layout is:

```text
<local-inputs>/
├── images/
├── masks/
├── metadata.json
└── checkpoints/
```

For example, from the repository root:

```bash
python scripts/prepare_rex_voxtell_preprocessed.py \
  --rex-json <local-inputs>/metadata.json \
  --image-dir <local-inputs>/images \
  --mask-dir <local-inputs>/masks \
  --out-dir <local-workdir>/preprocessed
```

All checked-in shell and Slurm launchers use paths relative to the repository
root. Submit them after `cd`-ing into the clone, or set `REX_ROOT` to that
directory when a launcher supports it. Set `PYTHON` if a launcher should use a
specific interpreter.

## Checks

```bash
pytest -q tests
python -m compileall -q VoxTell/voxtell nnUNet/nnunetv2 scripts tools
```

Some integration tests and training/inference commands require local data and
checkpoints supplied by the user; these are deliberately not included here.

## Repository layout

```text
VoxTell/       local VoxTell source
nnUNet/        local nnU-Net source
configs/       reusable experiment configuration
scripts/       training, inference, preprocessing and evaluation entry points
tests/         unit and integration tests
tools/         maintenance and diagnostic utilities
data/          code-only evaluation helper
```
