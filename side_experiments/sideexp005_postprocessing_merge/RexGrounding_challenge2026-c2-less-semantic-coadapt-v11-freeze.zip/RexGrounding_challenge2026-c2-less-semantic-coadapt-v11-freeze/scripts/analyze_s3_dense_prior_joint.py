#!/usr/bin/env python3
"""Aggregate targeted/preservation/full results and apply the dense-joint gate."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch


CONDITIONS = ("learned", "zero", "oracle", "shifted_oracle")


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, default=str) + "\n")


def sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def summarize(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "n": int(len(frame)),
        "dice": float(frame.dice.mean()),
        "hits": int(frame.hit.sum()),
        "precision": float(frame.precision.mean()),
        "recall": float(frame.recall.mean()),
        "fn_over_gt": float((frame.fn_voxels / frame.gt_voxels.clip(lower=1)).mean()),
        "fp_over_gt": float((frame.fp_voxels / frame.gt_voxels.clip(lower=1)).mean()),
        "predicted_volume": float(frame.pred_voxels.mean()),
    }


def target_summary(frame: pd.DataFrame) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for arm in ("C", "T"):
        for update in (100, 250, 500):
            subset_update = frame[(frame.arm == arm) & (frame.update == update)]
            if subset_update.empty:
                continue
            result.setdefault(arm, {})[str(update)] = {}
            for condition in CONDITIONS:
                subset_condition = subset_update[subset_update.condition == condition]
                if subset_condition.empty:
                    continue
                groups = {"all25": subset_condition}
                groups.update(
                    {
                        name: subset_condition[subset_condition.size_group == name]
                        for name in ("small-2d", "other-2d")
                    }
                )
                result[arm][str(update)][condition] = {
                    name: summarize(group) for name, group in groups.items()
                }
    return result


def load_target(run: Path, arm: str) -> pd.DataFrame:
    frames = []
    for update, label in ((100, "path5"), (250, "target25"), (500, "target25")):
        path = run / "evaluation" / f"{label}_update_{update}" / "per_finding_metrics.csv"
        frame = pd.read_csv(path)
        expected = 5 if update == 100 else 25
        learned = frame[frame.condition == "learned"]
        keys = learned[["case_id", "finding_id"]].drop_duplicates()
        if len(learned) != expected or len(keys) != expected:
            raise AssertionError(f"{arm} update{update}: expected {expected} unique learned findings")
        if set(frame.condition) != set(CONDITIONS) or len(frame) != 4 * expected:
            raise AssertionError(f"{arm} update{update}: incomplete four-condition evaluation")
        frame["update"] = update
        frame["arm"] = arm
        frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def load_fixed(run: Path, arm: str) -> pd.DataFrame:
    frame = pd.read_csv(run / "evaluation/fixed30_update_500/per_finding_metrics.csv")
    frame["arm"] = arm
    if frame[["file", "finding_idx"]].duplicated().any():
        raise AssertionError(f"{arm} fixed30 duplicated findings")
    return frame


def fixed_summary(frame: pd.DataFrame) -> dict[str, Any]:
    groups = {
        "overall": frame,
        "2d": frame[frame.category.astype(str) == "2d"],
        "non2d": frame[frame.category.astype(str) != "2d"],
        "2b_2c": frame[frame.category.astype(str).isin(("2b", "2c"))],
        "tiny_non2b2c": frame[(frame.pixels < 100) & ~frame.category.astype(str).isin(("2b", "2c"))],
    }
    return {
        name: {
            "n": int(len(group)),
            "dice": float(group.global_dice.mean()),
            "hits": int(group.global_hit.sum()),
            "precision": float(group.voxel_precision.mean()),
            "recall": float(group.voxel_recall.mean()),
            "fp_voxels": float(group.fp_voxels.mean()),
            "fn_voxels": float(group.fn_voxels.mean()),
            "predicted_volume": float(group.pred_voxels.mean()),
        }
        for name, group in groups.items()
    }


def parameter_changes(run: Path) -> dict[str, Any]:
    zero = torch.load(run / "checkpoints/checkpoint_update_0.pth", map_location="cpu", weights_only=False)["network_weights"]
    final = torch.load(run / "checkpoints/checkpoint_update_500.pth", map_location="cpu", weights_only=False)["network_weights"]
    prefixes = {
        "dense_prior_head": "category_2d_dense_joint.dense_prior_head.",
        "half_adapter": "category_2d_dense_joint.half_adapter.",
        "full_adapter": "category_2d_dense_joint.full_adapter.",
        "logit_residual": "category_2d_dense_joint.logit_residual.",
    }
    result = {}
    for label, prefix in prefixes.items():
        values = [
            (final[key].float() - zero[key].float()).square().sum()
            for key in zero
            if key.startswith(prefix)
        ]
        result[label] = float(torch.stack(values).sum().sqrt())
    return result


def sequence_from_history(path: Path) -> list[Any]:
    return [json.loads(line)["micro_samples"] for line in path.read_text().splitlines() if line]


def bootstrap_target(frame: pd.DataFrame, samples: int = 2000) -> pd.DataFrame:
    rng = np.random.default_rng(20260804)
    learned = frame[(frame.update == 500) & (frame.condition == "learned")]
    pivot = learned.pivot(index=["case_id", "finding_id"], columns="arm", values="dice").dropna()
    values = pivot["T"].to_numpy() - pivot["C"].to_numpy()
    draws = np.asarray([rng.choice(values, len(values), replace=True).mean() for _ in range(samples)])
    return pd.DataFrame(
        [
            {
                "scope": "target25_T500_minus_C500_learned_dice",
                "estimate": float(values.mean()),
                "ci95_low": float(np.quantile(draws, 0.025)),
                "ci95_high": float(np.quantile(draws, 0.975)),
                "bootstrap_samples": samples,
            }
        ]
    )


def stage_gate(control: Path, treatment: Path, comparison: Path) -> bool:
    target = pd.concat((load_target(control, "C"), load_target(treatment, "T")), ignore_index=True)
    target.to_csv(comparison / "per_finding_all_conditions.csv", index=False)
    summaries = target_summary(target)
    write_json(comparison / "update100_path_audit.json", {arm: summaries[arm]["100"] for arm in summaries})
    write_json(comparison / "update250_targeted_results.json", {arm: summaries[arm]["250"] for arm in summaries})
    write_json(comparison / "update500_targeted_results.json", {arm: summaries[arm]["500"] for arm in summaries})
    target[
        [
            "arm", "update", "case_id", "finding_id", "condition", "size_group",
            "prior_soft_dice", "prior_voxel_auroc", "prior_voxel_auprc", "prior_prevalence",
            "mean_Q_inside_gt", "mean_Q_inside_5mm_support", "mean_Q_outside_support",
            "prior_mass_inside_support_fraction", "prior_component_coverage",
        ]
    ].to_csv(comparison / "prior_quality_metrics.csv", index=False)
    target[
        [
            "arm", "update", "case_id", "finding_id", "condition", "size_group",
            "logit_change_mean_abs", "logit_change_max_abs",
            "oracle_shifted_logit_mean_abs", "oracle_shifted_logit_max_abs",
            "delta_z_mean_abs", "delta_z_max_abs", "gt_crossing_count",
            "background_crossing_count", "Qused_logit_change_correlation",
        ]
    ].to_csv(comparison / "causal_conversion_metrics.csv", index=False)
    bootstrap_target(target).to_csv(comparison / "bootstrap_results.csv", index=False)

    fixed = pd.concat((load_fixed(control, "C"), load_fixed(treatment, "T")), ignore_index=True)
    fixed.to_csv(comparison / "fixed30_per_finding.csv", index=False)
    fixed_results = {arm: fixed_summary(fixed[fixed.arm == arm]) for arm in ("C", "T")}
    write_json(comparison / "fixed30_results.json", fixed_results)

    c_sequence = sequence_from_history(control / "training_history.jsonl")
    t_sequence = sequence_from_history(treatment / "training_history.jsonl")
    if len(c_sequence) != 500 or len(t_sequence) != 500:
        raise AssertionError("Formal training did not contain exactly 500 optimizer updates")
    sequence_equal = c_sequence == t_sequence
    changes = {"C": parameter_changes(control), "T": parameter_changes(treatment)}
    t500 = target[(target.arm == "T") & (target.update == 500)]
    c500 = target[(target.arm == "C") & (target.update == 500)]
    t_learned = t500[t500.condition == "learned"]
    t_zero = t500[t500.condition == "zero"]
    merged = t_learned.merge(
        c500[c500.condition == "learned"], on=["case_id", "finding_id", "size_group"], suffixes=("_T", "_C")
    )
    small = merged[merged.size_group == "small-2d"]
    other = merged[merged.size_group == "other-2d"]
    small_hit_gain = int(small.hit_T.sum() - small.hit_C.sum())
    small_dice_gain = float((small.dice_T - small.dice_C).mean())
    other_dice_gain = float((other.dice_T - other.dice_C).mean())
    fixed_non2d_gain = fixed_results["T"]["non2d"]["dice"] - fixed_results["C"]["non2d"]["dice"]
    learned_zero = t_learned.merge(t_zero, on=["case_id", "finding_id", "size_group"], suffixes=("_learned", "_zero"))
    learned_zero_dice = float((learned_zero.dice_learned - learned_zero.dice_zero).mean())
    learned_zero_precision = float((learned_zero.precision_learned - learned_zero.precision_zero).mean())
    learned_zero_logit = float(t_zero.logit_change_max_abs.max())
    oracle_shifted_logit = float(t500.oracle_shifted_logit_max_abs.max())
    per_finding_gain = merged.dice_T - merged.dice_C
    checks = {
        "small2d_hit_or_dice_gate": small_hit_gain >= 1 or small_dice_gain >= 0.003,
        "other2d_dice_preserved": other_dice_gain >= -0.002,
        "fixed30_non2d_dice_preserved": fixed_non2d_gain >= -0.001,
        "learned_differs_from_zero_in_logits": learned_zero_logit > 0.0,
        "oracle_differs_from_shifted_spatially": oracle_shifted_logit > 0.0,
        "all_adapter_parameter_groups_changed": all(value > 0 for value in changes["T"].values()),
        "t_learned_not_worse_than_zero_in_both_dice_and_precision": not (learned_zero_dice < 0 and learned_zero_precision < 0),
        "improvement_not_entirely_one_finding": int((per_finding_gain > 0).sum()) >= 2,
        "formal_training_batches_exactly_matched": sequence_equal,
    }
    gate_pass = all(checks.values())
    safety = {
        "same_sequence": sequence_equal,
        "sequence_sha256": sha(c_sequence),
        "micro_samples_per_arm": sum(map(len, c_sequence)),
        "category_2d_prompt_exposure_C": int(sum(json.loads(line)["category_counts"].get("2d", 0) for line in [control.joinpath("training_history.jsonl").read_text().splitlines()[-1]])),
        "category_2d_prompt_exposure_T": int(sum(json.loads(line)["category_counts"].get("2d", 0) for line in [treatment.joinpath("training_history.jsonl").read_text().splitlines()[-1]])),
        "parameter_changes_from_update0": changes,
        "target_findings_unique": int(len(t_learned[["case_id", "finding_id"]].drop_duplicates())) == 25,
    }
    write_json(comparison / "safety_checks.json", safety)
    decision = {
        "full381_gate": "PASS" if gate_pass else "FAIL",
        "checks": checks,
        "measurements": {
            "small2d_hit_gain_T_minus_C": small_hit_gain,
            "small2d_dice_gain_T_minus_C": small_dice_gain,
            "other2d_dice_gain_T_minus_C": other_dice_gain,
            "fixed30_non2d_dice_gain_T_minus_C": fixed_non2d_gain,
            "T_learned_minus_zero_dice": learned_zero_dice,
            "T_learned_minus_zero_precision": learned_zero_precision,
            "max_learned_zero_logit_difference": learned_zero_logit,
            "max_oracle_shifted_logit_difference": oracle_shifted_logit,
            "findings_improved_T_vs_C": int((per_finding_gain > 0).sum()),
        },
        "full381_action": "run matched C/T full381" if gate_pass else "do not run full381",
        "training_stops_at_update500": True,
    }
    write_json(comparison / "decision.json", decision)
    curves = []
    for arm, run in (("C", control), ("T", treatment)):
        frame = pd.read_csv(run / "training_metrics.csv")
        frame["arm"] = arm
        curves.append(frame)
    pd.concat(curves, ignore_index=True).to_csv(comparison / "training_curves.csv", index=False)
    report = f"""# Dense Prior Joint-Training Pilot

Status: targeted/fixed30 complete; full381 gate **{decision['full381_gate']}**.

- Base: `{json.loads((comparison / 'checkpoint_provenance.json').read_text())['checkpoint']}`
- Small-2d T−C: Dice {small_dice_gain:+.6f}, hits {small_hit_gain:+d}
- Other-2d T−C Dice: {other_dice_gain:+.6f}
- Fixed30 non-2d T−C Dice: {fixed_non2d_gain:+.6f}
- T learned−zero: Dice {learned_zero_dice:+.6f}, precision {learned_zero_precision:+.6f}
- Matched training sequence: {sequence_equal} ({safety['micro_samples_per_arm']} micro-samples/arm)
- Decision details: `decision.json`

Training is capped at update 500. Full381 is {'enabled by the preregistered gate' if gate_pass else 'not launched because at least one preregistered gate failed'}.
"""
    (comparison / "report.md").write_text(report)
    print(json.dumps(decision, sort_keys=True))
    return gate_pass


def stage_final(control: Path, treatment: Path, comparison: Path) -> bool:
    decision = json.loads((comparison / "decision.json").read_text())
    if decision["full381_gate"] != "PASS":
        return False
    frames = []
    for arm, run in (("C", control), ("T", treatment)):
        frame = pd.read_csv(run / "evaluation/full381_update_500/per_finding_metrics.csv")
        if len(frame) != 381 or frame[["file", "finding_idx"]].duplicated().any():
            raise AssertionError(f"{arm}: full381 is not exactly 381 unique findings")
        frame["arm"] = arm
        frames.append(frame)
    full = pd.concat(frames, ignore_index=True)
    full.to_csv(comparison / "full381_per_finding.csv", index=False)
    summaries = {arm: fixed_summary(full[full.arm == arm]) for arm in ("C", "T")}
    per_category = (
        full.groupby(["arm", "category"], dropna=False)
        .agg(n=("global_dice", "size"), dice=("global_dice", "mean"), hits=("global_hit", "sum"))
        .reset_index()
    )
    per_category.to_csv(comparison / "full381_per_category.csv", index=False)
    full["size_stratum"] = pd.cut(
        full.pixels,
        bins=[-np.inf, 99, 999, 9999, np.inf],
        labels=["tiny", "small", "medium", "large"],
    )
    (
        full.groupby(["arm", "size_stratum"], observed=True)
        .agg(n=("global_dice", "size"), dice=("global_dice", "mean"), hits=("global_hit", "sum"))
        .reset_index()
        .to_csv(comparison / "full381_size_strata.csv", index=False)
    )
    paired = full.pivot(index=["file", "finding_idx"], columns="arm", values="global_dice").dropna()
    case_values = (
        paired.assign(difference=paired["T"] - paired["C"])
        .reset_index()
        .groupby("file").difference.mean()
        .to_numpy()
    )
    rng = np.random.default_rng(20260804)
    bootstrap = np.asarray(
        [rng.choice(case_values, len(case_values), replace=True).mean() for _ in range(5000)]
    )
    bootstrap_path = comparison / "bootstrap_results.csv"
    bootstrap_frame = pd.read_csv(bootstrap_path)
    bootstrap_frame = pd.concat(
        (
            bootstrap_frame,
            pd.DataFrame(
                [
                    {
                        "scope": "full381_case_bootstrap_T500_minus_C500_learned_dice",
                        "estimate": float(case_values.mean()),
                        "ci95_low": float(np.quantile(bootstrap, 0.025)),
                        "ci95_high": float(np.quantile(bootstrap, 0.975)),
                        "bootstrap_samples": 5000,
                    }
                ]
            ),
        ),
        ignore_index=True,
    )
    bootstrap_frame.to_csv(bootstrap_path, index=False)
    write_json(comparison / "full381_results.json", summaries)
    report_path = comparison / "report.md"
    report_path.write_text(
        report_path.read_text()
        + f"\n## Full381\n\n- C overall Dice: {summaries['C']['overall']['dice']:.6f}\n"
        + f"- T overall Dice: {summaries['T']['overall']['dice']:.6f}\n"
        + f"- T−C overall Dice: {summaries['T']['overall']['dice'] - summaries['C']['overall']['dice']:+.6f}\n"
    )
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("gate", "final"), required=True)
    parser.add_argument("--control-dir", type=Path, required=True)
    parser.add_argument("--treatment-dir", type=Path, required=True)
    parser.add_argument("--comparison-dir", type=Path, required=True)
    args = parser.parse_args()
    passed = (
        stage_gate(args.control_dir, args.treatment_dir, args.comparison_dir)
        if args.stage == "gate"
        else stage_final(args.control_dir, args.treatment_dir, args.comparison_dir)
    )
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
