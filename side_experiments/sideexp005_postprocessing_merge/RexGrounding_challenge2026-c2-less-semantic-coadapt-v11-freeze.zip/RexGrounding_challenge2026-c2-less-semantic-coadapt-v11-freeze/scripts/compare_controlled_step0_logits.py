#!/usr/bin/env python3
"""Compare baseline and S3 update-0 full-volume logits on one fixed input."""

from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path

import torch


ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "VoxTell", ROOT / "scripts"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from run_voxtell_rex_inference import load_image  # noqa: E402
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402


@torch.inference_mode()
def predict(model_dir: Path, image_path: Path, embedding: torch.Tensor) -> torch.Tensor:
    predictor = VoxTellPredictor(
        str(model_dir),
        device=torch.device("cuda"),
        load_text_backbone=False,
    )
    image, _ = load_image(image_path)
    data, _, _ = predictor.preprocess(image)
    logits = predictor.predict_sliding_window_return_logits(
        data, embedding[None, None].float()
    )
    result = logits[0, 0].float().cpu()
    del logits, predictor
    gc.collect()
    torch.cuda.empty_cache()
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-experiment", type=Path, required=True)
    parser.add_argument("--s3-experiment", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(
        (args.baseline_experiment / "fixed30_manifest.json").read_text()
    )
    first_case = manifest["val"][0]["name"]
    cache = torch.load(
        ROOT
        / "outputs/prompt_standardization_rule_only_v1"
        / "stratified30_six_variant_ablation_v1"
        / "prepared_inputs/qwen_original_subset30.pt",
        map_location="cpu",
        weights_only=False,
    )
    index = next(
        i
        for i, record in enumerate(cache["records"])
        if record["case"] == first_case and int(record["finding_idx"]) == 0
    )
    embedding = cache["embeddings"][index]
    baseline = predict(
        args.baseline_experiment / "validation_models/update_00000",
        ROOT / "data/ct_rate_volumes_fixed" / first_case,
        embedding,
    )
    s3 = predict(
        args.s3_experiment / "validation_models/update_00000",
        ROOT / "data/ct_rate_volumes_fixed" / first_case,
        embedding,
    )
    if baseline.shape != s3.shape:
        raise AssertionError(f"Logit shapes differ: {baseline.shape} != {s3.shape}")
    difference = (baseline - s3).abs()
    result = {
        "case": first_case,
        "finding_idx": 0,
        "voxel_count": difference.numel(),
        "maximum_absolute_segmentation_logit_difference": float(difference.max()),
        "mean_absolute_segmentation_logit_difference": float(difference.mean()),
        "baseline_logit_mean": float(baseline.mean()),
        "s3_logit_mean": float(s3.mean()),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
