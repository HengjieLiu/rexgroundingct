#!/usr/bin/env python3
"""Submit only the next safe stage of the streamlined alignment-v2 pipeline."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
TRAIN_SBATCH = ROOT / "scripts/train_prompt_location_alignment_v2_2h200.sbatch"
EVAL_SBATCH = ROOT / "scripts/eval_prompt_location_v2_streamlined_fixed30.sbatch"
CONTINUE_SBATCH = ROOT / "scripts/continue_prompt_location_v2_streamlined_cpu.sbatch"
REPORT_SBATCH = ROOT / "scripts/report_prompt_location_v2_streamlined_cpu.sbatch"


def submit(
    script: Path,
    exports: dict[str, Any],
    dependency: str | None = None,
) -> str:
    export_value = "ALL," + ",".join(f"{key}={value}" for key, value in exports.items())
    command = ["sbatch", "--parsable", f"--export={export_value}"]
    if dependency:
        command.append(f"--dependency={dependency}")
    command.append(str(script))
    return subprocess.check_output(command, cwd=ROOT, text=True).strip()


def append_event(root: Path, event: dict[str, Any]) -> None:
    path = root / "pipeline_jobs.json"
    payload = json.loads(path.read_text()) if path.exists() else {"events": []}
    payload["events"].append(event)
    path.write_text(json.dumps(payload, indent=2) + "\n")


def training_exports(
    experiment_root: Path,
    stage: str,
    updates: int,
    config: dict[str, Any],
) -> dict[str, Any]:
    return {
        "STAGE": stage,
        "UPDATES": updates,
        "EXPERIMENT_ROOT": experiment_root,
        "HARD_NEGATIVE_CSV": (
            experiment_root / "hard_negative_components.csv"
        ),
        "LAMBDA_LUNG": config["lambda_lung"],
        "LAMBDA_SIDE": config["lambda_side"],
        "LAMBDA_LOBE": config["lambda_lobe"],
        "TAU_LUNG": config["tau_lung"],
        "TAU_SIDE": config["tau_side"],
        "TAU_LOBE": config["tau_lobe"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke-dir", type=Path, required=True)
    parser.add_argument(
        "--phase", choices=["default", "stronger", "weaker"], required=True
    )
    args = parser.parse_args()
    smoke_dir = args.smoke_dir.resolve()
    experiment_root = smoke_dir.parent
    decision_path = experiment_root / f"smoke_decision_{smoke_dir.name}.json"
    decision = json.loads(decision_path.read_text())
    train_args = json.loads((smoke_dir / "args.json").read_text())
    chosen = {
        "lambda_lung": train_args["prompt_location_lambda_lung"],
        "lambda_side": train_args["prompt_location_lambda_side"],
        "lambda_lobe": train_args["prompt_location_lambda_lobe"],
        "tau_lung": train_args["prompt_location_tau_lung"],
        "tau_side": train_args["prompt_location_tau_side"],
        "tau_lobe": train_args["prompt_location_tau_lobe"],
    }
    value = decision["decision"]
    event: dict[str, Any] = {
        "phase": args.phase,
        "smoke_dir": str(smoke_dir),
        "decision": value,
        "chosen_parameters": chosen,
    }
    final_decision = value not in {
        "STRONGER_SMOKE_REQUIRED",
        "WEAKER_OR_STOP",
    } or args.phase != "default"
    if final_decision:
        for source, destination in (
            (
                experiment_root / f"smoke_decision_{smoke_dir.name}.md",
                experiment_root / "smoke_decision.md",
            ),
            (
                experiment_root / f"smoke_decision_{smoke_dir.name}.json",
                experiment_root / "smoke_decision.json",
            ),
            (
                experiment_root / f"resolved_config_{smoke_dir.name}.yaml",
                experiment_root / "resolved_config.yaml",
            ),
        ):
            if not destination.exists():
                shutil.copyfile(source, destination)

    if value == "SMOKE_GO":
        checkpoint_250 = (
            experiment_root / "formal/checkpoints/checkpoint_update_250.pth"
        )
        if checkpoint_250.is_file():
            event["formal"] = "reused_existing_checkpoint"
            formal_job = None
        else:
            formal_job = submit(
                TRAIN_SBATCH,
                training_exports(experiment_root, "formal", 250, chosen),
            )
            event["formal_job"] = formal_job
        dependency = None if formal_job is None else f"afterok:{formal_job}"
        checkpoint_100 = (
            experiment_root / "formal/checkpoints/checkpoint_update_100.pth"
        )
        eval_jobs = {}
        for label, checkpoint in ((100, checkpoint_100), (250, checkpoint_250)):
            eval_dir = experiment_root / f"subset30_eval_update{label}"
            if (eval_dir / "subset_metrics.csv").is_file():
                eval_jobs[str(label)] = "reused_existing"
                continue
            eval_jobs[str(label)] = submit(
                EVAL_SBATCH,
                {
                    "LABEL": label,
                    "CHECKPOINT": checkpoint,
                    "EXPERIMENT_ROOT": experiment_root,
                },
                dependency=dependency,
            )
        event["fixed30_jobs"] = eval_jobs
        numeric_eval_jobs = [
            value for value in eval_jobs.values() if str(value).isdigit()
        ]
        if numeric_eval_jobs:
            report_dependency = "afterok:" + ":".join(numeric_eval_jobs)
            report_job = submit(
                REPORT_SBATCH,
                {"EXPERIMENT_ROOT": experiment_root},
                dependency=report_dependency,
            )
            event["report_job"] = report_job
    elif value == "STRONGER_SMOKE_REQUIRED" and args.phase == "default":
        stronger = {
            "lambda_lung": 0.004,
            "lambda_side": 0.006,
            "lambda_lobe": 0.002,
            "tau_lung": 0.002,
            "tau_side": 0.01,
            "tau_lobe": 0.03,
        }
        smoke_job = submit(
            TRAIN_SBATCH,
            training_exports(experiment_root, "smoke_stronger", 20, stronger),
        )
        decision_job = submit(
            CONTINUE_SBATCH,
            {
                "SMOKE_DIR": experiment_root / "smoke_stronger",
                "PHASE": "stronger",
            },
            dependency=f"afterok:{smoke_job}",
        )
        event.update(
            {"stronger_smoke_job": smoke_job, "stronger_decision_job": decision_job}
        )
    elif value == "WEAKER_OR_STOP" and args.phase == "default":
        weaker = {
            "lambda_lung": float(chosen["lambda_lung"]) / 2,
            "lambda_side": float(chosen["lambda_side"]) / 2,
            "lambda_lobe": float(chosen["lambda_lobe"]) / 2,
            "tau_lung": chosen["tau_lung"],
            "tau_side": chosen["tau_side"],
            "tau_lobe": chosen["tau_lobe"],
        }
        smoke_job = submit(
            TRAIN_SBATCH,
            training_exports(experiment_root, "smoke_weaker", 20, weaker),
        )
        decision_job = submit(
            CONTINUE_SBATCH,
            {
                "SMOKE_DIR": experiment_root / "smoke_weaker",
                "PHASE": "weaker",
            },
            dependency=f"afterok:{smoke_job}",
        )
        event.update(
            {"weaker_smoke_job": smoke_job, "weaker_decision_job": decision_job}
        )
    else:
        event["pipeline_stopped"] = True
        event["reason"] = (
            "Smoke did not safely activate after the single permitted calibration "
            "or required diagnostics were missing."
        )
    append_event(experiment_root, event)
    print(json.dumps(event, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
