#!/usr/bin/env python3
"""Combine Presence V2 gating reports across checkpoint steps."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


REX_ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--steps", nargs="+", default=["step600", "step1500", "step1800"])
    parser.add_argument("--out", type=Path, default=REX_ROOT / "outputs/presence_v2_category_gating_report.txt")
    args = parser.parse_args()

    frames = []
    lines = ["Presence V2 combined category gating report", ""]
    for step in args.steps:
        out_dir = REX_ROOT / f"outputs/presence_v2_category_gating_{step}"
        csv_path = out_dir / "category_gating_summary.csv"
        report_path = out_dir / "report.txt"
        if csv_path.exists():
            df = pd.read_csv(csv_path)
            df.insert(0, "checkpoint", step)
            frames.append(df)
        if report_path.exists():
            lines.append(f"## {step}")
            lines.append(report_path.read_text().strip())
            lines.append("")
    if frames:
        combined = pd.concat(frames, ignore_index=True)
        combined_csv = args.out.with_suffix(".csv")
        combined.to_csv(combined_csv, index=False)
        best = combined.sort_values("mean_global_dice_per_finding", ascending=False).iloc[0]
        lines.insert(
            2,
            f"Overall best: {best['checkpoint']} / {best['setting']} "
            f"Dice/finding={best['mean_global_dice_per_finding']:.6f}, "
            f"hit_rate={best['hit_rate']:.6f}.\n",
        )
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text("\n".join(lines) + "\n")
    print(args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
