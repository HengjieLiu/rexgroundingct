#!/usr/bin/env python3
"""Audit terminal accounting and checkpoint contents for a controlled run."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-dir", type=Path, required=True)
    parser.add_argument("--expected-updates", type=int, default=10_000)
    args = parser.parse_args()
    checkpoint = args.experiment_dir / "checkpoints" / "checkpoint_latest.pth"
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False, mmap=True)
    expected_micro_steps = args.expected_updates * 4
    required = {
        "network_weights",
        "optimizer",
        "scheduler",
        "micro_step",
        "optimizer_update",
        "epoch",
        "step_in_epoch",
        "python_rng_state",
        "numpy_rng_state",
        "torch_cpu_rng_state",
        "torch_cuda_rng_state_all",
        "sampler_state",
    }
    missing = sorted(required - set(payload))
    if missing:
        raise AssertionError(f"Checkpoint missing required state: {missing}")
    if int(payload["optimizer_update"]) != args.expected_updates:
        raise AssertionError(payload["optimizer_update"])
    if int(payload["micro_step"]) != expected_micro_steps:
        raise AssertionError(payload["micro_step"])
    if int(payload["epoch"]) != args.expected_updates // 100:
        raise AssertionError(payload["epoch"])
    history = [
        json.loads(line)
        for line in (args.experiment_dir / "history.jsonl").read_text().splitlines()
        if line.strip()
    ]
    training = [row for row in history if int(row.get("micro_step", 0)) > 0]
    if len(training) != expected_micro_steps:
        raise AssertionError(f"Expected {expected_micro_steps} history rows, got {len(training)}")
    registry = json.loads(
        (args.experiment_dir / "full_volume/validation_registry.json").read_text()
    )
    expected_validation = {str(update) for update in range(0, args.expected_updates + 1, 1000)}
    if set(registry) != expected_validation:
        raise AssertionError(f"Validation updates: {sorted(registry, key=int)}")
    report = {
        "optimizer_updates": args.expected_updates,
        "micro_steps": expected_micro_steps,
        "patch_exposures": expected_micro_steps,
        "prompt_mask_pair_exposures": expected_micro_steps * 3,
        "reporting_epochs": args.expected_updates // 100,
        "fixed30_validation_rounds": len(registry),
        "checkpoint_latest": str(checkpoint),
        "checkpoint_best_fullvolume_dice": str(
            args.experiment_dir / "checkpoints/checkpoint_best_fullvolume_dice.pth"
        ),
        "status": "PASS",
    }
    path = args.experiment_dir / "controlled_completion_audit.json"
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
