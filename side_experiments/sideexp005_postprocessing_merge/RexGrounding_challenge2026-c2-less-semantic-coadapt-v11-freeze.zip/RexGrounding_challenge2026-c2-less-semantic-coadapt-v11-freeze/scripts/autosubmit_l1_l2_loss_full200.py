#!/usr/bin/env python3
"""Submit independent L1/L2 full-validation jobs selected by the subset gate."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SUBSET_DIR = ROOT / "outputs/l1_l2_loss_subset30"


def submit(*args: str) -> str:
    result = subprocess.run(
        ["sbatch", "--parsable", *args], check=True, text=True, capture_output=True
    )
    return result.stdout.strip().split(";")[0]


def main() -> int:
    decision = json.loads((SUBSET_DIR / "decision.json").read_text())
    record = {"decision": decision, "submitted": False, "jobs": {}}
    selected = decision.get("selected", [])
    if not selected:
        (SUBSET_DIR / "full200_submission.json").write_text(json.dumps(record, indent=2) + "\n")
        print("No L1/L2 checkpoint passed the predeclared subset gate.")
        return 0

    jobs = {}
    for item in selected:
        branch, step = item["branch"], int(item["step"])
        key = f"{branch}_step{step}"
        jobs[key] = submit(
            f"--job-name=l12_full_{branch}_{step}",
            f"--export=ALL,LOSS_BRANCH={branch},STEP={step}",
            str(ROOT / "scripts/evaluate_l1_l2_loss_full200.sbatch"),
        )

    dependency = ":".join(jobs.values())
    collector = submit(
        f"--dependency=afterok:{dependency}",
        str(ROOT / "scripts/collect_l1_l2_loss_full200.sbatch"),
    )
    record.update({"submitted": True, "jobs": jobs, "collector_job": collector})
    (SUBSET_DIR / "full200_submission.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
