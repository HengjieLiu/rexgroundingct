#!/usr/bin/env python3
"""Gate and summarize the half-LR, 1c-S3-disabled attention continuation."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "outputs/dual_expert_historical_lr_from_u500"
SOURCE = BASE / "attention_continue_3000_to_5000"
OUT = BASE / "attention_low_lr_no1c_from_u3500_to_u6000"
BASELINE_PATH = ROOT / "outputs/nonattention_baseline_selection/full381_update10000/summary_tables/per_finding_metrics.csv"
ROUTING_PATH = ROOT / "configs/attention_routing_by_scale_no1c.json"
CATEGORIES = ["1c", "1d", "1f", "2b", "2c"]
ATTENTION_CATEGORIES = ["1d", "1f", "2b", "2c"]
KEYS = ["file", "finding_idx"]
REFERENCE_UPDATE = 3500
MARGIN = 0.003


def write_json(name: str, value: object) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_text(json.dumps(value, indent=2, default=str) + "\n")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def metrics_path(update: int) -> Path:
    return OUT / f"evaluations/update{update}/summary_tables/specialist_metrics.csv"


def load(update: int) -> pd.DataFrame:
    frame = pd.read_csv(metrics_path(update))
    frame["category"] = frame.category.astype(str)
    frame = frame[frame.category.isin(CATEGORIES)].copy()
    if len(frame) != 136 or frame.duplicated(KEYS).any():
        raise RuntimeError(f"update{update}: expected 136 unique specialist findings, got {len(frame)}")
    return frame.sort_values(KEYS).reset_index(drop=True)


def summary(frame: pd.DataFrame) -> dict[str, float | int]:
    gt = frame.gt_voxels.clip(lower=1)
    return {
        "findings": len(frame),
        "mean_dice": float(frame.global_dice.mean()),
        "hits": int(frame.global_hit.astype(bool).sum()),
        "hit_rate": float(frame.global_hit.astype(bool).mean()),
        "precision": float(frame.voxel_precision.mean()),
        "recall": float(frame.voxel_recall.mean()),
        "FP_GT": float((frame.fp_voxels / gt).mean()),
        "FN_GT": float((frame.fn_voxels / gt).mean()),
        "predicted_GT_volume_ratio": float((frame.pred_voxels / gt).mean()),
    }


def paired(candidate: pd.DataFrame, reference: pd.DataFrame) -> dict:
    merged = reference[KEYS + ["global_dice", "global_hit"]].merge(
        candidate[KEYS + ["global_dice", "global_hit"]],
        on=KEYS,
        suffixes=("_reference", "_candidate"),
        validate="one_to_one",
    )
    delta = merged.global_dice_candidate - merged.global_dice_reference
    absolute_sum = float(delta.abs().sum())
    return {
        "mean_dice_delta": float(delta.mean()),
        "hit_delta": int(merged.global_hit_candidate.sum() - merged.global_hit_reference.sum()),
        "improved": int((delta > 1e-12).sum()),
        "degraded": int((delta < -1e-12).sum()),
        "tied": int((delta.abs() <= 1e-12).sum()),
        "largest_finding_absolute_share": float(delta.abs().max() / absolute_sum) if absolute_sum else 0.0,
        "single_finding_dominated": bool(absolute_sum and delta.abs().max() / absolute_sum > 0.5),
    }


def matched_baseline(reference: pd.DataFrame) -> pd.DataFrame:
    baseline = pd.read_csv(BASELINE_PATH)
    baseline["category"] = baseline.category.astype(str)
    keys = set(map(tuple, reference[KEYS].itertuples(index=False, name=None)))
    matched = baseline[
        [tuple(row) in keys for row in baseline[KEYS].itertuples(index=False, name=None)]
    ].sort_values(KEYS).reset_index(drop=True)
    if len(matched) != 136 or matched.duplicated(KEYS).any():
        raise RuntimeError("baseline specialist-pool mapping mismatch")
    return matched


def available_updates() -> list[int]:
    return [update for update in (3500, 4000, 4500, 5000, 5500, 6000) if metrics_path(update).is_file()]


def build_tables() -> tuple[pd.DataFrame, pd.DataFrame, dict[int, pd.DataFrame]]:
    updates = available_updates()
    if REFERENCE_UPDATE not in updates:
        raise RuntimeError("The 1c-disabled update3500 reference evaluation is missing")
    frames = {update: load(update) for update in updates}
    reference = frames[REFERENCE_UPDATE]
    baseline = matched_baseline(reference)
    trajectory_rows: list[dict] = []
    category_rows: list[dict] = []
    for update, frame in frames.items():
        trajectory_rows.append({
            "update": update,
            **summary(frame),
            "dice_delta_vs_no1c_attention3500": float(frame.global_dice.mean() - reference.global_dice.mean()),
            "dice_delta_vs_baseline10000": float(frame.global_dice.mean() - baseline.global_dice.mean()),
        })
        for category in CATEGORIES:
            block = frame[frame.category.eq(category)]
            ref = reference[reference.category.eq(category)]
            base = baseline[baseline.category.eq(category)]
            category_rows.append({
                "update": update,
                "category": category,
                "attention_enabled": category in ATTENTION_CATEGORIES,
                **summary(block),
                "dice_delta_vs_no1c_attention3500": float(block.global_dice.mean() - ref.global_dice.mean()),
                "dice_delta_vs_baseline10000": float(block.global_dice.mean() - base.global_dice.mean()),
            })
    trajectory = pd.DataFrame(trajectory_rows).sort_values("update")
    per_category = pd.DataFrame(category_rows).sort_values(["update", "category"])
    trajectory.to_csv(OUT / "attention_trajectory.csv", index=False)
    per_category.to_csv(OUT / "per_category_trajectory.csv", index=False)
    return trajectory, per_category, frames


def prepare() -> None:
    checkpoint = SOURCE / "checkpoints/checkpoint_update_3500.pth"
    routing = json.loads(ROUTING_PATH.read_text())
    if any(float(routing[scale].get("1c", 0.0)) != 0.0 for scale in ("1/4", "1/2", "1/1")):
        raise RuntimeError("1c must be disabled at every S3 scale")
    write_json("experiment_config.json", {
        "objective": "half-LR continuation from attention@3500 with 1c removed from S3 attention",
        "resume_checkpoint": str(checkpoint.resolve()),
        "resume_checkpoint_sha256": sha256(checkpoint),
        "resume_optimizer_state": True,
        "resume_scheduler_state": True,
        "start_update": 3500,
        "maximum_update": 6000,
        "checkpoint_interval": 500,
        "specialist_training_categories": CATEGORIES,
        "s3_attention_categories": ATTENTION_CATEGORIES,
        "one_c_policy": "remains in specialist sampling/segmentation loss; S3 gate and S3 map supervision disabled at all scales",
        "learning_rates": {"encoder": 5e-6, "decoder_and_segmentation_head": 5e-5, "s3_attention": 5e-5},
        "optimizer": {"type": "SGD", "momentum": 0.99, "nesterov": True, "weight_decay": 3e-5},
        "routing_path": str(ROUTING_PATH.resolve()),
        "routing": routing,
        "reference_policy": "re-evaluate update3500 using the same 1c-disabled inference route",
        "continuation_gate": f"stop if both consecutive stage checkpoints are below update3500 by more than {MARGIN}",
        "sampler_resume_caveat": "model/optimizer/scheduler/global RNG restored; prefetched sampler state skipped and deterministic sampler stream restarted due validated resume workaround",
    })


def gate(stage: int) -> None:
    if stage not in (1, 2):
        raise ValueError(stage)
    if stage == 2:
        upstream = json.loads((OUT / "gate_stage1.json").read_text())
        if upstream["status"] != "CONTINUE":
            write_json("gate_stage2.json", {
                "status": "STOP",
                "reason": "propagated from gate_stage1",
                "upstream": upstream,
            })
            return
    trajectory, _, _ = build_tables()
    pair = (4000, 4500) if stage == 1 else (5000, 5500)
    scores = trajectory.set_index("update").mean_dice
    missing = [update for update in pair if update not in scores.index]
    if missing:
        raise RuntimeError(f"stage{stage} missing evaluated checkpoints {missing}")
    reference = float(scores.loc[REFERENCE_UPDATE])
    threshold = reference - MARGIN
    stop = all(float(scores.loc[update]) < threshold for update in pair)
    write_json(f"gate_stage{stage}.json", {
        "status": "STOP" if stop else "CONTINUE",
        "reference_update": REFERENCE_UPDATE,
        "reference_mean_dice": reference,
        "margin": MARGIN,
        "stop_threshold": threshold,
        "evaluated_pair": {str(update): float(scores.loc[update]) for update in pair},
        "rule": "STOP only if both checkpoints in this consecutive stage pair are below reference by more than 0.003",
    })


def hybrid(candidate: pd.DataFrame, include_1c: bool) -> dict:
    full = pd.read_csv(BASELINE_PATH)
    selected = candidate if include_1c else candidate[~candidate.category.eq("1c")]
    keys = set(map(tuple, selected[KEYS].itertuples(index=False, name=None)))
    preserved = full[
        [tuple(row) not in keys for row in full[KEYS].itertuples(index=False, name=None)]
    ]
    if len(preserved) + len(selected) != 381:
        raise RuntimeError("hybrid is not exactly 381 findings")
    return {
        "specialist_categories": CATEGORIES if include_1c else ATTENTION_CATEGORIES,
        "specialist_findings": len(selected),
        "baseline_preserved_findings": len(preserved),
        "overall_381_dice": float((preserved.global_dice.sum() + selected.global_dice.sum()) / 381),
        "overall_381_hits": int(preserved.global_hit.astype(bool).sum() + selected.global_hit.astype(bool).sum()),
        "non_selected_findings_exactly_preserved": True,
    }


def final() -> None:
    trajectory, per_category, frames = build_tables()
    best_update = int(trajectory.loc[trajectory.mean_dice.idxmax(), "update"])
    best = frames[best_update]
    reference = frames[REFERENCE_UPDATE]
    comparison = paired(best, reference)
    category_delta = {
        category: float(
            best[best.category.eq(category)].global_dice.mean()
            - reference[reference.category.eq(category)].global_dice.mean()
        )
        for category in CATEGORIES
    }
    best_summary = summary(best)
    reference_summary = summary(reference)
    core_delta = float((category_delta["2b"] + category_delta["2c"]) / 2.0)
    improved = bool(best_update != REFERENCE_UPDATE and comparison["mean_dice_delta"] > 0)
    health_checks = {
        "2b_2c_mean_delta_nonnegative": core_delta >= 0,
        "precision_stable": best_summary["precision"] >= reference_summary["precision"] - 0.02,
        "volume_controlled": best_summary["predicted_GT_volume_ratio"] <= 1.15 * reference_summary["predicted_GT_volume_ratio"],
        "hits_stable_or_improved": best_summary["hits"] >= reference_summary["hits"],
        "not_single_finding_dominated": not comparison["single_finding_dominated"],
    }
    healthy = bool(improved and all(health_checks.values()))
    all_five = hybrid(best, include_1c=True)
    safe_no1c = hybrid(best, include_1c=False)
    baseline = pd.read_csv(BASELINE_PATH)
    baseline_summary = {
        "overall_381_dice": float(baseline.global_dice.mean()),
        "overall_381_hits": int(baseline.global_hit.astype(bool).sum()),
    }
    write_json("best_checkpoint.json", {
        "selected_update": best_update,
        "selection_metric": "136-finding specialist-pool mean Dice under the 1c-disabled S3 policy",
        "checkpoint": str((OUT / f"checkpoints/checkpoint_update_{best_update}.pth").resolve()) if best_update != 3500 else str((SOURCE / "checkpoints/checkpoint_update_3500.pth").resolve()),
        "specialist_metrics": best_summary,
        "reference_update3500_metrics": reference_summary,
        "comparison_to_reference": comparison,
        "per_category_dice_delta_vs_reference": category_delta,
        "improved_beyond_reference": improved,
        "healthy": healthy,
        "health_checks": health_checks,
    })
    write_json("hybrid_summary.json", {
        "selected_update": best_update,
        "baseline10000": baseline_summary,
        "all_five_specialist_hybrid": all_five,
        "deployment_safe_no1c_hybrid": safe_no1c,
    })
    write_json("decision.json", {
        "selected_update": best_update,
        "evaluated_updates": trajectory.update.astype(int).tolist(),
        "improves_over_no1c_attention3500": improved,
        "selected_checkpoint_healthy": healthy,
        "health_checks": health_checks,
        "selection_rule": "best specialist-pool Dice, then report deployability health using the same core-category/precision/volume/hits/influence criteria as the current continuation",
        "stage1_gate": json.loads((OUT / "gate_stage1.json").read_text()) if (OUT / "gate_stage1.json").is_file() else None,
        "stage2_gate": json.loads((OUT / "gate_stage2.json").read_text()) if (OUT / "gate_stage2.json").is_file() else None,
        "recommended_full381_policy": "deployment_safe_no1c_hybrid",
    })
    rows = [
        "# Half-LR attention continuation with 1c S3 disabled", "",
        f"Best evaluated update: **{best_update}**.",
        f"Specialist-pool Dice: **{best_summary['mean_dice']:.6f}**; healthy: **{healthy}**.",
        f"Full-381 hybrid (all five specialist outputs): **{all_five['overall_381_dice']:.6f}**, {all_five['overall_381_hits']} hits.",
        f"Deployment-safe hybrid (1c baseline): **{safe_no1c['overall_381_dice']:.6f}**, {safe_no1c['overall_381_hits']} hits.", "",
        "See `attention_trajectory.csv` and `per_category_trajectory.csv` for checkpoint/category details.",
    ]
    (OUT / "report.md").write_text("\n".join(rows) + "\n")


def register(args: argparse.Namespace) -> None:
    write_json("jobs.json", {
        "reference_eval_3500": args.reference_eval,
        "stage1_train_to4500": args.train1,
        "stage1_eval_4000_4500": args.eval1,
        "stage1_gate": args.gate1,
        "stage2_train_to5500": args.train2,
        "stage2_eval_5000_5500": args.eval2,
        "stage2_gate": args.gate2,
        "stage3_train_to6000": args.train3,
        "stage3_eval_6000": args.eval3,
        "final_analysis": args.final_job,
    })


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["prepare", "gate1", "gate2", "final", "register"])
    for name in ("reference_eval", "train1", "eval1", "gate1", "train2", "eval2", "gate2", "train3", "eval3", "final_job"):
        parser.add_argument(f"--{name.replace('_', '-')}")
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare()
    elif args.mode == "gate1":
        gate(1)
    elif args.mode == "gate2":
        gate(2)
    elif args.mode == "final":
        final()
    else:
        register(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
