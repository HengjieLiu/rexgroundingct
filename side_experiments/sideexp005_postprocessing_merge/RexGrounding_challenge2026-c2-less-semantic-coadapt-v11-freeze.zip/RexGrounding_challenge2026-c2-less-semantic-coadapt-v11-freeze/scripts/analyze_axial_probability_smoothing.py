#!/usr/bin/env python3
"""Compare controlled axial-probability-smoothing ReX evaluations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REFERENCE = (
    ROOT
    / "outputs/s3_1over1_allcat_v11_e1e-5_d1e-4_s3e1e-4_1gpu_bs1_acc4_10kupd"
    / "full_volume/update_09000"
)


def sigma_label(sigma: float) -> str:
    return f"sigma_{sigma:.1f}mm".replace(".", "p")


def read_summary(eval_dir: Path) -> dict:
    return json.loads((eval_dir / "eval_rexrank_metrics_global.json").read_text())["summary"]


def compare_predictions(reference: Path, candidate: Path) -> dict:
    reference_files = {path.name for path in reference.glob("*.nii.gz")}
    candidate_files = {path.name for path in candidate.glob("*.nii.gz")}
    if reference_files != candidate_files:
        raise RuntimeError(
            f"Prediction file mismatch: missing={sorted(reference_files-candidate_files)[:3]} "
            f"extra={sorted(candidate_files-reference_files)[:3]}"
        )
    differing_voxels = 0
    differing_files: list[str] = []
    for name in sorted(reference_files):
        left = np.asanyarray(nib.load(str(reference / name)).dataobj)
        right = np.asanyarray(nib.load(str(candidate / name)).dataobj)
        if left.shape != right.shape:
            raise RuntimeError(f"Shape mismatch for {name}: {left.shape} vs {right.shape}")
        changed = int(np.count_nonzero(left != right))
        differing_voxels += changed
        if changed:
            differing_files.append(name)
    return {
        "files": len(reference_files),
        "differing_voxels": differing_voxels,
        "differing_files": differing_files,
        "voxelwise_identical": differing_voxels == 0,
    }


def metric_identity(reference: Path, candidate: Path) -> dict:
    left, right = read_summary(reference), read_summary(candidate)
    keys = [
        "total_cases",
        "total_findings",
        "total_hits",
        "total_misses",
        "hit_rate",
        "mean_global_dice_per_finding",
        "mean_global_dice_per_case",
    ]
    differences = {key: [left[key], right[key]] for key in keys if left[key] != right[key]}
    return {"metric_identical": not differences, "differences": differences}


def finding_table(eval_dir: Path) -> pd.DataFrame:
    table = pd.read_csv(eval_dir / "summary_tables/per_finding_metrics.csv")
    keys = ["file", "finding_idx"]
    if table.duplicated(keys).any():
        raise RuntimeError(f"Duplicate finding keys in {eval_dir}")
    return table


def top_rows(frame: pd.DataFrame, ascending: bool) -> list[dict]:
    columns = [
        "file",
        "finding_idx",
        "category_baseline",
        "global_dice_baseline",
        "global_dice_smoothed",
        "dice_delta",
        "gt_voxels_baseline",
        "pred_voxels_baseline",
        "pred_voxels_smoothed",
        "pred_volume_delta_mm3",
    ]
    return json.loads(
        frame.sort_values("dice_delta", ascending=ascending).loc[:, columns].head(3).to_json(
            orient="records"
        )
    )


def paired_result(baseline: pd.DataFrame, candidate: pd.DataFrame, summary: dict) -> dict:
    keys = ["file", "finding_idx"]
    merged = baseline.merge(candidate, on=keys, suffixes=("_baseline", "_smoothed"))
    if len(merged) != len(baseline) or len(merged) != len(candidate):
        raise RuntimeError("Finding tables do not have the same keys")
    merged["dice_delta"] = (
        merged["global_dice_smoothed"] - merged["global_dice_baseline"]
    )
    merged["pred_volume_delta_mm3"] = (
        (merged["pred_voxels_smoothed"] - merged["pred_voxels_baseline"])
        * merged["voxel_volume_mm3_baseline"]
    )
    tolerance = 1e-12
    improved = int((merged["dice_delta"] > tolerance).sum())
    worsened = int((merged["dice_delta"] < -tolerance).sum())
    unchanged = int(len(merged) - improved - worsened)
    volume_delta = merged["pred_volume_delta_mm3"]
    examples = {}
    for label, selector in {
        "improved": merged["dice_delta"] > tolerance,
        "unchanged": merged["dice_delta"].abs() <= tolerance,
        "worsened": merged["dice_delta"] < -tolerance,
    }.items():
        rows = merged.loc[selector]
        if len(rows):
            examples[label] = top_rows(rows, ascending=(label == "worsened"))[0]
        else:
            examples[label] = None
    return {
        "cases": int(summary["total_cases"]),
        "findings": int(summary["total_findings"]),
        "mean_dice_per_finding": float(summary["mean_global_dice_per_finding"]),
        "mean_dice_per_case": float(summary["mean_global_dice_per_case"]),
        "hit_count": int(summary["total_hits"]),
        "hit_rate": float(summary["hit_rate"]),
        "mean_dice_delta": float(merged["dice_delta"].mean()),
        "median_dice_delta": float(merged["dice_delta"].median()),
        "findings_improved": improved,
        "findings_unchanged": unchanged,
        "findings_worsened": worsened,
        "mean_absolute_predicted_volume_change_mm3": float(volume_delta.abs().mean()),
        "median_predicted_volume_change_mm3": float(volume_delta.median()),
        "masks_volume_increased_percent": float((volume_delta > 0).mean() * 100),
        "masks_volume_decreased_percent": float((volume_delta < 0).mean() * 100),
        "largest_improvements": top_rows(merged, ascending=False),
        "largest_degradations": top_rows(merged, ascending=True),
        "representative_examples": examples,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-root", type=Path, required=True)
    parser.add_argument("--reference-dir", type=Path, default=DEFAULT_REFERENCE)
    parser.add_argument("--sigmas-mm", type=float, nargs="+", default=[0.0, 0.5, 1.0, 1.5])
    parser.add_argument("--update", type=int, default=9000)
    parser.add_argument("--output-json", type=Path, default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = args.experiment_root.resolve()
    reference = args.reference_dir.resolve()
    results: dict[str, object] = {
        "reference_dir": str(reference),
        "experiment_root": str(root),
        "sigma_results": {},
    }
    output = args.output_json or root / "fixed30_smoothing_report.json"
    dirs = {
        sigma: root / sigma_label(sigma) / "full_volume" / f"update_{args.update:05d}"
        for sigma in args.sigmas_mm
    }
    for sigma, directory in dirs.items():
        if not (directory / "eval_rexrank_metrics_global.json").is_file():
            raise FileNotFoundError(f"Incomplete evaluation for sigma={sigma}: {directory}")
    zero = dirs[0.0]
    if reference == zero.resolve():
        voxel_check = {
            "files": len(list(zero.glob("*.nii.gz"))),
            "differing_voxels": 0,
            "differing_files": [],
            "voxelwise_identical": True,
        }
    else:
        voxel_check = compare_predictions(reference, zero)
    metric_check = metric_identity(reference, zero)
    results["sigma_zero_regression"] = {**voxel_check, **metric_check}
    if not voxel_check["voxelwise_identical"] or not metric_check["metric_identical"]:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(results, indent=2) + "\n")
        raise RuntimeError(json.dumps(results["sigma_zero_regression"], indent=2))

    baseline = finding_table(zero)
    for sigma, directory in dirs.items():
        results["sigma_results"][f"{sigma:g}"] = paired_result(
            baseline, finding_table(directory), read_summary(directory)
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
