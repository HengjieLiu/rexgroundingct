#!/usr/bin/env python3
"""Paired native-vs-in-plane-resampled ReX full-volume inference audit.

The intervention is deliberately narrow: validation cases above a threshold in
native in-plane spacing are upsampled in X/Y to the training-set median spacing.
Z is untouched.  Resampled probabilities are mapped back to the native cropped
grid and every metric is computed against the untouched native-grid GT.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm


ROOT = Path(__file__).resolve().parents[1]
for candidate in (ROOT / "VoxTell", ROOT / "nnUNet", ROOT / "scripts"):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from audit_rex_original_canonical_fullval import (  # noqa: E402
    ranking_metrics,
    stable_seed,
    stratified_indices,
)
from audit_rex_prompt_variant_inference import (  # noqa: E402
    binary_dice,
    probability_correlation,
    prompt_metrics,
)
from prepare_rex_measurement_ablation import (  # noqa: E402
    contains_explicit_measurement,
    measurement_values_mm,
)
from run_voxtell_rex_inference import (  # noqa: E402
    load_entries,
    load_image,
    load_reference_mask_for_window_diagnostic,
    select_entries,
    sorted_finding_keys,
)
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402
from voxtell.utils.prompt_embedding_cache import load_embedding_cache  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rex-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument(
        "--spacing-manifest",
        type=Path,
        default=ROOT / "data/rex_voxtell_preprocessed_v1/manifest.jsonl",
    )
    parser.add_argument("--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--mask-dir", type=Path, default=ROOT / "data/segmentations")
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--embedding-cache", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--coarse-threshold-mm",
        type=float,
        default=None,
        help="Mean native X/Y spacing cutoff; default is the training-set 75th percentile.",
    )
    parser.add_argument(
        "--target-spacing-mm",
        type=float,
        default=None,
        help="Target X/Y spacing; default is the training-set median mean X/Y spacing.",
    )
    parser.add_argument("--thresholds", nargs="+", type=float, default=[0.5])
    parser.add_argument("--num-shards", type=int, default=None)
    parser.add_argument("--shard-id", type=int, default=None)
    parser.add_argument("--max-ranking-voxels-per-class", type=int, default=50_000)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--text-encoding-model", default="Qwen/Qwen3-Embedding-4B")
    return parser.parse_args()


def load_spacing_manifest(path: Path) -> dict[str, dict[str, tuple[float, float, float]]]:
    result: dict[str, dict[str, tuple[float, float, float]]] = {}
    with path.open() as handle:
        for line in handle:
            row = json.loads(line)
            spacing = tuple(float(value) for value in row["spacing"])
            if len(spacing) != 3 or any(not np.isfinite(value) or value <= 0 for value in spacing):
                raise ValueError(f"Invalid spacing for {row['case']}: {spacing}")
            result.setdefault(str(row["split"]), {})[str(row["case"])] = spacing
    return result


def cohort_parameters(
    spacing_by_split: dict[str, dict[str, tuple[float, float, float]]],
    coarse_threshold_mm: float | None,
    target_spacing_mm: float | None,
) -> tuple[float, float]:
    train = np.asarray(list(spacing_by_split["train"].values()), dtype=np.float64)
    train_inplane = train[:, :2].mean(axis=1)
    coarse = (
        float(np.quantile(train_inplane, 0.75))
        if coarse_threshold_mm is None
        else float(coarse_threshold_mm)
    )
    target = float(np.median(train_inplane)) if target_spacing_mm is None else float(target_spacing_mm)
    if not 0 < target < coarse:
        raise ValueError(f"Expected 0 < target spacing < coarse cutoff, got target={target}, cutoff={coarse}")
    return coarse, target


def resampled_inplane_shape(
    shape_dhw: tuple[int, int, int],
    spacing_xy_mm: tuple[float, float],
    target_xy_mm: tuple[float, float],
) -> tuple[int, int, int]:
    depth, height, width = map(int, shape_dhw)
    spacing_x, spacing_y = map(float, spacing_xy_mm)
    target_x, target_y = map(float, target_xy_mm)
    new_height = max(1, int(round(height * spacing_y / target_y)))
    new_width = max(1, int(round(width * spacing_x / target_x)))
    return depth, new_height, new_width


def resize_4d_channels(values: torch.Tensor, shape_dhw: tuple[int, int, int]) -> torch.Tensor:
    """Trilinearly resize a (C, D, H, W) tensor without changing channels."""
    if values.ndim != 4:
        raise ValueError(f"Expected (C,D,H,W), got {tuple(values.shape)}")
    if tuple(values.shape[1:]) == tuple(shape_dhw):
        return values.clone()
    return F.interpolate(
        values[None].float(), size=shape_dhw, mode="trilinear", align_corners=False
    )[0]


def prefix_metrics(prefix: str, metrics: dict[str, float]) -> dict[str, float]:
    return {f"{prefix}_{key}": value for key, value in metrics.items()}


def main() -> int:
    args = parse_args()
    thresholds = sorted(set(float(value) for value in args.thresholds))
    if not thresholds or any(not 0 < value < 1 for value in thresholds):
        raise ValueError(f"Invalid thresholds: {thresholds}")

    world_size = args.num_shards or int(os.environ.get("WORLD_SIZE", "1"))
    rank = args.shard_id if args.shard_id is not None else int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", str(args.gpu)))
    if rank < 0 or rank >= world_size:
        raise ValueError(f"shard-id {rank} is outside [0, {world_size})")

    spacing_by_split = load_spacing_manifest(args.spacing_manifest)
    coarse_cutoff, target_spacing = cohort_parameters(
        spacing_by_split, args.coarse_threshold_mm, args.target_spacing_mm
    )
    val_spacing = spacing_by_split["val"]
    all_val_entries = select_entries(load_entries(args.rex_json, ["val"]), args.image_dir, None, None)
    selected = [
        entry
        for entry in all_val_entries
        if np.mean(val_spacing[entry["name"]][:2]) > coarse_cutoff
    ]
    entries = [entry for index, entry in enumerate(selected) if index % world_size == rank]
    if not selected:
        raise RuntimeError("The coarse-spacing rule selected no validation cases")

    shard_dir = args.output_dir / f"shard_{rank:02d}" if world_size > 1 else args.output_dir
    shard_dir.mkdir(parents=True, exist_ok=True)
    if rank == 0:
        train_values = np.asarray(list(spacing_by_split["train"].values()), dtype=np.float64)
        val_values = np.asarray(list(val_spacing.values()), dtype=np.float64)
        (args.output_dir / "cohort.json").write_text(json.dumps({
            "selection_rule": "validation mean(X,Y) spacing > training 75th percentile",
            "target_rule": "resample X/Y to training median mean(X,Y) spacing; preserve Z",
            "training_cases": int(train_values.shape[0]),
            "validation_cases": int(val_values.shape[0]),
            "training_inplane_median_mm": float(np.median(train_values[:, :2].mean(axis=1))),
            "training_inplane_q75_mm": float(np.quantile(train_values[:, :2].mean(axis=1), 0.75)),
            "coarse_cutoff_mm": coarse_cutoff,
            "target_spacing_xy_mm": [target_spacing, target_spacing],
            "selected_cases": len(selected),
            "cases": [entry["name"] for entry in selected],
        }, indent=2) + "\n")

    cache = load_embedding_cache(args.embedding_cache)["mapping"]
    device = torch.device(f"cuda:{local_rank}" if args.device == "cuda" else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(device)
    predictor = VoxTellPredictor(
        str(args.model_dir),
        device,
        args.text_encoding_model,
        checkpoint_path=str(args.checkpoint),
        load_text_backbone=False,
    )
    predictor.network.eval()

    rows: list[dict] = []
    for entry in tqdm(entries, desc=f"In-plane resampling audit shard {rank}", unit="case"):
        case = entry["name"]
        spacing_xyz = val_spacing[case]
        image, properties = load_image(args.image_dir / case)
        property_spacing_xyz = tuple(float(value) for value in properties["spacing"])[::-1]
        if not np.allclose(spacing_xyz, property_spacing_xyz, atol=1e-5, rtol=1e-5):
            raise ValueError(
                f"Spacing mismatch for {case}: manifest={spacing_xyz}, reader={property_spacing_xyz}"
            )
        data, bbox, original_shape = predictor.preprocess(image)
        native_shape = tuple(int(value) for value in data.shape[1:])
        resampled_shape = resampled_inplane_shape(
            native_shape, spacing_xyz[:2], (target_spacing, target_spacing)
        )
        resampled_data = resize_4d_channels(data, resampled_shape)
        finding_keys = sorted_finding_keys(entry)
        embeddings = torch.stack([
            cache[(entry["_split"], case, int(finding_idx))] for finding_idx in finding_keys
        ])[None].to(device)
        gt = load_reference_mask_for_window_diagnostic(
            args.mask_dir / case,
            len(finding_keys),
            tuple(original_shape),
            bbox,
            image_properties=properties,
        )
        if gt is None:
            raise ValueError(f"Could not align native GT for {case}")
        target = gt.numpy().astype(bool, copy=False)

        native_logits = predictor.predict_sliding_window_return_logits(data, embeddings)
        native_probability_t = torch.sigmoid(native_logits.float()).cpu()
        del native_logits
        resampled_logits = predictor.predict_sliding_window_return_logits(resampled_data, embeddings)
        resampled_probability_t = torch.sigmoid(resampled_logits.float()).cpu()
        del resampled_logits
        resampled_back_t = resize_4d_channels(resampled_probability_t, native_shape)
        sham_back_t = resize_4d_channels(
            resize_4d_channels(native_probability_t, resampled_shape), native_shape
        )
        native_probability = native_probability_t.numpy()
        resampled_probability = resampled_back_t.numpy()
        sham_probability = sham_back_t.numpy()

        achieved_spacing_y = spacing_xyz[1] * native_shape[1] / resampled_shape[1]
        achieved_spacing_x = spacing_xyz[0] * native_shape[2] / resampled_shape[2]
        categories = entry.get("categories") or {}
        findings = entry.get("findings") or {}
        voxel_mm3 = float(np.prod(spacing_xyz))
        for channel, finding_idx_text in enumerate(finding_keys):
            finding_idx = int(finding_idx_text)
            prompt = str(findings[finding_idx_text])
            measurement_values = (
                measurement_values_mm(prompt) if contains_explicit_measurement(prompt) else []
            )
            gt_channel = target[channel]
            positive, negative = stratified_indices(
                gt_channel,
                args.max_ranking_voxels_per_class,
                stable_seed(case, finding_idx, args.seed),
            )
            ranking_by_variant = {
                "native": ranking_metrics(native_probability[channel], positive, negative),
                "resampled": ranking_metrics(resampled_probability[channel], positive, negative),
                "sham": ranking_metrics(sham_probability[channel], positive, negative),
            }
            base = {
                "case": case,
                "finding_idx": finding_idx,
                "category": str(categories.get(finding_idx_text, "unknown")),
                "prompt": prompt,
                "gt_voxels": int(gt_channel.sum()),
                "has_explicit_measurement": bool(measurement_values),
                "measurement_values_mm": json.dumps(measurement_values),
                "maximum_measurement_mm": max(measurement_values) if measurement_values else float("nan"),
                "exact_3mm": any(abs(value - 3.0) < 1e-9 for value in measurement_values),
                "spacing_x_mm": spacing_xyz[0],
                "spacing_y_mm": spacing_xyz[1],
                "spacing_z_mm": spacing_xyz[2],
                "source_mean_inplane_spacing_mm": float(np.mean(spacing_xyz[:2])),
                "target_spacing_x_mm": target_spacing,
                "target_spacing_y_mm": target_spacing,
                "achieved_spacing_x_mm": achieved_spacing_x,
                "achieved_spacing_y_mm": achieved_spacing_y,
                "native_shape_dhw": json.dumps(native_shape),
                "resampled_shape_dhw": json.dumps(resampled_shape),
                "ranking_positive_samples": int(positive.size),
                "ranking_negative_samples": int(negative.size),
                **prefix_metrics("native", ranking_by_variant["native"]),
                **prefix_metrics("resampled", ranking_by_variant["resampled"]),
                **prefix_metrics("sham", ranking_by_variant["sham"]),
                "resampled_probability_correlation_to_native": probability_correlation(
                    resampled_probability[channel], native_probability[channel]
                ),
                "resampled_probability_mad_to_native": float(np.mean(np.abs(
                    resampled_probability[channel] - native_probability[channel]
                ))),
                "sham_probability_correlation_to_native": probability_correlation(
                    sham_probability[channel], native_probability[channel]
                ),
                "sham_probability_mad_to_native": float(np.mean(np.abs(
                    sham_probability[channel] - native_probability[channel]
                ))),
            }
            for threshold in thresholds:
                native_metrics = prompt_metrics(
                    native_probability[channel], gt_channel, threshold, voxel_mm3
                )
                resampled_metrics = prompt_metrics(
                    resampled_probability[channel], gt_channel, threshold, voxel_mm3
                )
                sham_metrics = prompt_metrics(
                    sham_probability[channel], gt_channel, threshold, voxel_mm3
                )
                rows.append({
                    **base,
                    "threshold": threshold,
                    **prefix_metrics("native", native_metrics),
                    **prefix_metrics("resampled", resampled_metrics),
                    **prefix_metrics("sham", sham_metrics),
                    "resampled_hit": resampled_metrics["dice"] >= 0.1,
                    "native_hit": native_metrics["dice"] >= 0.1,
                    "sham_hit": sham_metrics["dice"] >= 0.1,
                    "resampled_prediction_dice_to_native": binary_dice(
                        resampled_probability[channel] > threshold,
                        native_probability[channel] > threshold,
                    ),
                    "sham_prediction_dice_to_native": binary_dice(
                        sham_probability[channel] > threshold,
                        native_probability[channel] > threshold,
                    ),
                })

        del embeddings, data, resampled_data, gt
        del native_probability_t, resampled_probability_t, resampled_back_t, sham_back_t
        if device.type == "cuda":
            torch.cuda.empty_cache()

    output_csv = shard_dir / "per_finding_threshold_metrics.csv"
    with output_csv.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    manifest = {
        "rank": rank,
        "world_size": world_size,
        "cases": len(entries),
        "case_names": [entry["name"] for entry in entries],
        "findings": len({(row["case"], row["finding_idx"]) for row in rows}),
        "rows": len(rows),
        "thresholds": thresholds,
        "coarse_cutoff_mm": coarse_cutoff,
        "target_spacing_xy_mm": [target_spacing, target_spacing],
        "checkpoint": str(args.checkpoint.resolve()),
        "output_csv": str(output_csv.resolve()),
    }
    (shard_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
