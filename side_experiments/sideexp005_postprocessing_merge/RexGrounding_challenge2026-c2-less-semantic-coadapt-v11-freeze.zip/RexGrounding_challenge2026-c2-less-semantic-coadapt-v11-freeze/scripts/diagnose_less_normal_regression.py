"""Reproduce legacy baseline, then gate deterministic baseline vs hooks."""
import json
from pathlib import Path
import sys
import numpy as np
import audit_less_minimal_mechanism as audit


def compare(a,b):
    with np.load(a) as p:x=p['probability']
    with np.load(b) as p:y=p['probability']
    assert x.shape==y.shape
    x=x.reshape(-1);y=y.reshape(-1)
    maximum=total=count=0
    for start in range(0,len(x),1048576):
        a=x[start:start+1048576].astype(np.float64);b=y[start:start+1048576].astype(np.float64)
        d=np.abs(a-b);maximum=max(maximum,float(d.max()));total+=float(d.sum())
        count+=int(np.count_nonzero((a>.5)!=(b>.5)))
    return {'max_abs':maximum,'mean_abs':total/len(x),'threshold_disagreement_voxels':count,'voxels':len(x)}


def main():
    root=audit.OUT
    mapping=json.loads((root/'wrong_less_mapping.json').read_text())
    cases=mapping['_feature_cases']
    # Repeating the old default alone tests whether the failure needs a hook.
    legacy=root/'3000/legacy_repeat'
    if not (legacy/'manifest.json').exists():
        audit.command([sys.executable,audit.ROOT/'scripts/run_voxtell_rex_inference.py',
            '--rex-json',audit.MANIFEST,'--splits','val','--image-dir',audit.ROOT/'data/ct_rate_volumes_fixed',
            '--reference-mask-dir',audit.ROOT/'data/segmentations','--model-dir',root/'3000/model',
            '--prompt-embedding-cache',audit.PROMPTS,'--token-feature-cache',audit.CACHE,
            '--text-representation','qwen','--output-dir',legacy,'--device','cuda','--amp-dtype','bfloat16',
            '--threshold','0.5','--presence-logit-weight','0','--spatial-attention-rho-scale','1','--overwrite',
            '--cases',*cases,'--probability-output-dir',legacy/'probabilities'])
    default=audit.infer(3000,'default','regression',cases,True)
    normal=audit.infer(3000,'normal','regression',cases)
    rows=[]
    old=audit.ROOT/'less_minimal_mechanism_audit/3000/regression'
    for case in cases:
        name=case.removesuffix('.nii.gz')+'.npz'
        rows.append({'case':case,
          'legacy_default_vs_legacy_repeat':compare(old/'default/probabilities'/name,legacy/'probabilities'/name),
          'old_hook_vs_legacy_repeat':compare(old/'normal/probabilities'/name,legacy/'probabilities'/name),
          'deterministic_default_vs_hook':compare(default/'probabilities'/name,normal/'probabilities'/name),
          'legacy_vs_deterministic_default':compare(legacy/'probabilities'/name,default/'probabilities'/name)})
    passed=all(r['deterministic_default_vs_hook']['max_abs']<=1e-6 and
               r['deterministic_default_vs_hook']['threshold_disagreement_voxels']==0 for r in rows)
    audit.save(root/'normal_regression_diagnosis.json',{'passed':passed,'rows':rows,
        'controls':'fixed RNG1701; cudnn benchmark=False, deterministic=True at inference call; deterministic algorithms; CUBLAS_WORKSPACE_CONFIG=:4096:8; BF16 unchanged'})
    print(json.dumps(rows,indent=2),flush=True)
    assert passed, 'Deterministic normal/hook regression still fails; stop, do not loosen gate'
    # The full audit rechecks main pathway hashes/bypass/wrong and all updates.
    audit.run()


if __name__=='__main__':main()
