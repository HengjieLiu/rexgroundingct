#!/usr/bin/env python3
"""Validate final study artifacts and write inventory/job audit files."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
JOB_IDS = (
    5334001, 5334002, 5334005, 5334006, 5334009,
    5334010, 5334011, 5334012, 5334067,
    5334104, 5334105, 5334106, 5334107,
    5334131, 5334132, 5334133, 5334134,
    5334170, 5334171, 5334172, 5334173,
    5334391, 5334392, 5334393, 5334405, 5334406, 5334428, 5334435,
)
USED_JOBS = {5334009, 5334170, 5334391, 5334405, 5334435}
MANUAL_NOTES = {
    5334001: "replay-key tuple/list normalization false failure; no result used",
    5334010: "stopped when a legacy P1/zero binary boundary reference was noticed; quarantined outside final root; no result used",
    5334104: "filesystem metadata race after quarantining partial output; no result used",
    5334131: "stopped to replace a data-only manifest located under a P1-named directory; quarantined outside final root; no result used",
    5334171: "cached text singleton dimension not squeezed in analysis-only manual forward; no result used",
    5334392: "all controls computed but aggregate CSV union fields failed; full clean retry 5334405 used",
    5334406: "directional-only output channels incompatible with reference NIfTI channel count; no result used",
    5334428: "runner disallows preserve-reference-channels with probability archives; no result used",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    out = args.output_root
    expected_counts = {
        "cohort_manifest.csv": 49,
        "inference_ablation_results.csv": 13 * 49,
        "native_voxtell_scores.csv": 3 * 49,
        "native_internal_response_scores.csv": 5 * 49,
        "control_per_finding.csv": 7 * 3 * 49,
        "prompt_swap_manifest.csv": 25,
        "p0_prompt_swap_results.csv": 25,
        "native_prompt_swap_results.csv": 25,
        "paired_comparisons.csv": 9,
        "secondary_comparisons.csv": 10,
    }
    count_audit = {}
    for filename, expected in expected_counts.items():
        actual = len(read_csv(out / filename))
        count_audit[filename] = {"expected": expected, "actual": actual, "passed": actual == expected}
    manifest = json.loads((out / "fixed30_rex_manifest.json").read_text())
    if manifest["provenance"].get("p1_artifacts_used") is not False:
        raise AssertionError("Final inference manifest is not explicitly P1-free")
    native_manifest = json.loads((out / "native_voxtell_predictions/manifest.json").read_text())
    native_completed = sum(row.get("status") in {"done", "completed"} for row in native_manifest)
    count_audit["native_voxtell_predictions/manifest.json"] = {
        "expected": 30, "actual": native_completed, "passed": native_completed == 30
    }
    if not all(row["passed"] for row in count_audit.values()):
        raise AssertionError(f"Artifact count audit failed: {count_audit}")

    sacct = subprocess.check_output(
        [
            "sacct", "-j", ",".join(map(str, JOB_IDS)), "-X", "-n", "-P",
            "--format=JobIDRaw,JobName,State,Elapsed,ExitCode,NodeList",
        ],
        text=True,
    )
    job_rows = []
    for line in sacct.splitlines():
        if not line.strip():
            continue
        fields = line.split("|")
        job_id = int(fields[0])
        job_rows.append(
            {
                "job_id": job_id,
                "job_name": fields[1],
                "state": fields[2],
                "elapsed": fields[3],
                "exit_code": fields[4],
                "node": fields[5],
                "used_for_final_results": job_id in USED_JOBS,
                "note": MANUAL_NOTES.get(job_id, "final clean job" if job_id in USED_JOBS else "dependency/canceled retry chain; no result used"),
            }
        )
    with (out / "slurm_job_audit.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(job_rows[0])); writer.writeheader(); writer.writerows(job_rows)

    inventory = []
    for path in sorted(value for value in out.rglob("*") if value.is_file()):
        size = path.stat().st_size
        inventory.append(
            {
                "relative_path": str(path.relative_to(out)),
                "size_bytes": size,
                "sha256": sha256(path) if size <= 1_000_000 else "SKIPPED_GT_1MB",
            }
        )
    with (out / "artifact_inventory.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(inventory[0])); writer.writeheader(); writer.writerows(inventory)
    audit = {
        "schema": "aca_p0_incremental_final_audit_v1",
        "passed": True,
        "count_audit": count_audit,
        "used_job_ids": sorted(USED_JOBS),
        "p1_checkpoint_loaded": False,
        "p1_artifacts_in_final_scoring_path": False,
        "rejected_attempt_quarantine": str((ROOT / "outputs/aca_p0_incremental_rejected_attempts_20260731T213256Z").resolve()),
        "quarantine_used_for_results": False,
        "code_sources": {
            str(path.relative_to(ROOT)): sha256(path)
            for path in sorted((ROOT / "scripts").glob("aca_p0_incremental_*"))
            if path.is_file()
        },
    }
    (out / "final_audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
