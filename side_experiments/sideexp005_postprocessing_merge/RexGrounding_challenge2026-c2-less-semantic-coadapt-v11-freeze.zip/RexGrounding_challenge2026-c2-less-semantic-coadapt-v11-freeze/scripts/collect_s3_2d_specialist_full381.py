#!/usr/bin/env python3
"""Combine specialist 2d metrics with frozen original S3 non-2d metrics."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/s3_2d_specialist_fast_comparison"
ORIGINAL = ROOT / "outputs/controlled_v11_selected_full200/s3_update9000/per_finding_metrics.csv"
MASTER = ROOT / "outputs/baseline_vs_s3_9000_failure_mode_audit/per_finding_failure_mode_master.csv"


def load_specialist(arm: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    run = ROOT / f"outputs/s3_2d_specialist_{arm}_fast/full381/update_300"
    seg = pd.read_csv(run / "per_finding_metrics.csv").rename(columns={"file": "case_id", "finding_idx": "finding_id"})
    det = pd.read_csv(run / "detection_metrics.csv")
    return seg, det


def hybrid(original: pd.DataFrame, specialist: pd.DataFrame) -> pd.DataFrame:
    keys = ["case_id", "finding_id"]
    value = original.set_index(keys).copy()
    replacement = specialist.set_index(keys)
    common = [column for column in replacement if column in value]
    value.loc[replacement.index, common] = replacement[common]
    value = value.reset_index()
    if len(value) != 381 or value.duplicated(keys).any():
        raise AssertionError("Hybrid metrics must contain exactly 381 unique findings")
    return value


def main() -> int:
    keys = ["case_id", "finding_id"]
    original = pd.read_csv(ORIGINAL).rename(columns={"file": "case_id", "finding_idx": "finding_id"})
    l2d, ldet = load_specialist("L"); ld2d, lddet = load_specialist("LD")
    l, ld = hybrid(original, l2d), hybrid(original, ld2d)
    paired = l.merge(ld, on=keys, suffixes=("_L", "_LD"), validate="one_to_one")
    paired["dice_delta"] = paired.global_dice_LD - paired.global_dice_L
    paired["hit_delta"] = paired.global_hit_LD.astype(int) - paired.global_hit_L.astype(int)
    master = pd.read_csv(MASTER)[keys + ["category", "gt_voxels", "multiplicity_group"]]
    paired = paired.merge(master, on=keys, validate="one_to_one")
    groups = {
        "overall": np.ones(len(paired), dtype=bool),
        "2d": paired.category.astype(str).eq("2d"),
        "2d-small": paired.category.astype(str).eq("2d") & paired.gt_voxels.between(100, 999),
        "2d-small-single": paired.category.astype(str).eq("2d") & paired.gt_voxels.between(100, 999) & paired.multiplicity_group.astype(str).eq("single"),
        "2d-small-few": paired.category.astype(str).eq("2d") & paired.gt_voxels.between(100, 999) & paired.multiplicity_group.astype(str).eq("few_2_3"),
        "2d-small-multiple": paired.category.astype(str).eq("2d") & paired.gt_voxels.between(100, 999) & paired.multiplicity_group.astype(str).eq("multiple_ge4"),
        "2d-medium-large": paired.category.astype(str).eq("2d") & ~paired.gt_voxels.between(100, 999),
    }
    rows = []
    for group, mask in groups.items():
        values = paired.loc[mask]
        rows.append({
            "group": group, "n": len(values),
            "L_dice": float(values.global_dice_L.mean()), "LD_dice": float(values.global_dice_LD.mean()),
            "dice_delta": float(values.dice_delta.mean()),
            "L_hits": int(values.global_hit_L.sum()), "LD_hits": int(values.global_hit_LD.sum()),
            "new_hits": int((values.hit_delta == 1).sum()), "lost_hits": int((values.hit_delta == -1).sum()),
            "improved": int((values.dice_delta > 1e-12).sum()), "degraded": int((values.dice_delta < -1e-12).sum()),
            "tied": int((values.dice_delta.abs() <= 1e-12).sum()),
        })
    pd.DataFrame(rows).to_csv(OUT / "full381_group_summary.csv", index=False)
    paired.to_csv(OUT / "full381_paired_findings.csv", index=False)
    case_delta = paired.groupby("case_id").dice_delta.mean().to_numpy()
    rng = np.random.default_rng(2026)
    boot = np.asarray([rng.choice(case_delta, len(case_delta), replace=True).mean() for _ in range(10000)])
    lost = pd.read_csv(ROOT / "outputs/baseline_vs_s3_9000_failure_mode_audit/category_2d_lost_hit_detailed.csv")
    six = lost[keys].merge(paired, on=keys, validate="one_to_one")
    six.to_csv(OUT / "full381_six_lost_hits.csv", index=False)
    detection = ldet.merge(lddet, on=keys, suffixes=("_L", "_LD"), validate="one_to_one")
    detection.to_csv(OUT / "full381_paired_detection.csv", index=False)
    result = {
        "status": "complete", "overall_findings": 381, "specialist_2d_findings": 132,
        "non2d_source": "reused original S3 update9000 metrics/predictions",
        "overall_L_dice": float(l.global_dice.mean()), "overall_LD_dice": float(ld.global_dice.mean()),
        "overall_L_hits": int(l.global_hit.sum()), "overall_LD_hits": int(ld.global_hit.sum()),
        "LD_minus_L_case_bootstrap_95ci": [float(np.quantile(boot, .025)), float(np.quantile(boot, .975))],
    }
    (OUT / "full381_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
