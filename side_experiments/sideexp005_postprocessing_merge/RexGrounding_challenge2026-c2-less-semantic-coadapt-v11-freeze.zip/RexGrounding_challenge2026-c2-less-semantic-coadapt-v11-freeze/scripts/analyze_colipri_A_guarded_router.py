#!/usr/bin/env python3
"""Audit canonical CoLiPri A0/A2 disagreements and cross-fit a bounded guard."""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import socket
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import analyze_colipri_A_strict_null as strict_null  # noqa: E402
import colipri_experiment_a_router as experiment_a  # noqa: E402
import colipri_voxtell_matched_alignment as matched_alignment  # noqa: E402
import postzoom_routing_pipeline as p0  # noqa: E402


SOURCE = ROOT / "outputs/colipri_experiment_A_router_retry1_20260805"
P0_DIR = ROOT / "outputs/dual_s3_postzoom_routing"
MATCHED = ROOT / "outputs/colipri_voxtell_matched_alignment_20260804/matched_roi_manifest.csv"
STRICT_DIR = ROOT / "outputs/colipri_experiment_A_strict_null_20260806"
STRICT_ANALYSIS = STRICT_DIR / "analysis_retry4"
STRICT_EMBEDDINGS = STRICT_DIR / "embedding_cache_retry2"
EXPECTED_A0 = 0.27891622651020864
EXPECTED_A2 = 0.28059484677922275
EXPECTED_DELTA = 0.0016786202690141083
EXPECTED_SAME_ENTITY_DELTA = -0.0009242310801821363
SEED = 20260807
TOL = 1e-6

_NULL_STATE: dict[str, Any] = {}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--starting-report",
        type=Path,
        default=ROOT / "reports/colipri_A_guarded_router_starting_state.md",
    )
    parser.add_argument(
        "--final-report",
        type=Path,
        default=ROOT / "reports/colipri_A_guarded_router_analysis.md",
    )
    parser.add_argument("--bootstrap-reps", type=int, default=10_000)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--null-realizations", type=int, default=100)
    return parser.parse_args()


def atomic_text(text: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text)
    temporary.replace(path)


def atomic_json(value: Any, path: Path) -> None:
    atomic_text(json.dumps(value, indent=2) + "\n", path)


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def command_output(command: list[str]) -> str:
    executable = {
        "git": "/home/shenc2/miniconda3/envs/cmr/bin/git",
        "squeue": "/cm/shared/apps/slurm/current/bin/squeue",
    }.get(command[0], command[0])
    command = [executable, *command[1:]]
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, check=False)
    return (result.stdout + result.stderr).strip()


def ordered(frame: pd.DataFrame, keys: pd.Series) -> pd.DataFrame:
    return frame.set_index("finding_key").loc[keys].reset_index()


def decision(frame: pd.DataFrame) -> pd.Series:
    if "router_selected" in frame:
        return frame.router_selected.astype(int).map({0: "native", 1: "zoom"})
    return frame.selected_method.map({"native192": "native", "top3_replacement": "zoom"})


def approximate_fp(dice: pd.Series, predicted: pd.Series, target: pd.Series) -> pd.Series:
    # The cached P0 Dice used epsilon=1e-6; invert that equation to recover TP/FP.
    epsilon = 1e-6
    tp = (dice.astype(float) * (predicted.astype(float) + target.astype(float) + epsilon) - epsilon) / 2
    return (predicted.astype(float) - tp).clip(lower=0)


def enrich_metadata(base: pd.DataFrame) -> pd.DataFrame:
    metadata = pd.read_csv(MATCHED)
    metadata["finding_key"] = metadata.case_id.astype(str) + "|" + metadata.finding_idx.astype(int).astype(str)
    keep = [
        "finding_key", "case_id", "prompt_text", "category", "entity", "focality",
        "size_bin", "image_path", "mask_path",
    ]
    metadata = metadata[keep].rename(
        columns={
            "prompt_text": "metadata_prompt",
            "category": "metadata_category",
            "focality": "metadata_focality",
            "size_bin": "metadata_size_group",
        }
    )
    result = base[["finding_key", "file", "finding_idx", "prompt"]].merge(
        metadata, on="finding_key", validate="one_to_one"
    )
    expected_entities = result.metadata_category.map(matched_alignment.CATEGORY_NAMES)
    result["entity_reliable"] = (
        expected_entities.notna()
        & result.entity.notna()
        & expected_entities.eq(result.entity)
        & result.prompt.eq(result.metadata_prompt)
    )
    result["same_case_finding_count"] = result.groupby("case_id").finding_key.transform("size")
    reliable = result.entity.where(result.entity_reliable, "__UNRELIABLE__")
    result["same_case_same_entity_count"] = (
        result.assign(_entity=reliable).groupby(["case_id", "_entity"]).finding_key.transform("size")
    )
    result["same_case_same_entity_ambiguous"] = (
        result.entity_reliable & result.same_case_same_entity_count.ge(2)
    )
    result["multi_finding_case"] = result.same_case_finding_count.ge(2)
    return result


def validate_starting_state(
    a0: pd.DataFrame, a2: pd.DataFrame, folds: pd.DataFrame, metadata: pd.DataFrame
) -> dict[str, Any]:
    problems: list[str] = []
    if len(a0) != 381 or a0.file.nunique() != 200:
        problems.append(f"A0 cohort is {len(a0)} findings/{a0.file.nunique()} cases")
    if len(a2) != 381 or a2.file.nunique() != 200:
        problems.append(f"A2 cohort is {len(a2)} findings/{a2.file.nunique()} cases")
    if a0.finding_key.duplicated().any() or a2.finding_key.duplicated().any():
        problems.append("duplicate finding IDs")
    if set(a0.finding_key) != set(a2.finding_key):
        problems.append("A0/A2 finding IDs are not one-to-one")
    if folds.case_id.nunique() != 200 or set(folds.outer_fold) != set(range(5)):
        problems.append("fold assignment is not the canonical 200-case five-fold split")
    a2_aligned = ordered(a2, a0.finding_key)
    delta = float(a2_aligned.dice.mean() - a0.dice.mean())
    same = metadata.same_case_same_entity_ambiguous.to_numpy(bool)
    same_delta = float((a2_aligned.dice.to_numpy() - a0.dice.to_numpy())[same].mean())
    if not np.isclose(a0.dice.mean(), EXPECTED_A0, atol=1e-12):
        problems.append(f"A0 mismatch: {a0.dice.mean():.15f}")
    if not np.isclose(a2_aligned.dice.mean(), EXPECTED_A2, atol=1e-12):
        problems.append(f"A2 mismatch: {a2_aligned.dice.mean():.15f}")
    if not np.isclose(delta, EXPECTED_DELTA, atol=1e-12):
        problems.append(f"A2-A0 mismatch: {delta:+.15f}")
    if int(same.sum()) != 74 or not np.isclose(same_delta, EXPECTED_SAME_ENTITY_DELTA, atol=1e-12):
        problems.append(f"same-entity mismatch: n={same.sum()}, delta={same_delta:+.15f}")
    return {
        "passed": not problems,
        "problems": problems,
        "cases": int(a0.file.nunique()),
        "findings": len(a0),
        "a0": float(a0.dice.mean()),
        "a2": float(a2_aligned.dice.mean()),
        "delta": delta,
        "same_entity_findings": int(same.sum()),
        "same_entity_delta": same_delta,
        "entity_reliable_findings": int(metadata.entity_reliable.sum()),
    }


def write_starting_report(
    path: Path, audit: dict[str, Any], git_commit: str, branch: str, status: str, jobs: str
) -> None:
    artifacts = {
        "A0 OOF": SOURCE / "oof/A0_existing_p0.csv",
        "A2 OOF": SOURCE / "oof/A2_p0_plus_correct_colipri.csv",
        "P0 folds": P0_DIR / "fold_assignments.csv",
        "CoLiPri features": SOURCE / "colipri_router_features.csv",
        "entity metadata": MATCHED,
        "native probabilities": ROOT / "outputs/dual_s3_two_stage_zoom96/context_probabilities",
        "zoom predictions": ROOT / "outputs/dual_s3_two_stage_zoom96_bounded_update2000/top3/replacement",
        "strict-null embeddings": STRICT_EMBEDDINGS / "colipri_strict_null_embeddings.npz",
        "strict-null assignments": STRICT_ANALYSIS / "null_prompt_assignments.csv",
    }
    artifact_lines = "\n".join(
        f"- `{name}`: `{value}`" + (f" (sha256 `{sha256(value)}`)" if value.is_file() else "")
        for name, value in artifacts.items()
    )
    text = f"""# CoLiPri A Guarded Router Starting State

Status: **{'PASS' if audit['passed'] else 'FAIL'}**

## Repository

- Commit: `{git_commit}`
- Branch: `{branch}`
- Host: `{socket.gethostname()}`
- SLURM job: `{os.environ.get('SLURM_JOB_ID', 'local')}`

## Canonical Reproduction

- Cases: {audit['cases']}
- Findings: {audit['findings']}
- A0 Dice: {audit['a0']:.15f}
- A2 Dice: {audit['a2']:.15f}
- A2-A0: {audit['delta']:+.15f}
- Same-case same-entity: n={audit['same_entity_findings']}, delta={audit['same_entity_delta']:+.15f}
- Reliable inference-time entity labels: {audit['entity_reliable_findings']}/{audit['findings']}

## Canonical Artifacts

{artifact_lines}

Entity identity is the deterministic `CATEGORY_NAMES` mapping from the structured ReX
`categories` field in `MICCAI_challenge_dataset.json`. The field is available with the
finding prompt and is not derived from GT overlap, volume, Dice, or prediction quality.
The matched manifest is accepted only when its prompt/category/entity exactly agrees
with this mapping; an unreliable or missing entity falls back to A0.

## Git Status

```text
{status}
```

## Jobs At Start

```text
{jobs}
```

## Problems

{chr(10).join('- ' + item for item in audit['problems']) if audit['problems'] else '- None.'}
"""
    atomic_text(text, path)


def disagreement_table(a0: pd.DataFrame, a2: pd.DataFrame, metadata: pd.DataFrame) -> pd.DataFrame:
    a2 = ordered(a2, a0.finding_key)
    meta = ordered(metadata, a0.finding_key)
    result = pd.DataFrame({
        "case_id": a0.file,
        "finding_id": a0.finding_key,
        "finding_idx": a0.finding_idx.astype(int),
        "prompt": a0.prompt,
        "entity": meta.entity,
        "entity_reliable": meta.entity_reliable.astype(bool),
        "A0_decision": decision(a0),
        "A2_decision": decision(a2),
        "A0_final_dice": a0.dice,
        "A2_final_dice": a2.dice,
        "delta_A2_A0": a2.dice - a0.dice,
        "native_dice": a0.baseline_dice,
        "zoom_dice": a0.top3_dice,
        "native_hit": a0.baseline_hit.astype(int),
        "zoom_hit": a0.top3_hit.astype(int),
        "A0_hit": a0.hit.astype(int),
        "A2_hit": a2.hit.astype(int),
        "native_predicted_voxels": a0.baseline_predicted_voxels,
        "zoom_predicted_voxels": a0.top3_predicted_voxels,
        "A0_predicted_voxels": a0.predicted_voxels,
        "A2_predicted_voxels": a2.predicted_voxels,
        "colipri_native_similarity": a2.colipri_native_correct,
        "colipri_best_zoom_similarity": a2.colipri_zoom_correct_max,
        "colipri_zoom_minus_native": a2.colipri_zoom_minus_native,
        "same_case_finding_count": meta.same_case_finding_count.astype(int),
        "same_case_same_entity_count": meta.same_case_same_entity_count.astype(int),
        "same_case_same_entity_ambiguous": meta.same_case_same_entity_ambiguous.astype(bool),
        "category": a0.category,
        "focality": meta.metadata_focality,
        "size_group": meta.metadata_size_group,
        "fold": a0.outer_fold.astype(int),
        "gt_voxels": a0.pixels,
        "image_path": meta.image_path,
        "gt_mask_path": meta.mask_path,
    })
    for prefix in ("native", "zoom", "A0", "A2"):
        result[f"{prefix}_fp_voxels"] = approximate_fp(
            result[f"{prefix}_dice" if prefix in {"native", "zoom"} else f"{prefix}_final_dice"],
            result[f"{prefix}_predicted_voxels"],
            result.gt_voxels,
        )
    different = result.A0_decision.ne(result.A2_decision)
    tied = (result.native_dice - result.zoom_dice).abs().le(TOL)
    taxonomy = np.full(len(result), "SAME", dtype=object)
    taxonomy[different & tied] = "T"
    veto = different & result.A0_decision.eq("zoom") & result.A2_decision.eq("native") & ~tied
    promote = different & result.A0_decision.eq("native") & result.A2_decision.eq("zoom") & ~tied
    taxonomy[veto & result.native_dice.gt(result.zoom_dice)] = "V1"
    taxonomy[veto & result.native_dice.le(result.zoom_dice)] = "H1"
    taxonomy[promote & result.zoom_dice.gt(result.native_dice)] = "V2"
    taxonomy[promote & result.zoom_dice.le(result.native_dice)] = "H2"
    result["taxonomy"] = taxonomy
    result["decision_changed"] = different
    return result


def taxonomy_summary(table: pd.DataFrame) -> pd.DataFrame:
    changed = table.loc[table.decision_changed].copy()
    rows = []
    for label in ("V1", "V2", "H1", "H2", "T"):
        block = changed.loc[changed.taxonomy.eq(label)]
        rows.append({
            "taxonomy": label,
            "findings": len(block),
            "mean_dice_contribution": float(block.delta_A2_A0.mean()) if len(block) else np.nan,
            "total_dice_contribution": float(block.delta_A2_A0.sum()),
            "new_hits": int(((block.A2_hit == 1) & (block.A0_hit == 0)).sum()),
            "lost_hits": int(((block.A2_hit == 0) & (block.A0_hit == 1)).sum()),
            "fp_change_voxels": float((block.A2_fp_voxels - block.A0_fp_voxels).sum()),
            "predicted_volume_change_voxels": float(
                (block.A2_predicted_voxels - block.A0_predicted_voxels).sum()
            ),
        })
    return pd.DataFrame(rows)


def contribution_outputs(table: pd.DataFrame, output: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    changed = table.loc[table.decision_changed].copy()
    columns = [
        "case_id", "finding_id", "prompt", "entity", "taxonomy", "A0_decision", "A2_decision",
        "native_dice", "zoom_dice", "A0_final_dice", "A2_final_dice", "delta_A2_A0",
        "colipri_native_similarity", "colipri_best_zoom_similarity", "colipri_zoom_minus_native",
        "same_case_same_entity_ambiguous",
    ]
    positive = changed.sort_values("delta_A2_A0", ascending=False).head(20)[columns]
    negative = changed.sort_values("delta_A2_A0", ascending=True).head(20)[columns]
    atomic_csv(positive, output / "positive_contributors.csv")
    atomic_csv(negative, output / "negative_contributors.csv")
    rows = []
    for direction, block in (
        ("positive", changed.loc[changed.delta_A2_A0 > TOL].sort_values("delta_A2_A0", ascending=False)),
        ("negative", changed.loc[changed.delta_A2_A0 < -TOL].sort_values("delta_A2_A0")),
    ):
        total = float(block.delta_A2_A0.sum())
        for count in (1, 5, 10, 25):
            value = float(block.head(count).delta_A2_A0.sum())
            rows.append({"direction": direction, "segment": f"top_{count}", "contribution": value,
                         "fraction_of_direction_total": value / total if total else np.nan})
        value = float(block.iloc[25:].delta_A2_A0.sum())
        rows.append({"direction": direction, "segment": "remainder_after_25", "contribution": value,
                     "fraction_of_direction_total": value / total if total else np.nan})
    concentration = pd.DataFrame(rows)
    atomic_csv(concentration, output / "contribution_concentration.csv")
    overall = float(table.delta_A2_A0.mean())
    loco = []
    for case, block in table.groupby("case_id", sort=True):
        remaining = table.loc[table.case_id.ne(case), "delta_A2_A0"]
        loco.append({"left_out_case": case, "findings_removed": len(block), "delta_without_case": float(remaining.mean()),
                     "influence_overall_minus_loco": overall - float(remaining.mean()),
                     "case_total_contribution": float(block.delta_A2_A0.sum())})
    loco_frame = pd.DataFrame(loco).sort_values("influence_overall_minus_loco", key=abs, ascending=False)
    atomic_csv(loco_frame, output / "leave_one_case_out_influence.csv")
    return positive, negative, concentration


def subgroup_summary(table: pd.DataFrame) -> pd.DataFrame:
    masks: dict[str, pd.Series] = {
        "single_finding": table.same_case_finding_count.eq(1),
        "multi_finding": table.same_case_finding_count.ge(2),
        "same_case_same_entity": table.same_case_same_entity_ambiguous,
        "same_case_different_entity": table.same_case_finding_count.ge(2) & ~table.same_case_same_entity_ambiguous,
    }
    for value in ("tiny", "small", "medium", "large"):
        masks[f"size_{value}"] = table.size_group.astype(str).str.lower().eq(value)
    for value in ("focal", "diffuse", "mixed", "unknown"):
        masks[f"focality_{value}"] = table.focality.astype(str).str.lower().eq(value)
    for value in sorted(table.category.dropna().astype(str).unique()):
        masks[f"category_{value}"] = table.category.astype(str).eq(value)
    rows = []
    for name, mask in masks.items():
        block = table.loc[mask]
        if not len(block):
            continue
        rows.append({
            "subgroup": name,
            "findings": len(block),
            "cases": int(block.case_id.nunique()),
            "disagreements": int(block.decision_changed.sum()),
            "disagreement_rate": float(block.decision_changed.mean()),
            "A0_mean_dice": float(block.A0_final_dice.mean()),
            "A2_mean_dice": float(block.A2_final_dice.mean()),
            "delta_A2_A0": float(block.delta_A2_A0.mean()),
            "new_hits": int(((block.A2_hit == 1) & (block.A0_hit == 0)).sum()),
            "lost_hits": int(((block.A2_hit == 0) & (block.A0_hit == 1)).sum()),
            "mean_fp_change": float((block.A2_fp_voxels - block.A0_fp_voxels).mean()),
        })
    return pd.DataFrame(rows)


def policy_frame(a0: pd.DataFrame, a2: pd.DataFrame, fallback: np.ndarray, name: str) -> pd.DataFrame:
    a2 = ordered(a2, a0.finding_key)
    fallback = np.asarray(fallback, dtype=bool)
    result = pd.DataFrame({
        "file": a0.file,
        "finding_key": a0.finding_key,
        "finding_idx": a0.finding_idx.astype(int),
        "pixels": a0.pixels,
        "dice": np.where(fallback, a0.dice, a2.dice),
        "hit": np.where(fallback, a0.hit, a2.hit).astype(int),
        "predicted_voxels": np.where(fallback, a0.predicted_voxels, a2.predicted_voxels),
        "decision": np.where(fallback, decision(a0), decision(a2)),
        "guard_fallback_to_A0": fallback,
        "policy": name,
        "outer_fold": a0.outer_fold.astype(int),
    })
    result["fp_voxels"] = approximate_fp(result.dice, result.predicted_voxels, result.pixels)
    return result


def select_crossfit_guard(
    a0: pd.DataFrame, a2: pd.DataFrame, metadata: pd.DataFrame
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    a2 = ordered(a2, a0.finding_key)
    meta = ordered(metadata, a0.finding_key)
    unreliable = ~meta.entity_reliable.to_numpy(bool)
    masks = {
        "G0": np.zeros(len(a0), dtype=bool),
        "G1": meta.same_case_same_entity_ambiguous.to_numpy(bool) | unreliable,
        "G2": meta.multi_finding_case.to_numpy(bool) | unreliable,
    }
    candidates = {name: policy_frame(a0, a2, mask, name) for name, mask in masks.items()}
    selected_blocks = []
    fold_records = []
    simplicity = {"G0": 0, "G1": 1, "G2": 2}
    for fold in range(5):
        development = a0.outer_fold.ne(fold).to_numpy()
        scores = []
        for name, frame in candidates.items():
            block = frame.loc[development]
            a2_block = a2.loc[development]
            scores.append({
                "policy": name,
                "mean_dice": float(block.dice.mean()),
                "lost_hits_vs_A2": int(((block.hit == 0) & (a2_block.hit.to_numpy() == 1)).sum()),
                "mean_fp_voxels": float(block.fp_voxels.mean()),
                "fallback_fraction": float(block.guard_fallback_to_A0.mean()),
            })
        best_dice = max(row["mean_dice"] for row in scores)
        eligible = [row for row in scores if best_dice - row["mean_dice"] <= 1e-12]
        fewest_lost = min(row["lost_hits_vs_A2"] for row in eligible)
        eligible = [row for row in eligible if row["lost_hits_vs_A2"] == fewest_lost]
        lowest_fp = min(row["mean_fp_voxels"] for row in eligible)
        eligible = [row for row in eligible if abs(row["mean_fp_voxels"] - lowest_fp) <= 1e-9]
        selected = min(eligible, key=lambda row: simplicity[row["policy"]])["policy"]
        test = a0.outer_fold.eq(fold).to_numpy()
        selected_blocks.append(candidates[selected].loc[test].copy())
        fold_records.append({
            "outer_fold": fold,
            "development_findings": int(development.sum()),
            "heldout_findings": int(test.sum()),
            "selected_policy": selected,
            "candidates": scores,
        })
    result = pd.concat(selected_blocks).sort_values(["file", "finding_idx"]).reset_index(drop=True)
    result["policy"] = "A2-GUARD-CROSSFIT"
    return result, fold_records


def native_frame(a0: pd.DataFrame) -> pd.DataFrame:
    frame = pd.DataFrame({
        "file": a0.file, "finding_key": a0.finding_key, "finding_idx": a0.finding_idx,
        "pixels": a0.pixels, "dice": a0.baseline_dice, "hit": a0.baseline_hit.astype(int),
        "predicted_voxels": a0.baseline_predicted_voxels, "decision": "native",
        "guard_fallback_to_A0": False, "policy": "NATIVE", "outer_fold": a0.outer_fold,
    })
    frame["fp_voxels"] = approximate_fp(frame.dice, frame.predicted_voxels, frame.pixels)
    return frame


def as_method_frame(source: pd.DataFrame, name: str) -> pd.DataFrame:
    result = pd.DataFrame({
        "file": source.file, "finding_key": source.finding_key, "finding_idx": source.finding_idx,
        "pixels": source.pixels, "dice": source.dice, "hit": source.hit.astype(int),
        "predicted_voxels": source.predicted_voxels, "decision": decision(source),
        "guard_fallback_to_A0": False, "policy": name, "outer_fold": source.outer_fold,
    })
    result["fp_voxels"] = approximate_fp(result.dice, result.predicted_voxels, result.pixels)
    return result


def method_summary(methods: dict[str, pd.DataFrame]) -> pd.DataFrame:
    native, a0, a2 = methods["NATIVE"], methods["A0"], methods["A2"]
    rows = []
    for name, frame in methods.items():
        guard_changed_fraction = (
            float(frame.decision.ne(a2.decision).mean())
            if name.startswith("A2-GUARD-") else 0.0
        )
        row = {
            "method": name,
            "mean_dice": float(frame.dice.mean()),
            "median_dice": float(frame.dice.median()),
            "hits": int(frame.hit.sum()),
            "new_hits_vs_native": int(((frame.hit == 1) & (native.hit == 0)).sum()),
            "lost_hits_vs_native": int(((frame.hit == 0) & (native.hit == 1)).sum()),
            "new_hits_vs_A0": int(((frame.hit == 1) & (a0.hit == 0)).sum()),
            "lost_hits_vs_A0": int(((frame.hit == 0) & (a0.hit == 1)).sum()),
            "new_hits_vs_A2": int(((frame.hit == 1) & (a2.hit == 0)).sum()),
            "lost_hits_vs_A2": int(((frame.hit == 0) & (a2.hit == 1)).sum()),
            "mean_predicted_voxels": float(frame.predicted_voxels.mean()),
            "mean_fp_voxels": float(frame.fp_voxels.mean()),
            "fraction_routed_to_zoom": float(frame.decision.eq("zoom").mean()),
            "fraction_guard_fallback_to_A0": float(frame.guard_fallback_to_A0.mean()),
            "fraction_guard_changed_A2": guard_changed_fraction,
            "delta_vs_A0": float((frame.dice - a0.dice).mean()),
            "delta_vs_A2": float((frame.dice - a2.dice).mean()),
        }
        rows.append(row)
    return pd.DataFrame(rows)


def finding_weighted_case_bootstrap(
    left: pd.DataFrame, right: pd.DataFrame, reps: int, seed: int
) -> dict[str, Any]:
    merged = left[["file", "finding_key", "dice"]].merge(
        right[["finding_key", "dice"]], on="finding_key", suffixes=("_left", "_right"), validate="one_to_one"
    )
    merged["delta"] = merged.dice_left - merged.dice_right
    grouped = [block.delta.to_numpy(np.float64) for _, block in merged.groupby("file", sort=True)]
    sums = np.asarray([values.sum() for values in grouped])
    counts = np.asarray([len(values) for values in grouped])
    rng = np.random.default_rng(seed)
    draws = np.empty(reps)
    for start in range(0, reps, 1000):
        count = min(1000, reps - start)
        sampled = rng.integers(0, len(grouped), size=(count, len(grouped)))
        draws[start:start + count] = sums[sampled].sum(1) / counts[sampled].sum(1)
    return {
        "estimate": float(merged.delta.mean()),
        "ci95_low": float(np.quantile(draws, 0.025)),
        "ci95_high": float(np.quantile(draws, 0.975)),
        "p_delta_gt_0": float((draws > 0).mean()),
        "replicates": reps,
        "cases": len(grouped),
        "findings": len(merged),
    }


def init_null_worker(state: dict[str, Any]) -> None:
    global _NULL_STATE
    _NULL_STATE = state


def run_guarded_null(realization: int) -> dict[str, Any]:
    state = _NULL_STATE
    assignments = state["assignments"][realization]
    key_to_index = state["key_to_index"]
    primary = assignments.source_finding_key.map(key_to_index).to_numpy(np.int32)
    contrast = assignments.contrast_finding_key.map(key_to_index).to_numpy(np.int32)
    features = strict_null.build_features(state["manifest"], state["arrays"], primary, contrast)
    merged = state["base"].merge(
        features, on=["finding_key", "file", "finding_idx", "prompt"], validate="one_to_one"
    )
    null_a2 = p0.nested_finding_router(merged, state["folds"])
    null_a2 = ordered(null_a2, state["a0"].finding_key)
    guarded, policies = select_crossfit_guard(state["a0"], null_a2, state["metadata"])
    return {
        "realization": realization,
        "unguarded_mean_dice": float(null_a2.dice.mean()),
        "unguarded_delta_vs_A0": float(null_a2.dice.mean() - state["a0"].dice.mean()),
        "guarded_mean_dice": float(guarded.dice.mean()),
        "guarded_delta_vs_A0": float(guarded.dice.mean() - state["a0"].dice.mean()),
        "selected_policies": ",".join(record["selected_policy"] for record in policies),
    }


def strict_guarded_null(
    a0: pd.DataFrame,
    metadata: pd.DataFrame,
    correct_guarded: pd.DataFrame,
    workers: int,
    realizations: int,
    output: Path,
) -> dict[str, Any]:
    manifest = pd.read_csv(STRICT_EMBEDDINGS / "embedding_manifest.csv")
    loaded = np.load(STRICT_EMBEDDINGS / "colipri_strict_null_embeddings.npz")
    arrays = {name: loaded[name] for name in loaded.files}
    base = pd.read_csv(P0_DIR / "feature_tables/finding_features.csv")
    folds = pd.read_csv(P0_DIR / "fold_assignments.csv")
    old_features = pd.read_csv(SOURCE / "colipri_router_features.csv")
    old_shuffle = pd.read_csv(SOURCE / "shuffled_prompt_manifest.csv")
    key_to_index = dict(zip(manifest.finding_key, range(len(manifest))))
    contrast = old_shuffle.set_index("finding_key").loc[
        manifest.finding_key, "shuffled_prompt_source_key"
    ].map(key_to_index).to_numpy(np.int32)
    strict_null.calibrate_score_matrices(arrays, old_features, contrast)
    assignment_frame = pd.read_csv(STRICT_ANALYSIS / "null_prompt_assignments.csv")
    assignment_frame = assignment_frame.loc[
        assignment_frame.null_type.eq("cross_case") & assignment_frame.realization.lt(realizations)
    ].copy()
    if assignment_frame.realization.nunique() != realizations:
        raise RuntimeError("Requested strict-null realizations are not available")
    grouped = assignment_frame.set_index(["realization", "target_finding_key"]).sort_index()
    ordered_groups = {}
    for realization in range(realizations):
        block = grouped.loc[realization].loc[manifest.finding_key].reset_index()
        ordered_groups[realization] = block
    state = {
        "manifest": manifest,
        "arrays": arrays,
        "base": base,
        "folds": folds,
        "a0": ordered(a0, manifest.finding_key),
        "metadata": ordered(metadata, manifest.finding_key),
        "key_to_index": key_to_index,
        "assignments": ordered_groups,
    }
    results = []
    if workers == 1:
        init_null_worker(state)
        for complete, index in enumerate(range(realizations), start=1):
            results.append(run_guarded_null(index))
            if complete % 10 == 0 or complete == realizations:
                print(f"[guarded strict null] {complete}/{realizations}", flush=True)
    else:
        context = mp.get_context("fork")
        with ProcessPoolExecutor(
            max_workers=workers, mp_context=context, initializer=init_null_worker, initargs=(state,)
        ) as executor:
            futures = {executor.submit(run_guarded_null, index): index for index in range(realizations)}
            for complete, future in enumerate(as_completed(futures), start=1):
                results.append(future.result())
                if complete % 10 == 0 or complete == realizations:
                    print(f"[guarded strict null] {complete}/{realizations}", flush=True)
    frame = pd.DataFrame(results).sort_values("realization")
    atomic_csv(frame, output / "strict_null_guarded_realizations.csv")
    observed = float(correct_guarded.dice.mean() - a0.dice.mean())
    values = frame.guarded_delta_vs_A0.to_numpy()
    result = {
        "correct_guarded_delta_vs_A0": observed,
        "realizations": realizations,
        "shuffled_guarded_null_mean": float(values.mean()),
        "shuffled_guarded_null_p95": float(np.quantile(values, 0.95)),
        "shuffled_guarded_null_p2p5": float(np.quantile(values, 0.025)),
        "shuffled_guarded_null_p97p5": float(np.quantile(values, 0.975)),
        "empirical_p_one_sided": float((1 + np.sum(values >= observed)) / (realizations + 1)),
        "fraction_ge_observed": float(np.mean(values >= observed)),
    }
    atomic_json(result, output / "strict_null_guarded.json")
    return result


def qualitative_examples(table: pd.DataFrame, fixed: pd.DataFrame, crossfit: pd.DataFrame) -> pd.DataFrame:
    fixed = fixed.set_index("finding_key")
    crossfit = crossfit.set_index("finding_key")
    rows = []
    groups = {
        "best_semantic_veto_success": table.loc[table.taxonomy.eq("V1")].nlargest(10, "delta_A2_A0"),
        "worst_incorrect_veto_or_promotion": table.loc[table.taxonomy.isin(["H1", "H2"])].nsmallest(10, "delta_A2_A0"),
        "same_entity_hurt_gt_0p01": table.loc[
            table.same_case_same_entity_ambiguous & table.delta_A2_A0.lt(-0.01)
        ],
    }
    fixed_delta = fixed.dice - table.set_index("finding_id").A2_final_dice
    repaired_keys = fixed_delta[fixed_delta > TOL].sort_values(ascending=False).index
    removed_keys = fixed_delta[fixed_delta < -TOL].sort_values().index
    groups["fixed_guard_repairs_A2"] = table.set_index("finding_id").loc[repaired_keys].reset_index()
    groups["fixed_guard_removes_A2_benefit"] = table.set_index("finding_id").loc[removed_keys].reset_index()
    crossfit_delta = crossfit.dice - table.set_index("finding_id").A2_final_dice
    crossfit_repairs = crossfit_delta[crossfit_delta > TOL].sort_values(ascending=False).index
    crossfit_removes = crossfit_delta[crossfit_delta < -TOL].sort_values().index
    groups["crossfit_guard_repairs_A2"] = table.set_index("finding_id").loc[crossfit_repairs].reset_index()
    groups["crossfit_guard_removes_A2_benefit"] = table.set_index("finding_id").loc[crossfit_removes].reset_index()
    for group, block in groups.items():
        for _, row in block.iterrows():
            case = row.case_id
            key = f"{case}|{int(row.finding_idx)}"
            rows.append({
                "example_group": group,
                "case_id": case,
                "finding_id": key,
                "prompt": row.prompt,
                "entity": row.entity,
                "native_prediction_cache": str(ROOT / "outputs/dual_s3_two_stage_zoom96/context_probabilities" / case.replace(".nii.gz", ".npz")),
                "zoom_prediction_path": str(ROOT / "outputs/dual_s3_two_stage_zoom96_bounded_update2000/top3/replacement" / case),
                "ct_path": row.image_path,
                "gt_path": row.gt_mask_path,
                "A0_decision": row.A0_decision,
                "A2_decision": row.A2_decision,
                "guard_fixed_decision": fixed.loc[key, "decision"],
                "guard_crossfit_decision": crossfit.loc[key, "decision"],
                "native_dice": row.native_dice,
                "zoom_dice": row.zoom_dice,
                "A0_dice": row.A0_final_dice,
                "A2_dice": row.A2_final_dice,
                "guard_fixed_dice": fixed.loc[key, "dice"],
                "guard_crossfit_dice": crossfit.loc[key, "dice"],
                "colipri_native_similarity": row.colipri_native_similarity,
                "colipri_best_zoom_similarity": row.colipri_best_zoom_similarity,
                "colipri_zoom_minus_native": row.colipri_zoom_minus_native,
                "same_case_same_entity_ambiguous": row.same_case_same_entity_ambiguous,
            })
    return pd.DataFrame(rows).drop_duplicates(["example_group", "finding_id"])


def markdown_table(frame: pd.DataFrame, columns: list[str], limit: int | None = None) -> str:
    block = frame[columns].head(limit) if limit else frame[columns]
    if not len(block):
        return "_No rows._"
    header = "| " + " | ".join(columns) + " |"
    separator = "|" + "|".join("---" for _ in columns) + "|"
    lines = [header, separator]
    for row in block.itertuples(index=False, name=None):
        values = []
        for value in row:
            if isinstance(value, float):
                values.append(f"{value:.6f}")
            else:
                values.append(str(value).replace("|", "/"))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def write_final_report(
    path: Path,
    table: pd.DataFrame,
    taxonomy: pd.DataFrame,
    subgroups: pd.DataFrame,
    summary: pd.DataFrame,
    policies: list[dict[str, Any]],
    bootstrap: dict[str, Any],
    null: dict[str, Any],
    positive: pd.DataFrame,
    negative: pd.DataFrame,
    concentration: pd.DataFrame,
    output: Path,
) -> None:
    taxonomy_map = taxonomy.set_index("taxonomy")
    veto_positive = float(taxonomy_map.loc["V1", "total_dice_contribution"])
    rescue_positive = float(taxonomy_map.loc["V2", "total_dice_contribution"])
    mechanism = "both" if min(veto_positive, rescue_positive) >= 0.25 * max(veto_positive, rescue_positive) else (
        "zoom veto" if veto_positive > rescue_positive else "zoom rescue"
    )
    same = subgroups.set_index("subgroup").loc["same_case_same_entity"]
    fixed_row = summary.set_index("method").loc["A2-GUARD-ENTITY-FIXED"]
    cross_row = summary.set_index("method").loc["A2-GUARD-CROSSFIT"]
    same_keys = table.loc[table.same_case_same_entity_ambiguous, "finding_id"]
    crossfit_findings = pd.read_csv(output / "guard_crossfit_per_finding.csv").set_index("finding_key")
    same_indexed = table.set_index("finding_id").loc[same_keys]
    same_crossfit_delta_vs_a2 = float(
        (crossfit_findings.loc[same_keys, "dice"].to_numpy() - same_indexed.A2_final_dice.to_numpy()).mean()
    )
    same_crossfit_delta_vs_a0 = float(
        (crossfit_findings.loc[same_keys, "dice"].to_numpy() - same_indexed.A0_final_dice.to_numpy()).mean()
    )
    selected = [record["selected_policy"] for record in policies]
    if (
        cross_row.delta_vs_A2 >= -1e-12
        and cross_row.lost_hits_vs_A2 == 0
        and null["empirical_p_one_sided"] <= 0.05
    ):
        guard_verdict = "GO"
    elif fixed_row.delta_vs_A2 > 0 and cross_row.delta_vs_A2 <= 0:
        guard_verdict = "FIXED POLICY LOOKS POSITIVE, BUT CROSS-FITTED EVIDENCE IS WEAK"
    else:
        guard_verdict = "NO-GO" if cross_row.delta_vs_A2 < 0 else "INCONCLUSIVE"
    production = "A2-GUARD-CROSSFIT" if guard_verdict == "GO" and any(x != "G0" for x in selected) else "A2"
    top_one = concentration.loc[
        (concentration.direction == "positive") & (concentration.segment == "top_1"),
        "fraction_of_direction_total",
    ].iloc[0]
    concentration_text = "concentrated" if top_one > 0.5 else "distributed across multiple findings"
    semantic_veto = (
        "Not evaluated: helpful veto and rescue contributions are both substantial, so the precondition "
        "that vetoing is the dominant mechanism was not met."
    )
    report = f"""# CoLiPri Experiment A — Disagreement and Guarded Router Analysis

## 1. Canonical A reproduction

- A0: {EXPECTED_A0:.6f}
- A2: {EXPECTED_A2:.6f}
- A2-A0: {EXPECTED_DELTA:+.6f}
- Strict-null result: p=0.019802, null mean=-0.001876, null p95=+0.000172.
- A2 verdict: **CONFIRMED GO**.

## 2. What A2 actually changes

- A0/A2 disagreements: {int(table.decision_changed.sum())}/381.
- Helpful vetoes (V1): {int(taxonomy_map.loc['V1', 'findings'])}.
- Helpful promotions (V2): {int(taxonomy_map.loc['V2', 'findings'])}.
- Harmful vetoes (H1): {int(taxonomy_map.loc['H1', 'findings'])}.
- Harmful promotions (H2): {int(taxonomy_map.loc['H2', 'findings'])}.
- Ties: {int(taxonomy_map.loc['T', 'findings'])}.

CoLiPri acts as **{mechanism}**: V1 total Dice contribution is {veto_positive:+.6f},
while V2 contributes {rescue_positive:+.6f}. The optional veto-only policy was therefore
not justified.

{markdown_table(taxonomy, ['taxonomy', 'findings', 'mean_dice_contribution', 'total_dice_contribution', 'new_hits', 'lost_hits', 'fp_change_voxels'])}

## 3. Contribution concentration

The gain is **{concentration_text}**; the largest positive disagreement contributes
{top_one:.1%} of gross positive contribution. Positive and negative changes largely
cancel, so both tails matter.

Top positive contributors:

{markdown_table(positive, ['finding_id', 'entity', 'taxonomy', 'A0_decision', 'A2_decision', 'delta_A2_A0'], 10)}

Top negative contributors:

{markdown_table(negative, ['finding_id', 'entity', 'taxonomy', 'A0_decision', 'A2_decision', 'delta_A2_A0'], 10)}

## 4. Failure modes

Same-case same-entity remains the key failure subgroup: n={int(same.findings)},
A2-A0={same.delta_A2_A0:+.6f}, disagreement rate={same.disagreement_rate:.3f}.
See `subgroup_summary.csv` for multi-finding, size, focality, and category results.

## 5. Guard definition

Entity identity is obtained from the deterministic `CATEGORY_NAMES` mapping applied to
the structured ReX finding `categories` metadata. It is available with the prompt and
does not use GT masks, Dice, GT volume, or oracle labels. The mapping and prompt are
cross-checked against the existing matched manifest. Missing or inconsistent entity
identity conservatively falls back to A0.

- G0: A2 everywhere.
- G1: A2 except repeated same-case entity (or unreliable entity) falls back to A0.
- G2: A2 except any multi-finding case (or unreliable entity) falls back to A0.

## 6. Fixed guarded policy

`A2-GUARD-ENTITY-FIXED` is descriptive and potentially optimistic because the guard was
proposed after observing the subgroup failure. Dice={fixed_row.mean_dice:.6f},
delta vs A2={fixed_row.delta_vs_A2:+.6f}.

## 7. Cross-fitted guarded policy

Each outer fold selected among the predeclared G0/G1/G2 family using only the other four
folds. Selection order was mean Dice, fewer lost A2 hits, lower FP, then simplicity
G0 > G1 > G2. Selected policies by fold: `{','.join(selected)}`.

Primary verdict: **{guard_verdict}**.

On the known 74-finding same-case same-entity subgroup, cross-fit guard delta is
{same_crossfit_delta_vs_a2:+.6f} vs A2 and {same_crossfit_delta_vs_a0:+.6f} vs A0. Thus the
leakage-safe policy does not repair the subgroup even though fixed G1 does descriptively.

## 8. Finding-level comparison table

{markdown_table(summary, ['method', 'mean_dice', 'median_dice', 'hits', 'mean_fp_voxels', 'fraction_routed_to_zoom', 'fraction_guard_fallback_to_A0', 'fraction_guard_changed_A2', 'delta_vs_A0', 'delta_vs_A2'])}

## 9. Case-bootstrap statistics

- Crossfit-A0: {bootstrap['crossfit_minus_A0']['estimate']:+.6f}, 95% CI
  [{bootstrap['crossfit_minus_A0']['ci95_low']:+.6f}, {bootstrap['crossfit_minus_A0']['ci95_high']:+.6f}].
- Crossfit-A2: {bootstrap['crossfit_minus_A2']['estimate']:+.6f}, 95% CI
  [{bootstrap['crossfit_minus_A2']['ci95_low']:+.6f}, {bootstrap['crossfit_minus_A2']['ci95_high']:+.6f}].

The bootstrap samples cases as clusters and retains every finding from each sampled case;
the statistic remains finding-weighted.

## 10. Guarded strict-null analysis

- Correct guarded delta vs A0: {null['correct_guarded_delta_vs_A0']:+.6f}.
- Shuffled guarded null mean: {null['shuffled_guarded_null_mean']:+.6f}.
- Shuffled guarded null p95: {null['shuffled_guarded_null_p95']:+.6f}.
- Empirical one-sided p: {null['empirical_p_one_sided']:.6f}.

## 11. Qualitative disagreement examples

`qualitative_examples.csv` records CT, GT, native probability cache, zoom prediction,
prompt, decisions, metrics, semantic features, and ambiguity status without rerunning
segmentation or CoLiPri inference.

## 12. Final interpretation

- A2 remains a valid **CONFIRMED GO**.
- Guarded A2 verdict: **{guard_verdict}**.
- The cross-fitted guard does not repair the same-case same-entity subgroup
  (delta vs A2 {same_crossfit_delta_vs_a2:+.6f}).
- Semantic veto: {semantic_veto}
- Same-case same-entity ambiguity should trigger fallback only if selected by the
  leakage-safe outer-fold policy; the full-cohort fixed result is not unbiased evidence.

## 13. Recommended production policy

**{production}**

This recommendation follows the cross-fitted result and strict semantic-null check, not
the numerically highest post-hoc full-cohort score.

## 14. Reproduction commands

```bash
# Run the bounded 4-CPU analysis; no GPU or neural inference is requested.
sbatch scripts/analyze_colipri_A_guarded_router_cpu.sbatch

# Equivalent direct command inside the existing analysis environment.
python scripts/analyze_colipri_A_guarded_router.py \\
  --output-dir {output} \\
  --workers 4 --bootstrap-reps 10000 --null-realizations 100
```

## 15. Modified/created files

- `scripts/analyze_colipri_A_guarded_router.py`
- `scripts/analyze_colipri_A_guarded_router_cpu.sbatch`
- `reports/colipri_A_guarded_router_starting_state.md`
- `reports/colipri_A_guarded_router_analysis.md`
- `{output}/` (all derived CSV/JSON artifacts)
"""
    atomic_text(report, path)


def save_job_history(path: Path) -> None:
    output = command_output([
        "squeue", "-u", os.environ.get("USER", "shenc2"), "-h", "-o",
        "%i|%P|%j|%T|%M|%l|%D|%R",
    ])
    rows = []
    for line in output.splitlines():
        parts = line.split("|", 7)
        if len(parts) == 8:
            rows.append(dict(zip(
                ["job_id", "partition", "name", "state", "elapsed", "limit", "nodes", "reason_or_node"],
                parts,
            )))
    frame = pd.DataFrame(rows)
    frame.insert(0, "captured_utc", datetime.now(timezone.utc).isoformat())
    frame["analysis_job_id"] = os.environ.get("SLURM_JOB_ID", "local")
    frame["analysis_host"] = socket.gethostname()
    atomic_csv(frame, path)


def main() -> int:
    args = parse_args()
    if args.output_dir.exists():
        raise FileExistsError(f"Refusing to overwrite existing output: {args.output_dir}")
    if not 1 <= args.workers <= 4:
        raise ValueError("Resource policy permits 1-4 workers")
    if args.bootstrap_reps < 10_000:
        raise ValueError("At least 10,000 bootstrap replicates are required")
    args.output_dir.mkdir(parents=True)
    save_job_history(args.output_dir / "job_history.csv")

    a0 = pd.read_csv(SOURCE / "oof/A0_existing_p0.csv").sort_values(["file", "finding_idx"]).reset_index(drop=True)
    a2 = pd.read_csv(SOURCE / "oof/A2_p0_plus_correct_colipri.csv")
    a2 = ordered(a2, a0.finding_key)
    folds = pd.read_csv(P0_DIR / "fold_assignments.csv")
    metadata = enrich_metadata(a0)
    metadata = ordered(metadata, a0.finding_key)
    audit = validate_starting_state(a0, a2, folds, metadata)
    git_commit = command_output(["git", "rev-parse", "HEAD"])
    branch = command_output(["git", "branch", "--show-current"])
    status = command_output(["git", "status", "--short", "--branch"])
    jobs = command_output(["squeue", "-u", os.environ.get("USER", "shenc2"), "-o", "%.18i %.9P %.28j %.8T %.10M %.10l %.6D %R"])
    write_starting_report(args.starting_report, audit, git_commit, branch, status, jobs)
    if not audit["passed"]:
        raise RuntimeError("Starting-state audit failed: " + "; ".join(audit["problems"]))
    print("[audit] canonical A0/A2 state reproduced", flush=True)

    table = disagreement_table(a0, a2, metadata)
    atomic_csv(table, args.output_dir / "per_finding_disagreement.csv")
    taxonomy = taxonomy_summary(table)
    atomic_csv(taxonomy, args.output_dir / "disagreement_taxonomy.csv")
    positive, negative, concentration = contribution_outputs(table, args.output_dir)
    subgroups = subgroup_summary(table)
    atomic_csv(subgroups, args.output_dir / "subgroup_summary.csv")

    unreliable = ~metadata.entity_reliable.to_numpy(bool)
    fixed_mask = metadata.same_case_same_entity_ambiguous.to_numpy(bool) | unreliable
    fixed = policy_frame(a0, a2, fixed_mask, "A2-GUARD-ENTITY-FIXED")
    crossfit, policies = select_crossfit_guard(a0, a2, metadata)
    atomic_csv(fixed, args.output_dir / "guard_fixed_per_finding.csv")
    atomic_csv(crossfit, args.output_dir / "guard_crossfit_per_finding.csv")
    atomic_json(policies, args.output_dir / "guard_policy_by_fold.json")

    methods = {
        "NATIVE": native_frame(a0),
        "A0": as_method_frame(a0, "A0"),
        "A2": as_method_frame(a2, "A2"),
        "A2-GUARD-ENTITY-FIXED": fixed,
        "A2-GUARD-CROSSFIT": crossfit,
    }
    summary = method_summary(methods)
    atomic_csv(summary, args.output_dir / "method_comparison.csv")
    bootstrap = {
        "crossfit_minus_A0": finding_weighted_case_bootstrap(crossfit, methods["A0"], args.bootstrap_reps, SEED),
        "crossfit_minus_A2": finding_weighted_case_bootstrap(crossfit, methods["A2"], args.bootstrap_reps, SEED + 1),
    }
    atomic_json(bootstrap, args.output_dir / "bootstrap_metrics.json")

    examples = qualitative_examples(table, fixed, crossfit)
    atomic_csv(examples, args.output_dir / "qualitative_examples.csv")
    print("[analysis] disagreement and cross-fit guard complete", flush=True)

    guarded_null = strict_guarded_null(
        a0, metadata, crossfit, args.workers, args.null_realizations, args.output_dir
    )
    write_final_report(
        args.final_report, table, taxonomy, subgroups, summary, policies, bootstrap,
        guarded_null, positive, negative, concentration, args.output_dir,
    )
    result = {
        "canonical_A0": float(a0.dice.mean()),
        "canonical_A2": float(a2.dice.mean()),
        "canonical_delta": float(a2.dice.mean() - a0.dice.mean()),
        "strict_null_p": 0.019801980198019802,
        "disagreement_count": int(table.decision_changed.sum()),
        "taxonomy_counts": taxonomy.set_index("taxonomy").findings.astype(int).to_dict(),
        "same_case_same_entity_A2_delta": float(
            subgroups.set_index("subgroup").loc["same_case_same_entity", "delta_A2_A0"]
        ),
        "fixed_guard_dice": float(fixed.dice.mean()),
        "fixed_guard_delta_vs_A2": float((fixed.dice - methods["A2"].dice).mean()),
        "crossfit_guard_dice": float(crossfit.dice.mean()),
        "crossfit_guard_delta_vs_A0": float((crossfit.dice - methods["A0"].dice).mean()),
        "crossfit_guard_delta_vs_A2": float((crossfit.dice - methods["A2"].dice).mean()),
        "crossfit_bootstrap": bootstrap,
        "guarded_strict_null": guarded_null,
        "output_dir": str(args.output_dir),
        "final_report": str(args.final_report),
    }
    atomic_json(result, args.output_dir / "result.json")
    print(json.dumps(result, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
