#!/usr/bin/env python3
"""Absolute-gradient reference audit for original-VoxTell C-global.

This diagnostic performs no optimizer step and does not recompute any of the
saved 32 C-pair gradients.  Its only GPU work is measuring the ordinary
segmentation-loss gradient on a deterministic canonical training stream.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import sys
import time
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]

from scripts import calibrate_original_voxtell_samecase as base  # noqa: E402
from scripts import recheck_original_voxtell_c_gradient_scaling as old_grad  # noqa: E402
from scripts import train_voxtell_rex_full_nnunet_aug as tr  # noqa: E402

DEFAULT_OUT = ROOT / "outputs/c_global_absolute_gradient_reference"
OLD_PAIR_TABLE = ROOT / "outputs/c_global_32pair_gradient_forensics/per_pair.tsv"
OLD_GRADIENT_TABLE = (
    ROOT
    / "outputs/original_voxtell_wholefinding_semantic/c_global/"
    "lambda_scaling_recheck/per_pair_gradients.tsv"
)
OLD_CALIBRATION = (
    ROOT
    / "outputs/original_voxtell_wholefinding_semantic/c_global/"
    "calibration/calibration.json"
)
LAMBDAS = (0.10, 0.25, 0.50, 1.00)


def write_tsv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise RuntimeError(f"Refusing to write empty table: {path}")
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def q(values: Iterable[float], quantile: float) -> float:
    array = np.asarray(list(values), dtype=np.float64)
    return float(np.quantile(array, quantile))


def describe(values: Iterable[float]) -> dict[str, float | int]:
    array = np.asarray(list(values), dtype=np.float64)
    if not array.size or not np.isfinite(array).all():
        raise RuntimeError("Reference distribution is empty or non-finite")
    return {
        "n": int(array.size),
        "mean": float(array.mean()),
        "median": float(np.median(array)),
        "p25": float(np.quantile(array, 0.25)),
        "p75": float(np.quantile(array, 0.75)),
        "p90": float(np.quantile(array, 0.90)),
        "p95": float(np.quantile(array, 0.95)),
        "max": float(array.max()),
    }


def make_canonical_sampler(
    config: dict[str, Any], cases: list[dict[str, Any]], embeddings: dict
) -> tr.RexPreprocessedSampler:
    """Recreate the exact historical B0 training sampler from recorded args."""
    sampler = tr.RexPreprocessedSampler(
        preprocessed_dir=Path(config["preprocessed_dir"]),
        cases=cases,
        embedding_map=embeddings,
        patch_size=tuple(config["patch_size"]),
        positive_prompts=int(config["positive_prompts"]),
        negative_prompts=int(config["negative_prompts"]),
        positive_loss_weight=float(config["positive_loss_weight"]),
        negative_loss_weight=float(config["negative_loss_weight"]),
        foreground_prob=float(config["foreground_prob"]),
        require_positive_crop=bool(config["require_positive_crop"]),
        min_positive_voxels=int(config["min_positive_voxels"]),
        max_crop_attempts=int(config["max_crop_attempts"]),
        max_sample_attempts=int(config["max_sample_attempts"]),
        cache_size=int(config["case_cache_size"]),
        augmenter=None,  # Historical B0 args record nnunet_augmentation=false.
        hard_negative_sampler=bool(config["hard_negative_sampler"]),
        hard_negative_match=str(config["hard_negative_match"]),
        hard_negative_exclude_identical_prompt=bool(
            config["hard_negative_exclude_identical_prompt"]
        ),
        sampler_mode=str(config["sampler_mode"]),
        anchor_positive_prob=float(config["anchor_positive_prob"]),
        same_case_negative_prob=float(config["same_case_negative_prob"]),
        shuffle_prompt_order=bool(config["shuffle_prompt_order"]),
        cross_case_negative_requires_foreground=bool(
            config["cross_case_negative_requires_foreground"]
        ),
        spatial_empty_foreground_prob=float(config["spatial_empty_foreground_prob"]),
        spatial_empty_around_other_prob=float(config["spatial_empty_around_other_prob"]),
        spatial_empty_near_anchor_prob=float(config["spatial_empty_near_anchor_prob"]),
        spatial_empty_far_anchor_prob=float(config["spatial_empty_far_anchor_prob"]),
        spatial_empty_hard_negative_prob=float(
            config["spatial_empty_hard_negative_prob"]
        ),
        anchor_hard_negative_prob=float(config["anchor_hard_negative_prob"]),
        category_balance_lambda=float(config["category_balance_lambda"]),
        category_balance_alpha=float(config["category_balance_alpha"]),
        category_balance_tau=float(config["category_balance_tau"]),
        prompt_embedding_selector=None,
        hybrid_lambda=float(config["hybrid_lambda"]),
        global_dual_positive_prob=float(config["global_dual_positive_prob"]),
        sampler_seed=int(config["sampler_seed"]),
    )
    return sampler


def loss_config(config: dict[str, Any]) -> dict[str, Any]:
    defaults = tr.parse_args([])
    defaults.steps = 8000
    defaults.rex_loss_mode = str(config["rex_loss_mode"])
    defaults.category_tversky_map = Path(config["category_tversky_map"])
    defaults.category_tversky_weight = float(config["category_tversky_weight"])
    return tr.loss_kwargs_from_args(defaults)


def shared_norm(
    grads: tuple[torch.Tensor | None, ...], indices: list[int]
) -> float:
    total = torch.zeros((), device="cuda", dtype=torch.float64)
    for index in indices:
        gradient = grads[index]
        if gradient is not None:
            total += gradient.detach().double().square().sum()
    return float(total.sqrt())


def measure_reference(sample_count: int, output: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    config = json.loads(base.ARGS.read_text())
    if bool(config.get("nnunet_augmentation")):
        raise RuntimeError("Recorded B0 unexpectedly enables augmentation")
    device = torch.device("cuda")
    model = base.make_model(config, device)
    manifest = tr.load_manifest(Path(config["preprocessed_dir"]))
    cases = tr.build_case_records(manifest, "train", None)
    embeddings = tr.load_embedding_map(Path(config["embedding_cache"]), "qwen")
    sampler = make_canonical_sampler(config, cases, embeddings)
    loss_kwargs = loss_config(config)
    params, groups, names = old_grad.parameter_groups(model)
    shared_indices = groups["all_shared"]
    group_audit = {
        "definition": "transformer_decoder + decoder + project_to_decoder_channels",
        "parameter_tensors": len(shared_indices),
        "parameters": int(sum(params[index].numel() for index in shared_indices)),
        "example_names": [names[index] for index in shared_indices[:12]],
    }
    expected_group = json.loads(
        (ROOT / "outputs/original_voxtell_wholefinding_semantic/c_global/"
         "lambda_scaling_recheck/parameter_groups.json").read_text()
    )["all_shared"]
    if (
        int(expected_group["parameter_tensors"]) != group_audit["parameter_tensors"]
        or int(expected_group["parameters"]) != group_audit["parameters"]
    ):
        raise RuntimeError(f"all_shared mismatch: {group_audit} vs {expected_group}")

    random.seed(int(config["sampler_seed"]))
    np.random.seed(int(config["sampler_seed"]))
    torch.manual_seed(int(config["seed"]))
    torch.cuda.manual_seed_all(int(config["seed"]))
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.cuda.reset_peak_memory_stats()

    rows: list[dict[str, Any]] = []
    started = time.time()
    for sample_index in range(sample_count):
        image, embedding, target, weight, meta = sampler.sample()
        image = image[None].to(device)
        embedding = embedding[None].to(device)
        target = target[None].to(device)
        weight = weight[None].to(device)
        model.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            output_value = model(image, embedding)
            logits = output_value[0] if isinstance(output_value, tuple) else output_value
            segmentation, _ = tr.segmentation_loss(
                logits,
                target,
                weight,
                prompt_categories=[meta["categories_after_shuffle"]],
                current_step=1,
                **loss_kwargs,
            )
        grads = torch.autograd.grad(
            segmentation, params, retain_graph=False, allow_unused=True
        )
        gradient_norm = shared_norm(grads, shared_indices)
        roles = list(meta.get("roles_after_shuffle", []))
        prompts = list(meta.get("prompt_texts_after_shuffle", []))
        categories = list(meta.get("categories_after_shuffle", []))
        target_voxels = [int(value) for value in meta.get("target_voxels", [])]
        rows.append(
            {
                "sample_index": sample_index,
                "case_id": str(meta["case"]),
                "sampler_mode": str(meta.get("sampler_mode", "")),
                "crop_mode": str(meta.get("crop_mode", "")),
                "prompt_count": len(prompts),
                "positive_prompt_count": sum("positive" in str(role).lower() for role in roles),
                "nonempty_target_count": sum(value > 0 for value in target_voxels),
                "L_seg": float(segmentation.detach()),
                "g_seg_ref_norm": gradient_norm,
                "roles": json.dumps(roles, ensure_ascii=False),
                "finding_ids": json.dumps(meta.get("prompt_indices_after_shuffle", [])),
                "categories": json.dumps(categories, ensure_ascii=False),
                "target_voxels": json.dumps(target_voxels),
                "prompts": json.dumps(prompts, ensure_ascii=False),
            }
        )
        del grads, output_value, logits, segmentation, image, embedding, target, weight
        print(
            f"NORMAL_SEG_GRADIENT {sample_index + 1}/{sample_count} "
            f"norm={gradient_norm:.8g} elapsed={time.time() - started:.1f}s",
            flush=True,
        )
    metadata = {
        "runtime_seconds": time.time() - started,
        "peak_gpu_memory_allocated_bytes": int(torch.cuda.max_memory_allocated()),
        "peak_gpu_memory_reserved_bytes": int(torch.cuda.max_memory_reserved()),
        "checkpoint": str(base.V11.resolve()),
        "args": str(base.ARGS.resolve()),
        "sampler": {
            "mode": config["sampler_mode"],
            "positive_prompts": config["positive_prompts"],
            "negative_prompts": config["negative_prompts"],
            "sampler_seed": config["sampler_seed"],
            "augmentation": bool(config["nnunet_augmentation"]),
        },
        "loss": {
            "mode": config["rex_loss_mode"],
            "category_map": config["category_tversky_map"],
            "category_weight": config["category_tversky_weight"],
        },
        "gradient_group": group_audit,
    }
    write_tsv(output / "normal_seg_gradients.tsv", rows)
    (output / "reference_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    return rows, metadata


def finite(value: str | float | int) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise RuntimeError(f"Non-finite value: {value}")
    return result


def analyze(
    reference_rows: list[dict[str, Any]], metadata: dict[str, Any], output: Path
) -> dict[str, Any]:
    if not OLD_PAIR_TABLE.exists() or not OLD_GRADIENT_TABLE.exists():
        raise FileNotFoundError("Existing 32-pair C-gradient audit is required")
    old_rows = read_tsv(OLD_PAIR_TABLE)
    old_raw = read_tsv(OLD_GRADIENT_TABLE)
    if len(old_rows) != 32 or len(old_raw) != 32:
        raise RuntimeError(f"Expected 32 saved C pairs; got {len(old_rows)} and {len(old_raw)}")
    for rich, raw in zip(old_rows, old_raw):
        identity_rich = (
            rich["case_id"], int(rich["target_finding_id"]), int(rich["wrong_finding_id"])
        )
        identity_raw = (
            raw["case_id"], int(raw["correct_finding_id"]), int(raw["wrong_finding_id"])
        )
        if identity_rich != identity_raw:
            raise RuntimeError(f"Saved pair identity mismatch: {identity_rich} != {identity_raw}")

    ref_stats = describe(finite(row["g_seg_ref_norm"]) for row in reference_rows)
    g_ref = float(ref_stats["median"])
    p25_ref = float(ref_stats["p25"])
    p95_ref = float(ref_stats["p95"])
    calibration = json.loads(OLD_CALIBRATION.read_text())
    margin = float(calibration["margin"])

    absolute_rows: list[dict[str, Any]] = []
    for rich, raw in zip(old_rows, old_raw):
        g_c = finite(raw["all_shared_c_norm"])
        pair_g_seg = finite(raw["all_shared_seg_norm"])
        absolute_rows.append(
            {
                "pair_index": int(rich["pair_index"]),
                "case_id": rich["case_id"],
                "target_finding_id": int(rich["target_finding_id"]),
                "wrong_finding_id": int(rich["wrong_finding_id"]),
                "pair_type": rich["pair_type"],
                "hinge_active": int(raw["hinge_active"]),
                "g_C_norm": g_c,
                "pair_specific_g_seg_norm": pair_g_seg,
                "old_pair_specific_ratio": g_c / max(pair_g_seg, 1e-30),
                "G_seg_ref_median": g_ref,
                "absolute_reference_ratio": g_c / max(g_ref, 1e-30),
                "target_gt_volume_preprocessed_voxels": int(
                    rich["target_gt_volume_preprocessed_voxels"]
                ),
                "target_finding": rich["target_finding"],
                "wrong_same_case_finding": rich["wrong_same_case_finding"],
            }
        )
    write_tsv(output / "c_pair_absolute_ratios.tsv", absolute_rows)

    top_n = int(math.ceil(0.20 * len(absolute_rows)))
    top = sorted(absolute_rows, key=lambda row: row["old_pair_specific_ratio"], reverse=True)[:top_n]
    tail_rows: list[dict[str, Any]] = []
    for row in top:
        small_denominator = float(row["pair_specific_g_seg_norm"]) < p25_ref
        extreme_c = float(row["g_C_norm"]) > p95_ref
        if small_denominator and extreme_c:
            mechanism = "MIXED"
        elif small_denominator:
            mechanism = "DENOMINATOR_DRIVEN"
        elif extreme_c:
            mechanism = "C_GRADIENT_DRIVEN"
        else:
            # For points inside both robust reference thresholds, compare how
            # far numerator and denominator sit from the normal median.  A
            # two-fold dominance is required for a single-cause label.
            denominator_factor = g_ref / max(float(row["pair_specific_g_seg_norm"]), 1e-30)
            numerator_factor = float(row["g_C_norm"]) / max(g_ref, 1e-30)
            if denominator_factor >= 2.0 * max(numerator_factor, 1e-30):
                mechanism = "DENOMINATOR_DRIVEN"
            elif numerator_factor >= 2.0 * max(denominator_factor, 1e-30):
                mechanism = "C_GRADIENT_DRIVEN"
            else:
                mechanism = "MIXED"
        tail_rows.append(
            {
                **row,
                "normal_seg_p25": p25_ref,
                "normal_seg_p95": p95_ref,
                "small_denominator_vs_normal_p25": int(small_denominator),
                "extreme_C_vs_normal_p95": int(extreme_c),
                "classification": mechanism,
            }
        )
    write_tsv(output / "top_tail_reclassification.tsv", tail_rows)

    ratios = np.asarray([float(row["absolute_reference_ratio"]) for row in absolute_rows])
    c_abs_stats = describe(float(row["g_C_norm"]) for row in absolute_rows)
    active_ratios = np.asarray(
        [float(row["absolute_reference_ratio"]) for row in absolute_rows if row["hinge_active"]]
    )
    # "Absolute" must mean unusual relative to the ordinary distribution,
    # not merely large relative to its median.  Compare like quantiles and
    # observed maxima between the C and ordinary-gradient distributions.
    raw_p95 = float(np.quantile(ratios, 0.95))
    raw_max = float(ratios.max())
    tail_genuinely_extreme = (
        float(c_abs_stats["p95"]) > float(ref_stats["p95"])
        or float(c_abs_stats["max"]) > float(ref_stats["max"])
    )

    lambda_rows: list[dict[str, Any]] = []
    for lam in LAMBDAS:
        weighted = lam * ratios
        lambda_rows.append(
            {
                "lambda": lam,
                "cap_c": "none",
                "median_lambda_gC_over_Gref": float(np.median(weighted)),
                "active_median_lambda_gC_over_Gref": float(np.median(lam * active_ratios)),
                "p75": float(np.quantile(weighted, 0.75)),
                "p90": float(np.quantile(weighted, 0.90)),
                "p95": float(np.quantile(weighted, 0.95)),
                "max": float(weighted.max()),
                "fraction_gt_0p5": float(np.mean(weighted > 0.5)),
                "fraction_gt_1": float(np.mean(weighted > 1.0)),
                "fraction_gt_2": float(np.mean(weighted > 2.0)),
                "fraction_capped": 0.0,
            }
        )
    if tail_genuinely_extreme:
        for cap_c in (1.0, 2.0):
            capped_ratios = np.minimum(ratios, cap_c)
            for lam in LAMBDAS:
                weighted = lam * capped_ratios
                lambda_rows.append(
                    {
                        "lambda": lam,
                        "cap_c": cap_c,
                        "median_lambda_gC_over_Gref": float(np.median(weighted)),
                        "active_median_lambda_gC_over_Gref": float(
                            np.median(lam * np.minimum(active_ratios, cap_c))
                        ),
                        "p75": float(np.quantile(weighted, 0.75)),
                        "p90": float(np.quantile(weighted, 0.90)),
                        "p95": float(np.quantile(weighted, 0.95)),
                        "max": float(weighted.max()),
                        "fraction_gt_0p5": float(np.mean(weighted > 0.5)),
                        "fraction_gt_1": float(np.mean(weighted > 1.0)),
                        "fraction_gt_2": float(np.mean(weighted > 2.0)),
                        "fraction_capped": float(np.mean(ratios > cap_c)),
                    }
                )
    write_tsv(output / "lambda_simulation.tsv", lambda_rows)

    # Decision criteria: a static lambda is acceptable only when it provides a
    # visible central contribution on hinge-active pairs while keeping the
    # complete-cohort absolute p95 below one normal segmentation-gradient unit
    # and max below two. Prefer the largest qualifying lambda. A cap is
    # considered only if the absolute C distribution is genuinely more extreme
    # than the ordinary reference and <=25% of pairs are capped.
    def qualifies(row: dict[str, Any]) -> bool:
        return (
            float(row["active_median_lambda_gC_over_Gref"]) >= 0.10
            and float(row["p95"]) <= 1.0
            and float(row["max"]) <= 2.0
        )

    uncapped = [row for row in lambda_rows if row["cap_c"] == "none" and qualifies(row)]
    capped = [
        row
        for row in lambda_rows
        if row["cap_c"] != "none"
        and qualifies(row)
        and float(row["fraction_capped"]) <= 0.25
    ]
    if uncapped:
        chosen = max(uncapped, key=lambda row: float(row["lambda"]))
        recommendation = "TRY_STATIC_LAMBDA"
    elif capped:
        chosen = max(capped, key=lambda row: (float(row["lambda"]), float(row["cap_c"])))
        recommendation = "TRY_STATIC_LAMBDA_WITH_SIMPLE_CAP"
    else:
        chosen = None
        recommendation = "NEED_PER_PAIR_NORMALIZATION_STUDY"

    classification_counts: dict[str, int] = {}
    for row in tail_rows:
        key = str(row["classification"])
        classification_counts[key] = classification_counts.get(key, 0) + 1

    summary = {
        "normal_seg_reference": ref_stats,
        "g_C_absolute": c_abs_stats,
        "g_C_over_G_seg_ref": describe(ratios),
        "active_g_C_over_G_seg_ref": describe(active_ratios),
        "top_tail_classification": classification_counts,
        "tail_genuinely_extreme": tail_genuinely_extreme,
        "tail_extreme_rule": "p95(g_C)>p95(normal g_seg) or max(g_C)>max(normal g_seg)",
        "recommendation": recommendation,
        "chosen_simulation": chosen,
        "margin": margin,
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    write_report(output, metadata, summary, tail_rows, lambda_rows)
    return summary


def fmt(value: Any) -> str:
    return f"{float(value):.6g}"


def write_report(
    output: Path,
    metadata: dict[str, Any],
    summary: dict[str, Any],
    tail_rows: list[dict[str, Any]],
    lambda_rows: list[dict[str, Any]],
) -> None:
    ref = summary["normal_seg_reference"]
    absolute = summary["g_C_over_G_seg_ref"]
    c_abs = summary["g_C_absolute"]
    selected = summary["chosen_simulation"]
    counts = summary["top_tail_classification"]
    lines = [
        "# C-global absolute-gradient reference audit",
        "",
        f"**Recommendation: {summary['recommendation']}**",
        "",
        "This is a frozen-model gradient diagnostic. It performed no optimizer update, did not recompute or resample the existing 32 C pairs, and did not run inference.",
        "",
        "## Exact setup",
        "",
        f"- Checkpoint: `{metadata['checkpoint']}`",
        f"- Normal reference samples: `{ref['n']}` ordinary canonical B0 training micro-samples.",
        f"- Canonical sampler: `{metadata['sampler']['mode']}`, 2 positive + 1 negative prompts, sampler seed `{metadata['sampler']['sampler_seed']}`, augmentation `{metadata['sampler']['augmentation']}`.",
        f"- Normal objective: `{metadata['loss']['mode']}` full prompt-set segmentation loss with the recorded category map.",
        f"- C objective: `max(0, {summary['margin']:.9g} + L_correct - L_wrong)`; the saved exact 32-pair gradients were reused unchanged.",
        f"- Shared parameter group: `{metadata['gradient_group']['definition']}`; `{metadata['gradient_group']['parameter_tensors']}` tensors / `{metadata['gradient_group']['parameters']}` parameters.",
        "- Both reference and saved C gradients use the frozen v1.1 model in evaluation mode and BF16 autocast.",
        "",
        "## Normal segmentation-gradient reference",
        "",
        "| Statistic | ||g_seg|| |",
        "|---|---:|",
    ]
    for key in ("median", "p25", "p75", "p90", "p95", "max"):
        lines.append(f"| {key} | {fmt(ref[key])} |")
    lines += [
        "",
        f"Robust reference `G_seg_ref = median(||g_seg||) = {fmt(ref['median'])}`.",
        "",
        "## Absolute C-gradient scale",
        "",
        "| Quantity | median | p75 | p90 | p95 | max |",
        "|---|---:|---:|---:|---:|---:|",
        f"| `||g_C||` | {fmt(c_abs['median'])} | {fmt(c_abs['p75'])} | {fmt(c_abs['p90'])} | {fmt(c_abs['p95'])} | {fmt(c_abs['max'])} |",
        f"| `||g_C|| / G_seg_ref` | {fmt(absolute['median'])} | {fmt(absolute['p75'])} | {fmt(absolute['p90'])} | {fmt(absolute['p95'])} | {fmt(absolute['max'])} |",
        "",
        "## Old-ratio top-tail reclassification",
        "",
        "Primary criteria: `pair g_seg < normal p25` marks a strongly small denominator; `g_C > normal p95` marks an absolutely extreme C gradient; both marks mixed. If neither robust tail threshold is crossed, two-fold dominance of distance from the normal median assigns the mechanism, otherwise it is mixed.",
        "",
        f"Classification counts among the top {len(tail_rows)}/32 old pair-specific ratios: `{json.dumps(counts, sort_keys=True)}`.",
        "",
        "| pair | case | old ratio | g_C/G_ref | pair g_seg | g_C | class |",
        "|---:|---|---:|---:|---:|---:|---|",
    ]
    for row in tail_rows:
        lines.append(
            f"| {row['pair_index']} | {row['case_id']} | {fmt(row['old_pair_specific_ratio'])} | "
            f"{fmt(row['absolute_reference_ratio'])} | {fmt(row['pair_specific_g_seg_norm'])} | "
            f"{fmt(row['g_C_norm'])} | {row['classification']} |"
        )
    lines += [
        "",
        "## Static-lambda simulation against robust reference",
        "",
        "| lambda | cap c | all-pair median | active-pair median | p90 | p95 | max | frac >1 | frac capped |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in lambda_rows:
        lines.append(
            f"| {fmt(row['lambda'])} | {row['cap_c']} | {fmt(row['median_lambda_gC_over_Gref'])} | "
            f"{fmt(row['active_median_lambda_gC_over_Gref'])} | "
            f"{fmt(row['p90'])} | {fmt(row['p95'])} | {fmt(row['max'])} | "
            f"{fmt(row['fraction_gt_1'])} | {fmt(row['fraction_capped'])} |"
        )
    lines += [
        "",
        "A simple cap was simulated only because the predefined absolute-tail rule was met." if summary["tail_genuinely_extreme"] else "The predefined absolute-tail rule was not met, so no cap simulation was needed.",
        "",
        "Decision rule: accept a candidate only if the hinge-active median weighted absolute ratio is at least 0.10, complete-cohort p95 is at most 1.0, and max is at most 2.0; a capped candidate must additionally cap no more than 25% of pairs.",
        "",
        "## Required answers",
        "",
        f"1. **Is the C gradient tail genuinely large in absolute terms?** {'YES' if summary['tail_genuinely_extreme'] else 'NO'}. C p95/max are `{fmt(c_abs['p95'])}/{fmt(c_abs['max'])}` versus ordinary p95/max `{fmt(ref['p95'])}/{fmt(ref['max'])}`; `g_C/G_ref` p95/max are `{fmt(absolute['p95'])}/{fmt(absolute['max'])}`.",
        f"2. **Is the old extreme-ratio problem mainly denominator-driven?** The robust classification is `{json.dumps(counts, sort_keys=True)}`; this separates small-denominator and absolute-C effects rather than inferring from a ratio alone.",
        "3. **Would a static lambda look acceptable relative to ordinary training gradients?** " + (f"YES under the selected simulation `{selected}`." if selected is not None else "NO under the predefined central-scale and tail-control criteria."),
        "4. **Would a simple cap help materially?** " + ("YES; it is required by the selected acceptable simulation." if summary["recommendation"] == "TRY_STATIC_LAMBDA_WITH_SIMPLE_CAP" else "No cap is needed for the selected recommendation." if summary["recommendation"] == "TRY_STATIC_LAMBDA" else "No tested simple cap yields an acceptable robust-reference distribution under the predefined criteria."),
        "5. **Does pairwise normalization still appear necessary?** " + ("YES; static scaling and the optional simple caps did not adequately control the absolute distribution." if summary["recommendation"] == "NEED_PER_PAIR_NORMALIZATION_STUDY" else "Not as the next step; a lower-complexity static pilot is supported first."),
        f"6. **Recommended next step:** `{summary['recommendation']}`.",
        "7. **Lowest-complexity path back to C training:** use the selected static/capped pilot if one passed; otherwise perform the requested per-pair-normalization study before training. This audit itself implements neither.",
        "",
        "## Provenance and runtime",
        "",
        f"- Existing saved C gradients: `{OLD_GRADIENT_TABLE.resolve()}`",
        f"- Existing exact-pair metadata: `{OLD_PAIR_TABLE.resolve()}`",
        f"- Normal-reference table: `{(output / 'normal_seg_gradients.tsv').resolve()}`",
        f"- GPU runtime: `{metadata['runtime_seconds']:.2f}` seconds",
        f"- Peak allocated GPU memory: `{metadata['peak_gpu_memory_allocated_bytes'] / 2**30:.3f}` GiB",
        f"- Peak reserved GPU memory: `{metadata['peak_gpu_memory_reserved_bytes'] / 2**30:.3f}` GiB",
        "",
    ]
    (output / "report.md").write_text("\n".join(lines))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", type=int, default=64)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--reuse-reference", action="store_true")
    args = parser.parse_args()
    if not 32 <= args.samples <= 64:
        raise ValueError("Use 32-64 normal reference samples; 64 is preferred")
    args.output.mkdir(parents=True, exist_ok=True)
    if args.reuse_reference:
        rows = read_tsv(args.output / "normal_seg_gradients.tsv")
        metadata = json.loads((args.output / "reference_metadata.json").read_text())
        if len(rows) != args.samples:
            raise RuntimeError(f"Expected {args.samples} saved reference rows, got {len(rows)}")
    else:
        rows, metadata = measure_reference(args.samples, args.output)
    summary = analyze(rows, metadata, args.output)
    print(json.dumps(summary, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
