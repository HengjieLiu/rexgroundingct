#!/usr/bin/env python3
"""Audit VoxTell's native 1/2-resolution decoder response maps on a fixed ReX subset."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from scipy import ndimage
from sklearn.metrics import average_precision_score, roc_auc_score
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "VoxTell", ROOT / "scripts"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from diagnose_spatial_attention_localization import load_rex_masks_in_preprocessed_ras
from run_voxtell_rex_inference import load_entries, load_image, sorted_finding_keys, sorted_prompts
from voxtell.inference.predictor import VoxTellPredictor


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--selected-findings", type=Path, required=True)
    parser.add_argument("--rex-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--mask-dir", type=Path, default=ROOT / "data/segmentations")
    parser.add_argument("--model-dir", type=Path, default=ROOT / "VoxTell/voxtell_v1.1")
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--shuffle-seed", type=int, default=20260716)
    parser.add_argument("--max-background-samples", type=int, default=200000)
    parser.add_argument("--max-visualizations", type=int, default=8)
    return parser.parse_args()


def dice(pred: np.ndarray, target: np.ndarray) -> float:
    denom = int(pred.sum()) + int(target.sum())
    return 1.0 if denom == 0 else float(2 * np.logical_and(pred, target).sum() / denom)


def sampled_rank_metrics(response: np.ndarray, target: np.ndarray, background_cap: int, rng) -> dict[str, float]:
    """Compute AP/AUROC on all foreground and a bounded random background sample."""
    target = target.astype(bool, copy=False)
    fg = response[target]
    bg = response[~target]
    if fg.size == 0 or bg.size == 0:
        return {"native_voxel_ap": float("nan"), "native_voxel_auroc": float("nan")}
    if bg.size > background_cap:
        bg = bg[rng.choice(bg.size, size=background_cap, replace=False)]
    if fg.size > background_cap:
        fg = fg[rng.choice(fg.size, size=background_cap, replace=False)]
    labels = np.concatenate([np.ones(fg.size, dtype=np.uint8), np.zeros(bg.size, dtype=np.uint8)])
    scores = np.concatenate([fg, bg])
    return {
        "native_voxel_ap": float(average_precision_score(labels, scores)),
        "native_voxel_auroc": float(roc_auc_score(labels, scores)),
    }


def response_metrics(response: np.ndarray, target: np.ndarray, background_cap: int, rng) -> dict[str, float | bool]:
    target = target.astype(bool, copy=False)
    inside = response[target]
    outside = response[~target]
    if inside.size == 0:
        raise ValueError("A selected finding has an empty target")
    cutoff = float(np.quantile(response, 0.95))
    top5 = response >= cutoff
    peak = np.unravel_index(int(np.argmax(response)), response.shape)
    pointing_hit = bool(target[peak])
    distance = 0.0 if pointing_hit else float(ndimage.distance_transform_edt(~target)[peak])
    intersection = int(np.logical_and(top5, target).sum())
    return {
        "native_inside_gt_mean": float(inside.mean()),
        "native_outside_gt_mean": float(outside.mean()),
        "native_inside_minus_outside": float(inside.mean() - outside.mean()),
        "native_top5_gt_precision": intersection / max(int(top5.sum()), 1),
        "native_top5_gt_recall": intersection / max(int(target.sum()), 1),
        "native_pointing_hit": pointing_hit,
        "native_peak_distance_voxels": distance,
        **sampled_rank_metrics(response, target, background_cap, rng),
    }


def segmentation_metrics(prob: np.ndarray, target: np.ndarray) -> dict[str, float | int | bool]:
    pred = prob >= 0.5
    tp = int(np.logical_and(pred, target).sum())
    fp = int(np.logical_and(pred, ~target).sum())
    fn = int(np.logical_and(~pred, target).sum())
    return {
        "segmentation_dice": dice(pred, target),
        "segmentation_precision": tp / max(tp + fp, 1),
        "segmentation_recall": tp / max(tp + fn, 1),
        "segmentation_hit": bool(tp > 0),
        "pred_voxels": int(pred.sum()),
        "false_positive_voxels": fp,
        "empty_prediction": bool(pred.sum() == 0),
    }


def map_correlation(first: np.ndarray, second: np.ndarray, cap: int = 250000) -> float:
    a = first.reshape(-1); b = second.reshape(-1)
    if a.size > cap:
        stride = max(1, a.size // cap)
        a = a[::stride][:cap]; b = b[::stride][:cap]
    if np.std(a) < 1e-8 or np.std(b) < 1e-8:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def save_visualization(path: Path, ct: np.ndarray, target: np.ndarray, correct: np.ndarray, shuffled: np.ndarray, row: dict) -> None:
    z = int(np.argmax(target.sum(axis=(1, 2))))
    image = ct[z]
    low, high = np.percentile(image, [1, 99])
    lo, hi = np.percentile(np.concatenate([correct.ravel()[::32], shuffled.ravel()[::32]]), [2, 98])
    if math.isclose(lo, hi):
        lo, hi = float(correct.min()), float(correct.max() + 1e-6)
    fig, axes = plt.subplots(1, 5, figsize=(21, 4.3), constrained_layout=True)
    for ax in axes:
        ax.imshow(image, cmap="gray", vmin=low, vmax=high); ax.axis("off")
    axes[0].set_title("CT")
    axes[1].contour(target[z], [0.5], colors="lime", linewidths=1.5); axes[1].set_title("GT")
    for axis, value, title in ((axes[2], correct[z], "Native: correct prompt"), (axes[3], shuffled[z], "Native: shuffled prompt")):
        overlay = axis.imshow(value, cmap="magma", alpha=.68, vmin=lo, vmax=hi)
        axis.contour(target[z], [0.5], colors="lime", linewidths=1.2); axis.set_title(title)
    top5 = correct[z] >= np.quantile(correct, .95)
    axes[4].contour(target[z], [0.5], colors="lime", linewidths=1.5)
    axes[4].contour(top5, [0.5], colors="cyan", linewidths=1.2); axes[4].set_title("GT green / native top-5% cyan")
    fig.colorbar(overlay, ax=axes[2:4], shrink=.85, label="native response")
    fig.suptitle(
        f"{row['case_id']} finding {row['finding_idx']} {row['category']} | AP={row['native_voxel_ap']:.3f} | "
        f"correct-shuffled margin={row['native_inside_minus_outside_delta_vs_shuffled']:+.3g}\n"
        f"correct: {row['prompt']}\nshuffled: {row['shuffled_prompt']}", fontsize=9
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=150); plt.close(fig)


def main() -> int:
    args = parse_args(); args.output_dir.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(args.manifest.read_text())
    selected_cases = set(manifest["cases"])
    selected = pd.read_csv(args.selected_findings)
    selected = selected[selected["case"].isin(selected_cases)].copy()
    if selected["case"].nunique() != 30:
        raise ValueError(f"Expected fixed 30-case manifest, found {selected['case'].nunique()} selected cases")
    entries = {item["name"]: item for item in load_entries(args.rex_json, ["val"])}
    selected["prompt"] = [
        sorted_prompts(entries[case])[int(finding_idx)]
        for case, finding_idx in zip(selected["case"], selected["finding_idx"])
    ]
    selected["shuffled_prompt"] = ""; selected["shuffled_source"] = ""
    rng = np.random.default_rng(args.shuffle_seed)
    rows = selected.index.to_numpy(); shuffled_rows = rng.permutation(rows)
    for destination, source in zip(rows, shuffled_rows):
        if selected.loc[source, "prompt"] == selected.loc[destination, "prompt"]:
            source = rows[(np.where(rows == source)[0][0] + 1) % len(rows)]
        selected.loc[destination, "shuffled_prompt"] = selected.loc[source, "prompt"]
        selected.loc[destination, "shuffled_source"] = f"{selected.loc[source, 'case']}:finding{int(selected.loc[source, 'finding_idx'])}"
    selected.to_csv(args.output_dir / "selected_findings_with_shuffle.csv", index=False)

    device = torch.device(f"cuda:{args.gpu}" if args.device == "cuda" else "cpu")
    predictor = VoxTellPredictor(str(args.model_dir), device=device)
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    incompatible = predictor.network.load_state_dict(checkpoint["network_weights"], strict=True)
    if incompatible.missing_keys or incompatible.unexpected_keys:
        raise RuntimeError(f"Checkpoint mismatch: {incompatible}")
    predictor.network.eval()
    metric_rows = []
    rng = np.random.default_rng(args.shuffle_seed + 1)
    for case, case_rows in tqdm(selected.groupby("case", sort=True), desc="Native response audit", unit="case"):
        entry = entries[case]
        image, props = load_image(args.image_dir / case)
        data, bbox, _ = predictor.preprocess(image)
        prompts = sorted_prompts(entry); keys = sorted_finding_keys(entry)
        target = load_rex_masks_in_preprocessed_ras(args.mask_dir / case, props, len(prompts), bbox).numpy().astype(bool)
        finding_indices = [int(value) for value in case_rows["finding_idx"]]
        # VoxTell decodes prompts sequentially. The fixed manifest contains one selected finding per case,
        # so sending only selected prompts avoids re-running unrelated findings without changing this audit.
        correct_prompts = [prompts[index] for index in finding_indices]
        correct_embed = predictor.embed_text_prompts(correct_prompts)
        correct_logits, native = predictor.predict_sliding_window_return_logits(data, correct_embed, return_native_response_maps=True)
        shuffled_prompts = [str(source.shuffled_prompt) for source in case_rows.itertuples(index=False)]
        shuffled_embed = predictor.embed_text_prompts(shuffled_prompts)
        _, shuffled_native = predictor.predict_sliding_window_return_logits(data, shuffled_embed, return_native_response_maps=True)
        probs = torch.sigmoid(correct_logits.float()).cpu().numpy(); native = native.float().cpu().numpy(); shuffled_native = shuffled_native.float().cpu().numpy()
        for local_index, source in enumerate(case_rows.itertuples(index=False)):
            finding_idx = int(source.finding_idx); gt = target[finding_idx]
            correct_metrics = response_metrics(native[local_index], gt, args.max_background_samples, rng)
            shuffled_metrics = response_metrics(shuffled_native[local_index], gt, args.max_background_samples, rng)
            row = {"case_id": case, "finding_idx": finding_idx, "category": str(source.category), "focality": "non-focal" if str(source.category).startswith("1") else "focal", "prompt": correct_prompts[local_index], "shuffled_prompt": shuffled_prompts[local_index], "shuffled_source": source.shuffled_source, **segmentation_metrics(probs[local_index], gt), **correct_metrics}
            for key, value in shuffled_metrics.items(): row[f"shuffled_{key}"] = value
            row["native_inside_minus_outside_delta_vs_shuffled"] = row["native_inside_minus_outside"] - row["shuffled_native_inside_minus_outside"]
            row["native_map_correlation_with_shuffled"] = map_correlation(
                native[local_index], shuffled_native[local_index]
            )
            metric_rows.append(row)
    frame = pd.DataFrame(metric_rows); frame.to_csv(args.output_dir / "native_response_metrics.csv", index=False)
    frame[["case_id", "finding_idx", "category", "native_inside_minus_outside_delta_vs_shuffled", "native_map_correlation_with_shuffled", "native_voxel_ap", "shuffled_native_voxel_ap"]].to_csv(args.output_dir / "prompt_specificity_metrics.csv", index=False)
    summary = frame.groupby(["focality", "category"], dropna=False).agg(n=("case_id", "size"), dice=("segmentation_dice", "mean"), native_ap=("native_voxel_ap", "mean"), native_auroc=("native_voxel_auroc", "mean"), margin=("native_inside_minus_outside", "mean"), correct_minus_shuffled=("native_inside_minus_outside_delta_vs_shuffled", "mean"), map_correlation=("native_map_correlation_with_shuffled", "mean"), hit_rate=("segmentation_hit", "mean")).reset_index()
    summary.to_csv(args.output_dir / "native_response_summary_by_group.csv", index=False)
    examples = pd.concat([frame.nsmallest(2, "native_voxel_ap"), frame.nlargest(2, "native_voxel_ap"), frame.nsmallest(2, "native_inside_minus_outside_delta_vs_shuffled"), frame.nlargest(2, "native_inside_minus_outside_delta_vs_shuffled")]).drop_duplicates(["case_id", "finding_idx"]).head(args.max_visualizations)
    for row in tqdm(examples.itertuples(index=False), desc="Native response PNGs", unit="finding"):
        # Regenerate only selected examples. Retaining all 30 full volumes would waste host memory.
        entry = entries[row.case_id]
        image, props = load_image(args.image_dir / row.case_id)
        data, bbox, _ = predictor.preprocess(image)
        prompts = sorted_prompts(entry)
        target = load_rex_masks_in_preprocessed_ras(args.mask_dir / row.case_id, props, len(prompts), bbox).numpy().astype(bool)
        finding_idx = int(row.finding_idx)
        _, native = predictor.predict_sliding_window_return_logits(
            data, predictor.embed_text_prompts([prompts[finding_idx]]), return_native_response_maps=True
        )
        _, shuffled_native = predictor.predict_sliding_window_return_logits(
            data, predictor.embed_text_prompts([row.shuffled_prompt]), return_native_response_maps=True
        )
        save_visualization(
            args.output_dir / "native_response_visualizations" / f"{row.case_id.removesuffix('.nii.gz')}_finding{row.finding_idx}.png",
            data[0].numpy(), target[finding_idx], native[0].float().cpu().numpy(),
            shuffled_native[0].float().cpu().numpy(), row._asdict(),
        )
    report = ["# Native VoxTell Response-Map Audit", "", f"- Fixed manifest: `{args.manifest}`", "- Map: native 1/2-resolution pre-concatenation response, fixed mean over 32 channels, upsampled only for metric alignment.", "- Prompt condition: original ReX prompt versus deterministic non-identical shuffled prompt.", "", "## Aggregate", "", summary.to_markdown(index=False), "", f"- Overall Dice: {frame.segmentation_dice.mean():.4f}; hit rate: {frame.segmentation_hit.mean():.3f}.", f"- Mean native voxel AP: {frame.native_voxel_ap.mean():.4f}; mean correct-minus-shuffled localization margin: {frame.native_inside_minus_outside_delta_vs_shuffled.mean():+.5f}.", f"- Mean correct/shuffled map correlation: {frame.native_map_correlation_with_shuffled.mean():.4f}."]
    (args.output_dir / "native_response_report.md").write_text("\n".join(report) + "\n")
    print(f"Wrote {len(frame)} findings to {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
