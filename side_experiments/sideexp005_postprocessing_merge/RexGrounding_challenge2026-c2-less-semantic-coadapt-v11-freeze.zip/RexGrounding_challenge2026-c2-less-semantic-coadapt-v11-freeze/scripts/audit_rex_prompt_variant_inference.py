#!/usr/bin/env python
"""Inference-only prompt sensitivity audit on a fixed ReX validation subset."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from difflib import SequenceMatcher
from pathlib import Path

import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import torch
from scipy import ndimage
from tqdm import tqdm


REX_ROOT = Path(__file__).resolve().parents[1]
VOXTELL_ROOT = REX_ROOT / "VoxTell"
NNUNET_ROOT = REX_ROOT / "nnUNet"
for path in (VOXTELL_ROOT, NNUNET_ROOT, REX_ROOT / "scripts"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from run_voxtell_rex_inference import (  # noqa: E402
    load_entries,
    load_image,
    load_reference_mask_for_window_diagnostic,
    select_entries,
    sorted_finding_keys,
    sorted_prompts,
)
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402
from voxtell.utils.prompt_embedding_cache import load_embedding_cache  # noqa: E402
from voxtell.utils.prompt_standardization import finding_id, load_sidecar  # noqa: E402


VARIANT_FIELDS = {
    "original": "original_prompt",
    "canonical_visual": "canonical_visual_prompt",
    "disease_only": "disease_only_prompt",
    "disease_anatomy": "disease_anatomy_prompt",
}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rex-json", type=Path, default=REX_ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--split", default="val")
    parser.add_argument("--image-dir", type=Path, default=REX_ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--mask-dir", type=Path, default=REX_ROOT / "data/segmentations")
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        help="Optional clean VoxTell checkpoint whose network_weights replace model-dir weights.",
    )
    parser.add_argument("--sidecar", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--variants", nargs="+", choices=list(VARIANT_FIELDS), default=list(VARIANT_FIELDS))
    parser.add_argument("--cases", nargs="+")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--text-encoding-model", default="Qwen/Qwen3-Embedding-4B")
    parser.add_argument("--embedding-cache", nargs="*", type=Path, default=[])
    parser.add_argument(
        "--anatomy-prior-dir",
        type=Path,
        help="Optional per-case TotalSegmentator lung-prior root for movement diagnostics.",
    )
    return parser.parse_args()


def size_bin(voxels: int) -> str:
    if voxels < 100:
        return "tiny_lt100"
    if voxels < 1000:
        return "small_100_999"
    if voxels < 10000:
        return "medium_1k_9999"
    return "large_ge10k"


def binary_dice(a: np.ndarray, b: np.ndarray) -> float:
    denom = int(a.sum()) + int(b.sum())
    return 1.0 if denom == 0 else 2.0 * float(np.logical_and(a, b).sum()) / denom


def probability_correlation(a: np.ndarray, b: np.ndarray) -> float:
    x = a.astype(np.float64, copy=False).ravel()
    y = b.astype(np.float64, copy=False).ravel()
    x = x - x.mean(); y = y - y.mean()
    denom = math.sqrt(float(np.dot(x, x)) * float(np.dot(y, y)))
    return float(np.dot(x, y) / denom) if denom > 0 else float("nan")


def prompt_metrics(prob: np.ndarray, target: np.ndarray, threshold: float, voxel_mm3: float) -> dict:
    pred = prob > threshold
    gt = target > 0
    tp = int(np.logical_and(pred, gt).sum())
    fp = int(np.logical_and(pred, ~gt).sum())
    fn = int(np.logical_and(~pred, gt).sum())
    pred_voxels = int(pred.sum()); gt_voxels = int(gt.sum())
    return {
        "dice": binary_dice(pred, gt),
        "positive_recall": tp / max(tp + fn, 1),
        "precision": tp / max(tp + fp, 1),
        "fp_volume_mm3": fp * voxel_mm3,
        "pred_voxels": pred_voxels,
        "gt_voxels": gt_voxels,
        "pred_gt_volume_ratio": pred_voxels / max(gt_voxels, 1),
        "empty_prediction": pred_voxels == 0,
        "gross_oversegmentation": gt_voxels > 0 and pred_voxels / gt_voxels >= 5.0,
        "connected_components": int(ndimage.label(pred)[1]),
    }


LOBE_PRIORS = {
    "RUL": "lung_upper_lobe_right",
    "RML": "lung_middle_lobe_right",
    "RLL": "lung_lower_lobe_right",
    "LUL": "lung_upper_lobe_left",
    "LLL": "lung_lower_lobe_left",
}


def load_cropped_anatomy_priors(prior_dir: Path | None, case: str, original_shape, bbox) -> dict[str, np.ndarray]:
    if prior_dir is None:
        return {}
    case_dir = prior_dir / case.removesuffix(".nii.gz")
    names = {"left": "left_lung", "right": "right_lung", **LOBE_PRIORS}
    output = {}
    for label, filename in names.items():
        path = case_dir / f"{filename}.nii.gz"
        if not path.exists():
            path = case_dir / "totalseg" / f"{filename}.nii.gz"
        if not path.exists():
            continue
        data, _ = load_image(path)
        if tuple(data.shape[1:]) != tuple(original_shape):
            continue
        output[label] = data[(0, *tuple(
            item if isinstance(item, slice) else slice(int(item[0]), int(item[1])) for item in bbox
        ))] > 0
    return output


def dominant_region(prediction: np.ndarray, priors: dict[str, np.ndarray], labels: list[str]) -> str | None:
    overlaps = {label: int(np.logical_and(prediction, priors[label]).sum()) for label in labels if label in priors}
    if not overlaps or max(overlaps.values()) == 0:
        return None
    return max(overlaps, key=overlaps.get)


def load_audit_embedding_caches(paths: list[Path]) -> tuple[dict, dict]:
    caches = {}
    for path in paths:
        cache = load_embedding_cache(path)
        variant = cache["metadata"].get("prompt_variant", "")
        caches[variant] = cache
    original = caches.get("original_prompt")
    if original is None:
        return {}, {
            metadata_variant.removesuffix("_prompt"): cache["mapping"]
            for metadata_variant, cache in caches.items()
        }
    result = {}
    for variant, cache in caches.items():
        if variant == "original_prompt":
            continue
        for key, embedding in cache["mapping"].items():
            if key in original["mapping"]:
                result[(*key, variant)] = float(torch.nn.functional.cosine_similarity(
                    original["mapping"][key][None], embedding[None]
                ).item())
    variant_mappings = {
        metadata_variant.removesuffix("_prompt"): cache["mapping"]
        for metadata_variant, cache in caches.items()
    }
    return result, variant_mappings


def write_visualization(path: Path, image: np.ndarray, gt: np.ndarray, probs: dict[str, np.ndarray], title: str):
    signal = gt.sum(axis=(1, 2))
    if signal.max() == 0:
        signal = sum(prob.sum(axis=(1, 2)) for prob in probs.values())
    z = int(np.argmax(signal))
    names = ["CT", "GT", *probs]
    fig, axes = plt.subplots(1, len(names), figsize=(4 * len(names), 4), constrained_layout=True)
    axes[0].imshow(image[z], cmap="gray"); axes[0].set_title("CT")
    axes[1].imshow(image[z], cmap="gray"); axes[1].imshow(gt[z], alpha=0.45, cmap="Greens"); axes[1].set_title("GT")
    for axis, (name, prob) in zip(axes[2:], probs.items()):
        axis.imshow(image[z], cmap="gray")
        overlay = axis.imshow(prob[z], alpha=0.55, cmap="magma", vmin=0, vmax=1)
        axis.set_title(name)
        fig.colorbar(overlay, ax=axis, fraction=0.046)
    for axis in axes:
        axis.axis("off")
    fig.suptitle(title, fontsize=10)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=140); plt.close(fig)


def summarize(rows: list[dict]) -> list[dict]:
    output = []
    dimensions = [
        None,
        "focality",
        "size_bin",
        "location_specific",
        "embedding_similarity_bin",
        "text_modification_bin",
        "category",
        "non_atomic_flag",
        "conversion_confidence_bin",
    ]
    for dimension in dimensions:
        groups = {"all": rows} if dimension is None else {}
        if dimension is not None:
            for row in rows:
                groups.setdefault(str(row[dimension]), []).append(row)
        for group, group_rows in sorted(groups.items()):
            for variant in sorted({row["variant"] for row in group_rows}):
                selected = [row for row in group_rows if row["variant"] == variant]
                correlations = [
                    row["probability_correlation_to_original"] for row in selected
                    if math.isfinite(row["probability_correlation_to_original"])
                ]
                output.append({
                    "stratum": dimension or "overall",
                    "group": group,
                    "variant": variant,
                    "findings": len(selected),
                    "mean_global_dice": float(np.mean([row["dice"] for row in selected])),
                    "mean_positive_dice": float(np.nanmean([row["positive_dice"] for row in selected])),
                    "mean_positive_recall": float(np.mean([row["positive_recall"] for row in selected])),
                    "mean_precision": float(np.mean([row["precision"] for row in selected])),
                    "mean_fp_volume_mm3": float(np.mean([row["fp_volume_mm3"] for row in selected])),
                    "mean_pred_gt_volume_ratio": float(np.mean([row["pred_gt_volume_ratio"] for row in selected])),
                    "mean_prediction_dice_vs_original": float(np.mean([row["prediction_dice_vs_original"] for row in selected])),
                    "mean_absolute_probability_difference": float(np.mean([row["mean_absolute_probability_difference"] for row in selected])),
                    "mean_probability_correlation_to_original": float(np.mean(correlations)) if correlations else float("nan"),
                    "mean_changed_foreground_voxels": float(np.mean([row["changed_foreground_voxels"] for row in selected])),
                    "empty_predictions": sum(row["empty_prediction"] for row in selected),
                    "gross_oversegmentations": sum(row["gross_oversegmentation"] for row in selected),
                    "anatomically_incorrect_movements": sum(row["anatomically_incorrect_movement"] for row in selected),
                })
    return output


def similarity_bin(value: float | None) -> str:
    if value is None or not math.isfinite(value):
        return "missing_or_original"
    if value >= 0.95:
        return "high_ge0p95"
    if value >= 0.80:
        return "medium_0p80_0p95"
    return "low_lt0p80"


def modification_bin(value: float) -> str:
    if value <= 0.10:
        return "small_le0p10"
    if value <= 0.40:
        return "medium_0p10_0p40"
    return "large_gt0p40"


def confidence_bin(value: float) -> str:
    if value >= 0.90:
        return "accepted_ge0p90"
    if value >= 0.75:
        return "review_0p75_0p90"
    return "low_lt0p75"


def main() -> int:
    args = parse_args()
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    entries = select_entries(load_entries(args.rex_json, [args.split]), args.image_dir, args.cases, args.limit)
    sidecar, sidecar_meta = load_sidecar(args.sidecar)
    similarities, embedding_mappings = load_audit_embedding_caches(args.embedding_cache)
    device = torch.device(f"cuda:{args.gpu}" if args.device == "cuda" else "cpu")
    predictor = VoxTellPredictor(str(args.model_dir), device, args.text_encoding_model)
    if args.checkpoint is not None:
        checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
        incompatible = predictor.network.load_state_dict(checkpoint["network_weights"], strict=True)
        if incompatible.missing_keys or incompatible.unexpected_keys:
            raise RuntimeError(
                f"Checkpoint mismatch: missing={incompatible.missing_keys}, "
                f"unexpected={incompatible.unexpected_keys}"
            )
        predictor.network.eval()
        print(f"Loaded audit checkpoint: {args.checkpoint}")
    rows = []
    representatives: dict[str, tuple[float, tuple]] = {}
    for entry in tqdm(entries, desc="Prompt audit", unit="case"):
        image, properties = load_image(args.image_dir / entry["name"])
        data, bbox, original_shape = predictor.preprocess(image)
        keys = sorted_finding_keys(entry)
        gt = load_reference_mask_for_window_diagnostic(
            args.mask_dir / entry["name"],
            len(keys),
            tuple(original_shape),
            bbox,
            image_properties=properties,
        )
        if gt is None:
            raise ValueError(f"Could not align GT for {entry['name']}")
        gt_np = gt.numpy().astype(bool)
        anatomy_priors = load_cropped_anatomy_priors(
            args.anatomy_prior_dir, entry["name"], original_shape, bbox
        )
        voxel_mm3 = float(np.prod(properties.get("spacing", (1.0, 1.0, 1.0))))
        variant_probs = {}
        variant_texts = {}
        for variant in args.variants:
            field = VARIANT_FIELDS[variant]
            texts = []
            for idx, fallback in zip(keys, sorted_prompts(entry)):
                stable = finding_id(entry["_split"], entry["name"], idx)
                texts.append(sidecar.get(stable, {}).get(field) or fallback)
            mapping = embedding_mappings.get(variant)
            if mapping is not None:
                embeddings = torch.stack([
                    mapping[(entry["_split"], entry["name"], int(idx))] for idx in keys
                ])[None].to(device)
            else:
                embeddings = predictor.embed_text_prompts(texts)
            logits = predictor.predict_sliding_window_return_logits(data, embeddings).cpu().float()
            variant_probs[variant] = torch.sigmoid(logits).numpy()
            variant_texts[variant] = texts

        if "original" in variant_probs and "canonical_visual" in variant_probs:
            variant_probs["average_original_canonical"] = (
                variant_probs["original"] + variant_probs["canonical_visual"]
            ) / 2.0
            variant_texts["average_original_canonical"] = [
                f"AVERAGE({a} || {b})"
                for a, b in zip(variant_texts["original"], variant_texts["canonical_visual"])
            ]

        original_prob = variant_probs["original"]
        for channel, idx in enumerate(keys):
            stable = finding_id(entry["_split"], entry["name"], idx)
            side = sidecar[stable]
            category = (entry.get("categories") or {}).get(idx, "unknown")
            base_pred = original_prob[channel] > args.threshold
            base_lung = dominant_region(base_pred, anatomy_priors, ["left", "right"])
            base_lobe = dominant_region(base_pred, anatomy_priors, list(LOBE_PRIORS))
            finding_rows = {}
            for variant in variant_probs:
                prob = variant_probs[variant][channel]
                metrics = prompt_metrics(prob, gt_np[channel], args.threshold, voxel_mm3)
                prediction = prob > args.threshold
                pred_lung = dominant_region(prediction, anatomy_priors, ["left", "right"])
                pred_lobe = dominant_region(prediction, anatomy_priors, list(LOBE_PRIORS))
                cache_variant = VARIANT_FIELDS.get(variant, "")
                attrs = side["structured_attributes"]
                expected_side = attrs.get("laterality")
                expected_lobes = set(attrs.get("lobe") or [])
                invalid_side = expected_side in {"left", "right"} and pred_lung not in {None, expected_side}
                invalid_lobe = bool(expected_lobes) and pred_lobe not in expected_lobes | {None}
                embedding_similarity = similarities.get((entry["_split"], entry["name"], int(idx), cache_variant))
                text_modification = 1.0 - SequenceMatcher(None, side["original_prompt"], variant_texts[variant][channel]).ratio()
                conversion_confidence = float(side["quality_control"]["conversion_confidence"])
                row = {
                    "finding_id": stable, "case": entry["name"], "finding_idx": int(idx),
                    "category": category, "focality": "non-focal" if str(category).startswith("1") else "focal",
                    "size_bin": size_bin(metrics["gt_voxels"]), "variant": variant,
                    "prompt": variant_texts[variant][channel],
                    "original_prompt": side["original_prompt"],
                    "text_modification_ratio": text_modification,
                    "text_modification_bin": modification_bin(text_modification),
                    "embedding_similarity_to_original": embedding_similarity,
                    "embedding_similarity_bin": similarity_bin(embedding_similarity),
                    "location_specific": bool(side["structured_attributes"].get("laterality") or side["structured_attributes"].get("lobe")),
                    "non_atomic_flag": side["quality_control"]["non_atomic_flag"],
                    "conversion_confidence": conversion_confidence,
                    "conversion_confidence_bin": confidence_bin(conversion_confidence),
                    "prediction_dice_vs_original": binary_dice(prediction, base_pred),
                    "mean_absolute_probability_difference": float(np.mean(np.abs(prob - original_prob[channel]))),
                    "probability_correlation_to_original": probability_correlation(prob, original_prob[channel]),
                    "changed_foreground_voxels": int(prediction.sum()) - int(base_pred.sum()),
                    "connected_component_change": metrics["connected_components"] - int(ndimage.label(base_pred)[1]),
                    "pred_dominant_lung": pred_lung,
                    "pred_dominant_lobe": pred_lobe,
                    "prediction_moved_to_different_lung": pred_lung != base_lung,
                    "prediction_moved_to_different_lobe": pred_lobe != base_lobe,
                    "anatomically_incorrect_movement": bool(
                        variant != "original" and (invalid_side or invalid_lobe)
                    ),
                    **metrics,
                }
                row["positive_dice"] = row["dice"] if row["gt_voxels"] > 0 else float("nan")
                rows.append(row); finding_rows[variant] = row

            probs = {name: values[channel] for name, values in variant_probs.items()}
            candidate_scores = {
                "canonical_better": finding_rows.get("canonical_visual", finding_rows["original"])["dice"] - finding_rows["original"]["dice"],
                "original_better": finding_rows["original"]["dice"] - finding_rows.get("canonical_visual", finding_rows["original"])["dice"],
                "nearly_identical": finding_rows.get("canonical_visual", finding_rows["original"])["prediction_dice_vs_original"],
                "anatomy_beats_disease_only": finding_rows.get("disease_anatomy", finding_rows["original"])["dice"] - finding_rows.get("disease_only", finding_rows["original"])["dice"],
                "largest_prompt_movement": 1.0 - finding_rows.get("canonical_visual", finding_rows["original"])["prediction_dice_vs_original"],
                "anatomically_incorrect_movement": float(
                    finding_rows.get("canonical_visual", finding_rows["original"])["anatomically_incorrect_movement"]
                ),
            }
            for label, score in candidate_scores.items():
                if label not in representatives or score > representatives[label][0]:
                    representatives[label] = (score, (data[0].numpy(), gt_np[channel], probs, f"{stable}: {side['original_prompt']}"))

    args.output_dir.mkdir(parents=True, exist_ok=True)
    per_path = args.output_dir / "per_finding_prompt_variant_metrics.csv"
    with per_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    aggregate = summarize(rows)
    aggregate_path = args.output_dir / "aggregate_prompt_variant_metrics.csv"
    with aggregate_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(aggregate[0])); writer.writeheader(); writer.writerows(aggregate)
    for label, (_, payload) in representatives.items():
        write_visualization(args.output_dir / "visualizations" / f"{label}.png", *payload)
    evaluated_variant_count = len({row["variant"] for row in rows})
    report = ["# Prompt-only Inference Audit", "", f"- Cases: {len(entries)}", f"- Findings: {len(rows) // evaluated_variant_count}", f"- Model directory: `{args.model_dir}`", f"- Checkpoint override: `{args.checkpoint}`", f"- Sidecar schema: `{sidecar_meta.get('schema_version')}`", "", "| Variant | Mean Dice | Recall | Precision | Mean FP mm3 | Empty | Gross overseg |", "|---|---:|---:|---:|---:|---:|---:|"]
    for row in (item for item in aggregate if item["stratum"] == "overall"):
        report.append(f"| {row['variant']} | {row['mean_global_dice']:.4f} | {row['mean_positive_recall']:.4f} | {row['mean_precision']:.4f} | {row['mean_fp_volume_mm3']:.1f} | {row['empty_predictions']} | {row['gross_oversegmentations']} |")
    report.extend(["", "This is a fixed-subset diagnostic. It does not establish benefit without consistent full-validation improvement.", ""])
    (args.output_dir / "report.md").write_text("\n".join(report))
    print(json.dumps(aggregate, indent=2)); print(f"Report: {args.output_dir / 'report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
