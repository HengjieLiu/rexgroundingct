#!/usr/bin/env python3
"""Analyze category-level voxel precision/recall for ReXGroundingCT predictions.

This script reports two related views:

1. category-confusion metrics: false positives/false negatives only count voxels
   assigned to another non-background ReX category. This matches the question
   "predicted as category 1 but actually belongs to another category".
2. standard segmentation metrics: false positives include background and other
   categories, and false negatives include missed category voxels.
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import pandas as pd
from tqdm import tqdm


FINE_CATEGORY_ORDER = ["1a", "1b", "1c", "1d", "1e", "1f", "2a", "2b", "2c", "2d", "2e", "2f", "2g", "2h"]
TOP_CATEGORY_ORDER = ["1", "2"]

PALETTE = {
    "blue": "#2f6f9f",
    "teal": "#2a9d8f",
    "red": "#c44e52",
    "orange": "#d9842b",
    "gray": "#6f7785",
}


def set_style() -> None:
    plt.rcParams.update(
        {
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "axes.edgecolor": "#343a40",
            "axes.labelcolor": "#20252b",
            "axes.titlecolor": "#20252b",
            "xtick.color": "#20252b",
            "ytick.color": "#20252b",
            "grid.color": "#d9dde5",
            "grid.linewidth": 0.8,
            "font.size": 10,
            "axes.titlesize": 12,
            "axes.labelsize": 10,
            "savefig.dpi": 220,
            "savefig.bbox": "tight",
        }
    )


def safe_div(num: int | float, den: int | float) -> float:
    return float(num) / float(den) if den else float("nan")


def category_to_level(category: str, level: str) -> str:
    if level == "top":
        return category[0]
    if level == "fine":
        return category
    raise ValueError(f"Unknown category level: {level}")


def volume_to_category_bits(
    volume_4d: np.ndarray,
    categories: dict[str, str],
    level: str,
    order: list[str],
) -> np.ndarray:
    """Convert (F, X, Y, Z) finding masks into category bitmasks.

    A voxel can have multiple bits set when multiple ReX findings/categories
    overlap. This keeps the analysis multi-label instead of forcing a single
    category label per voxel.
    """
    bit_for_category = {category: np.uint16(1 << idx) for idx, category in enumerate(order)}
    bits = np.zeros(volume_4d.shape[1:], dtype=np.uint16)
    for channel_str, category in categories.items():
        channel = int(channel_str)
        mapped = category_to_level(category, level)
        bit = bit_for_category[mapped]
        np.bitwise_or(bits, bit, out=bits, where=volume_4d[channel] > 0)
    return bits


def add_counts_from_bits(
    totals: dict[str, dict[str, int]],
    confusion: pd.DataFrame,
    gt_bits: np.ndarray,
    pred_bits: np.ndarray,
    categories: list[str],
) -> None:
    used_mask = np.uint16((1 << len(categories)) - 1)
    for idx, category in enumerate(categories):
        bit = np.uint16(1 << idx)
        other_mask = np.uint16(used_mask & ~bit)
        gt_cat = (gt_bits & bit) != 0
        pred_cat = (pred_bits & bit) != 0
        if not gt_cat.any() and not pred_cat.any():
            continue

        gt_other_only = ((gt_bits & other_mask) != 0) & ~gt_cat
        pred_other_only = ((pred_bits & other_mask) != 0) & ~pred_cat

        tp = int(np.count_nonzero(gt_cat & pred_cat))
        fp_other = int(np.count_nonzero(pred_cat & gt_other_only))
        fn_other = int(np.count_nonzero(gt_cat & pred_other_only))
        fp_background = int(np.count_nonzero(pred_cat & (gt_bits == 0)))
        fn_background = int(np.count_nonzero(gt_cat & (pred_bits == 0)))
        fp_standard = int(np.count_nonzero(pred_cat & ~gt_cat))
        fn_standard = int(np.count_nonzero(gt_cat & ~pred_cat))

        current = totals[category]
        current["tp"] += tp
        current["fp_other_category"] += fp_other
        current["fn_predicted_other_category"] += fn_other
        current["fp_background"] += fp_background
        current["fn_background"] += fn_background
        current["fp_standard"] += fp_standard
        current["fn_standard"] += fn_standard
        current["gt_voxels"] += int(np.count_nonzero(gt_cat))
        current["pred_voxels"] += int(np.count_nonzero(pred_cat))

    for gt_idx, gt_category in enumerate(categories):
        gt_bit = np.uint16(1 << gt_idx)
        gt_cat = (gt_bits & gt_bit) != 0
        if not gt_cat.any():
            continue
        for pred_idx, pred_category in enumerate(categories):
            pred_bit = np.uint16(1 << pred_idx)
            confusion.loc[gt_category, pred_category] += int(np.count_nonzero(gt_cat & ((pred_bits & pred_bit) != 0)))


def summarize(totals: dict[str, dict[str, int]], categories: list[str], level: str) -> pd.DataFrame:
    rows = []
    for category in categories:
        c = totals[category]
        if c["gt_voxels"] == 0 and c["pred_voxels"] == 0:
            continue
        rows.append(
            {
                "level": level,
                "category": category,
                **c,
                "precision_other_categories_only": safe_div(c["tp"], c["tp"] + c["fp_other_category"]),
                "recall_other_categories_only": safe_div(c["tp"], c["tp"] + c["fn_predicted_other_category"]),
                "precision_standard_including_background": safe_div(c["tp"], c["tp"] + c["fp_standard"]),
                "recall_standard_including_background": safe_div(c["tp"], c["tp"] + c["fn_standard"]),
                "dice_standard": safe_div(2 * c["tp"], 2 * c["tp"] + c["fp_standard"] + c["fn_standard"]),
                "background_share_of_standard_fp": safe_div(c["fp_background"], c["fp_standard"]),
                "background_share_of_standard_fn": safe_div(c["fn_background"], c["fn_standard"]),
            }
        )
    return pd.DataFrame(rows)


def plot_summary(df: pd.DataFrame, out_dir: Path, level: str) -> Path:
    if level == "top":
        order = TOP_CATEGORY_ORDER
    else:
        order = FINE_CATEGORY_ORDER
    sub = df[df["level"] == level].copy()
    sub["_order"] = sub["category"].map({c: i for i, c in enumerate(order)}).fillna(len(order)).astype(int)
    sub = sub.sort_values("_order", ascending=False)
    y = np.arange(len(sub))

    fig, axes = plt.subplots(1, 2, figsize=(12, max(3.6, 0.45 * len(sub) + 1.8)), sharey=True)
    axes[0].barh(y, sub["precision_other_categories_only"], color=PALETTE["blue"], label="precision")
    axes[0].barh(y, sub["recall_other_categories_only"], left=0, color=PALETTE["teal"], alpha=0.45, label="recall")
    axes[0].set_yticks(y, sub["category"])
    axes[0].set_xlim(0, 1.03)
    axes[0].set_xlabel("Score")
    axes[0].set_title("Category-Confusion Only\n(background ignored)")
    axes[0].legend(frameon=False, loc="lower right")
    axes[0].grid(axis="x")

    axes[1].barh(y, sub["precision_standard_including_background"], color=PALETTE["red"], label="precision")
    axes[1].barh(y, sub["recall_standard_including_background"], left=0, color=PALETTE["orange"], alpha=0.55, label="recall")
    axes[1].set_xlim(0, 1.03)
    axes[1].set_xlabel("Score")
    axes[1].set_title("Standard Segmentation\n(background included)")
    axes[1].legend(frameon=False, loc="lower right")
    axes[1].grid(axis="x")

    for ax, p_col, r_col in [
        (axes[0], "precision_other_categories_only", "recall_other_categories_only"),
        (axes[1], "precision_standard_including_background", "recall_standard_including_background"),
    ]:
        for yi, p, r in zip(y, sub[p_col], sub[r_col]):
            ax.text(min(1.01, p + 0.015), yi + 0.13, f"P {p:.2f}", va="center", fontsize=8)
            ax.text(min(1.01, r + 0.015), yi - 0.13, f"R {r:.2f}", va="center", fontsize=8)

    fig.suptitle(f"ReX Category Precision/Recall ({level})", y=1.02, fontsize=15)
    out_path = out_dir / f"category_precision_recall_{level}.png"
    fig.savefig(out_path)
    plt.close(fig)
    return out_path


def plot_confusion(confusion: pd.DataFrame, out_dir: Path, level: str) -> Path:
    # Row-normalized: of GT category voxels that were predicted as foreground,
    # which predicted categories did they overlap?
    row_sums = confusion.sum(axis=1).replace(0, np.nan)
    norm = confusion.div(row_sums, axis=0)

    fig, ax = plt.subplots(figsize=(max(5.0, 0.55 * len(confusion.columns)), max(4.0, 0.45 * len(confusion.index))))
    im = ax.imshow(norm.fillna(0).to_numpy(), cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(np.arange(len(norm.columns)), norm.columns, rotation=45, ha="right")
    ax.set_yticks(np.arange(len(norm.index)), norm.index)
    ax.set_xlabel("Predicted category")
    ax.set_ylabel("GT category")
    ax.set_title(f"Voxel Category Confusion, Row-Normalized ({level})")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    for i in range(norm.shape[0]):
        for j in range(norm.shape[1]):
            value = norm.iat[i, j]
            if np.isfinite(value) and value >= 0.05:
                ax.text(j, i, f"{value:.2f}", ha="center", va="center", fontsize=7, color="#20252b")

    out_path = out_dir / f"category_confusion_matrix_{level}.png"
    fig.savefig(out_path)
    plt.close(fig)
    return out_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-json", type=Path, default=Path("data/MICCAI_challenge_dataset.json"))
    parser.add_argument("--split", default="val")
    parser.add_argument("--limit", type=int, default=None, help="Optional number of cases for a quick smoke test.")
    parser.add_argument("--gt-dir", type=Path, default=Path("data/segmentations"))
    parser.add_argument(
        "--pred-dir",
        type=Path,
        default=Path("outputs/voxtell_rex_aug_lr1e6_step500_fullvol_val_predictions"),
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("outputs/analysis_prompt_embedding_failures_aug_step500/category_precision_recall"),
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    set_style()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    with args.dataset_json.open() as f:
        dataset = json.load(f)
    entries = dataset[args.split]
    if args.limit is not None:
        entries = entries[: args.limit]

    totals = {
        "top": defaultdict(lambda: defaultdict(int)),
        "fine": defaultdict(lambda: defaultdict(int)),
    }
    confusions = {
        "top": pd.DataFrame(0, index=TOP_CATEGORY_ORDER, columns=TOP_CATEGORY_ORDER, dtype=np.int64),
        "fine": pd.DataFrame(0, index=FINE_CATEGORY_ORDER, columns=FINE_CATEGORY_ORDER, dtype=np.int64),
    }
    missing = []
    shape_mismatches = []
    for entry in tqdm(entries, desc="Analyzing category confusion", unit="case"):
        name = entry["name"]
        gt_path = args.gt_dir / name
        pred_path = args.pred_dir / name
        if not gt_path.exists() or not pred_path.exists():
            missing.append(name)
            continue
        gt_img = nib.load(str(gt_path))
        pred_img = nib.load(str(pred_path))
        if gt_img.shape != pred_img.shape:
            shape_mismatches.append((name, gt_img.shape, pred_img.shape))
            continue
        categories = entry["categories"]
        gt = np.asanyarray(gt_img.dataobj)
        pred = np.asanyarray(pred_img.dataobj)
        for level, order in [("top", TOP_CATEGORY_ORDER), ("fine", FINE_CATEGORY_ORDER)]:
            gt_bits = volume_to_category_bits(gt, categories, level, order)
            pred_bits = volume_to_category_bits(pred, categories, level, order)
            add_counts_from_bits(totals[level], confusions[level], gt_bits, pred_bits, order)
            del gt_bits, pred_bits
        gt_img.uncache()
        pred_img.uncache()
        del gt_img, pred_img, gt, pred

    if missing:
        (args.out_dir / "missing_cases.txt").write_text("\n".join(missing) + "\n")
    if shape_mismatches:
        (args.out_dir / "shape_mismatches.json").write_text(json.dumps(shape_mismatches, indent=2))

    summary = pd.concat(
        [
            summarize(totals["top"], TOP_CATEGORY_ORDER, "top"),
            summarize(totals["fine"], FINE_CATEGORY_ORDER, "fine"),
        ],
        ignore_index=True,
    )
    summary_path = args.out_dir / "category_precision_recall_summary.csv"
    summary.to_csv(summary_path, index=False)

    written = [summary_path]
    for level in ["top", "fine"]:
        confusion_path = args.out_dir / f"category_confusion_counts_{level}.csv"
        confusions[level].to_csv(confusion_path)
        written.append(confusion_path)
        written.append(plot_summary(summary, args.out_dir, level))
        written.append(plot_confusion(confusions[level], args.out_dir, level))

    metadata = {
        "dataset_json": str(args.dataset_json),
        "split": args.split,
        "gt_dir": str(args.gt_dir),
        "pred_dir": str(args.pred_dir),
        "num_entries": len(entries),
        "num_missing": len(missing),
        "num_shape_mismatches": len(shape_mismatches),
        "definition": {
            "precision_other_categories_only": "TP / (TP + voxels predicted as category C but GT belongs only to another non-background category)",
            "recall_other_categories_only": "TP / (TP + GT category C voxels predicted only as another non-background category)",
            "precision_standard_including_background": "TP / (TP + all predicted category C voxels outside GT category C, including background)",
            "recall_standard_including_background": "TP / (TP + all GT category C voxels not predicted as category C, including missed-as-background)",
        },
    }
    metadata_path = args.out_dir / "category_precision_recall_metadata.json"
    metadata_path.write_text(json.dumps(metadata, indent=2))
    written.append(metadata_path)

    print(f"Processed {len(entries) - len(missing) - len(shape_mismatches)} case(s).")
    print(f"Missing: {len(missing)}; shape mismatches: {len(shape_mismatches)}")
    for path in written:
        print(f"Wrote: {path}")
    print(summary[["level", "category", "precision_other_categories_only", "recall_other_categories_only", "precision_standard_including_background", "recall_standard_including_background", "dice_standard"]].to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
