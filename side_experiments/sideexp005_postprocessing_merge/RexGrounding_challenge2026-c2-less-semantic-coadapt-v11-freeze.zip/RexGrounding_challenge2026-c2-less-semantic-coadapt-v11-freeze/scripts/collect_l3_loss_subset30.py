#!/usr/bin/env python3
"""Collect L3 category-aware focal Tversky fixed 30-case screening results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
STEPS = (200, 400, 600)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT / "outputs/l3_category_focal_tversky_subset30")
    parser.add_argument("--reference-root", type=Path, default=ROOT / "outputs/category_adaptive_tversky_subset30")
    parser.add_argument("--l1l2-root", type=Path, default=ROOT / "outputs/l1_l2_loss_subset30")
    parser.add_argument(
        "--mapping-csv",
        type=Path,
        default=ROOT / "outputs/category_adaptive_tversky_audit/category_mapping.csv",
    )
    parser.add_argument("--steps", nargs="+", type=int, default=list(STEPS))
    return parser.parse_args()


def load_frame(root: Path, branch: str, step: int) -> pd.DataFrame:
    path = root / branch / f"step{step}" / "per_finding_metrics.csv"
    if not path.is_file():
        raise FileNotFoundError(path)
    frame = pd.read_csv(path)
    required = {
        "file", "finding_idx", "category", "prompt", "global_dice", "global_hit",
        "voxel_precision", "voxel_recall", "fp_mm3", "fn_mm3", "pred_gt_volume_ratio",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"{path} missing columns: {missing}")
    return frame


def summarize(frame: pd.DataFrame, branch: str, step: int) -> dict:
    return {
        "branch": branch,
        "step": int(step),
        "findings": int(len(frame)),
        "cases": int(frame.file.nunique()),
        "dice_per_finding": float(frame.global_dice.mean()),
        "dice_per_case": float(frame.groupby("file").global_dice.mean().mean()),
        "hit_rate": float(frame.global_hit.mean()),
        "hits": int(frame.global_hit.sum()),
        "misses": int((~frame.global_hit.astype(bool)).sum()),
        "precision": float(frame.voxel_precision.mean()),
        "recall": float(frame.voxel_recall.mean()),
        "total_fp_mm3": float(frame.fp_mm3.sum()),
        "total_fn_mm3": float(frame.fn_mm3.sum()),
        "median_pred_gt_volume_ratio": float(frame.pred_gt_volume_ratio.median()),
    }


def pair(candidate: pd.DataFrame, reference: pd.DataFrame, step: int, group_map: dict[str, str]) -> pd.DataFrame:
    keys = ["file", "finding_idx"]
    metrics = ["global_dice", "global_hit", "voxel_precision", "voxel_recall", "fp_mm3", "fn_mm3", "pred_gt_volume_ratio"]
    paired = reference[keys + ["category", "prompt"] + metrics].merge(
        candidate[keys + metrics],
        on=keys,
        suffixes=("_adaptive", "_l3"),
        validate="one_to_one",
    )
    paired.insert(0, "step", int(step))
    paired["assigned_group"] = paired.category.astype(str).map(group_map).fillna("mixed")
    for metric in metrics:
        paired[f"delta_{metric}"] = paired[f"{metric}_l3"].astype(float) - paired[f"{metric}_adaptive"].astype(float)
    paired["dice_improved"] = paired.delta_global_dice > 0
    return paired


def summarize_pairs(paired: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (step, group), sub in paired.groupby(["step", "assigned_group"], sort=True):
        adaptive_fp = float(sub.fp_mm3_adaptive.sum())
        l3_fp = float(sub.fp_mm3_l3.sum())
        rows.append(
            {
                "step": int(step),
                "assigned_group": group,
                "n": int(len(sub)),
                "adaptive_dice": float(sub.global_dice_adaptive.mean()),
                "l3_dice": float(sub.global_dice_l3.mean()),
                "paired_mean_dice_delta": float(sub.delta_global_dice.mean()),
                "fraction_findings_improved": float(sub.dice_improved.mean()),
                "adaptive_precision": float(sub.voxel_precision_adaptive.mean()),
                "l3_precision": float(sub.voxel_precision_l3.mean()),
                "adaptive_recall": float(sub.voxel_recall_adaptive.mean()),
                "l3_recall": float(sub.voxel_recall_l3.mean()),
                "recall_delta": float(sub.delta_voxel_recall.mean()),
                "adaptive_total_fp_mm3": adaptive_fp,
                "l3_total_fp_mm3": l3_fp,
                "relative_fp_change": float((l3_fp - adaptive_fp) / max(adaptive_fp, np.finfo(float).eps)),
                "adaptive_hits": int(sub.global_hit_adaptive.sum()),
                "l3_hits": int(sub.global_hit_l3.sum()),
            }
        )
    return pd.DataFrame(rows)


def make_decision(overall: pd.DataFrame, grouped: pd.DataFrame, paired: pd.DataFrame) -> dict:
    rows = []
    for step in sorted(overall.step.unique()):
        l3 = overall[(overall.branch == "l3") & (overall.step == step)].iloc[0]
        adaptive = overall[(overall.branch == "adaptive") & (overall.step == step)].iloc[0]
        fp_group = grouped[(grouped.step == step) & (grouped.assigned_group == "fp_heavy")]
        all_pair = paired[paired.step == step]
        fp_dice_delta = float(fp_group.iloc[0].paired_mean_dice_delta) if not fp_group.empty else np.nan
        fp_change = float(fp_group.iloc[0].relative_fp_change) if not fp_group.empty else np.nan
        dice_delta = float(l3.dice_per_finding - adaptive.dice_per_finding)
        recall_delta = float(l3.recall - adaptive.recall)
        hits_delta = int(l3.hits - adaptive.hits)
        rows.append(
            {
                "step": int(step),
                "l3_dice_per_finding": float(l3.dice_per_finding),
                "adaptive_dice_per_finding": float(adaptive.dice_per_finding),
                "dice_delta_vs_adaptive": dice_delta,
                "l3_hit_rate": float(l3.hit_rate),
                "adaptive_hit_rate": float(adaptive.hit_rate),
                "hits_delta_vs_adaptive": hits_delta,
                "recall_delta_vs_adaptive": recall_delta,
                "precision_delta_vs_adaptive": float(l3.precision - adaptive.precision),
                "fp_heavy_paired_dice_delta": fp_dice_delta,
                "fp_heavy_relative_fp_change": fp_change,
                "fraction_findings_improved_vs_adaptive": float(all_pair.dice_improved.mean()),
                "not_below_adaptive": bool(dice_delta >= -1e-12),
            }
        )
    decision_frame = pd.DataFrame(rows)
    not_below_count = int(decision_frame.not_below_adaptive.sum())
    best = decision_frame.sort_values(
        ["dice_delta_vs_adaptive", "fp_heavy_paired_dice_delta", "hits_delta_vs_adaptive"],
        ascending=[False, False, False],
    ).iloc[0]
    secondary = {
        "dice_gain_at_least_0p0003": bool(best.dice_delta_vs_adaptive >= 0.0003),
        "fp_heavy_dice_improved": bool(best.fp_heavy_paired_dice_delta > 0),
        "recall_not_clearly_lower_with_similar_fp": bool(
            best.recall_delta_vs_adaptive >= -0.002
            and np.isfinite(best.fp_heavy_relative_fp_change)
            and best.fp_heavy_relative_fp_change <= 0.02
        ),
        "hit_count_increased": bool(best.hits_delta_vs_adaptive > 0),
        "not_single_case_driven": bool(best.fraction_findings_improved_vs_adaptive >= 0.45),
    }
    recommend = bool(not_below_count >= 2 and any(secondary.values()))
    return {
        "criteria": {
            "primary": "L3 not below adaptive on at least two checkpoints",
            "secondary_any_of": [
                "best Dice/finding gain >= 0.0003 vs adaptive",
                "FP-heavy paired Dice improves",
                "recall not clearly lower while FP-heavy FP remains similar/reduced",
                "hit count increases",
                "improvement not single-case driven",
            ],
        },
        "not_below_adaptive_checkpoints": not_below_count,
        "best_step": int(best.step),
        "best_step_secondary": secondary,
        "recommend_full_200_case_evaluation": recommend,
        "per_checkpoint": rows,
    }


def main() -> int:
    args = parse_args()
    args.root.mkdir(parents=True, exist_ok=True)
    mapping = pd.read_csv(args.mapping_csv)
    group_map = dict(zip(mapping.category.astype(str), mapping.assigned_group.astype(str)))

    frames: dict[tuple[str, int], pd.DataFrame] = {}
    overall_rows = []
    branch_roots = {
        "control": args.reference_root,
        "adaptive": args.reference_root,
        "l1": args.l1l2_root,
        "l2": args.l1l2_root,
        "l3": args.root,
    }
    for step in args.steps:
        for branch, root in branch_roots.items():
            frame = load_frame(root, branch, step)
            frames[(branch, step)] = frame
            overall_rows.append(summarize(frame, branch, step))

    paired = pd.concat(
        [pair(frames[("l3", step)], frames[("adaptive", step)], step, group_map) for step in args.steps],
        ignore_index=True,
    )
    overall = pd.DataFrame(overall_rows).sort_values(["step", "branch"])
    grouped = summarize_pairs(paired)
    decision = make_decision(overall, grouped, paired)

    overall.to_csv(args.root / "overall_summary.csv", index=False)
    paired.to_csv(args.root / "paired_per_finding_vs_adaptive.csv", index=False)
    grouped.to_csv(args.root / "paired_group_summary_vs_adaptive.csv", index=False)
    (args.root / "decision.json").write_text(json.dumps(decision, indent=2) + "\n")
    report = [
        "# L3 Category-Aware Focal Tversky 30-Case Screening",
        "",
        "## Overall",
        "",
        "```text",
        overall.round(6).to_string(index=False),
        "```",
        "",
        "## Decision",
        "",
        f"Recommend full-200 evaluation: **{decision['recommend_full_200_case_evaluation']}**",
        f"Best step: `{decision['best_step']}`",
        f"Not-below-adaptive checkpoints: `{decision['not_below_adaptive_checkpoints']}`",
        "",
        "```json",
        json.dumps(decision, indent=2),
        "```",
        "",
    ]
    (args.root / "report.md").write_text("\n".join(report))
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
