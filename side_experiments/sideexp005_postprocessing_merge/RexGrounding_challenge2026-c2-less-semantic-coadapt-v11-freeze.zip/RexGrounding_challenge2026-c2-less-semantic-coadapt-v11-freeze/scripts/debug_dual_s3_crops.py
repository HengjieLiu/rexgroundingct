#!/usr/bin/env python
"""Create and numerically verify representative Dual-S3 crop visualizations."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch.nn.functional as F


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dual_s3_multifov import extract_native_zoom, is_focal_category, upsample_native_zoom


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--preprocessed-dir", type=Path, default=ROOT / "data/rex_voxtell_preprocessed_v1"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=ROOT / "outputs/dual_s3_smoke/crop_debug"
    )
    parser.add_argument("--context-size", type=int, nargs=3, default=(192, 192, 192))
    parser.add_argument("--zoom-size", type=int, nargs=3, default=(96, 96, 96))
    return parser.parse_args()


def symmetric_pad_to_shape(
    image: np.ndarray, masks: np.ndarray, minimum_shape: tuple[int, int, int]
) -> tuple[np.ndarray, np.ndarray, tuple[tuple[int, int], ...]]:
    needed = np.maximum(np.asarray(minimum_shape) - np.asarray(image.shape), 0)
    before = needed // 2
    after = needed - before
    pads = tuple((int(left), int(right)) for left, right in zip(before, after))
    return (
        np.pad(image, pads, mode="constant", constant_values=0),
        np.pad(masks, ((0, 0), *pads), mode="constant", constant_values=0),
        pads,
    )


def finding_candidates(rows: list[dict]) -> dict[str, list[tuple[dict, int]]]:
    candidates = {"small_focal": [], "medium_focal": [], "diffuse_large": [], "boundary": []}
    for row in rows:
        if row.get("split") != "train" or not row.get("has_mask"):
            continue
        counts = row.get("preprocessed_mask_voxels", [])
        categories = row.get("categories", {})
        for channel, finding_id in enumerate(row.get("finding_indices", [])):
            if channel >= len(counts) or int(counts[channel]) <= 0:
                continue
            count = int(counts[channel])
            category = categories.get(str(finding_id), categories.get(str(channel)))
            if is_focal_category(category) and count < 1000:
                candidates["small_focal"].append((row, channel))
            if is_focal_category(category) and 1000 <= count < 10000:
                candidates["medium_focal"].append((row, channel))
            if not is_focal_category(category) and count >= 10000:
                candidates["diffuse_large"].append((row, channel))
            if any(int(size) < 192 for size in row["preprocessed_shape"]):
                candidates["boundary"].append((row, channel))
    return candidates


def pick_valid(
    options: list[tuple[dict, int]],
    require_edge: bool = False,
) -> tuple[dict, int, np.ndarray, np.ndarray]:
    for row, channel in options:
        with np.load(row["cache_path"], allow_pickle=False) as data:
            image = data["image"].astype(np.float32, copy=False)[0]
            masks = data["masks"].astype(np.uint8, copy=False)
        coords = np.argwhere(masks[channel] > 0)
        if not len(coords):
            continue
        bbox_min, bbox_max = coords.min(0), coords.max(0)
        near_edge = bool(np.any(bbox_min < 48) or np.any(bbox_max >= np.asarray(image.shape) - 48))
        if require_edge and not (near_edge or any(size < 192 for size in image.shape)):
            continue
        return row, channel, image, masks
    raise RuntimeError("Could not find a representative Dual-S3 crop")


def central_slice(array: np.ndarray, axis: int) -> np.ndarray:
    index = array.shape[axis] // 2
    return np.take(array, index, axis=axis)


def save_views(
    path: Path,
    context_image: np.ndarray,
    context_mask: np.ndarray,
    native_image: np.ndarray,
    native_mask: np.ndarray,
    zoom_image: np.ndarray,
    zoom_mask: np.ndarray,
) -> None:
    views = [
        ("context", context_image, context_mask),
        ("native zoom", native_image, native_mask),
        ("upsampled zoom", zoom_image, zoom_mask),
    ]
    axes_names = [(0, "axial/D"), (1, "coronal/H"), (2, "sagittal/W")]
    fig, axes = plt.subplots(3, 3, figsize=(12, 12), constrained_layout=True)
    for row_index, (name, image, mask) in enumerate(views):
        for column_index, (axis, axis_name) in enumerate(axes_names):
            image_slice = central_slice(image, axis)
            mask_slice = central_slice(mask, axis)
            ax = axes[row_index, column_index]
            ax.imshow(image_slice, cmap="gray", origin="lower")
            ax.imshow(np.ma.masked_where(mask_slice <= 0, mask_slice), cmap="autumn", alpha=0.45, origin="lower")
            ax.set_title(f"{name}: {axis_name}")
            ax.axis("off")
    fig.savefig(path, dpi=140)
    plt.close(fig)


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = [json.loads(line) for line in (args.preprocessed_dir / "manifest.jsonl").open() if line.strip()]
    candidates = finding_candidates(rows)
    selections = {
        "small_focal": pick_valid(candidates["small_focal"]),
        "medium_focal": pick_valid(candidates["medium_focal"]),
        "diffuse_large": pick_valid(candidates["diffuse_large"]),
        "boundary": pick_valid(candidates["boundary"], require_edge=True),
    }
    summary = {"all_checks_passed": True, "samples": []}
    for label, (row, channel, image, masks) in selections.items():
        padded_image, padded_masks, pads = symmetric_pad_to_shape(image, masks, tuple(args.context_size))
        coords = np.argwhere(padded_masks[channel] > 0)
        # A finding may have disconnected components, making its arithmetic
        # centroid empty.  Center on the foreground voxel nearest that centroid.
        centroid = coords.mean(axis=0)
        center = coords[np.argmin(((coords - centroid) ** 2).sum(axis=1))].astype(np.int64)
        max_start = np.asarray(padded_image.shape) - np.asarray(args.context_size)
        start = np.minimum(np.maximum(center - np.asarray(args.context_size) // 2, 0), max_start)
        context_slices = tuple(slice(int(value), int(value + size)) for value, size in zip(start, args.context_size))
        context_image = np.ascontiguousarray(padded_image[context_slices])
        context_mask = np.ascontiguousarray(padded_masks[channel][context_slices])
        native_image, native_all_masks, geometry = extract_native_zoom(
            padded_image, padded_masks[[channel]], start, args.context_size, args.zoom_size
        )
        native_mask = native_all_masks[0]
        if int(native_mask.sum()) == 0:
            raise AssertionError(f"{label}: selected finding is empty in its centered native zoom")
        zoom_image_t, zoom_mask_t = upsample_native_zoom(
            native_image, native_mask[None], args.context_size
        )
        zoom_image = zoom_image_t[0].numpy()
        zoom_mask = zoom_mask_t[0].numpy()
        local = tuple(
            slice(left, right)
            for left, right in zip(geometry.central_context_start, geometry.central_context_stop)
        )
        exact_source = bool(np.array_equal(native_image, context_image[local]))
        exact_mask_source = bool(np.array_equal(native_mask, context_mask[local]))
        roundtrip = F.interpolate(zoom_mask_t[None], size=args.zoom_size, mode="nearest")[0, 0].numpy()
        exact_roundtrip = bool(np.array_equal(roundtrip, native_mask))
        centers_match = geometry.context_center_twice == geometry.zoom_center_twice
        if not all((exact_source, exact_mask_source, exact_roundtrip, centers_match)):
            raise AssertionError(f"{label}: Dual-S3 numeric crop verification failed")
        finding_id = int(row["finding_indices"][channel])
        prompt = row["prompts"][channel]
        category = row.get("categories", {}).get(str(finding_id), row.get("categories", {}).get(str(channel)))
        sample_dir = args.output_dir / label
        sample_dir.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            sample_dir / "arrays.npz",
            context_image=context_image,
            context_gt=context_mask,
            native_zoom_image=native_image,
            native_zoom_gt=native_mask,
            upsampled_zoom_image=zoom_image,
            upsampled_zoom_gt=zoom_mask,
        )
        save_views(
            sample_dir / "views.png",
            context_image,
            context_mask,
            native_image,
            native_mask,
            zoom_image,
            zoom_mask,
        )
        metadata = {
            "label": label,
            "case": row["case"],
            "finding_id_context": finding_id,
            "finding_id_zoom": finding_id,
            "prompt_context": prompt,
            "prompt_zoom": prompt,
            "category": category,
            "original_preprocessed_shape": list(image.shape),
            "padded_shape": list(padded_image.shape),
            "padding_dhw": [list(pair) for pair in pads],
            "crop_center_twice_dhw": list(geometry.context_center_twice),
            "context_bbox_dhw": [list(geometry.context_start), list(geometry.context_stop)],
            "zoom_bbox_dhw": [list(geometry.zoom_start), list(geometry.zoom_stop)],
            "context_intensity": {
                "min": float(context_image.min()), "max": float(context_image.max()), "mean": float(context_image.mean())
            },
            "native_zoom_intensity": {
                "min": float(native_image.min()), "max": float(native_image.max()), "mean": float(native_image.mean())
            },
            "gt_voxels_context": int(context_mask.sum()),
            "gt_voxels_native_zoom": int(native_mask.sum()),
            "gt_voxels_upsampled_zoom": int(zoom_mask.sum()),
            "expected_upsampled_voxel_multiplier": 8,
            "checks": {
                "native_is_exact_context_center": exact_source,
                "native_mask_is_exact_context_center": exact_mask_source,
                "nearest_mask_roundtrip_exact": exact_roundtrip,
                "foreground_preserved": bool(native_mask.sum() > 0 and zoom_mask.sum() > 0),
                "centers_identical": centers_match,
                "prompt_identical": True,
                "finding_id_identical": True,
                "axis_order": "D,H,W (no permutation)",
                "image_interpolation": "trilinear_align_corners_false",
                "mask_interpolation": "nearest",
                "padding_convention": "symmetric_constant_zero",
            },
        }
        (sample_dir / "metadata.json").write_text(json.dumps(metadata, indent=2))
        summary["samples"].append(metadata)
        print(json.dumps(metadata))
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2))
    print(f"PASS: wrote {len(summary['samples'])} verified samples to {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
