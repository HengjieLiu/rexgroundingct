#!/usr/bin/env python3
"""Paired full381 report for the conditionally selected small2d checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def load(path: Path) -> pd.DataFrame:
    seg = pd.read_csv(path / "per_finding_metrics.csv")
    att = pd.read_csv(path / "attention_localization_per_finding.csv").rename(columns={"case_id": "file"})
    keep = [value for value in att if value not in seg or value in {"file", "finding_idx"}]
    return seg.merge(att[keep], on=["file", "finding_idx"], validate="one_to_one")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control", type=Path, required=True); parser.add_argument("--repair", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True); parser.add_argument("--update", type=int, required=True)
    args = parser.parse_args(); args.output_dir.mkdir(parents=True, exist_ok=True)
    control, repair = load(args.control), load(args.repair)
    keys = ["file", "finding_idx"]
    paired = control.merge(repair, on=keys, suffixes=("_control", "_repair"), validate="one_to_one")
    paired["dice_delta"] = paired.global_dice_repair - paired.global_dice_control
    paired["hit_delta"] = paired.global_hit_repair.astype(int) - paired.global_hit_control.astype(int)
    category, pixels = paired.category_control.astype(str), paired.pixels_control.astype(int)
    groups = {
        "overall": np.ones(len(paired), dtype=bool), "all-2d": category.eq("2d"),
        "2d-small": category.eq("2d") & pixels.between(100, 999),
        "2b": category.eq("2b"), "2c": category.eq("2c"), "2b+2c": category.isin(["2b", "2c"]),
        "tiny-non-2b2c": pixels.lt(1000) & ~category.isin(["2b", "2c"]),
        "small-non-2d": pixels.lt(1000) & ~category.eq("2d"),
        "medium": pixels.between(1000, 9999), "large": pixels.ge(10000),
    }
    rows = []
    for group, mask in groups.items():
        values = paired.loc[mask]
        rows.append({"group": group, "n": len(values), "control_dice": values.global_dice_control.mean(),
                     "repair_dice": values.global_dice_repair.mean(), "dice_delta": values.dice_delta.mean(),
                     "control_hits": int(values.global_hit_control.sum()), "repair_hits": int(values.global_hit_repair.sum()),
                     "improved": int((values.dice_delta > 1e-12).sum()), "degraded": int((values.dice_delta < -1e-12).sum()),
                     "tied": int((values.dice_delta.abs() <= 1e-12).sum()), "new_hits": int((values.hit_delta == 1).sum()),
                     "lost_hits": int((values.hit_delta == -1).sum()), "precision_delta": (values.voxel_precision_repair - values.voxel_precision_control).mean(),
                     "recall_delta": (values.voxel_recall_repair - values.voxel_recall_control).mean(),
                     "peak_in_gt_delta": (values.attention_pointing_hit_repair.astype(float) - values.attention_pointing_hit_control.astype(float)).mean(),
                     "topk_precision_delta": (values.attention_gt_sized_topk_precision_repair - values.attention_gt_sized_topk_precision_control).mean(),
                     "peak_distance_mm_delta": (values.attention_peak_distance_mm_repair - values.attention_peak_distance_mm_control).mean()})
    pd.DataFrame(rows).to_csv(args.output_dir / "full381_group_summary.csv", index=False)
    paired.to_csv(args.output_dir / "full381_paired_findings.csv", index=False)
    case_delta = paired.groupby("file").dice_delta.mean().to_numpy(); rng = np.random.default_rng(20260731)
    bootstrap = np.array([rng.choice(case_delta, len(case_delta), replace=True).mean() for _ in range(10000)])
    ci = [float(np.quantile(bootstrap, .025)), float(np.quantile(bootstrap, .975))]
    lost = pd.read_csv(ROOT / "outputs/baseline_vs_s3_9000_failure_mode_audit/category_2d_lost_hit_detailed.csv")
    known = lost[["case_id", "finding_id"]].merge(paired, left_on=["case_id", "finding_id"], right_on=keys, validate="one_to_one")
    known["restored_hit"] = known.global_hit_repair.astype(bool)
    known["restored_any_overlap"] = known.tp_voxels_repair > 0
    known["reduced_peak_distance"] = known.attention_peak_distance_mm_repair < known.attention_peak_distance_mm_control
    known["improved_coverage"] = known.voxel_recall_repair > known.voxel_recall_control
    known["fp_increase"] = known.fp_voxels_repair - known.fp_voxels_control
    known.to_csv(args.output_dir / "six_known_lost_hit_outcomes.csv", index=False)
    result = {"record_name": "small 2d attention fix", "update": args.update, "cases": 200, "findings": 381,
              "overall_control_dice": float(control.global_dice.mean()), "overall_repair_dice": float(repair.global_dice.mean()),
              "paired_dice_delta_case_bootstrap_95ci": ci, "control_hits": int(control.global_hit.sum()), "repair_hits": int(repair.global_hit.sum()),
              "known_six_restored_hits": int(known.restored_hit.sum()), "known_six_any_overlap": int(known.restored_any_overlap.sum())}
    (args.output_dir / "full381_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2)); return 0


if __name__ == "__main__": raise SystemExit(main())
