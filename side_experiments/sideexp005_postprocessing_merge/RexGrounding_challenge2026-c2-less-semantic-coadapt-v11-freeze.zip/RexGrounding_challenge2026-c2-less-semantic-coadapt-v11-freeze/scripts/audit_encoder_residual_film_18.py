#!/usr/bin/env python3
"""Shape, FP32 identity, and early-gradient audit for Residual FiLM-1/8."""

from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "VoxTell"))

from scripts.train_voxtell_rex_full_nnunet_aug import instantiate_voxtell


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=ROOT
        / "outputs/s3d_matched_continue_from_weakdiffuse_control_step1000"
        / "allcat_1over1_only_to_step6000/checkpoints/checkpoint_step_6000.pth",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "outputs/encoder_residual_film_18_screen/audits/full_model",
    )
    parser.add_argument("--trainability-updates", type=int, default=3)
    parser.add_argument("--film-lr", type=float, default=1e-5)
    parser.add_argument("--stage", type=int, choices=[2, 3, 4], default=3)
    return parser.parse_args()


def crop_case() -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    case = "train_2664_a_2.nii.gz"
    arrays = np.load(
        ROOT / "data/rex_voxtell_preprocessed_v1/cases/val/train_2664_a_2.npz"
    )
    mask = arrays["masks"][0]
    center = np.argwhere(mask > 0).mean(axis=0).round().astype(int)
    start = np.maximum(0, np.minimum(center - 96, np.asarray(mask.shape) - 192))
    slices = tuple(slice(int(value), int(value + 192)) for value in start)
    image = torch.from_numpy(arrays["image"][(slice(None), *slices)]).float()[None]
    target = torch.from_numpy(mask[slices]).float()[None, None]
    payload = torch.load(
        ROOT
        / "outputs/voxtell_rex_miccai_val/text_embedding_analysis"
        / "qwen_prompt_embeddings_train_val.pt",
        map_location="cpu",
        weights_only=False,
    )
    key = ("val", case, 0)
    index = next(
        i
        for i, record in enumerate(payload["records"])
        if (record["split"], record["case"], int(record["finding_idx"])) == key
    )
    pooled = payload["embeddings"][index].float()[None, None, None]
    return image, target, pooled


def make_model(film: bool, device: torch.device, checkpoint: dict, stage: int):
    model = instantiate_voxtell(
        ROOT / "VoxTell/voxtell_v1.1",
        device,
        deep_supervision=False,
        enable_s3_voxel_text_matching_attention=True,
        s3_attention_hidden_channels=128,
        s3_rho_mode="fixed",
        s3_rho_fixed=0.25,
        s3_logit_scale_init=10.0,
        s3_attention_scales=("1/1",),
        token_image_text_mode="original",
        encoder_residual_film_mode="text" if film else "none",
        encoder_residual_film_hidden_dim=512,
        encoder_residual_film_groups=32,
        encoder_residual_film_init_seed=260811,
        encoder_residual_film_stage=stage,
    )
    incompatible = model.load_state_dict(checkpoint["network_weights"], strict=False)
    allowed = ("s3_extra_attention_gates.",)
    if film:
        allowed += ("encoder_residual_film_block.",)
    invalid = [
        key for key in incompatible.missing_keys if not key.startswith(allowed)
    ]
    if invalid or incompatible.unexpected_keys:
        raise RuntimeError(
            f"Checkpoint mismatch missing={invalid}, "
            f"unexpected={list(incompatible.unexpected_keys)}"
        )
    s3_extra = checkpoint.get("s3_extra_attention_weights")
    if s3_extra is None:
        raise RuntimeError("Canonical checkpoint is missing separate 1/1 S3 weights")
    model.s3_extra_attention_gates.load_state_dict(s3_extra, strict=True)
    return model.to(device)


def dice(logits: torch.Tensor, target: torch.Tensor) -> float:
    prediction = torch.sigmoid(logits) >= 0.5
    truth = target > 0.5
    denominator = prediction.sum() + truth.sum()
    return 1.0 if denominator == 0 else float(2 * (prediction & truth).sum() / denominator)


def grad_norm(module: torch.nn.Module) -> float:
    values = [
        parameter.grad.detach().float().square().sum()
        for parameter in module.parameters()
        if parameter.grad is not None
    ]
    return 0.0 if not values else float(torch.stack(values).sum().sqrt().item())


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not torch.cuda.is_available():
        raise RuntimeError("The 192^3 full-model audit requires a scheduled GPU")
    device = torch.device("cuda")
    torch.manual_seed(2026)
    torch.cuda.manual_seed_all(2026)
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True, warn_only=True)
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    image, target, pooled = crop_case()
    image, target, pooled = image.to(device), target.to(device), pooled.to(device)

    logits: dict[str, torch.Tensor] = {}
    film_audit: dict[str, object] = {}
    film_parameters = 0
    for label, enabled in (("baseline", False), ("film_update0", True)):
        model = make_model(enabled, device, checkpoint, args.stage).eval().float()
        with torch.no_grad():
            output = model(image, pooled)
        logits[label] = output.detach().cpu()
        if enabled:
            film_audit = model.last_encoder_residual_film_audit
            block = model.encoder_residual_film_block
            assert block is not None
            film_parameters = block.parameter_count()
        del model
        gc.collect()
        torch.cuda.empty_cache()

    difference = (logits["film_update0"] - logits["baseline"]).abs()
    equivalence = {
        "max_absolute_logit_difference": float(difference.max().item()),
        "mean_absolute_logit_difference": float(difference.mean().item()),
        "baseline_dice": dice(logits["baseline"], target.cpu()),
        "film_dice": dice(logits["film_update0"], target.cpu()),
        "dice_difference": dice(logits["film_update0"], target.cpu())
        - dice(logits["baseline"], target.cpu()),
    }

    model = make_model(True, device, checkpoint, args.stage).train()
    for name, parameter in model.named_parameters():
        parameter.requires_grad_(name.startswith("encoder_residual_film_block."))
    block = model.encoder_residual_film_block
    assert block is not None
    optimizer = torch.optim.SGD(
        block.parameters(),
        lr=args.film_lr,
        momentum=0.99,
        nesterov=True,
        weight_decay=3e-5,
    )
    optimizer_ids = {
        id(parameter)
        for group in optimizer.param_groups
        for parameter in group["params"]
    }
    startup = []
    for update in range(1, args.trainability_updates + 1):
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            output = model(image, pooled)
            loss = F.binary_cross_entropy_with_logits(output.float(), target)
        loss.backward()
        gradients = {
            "scale_head_gradient_norm": grad_norm(block.scale_head),
            "shift_head_gradient_norm": grad_norm(block.shift_head),
            "text_projection_gradient_norm": grad_norm(block.text_projection),
        }
        finite_gradients = all(
            parameter.grad is None or bool(torch.isfinite(parameter.grad).all())
            for parameter in block.parameters()
        )
        optimizer.step()
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
            model(image, pooled)
        startup.append(
            {
                "update": update,
                "loss": float(loss.detach().item()),
                "finite_loss": bool(torch.isfinite(loss.detach()).item()),
                "finite_gradients": finite_gradients,
                **gradients,
                **block.last_audit,
            }
        )

    all_film_ids = {id(parameter) for parameter in block.parameters()}
    report = {
        "schema": "encoder_residual_film_location_screen_audit_v1",
        "conditioning_stage": args.stage,
        "checkpoint": str(args.checkpoint.resolve()),
        "gpu": torch.cuda.get_device_name(0),
        "equivalence_precision": "FP32",
        "case": "val/train_2664_a_2.nii.gz",
        "finding_idx": 0,
        "text_representation": "Qwen3-Embedding-4B last-token pooled sentence embedding",
        "text_dimension": 2560,
        "film_parameter_count": film_parameters,
        "shape_and_initialization": film_audit,
        "equivalence": equivalence,
        "startup": startup,
        "optimizer_contains_all_film_parameters": optimizer_ids == all_film_ids,
    }
    report["passed"] = bool(
        equivalence["max_absolute_logit_difference"] <= 1e-5
        and equivalence["mean_absolute_logit_difference"] <= 1e-7
        and film_audit["max_conditioned_minus_base"] == 0.0
        and film_audit["scale_max_absolute"] == 0.0
        and film_audit["shift_max_absolute"] == 0.0
        and startup[0]["scale_head_gradient_norm"] > 0
        and startup[0]["shift_head_gradient_norm"] > 0
        and any(row["text_projection_gradient_norm"] > 0 for row in startup[1:])
        and all(row["finite_loss"] and row["finite_gradients"] for row in startup)
        and report["optimizer_contains_all_film_parameters"]
    )
    output = args.output_dir / "audit.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
