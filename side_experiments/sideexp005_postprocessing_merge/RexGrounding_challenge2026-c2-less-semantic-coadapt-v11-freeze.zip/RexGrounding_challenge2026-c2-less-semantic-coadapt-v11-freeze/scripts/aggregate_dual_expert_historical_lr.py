#!/usr/bin/env python3
"""Aggregate one historical-LR dual-expert checkpoint evaluation."""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


SPECIALIST = ["1c", "1d", "1f", "2b", "2c"]


def normalize(frame: pd.DataFrame, prefix: str) -> pd.DataFrame:
    keys = ["file", "finding_idx", "category"]
    values = [column for column in ("global_dice", "global_hit", "pred_gt_volume_ratio") if column in frame]
    return frame[keys + values].rename(columns={column: f"{prefix}_{column}" for column in values})


def localization_window(path: Path, update: int) -> dict[str, dict[str, float | int | None]]:
    accum: dict[tuple[str, str], list[float]] = defaultdict(lambda: [0.0, 0.0])
    lower = max(1, update - 499)
    with path.open() as handle:
        for line in handle:
            row = json.loads(line)
            current = int(row.get("optimizer_update", -1))
            if not lower <= current <= update:
                continue
            for suffix in ("1over4", "1over2", "1over1"):
                count = int(row.get(f"s3_attention_supervised_prompts_{suffix}", 0))
                if count <= 0:
                    continue
                for metric in ("dice", "pos_mean", "hard_bg_mean", "map_mean", "peak_in_gt_fraction"):
                    key = f"s3_attention_{metric}_{suffix}"
                    if key not in row:
                        continue
                    value = float(row[key])
                    if math.isfinite(value):
                        accum[suffix, metric][0] += value * count
                        accum[suffix, metric][1] += count
    result: dict[str, dict[str, float | int | None]] = {}
    for suffix in ("1over4", "1over2", "1over1"):
        result[suffix] = {"update_lower": lower, "update_upper": update}
        for metric in ("dice", "pos_mean", "hard_bg_mean", "map_mean", "peak_in_gt_fraction"):
            total, count = accum[suffix, metric]
            result[suffix][metric] = total / count if count else None
            result[suffix][f"{metric}_prompt_count"] = int(count)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--experiment-root", type=Path, required=True)
    parser.add_argument("--update", type=int, required=True)
    args = parser.parse_args()

    control_dir = args.experiment_root / "control_to_u3000"
    attention_dir = args.experiment_root / "attention_to_u3000"
    output_dir = args.experiment_root / "comparison" / f"update_{args.update:05d}"
    output_dir.mkdir(parents=True, exist_ok=True)
    metric_rel = Path(f"full_volume_update{args.update}/summary_tables/specialist_metrics.csv")
    control = normalize(pd.read_csv(control_dir / metric_rel), "control")
    attention = normalize(pd.read_csv(attention_dir / metric_rel), "attention")
    baseline_path = args.root / "outputs/nonattention_baseline_selection/full381_update10000/summary_tables/per_finding_metrics.csv"
    baseline_frame = pd.read_csv(baseline_path)
    baseline = normalize(baseline_frame[baseline_frame["category"].astype(str).isin(SPECIALIST)], "baseline")
    paired = control.merge(attention, on=["file", "finding_idx", "category"], validate="one_to_one")
    paired = paired.merge(baseline, on=["file", "finding_idx", "category"], validate="one_to_one")
    if len(paired) != 136:
        raise RuntimeError(f"expected 136 paired findings, got {len(paired)}")
    paired["attention_minus_control_dice"] = paired["attention_global_dice"] - paired["control_global_dice"]
    paired["attention_minus_baseline_dice"] = paired["attention_global_dice"] - paired["baseline_global_dice"]
    paired.to_csv(output_dir / "paired_specialist_comparison.csv", index=False)

    groups = [("SPECIALIST_ALL", paired)] + [
        (category, paired[paired["category"].astype(str) == category]) for category in SPECIALIST
    ]
    summary_rows = []
    for category, group in groups:
        summary_rows.append({
            "category": category,
            "n": len(group),
            "control_mean_dice": float(group["control_global_dice"].mean()),
            "attention_mean_dice": float(group["attention_global_dice"].mean()),
            "baseline_mean_dice": float(group["baseline_global_dice"].mean()),
            "attention_minus_control_dice": float(group["attention_minus_control_dice"].mean()),
            "attention_minus_baseline_dice": float(group["attention_minus_baseline_dice"].mean()),
            "control_hits": int(group["control_global_hit"].sum()),
            "attention_hits": int(group["attention_global_hit"].sum()),
            "baseline_hits": int(group["baseline_global_hit"].sum()),
        })
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(output_dir / "category_specialist_summary.csv", index=False)

    rng = np.random.default_rng(731945 + args.update)
    cases = paired["file"].unique()
    by_case = {case: paired[paired["file"] == case] for case in cases}
    draws = np.empty(10_000)
    for index in range(len(draws)):
        sample = rng.choice(cases, size=len(cases), replace=True)
        frame = pd.concat([by_case[case] for case in sample], ignore_index=True)
        draws[index] = frame["attention_minus_control_dice"].mean()

    overall = summary.iloc[0]
    localization = localization_window(attention_dir / "history.jsonl", args.update)
    trace_match = (
        (control_dir / "sampler_trace_rank0.jsonl").read_bytes()
        == (attention_dir / "sampler_trace_rank0.jsonl").read_bytes()
    )
    result = {
        "update": args.update,
        "learning_rates": {"encoder": 1e-5, "decoder": 1e-4, "attention": 1e-4},
        "specialist_findings": 136,
        "control_mean_dice": float(overall["control_mean_dice"]),
        "attention_mean_dice": float(overall["attention_mean_dice"]),
        "baseline_mean_dice": float(overall["baseline_mean_dice"]),
        "attention_minus_control_dice": float(overall["attention_minus_control_dice"]),
        "attention_minus_baseline_dice": float(overall["attention_minus_baseline_dice"]),
        "attention_minus_control_ci95": [float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))],
        "attention_minus_control_probability_gt_zero": float((draws > 0).mean()),
        "sampler_traces_identical": trace_match,
        "attention_localization_last_500_updates": localization,
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
