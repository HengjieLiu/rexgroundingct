"""Compare cached Qwen and PubMedBERT representation scales before training."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch


def stats(x: torch.Tensor) -> dict[str, float | list[int]]:
    x = x.float()
    return {
        "shape": list(x.shape),
        "mean": float(x.mean()),
        "std": float(x.std(unbiased=False)),
        "mean_abs": float(x.abs().mean()),
        "rms": float(x.square().mean().sqrt()),
        "mean_row_l2": float(x.norm(dim=-1).mean()),
        "min_row_l2": float(x.norm(dim=-1).min()),
        "max_row_l2": float(x.norm(dim=-1).max()),
        "finite_fraction": float(torch.isfinite(x).float().mean()),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--qwen-cache", type=Path, required=True)
    parser.add_argument("--pubmedbert-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    qwen = torch.load(args.qwen_cache, map_location="cpu", weights_only=False)
    pubmed = torch.load(args.pubmedbert_cache, map_location="cpu", weights_only=False)
    report: dict[str, object] = {
        "qwen_embeddings": stats(qwen["embeddings"]),
        "pubmedbert_cls_embeddings": stats(pubmed["cls_embeddings"]),
        "pubmedbert_mean_embeddings": stats(pubmed["mean_embeddings"]),
        "pubmedbert_token_features": {},
        "adapter": {},
    }

    token_rows = [x.float() for x in pubmed["token_features"]]
    token_flat = torch.cat(token_rows, dim=0)
    report["pubmedbert_token_features"] = stats(token_flat)

    # Match the model's new pooled adapter initialization and record its output
    # scale on the complete cache.  This is an audit only; no weights are saved.
    torch.manual_seed(20260819)
    adapter = torch.nn.Linear(768, 2560)
    torch.nn.init.xavier_uniform_(adapter.weight)
    torch.nn.init.zeros_(adapter.bias)
    with torch.no_grad():
        report["adapter"] = {
            "type": "Linear(768,2560)",
            "weight_init": "xavier_uniform",
            "bias_init": "zeros",
            "cls_output": stats(adapter(pubmed["cls_embeddings"].float())),
            "mean_output": stats(adapter(pubmed["mean_embeddings"].float())),
        }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
