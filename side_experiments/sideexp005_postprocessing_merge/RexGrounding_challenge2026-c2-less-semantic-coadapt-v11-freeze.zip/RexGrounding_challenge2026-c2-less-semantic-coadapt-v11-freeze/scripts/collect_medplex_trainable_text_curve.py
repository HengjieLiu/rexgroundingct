#!/usr/bin/env python3
"""Collect fixed30, smoothed training-loss, LR, FP, and volume trajectories."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SHARED = ROOT / "outputs/medplex_trainable_text_study"
RUNS = {
    "P0": ROOT / "outputs/pbt_trainable_control_from4800",
    "M1": ROOT / "outputs/pbt_medplex_from4800",
    "B0": ROOT / "outputs/bclip_trainable_control_from4000",
    "M2": ROOT / "outputs/bclip_medplex_from4000",
}


def load_optimizer_history(path: Path) -> list[dict]:
    """Stream the JSONL log and retain only optimizer-step records.

    These runs write many microstep diagnostics; loading the complete raw file at
    once is needlessly memory-intensive for a simple trajectory report.
    """
    awk = r'''
index($0, "\"optimizer_step_performed\": true") && match($0, /"optimizer_update": [0-9]+/) {
    update = substr($0, RSTART + 20, RLENGTH - 20)
    if (match($0, /"train_loss": [-+0-9.eE]+/)) {
        loss = substr($0, RSTART + 14, RLENGTH - 14)
        print update "\t" loss
    }
}
'''
    result = subprocess.run(
        ["awk", awk, str(path)], text=True, capture_output=True, check=True
    )
    return [
        {"optimizer_step_performed": True, "optimizer_update": int(update), "train_loss": float(loss)}
        for update, loss in (line.split("\t") for line in result.stdout.splitlines())
    ]


def train_at_update(history: list[dict], update: int) -> dict:
    candidates = [row for row in history if int(row.get("optimizer_update", -1)) == update]
    if not candidates:
        return {}
    row = candidates[-1]
    return {
        "training_loss": row.get("train_loss"),
        **{f"lr_{key}": value for key, value in row.get("lr", {}).items()},
    }


def mean_training_loss_before_update(
    history: list[dict], update: int, window: int = 200
) -> float | None:
    """Average one optimizer-step loss per update in the preceding fixed30 window."""
    lower = max(1, update - window + 1)
    values = [
        float(row["train_loss"])
        for row in history
        if row.get("optimizer_step_performed")
        and lower <= int(row.get("optimizer_update", -1)) <= update
        and row.get("train_loss") is not None
    ]
    return float(sum(values) / len(values)) if values else None


def fixed30_paths(run: Path) -> dict[int, Path]:
    """Discover completed validation points; this study intentionally starts at 1000."""
    paths: dict[int, Path] = {}
    for path in run.glob("fixed30/update_*/full_volume/update_*/controlled_summary.json"):
        payload = json.loads(path.read_text())
        paths[int(payload["update"])] = path
    return paths


def markdown_table(frame: pd.DataFrame) -> str:
    """Render a small markdown table without adding a reporting dependency."""
    columns = list(frame.columns)
    rendered = frame.copy()
    for column in columns:
        if pd.api.types.is_float_dtype(rendered[column]):
            rendered[column] = rendered[column].map(lambda value: f"{value:.6f}")
    rows = ["| " + " | ".join(columns) + " |"]
    rows.append("| " + " | ".join("---" for _ in columns) + " |")
    rows.extend(
        "| " + " | ".join(str(value) for value in row) + " |"
        for row in rendered.itertuples(index=False, name=None)
    )
    return "\n".join(rows)


def main() -> int:
    rows = []
    per_finding = []
    for arm, run in RUNS.items():
        history = load_optimizer_history(run / "history.jsonl")
        for update, controlled_path in sorted(fixed30_paths(run).items()):
            base = controlled_path.parent
            summary = json.loads((base / "eval_rexrank_metrics_global.json").read_text())["summary"]
            findings = pd.read_csv(base / "summary_tables/per_finding_metrics.csv")
            pred_voxels = pd.to_numeric(findings["pred_voxels"], errors="coerce")
            false_positive_voxels = pd.to_numeric(findings.get("fp_voxels"), errors="coerce")
            rows.append({
                "arm": arm,
                "update": update,
                "dice": float(summary["mean_global_dice_per_finding"]),
                "hit": int(summary["total_hits"]),
                "findings": int(summary["total_findings"]),
                "fp_voxels_total": float(false_positive_voxels.sum()),
                "prediction_voxels_total": float(pred_voxels.sum()),
                "prediction_voxels_mean": float(pred_voxels.mean()),
                "training_loss_mean_prior_200_updates": mean_training_loss_before_update(history, update),
                **train_at_update(history, update),
            })
            findings.insert(0, "update", update)
            findings.insert(0, "arm", arm)
            per_finding.append(findings)
    curve = pd.DataFrame(rows)
    curve.to_csv(SHARED / "training_curve_comparison.csv", index=False)
    pd.concat(per_finding, ignore_index=True).to_csv(
        SHARED / "per_finding_fixed30.csv", index=False
    )
    summary_rows = []
    for arm, values in curve.groupby("arm", sort=True):
        best = values.loc[values["dice"].idxmax()]
        final = values.loc[values["update"].idxmax()]
        first = values.loc[values["update"].idxmin()]
        summary_rows.append({
            "arm": arm,
            "first_update": int(first["update"]),
            "first_loss_prior_200": first["training_loss_mean_prior_200_updates"],
            "final_update": int(final["update"]),
            "final_loss_prior_200": final["training_loss_mean_prior_200_updates"],
            "loss_change_first_to_final": (
                final["training_loss_mean_prior_200_updates"]
                - first["training_loss_mean_prior_200_updates"]
            ),
            "best_update": int(best["update"]),
            "best_dice": best["dice"],
            "best_hit": int(best["hit"]),
            "final_dice": final["dice"],
            "final_hit": int(final["hit"]),
        })
    summary_frame = pd.DataFrame(summary_rows)
    summary_frame.to_csv(SHARED / "training_curve_summary.csv", index=False)
    report = [
        "# Trainable text-encoder / MedPlex fixed30 trajectory", "",
        "All values use the matched fixed30 cohort (30 cases / 49 findings). "
        "`training_loss_mean_prior_200_updates` averages one logged loss for each "
        "optimizer update in the 200-update window ending at the validation point.",
        "", "## Peak and final checkpoints", "",
        markdown_table(summary_frame), "",
        "## Complete trajectory", "",
        "See `training_curve_comparison.csv` for every 200-update validation point "
        "from update 1000 through 5000, including Dice, HIT, FP, prediction volume, "
        "smoothed loss, and instantaneous logged loss.",
    ]
    (SHARED / "training_curve_report.md").write_text("\n".join(report) + "\n")
    print(curve.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
