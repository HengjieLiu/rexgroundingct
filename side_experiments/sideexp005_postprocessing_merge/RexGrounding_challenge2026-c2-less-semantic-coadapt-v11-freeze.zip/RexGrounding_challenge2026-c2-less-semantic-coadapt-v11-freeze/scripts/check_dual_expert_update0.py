#!/usr/bin/env python3
"""Verify update-0 identity for the matched dual-expert experiment."""

from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
for directory in (ROOT / "VoxTell", ROOT / "scripts"):
    sys.path.insert(0, str(directory))

import train_voxtell_rex_full_nnunet_aug as train_lib  # noqa: E402
from prepare_dual_expert_feasibility import ROUTING, SPECIALIST, make_sampler  # noqa: E402


def build(base: dict, checkpoint: dict, device: torch.device, attention: bool):
    torch.manual_seed(2026)
    model = train_lib.instantiate_voxtell(
        Path(base["model_dir"]),
        device,
        deep_supervision=True,
        enable_s3_voxel_text_matching_attention=attention,
        s3_attention_hidden_channels=128,
        s3_rho_mode="fixed",
        s3_rho_fixed=0.25,
        s3_logit_scale_init=10.0,
        s3_attention_scales=["1/4", "1/2", "1/1"] if attention else ["1/2"],
    )
    incompatible = model.load_state_dict(checkpoint["network_weights"], strict=not attention)
    invalid = [
        key
        for key in incompatible.missing_keys
        if not key.startswith(("s3_attention_gate.", "s3_extra_attention_gates."))
    ]
    if invalid or incompatible.unexpected_keys:
        raise RuntimeError(f"checkpoint mismatch: missing={invalid}, unexpected={incompatible.unexpected_keys}")
    model.eval()
    return model


@torch.inference_mode()
def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--parent-args", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=28671)
    args = parser.parse_args()
    base = json.loads(args.parent_args.read_text())
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    sampler, _ = make_sampler(base, args.seed)
    batches = {}
    for _ in range(1000):
        image, embeddings, _, _, meta = sampler.sample()
        category = str(meta.get("anchor_category") or "")
        if category in SPECIALIST and category not in batches:
            batches[category] = (image, embeddings, meta)
        if len(batches) == len(SPECIALIST):
            break
    if set(batches) != set(SPECIALIST):
        raise RuntimeError(f"representative category coverage missing {sorted(set(SPECIALIST)-set(batches))}")

    device = torch.device("cuda")
    original = build(base, checkpoint, device, False)
    expected = {}
    for category, (image, embeddings, _) in batches.items():
        with torch.autocast("cuda", dtype=torch.bfloat16):
            expected[category] = original(image[None].to(device), embeddings[None].to(device))[0].float().cpu()
    del original
    gc.collect(); torch.cuda.empty_cache()

    control = build(base, checkpoint, device, False)
    control_logits = {}
    control_max = 0.0
    for category, (image, embeddings, _) in batches.items():
        with torch.autocast("cuda", dtype=torch.bfloat16):
            value = control(image[None].to(device), embeddings[None].to(device))[0].float().cpu()
        control_logits[category] = value
        control_max = max(control_max, float((value - expected[category]).abs().max()))
    del control
    gc.collect(); torch.cuda.empty_cache()

    attention = build(base, checkpoint, device, True)
    expert_max = 0.0
    probability_sum = 0.0
    probability_count = 0
    binary_difference = 0
    per_category = {}
    for category, (image, embeddings, meta) in batches.items():
        categories = [str(value) for value in meta["categories_after_shuffle"]]
        scale_values = {
            scale: torch.zeros((1, len(categories)), device=device)
            for scale in ROUTING
        }
        with torch.autocast("cuda", dtype=torch.bfloat16):
            actual = attention(
                image[None].to(device),
                embeddings[None].to(device),
                s3_attention_gate_scale=torch.zeros((1, len(categories)), device=device),
                s3_attention_gate_scales_by_scale=scale_values,
            )[0].float().cpu()
        delta = actual - control_logits[category]
        expert_max = max(expert_max, float(delta.abs().max()))
        probability_delta = (actual.sigmoid() - control_logits[category].sigmoid()).abs()
        probability_sum += float(probability_delta.sum())
        probability_count += probability_delta.numel()
        binary = int(((actual > 0) != (control_logits[category] > 0)).sum())
        binary_difference += binary
        maps = {}
        for scale, values in attention.last_s3_attention_maps.items():
            flattened = torch.cat([value.detach().float().flatten() for value in values])
            maps[scale] = {
                "mean": float(flattened.mean()),
                "std": float(flattened.std()),
                "min": float(flattened.min()),
                "max": float(flattened.max()),
            }
        per_category[category] = {
            "case_id": meta["case"],
            "prompt_categories": categories,
            "intended_active_scales": [scale for scale, mapping in ROUTING.items() if mapping.get(category, 0) > 0],
            "max_abs_logit_difference": float(delta.abs().max()),
            "binary_voxel_difference": binary,
            "attention_maps": maps,
        }

    tolerance = 1e-5
    report = {
        "checkpoint": str(args.checkpoint.resolve()),
        "representative_categories": list(SPECIALIST),
        "control_vs_original_max_abs_logit_difference": control_max,
        "attention_vs_control_max_abs_logit_difference": expert_max,
        "attention_vs_control_mean_abs_probability_difference": probability_sum / max(1, probability_count),
        "attention_vs_control_binary_voxel_difference_threshold_0_5": binary_difference,
        "neutral_initialization": "all per-scale runtime gate multipliers are exactly zero at update 0",
        "activation": "linear gate ramp reaches fixed rho=0.25 at optimizer update 20",
        "per_category": per_category,
        "numerical_tolerance": tolerance,
        "status": "passed" if control_max <= tolerance and expert_max <= tolerance and binary_difference == 0 else "failed",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if report["status"] != "passed":
        raise RuntimeError("update-0 identity check failed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
