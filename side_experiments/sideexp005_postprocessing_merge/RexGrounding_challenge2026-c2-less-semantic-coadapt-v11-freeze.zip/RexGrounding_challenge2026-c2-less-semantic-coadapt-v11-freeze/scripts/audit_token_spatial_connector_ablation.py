#!/usr/bin/env python3
"""Calibrate and startup-audit direct/diagonal token-spatial connectors."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'VoxTell')]
from scripts.audit_encoder_token_spatial_18 import load_case, make_model, norm

def args():
 p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--target-ratio',type=float,default=3e-4);p.add_argument('--updates',type=int,default=10);return p.parse_args()
def grad(module,name):
 p=getattr(module,name,None)
 return 0. if p is None or p.grad is None else float(p.grad.detach().float().norm())
def main():
 a=args();a.output_dir.mkdir(parents=True,exist_ok=True)
 if not torch.cuda.is_available():raise RuntimeError('CUDA required')
 d=torch.device('cuda'); torch.manual_seed(2026);torch.cuda.manual_seed_all(2026)
 ckpt=torch.load(ROOT/'outputs/s3d_matched_continue_from_weakdiffuse_control_step1000/allcat_1over1_only_to_step6000/checkpoints/checkpoint_step_6000.pth',map_location='cpu',weights_only=False)
 image,target,pooled,tokens,valid=[x.to(d) for x in load_case(ROOT/'outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt')]
 base=make_model(False,d,ckpt).eval().float()
 with torch.no_grad():base_logits=base(image,pooled)
 base_path=ROOT/'outputs/s3d_matched_continue_from_weakdiffuse_control_step1000/allcat_1over1_only_to_step6000/checkpoints/checkpoint_step_6000.pth'
 report={'checkpoint':str(base_path.resolve()),'target_ratio':a.target_ratio,'variants':{}}
 for kind in ('direct','diagonal'):
  # Linear calibration: one provisional nonzero pass, then instantiate from clean checkpoint with matched scale.
  probe=make_model(True,d,ckpt,kind,1.0).eval().float()
  with torch.no_grad():probe(image,pooled,token_features=tokens,token_valid_mask=valid);unit=float(probe.last_encoder_token_spatial_audit['residual_to_feature_norm'])
  scale=a.target_ratio/unit
  del probe;torch.cuda.empty_cache()
  model=make_model(True,d,ckpt,kind,scale).eval().float();block=model.encoder_token_spatial_block;assert block
  with torch.no_grad():
   out=model(image,pooled,token_features=tokens,token_valid_mask=valid);audit=dict(model.last_encoder_token_spatial_audit)
  diff=(out-base_logits).abs(); pred0=(torch.sigmoid(base_logits)>=.5);pred=(torch.sigmoid(out)>=.5)
  safe={'calibrated_init_scale':scale,'unit_residual_ratio':unit,'initial_residual_ratio':audit['residual_to_feature_norm'],'max_absolute_logit_difference':float(diff.max()),'mean_absolute_logit_difference':float(diff.mean()),'predicted_voxel_difference':int(pred.sum()-pred0.sum()),'prediction_disagreement_voxels':int((pred!=pred0).sum()),'audit':audit}
  model.train(); opt=torch.optim.SGD(block.parameters(),lr=1e-3,momentum=.99,nesterov=True,weight_decay=3e-5); history=[]
  for update in range(1,a.updates+1):
   opt.zero_grad(set_to_none=True)
   with torch.autocast('cuda',dtype=torch.bfloat16):
    logits=model(image,pooled,token_features=tokens,token_valid_mask=valid);loss=F.binary_cross_entropy_with_logits(logits.float(),target)
   loss.backward(); finite=all(p.grad is None or bool(torch.isfinite(p.grad).all()) for p in block.parameters())
   entry={'update':update,'loss':float(loss.detach()),'finite':finite,'q_grad':norm(block.q_proj),'k_grad':norm(block.k_proj),'v_grad':norm(block.v_proj),'alpha_grad':grad(block,'alpha'),'gain_grad':grad(block,'channel_gain')}
   opt.step()
   with torch.no_grad():model(image,pooled,token_features=tokens,token_valid_mask=valid)
   entry.update({'residual_ratio':block.last_audit['residual_to_feature_norm'],'alpha':float(block.alpha.detach()) if block.alpha is not None else None,'gain_mean_abs':float(block.channel_gain.detach().abs().mean()) if block.channel_gain is not None else None,'gain_min':float(block.channel_gain.detach().min()) if block.channel_gain is not None else None,'gain_max':float(block.channel_gain.detach().max()) if block.channel_gain is not None else None})
   history.append(entry)
  report['variants'][kind]={'safety':safe,'startup':history,'passed':bool(1e-4<=safe['initial_residual_ratio']<=1e-3 and all(x['finite'] and x['q_grad']>0 and x['k_grad']>0 and x['v_grad']>0 for x in history))}
  del model;torch.cuda.empty_cache()
 (a.output_dir/'connector_ablation_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
 if not all(x['passed'] for x in report['variants'].values()):raise SystemExit(1)
if __name__=='__main__':main()
