#!/usr/bin/env python3
"""Collect a sharded, paired prompt-ablation subset audit."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--subset-manifest", type=Path, required=True)
    parser.add_argument("--expected-shards", type=int, default=4)
    return parser.parse_args()


def mean(values):
    return float(np.nanmean(np.asarray(list(values), dtype=np.float64)))


def main() -> int:
    args = parse_args()
    subset = json.loads(args.subset_manifest.read_text())
    expected_cases = set(subset["cases"])
    rows = []
    for shard_id in range(args.expected_shards):
        path = args.input_dir / f"shard_{shard_id:02d}" / "per_finding_threshold_metrics.csv"
        with path.open() as handle:
            rows.extend(csv.DictReader(handle))
    present_cases = {row["case"] for row in rows}
    if present_cases != expected_cases:
        raise RuntimeError(f"Case coverage mismatch: got {len(present_cases)}, expected {len(expected_cases)}")
    for row in rows:
        for field in ("threshold", "dice", "positive_recall", "precision", "fp_volume_mm3", "pred_voxels", "gt_voxels", "pred_gt_volume_ratio", "voxel_average_precision", "voxel_auroc"):
            row[field] = float(row[field])
        row["global_hit"] = row["global_hit"].lower() == "true"

    combined = args.input_dir / "per_finding_threshold_metrics.csv"
    with combined.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

    variants = sorted({row["variant"] for row in rows})
    thresholds = sorted({row["threshold"] for row in rows})
    summary = []
    for threshold in thresholds:
        for variant in variants:
            selected = [row for row in rows if row["threshold"] == threshold and row["variant"] == variant]
            by_case = defaultdict(list)
            for row in selected:
                by_case[row["case"]].append(row["dice"])
            summary.append({
                "variant": variant, "threshold": threshold, "findings": len(selected), "cases": len(by_case),
                "mean_global_dice_per_finding": mean(row["dice"] for row in selected),
                "mean_global_dice_per_case": mean(np.mean(values) for values in by_case.values()),
                "hit_rate": mean(row["global_hit"] for row in selected),
                "mean_precision": mean(row["precision"] for row in selected),
                "mean_recall": mean(row["positive_recall"] for row in selected),
                "mean_fp_volume_mm3": mean(row["fp_volume_mm3"] for row in selected),
                "mean_pred_gt_volume_ratio": mean(row["pred_gt_volume_ratio"] for row in selected),
                "mean_voxel_average_precision": mean(row["voxel_average_precision"] for row in selected),
                "mean_voxel_auroc": mean(row["voxel_auroc"] for row in selected),
            })
    with (args.input_dir / "threshold_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary[0]))
        writer.writeheader(); writer.writerows(summary)

    paired = []
    for threshold in thresholds:
        lookup = {(row["case"], int(row["finding_idx"]), row["variant"]): row for row in rows if row["threshold"] == threshold}
        keys = sorted({(row["case"], int(row["finding_idx"])) for row in rows if row["threshold"] == threshold})
        for variant in variants:
            if variant == "original":
                continue
            delta = np.asarray([lookup[(*key, variant)]["dice"] - lookup[(*key, "original")]["dice"] for key in keys])
            paired.append({
                "variant": variant, "threshold": threshold, "findings": len(keys),
                "mean_dice_delta_vs_original": float(delta.mean()),
                "improved_findings": int((delta > 1e-8).sum()),
                "tied_findings": int((np.abs(delta) <= 1e-8).sum()),
                "worse_findings": int((delta < -1e-8).sum()),
            })
    with (args.input_dir / "paired_deltas_vs_original.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(paired[0]))
        writer.writeheader(); writer.writerows(paired)

    report = ["# Stratified Prompt-Ablation Subset", "", f"Cases: {len(expected_cases)}", f"Findings: {len({(row['case'], row['finding_idx']) for row in rows})}", "", "| Variant | Threshold | Dice/finding | Dice/case | Hit rate | Precision | Recall |", "|---|---:|---:|---:|---:|---:|---:|"]
    for row in summary:
        report.append(f"| {row['variant']} | {row['threshold']:.2f} | {row['mean_global_dice_per_finding']:.6f} | {row['mean_global_dice_per_case']:.6f} | {row['hit_rate']:.6f} | {row['mean_precision']:.6f} | {row['mean_recall']:.6f} |")
    report.extend(["", "Paired deltas versus original: `paired_deltas_vs_original.csv`.", ""])
    (args.input_dir / "report.md").write_text("\n".join(report))
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
