#!/usr/bin/env python3
"""Collect Presence V2 inference-only gating diagnostics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


REX_ROOT = Path(__file__).resolve().parents[1]


SETTINGS = [
    "no_gate",
    "multiply_gate_gamma1",
    "multiply_gate_gamma0p5",
    "hard_gate_tau0p1",
    "hard_gate_tau0p2",
    "hard_gate_tau0p3",
]


def load_summary(run_dir: Path) -> dict | None:
    path = run_dir / "summary.json"
    if not path.exists():
        return None
    with path.open() as f:
        return json.load(f)


def load_category(run_dir: Path) -> pd.DataFrame:
    path = run_dir / "per_category_metrics.csv"
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)


def add_size_and_focus(per_finding: pd.DataFrame) -> pd.DataFrame:
    out = per_finding.copy()
    pixels = out.get("pixels", pd.Series([np.nan] * len(out))).fillna(0).astype(float)
    out["gt_volume_bin"] = pd.cut(
        pixels,
        bins=[-1, 99, 999, 9999, np.inf],
        labels=["tiny_lt100", "small_100_999", "medium_1k_9999", "large_ge10k"],
    )
    category = out.get("category", pd.Series(["unknown"] * len(out))).astype(str)
    out["focus_group"] = np.where(category.str.startswith("2"), "focal", "non_focal_or_diffuse")
    return out


def group_summary(per_finding: pd.DataFrame, group_col: str) -> pd.DataFrame:
    if group_col not in per_finding or per_finding.empty:
        return pd.DataFrame()
    return (
        per_finding.groupby(group_col, dropna=False)
        .agg(
            n=("global_dice", "size"),
            mean_dice=("global_dice", "mean"),
            hit_rate=("global_hit", "mean"),
            hits=("global_hit", "sum"),
        )
        .reset_index()
        .assign(misses=lambda x: x["n"] - x["hits"])
    )


def auroc_score(y_true: np.ndarray, score: np.ndarray) -> float:
    y_true = y_true.astype(bool)
    n_pos = int(y_true.sum())
    n_neg = int((~y_true).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(score) + 1)
    _, inv, counts = np.unique(score, return_inverse=True, return_counts=True)
    for group in np.flatnonzero(counts > 1):
        idx = np.flatnonzero(inv == group)
        ranks[idx] = ranks[idx].mean()
    rank_sum_pos = ranks[y_true].sum()
    return float((rank_sum_pos - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg))


def auprc_score(y_true: np.ndarray, score: np.ndarray) -> float:
    y_true = y_true.astype(bool)
    n_pos = int(y_true.sum())
    if n_pos == 0:
        return float("nan")
    order = np.argsort(-score, kind="mergesort")
    y = y_true[order]
    tp = np.cumsum(y)
    fp = np.cumsum(~y)
    recall = tp / n_pos
    precision = tp / np.maximum(tp + fp, 1)
    recall = np.r_[0.0, recall]
    precision = np.r_[1.0, precision]
    return float(np.trapezoid(precision, recall))


def collect_window_metrics(out_dir: Path, step_label: str) -> pd.DataFrame:
    files = sorted((out_dir / "window_presence").glob(f"window_presence_scores_{step_label}_shard_*.csv"))
    if not files:
        return pd.DataFrame()
    df = pd.concat((pd.read_csv(p) for p in files), ignore_index=True)
    merged_path = out_dir / "window_presence" / f"window_presence_scores_{step_label}.csv"
    df.to_csv(merged_path, index=False)
    rows = []
    group_specs = [("all", None)]
    if "category" in df:
        group_specs.extend((f"category_{cat}", sub.index) for cat, sub in df.groupby("category", dropna=False))
        group_specs.append(("focus_2c", df.index[df["category"].astype(str) == "2c"]))
        group_specs.append(("focus_2d", df.index[df["category"].astype(str) == "2d"]))
    for label, idx in group_specs:
        sub = df if idx is None else df.loc[idx]
        if sub.empty:
            continue
        y = sub["window_has_gt"].astype(str).str.lower().isin(["true", "1"])
        s = sub["presence_prob"].astype(float)
        pos = sub.loc[y]
        neg = sub.loc[~y]
        rows.append(
            {
                "group": label,
                "n": len(sub),
                "positive_windows": int(y.sum()),
                "negative_windows": int((~y).sum()),
                "auroc": auroc_score(y.to_numpy(), s.to_numpy()),
                "auprc": auprc_score(y.to_numpy(), s.to_numpy()),
                "positive_presence_mean": float(pos["presence_prob"].mean()) if len(pos) else np.nan,
                "positive_presence_median": float(pos["presence_prob"].median()) if len(pos) else np.nan,
                "negative_presence_mean": float(neg["presence_prob"].mean()) if len(neg) else np.nan,
                "negative_presence_median": float(neg["presence_prob"].median()) if len(neg) else np.nan,
            }
        )
    metrics = pd.DataFrame(rows)
    metrics.to_csv(out_dir / "window_presence" / f"window_presence_metrics_by_category_{step_label}.csv", index=False)
    return metrics


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--step-label", required=True)
    parser.add_argument(
        "--anchor-dir",
        type=Path,
        default=REX_ROOT / "outputs/voxtell_rex_anchor85_step3800_bestval_fullvol_val_predictions",
    )
    parser.add_argument("--old-additive-dir", type=Path, default=None)
    args = parser.parse_args()

    rows = []
    anchor = load_summary(args.anchor_dir)
    for setting in SETTINGS:
        run_dir = args.out_dir / setting
        summary = load_summary(run_dir)
        if summary is None:
            continue
        row = {
            "setting": setting,
            "mean_global_dice_per_finding": float(summary["mean_global_dice_per_finding"]),
            "mean_global_dice_per_case": float(summary["mean_global_dice_per_case"]),
            "hit_rate": float(summary["hit_rate"]),
            "hits": int(summary["total_hits"]),
            "misses": int(summary["total_misses"]),
        }
        if anchor is not None:
            row["delta_dice_vs_anchor85"] = row["mean_global_dice_per_finding"] - float(anchor["mean_global_dice_per_finding"])
            row["delta_hit_rate_vs_anchor85"] = row["hit_rate"] - float(anchor["hit_rate"])
        cat = load_category(run_dir)
        for category in ["2c", "2d"]:
            c = cat.loc[cat["category"].astype(str) == category]
            if not c.empty:
                row[f"{category}_dice"] = float(c.iloc[0]["mean_dice"])
                row[f"{category}_hit_rate"] = float(c.iloc[0]["hit_rate"])
        rows.append(row)

        pf_path = run_dir / "per_finding_metrics.csv"
        if pf_path.exists():
            pf = add_size_and_focus(pd.read_csv(pf_path))
            group_summary(pf, "focus_group").to_csv(run_dir / "focus_group_metrics.csv", index=False)
            group_summary(pf, "gt_volume_bin").to_csv(run_dir / "gt_volume_bin_metrics.csv", index=False)

    summary_df = pd.DataFrame(rows)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    summary_df.to_csv(args.out_dir / "category_gating_summary.csv", index=False)
    window_metrics = collect_window_metrics(args.out_dir, args.step_label)

    lines = [f"Presence V2 category gating report: {args.step_label}", ""]
    if not summary_df.empty:
        best = summary_df.sort_values("mean_global_dice_per_finding", ascending=False).iloc[0]
        lines.append(
            f"Best setting: {best['setting']} "
            f"Dice/finding={best['mean_global_dice_per_finding']:.6f}, "
            f"hit_rate={best['hit_rate']:.6f}."
        )
        if anchor is not None:
            lines.append(
                f"Anchor85 baseline Dice/finding={float(anchor['mean_global_dice_per_finding']):.6f}, "
                f"hit_rate={float(anchor['hit_rate']):.6f}."
            )
        if "2d_dice" in best:
            lines.append(f"Best-setting 2d Dice={best.get('2d_dice', np.nan):.6f}.")
        if "2c_dice" in best:
            lines.append(f"Best-setting 2c Dice={best.get('2c_dice', np.nan):.6f}.")
    if args.old_additive_dir is not None and (args.old_additive_dir / "summary.json").exists():
        old = load_summary(args.old_additive_dir)
        lines.append("")
        lines.append(
            "Old additive reference: "
            f"Dice/finding={float(old['mean_global_dice_per_finding']):.6f}, "
            f"hit_rate={float(old['hit_rate']):.6f}."
        )
    if not window_metrics.empty:
        all_row = window_metrics.loc[window_metrics["group"] == "all"].iloc[0]
        lines.append("")
        lines.append(
            "Window presence diagnostic: "
            f"AUROC={all_row['auroc']:.4f}, AUPRC={all_row['auprc']:.4f}, "
            f"positive_mean={all_row['positive_presence_mean']:.4f}, "
            f"negative_mean={all_row['negative_presence_mean']:.4f}."
        )
    (args.out_dir / "report.txt").write_text("\n".join(lines) + "\n")
    print(summary_df.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
