#!/usr/bin/env python3
"""Aggregate predicted/random/empty/full-mask retrieval at a trained checkpoint."""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "VoxTell", ROOT / "scripts"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import train_voxtell_mask_prompt_cycle as cycle_train  # noqa: E402
import train_voxtell_rex_full_nnunet_aug as rex_train  # noqa: E402
from voxtell.model.mask_prompt_cycle import MaskPromptCycle, same_case_cycle_loss  # noqa: E402


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batches", type=int, default=30)
    parser.add_argument("--seed", type=int, default=20260723)
    parser.add_argument("--temperature", type=float, default=0.07)
    parser.add_argument("--device", default="cuda:0")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    torch.cuda.set_device(device)

    preprocessed = ROOT / "data/rex_voxtell_preprocessed_v1"
    rows = rex_train.load_manifest(preprocessed)
    train_cases = rex_train.build_case_records(rows, "train", None)
    val_cases = rex_train.build_case_records(rows, "val", 200)
    embeddings = rex_train.load_embedding_map(
        ROOT
        / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/"
        "qwen_prompt_embeddings_train_val.pt"
    )
    # Construct both samplers in the same order as training before fixing validation.
    _train_sampler = cycle_train.make_sampler(preprocessed, train_cases, embeddings)
    val_sampler = cycle_train.make_sampler(preprocessed, val_cases, embeddings)
    batches = [val_sampler.sample() for _ in range(args.batches)]

    model = rex_train.instantiate_voxtell(ROOT / "VoxTell/voxtell_v1.1", device, True)
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    model.load_state_dict(checkpoint["network_weights"], strict=True)
    wrapper = MaskPromptCycle(model).to(device)
    wrapper.reconstruction_head.load_state_dict(
        checkpoint["mask_prompt_cycle_weights"], strict=True
    )
    wrapper.eval()

    names = ("predicted", "random_spatial", "empty", "full")
    rows_by_name = {name: [] for name in names}
    with torch.inference_mode():
        for batch in batches:
            image, text, target, _, meta = cycle_train.to_device(batch, device)
            output = wrapper(image, text, target, update=400, force_alpha=0.0)
            feature = wrapper.image_feature()
            probability = output.primary_logits.sigmoid()
            random_mask = probability.flatten(start_dim=2)[
                :, :, torch.randperm(probability[0, 0].numel(), device=device)
            ].reshape_as(probability)
            masks = {
                "predicted": probability,
                "random_spatial": random_mask,
                "empty": torch.zeros_like(probability),
                "full": torch.ones_like(probability),
            }
            prompts, cases = cycle_train.nested_meta(meta)
            for name, mask in masks.items():
                reconstructed, roi = wrapper.reconstruct_from_mask(feature, mask)
                loss, stats = same_case_cycle_loss(
                    reconstructed.float(),
                    output.target_embeddings,
                    target,
                    prompts,
                    cases,
                    temperature=args.temperature,
                )
                rows_by_name[name].append(
                    {
                        "loss": float(loss.item()),
                        "roi_norm": float(roi.float().norm(dim=-1).mean().item()),
                        **stats,
                    }
                )

    result = {
        "checkpoint": str(args.checkpoint),
        "batches": args.batches,
        "temperature": args.temperature,
        "masks": {},
    }
    for name, rows_for_mask in rows_by_name.items():
        result["masks"][name] = {
            key: float(np.nanmean([float(row[key]) for row in rows_for_mask]))
            for key in rows_for_mask[0]
        }
    predicted = result["masks"]["predicted"]
    random_result = result["masks"]["random_spatial"]
    result["anti_shortcut"] = {
        "random_loss_minus_predicted": random_result["loss"] - predicted["loss"],
        "predicted_top1_minus_random": predicted["cycle_top1"]
        - random_result["cycle_top1"],
        "predicted_margin_minus_random": predicted["cycle_margin"]
        - random_result["cycle_margin"],
        "random_mask_worsens_loss": random_result["loss"] > predicted["loss"],
        "random_mask_worsens_top1": random_result["cycle_top1"]
        < predicted["cycle_top1"],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

