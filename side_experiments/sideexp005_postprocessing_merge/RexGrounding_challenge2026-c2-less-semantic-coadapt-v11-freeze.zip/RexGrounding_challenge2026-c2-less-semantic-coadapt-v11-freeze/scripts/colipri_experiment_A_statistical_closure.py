#!/usr/bin/env python3
"""Leakage-safe statistical closure for CoLiPri Experiment A."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import postzoom_routing_pipeline as p0  # noqa: E402

DEFAULT_SOURCE = ROOT / "outputs/colipri_experiment_A_router_retry1_20260805"
DEFAULT_OUTPUT = ROOT / "outputs/colipri_experiment_A_statistical_closure_20260806"
SEED = 20260806
P0_DIR = ROOT / "outputs/dual_s3_postzoom_routing"
MATCHED_DIR = ROOT / "outputs/colipri_voxtell_matched_alignment_20260804"
CORRECT_FEATURES = [
    "colipri_native_correct",
    "colipri_zoom_rank1_correct",
    "colipri_zoom_rank2_correct",
    "colipri_zoom_rank3_correct",
    "colipri_zoom_correct_max",
    "colipri_zoom_correct_mean",
    "colipri_zoom_minus_native",
    "colipri_zoom_correct_gap12",
    "colipri_native_prompt_margin",
    "colipri_best_zoom_prompt_margin",
    "zoom_roi_count",
]


def control_features(features: pd.DataFrame) -> pd.DataFrame:
    result = features[["finding_key"]].copy()
    mapping = {
        "colipri_native_correct": "colipri_native_shuffled",
        "colipri_zoom_rank1_correct": "colipri_zoom_rank1_shuffled",
        "colipri_zoom_rank2_correct": "colipri_zoom_rank2_shuffled",
        "colipri_zoom_rank3_correct": "colipri_zoom_rank3_shuffled",
        "colipri_zoom_correct_max": "colipri_zoom_shuffled_max",
        "colipri_zoom_correct_mean": "colipri_zoom_shuffled_mean",
        "colipri_zoom_minus_native": "colipri_zoom_shuffled_minus_native",
        "colipri_zoom_correct_gap12": "colipri_zoom_shuffled_gap12",
        "colipri_native_prompt_margin": "colipri_native_prompt_margin",
        "colipri_best_zoom_prompt_margin": "colipri_best_zoom_prompt_margin",
        "zoom_roi_count": "zoom_roi_count",
    }
    for target, source in mapping.items():
        sign = -1.0 if target in {
            "colipri_native_prompt_margin", "colipri_best_zoom_prompt_margin"
        } else 1.0
        result[target] = sign * features[source]
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap-reps", type=int, default=10_000)
    parser.add_argument("--null-reps", type=int, default=50)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def write_json(value: object, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def canonical(frame: pd.DataFrame) -> pd.DataFrame:
    return frame.sort_values(["file", "finding_idx"]).reset_index(drop=True)


def load_variants(source: Path) -> dict[str, pd.DataFrame]:
    paths = {
        "A0": source / "oof/A0_existing_p0.csv",
        "A1": source / "oof/A1_colipri_only.csv",
        "A2": source / "oof/A2_p0_plus_correct_colipri.csv",
        "A3": source / "oof/A3_p0_plus_shuffled_colipri.csv",
    }
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing canonical OOF files: " + ", ".join(missing))
    variants = {name: canonical(pd.read_csv(path)) for name, path in paths.items()}
    reference = variants["A0"]
    if len(reference) != 381 or reference.finding_key.nunique() != 381:
        raise RuntimeError(f"Expected 381 unique findings, got {len(reference)} rows")
    reference_ids = reference[["file", "finding_idx", "finding_key"]]
    for name, frame in variants.items():
        if not reference_ids.equals(frame[["file", "finding_idx", "finding_key"]]):
            raise RuntimeError(f"{name} row IDs/order differ from A0")
        if not np.allclose(frame.pixels, reference.pixels, rtol=0, atol=0):
            raise RuntimeError(f"{name} GT volume differs from A0")
        for column in ("baseline_dice", "top3_dice", "baseline_hit", "top3_hit"):
            if not np.allclose(frame[column], reference[column], rtol=0, atol=1e-12):
                raise RuntimeError(f"{name} differs in shared source column {column}")
    return variants


def finding_weighted_case_bootstrap(
    left: pd.DataFrame,
    right: pd.DataFrame,
    reps: int,
    seed: int,
) -> dict[str, float | int]:
    merged = left[["file", "finding_key", "dice"]].merge(
        right[["finding_key", "dice"]],
        on="finding_key",
        suffixes=("_left", "_right"),
        validate="one_to_one",
    )
    merged["delta"] = merged.dice_left - merged.dice_right
    grouped = [block.delta.to_numpy(np.float64) for _, block in merged.groupby("file", sort=True)]
    case_sums = np.asarray([values.sum() for values in grouped], dtype=np.float64)
    case_counts = np.asarray([len(values) for values in grouped], dtype=np.int64)
    rng = np.random.default_rng(seed)
    draws = np.empty(reps, dtype=np.float64)
    chunk = 1000
    for start in range(0, reps, chunk):
        count = min(chunk, reps - start)
        sampled = rng.integers(0, len(grouped), size=(count, len(grouped)))
        draws[start : start + count] = case_sums[sampled].sum(axis=1) / case_counts[sampled].sum(axis=1)
    estimate = float(merged.delta.mean())
    return {
        "estimate": estimate,
        "ci95_low": float(np.quantile(draws, 0.025)),
        "ci95_high": float(np.quantile(draws, 0.975)),
        "p_delta_gt_0": float((draws > 0).mean()),
        "cases": len(grouped),
        "findings": len(merged),
        "replicates": reps,
        "bootstrap_mean": float(draws.mean()),
    }


def approximate_fp(frame: pd.DataFrame) -> pd.Series:
    gt = frame.pixels.astype(float)
    pred = frame.predicted_voxels.astype(float)
    tp = frame.dice.astype(float) * (pred + gt) / 2.0
    return (pred - tp).clip(lower=0)


def paired_summary(left: pd.DataFrame, right: pd.DataFrame, label: str) -> dict[str, float | int | str]:
    left = left.set_index("finding_key")
    right = right.set_index("finding_key").loc[left.index]
    left_hit, right_hit = left.hit.astype(bool), right.hit.astype(bool)
    return {
        "comparison": label,
        "dice_delta": float((left.dice - right.dice).mean()),
        "hit_delta": int(left_hit.sum() - right_hit.sum()),
        "new_hits": int((left_hit & ~right_hit).sum()),
        "lost_hits": int((~left_hit & right_hit).sum()),
        "mean_predicted_voxel_delta": float((left.predicted_voxels - right.predicted_voxels).mean()),
        "mean_derived_fp_voxel_delta": float((approximate_fp(left) - approximate_fp(right)).mean()),
        "route_fraction_left": float(left.router_selected.mean()),
        "route_fraction_right": float(right.router_selected.mean()),
    }


def variant_summary(variants: dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = []
    for name, frame in variants.items():
        rows.append(
            {
                "setting": name,
                "findings": len(frame),
                "cases": frame.file.nunique(),
                "mean_dice": frame.dice.mean(),
                "hits": int(frame.hit.sum()),
                "hit_rate": frame.hit.mean(),
                "mean_predicted_voxels": frame.predicted_voxels.mean(),
                "mean_derived_fp_voxels": approximate_fp(frame).mean(),
                "fraction_routed_to_zoom": frame.router_selected.mean(),
            }
        )
    return pd.DataFrame(rows)


def randomized_feature_frame(
    base: pd.DataFrame,
    features: pd.DataFrame,
    seed: int,
) -> tuple[pd.DataFrame, dict[str, int]]:
    """Build a cached paired-feature null, without claiming new prompt rescoring."""
    rng = np.random.default_rng(seed)
    choose_correct = rng.integers(0, 2, len(features)).astype(bool)
    correct = features[["finding_key", *CORRECT_FEATURES]].copy()
    shuffled = control_features(features)
    randomized = correct.copy()
    for column in CORRECT_FEATURES:
        randomized[column] = np.where(choose_correct, correct[column], shuffled[column])
    return base.merge(randomized, on="finding_key", validate="one_to_one"), {
        "correct_rows": int(choose_correct.sum()),
        "shuffled_rows": int((~choose_correct).sum()),
    }


def run_cached_null(
    base: pd.DataFrame,
    features: pd.DataFrame,
    folds: pd.DataFrame,
    a0: pd.DataFrame,
    reps: int,
    output: Path,
) -> pd.DataFrame:
    rows = []
    for index in range(reps):
        seed = SEED + 1000 + index
        null_input, counts = randomized_feature_frame(base, features, seed)
        result = p0.nested_finding_router(null_input, folds)
        row = {
            "realization": index,
            "seed": seed,
            "mean_dice": float(result.dice.mean()),
            "delta_vs_A0": float(result.dice.mean() - a0.dice.mean()),
            "hits": int(result.hit.sum()),
            "hit_delta_vs_A0": int(result.hit.sum() - a0.hit.sum()),
            **counts,
        }
        rows.append(row)
        print(f"[A null] {index + 1}/{reps} delta={row['delta_vs_A0']:+.6f}", flush=True)
    frame = pd.DataFrame(rows)
    write_csv(frame, output / "cached_feature_randomization_null.csv")
    return frame


def subgroup_stability(variants: dict[str, pd.DataFrame]) -> pd.DataFrame:
    a0, a2 = variants["A0"], variants["A2"]
    merged = a2[["finding_key", "file", "outer_fold", "category", "focality", "size_bin", "dice", "hit"]].merge(
        a0[["finding_key", "dice", "hit"]], on="finding_key", suffixes=("_A2", "_A0"), validate="one_to_one"
    )
    case_counts = merged.groupby("file").finding_key.transform("size")
    masks: dict[str, pd.Series] = {
        "single_finding": case_counts.eq(1),
        "multi_finding": case_counts.gt(1),
    }
    matched_manifest = MATCHED_DIR / "matched_roi_manifest.csv"
    if matched_manifest.exists():
        metadata = pd.read_csv(matched_manifest)
        entity_counts = metadata.groupby(["case_id", "entity"]).size()
        repeated = metadata.assign(
            finding_key=metadata.case_id + "|" + metadata.finding_idx.astype(int).astype(str),
            repeated=[entity_counts.loc[(row.case_id, row.entity)] > 1 for row in metadata.itertuples()],
        )
        keys = set(repeated.loc[repeated.repeated, "finding_key"])
        masks["same_case_same_entity"] = merged.finding_key.isin(keys)
    for value in sorted(merged.focality.dropna().unique()):
        masks[f"focality_{value}"] = merged.focality.eq(value)
    for value in sorted(merged.size_bin.dropna().unique()):
        masks[f"size_{value}"] = merged.size_bin.eq(value)
    rows = []
    for name, mask in masks.items():
        block = merged.loc[mask]
        if len(block):
            rows.append({
                "analysis": "subgroup",
                "held_out": name,
                "findings": len(block),
                "cases": block.file.nunique(),
                "A2_minus_A0": float((block.dice_A2 - block.dice_A0).mean()),
                "hit_delta": int(block.hit_A2.sum() - block.hit_A0.sum()),
            })
    for fold in sorted(merged.outer_fold.unique()):
        block = merged.loc[merged.outer_fold.ne(fold)]
        rows.append({
            "analysis": "leave_one_fold_out",
            "held_out": str(fold),
            "findings": len(block),
            "cases": block.file.nunique(),
            "A2_minus_A0": float((block.dice_A2 - block.dice_A0).mean()),
            "hit_delta": int(block.hit_A2.sum() - block.hit_A0.sum()),
        })
    for category in sorted(merged.category.dropna().astype(str).unique()):
        block = merged.loc[merged.category.astype(str).ne(category)]
        rows.append({
            "analysis": "leave_one_category_out",
            "held_out": category,
            "findings": len(block),
            "cases": block.file.nunique(),
            "A2_minus_A0": float((block.dice_A2 - block.dice_A0).mean()),
            "hit_delta": int(block.hit_A2.sum() - block.hit_A0.sum()),
        })
    return pd.DataFrame(rows)


def leave_one_case_influence(variants: dict[str, pd.DataFrame]) -> pd.DataFrame:
    a0 = variants["A0"].set_index("finding_key")
    a2 = variants["A2"].set_index("finding_key")
    delta = (a2.dice - a0.dice).rename("delta").to_frame()
    delta["file"] = a2.file
    total_sum, total_count = delta.delta.sum(), len(delta)
    rows = []
    for case, block in delta.groupby("file", sort=True):
        loo = (total_sum - block.delta.sum()) / (total_count - len(block))
        rows.append({"held_out_case": case, "findings_in_case": len(block), "A2_minus_A0_without_case": loo})
    return pd.DataFrame(rows).sort_values("A2_minus_A0_without_case")


def markdown_table(frame: pd.DataFrame) -> str:
    if frame.empty:
        return "_No rows._"
    clean = frame.copy()
    for column in clean.columns:
        clean[column] = clean[column].map(
            lambda value: f"{value:.6f}" if isinstance(value, (float, np.floating)) else str(value)
        )
    header = "| " + " | ".join(map(str, clean.columns)) + " |"
    divider = "| " + " | ".join(["---"] * len(clean.columns)) + " |"
    rows = ["| " + " | ".join(map(str, row)) + " |" for row in clean.to_numpy()]
    return "\n".join([header, divider, *rows])


def main() -> int:
    args = parse_args()
    source, output = args.source_dir.resolve(), args.output_dir.resolve()
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite {output}")
    output.mkdir(parents=True)
    variants = load_variants(source)
    source_files = sorted((source / "oof").glob("A*.csv"))
    provenance = {
        "source_dir": str(source),
        "source_files": {str(path): sha256(path) for path in source_files},
        "canonical_findings": 381,
        "canonical_cases": int(variants["A0"].file.nunique()),
        "bootstrap_unit": "case cluster; sampled cases contribute all findings; finding-weighted statistic",
        "null_type": "paired cached correct-vs-single-shuffled feature randomization; no new neural rescoring",
        "null_limitation": (
            "The cache has only one shuffled prompt score per image/zoom and no pooled embeddings. "
            "These are not 50 independently rescored shuffled prompts."
        ),
    }
    write_json(provenance, output / "input_audit.json")
    summary = variant_summary(variants)
    write_csv(summary, output / "canonical_variant_summary.csv")
    paired = pd.DataFrame([
        paired_summary(variants["A2"], variants["A0"], "A2_minus_A0"),
        paired_summary(variants["A2"], variants["A3"], "A2_minus_A3"),
        paired_summary(variants["A1"], variants["A0"], "A1_minus_A0"),
    ])
    write_csv(paired, output / "paired_effects.csv")
    boot = {
        "A2_minus_A0": finding_weighted_case_bootstrap(variants["A2"], variants["A0"], args.bootstrap_reps, SEED),
        "A2_minus_A3": finding_weighted_case_bootstrap(variants["A2"], variants["A3"], args.bootstrap_reps, SEED + 1),
        "A1_minus_A0": finding_weighted_case_bootstrap(variants["A1"], variants["A0"], args.bootstrap_reps, SEED + 2),
    }
    write_json(boot, output / "case_cluster_bootstrap.json")

    features = pd.read_csv(source / "colipri_router_features.csv")
    base = pd.read_csv(P0_DIR / "feature_tables/finding_features.csv")
    folds = pd.read_csv(P0_DIR / "fold_assignments.csv")
    if set(features.finding_key) != set(base.finding_key) or len(features) != 381:
        raise RuntimeError("CoLiPri feature cache does not match canonical 381 findings")
    null = run_cached_null(base, features, folds, variants["A0"], args.null_reps, output)
    correct_delta = boot["A2_minus_A0"]["estimate"]
    null_summary = {
        "realizations": len(null),
        "mean": float(null.delta_vs_A0.mean()),
        "std": float(null.delta_vs_A0.std(ddof=1)),
        "p2p5": float(null.delta_vs_A0.quantile(0.025)),
        "p50": float(null.delta_vs_A0.quantile(0.5)),
        "p97p5": float(null.delta_vs_A0.quantile(0.975)),
        "fraction_exceeding_correct_A2": float((null.delta_vs_A0 >= correct_delta).mean()),
        "empirical_p_one_sided": float((1 + (null.delta_vs_A0 >= correct_delta).sum()) / (1 + len(null))),
        "correct_A2_delta": correct_delta,
        "interpretation_limit": provenance["null_limitation"],
    }
    write_json(null_summary, output / "cached_feature_randomization_null_summary.json")
    stability = subgroup_stability(variants)
    influence = leave_one_case_influence(variants)
    write_csv(stability, output / "stability_summary.csv")
    write_csv(influence, output / "leave_one_case_out_influence.csv")

    multi = stability.query("analysis == 'subgroup' and held_out == 'multi_finding'")
    same = stability.query("analysis == 'subgroup' and held_out == 'same_case_same_entity'")
    no_major_subgroup_harm = all(
        block.empty or float(block.iloc[0].A2_minus_A0) >= -0.002 for block in (multi, same)
    )
    a2_hits = int(variants["A2"].hit.sum())
    a0_hits = int(variants["A0"].hit.sum())
    statistically_supported = boot["A2_minus_A0"]["ci95_low"] > 0
    beats_cached_null = null_summary["empirical_p_one_sided"] <= 0.05
    literal_shuffled_requirement_met = False
    go = statistically_supported and beats_cached_null and a2_hits >= a0_hits and no_major_subgroup_harm and literal_shuffled_requirement_met
    clear_no_go = boot["A2_minus_A0"]["ci95_high"] <= 0
    verdict = "GO" if go else ("NO-GO" if clear_no_go else "INCONCLUSIVE")
    result = {
        "verdict": verdict,
        "literal_50_independent_prompt_shuffles_available": literal_shuffled_requirement_met,
        "A2_minus_A0": boot["A2_minus_A0"],
        "A2_minus_A3": boot["A2_minus_A3"],
        "A1_minus_A0": boot["A1_minus_A0"],
        "null": null_summary,
    }
    write_json(result, output / "result.json")

    report = f"""# CoLiPri Experiment A Statistical Closure

**Verdict: {verdict}.**

## Input integrity

- All four variants contain the same 381 unique findings from {variants['A0'].file.nunique()} cases in identical order.
- Native/zoom source metrics, fold assignments, and thresholds were audited from canonical per-finding OOF files.
- Input hashes and source paths are recorded in `input_audit.json`.

## Exact finding-weighted results

{markdown_table(summary)}

{markdown_table(paired)}

The corrected A2-A0 subtraction is {boot['A2_minus_A0']['estimate']:+.6f}; the corrected A2-A3 subtraction is {boot['A2_minus_A3']['estimate']:+.6f}. The old report discrepancy came from using an equal-case mean as the bootstrap point estimate while displaying finding-weighted variant means.

## Case-cluster bootstrap

```json
{json.dumps(boot, indent=2)}
```

Cases were resampled as clusters and carried all their findings. Each replicate then used the finding-weighted mean, so the point estimate exactly matches direct per-finding subtraction.

## Cached-feature shuffled null

```json
{json.dumps(null_summary, indent=2)}
```

This is a 50-seed paired cached-feature randomization null with a complete fold-wise router refit for every seed. It is not represented as 50 independently encoded shuffled prompts: the exact P0 cache contains one shuffled score per image/zoom and no pooled embeddings. New prompt scoring would require neural inference and would violate the requested CPU-only/no-inference closure. Consequently, this closure cannot satisfy the literal shuffled-null GO gate and remains conservative.

## Stability

See `stability_summary.csv` for leave-one-fold-out, leave-one-category-out, single/multi-finding, same-entity, size, and focality analyses. See `leave_one_case_out_influence.csv` for case influence.
"""
    (ROOT / "reports/colipri_experiment_A_statistical_closure.md").write_text(report)
    print(json.dumps(result, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
