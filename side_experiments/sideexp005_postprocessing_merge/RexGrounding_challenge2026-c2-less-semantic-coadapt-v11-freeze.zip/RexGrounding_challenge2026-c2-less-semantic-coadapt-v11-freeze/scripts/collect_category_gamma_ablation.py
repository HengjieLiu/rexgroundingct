#!/usr/bin/env python3
"""Collect category-gamma spatial-attention ablation results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


REX_ROOT = Path(__file__).resolve().parents[1]


def load_summary(run_dir: Path) -> dict:
    with (run_dir / "summary.json").open() as f:
        return json.load(f)


def load_category(run_dir: Path) -> pd.DataFrame:
    return pd.read_csv(run_dir / "per_category_metrics.csv")


def category_dice(run_dir: Path, category: str) -> float:
    df = load_category(run_dir)
    row = df.loc[df["category"].astype(str) == category]
    return float(row.iloc[0]["mean_dice"]) if not row.empty else float("nan")


def row_for(label: str, run_dir: Path, anchor_dir: Path, s1_dir: Path) -> dict:
    summary = load_summary(run_dir)
    anchor = load_summary(anchor_dir)
    s1 = load_summary(s1_dir)
    out = {
        "model_config_name": label,
        "Dice/finding": float(summary["mean_global_dice_per_finding"]),
        "Dice/case": float(summary["mean_global_dice_per_case"]),
        "hit_rate": float(summary["hit_rate"]),
        "hits": int(summary["total_hits"]),
        "misses": int(summary["total_misses"]),
    }
    out["Delta_Dice_finding_vs_Anchor85"] = out["Dice/finding"] - float(anchor["mean_global_dice_per_finding"])
    out["Delta_Dice_finding_vs_S1_gamma1"] = out["Dice/finding"] - float(s1["mean_global_dice_per_finding"])
    out["Delta_hit_rate_vs_Anchor85"] = out["hit_rate"] - float(anchor["hit_rate"])
    for cat in ["1e", "2b", "2c", "2d", "2e"]:
        dice = category_dice(run_dir, cat)
        anchor_dice = category_dice(anchor_dir, cat)
        s1_dice = category_dice(s1_dir, cat)
        out[f"{cat}_Dice"] = dice
        out[f"{cat}_Delta_Dice_vs_Anchor85"] = dice - anchor_dice
        if cat == "2d":
            out["2d_Delta_Dice_vs_S1_gamma1"] = dice - s1_dice
    return out


def maybe_add(rows: list[dict], label: str, run_dir: Path, anchor_dir: Path, s1_dir: Path) -> None:
    if (run_dir / "summary.json").exists() and (run_dir / "per_category_metrics.csv").exists():
        rows.append(row_for(label, run_dir, anchor_dir, s1_dir))


def write_report(
    df: pd.DataFrame,
    path: Path,
    *,
    step_label: str,
    previous_summary_csv: Path | None = None,
) -> None:
    lines = ["# Spatial Attention Category Gamma Ablation", ""]
    if df.empty:
        lines.append("No completed runs found.")
        path.write_text("\n".join(lines) + "\n")
        return
    best_dice = df.sort_values("Dice/finding", ascending=False).iloc[0]
    best_trade = df.assign(
        trade_score=df["Dice/finding"] + 0.05 * df["hit_rate"]
    ).sort_values("trade_score", ascending=False).iloc[0]
    lines += [
        "## Overall",
        "",
        f"- Step label: `{step_label}`.",
        f"- Best Dice/finding: `{best_dice['model_config_name']}` = {best_dice['Dice/finding']:.5f}.",
        f"- Best simple Dice+hit tradeoff: `{best_trade['model_config_name']}`.",
        "",
        "## Interpretation Checks",
        "",
    ]
    def get(name: str):
        sub = df.loc[df["model_config_name"] == name]
        return None if sub.empty else sub.iloc[0]
    focal = get(f"S1_{step_label}_focaloff")
    focal2c = get(f"S1_{step_label}_focaloff_2c_on")
    only2d = get(f"S1_{step_label}_only_2d_off")
    if focal is not None and focal2c is not None:
        lines.append(
            f"- 2c ON vs focal-off: overall Dice delta "
            f"{focal2c['Dice/finding'] - focal['Dice/finding']:+.5f}; "
            f"2c Dice delta {focal2c['2c_Dice'] - focal['2c_Dice']:+.5f}."
        )
    if only2d is not None:
        lines.append(
            f"- only_2d_off: Dice/finding {only2d['Dice/finding']:.5f}, "
            f"hit rate {only2d['hit_rate']:.5f}, "
            f"2d delta vs Anchor85 {only2d['2d_Delta_Dice_vs_Anchor85']:+.5f}, "
            f"2d delta vs S1 gamma1 {only2d['2d_Delta_Dice_vs_S1_gamma1']:+.5f}."
        )
        lines.append(
            f"- 1e/2b gains under only_2d_off: "
            f"1e {only2d['1e_Delta_Dice_vs_Anchor85']:+.5f}, "
            f"2b {only2d['2b_Delta_Dice_vs_Anchor85']:+.5f}."
        )
    if previous_summary_csv is not None and previous_summary_csv.exists():
        prev = pd.read_csv(previous_summary_csv)
        prev_best = prev.sort_values("Dice/finding", ascending=False).iloc[0]
        cur_best = best_dice
        lines += [
            "",
            "## Step600 Comparison",
            "",
            f"- Previous best: `{prev_best['model_config_name']}` = {prev_best['Dice/finding']:.5f}.",
            f"- Current best: `{cur_best['model_config_name']}` = {cur_best['Dice/finding']:.5f}.",
            f"- Current minus previous best Dice/finding: {cur_best['Dice/finding'] - prev_best['Dice/finding']:+.5f}.",
        ]
    lines += [
        "",
        "## Recommendation",
        "",
        "Use the highest Dice/finding row as the current inference-only rule, "
        "but prefer simpler category rules if performance is effectively tied. "
        "For training, use category-aware attention/dropout: keep attention ON for "
        "regional opacity/pleural categories and OFF or weak for 2d nodules.",
        "",
    ]
    path.write_text("\n".join(lines) + "\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=REX_ROOT / "outputs/spatial_attention_ablation_s1_beta1p5_step600")
    parser.add_argument("--step-label", default="step600")
    parser.add_argument(
        "--s1-dir",
        type=Path,
        default=REX_ROOT / "outputs/H-S1_beta1p5_step600_fullvol_val_predictions",
        help="Directory for this checkpoint's unmodified spatial-attention gamma=1 predictions.",
    )
    parser.add_argument(
        "--previous-summary-csv",
        type=Path,
        default=REX_ROOT / "outputs/spatial_attention_ablation_s1_beta1p5_step600/category_gamma_summary.csv",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    out_dir = args.out_dir
    anchor = REX_ROOT / "outputs/voxtell_rex_anchor85_step3800_bestval_fullvol_val_predictions"
    s1 = args.s1_dir
    step = args.step_label
    rows: list[dict] = []
    maybe_add(rows, "Anchor85_step3800", anchor, anchor, s1)
    maybe_add(rows, f"S1_{step}_gamma1", s1, anchor, s1)
    maybe_add(rows, f"S1_{step}_focaloff", out_dir / "category_focaloff", anchor, s1)
    maybe_add(rows, f"S1_{step}_focaloff_2c_on", out_dir / "category_focaloff_2c_on", anchor, s1)
    maybe_add(rows, f"S1_{step}_only_2d_off", out_dir / "category_only_2d_off", anchor, s1)
    maybe_add(rows, f"S1_{step}_1f_2d_2g_off", out_dir / "category_1f_2d_2g_off", anchor, s1)
    sweep = out_dir / "global_rho_sweep"
    maybe_add(rows, f"S1_{step}_global_gamma0", sweep / "gamma_0p00", anchor, s1)
    maybe_add(rows, f"S1_{step}_global_gamma0p25", sweep / "gamma_0p25", anchor, s1)
    maybe_add(rows, f"S1_{step}_global_gamma0p5", sweep / "gamma_0p50", anchor, s1)
    df = pd.DataFrame(rows)
    out_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_dir / "category_gamma_summary.csv", index=False)
    write_report(
        df,
        out_dir / "category_gamma_report.md",
        step_label=step,
        previous_summary_csv=args.previous_summary_csv,
    )
    write_report(
        df,
        out_dir / "report.txt",
        step_label=step,
        previous_summary_csv=args.previous_summary_csv,
    )
    print(df.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
