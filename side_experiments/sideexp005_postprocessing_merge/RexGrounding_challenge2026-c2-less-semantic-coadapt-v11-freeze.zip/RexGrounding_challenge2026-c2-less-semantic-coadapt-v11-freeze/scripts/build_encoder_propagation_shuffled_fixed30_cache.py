#!/usr/bin/env python3
"""Build a deterministic cross-case Qwen-token permutation for EP fixed30."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source",
        type=Path,
        default=ROOT
        / "outputs/token_image_text_attention_phase0/cache"
        / "qwen_contextual_content_tokens_train_val.pt",
    )
    parser.add_argument(
        "--selection",
        type=Path,
        default=ROOT
        / "outputs/prompt_standardization_rule_only_v1"
        / "stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT
        / "outputs/encoder_propagation_ep18_phase0/configs"
        / "qwen_contextual_tokens_fixed30_cross_case_shuffled.pt",
    )
    args = parser.parse_args()
    selected = list(csv.DictReader(args.selection.open(newline="", encoding="utf-8")))
    wanted = [(row["case"], int(row["finding_idx"])) for row in selected]
    payload = torch.load(args.source, map_location="cpu", weights_only=False)
    lookup = {
        (str(record["case"]), int(record["finding_idx"])): index
        for index, record in enumerate(payload["records"])
        if str(record["split"]) == "val"
    }
    missing = [key for key in wanted if key not in lookup]
    if missing:
        raise ValueError(f"Missing fixed30 token records: {missing}")
    shift = next(
        candidate
        for candidate in range(1, len(wanted))
        if all(
            wanted[index][0] != wanted[(index + candidate) % len(wanted)][0]
            for index in range(len(wanted))
        )
    )
    records = []
    token_features = []
    mapping = []
    for index, destination in enumerate(wanted):
        source = wanted[(index + shift) % len(wanted)]
        destination_record = dict(payload["records"][lookup[destination]])
        source_record = payload["records"][lookup[source]]
        records.append(destination_record)
        token_features.append(payload["token_features"][lookup[source]].clone())
        mapping.append(
            {
                "destination_case": destination[0],
                "destination_finding_idx": destination[1],
                "source_case": source[0],
                "source_finding_idx": source[1],
                "source_prompt": source_record.get("prompt"),
            }
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "metadata": {
                "schema": "ep18_fixed30_cross_case_shuffle_v1",
                "source": str(args.source.resolve()),
                "selection": str(args.selection.resolve()),
                "shift": shift,
                "records": len(records),
            },
            "records": records,
            "token_features": token_features,
        },
        args.output,
    )
    args.output.with_suffix(".mapping.json").write_text(
        json.dumps(mapping, indent=2) + "\n"
    )
    print(json.dumps({"output": str(args.output), "records": len(records), "shift": shift}))


if __name__ == "__main__":
    main()
