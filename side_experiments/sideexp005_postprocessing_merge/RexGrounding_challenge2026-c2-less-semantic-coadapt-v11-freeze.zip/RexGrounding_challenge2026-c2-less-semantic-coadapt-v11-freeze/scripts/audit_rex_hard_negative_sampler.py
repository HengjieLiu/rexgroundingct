#!/usr/bin/env python
"""Audit ReX hard-negative sampler roles without constructing VoxTell."""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Any

import numpy as np
import torch


REX_ROOT = Path(__file__).resolve().parents[1]
if str(REX_ROOT) not in sys.path:
    sys.path.insert(0, str(REX_ROOT))

from scripts.train_voxtell_rex_full_nnunet_aug import (  # noqa: E402
    RexPreprocessedSampler,
    build_case_records,
    load_manifest,
)


class MaskOnlyAuditSampler(RexPreprocessedSampler):
    """Use the production sampler while avoiding unnecessary CT decompression."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.actual_full_voxels: dict[tuple[str, int], int] = {}

    def _load_case(self, case: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
        key = f"{case['split']}/{case['case']}"
        if key in self.cache:
            value = self.cache.pop(key)
            self.cache[key] = value
            return value

        with np.load(self._cache_path(case), allow_pickle=False) as data:
            masks = data["masks"].astype(np.uint8, copy=False)
        if masks.shape[0] != len(case["findings"]):
            raise ValueError(f"{case['case']}: cache mask channels do not match metadata findings")
        image = np.zeros(masks.shape[1:], dtype=np.uint8)
        for finding in case["findings"]:
            channel = int(finding["channel"])
            self.actual_full_voxels[(case["case"], int(finding["finding_idx"]))] = int(
                np.count_nonzero(masks[channel])
            )

        while len(self.cache) >= self.cache_size:
            self.cache.popitem(last=False)
        self.cache[key] = (image, masks)
        return image, masks


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--training-args",
        type=Path,
        default=REX_ROOT
        / "outputs/voxtell_rex_patch_presence_hardneg_from_baseline_4l40s_2000steps/args.json",
    )
    parser.add_argument("--batches", type=int, default=1000)
    parser.add_argument("--cache-size", type=int, default=4)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REX_ROOT / "outputs/sampler_audit_hardneg_presence_1000",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = json.loads(args.training_args.read_text())
    if config["sampler_mode"] != "hard_negative_triplet":
        raise ValueError(f"Expected hard_negative_triplet, got {config['sampler_mode']}")

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    preprocessed_dir = Path(config["preprocessed_dir"])
    cases = build_case_records(load_manifest(preprocessed_dir), config["train_split"], config["max_train_cases"])
    finding_lookup = {
        (finding["case"], int(finding["finding_idx"])): finding
        for case in cases
        for finding in case["findings"]
    }
    dummy_embedding = torch.zeros(1, dtype=torch.float32)
    embedding_map = {
        (finding["split"], finding["case"], int(finding["finding_idx"])): dummy_embedding
        for finding in finding_lookup.values()
    }

    sampler = MaskOnlyAuditSampler(
        preprocessed_dir,
        cases,
        embedding_map,
        tuple(config["patch_size"]),
        config["positive_prompts"],
        config["negative_prompts"],
        config["positive_loss_weight"],
        config["negative_loss_weight"],
        config["foreground_prob"],
        config["require_positive_crop"],
        config["min_positive_voxels"],
        config["max_crop_attempts"],
        config["max_sample_attempts"],
        args.cache_size,
        None,
        config["hard_negative_sampler"],
        config["hard_negative_match"],
        config["hard_negative_exclude_identical_prompt"],
        config["sampler_mode"],
        config["anchor_positive_prob"],
        config["same_case_negative_prob"],
        config["shuffle_prompt_order"],
        config["cross_case_negative_requires_foreground"],
    )

    slot_counts: Counter[str] = Counter()
    batch_counts: Counter[str] = Counter()
    violations: Counter[str] = Counter()
    rows: list[dict[str, Any]] = []

    for batch_idx in range(args.batches):
        _, _, _, _, meta = sampler.sample()
        current_case = meta["case"]
        roles = meta["roles_after_shuffle"]
        indices = [int(v) for v in meta["prompt_indices_after_shuffle"]]
        source_cases = meta["source_cases_after_shuffle"]
        prompts = meta["prompt_texts_after_shuffle"]
        crop_voxels = [int(v) for v in meta["target_voxels"]]

        anchor_positions = [i for i, role in enumerate(roles) if role == "A_anchor_positive"]
        if len(anchor_positions) != 1:
            violations["anchor_role_count_not_one"] += 1
            continue
        anchor_pos = anchor_positions[0]
        anchor_key = (source_cases[anchor_pos], indices[anchor_pos])
        seen_types: set[str] = set()

        for position, (role, source_case, finding_idx, prompt, crop_count) in enumerate(
            zip(roles, source_cases, indices, prompts, crop_voxels)
        ):
            key = (source_case, finding_idx)
            record = finding_lookup.get(key)
            manifest_full_count = None if record is None else record.get("source_foreground_voxels")
            actual_full_count = sampler.actual_full_voxels.get(key)

            if role == "A_anchor_positive":
                sample_type = "positive_anchored_crop"
            elif role == "B_same_case_negative":
                sample_type = "same_case_different_finding_spatial_empty"
            elif role == "C_cross_case_negative":
                sample_type = "cross_case_prompt"
            else:
                sample_type = "unexpected_role"

            is_exact_same_prompt_empty = (
                source_case == current_case
                and key == anchor_key
                and prompt == prompts[anchor_pos]
                and crop_count == 0
                and manifest_full_count is not None
                and int(manifest_full_count) > 0
            )
            if is_exact_same_prompt_empty:
                slot_counts["same_case_same_prompt_spatial_empty"] += 1
                seen_types.add("same_case_same_prompt_spatial_empty")

            slot_counts[sample_type] += 1
            seen_types.add(sample_type)

            if record is None:
                violations[f"{sample_type}:missing_finding_record"] += 1
            else:
                if prompt != record["prompt"]:
                    violations[f"{sample_type}:prompt_changed"] += 1
                if manifest_full_count is None or int(manifest_full_count) <= 0:
                    violations[f"{sample_type}:full_mask_not_positive"] += 1
            if sample_type == "positive_anchored_crop":
                if source_case != current_case or key != anchor_key or crop_count <= 0:
                    violations[f"{sample_type}:identity_or_crop"] += 1
            elif sample_type == "same_case_different_finding_spatial_empty":
                if source_case != current_case or key == anchor_key or crop_count != 0:
                    violations[f"{sample_type}:identity_or_crop"] += 1
                if actual_full_count is None or actual_full_count <= 0:
                    violations[f"{sample_type}:actual_full_mask_not_positive"] += 1
            elif sample_type == "cross_case_prompt":
                if source_case == current_case or crop_count != 0:
                    violations[f"{sample_type}:identity_or_crop"] += 1

            rows.append(
                {
                    "batch": batch_idx,
                    "position": position,
                    "type": sample_type,
                    "role": role,
                    "current_case": current_case,
                    "source_case": source_case,
                    "finding_idx": finding_idx,
                    "anchor_case": anchor_key[0],
                    "anchor_finding_idx": anchor_key[1],
                    "same_as_anchor_identity": int(key == anchor_key),
                    "prompt_unchanged_from_full_record": int(record is not None and prompt == record["prompt"]),
                    "manifest_full_mask_voxels": manifest_full_count,
                    "actual_full_mask_voxels_if_current_case_loaded": actual_full_count,
                    "crop_mask_voxels": crop_count,
                }
            )

        for sample_type in seen_types:
            batch_counts[sample_type] += 1

    slot_counts.setdefault("same_case_same_prompt_spatial_empty", 0)
    batch_counts.setdefault("same_case_same_prompt_spatial_empty", 0)
    total_slots = sum(count for key, count in slot_counts.items() if key != "same_case_same_prompt_spatial_empty")
    summary = {
        "training_args": str(args.training_args.resolve()),
        "sampler_mode": config["sampler_mode"],
        "requested_batches": args.batches,
        "audited_batches": args.batches,
        "prompt_slots": total_slots,
        "configured_values_not_used_by_hard_negative_triplet": {
            "anchor_positive_prob": config["anchor_positive_prob"],
            "same_case_negative_prob": config["same_case_negative_prob"],
        },
        "counts": {
            key: {
                "slot_count": slot_counts[key],
                "slot_percent": 100.0 * slot_counts[key] / max(1, total_slots),
                "batch_count": batch_counts[key],
                "batch_percent": 100.0 * batch_counts[key] / max(1, args.batches),
            }
            for key in sorted(slot_counts)
        },
        "violations": dict(sorted(violations.items())),
        "same_case_same_prompt_spatial_empty_implemented": slot_counts["same_case_same_prompt_spatial_empty"] > 0,
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (args.output_dir / "prompt_slots.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else [])
        if rows:
            writer.writeheader()
            writer.writerows(rows)
    print(json.dumps(summary, indent=2))
    return 0 if not violations else 2


if __name__ == "__main__":
    raise SystemExit(main())
