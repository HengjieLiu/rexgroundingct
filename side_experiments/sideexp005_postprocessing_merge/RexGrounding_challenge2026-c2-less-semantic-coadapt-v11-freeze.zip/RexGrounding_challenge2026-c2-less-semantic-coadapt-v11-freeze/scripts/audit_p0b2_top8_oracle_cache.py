#!/usr/bin/env python3
"""Audit fold-0 P0-B2 top-8 native-96 caches before exact oracle enumeration."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from p0b2_lite_common import (
    BASE_CHECKPOINT,
    FINAL_THRESHOLD,
    OUT as P0B2,
    PREP,
    ZOOM,
    ZOOM_SOURCE,
    archive_path,
    atomic_csv,
    atomic_json,
    insert_zoom_max,
    load_manifest,
    proposal_cache_path,
    sha256,
)

OUT = Path("outputs/p0b2_top8_residual_utility_oracle_fold0")


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "logs").mkdir(exist_ok=True)
    (OUT / "visualizations").mkdir(exist_ok=True)
    candidates = pd.read_csv(P0B2 / "heldout_candidate_scores.csv")
    candidates = candidates.loc[candidates.outer_fold.eq(0)].copy()
    candidates["learned_rank"] = (
        candidates.sort_values(
            ["finding_key", "coverage_score", "candidate_index"],
            ascending=[True, False, True],
        )
        .groupby("finding_key")
        .cumcount()
        .add(1)
        .reindex(candidates.index)
    )
    findings = pd.read_csv(P0B2 / "case_finding_split_manifest.csv")
    findings = findings.loc[findings.outer_fold.eq(0)].copy()
    finding_lookup = findings.set_index("finding_key")
    missing, audited = [], []
    expected_checkpoint = str(BASE_CHECKPOINT.resolve())
    for _, candidate in candidates.sort_values("candidate_index").iterrows():
        key = candidate.finding_key
        finding = finding_lookup.loc[key]
        if str(candidate.prompt) != str(finding.prompt):
            raise AssertionError(f"{candidate.candidate_uid}: prompt identity mismatch")
        center = np.asarray(
            [
                candidate.candidate_center_d,
                candidate.candidate_center_h,
                candidate.candidate_center_w,
            ],
            dtype=int,
        )
        start = np.asarray(
            [
                candidate.roi_requested_d0,
                candidate.roi_requested_h0,
                candidate.roi_requested_w0,
            ],
            dtype=int,
        )
        stop = np.asarray(
            [
                candidate.roi_requested_d1,
                candidate.roi_requested_h1,
                candidate.roi_requested_w1,
            ],
            dtype=int,
        )
        if not np.array_equal(start, center - 48) or not np.array_equal(
            stop, start + 96
        ):
            raise AssertionError(f"{candidate.candidate_uid}: fixed-96 geometry mismatch")
        cache = proposal_cache_path(
            ZOOM,
            str(candidate["case"]),
            int(candidate.finding_idx),
            int(candidate.component_id),
        )
        if not cache.exists():
            missing.append(
                {
                    "candidate_uid": candidate.candidate_uid,
                    "candidate_index": int(candidate.candidate_index),
                    "case": candidate["case"],
                    "finding_idx": int(candidate.finding_idx),
                    "component_id": int(candidate.component_id),
                    "cache_path": str(cache),
                }
            )
            continue
        with np.load(cache, allow_pickle=False) as archive:
            probability = archive["zoom_probability"]
            metadata = json.loads(str(archive["metadata_json"].item()))
        if probability.shape != (96, 96, 96):
            raise AssertionError(f"{candidate.candidate_uid}: cache is not 96^3")
        expected = {
            "case": str(candidate["case"]),
            "finding_idx": int(candidate.finding_idx),
            "component_id": int(candidate.component_id),
            "requested_start": start.tolist(),
            "checkpoint": expected_checkpoint,
            "native_crop": [96, 96, 96],
            "final_threshold": FINAL_THRESHOLD,
        }
        for field, value in expected.items():
            if metadata.get(field) != value:
                raise AssertionError(
                    f"{candidate.candidate_uid}: cache metadata {field}="
                    f"{metadata.get(field)!r}, expected {value!r}"
                )
        audited.append(
            {
                "candidate_uid": candidate.candidate_uid,
                "candidate_index": int(candidate.candidate_index),
                "cache_path": str(cache),
                "cache_shape": list(probability.shape),
                "metadata_aligned": True,
            }
        )
    missing_columns = [
        "candidate_uid",
        "candidate_index",
        "case",
        "finding_idx",
        "component_id",
        "cache_path",
    ]
    atomic_csv(
        pd.DataFrame(missing, columns=missing_columns),
        OUT / "missing_candidate_predictions.csv",
    )

    # Fixed qualitative/numeric mapping checks from deployable metadata.
    criteria = {
        "tiny": candidates.size_bin.eq("tiny_lt100"),
        "baseline_miss": candidates.baseline_hit.eq(0),
        "boundary": candidates.crop_padding_indicator.eq(1),
        "multifocal": candidates.gt_component_count.gt(1),
        "heuristic_top3": candidates.heuristic_rank.le(3),
        "outside_both_top3": candidates.heuristic_rank.gt(3)
        & candidates.learned_rank.gt(3),
    }
    selected_examples = {}
    used: set[int] = set()
    for name, mask in criteria.items():
        pool = candidates.loc[mask & ~candidates.candidate_index.isin(used)].sort_values(
            ["candidate_index"]
        )
        if pool.empty:
            pool = candidates.loc[mask].sort_values("candidate_index")
        if pool.empty:
            raise AssertionError(f"No example available for required audit type {name}")
        row = pool.iloc[0]
        used.add(int(row.candidate_index))
        selected_examples[name] = row

    manifest = {
        row["case"]: row for row in load_manifest(PREP / "manifest.jsonl", "val", None)
    }
    examples = {}
    for name, candidate in selected_examples.items():
        case = str(candidate["case"])
        finding_idx = int(candidate.finding_idx)
        channel = int(candidate.channel)
        with np.load(manifest[case]["cache_path"], allow_pickle=False) as archive:
            gt = archive["masks"][channel].astype(bool)
        with np.load(
            archive_path(ZOOM_SOURCE / "context_probabilities", case),
            allow_pickle=False,
        ) as archive:
            context = archive["probability"][channel].astype(np.float16)
            finding_ids = [int(value) for value in archive["finding_ids"]]
        if finding_ids[channel] != finding_idx:
            raise AssertionError(f"{case}/{finding_idx}: context channel mismatch")
        cache = proposal_cache_path(
            ZOOM, case, finding_idx, int(candidate.component_id)
        )
        with np.load(cache, allow_pickle=False) as archive:
            patch = archive["zoom_probability"].astype(np.float16)
        mapped = np.zeros_like(context, dtype=np.float16)
        coverage = np.zeros_like(context, dtype=bool)
        start = tuple(
            int(candidate[f"roi_requested_{axis}0"]) for axis in "dhw"
        )
        insert_zoom_max(mapped, coverage, patch, start)
        maximum = np.maximum(context, mapped)
        depth = int(candidate.candidate_center_d)
        fig, axes = plt.subplots(1, 4, figsize=(16, 4))
        axes[0].imshow(context[depth], cmap="magma", vmin=0, vmax=1)
        axes[0].set_title("Native-192 probability")
        axes[1].imshow(gt[depth], cmap="gray", vmin=0, vmax=1)
        axes[1].set_title("GT")
        axes[2].imshow(mapped[depth], cmap="magma", vmin=0, vmax=1)
        axes[2].set_title("Mapped native-96")
        axes[3].imshow(maximum[depth] > FINAL_THRESHOLD, cmap="gray")
        axes[3].contour(gt[depth], levels=[0.5], colors="red", linewidths=0.6)
        axes[3].set_title("Max mask; GT red")
        for axis in axes:
            axis.axis("off")
        fig.suptitle(f"{name}: {candidate.candidate_uid}")
        fig.tight_layout()
        figure_path = OUT / "visualizations" / f"{name}.png"
        fig.savefig(figure_path, dpi=140)
        plt.close(fig)
        examples[name] = {
            "candidate_uid": candidate.candidate_uid,
            "case": case,
            "finding_idx": finding_idx,
            "prompt": candidate.prompt,
            "center_dhw": [
                int(candidate.candidate_center_d),
                int(candidate.candidate_center_h),
                int(candidate.candidate_center_w),
            ],
            "requested_start_dhw": list(start),
            "heuristic_rank": int(candidate.heuristic_rank),
            "learned_rank": int(candidate.learned_rank),
            "padding": int(candidate.crop_padding_indicator),
            "safe_coverage": float(candidate.safe_inner_coverage),
            "mapped_coverage_voxels": int(coverage.sum()),
            "mapped_positive_voxels": int(
                np.logical_and(coverage, mapped > FINAL_THRESHOLD).sum()
            ),
            "visualization": str(figure_path),
        }
    audit = {
        "status": "complete",
        "screening_fold": 0,
        "fold0_findings": len(findings),
        "fold0_candidates": len(candidates),
        "findings_with_candidates": int(candidates.finding_key.nunique()),
        "cached_candidate_predictions": len(audited),
        "missing_candidate_predictions": len(missing),
        "cache_complete": len(missing) == 0,
        "conditional_gpu_inference_required": len(missing) > 0,
        "checkpoint": expected_checkpoint,
        "checkpoint_sha256": sha256(BASE_CHECKPOINT),
        "official_threshold": FINAL_THRESHOLD,
        "prompt_identity_exact": True,
        "candidate_center_and_bounds_exact": True,
        "cache_metadata_exact": True,
        "required_example_types_verified": sorted(examples),
        "examples": examples,
    }
    atomic_json(audit, OUT / "cache_audit.json")
    print(json.dumps(audit, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
