#!/usr/bin/env python3
"""Audit exact five-lobe GT coverage and ACA routing eligibility.

This script only reads the existing preprocessed ReX arrays and audited lobe-label
cache.  It does not invoke TotalSegmentator or write outside its new output root.
"""

from __future__ import annotations

import argparse
import csv
import json
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np

from scripts.evaluate_semantic_aware_lobe_constraint_part1 import semantic_parse


ANATOMIES = ("RUL", "RML", "RLL", "LUL", "LLL", "GLOBAL")
LOBE_IDS = {"RUL": 3, "RML": 4, "RLL": 5, "LUL": 1, "LLL": 2}
LEFT = {"LUL", "LLL"}
RIGHT = {"RUL", "RML", "RLL"}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--preprocessed-dir",
        type=Path,
        default=root / "data/rex_voxtell_preprocessed_v1",
    )
    parser.add_argument(
        "--lobe-label-dir",
        type=Path,
        default=root / "data/rex_lobe_labels_preprocessed_v1",
    )
    parser.add_argument(
        "--fixed30-csv",
        type=Path,
        default=root
        / "outputs/prompt_location_alignment_loss_v1_lambda0_control_allcat1over1_step6000"
        / "subset30_update250/fixed30_findings.csv",
    )
    parser.add_argument("--train-findings", type=int, default=200)
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument("--min-overlap-threshold", type=float, default=0.05)
    parser.add_argument("--positive-prompts-per-step", type=int, default=2)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def stem(name: str) -> str:
    return name[:-7] if name.endswith(".nii.gz") else Path(name).stem


def load_manifest(path: Path) -> list[dict[str, Any]]:
    with path.open() as handle:
        return [json.loads(line) for line in handle if line.strip()]


def finding_records(row: dict[str, Any]) -> list[dict[str, Any]]:
    output = []
    categories = row.get("categories") or {}
    for channel, finding_id in enumerate(row["finding_indices"]):
        output.append(
            {
                "case_id": str(row["case"]),
                "finding_id": int(finding_id),
                "channel": int(channel),
                "prompt": str(row["prompts"][channel]),
                "category": str(
                    categories.get(str(finding_id), categories.get(str(channel), "unknown"))
                ),
            }
        )
    return output


def load_case_arrays(
    row: dict[str, Any],
    lobe_root: Path,
) -> tuple[np.ndarray, list[int], np.ndarray]:
    case_path = Path(row["cache_path"])
    lobe_path = lobe_root / str(row["split"]) / f"{stem(str(row['case']))}.npz"
    if not case_path.is_file() or not lobe_path.is_file():
        raise FileNotFoundError(f"Missing aligned inputs: {case_path}, {lobe_path}")
    with np.load(case_path, allow_pickle=False) as archive:
        masks = archive["masks"].astype(bool)
        finding_ids = [int(value) for value in archive["finding_indices"]]
    with np.load(lobe_path, allow_pickle=False) as archive:
        lobe_label = archive["lobe_label"].astype(np.uint8)
    if tuple(masks.shape[1:]) != tuple(lobe_label.shape):
        raise RuntimeError(
            f"{row['case']}: GT {masks.shape[1:]} != lobe label {lobe_label.shape}"
        )
    expected = tuple(row["preprocessed_shape"])
    if tuple(lobe_label.shape) != expected:
        raise RuntimeError(
            f"{row['case']}: lobe label {lobe_label.shape} != manifest CT {expected}"
        )
    values = set(map(int, np.unique(lobe_label)))
    if not values.issubset(set(range(6))):
        raise RuntimeError(f"{row['case']}: invalid lobe values {sorted(values)}")
    return masks, finding_ids, lobe_label


def analyze_finding(
    record: dict[str, Any],
    gt: np.ndarray,
    lobe_label: np.ndarray,
    threshold: float,
    subset: str,
) -> dict[str, Any]:
    gt_voxels = int(np.count_nonzero(gt))
    masses = {
        name: int(np.count_nonzero(gt & (lobe_label == label_id)))
        for name, label_id in LOBE_IDS.items()
    }
    masses["GLOBAL"] = int(np.count_nonzero(gt & (lobe_label == 0)))
    union_coverage = (
        float(sum(masses[name] for name in LOBE_IDS) / gt_voxels)
        if gt_voxels
        else None
    )
    dominant = max(ANATOMIES, key=lambda name: masses[name]) if gt_voxels else ""
    parsed = semantic_parse(record["prompt"])
    parsed_lobes = [str(value) for value in parsed.get("lobes") or []]
    parsed_side = str(parsed.get("side") or "")
    dominant_side = (
        "left" if dominant in LEFT else "right" if dominant in RIGHT else "global"
    )
    overlap = {
        name: (float(masses[name] / gt_voxels) if gt_voxels else 0.0)
        for name in ANATOMIES
    }
    # GLOBAL visual pooling spans the full patch and is always an ACA fallback.
    aca_eligible = {
        name: bool(gt_voxels and overlap[name] >= threshold) for name in LOBE_IDS
    }
    aca_eligible["GLOBAL"] = bool(gt_voxels)
    return {
        **record,
        "subset": subset,
        "gt_voxels": gt_voxels,
        **{f"mass_{name}": masses[name] for name in ANATOMIES},
        **{f"overlap_{name}": overlap[name] for name in ANATOMIES},
        **{f"aca_eligible_{name}": aca_eligible[name] for name in ANATOMIES},
        "union_five_lobe_coverage": union_coverage,
        "dominant_anatomy": dominant,
        "mostly_global": bool(dominant == "GLOBAL"),
        "parser_group": str(parsed["group"]),
        "parser_side": parsed_side,
        "parser_lobes": "+".join(parsed_lobes),
        "explicit_lobe_agrees": (
            bool(dominant in parsed_lobes) if parsed_lobes and gt_voxels else None
        ),
        "left_right_agrees": (
            bool(parsed_side == dominant_side)
            if parsed_side in {"left", "right"} and dominant_side in {"left", "right"}
            else None
        ),
        "lobe_specific_aca_eligible": any(aca_eligible[name] for name in LOBE_IDS),
        "any_aca_eligible_including_global": bool(gt_voxels),
    }


def select_grouped_train_findings(
    train_rows: list[dict[str, Any]],
    requested: int,
    seed: int,
) -> dict[str, list[dict[str, Any]]]:
    if requested < 200:
        raise ValueError("--train-findings must be at least 200")
    rng = random.Random(seed)
    rows = list(train_rows)
    rng.shuffle(rows)
    selected: dict[str, list[dict[str, Any]]] = {}
    count = 0
    for row in rows:
        records = finding_records(row)
        if not records:
            continue
        selected[str(row["case"])] = records
        count += len(records)
        if count >= requested:
            break
    if count < requested:
        raise RuntimeError(f"Only {count} training findings are available")
    return selected


def summarize(rows: list[dict[str, Any]], args: argparse.Namespace) -> dict[str, Any]:
    nonempty = [row for row in rows if int(row["gt_voxels"]) > 0]
    dominant = Counter(row["dominant_anatomy"] for row in nonempty)
    explicit = [row["explicit_lobe_agrees"] for row in nonempty if row["explicit_lobe_agrees"] is not None]
    side = [row["left_right_agrees"] for row in nonempty if row["left_right_agrees"] is not None]
    per_anatomy_fraction = {
        name: float(
            np.mean([bool(row[f"aca_eligible_{name}"]) for row in nonempty])
        )
        if nonempty
        else 0.0
        for name in ANATOMIES
    }
    return {
        "findings": len(rows),
        "nonempty_findings": len(nonempty),
        "mean_gt_coverage_by_five_lobe_union": float(
            np.mean([row["union_five_lobe_coverage"] for row in nonempty])
        )
        if nonempty
        else 0.0,
        "median_gt_coverage_by_five_lobe_union": float(
            np.median([row["union_five_lobe_coverage"] for row in nonempty])
        )
        if nonempty
        else 0.0,
        "dominant_anatomy_distribution": dict(dominant),
        "mostly_global_fraction": float(
            np.mean([bool(row["mostly_global"]) for row in nonempty])
        )
        if nonempty
        else 0.0,
        "explicit_lobe_parser_gt_agreement": float(np.mean(explicit)) if explicit else None,
        "explicit_lobe_count": len(explicit),
        "left_right_agreement": float(np.mean(side)) if side else None,
        "left_right_count": len(side),
        "lobe_specific_aca_eligible_fraction": float(
            np.mean([bool(row["lobe_specific_aca_eligible"]) for row in nonempty])
        )
        if nonempty
        else 0.0,
        "any_aca_eligible_fraction_including_global": 1.0 if nonempty else 0.0,
        "aca_eligibility_fraction_by_anatomy": per_anatomy_fraction,
        "projected_current_pairs_per_optimizer_step_by_anatomy": {
            name: args.positive_prompts_per_step * fraction
            for name, fraction in per_anatomy_fraction.items()
        },
        "projected_total_current_pairs_per_optimizer_step": float(
            args.positive_prompts_per_step * sum(per_anatomy_fraction.values())
        ),
        "queue_policy": "one detached FIFO per anatomy makes single-current-pair groups active after warmup",
    }


def main() -> int:
    args = parse_args()
    if args.output_dir.exists():
        raise FileExistsError(f"Refusing to overwrite output directory: {args.output_dir}")
    args.output_dir.mkdir(parents=True)
    manifest = load_manifest(args.preprocessed_dir / "manifest.jsonl")
    by_case = {str(row["case"]): row for row in manifest if row.get("has_mask")}
    train_rows = [row for row in manifest if row.get("split") == "train" and row.get("has_mask")]
    grouped_train = select_grouped_train_findings(
        train_rows, args.train_findings, args.seed
    )
    with args.fixed30_csv.open(newline="", encoding="utf-8") as handle:
        fixed_records = list(csv.DictReader(handle))
    if len(fixed_records) != 49 or len({row["case_id"] for row in fixed_records}) != 30:
        raise RuntimeError("fixed30 source must contain exactly 30 cases / 49 findings")
    grouped_fixed: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in fixed_records:
        grouped_fixed[str(row["case_id"])].append(
            {
                "case_id": str(row["case_id"]),
                "finding_id": int(row["finding_idx"]),
                "channel": -1,
                "prompt": str(row["prompt"]),
                "category": str(row["category"]),
            }
        )
    output_rows: list[dict[str, Any]] = []
    alignment_assertions = 0
    for subset, groups in (("train_sample", grouped_train), ("fixed30", grouped_fixed)):
        limit = args.train_findings if subset == "train_sample" else None
        subset_count = 0
        for case_id, requested_records in groups.items():
            if case_id not in by_case:
                raise KeyError(f"{case_id} is absent from the preprocessed manifest")
            source_row = by_case[case_id]
            masks, ids, lobe_label = load_case_arrays(source_row, args.lobe_label_dir)
            alignment_assertions += 1
            mask_by_id = {finding_id: masks[index] for index, finding_id in enumerate(ids)}
            for record in requested_records:
                if limit is not None and subset_count >= limit:
                    break
                finding_id = int(record["finding_id"])
                if finding_id not in mask_by_id:
                    raise KeyError(f"{case_id}: missing GT finding {finding_id}")
                output_rows.append(
                    analyze_finding(
                        record,
                        mask_by_id[finding_id],
                        lobe_label,
                        args.min_overlap_threshold,
                        subset,
                    )
                )
                subset_count += 1
            if limit is not None and subset_count >= limit:
                break
    train_output = [row for row in output_rows if row["subset"] == "train_sample"]
    fixed_output = [row for row in output_rows if row["subset"] == "fixed30"]
    if len(train_output) < 200 or len(fixed_output) != 49:
        raise RuntimeError(
            f"Audit sample sizes invalid: train={len(train_output)}, fixed30={len(fixed_output)}"
        )
    per_finding_path = args.output_dir / "per_finding_anatomy_audit.csv"
    with per_finding_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(output_rows[0]))
        writer.writeheader()
        writer.writerows(output_rows)
    aggregate = {
        "schema": "aca_anatomy_phase0a_audit_v1",
        "settings": {
            "seed": args.seed,
            "min_overlap_threshold": args.min_overlap_threshold,
            "positive_prompts_per_step": args.positive_prompts_per_step,
            "preprocessed_dir": str(args.preprocessed_dir.resolve()),
            "lobe_label_dir": str(args.lobe_label_dir.resolve()),
            "fixed30_csv": str(args.fixed30_csv.resolve()),
        },
        "spatial_correspondence_assertions_passed": alignment_assertions,
        "train_sample": summarize(train_output, args),
        "fixed30": summarize(fixed_output, args),
        "misalignment_detected": False,
        "totalsegmentator_rerun": False,
        "outputs": {"per_finding_csv": str(per_finding_path.resolve())},
    }
    (args.output_dir / "aggregate.json").write_text(json.dumps(aggregate, indent=2) + "\n")
    report = [
        "# ACA anatomy Phase 0A data audit",
        "",
        f"- Spatial shape/value assertions passed for {alignment_assertions} loaded cases.",
        f"- Train findings: {len(train_output)}; fixed30: 30 cases / {len(fixed_output)} findings.",
        f"- Train mean exact five-lobe-union GT coverage: {aggregate['train_sample']['mean_gt_coverage_by_five_lobe_union']:.6f}.",
        f"- Fixed30 mean exact five-lobe-union GT coverage: {aggregate['fixed30']['mean_gt_coverage_by_five_lobe_union']:.6f}.",
        f"- Train lobe-specific ACA eligibility: {aggregate['train_sample']['lobe_specific_aca_eligible_fraction']:.6f}.",
        f"- Fixed30 lobe-specific ACA eligibility: {aggregate['fixed30']['lobe_specific_aca_eligible_fraction']:.6f}.",
        "",
        "GLOBAL is eligible for every non-empty finding because its visual token pools the full feature map; lobe-specific eligibility is therefore reported separately.",
        "",
        "No TotalSegmentator task was run and no cache was modified.",
    ]
    (args.output_dir / "report.md").write_text("\n".join(report) + "\n")
    print(json.dumps(aggregate, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
