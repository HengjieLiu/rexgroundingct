"""Incremental paired fixed30 summaries with case-cluster bootstrap."""
import csv
import json
import os
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(os.environ.get('LESS_MINIMAL_AUDIT_ROOT',str(Path(__file__).resolve().parents[1]/'less_minimal_mechanism_audit')))


def markdown(frame):
    return '\n'.join(['| '+' | '.join(frame.columns)+' |',
                      '| '+' | '.join(['---']*len(frame.columns))+' |']+
                     ['| '+' | '.join(str(v) for v in row)+' |'
                      for row in frame.itertuples(index=False,name=None)])


def paired(frame, other):
    delta=frame['normal']-frame[other]
    grouped=pd.DataFrame({'case':frame['file'],'d':delta}).groupby('case').d.agg(['sum','count'])
    idx=np.random.default_rng(1701).integers(0,len(grouped),(10000,len(grouped)))
    boot=grouped['sum'].to_numpy()[idx].sum(1)/grouped['count'].to_numpy()[idx].sum(1)
    return {'mean':float(delta.mean()),'median':float(delta.median()),
            'ci95':np.quantile(boot,[.025,.975]).tolist(),
            'improved':int((delta>0).sum()),'worsened':int((delta<0).sum()),
            'tied':int((delta==0).sum()),'fraction_positive':float((delta>0).mean())}


def main():
    trajectories=[]; findings=[]; features=[]; stats={}
    expected=None
    for u in [1000,3000,5000]:
        paths={c:ROOT/str(u)/'formal'/c/'summary_tables/per_finding_metrics.csv'
               for c in ['normal','bypass','wrong']}
        if not all(p.exists() for p in paths.values()):continue
        frames={c:pd.read_csv(p).set_index(['file','finding_idx']).sort_index() for c,p in paths.items()}
        keys=frames['normal'].index
        assert len(keys)==49 and keys.get_level_values(0).nunique()==30
        if expected is None:expected=keys
        assert keys.equals(expected)
        for f in frames.values():assert f.index.equals(keys)
        merged=pd.DataFrame({c:f.global_dice for c,f in frames.items()}).reset_index()
        merged['update']=u
        findings.append(merged)
        row={'update':u}
        for c,f in frames.items():
            row[c+'_dice']=float(f.global_dice.mean())
            row[c+'_case_dice']=float(f.groupby(level=0).global_dice.mean().mean())
            row[c+'_hit']=int((f.global_dice>.1).sum())
        for other in ['bypass','wrong']:
            s=paired(merged,other);stats[f'{u}_normal_minus_{other}']=s
            row['normal_minus_'+other]=s['mean']
            row[other+'_ci_low'],row[other+'_ci_high']=s['ci95']
            row[other+'_fraction_normal_better']=s['fraction_positive']
        trajectories.append(row)
        for c in ['normal','bypass','wrong']:
            records={r['case']:r for r in map(json.loads,(ROOT/str(u)/'formal'/f'{c}_audit.jsonl').read_text().splitlines())}
            for r in records.values():features.extend(r['features'])
    if not trajectories:return
    df=pd.DataFrame(trajectories);df.to_csv(ROOT/'trajectory.csv',index=False)
    pd.concat(findings).to_csv(ROOT/'per_finding.csv',index=False)
    ff=pd.DataFrame(features);ff.to_csv(ROOT/'feature_effects.csv',index=False)
    (ROOT/'bootstrap_summary.json').write_text(json.dumps(stats,indent=2)+'\n')
    complete=len(df)==3
    classification=mechanism='INCONCLUSIVE'
    recommendation='Complete the three-checkpoint audit before selecting a follow-up.'
    # Conservative descriptive equivalence band, not a formal equivalence test.
    # Wide CIs lead to INCONCLUSIVE, rather than interpreting non-significance as equivalence.
    if complete:
        early,mid,final=[stats[f'{u}_normal_minus_bypass'] for u in [1000,3000,5000]]
        near=lambda s: max(abs(x) for x in s['ci95'])<.001
        if all(near(s) for s in [early,mid,final]): classification='NEAR_ZERO_THROUGHOUT'
        elif early['ci95'][0]>0 and early['mean']>mid['mean']>final['mean'] and near(final):
            classification='EARLY_DEPENDENCE_THEN_DECAY';mechanism='TRANSIENT_TRAINING_SCAFFOLD'
            recommendation='Test early-only LESS with an otherwise matched training recipe.'
        elif all(s['ci95'][0]>0 for s in [early,mid,final]): classification='PERSISTENT_DEPENDENCE'
        wrong=[stats[f'{u}_normal_minus_wrong'] for u in [1000,3000,5000]]
        effect=ff[ff.condition=='wrong'].groupby('update').text_rel_l2.mean()
        if mechanism=='INCONCLUSIVE':
            if classification=='PERSISTENT_DEPENDENCE' and all(s['ci95'][0]>0 for s in wrong):
                mechanism='PERSISTENT_FUNCTIONAL_TEXT_CONDITIONING'
                recommendation='Improve the quality of LESS conditioning while retaining the current coupling.'
            elif all(near(s) for s in wrong) and all(effect>.001):
                mechanism='TEXT_CONDITIONED_BUT_DOWNSTREAM_REDUNDANT'
                recommendation='Test a matched modulation/gating coupling in place of the residual LESS writeback.'
            elif classification=='NEAR_ZERO_THROUGHOUT' and all(near(s) for s in wrong) and all(effect<.0001):
                mechanism='GENERIC_OPTIMIZATION_REGULARIZATION'
                recommendation='Compare matched training with factual versus fixed LESS text.'
            else:
                recommendation='Resolve the widest paired uncertainty before selecting a training intervention.'
    prov=json.loads((ROOT/'provenance.json').read_text())
    lines=['# Minimal LESS mechanism audit','','CHECKPOINTS:']
    lines += [f'{label} = {u}: {prov["checkpoints"][str(u)]}' for label,u in zip(['early','mid','final'],[1000,3000,5000])]
    lines += ['','BYPASS TRAJECTORY:']
    for r in trajectories:lines.append(f"{r['update']}: {r['normal_minus_bypass']:+.6f}, CI [{r['bypass_ci_low']:+.6f}, {r['bypass_ci_high']:+.6f}]")
    lines += ['',f'CLASSIFICATION: `{classification}`','','LESS-TEXT FEATURE EFFECT:']
    for (u,level),f in ff[ff.condition=='wrong'].groupby(['update','level']):
        lines.append(f'{u} {level}: mean rel-L2 {f.text_rel_l2.mean():.8f}; mean cosine {f.text_cosine.mean():.8f}; N={len(f)}')
    lines += ['','LESS-TEXT PREDICTION EFFECT:']
    for r in trajectories:lines.append(f"{r['update']}: {r['normal_minus_wrong']:+.6f}, CI [{r['wrong_ci_low']:+.6f}, {r['wrong_ci_high']:+.6f}]")
    lines += ['',f'MOST PLAUSIBLE MECHANISM: `{mechanism}`','',f'NEXT EXPERIMENT: {recommendation}',
              '',f'Status: {"COMPLETE" if complete else "PARTIAL — remaining checkpoints pending"}',
              '\n## Trajectory\n',markdown(df),
              '\n## Interpretation and limits\n',
              'Positive Dice differences favor correct normal LESS. Bootstrap resamples 30 cases, preserving within-case findings (10000 draws, seed1701). '
              'A descriptive near-zero label requires the whole CI inside ±0.001 Dice; non-significance alone is not equivalence. '
              'Feature bands (<0.0001 very small, >0.001 appreciable rel-L2) are descriptive and not semantic evidence; intermediate values remain inconclusive. '
              'Three fixed cases, first window/first prompt, all four scales; full tensor metrics, no sampled coordinates. '
              'No unobserved checkpoints are covered: near-zero at 1000 cannot exclude a transient effect before 1000. '
              'Bypass and wrong text are interventions on a frozen model, not matched training counterfactuals.',
              '\n## Direct answers\n',
              f'1. Meaningful direct inference-time importance: {classification}; see paired intervals above.',
              f'2. Dependence decayed: {"supported" if classification=="EARLY_DEPENDENCE_THEN_DECAY" else "not established"}.',
              '3. LESS text dependence: quantified separately per scale above; numerical dependence does not establish semantic utility.',
              '4. Wrong LESS text changes final segmentation: see normal-minus-wrong effects and CIs; main factual inputs pass identity checks.',
              f'5. Explanation of existing training gain: {mechanism}; these inference observations cannot prove its training cause.',
              f'6. Single next experiment: {recommendation}',
              '\nContext only: prior @5000 Full200 B3+LESS−B3 +0.006669; normal−bypass +0.000152, CI [−0.000087,+0.000400]. No Full200 run in this audit.']
    for path in [ROOT/'submission.json',ROOT/'runtime.json']:
        if path.exists():lines+=['',path.name+': '+path.read_text()]
    (ROOT/'report.md').write_text('\n'.join(lines)+'\n')


if __name__=='__main__': main()
