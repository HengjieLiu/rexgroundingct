#!/usr/bin/env python
"""Audit a production hard-negative spatial-empty ReX sampler."""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from collections import Counter, OrderedDict, defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset


REX_ROOT = Path(__file__).resolve().parents[1]
if str(REX_ROOT) not in sys.path:
    sys.path.insert(0, str(REX_ROOT))

from scripts.train_voxtell_rex_full_nnunet_aug import (  # noqa: E402
    RexPreprocessedSampler,
    build_case_records,
    load_manifest,
)


INSTANCE_TYPES = (
    "positive_foreground",
    "hard_semantic_negative",
    "same_prompt_crop_empty",
    "cross_case_real_finding_negative",
)

MODE_NUM_ITEMS = {
    "smoke": 50,
    "fast": 500,
    "reliable": 1000,
}


class MaskOnlyAuditSampler(RexPreprocessedSampler):
    """Use production sampling while avoiding CT decompression during the audit."""

    def _load_case(self, case: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
        key = f"{case['split']}/{case['case']}"
        if key in self.cache:
            value = self.cache.pop(key)
            self.cache[key] = value
            return value
        with np.load(self._cache_path(case), allow_pickle=False) as data:
            masks = data["masks"].astype(np.uint8, copy=False)
        if masks.shape[0] != len(case["findings"]):
            raise ValueError(f"{case['case']}: cache mask channels do not match metadata findings")
        image = np.zeros(masks.shape[1:], dtype=np.uint8)
        while len(self.cache) >= self.cache_size:
            self.cache.popitem(last=False)
        self.cache[key] = (image, masks)
        return image, masks


class AuditDataset(Dataset):
    def __init__(self, sampler: RexPreprocessedSampler, num_items: int) -> None:
        self.sampler = sampler
        self.num_items = num_items

    def __len__(self) -> int:
        return self.num_items

    def __getitem__(self, _: int):
        return self.sampler.sample()


class MetadataOnlyAuditDataset(AuditDataset):
    """Run the production sampler but only transfer compact metadata to the parent."""

    def __getitem__(self, index: int):
        _, _, _, _, metadata = super().__getitem__(index)
        return metadata


def seed_audit_worker(worker_id: int) -> None:
    del worker_id
    worker_seed = torch.initial_seed() % (2**32)
    random.seed(worker_seed)
    np.random.seed(worker_seed)


def identity_collate(item):
    return item


def collate_one(batch):
    images, embeddings, masks, weights, metadata = zip(*batch)
    return (
        torch.stack(images),
        torch.stack(embeddings),
        torch.stack(masks),
        torch.stack(weights),
        list(metadata),
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--preprocessed-dir",
        type=Path,
        default=REX_ROOT / "data/rex_voxtell_preprocessed_v1",
    )
    parser.add_argument("--split", default="train")
    parser.add_argument(
        "--sampler-mode",
        choices=("hard_negative_spatial_empty", "hard_negative_spatial_empty_safe"),
        default="hard_negative_spatial_empty",
    )
    parser.add_argument("--mode", choices=tuple(MODE_NUM_ITEMS), default="fast")
    parser.add_argument(
        "--num-items",
        "--batches",
        dest="num_items",
        type=int,
        default=None,
        help="Number of sampled items; overrides the selected mode (default: fast=500).",
    )
    parser.add_argument(
        "--num-workers",
        type=int,
        default=0,
        help="DataLoader workers used to generate audit metadata.",
    )
    parser.add_argument("--cache-size", type=int, default=8)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--patch-size", type=int, nargs=3, default=(192, 192, 192))
    parser.add_argument("--max-crop-attempts", type=int, default=50)
    parser.add_argument("--max-sample-attempts", type=int, default=50)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REX_ROOT / "outputs/sampler_audits/hard_negative_spatial_empty",
    )
    return parser.parse_args()


def voxel_stats(values: list[int]) -> dict[str, float | int | None]:
    if not values:
        return {"count": 0, "min": None, "median": None, "mean": None, "p95": None, "max": None}
    arr = np.asarray(values, dtype=np.float64)
    return {
        "count": int(len(values)),
        "min": int(arr.min()),
        "median": float(np.median(arr)),
        "mean": float(arr.mean()),
        "p95": float(np.quantile(arr, 0.95)),
        "max": int(arr.max()),
    }


def make_sampler(args: argparse.Namespace) -> tuple[MaskOnlyAuditSampler, dict[tuple[str, int], dict[str, Any]]]:
    cases = build_case_records(load_manifest(args.preprocessed_dir), args.split, None)
    finding_lookup = {
        (finding["case"], int(finding["finding_idx"])): finding
        for case in cases
        for finding in case["findings"]
    }
    dummy_embedding = torch.zeros(1, dtype=torch.float32)
    embedding_map = {
        (finding["split"], finding["case"], int(finding["finding_idx"])): dummy_embedding
        for finding in finding_lookup.values()
    }
    sampler = MaskOnlyAuditSampler(
        preprocessed_dir=args.preprocessed_dir,
        cases=cases,
        embedding_map=embedding_map,
        patch_size=tuple(args.patch_size),
        positive_prompts=2,
        negative_prompts=1,
        positive_loss_weight=1.0,
        negative_loss_weight=1.0,
        foreground_prob=0.85,
        require_positive_crop=True,
        min_positive_voxels=1,
        max_crop_attempts=args.max_crop_attempts,
        max_sample_attempts=args.max_sample_attempts,
        cache_size=args.cache_size,
        augmenter=None,
        hard_negative_sampler=False,
        hard_negative_match="category_then_keyword",
        hard_negative_exclude_identical_prompt=True,
        sampler_mode=args.sampler_mode,
        anchor_positive_prob=0.85,
        same_case_negative_prob=0.15,
        shuffle_prompt_order=True,
        cross_case_negative_requires_foreground=True,
        spatial_empty_foreground_prob=(
            0.85 if args.sampler_mode == "hard_negative_spatial_empty_safe" else 0.70
        ),
        spatial_empty_around_other_prob=0.70,
        spatial_empty_near_anchor_prob=0.20,
        spatial_empty_far_anchor_prob=0.10,
        spatial_empty_hard_negative_prob=0.50,
    )
    return sampler, finding_lookup


def dataloader_smoke(sampler: RexPreprocessedSampler, patch_size: tuple[int, int, int]) -> dict[str, Any]:
    loader = DataLoader(
        AuditDataset(sampler, 1),
        batch_size=1,
        num_workers=0,
        collate_fn=collate_one,
    )
    image, embeddings, masks, weights, metadata = next(iter(loader))
    expected_image = (1, 1, *patch_size)
    prompt_count = int(masks.shape[1])
    expected_masks = (1, prompt_count, *patch_size)
    if tuple(image.shape) != expected_image:
        raise AssertionError(f"DataLoader image shape {tuple(image.shape)} != {expected_image}")
    if tuple(masks.shape) != expected_masks:
        raise AssertionError(f"DataLoader masks shape {tuple(masks.shape)} != {expected_masks}")
    variable_prompt_modes = {"anchor85_hardneg70_2b2c_focus"}
    if prompt_count not in (
        {2, 3}
        if sampler.sampler_mode.endswith("_safe") or sampler.sampler_mode in variable_prompt_modes
        else {3}
    ):
        raise AssertionError(f"Unexpected prompt count for {sampler.sampler_mode}: {prompt_count}")
    if tuple(embeddings.shape[:3]) != (1, prompt_count, 1):
        raise AssertionError(
            f"DataLoader embedding prefix {tuple(embeddings.shape)} != [1,{prompt_count},1,D]"
        )
    if tuple(weights.shape) != (1, prompt_count):
        raise AssertionError(
            f"DataLoader weights shape {tuple(weights.shape)} != (1,{prompt_count})"
        )
    if len(metadata) != 1 or len(metadata[0].get("prompt_instances", [])) != prompt_count:
        raise AssertionError("DataLoader metadata prompt count does not match tensors")
    return {
        "passed": True,
        "image_shape": list(image.shape),
        "embedding_shape": list(embeddings.shape),
        "mask_shape": list(masks.shape),
        "weight_shape": list(weights.shape),
    }


def audit_loader(
    sampler: RexPreprocessedSampler,
    num_items: int,
    num_workers: int,
    seed: int,
):
    generator = torch.Generator()
    generator.manual_seed(seed)
    kwargs: dict[str, Any] = {}
    if num_workers > 0:
        kwargs.update(persistent_workers=True, prefetch_factor=1)
    return DataLoader(
        MetadataOnlyAuditDataset(sampler, num_items),
        batch_size=None,
        num_workers=num_workers,
        collate_fn=identity_collate,
        worker_init_fn=seed_audit_worker if num_workers > 0 else None,
        generator=generator,
        **kwargs,
    )


def main() -> int:
    args = parse_args()
    args.num_items = MODE_NUM_ITEMS[args.mode] if args.num_items is None else args.num_items
    if args.num_items < 1:
        raise ValueError("--num-items must be positive")
    if args.num_workers < 0:
        raise ValueError("--num-workers cannot be negative")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    sampler, finding_lookup = make_sampler(args)
    smoke = dataloader_smoke(sampler, tuple(args.patch_size))
    loader = audit_loader(sampler, args.num_items, args.num_workers, args.seed)

    branch_counts: Counter[str] = Counter()
    type_counts: Counter[str] = Counter()
    position_counts: dict[str, Counter[int]] = defaultdict(Counter)
    hard_match_counts: Counter[str] = Counter()
    crop_source_requested: Counter[str] = Counter()
    crop_source_used: Counter[str] = Counter()
    fallback_counts: Counter[str] = Counter()
    violations: Counter[str] = Counter()
    target_voxels: dict[str, list[int]] = defaultdict(list)
    rows: list[dict[str, Any]] = []
    all_empty_crops = 0
    same_prompt_branches = 0
    same_prompt_with_positive_b = 0
    missing_second_positive_fallbacks = 0
    missing_b_fallbacks = 0
    cross_case_valid = 0
    cross_case_total = 0

    for batch_idx, meta in enumerate(loader):
        branch = meta.get("branch_type")
        branch_counts[branch] += 1
        instances = meta.get("prompt_instances", [])
        valid_prompt_counts = {2, 3} if args.sampler_mode.endswith("_safe") else {3}
        if len(instances) not in valid_prompt_counts:
            violations["unexpected_prompt_count"] += 1
            continue
        missing_second_positive_fallbacks += int(meta.get("safe_missing_second_positive_fallback_count", 0))
        missing_b_fallbacks += int(meta.get("safe_missing_b_fallback_count", 0))
        crop_counts = [int(v) for v in meta["target_voxels"]]
        if not any(v > 0 for v in crop_counts):
            all_empty_crops += 1
        if branch == "same_prompt_empty":
            same_prompt_branches += 1
            if meta.get("same_prompt_empty_positive_b_included"):
                same_prompt_with_positive_b += 1
            crop_source_requested[meta.get("same_prompt_empty_crop_source_requested", "missing")] += 1
            crop_source_used[meta.get("same_prompt_empty_crop_source_used", "missing")] += 1
            for reason in meta.get("same_prompt_empty_fallback_reasons", []):
                fallback_counts[reason] += 1

        anchor_id = int(instances[0]["anchor_finding_id"])
        anchor_record = finding_lookup.get((meta["case"], anchor_id))
        for position, instance in enumerate(instances):
            instance_type = instance.get("prompt_instance_type", "missing")
            type_counts[instance_type] += 1
            position_counts[instance_type][position] += 1
            voxels = int(instance["target_voxel_count"])
            target_voxels[instance_type].append(voxels)
            source_case = instance["prompt_source_case_id"]
            finding_id = int(instance["prompt_finding_id"])
            source_record = finding_lookup.get((source_case, finding_id))
            source_foreground = None if source_record is None else source_record.get("source_foreground_voxels")
            prompt_unchanged = source_record is not None and source_record["prompt"] == instance["prompt_text"]

            if instance_type not in INSTANCE_TYPES:
                violations["unexpected_prompt_instance_type"] += 1
            if not prompt_unchanged:
                violations[f"{instance_type}:prompt_not_source_record"] += 1
            if source_foreground is None or int(source_foreground) <= 0:
                violations[f"{instance_type}:source_finding_not_foreground"] += 1
            if instance_type == "positive_foreground" and voxels <= 0:
                violations["positive_foreground:empty_target"] += 1
            if instance_type == "same_prompt_crop_empty":
                if voxels != 0:
                    violations["same_prompt_crop_empty:nonempty_target"] += 1
                if source_case != meta["case"] or finding_id != anchor_id:
                    violations["same_prompt_crop_empty:identity_changed"] += 1
                if anchor_record is None or instance["prompt_text"] != anchor_record["prompt"]:
                    violations["same_prompt_crop_empty:prompt_changed"] += 1
            if instance_type == "hard_semantic_negative":
                if voxels != 0:
                    violations["hard_semantic_negative:nonempty_target"] += 1
                reason = instance.get("hard_negative_match_reason") or "missing"
                hard_match_counts[reason] += 1
                if reason not in {"same_category", "keyword_match", "fallback"}:
                    violations["hard_semantic_negative:invalid_match_reason"] += 1
                if anchor_record is not None and instance["prompt_text"] == anchor_record["prompt"]:
                    violations["hard_semantic_negative:identical_anchor_prompt"] += 1
            if instance_type == "cross_case_real_finding_negative":
                cross_case_total += 1
                valid = source_case != meta["case"] and source_foreground is not None and int(source_foreground) > 0
                cross_case_valid += int(valid)
                if source_case == meta["case"]:
                    violations["cross_case_negative:same_source_case"] += 1
                if voxels != 0:
                    violations["cross_case_negative:nonempty_target"] += 1

            rows.append(
                {
                    "batch_index": batch_idx,
                    "prompt_position": position,
                    "branch_type": branch,
                    "prompt_instance_type": instance_type,
                    "case_id": meta["case"],
                    "anchor_finding_id": anchor_id,
                    "prompt_source_case_id": source_case,
                    "prompt_finding_id": finding_id,
                    "prompt_text": instance["prompt_text"],
                    "target_voxel_count": voxels,
                    "is_empty_target": int(voxels == 0),
                    "source_foreground_voxels": source_foreground,
                    "negative_source_case_id": instance.get("negative_source_case_id"),
                    "hard_negative_match_reason": instance.get("hard_negative_match_reason"),
                    "crop_start": ";".join(map(str, instance["crop_start"])),
                    "crop_end": ";".join(map(str, instance["crop_end"])),
                    "loss_group_weight_metadata_only": instance.get("loss_group_weight_metadata_only"),
                }
            )

    total_instances = sum(type_counts.values())
    expected_branch = (
        {"foreground_present": 0.85, "same_prompt_empty": 0.15}
        if args.sampler_mode.endswith("_safe")
        else {"foreground_present": 0.70, "same_prompt_empty": 0.30}
    )
    summary = {
        "sampler_mode": sampler.sampler_mode,
        "mode": args.mode,
        "num_workers": args.num_workers,
        "seed": args.seed,
        "requested_items": args.num_items,
        "audited_items": sum(branch_counts.values()),
        "requested_batches": args.num_items,
        "audited_batches": sum(branch_counts.values()),
        "prompt_instances": total_instances,
        "dataloader_smoke": smoke,
        "branch_distribution": {
            branch: {
                "count": branch_counts[branch],
                "fraction": branch_counts[branch] / max(1, args.num_items),
                "intended_fraction": expected_branch.get(branch),
            }
            for branch in sorted(branch_counts)
        },
        "prompt_instance_distribution": {
            instance_type: {
                "count": type_counts[instance_type],
                "fraction": type_counts[instance_type] / max(1, total_instances),
                "target_voxels": voxel_stats(target_voxels[instance_type]),
                "position_counts": {str(k): v for k, v in sorted(position_counts[instance_type].items())},
            }
            for instance_type in INSTANCE_TYPES
        },
        "all_empty_crops": {
            "count": all_empty_crops,
            "fraction": all_empty_crops / max(1, args.num_items),
        },
        "same_prompt_empty_positive_b": {
            "count": same_prompt_with_positive_b,
            "branches": same_prompt_branches,
            "fraction": same_prompt_with_positive_b / max(1, same_prompt_branches),
        },
        "same_prompt_empty_crop_source_requested": dict(sorted(crop_source_requested.items())),
        "same_prompt_empty_crop_source_used": dict(sorted(crop_source_used.items())),
        "fallback_counts": dict(sorted(fallback_counts.items())),
        "safe_fallback_counts": {
            "missing_second_positive": missing_second_positive_fallbacks,
            "missing_b_positive_to_foreground_branch": missing_b_fallbacks,
        },
        "hard_negative_matching": dict(sorted(hard_match_counts.items())),
        "cross_case_negative_validity": {
            "valid": cross_case_valid,
            "total": cross_case_total,
            "fraction": cross_case_valid / max(1, cross_case_total),
        },
        "violations": dict(sorted(violations.items())),
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (args.output_dir / "prompt_instances.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else [])
        if rows:
            writer.writeheader()
            writer.writerows(rows)
    report_lines = [
        f"{args.sampler_mode} sampler audit",
        f"mode: {args.mode}",
        f"items: {args.num_items}",
        f"num_workers: {args.num_workers}",
        "",
        "1. prompt_instance_type counts and percentages",
    ]
    report_lines.extend(
        f"- {name}: {type_counts[name]} ({type_counts[name] / max(1, total_instances):.4%})"
        for name in INSTANCE_TYPES
    )
    report_lines.extend(
        [
            "",
            "2. branch_type counts",
            *(
                f"- {name}: {count} ({count / max(1, args.num_items):.4%})"
                for name, count in sorted(branch_counts.items())
            ),
            "",
            "3. target_voxel_count stats by type",
            *(f"- {name}: {voxel_stats(target_voxels[name])}" for name in INSTANCE_TYPES),
            "",
            "4. all-empty crop fraction",
            f"- {all_empty_crops}/{args.num_items} ({all_empty_crops / max(1, args.num_items):.4%})",
            "",
            "5. prompt position distribution",
            *(
                f"- {name}: {dict(sorted(position_counts[name].items()))}"
                for name in INSTANCE_TYPES
            ),
            "",
            "6. hard negative match reason stats",
            f"- {dict(sorted(hard_match_counts.items()))}",
            "",
            "7. cross-case negative validity",
            f"- {cross_case_valid}/{cross_case_total} ({cross_case_valid / max(1, cross_case_total):.4%})",
            "",
            "8. safe fallback counts",
            f"- missing_second_positive: {missing_second_positive_fallbacks}",
            f"- missing_b_positive_to_foreground_branch: {missing_b_fallbacks}",
        ]
    )
    (args.output_dir / "report.txt").write_text("\n".join(report_lines) + "\n")
    print("\n".join(report_lines))
    return 0 if not violations else 2


if __name__ == "__main__":
    raise SystemExit(main())
