#!/usr/bin/env python
"""Audit ReX category metadata and prompt embedding path for category prompts."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import torch


REX_ROOT = Path(__file__).resolve().parents[1]
VOXTELL_ROOT = REX_ROOT / "VoxTell"
if str(VOXTELL_ROOT) not in sys.path:
    sys.path.insert(0, str(VOXTELL_ROOT))

from voxtell.utils.rex_category_prompts import CATEGORY_NAME_BY_CODE, build_finding_prompt  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rex-json", type=Path, default=REX_ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--preprocessed-dir", type=Path, default=REX_ROOT / "data/rex_voxtell_preprocessed_v1")
    parser.add_argument(
        "--baseline-embedding-cache",
        type=Path,
        default=REX_ROOT
        / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt",
    )
    parser.add_argument("--baseline-script", type=Path, default=REX_ROOT / "scripts/train_anchor85_hardneg70_no_topk.sh")
    parser.add_argument("--baseline-output", type=Path, default=REX_ROOT / "outputs/anchor85_hardneg70_no_topk")
    parser.add_argument(
        "--output",
        type=Path,
        default=REX_ROOT / "outputs/category_prompt_experiment/category_prompt_audit.md",
    )
    return parser.parse_args()


def load_rex_sources(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    records = []
    for split, entries in data.items():
        if not isinstance(entries, list):
            continue
        for entry in entries:
            findings = entry.get("findings") or {}
            categories = entry.get("categories") or {}
            for idx, prompt in sorted(findings.items(), key=lambda item: int(item[0])):
                records.append(
                    {
                        "split": split,
                        "case": entry["name"],
                        "finding_idx": int(idx),
                        "prompt": prompt,
                        "category": categories.get(str(idx)),
                    }
                )
    return records


def load_manifest_summary(preprocessed_dir: Path) -> dict[str, Any]:
    manifest = preprocessed_dir / "manifest.jsonl"
    if not manifest.exists():
        return {"path": str(manifest), "exists": False}
    rows = [json.loads(line) for line in manifest.read_text().splitlines() if line.strip()]
    category_counts = Counter()
    missing_categories = 0
    for row in rows:
        categories = row.get("categories") or {}
        for channel, finding_idx in enumerate(row.get("finding_indices") or []):
            category = categories.get(str(finding_idx), categories.get(str(channel)))
            if category is None:
                missing_categories += 1
            else:
                category_counts[str(category)] += 1
    return {
        "path": str(manifest),
        "exists": True,
        "rows": len(rows),
        "category_counts": dict(sorted(category_counts.items())),
        "missing_categories": missing_categories,
    }


def load_cache_summary(path: Path) -> dict[str, Any]:
    cache = torch.load(path, map_location="cpu", weights_only=False)
    records = cache.get("records") or []
    embeddings = cache.get("embeddings")
    first_record = records[0] if records else {}
    duplicate_count = 0
    seen = set()
    for record in records:
        key = (record.get("split"), record.get("case"), int(record.get("finding_idx")))
        duplicate_count += int(key in seen)
        seen.add(key)
    return {
        "path": str(path),
        "metadata": cache.get("metadata", {}),
        "embedding_shape": list(embeddings.shape) if hasattr(embeddings, "shape") else None,
        "embedding_dtype": str(embeddings.dtype) if hasattr(embeddings, "dtype") else None,
        "record_count": len(records),
        "first_record": first_record,
        "key_format": "(split, case, finding_idx)",
        "duplicate_keys": duplicate_count,
    }


def main() -> int:
    args = parse_args()
    sources = load_rex_sources(args.rex_json)
    category_counts = Counter(str(item["category"]) for item in sources if item.get("category"))
    missing_category = [item for item in sources if not item.get("category")]
    unknown_names = sorted(code for code in category_counts if code not in CATEGORY_NAME_BY_CODE)
    examples: dict[str, list[dict[str, str]]] = defaultdict(list)
    for item in sources:
        code = item.get("category")
        if not code or len(examples[str(code)]) >= 5:
            continue
        name = CATEGORY_NAME_BY_CODE.get(str(code), "")
        examples[str(code)].append(
            {
                "case": item["case"],
                "finding_idx": str(item["finding_idx"]),
                "original": item["prompt"],
                "category_prefix": build_finding_prompt(item["prompt"], str(code), name, "category_prefix")
                if name
                else "",
            }
        )

    cache_summary = load_cache_summary(args.baseline_embedding_cache)
    manifest_summary = load_manifest_summary(args.preprocessed_dir)
    args.output.parent.mkdir(parents=True, exist_ok=True)

    lines = [
        "# Category Prompt Experiment Audit",
        "",
        "## Category Metadata",
        "",
        f"- Source JSON: `{args.rex_json}`",
        "- ReX categories are stored per finding under each entry's `categories` dictionary.",
        "- The free-text prompt is stored under each entry's `findings` dictionary.",
        "- In the training code, preprocessed records are built by `build_case_records()` in "
        "`scripts/train_voxtell_rex_full_nnunet_aug.py`; `prompt = row[\"prompts\"][channel]` and "
        "`category = row[\"categories\"][finding_idx]` are copied into each finding record.",
        f"- Total findings across JSON splits: `{len(sources)}`",
        f"- Missing category values: `{len(missing_category)}`",
        f"- Category codes without local canonical names: `{unknown_names}`",
        "",
        "## Category Mapping",
        "",
        "| code | canonical category name | n_findings |",
        "|---|---:|---:|",
    ]
    for code in sorted(CATEGORY_NAME_BY_CODE):
        lines.append(f"| {code} | {CATEGORY_NAME_BY_CODE[code]} | {category_counts.get(code, 0)} |")
    lines.extend(
        [
            "",
            "Mapping source: the ReXGroundingCT hierarchical finding tree for lung/airway/pleural categories "
            "reported in Appendix D of the dataset paper. The local dataset JSON stores only the category codes.",
            "",
            "## Embedding Cache",
            "",
            f"- Baseline cache: `{cache_summary['path']}`",
            f"- Shape: `{cache_summary['embedding_shape']}`",
            f"- dtype: `{cache_summary['embedding_dtype']}`",
            f"- Records: `{cache_summary['record_count']}`",
            f"- Key format used by loader: `{cache_summary['key_format']}`",
            f"- Duplicate keys: `{cache_summary['duplicate_keys']}`",
            f"- First record: `{cache_summary['first_record']}`",
            "- Training loads precomputed embeddings with `load_embedding_map()`; embeddings are not computed online "
            "during training.",
            "- Full-volume inference computes prompt embeddings online through `VoxTellPredictor.embed_text_prompts()`.",
            "",
            "## Preprocessed Manifest",
            "",
            f"- Manifest: `{manifest_summary['path']}`",
            f"- Exists: `{manifest_summary['exists']}`",
            f"- Rows: `{manifest_summary.get('rows')}`",
            f"- Missing categories in manifest findings: `{manifest_summary.get('missing_categories')}`",
            "",
            "## Baseline Configuration",
            "",
            f"- Baseline launch script: `{args.baseline_script}`",
            f"- Baseline output inspected: `{args.baseline_output}`",
            "- The most relevant controlled base is the existing `anchor85_hardneg70` setup; this experiment keeps "
            "that sampler/loss/LR/checkpoint fixed and changes only the prompt embedding cache plus inference prompt mode.",
            "",
            "## Is Category Already In The Prompt?",
            "",
            "- The original finding text often implies the disease family, but it does not explicitly contain ReX category "
            "codes such as `1a`/`2d` nor the full hierarchical category label. This experiment tests whether adding "
            "that explicit coarse prior helps.",
            "",
            "## Examples",
            "",
        ]
    )
    for code in sorted(examples):
        lines.append(f"### {code}: {CATEGORY_NAME_BY_CODE.get(code, 'unknown')}")
        for item in examples[code]:
            lines.append(f"- `{item['case']}` finding `{item['finding_idx']}`")
            lines.append(f"  - original: {item['original']}")
            lines.append(f"  - category_prefix: {item['category_prefix']}")
        lines.append("")
    args.output.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    print(f"Wrote {args.output}")
    return 0 if not missing_category and not unknown_names else 1


if __name__ == "__main__":
    raise SystemExit(main())
