#!/usr/bin/env python3
"""Offline component-verifier feasibility analysis for category-2d S3 priors."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import pandas as pd
from scipy import ndimage
from scipy.spatial import cKDTree
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
STRUCTURE = ndimage.generate_binary_structure(3, 3)
PRIOR_SCORES = ["s_max", "s_top1", "s_top5", "s_mean", "s_mass_density"]
KEYS = ["file", "finding_idx"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--prior-map-dir", type=Path, required=True)
    parser.add_argument("--baseline-seg-dir", type=Path, required=True)
    parser.add_argument("--s3-seg-dir", type=Path, required=True)
    parser.add_argument("--baseline-metrics", type=Path, required=True)
    parser.add_argument("--s3-metrics", type=Path, required=True)
    parser.add_argument("--prior-head-checkpoint", type=Path, required=True)
    parser.add_argument("--parent-s3-checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--gt-dir", type=Path, default=ROOT / "data/segmentations")
    return parser.parse_args()


def write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, indent=2, default=str) + "\n")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def bbox(mask: np.ndarray) -> list[list[int]] | None:
    coords = np.where(mask)
    if not len(coords[0]):
        return None
    return [[int(axis.min()), int(axis.max()) + 1] for axis in coords]


def top_mean(values: np.ndarray, fraction: float) -> float:
    count = max(1, int(math.ceil(values.size * fraction)))
    if count >= values.size:
        return float(values.mean())
    return float(np.partition(values, values.size - count)[-count:].mean())


def flatten_manifest(path: Path) -> list[dict[str, Any]]:
    manifest = json.loads(path.read_text())
    rows = []
    for case in manifest["val"]:
        for key, prompt in sorted(case["findings"].items(), key=lambda item: int(item[0])):
            rows.append({
                "file": case["name"],
                "finding_idx": int(key),
                "prompt": prompt,
                "pixels": int(case.get("pixels", {}).get(key, 0)),
            })
    if len(rows) != 132 or len({(r["file"], r["finding_idx"]) for r in rows}) != 132:
        raise RuntimeError(f"Expected 132 unique full-2d findings, found {len(rows)}")
    return rows


def load_reference_metrics(path: Path, entries: list[dict]) -> pd.DataFrame:
    wanted = {(row["file"], row["finding_idx"]) for row in entries}
    frame = pd.read_csv(path)
    frame = frame[[tuple(row) in wanted for row in frame[KEYS].itertuples(index=False, name=None)]].copy()
    if len(frame) != 132 or frame.duplicated(KEYS).any():
        raise RuntimeError(f"Reference metric mapping mismatch: {path}")
    return frame.set_index(KEYS).sort_index()


def component_rows(
    source: str,
    item: dict[str, Any],
    prediction: np.ndarray,
    target: np.ndarray,
    prior: np.ndarray,
    spacing: np.ndarray,
    reference: pd.Series,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    labels, count = ndimage.label(prediction, structure=STRUCTURE)
    objects = ndimage.find_objects(labels)
    gt_labels, gt_count = ndimage.label(target, structure=STRUCTURE)
    del gt_labels
    gt_voxels = int(target.sum())
    pred_voxels = int(prediction.sum())
    tp = int((prediction & target).sum())
    fp = pred_voxels - tp
    fn = gt_voxels - tp
    dice = 2.0 * tp / max(pred_voxels + gt_voxels, 1)
    if abs(dice - float(reference.global_dice)) > 2e-6 or bool(dice >= 0.1) != bool(reference.global_hit):
        raise RuntimeError(
            f"{source} metric reproduction failed for {item['file']} finding {item['finding_idx']}: "
            f"computed={dice}, saved={reference.global_dice}"
        )
    peak = np.asarray(np.unravel_index(int(prior.argmax()), prior.shape), dtype=np.float64)
    gt_coordinates = np.argwhere(target).astype(np.float64) * spacing
    gt_tree = cKDTree(gt_coordinates) if len(gt_coordinates) else None
    rows = []
    for component_id, obj in enumerate(objects, start=1):
        if obj is None:
            continue
        local = labels[obj] == component_id
        voxels = int(local.sum())
        values = prior[obj][local].astype(np.float32, copy=False)
        overlap = int(target[obj][local].sum())
        starts = np.asarray([axis.start for axis in obj], dtype=np.int64)
        local_coords = np.argwhere(local)
        centroid = local_coords.mean(axis=0) + starts
        scaled = (local_coords + starts - peak) * spacing
        peak_distance = float(np.sqrt(np.square(scaled).sum(axis=1).min()))
        component_bbox = [[int(axis.start), int(axis.stop)] for axis in obj]
        if overlap > 0:
            nearest_gt = 0.0
        elif gt_tree is not None and voxels:
            nearest_gt = float(gt_tree.query((local_coords + starts) * spacing, k=1, workers=1)[0].min())
        else:
            nearest_gt = float("nan")
        common = {
            "source": source,
            **item,
            "small_2d": item["pixels"] < 1000,
            "gt_component_count": int(gt_count),
            "original_hit": bool(reference.global_hit),
            "original_dice": float(reference.global_dice),
            "original_fp_gt": float(reference.fp_voxels / max(reference.gt_voxels, 1)),
            "component_id": component_id,
            "component_voxels": voxels,
            "physical_volume_mm3": float(voxels * np.prod(spacing)),
            "bbox_xyz": json.dumps(component_bbox),
            "centroid_xyz": json.dumps([float(v) for v in centroid]),
            "gt_overlap_positive": overlap > 0,
            "overlap_dice_with_gt": float(2 * overlap / max(voxels + gt_voxels, 1)),
            "overlap_voxels": overlap,
            "distance_to_nearest_gt_mm": nearest_gt,
            "seg_probability_available": False,
            "seg_max": 1.0,
            "seg_top1": 1.0,
            "seg_top5": 1.0,
            "seg_mean": 1.0,
            "seg_log_volume": float(np.log1p(voxels)),
            "s_max": float(values.max()),
            "s_top1": top_mean(values, 0.01),
            "s_top5": top_mean(values, 0.05),
            "s_mean": float(values.mean()),
            "s_mass": float(values.sum(dtype=np.float64)),
            "s_mass_density": float(values.sum(dtype=np.float64) / voxels),
            "prior_peak_distance_mm": peak_distance,
        }
        rows.append(common)
    finding = {
        "source": source,
        **item,
        "small_2d": item["pixels"] < 1000,
        "gt_voxels": gt_voxels,
        "gt_component_count": int(gt_count),
        "original_component_count": int(count),
        "original_dice": dice,
        "original_hit": dice >= 0.1,
        "original_tp": tp,
        "original_fp": fp,
        "original_fn": fn,
        "original_pred_voxels": pred_voxels,
        "original_fp_gt": fp / max(gt_voxels, 1),
        "rescuable": bool(tp > 0),
    }
    return rows, finding


def ranking_metrics(frame: pd.DataFrame, score: str, finding_count: int) -> dict[str, Any]:
    labels = frame.gt_overlap_positive.astype(int).to_numpy()
    values = frame[score].astype(float).to_numpy()
    prevalence = float(labels.mean()) if len(labels) else float("nan")
    if len(np.unique(labels)) == 2:
        auroc = float(roc_auc_score(labels, values))
        auprc = float(average_precision_score(labels, values))
    else:
        auroc = auprc = float("nan")
    first_ranks = []
    top = {1: 0, 2: 0, 3: 0}
    top_positive = 0
    component_findings = 0
    rescuable = 0
    for _, group in frame.groupby(KEYS, sort=False):
        component_findings += 1
        ranked = group.sort_values([score, "component_id"], ascending=[False, True])
        positive = ranked.gt_overlap_positive.to_numpy(bool)
        top_positive += int(bool(positive[0]))
        if positive.any():
            rescuable += 1
            rank = int(np.flatnonzero(positive)[0]) + 1
            first_ranks.append(rank)
            for k in top:
                top[k] += int(rank <= k)
    return {
        "components": int(len(frame)),
        "positive_components": int(labels.sum()),
        "positive_prevalence": prevalence,
        "component_AUROC": auroc,
        "component_AUPRC": auprc,
        "AUPRC_over_prevalence": auprc / max(prevalence, 1e-12) if np.isfinite(auprc) else float("nan"),
        "findings_with_components": component_findings,
        "rescuable_findings": rescuable,
        "precision_at_top_component": top_positive / max(component_findings, 1),
        "top1_recall_rescuable": top[1] / max(rescuable, 1),
        "top2_recall_rescuable": top[2] / max(rescuable, 1),
        "top3_recall_rescuable": top[3] / max(rescuable, 1),
        "top1_recall_all_findings": top[1] / finding_count,
        "top2_recall_all_findings": top[2] / finding_count,
        "top3_recall_all_findings": top[3] / finding_count,
        "MRR_first_GT_overlap": float(np.mean([1 / rank for rank in first_ranks])) if first_ranks else 0.0,
        "mean_rank_first_GT_overlap": float(np.mean(first_ranks)) if first_ranks else float("nan"),
    }


def selected_metrics(components: pd.DataFrame, finding: pd.Series, selected: np.ndarray) -> dict[str, Any]:
    kept = components.loc[selected]
    pred = int(kept.component_voxels.sum()) if len(kept) else 0
    tp = int(kept.overlap_voxels.sum()) if len(kept) else 0
    gt = int(finding.gt_voxels)
    fp = pred - tp
    fn = gt - tp
    dice = 2 * tp / max(pred + gt, 1)
    return {
        "dice": dice,
        "hit": dice >= 0.1,
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "pred_voxels": pred,
        "gt_voxels": gt,
        "precision": tp / max(pred, 1),
        "recall": tp / max(gt, 1),
        "FP_GT": fp / max(gt, 1),
        "FN_GT": fn / max(gt, 1),
        "predicted_GT_volume_ratio": pred / max(gt, 1),
        "kept_components": int(selected.sum()),
    }


def build_strategies(components: pd.DataFrame, findings: pd.DataFrame) -> pd.DataFrame:
    components = components.copy()
    for column in ["seg_log_volume", *PRIOR_SCORES]:
        std = float(components[column].std())
        components[f"z_{column}"] = (components[column] - components[column].mean()) / (std if std > 0 else 1.0)
    rows = []
    for _, finding in findings.iterrows():
        group = components[(components.file == finding.file) & (components.finding_idx == finding.finding_idx)].copy()
        specs: list[tuple[str, np.ndarray]] = [("original", np.ones(len(group), dtype=bool))]
        for score in [*PRIOR_SCORES, "seg_log_volume"]:
            order = np.argsort(-group[score].to_numpy(float), kind="stable")
            for n in (1, 2, 3, 5):
                keep = np.zeros(len(group), dtype=bool)
                keep[order[:n]] = True
                specs.append((f"top{n}_{score}", keep))
        for score in PRIOR_SCORES:
            values = group[score].to_numpy(float)
            volumes = group.component_voxels.to_numpy(float)
            for quantile in (0.05, 0.10, 0.20):
                keep = np.ones(len(group), dtype=bool)
                if len(group) > 1:
                    low = values <= np.quantile(values, quantile)
                    small = volumes <= np.median(volumes)
                    keep[low & small] = False
                    if not keep.any():
                        keep[int(np.argmax(values))] = True
                specs.append((f"prune_q{int(quantile*100):02d}_{score}", keep))
        for prior_score in PRIOR_SCORES:
            for lam in (0.25, 0.5, 1.0, 2.0):
                fusion = components.loc[group.index, "z_seg_log_volume"].to_numpy() + lam * components.loc[group.index, f"z_{prior_score}"].to_numpy()
                order = np.argsort(-fusion, kind="stable")
                for n in (1, 2, 3, 5):
                    keep = np.zeros(len(group), dtype=bool)
                    keep[order[:n]] = True
                    specs.append((f"fusion_{prior_score}_lambda{lam:g}_top{n}", keep))
        for strategy, selected in specs:
            rows.append({"source": finding.source, **{k: finding[k] for k in [*KEYS, "pixels", "small_2d"]}, "strategy": strategy, **selected_metrics(group, finding, selected)})
    return pd.DataFrame(rows)


def strategy_summary(frame: pd.DataFrame) -> pd.DataFrame:
    original = frame[frame.strategy == "original"].set_index(KEYS)
    rows = []
    for strategy, group in frame.groupby("strategy"):
        current = group.set_index(KEYS).loc[original.index]
        for stratum, mask in {
            "all_2d": np.ones(len(current), dtype=bool),
            "small_2d": current.small_2d.to_numpy(bool),
            "other_2d": ~current.small_2d.to_numpy(bool),
        }.items():
            sub = current.iloc[np.flatnonzero(mask)]
            ref = original.iloc[np.flatnonzero(mask)]
            delta = sub.dice.to_numpy() - ref.dice.to_numpy()
            rows.append({
                "strategy": strategy,
                "stratum": stratum,
                "n": len(sub),
                "mean_dice": float(sub.dice.mean()),
                "hits": int(sub.hit.sum()),
                "precision": float(sub.precision.mean()),
                "recall": float(sub.recall.mean()),
                "FP_GT": float(sub.FP_GT.mean()),
                "FN_GT": float(sub.FN_GT.mean()),
                "predicted_GT_volume_ratio": float(sub.predicted_GT_volume_ratio.mean()),
                "dice_delta": float(delta.mean()),
                "hit_delta": int(sub.hit.sum() - ref.hit.sum()),
                "improved": int((delta > 1e-12).sum()),
                "degraded": int((delta < -1e-12).sum()),
                "tied": int((np.abs(delta) <= 1e-12).sum()),
                "new_hits": int((sub.hit & ~ref.hit).sum()),
                "lost_hits": int((~sub.hit & ref.hit).sum()),
                "FP_GT_delta": float(sub.FP_GT.mean() - ref.FP_GT.mean()),
                "precision_delta": float(sub.precision.mean() - ref.precision.mean()),
                "recall_delta": float(sub.recall.mean() - ref.recall.mean()),
            })
    return pd.DataFrame(rows)


def bootstrap(candidate: pd.DataFrame, reference: pd.DataFrame, seed: int) -> dict[str, Any]:
    merged = reference.merge(candidate, on=KEYS, suffixes=("_reference", "_candidate"), validate="one_to_one")
    cases = np.asarray(sorted(merged.file.unique()))
    by_case = {case: merged[merged.file == case] for case in cases}
    rng = np.random.default_rng(seed)
    draws = np.empty(10000)
    for index in range(len(draws)):
        sample = rng.choice(cases, len(cases), replace=True)
        draws[index] = np.concatenate([(by_case[c].dice_candidate - by_case[c].dice_reference).to_numpy() for c in sample]).mean()
    return {
        "paired_dice_delta": float((merged.dice_candidate - merged.dice_reference).mean()),
        "ci_low": float(np.quantile(draws, 0.025)),
        "ci_high": float(np.quantile(draws, 0.975)),
        "p_delta_gt_0": float((draws > 0).mean()),
        "hit_delta": int(merged.hit_candidate.sum() - merged.hit_reference.sum()),
        "FP_GT_delta": float((merged.FP_GT_candidate - merged.FP_GT_reference).mean()),
        "precision_delta": float((merged.precision_candidate - merged.precision_reference).mean()),
        "recall_delta": float((merged.recall_candidate - merged.recall_reference).mean()),
        "replicates": 10000,
    }


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    entries = flatten_manifest(args.manifest)
    source_config = {
        "baseline_seg": (args.baseline_seg_dir, load_reference_metrics(args.baseline_metrics, entries)),
        "s3_seg": (args.s3_seg_dir, load_reference_metrics(args.s3_metrics, entries)),
    }
    all_components: dict[str, pd.DataFrame] = {}
    all_findings: dict[str, pd.DataFrame] = {}
    sanity = []
    for source, (seg_dir, references) in source_config.items():
        rows, findings = [], []
        for index, item in enumerate(entries):
            gt_img = nib.load(str(args.gt_dir / item["file"]))
            pred_img = nib.load(str(seg_dir / item["file"]))
            ct_img = nib.load(str(args.image_dir / item["file"]))
            # Slice the nibabel proxies before materializing. Some cases contain
            # many full-volume finding channels and loading the entire 4D array
            # would exceed the CPU job's memory request.
            target = np.asarray(np.asanyarray(gt_img.dataobj[item["finding_idx"]]) > 0)
            prediction = np.asarray(np.asanyarray(pred_img.dataobj[item["finding_idx"]]) > 0)
            map_path = args.prior_map_dir / f"{item['file'].removesuffix('.nii.gz')}_finding_{item['finding_idx']}.npz"
            with np.load(map_path, allow_pickle=False) as archive:
                prior = archive["prior"].astype(np.float32)
            if not (target.shape == prediction.shape == prior.shape == ct_img.shape):
                raise RuntimeError(f"Coordinate shape failure for {source} {item}: GT={target.shape}, pred={prediction.shape}, prior={prior.shape}, CT={ct_img.shape}")
            spacing = np.asarray(nib.affines.voxel_sizes(ct_img.affine), dtype=np.float64)
            ref = references.loc[(item["file"], item["finding_idx"])]
            component, finding = component_rows(source, item, prediction, target, prior, spacing, ref)
            rows.extend(component)
            findings.append(finding)
            if source == "baseline_seg" and len(sanity) < 8:
                peak = np.asarray(np.unravel_index(int(prior.argmax()), prior.shape))
                gt_tree = cKDTree(np.argwhere(target).astype(np.float64) * spacing)
                peak_distance = float(gt_tree.query(peak.astype(np.float64) * spacing, k=1)[0])
                sanity.append({
                    "file": item["file"], "finding_idx": item["finding_idx"],
                    "shape_xyz": list(target.shape), "spacing_xyz_mm": spacing.tolist(),
                    "GT_bbox_xyz": bbox(target), "segmentation_bbox_xyz": bbox(prediction),
                    "prior_peak_xyz": peak.tolist(), "prior_peak_to_GT_mm": peak_distance,
                    "GT_prediction_prior_CT_same_shape": True,
                    "orientation_note": "GT/pred arrays follow original CT voxel indices despite identity-like GT header; prior was explicitly restored from nnU-Net RAS grid",
                })
            del target, prediction, prior
        components = pd.DataFrame(rows)
        finding_frame = pd.DataFrame(findings)
        all_components[source] = components
        all_findings[source] = finding_frame
        base_columns = [column for column in components.columns if not column.startswith("s_") and not column.startswith("seg_") and column != "prior_peak_distance_mm"]
        components[base_columns].to_csv(args.output_dir / f"{source}_component_table.csv", index=False)
        components.to_csv(args.output_dir / f"{source}_prior_component_scores.csv", index=False)

    write_json(args.output_dir / "coordinate_sanity_check.json", {"status": "pass", "checks": sanity})

    ranking_rows, subgroup_rows = [], []
    ranking_by_source: dict[str, pd.DataFrame] = {}
    for source, components in all_components.items():
        findings = all_findings[source]
        q75 = float(findings.original_fp_gt.quantile(0.75))
        scores = [*PRIOR_SCORES, "s_mass", "prior_peak_distance_mm", "seg_mean", "seg_log_volume"]
        for score in scores:
            ranking_score = score
            working = components
            if score == "prior_peak_distance_mm":
                working = components.assign(_negative_peak_distance=-components[score])
                ranking_score = "_negative_peak_distance"
            metric = ranking_metrics(working, ranking_score, len(findings))
            ranking_rows.append({"source": source, "score": score, "subgroup": "all", **metric})
            subgroup_defs = {
                "small_2d": components.small_2d,
                "other_2d": ~components.small_2d,
                "single_GT_component": components.gt_component_count == 1,
                "multi_GT_component": components.gt_component_count > 1,
                "high_FP_burden": components.original_fp_gt >= q75,
                "original_hit": components.original_hit,
                "original_miss": ~components.original_hit,
            }
            for subgroup, mask in subgroup_defs.items():
                block = working.loc[mask]
                finding_count = int(findings[
                    (findings.small_2d if subgroup == "small_2d" else
                     ~findings.small_2d if subgroup == "other_2d" else
                     findings.gt_component_count.eq(1) if subgroup == "single_GT_component" else
                     findings.gt_component_count.gt(1) if subgroup == "multi_GT_component" else
                     findings.original_fp_gt.ge(q75) if subgroup == "high_FP_burden" else
                     findings.original_hit if subgroup == "original_hit" else ~findings.original_hit)
                ].shape[0])
                subgroup_rows.append({"source": source, "score": score, "subgroup": subgroup, **ranking_metrics(block, ranking_score, finding_count)})
        ranking_by_source[source] = pd.DataFrame([row for row in ranking_rows if row["source"] == source])
    pd.DataFrame(ranking_rows).to_csv(args.output_dir / "component_ranking_summary.csv", index=False)
    pd.DataFrame(subgroup_rows).to_csv(args.output_dir / "component_ranking_by_subgroup.csv", index=False)

    strategy_frames, summaries = {}, {}
    for source in source_config:
        per_finding = build_strategies(all_components[source], all_findings[source])
        summary = strategy_summary(per_finding)
        per_finding.to_csv(args.output_dir / f"{source}_per_finding_strategies.csv", index=False)
        summary.to_csv(args.output_dir / f"{source}_mask_strategy_summary.csv", index=False)
        strategy_frames[source] = per_finding
        summaries[source] = summary

    oracle = {}
    for source, components in all_components.items():
        findings = all_findings[source]
        rows = []
        for _, finding in findings.iterrows():
            group = components[(components.file == finding.file) & (components.finding_idx == finding.finding_idx)]
            rows.append({**{k: finding[k] for k in [*KEYS, "small_2d"]}, **selected_metrics(group, finding, group.gt_overlap_positive.to_numpy(bool))})
        frame = pd.DataFrame(rows)
        oracle[source] = {
            "findings": len(frame),
            "unmodified_mean_dice": float(findings.original_dice.mean()),
            "oracle_mean_dice": float(frame.dice.mean()),
            "oracle_hits": int(frame.hit.sum()),
            "oracle_FP_GT": float(frame.FP_GT.mean()),
            "findings_without_any_GT_overlap_component": int((~findings.rescuable).sum()),
            "miss_limitation": "component selection cannot rescue findings without a GT-overlap predicted component",
        }
    write_json(args.output_dir / "oracle_upper_bound_summary.json", oracle)

    bootstrap_rows, influence_rows = [], []
    promising_by_source = {}
    for source, summary in summaries.items():
        all_rows = summary[(summary.stratum == "all_2d") & (summary.strategy != "original")]
        small = summary[summary.stratum == "small_2d"].set_index("strategy")
        candidates = all_rows[
            (all_rows.dice_delta > 0) & (all_rows.hit_delta >= -1) &
            all_rows.strategy.map(lambda name: float(small.loc[name, "dice_delta"]) >= -0.001)
        ].sort_values("dice_delta", ascending=False).head(3)
        promising_by_source[source] = candidates.strategy.tolist()
        per = strategy_frames[source]
        reference = per[per.strategy == "original"]
        for rank, strategy in enumerate(candidates.strategy):
            candidate = per[per.strategy == strategy]
            bootstrap_rows.append({"source": source, "strategy": strategy, **bootstrap(candidate, reference, 860811 + rank)})
        if len(candidates):
            best = candidates.iloc[0].strategy
            merged = reference.merge(per[per.strategy == best], on=KEYS, suffixes=("_reference", "_candidate"), validate="one_to_one")
            for case in sorted(merged.file.unique()):
                keep = merged.file != case
                influence_rows.append({"source": source, "strategy": best, "left_out_case": case, "dice_delta": float((merged.loc[keep, "dice_candidate"] - merged.loc[keep, "dice_reference"]).mean())})
    bootstrap_columns = ["source", "strategy", "paired_dice_delta", "ci_low", "ci_high", "p_delta_gt_0", "hit_delta", "FP_GT_delta", "precision_delta", "recall_delta", "replicates"]
    pd.DataFrame(bootstrap_rows, columns=bootstrap_columns).to_csv(args.output_dir / "bootstrap_results.csv", index=False)
    pd.DataFrame(influence_rows, columns=["source", "strategy", "left_out_case", "dice_delta"]).to_csv(args.output_dir / "leave_one_case_out.csv", index=False)

    ranking_signal = {}
    for source, table in ranking_by_source.items():
        prior_best = table[table.score.isin(PRIOR_SCORES)].sort_values("component_AUPRC", ascending=False).iloc[0]
        volume = table[table.score == "seg_log_volume"].iloc[0]
        ranking_signal[source] = {
            "best_prior_score": prior_best.score,
            "best_prior_component_AUPRC": float(prior_best.component_AUPRC),
            "volume_component_AUPRC": float(volume.component_AUPRC),
            "prior_improves_over_available_segmentation_comparator": bool(prior_best.component_AUPRC > volume.component_AUPRC),
            "segmentation_probability_limitation": "only thresholded masks were retained; component probability/logit confidence is unavailable, so volume is the non-prior ranking comparator",
        }
    base_mask = bool(promising_by_source["baseline_seg"])
    s3_mask = bool(promising_by_source["s3_seg"])
    base_rank = ranking_signal["baseline_seg"]["prior_improves_over_available_segmentation_comparator"]
    s3_rank = ranking_signal["s3_seg"]["prior_improves_over_available_segmentation_comparator"]
    if base_mask and s3_mask:
        classification = "A. PRIOR HELPS BOTH BASELINE AND S3 SEGMENTATION"
    elif s3_mask and not base_mask:
        classification = "B. PRIOR HELPS S3 SEGMENTATION ONLY"
    elif base_mask and not s3_mask:
        classification = "C. PRIOR HELPS BASELINE SEGMENTATION ONLY"
    elif base_rank or s3_rank:
        classification = "E. RANKING IMPROVES BUT MASK-LEVEL PRUNING IS NOT DEPLOYABLE"
    else:
        classification = "D. PRIOR HELPS NEITHER"
    decision = {
        "classification": classification,
        "ranking_signal": ranking_signal,
        "promising_mask_strategies": promising_by_source,
        "train_no_attention_prior_head_next": bool(s3_mask and not base_mask),
        "validation_tuning_warning": "all thresholds and strategies are feasibility-only and require cross-fit before deployment",
    }
    write_json(args.output_dir / "decision.json", decision)

    parent_digest = "8a1a84a41598c70b624c90bda20e719d1409dff1209f59ad807923df5baaa845"
    checkpoint_payload = {
        "prior_head_checkpoint": str(args.prior_head_checkpoint.resolve()),
        "prior_head_sha256": sha256(args.prior_head_checkpoint),
        "parent_s3_checkpoint": str(args.parent_s3_checkpoint.resolve()),
        "parent_s3_sha256": parent_digest,
    }
    write_json(args.output_dir / "checkpoint_paths_and_digests.json", checkpoint_payload)
    write_json(args.output_dir / "prior_head_provenance.json", {
        **checkpoint_payload,
        "update": 300,
        "architecture_id": "frozen_s3_category_2d_prior_probe_v1",
        "architecture": "DensePriorHead2d(128 input channels, 32 hidden channels), half/full paths",
        "trainable_parameter_count_original_experiment": 8449,
        "selection_reason": "component/size-aware treatment checkpoint with the best reported target-25 localization/ranking signal",
    })
    write_json(args.output_dir / "provenance.json", {
        "manifest": str(args.manifest.resolve()),
        "findings": 132,
        "cases": len({row["file"] for row in entries}),
        "baseline_segmentation_source": str(args.baseline_seg_dir.resolve()),
        "s3_segmentation_source": str(args.s3_seg_dir.resolve()),
        "s3_segmentation_identity": "all-category single-S3 1/1 fixed-rho=0.25 step6000; same parent family as prior head",
        "segmentation_threshold": 0.5,
        "connectivity": 26,
        "segmentation_probabilities_available": False,
        "analysis_type": "inference maps plus offline component analysis; no training or weight modification",
    })
    report = f"""# Category-2d S3-prior component verifier feasibility

## BaselineSeg + S3Prior

Best prior ranking score: `{ranking_signal['baseline_seg']['best_prior_score']}`. Component AUPRC={ranking_signal['baseline_seg']['best_prior_component_AUPRC']:.6f}; volume comparator={ranking_signal['baseline_seg']['volume_component_AUPRC']:.6f}. Promising mask strategies: {promising_by_source['baseline_seg']}.

## S3Seg + S3Prior

Best prior ranking score: `{ranking_signal['s3_seg']['best_prior_score']}`. Component AUPRC={ranking_signal['s3_seg']['best_prior_component_AUPRC']:.6f}; volume comparator={ranking_signal['s3_seg']['volume_component_AUPRC']:.6f}. Promising mask strategies: {promising_by_source['s3_seg']}.

## Component ranking

See `component_ranking_summary.csv` and `component_ranking_by_subgroup.csv`. Original full-volume inference retained binary masks only, so probability/logit component confidence is unavailable; component volume is the non-prior comparator.

## Mask-level post-processing

See the two mask strategy summaries and paired per-finding tables. Candidate thresholds are validation-cohort feasibility checks, not deployable tuning.

## Decision

**{classification}**

Training a no-attention prior head next: **{decision['train_no_attention_prior_head_next']}**.
"""
    (args.output_dir / "report.md").write_text(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
