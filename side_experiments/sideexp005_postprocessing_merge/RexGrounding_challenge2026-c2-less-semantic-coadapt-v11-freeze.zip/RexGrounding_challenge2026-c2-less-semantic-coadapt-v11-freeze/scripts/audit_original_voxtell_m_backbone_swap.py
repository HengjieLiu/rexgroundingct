#!/usr/bin/env python3
"""Frozen M-head audit: M@2000 backbone versus historical B0@2000."""
from __future__ import annotations

import copy
import csv
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from scripts import run_original_voxtell_m_shortcut_pilot as pilot  # noqa: E402
from scripts import train_voxtell_rex_full_nnunet_aug as tr  # noqa: E402
from scripts.original_voxtell_wholefinding_runtime import install  # noqa: E402

OUT = ROOT / "outputs/original_voxtell_wholefinding_semantic/m_formal/backbone_swap"
M = ROOT / "outputs/original_voxtell_wholefinding_semantic/m_formal/checkpoints/checkpoint_update_2000.pth"
B0 = ROOT / "outputs/a2_fan_v11_longrun_5000/B0/checkpoints/checkpoint_update_2000.pth"


def per_item(
    model: pilot.M1,
    rows: list[dict],
    device: torch.device,
    stage: str = "joint",
) -> list[dict]:
    model.eval()
    with torch.no_grad():
        visual, text = model.encode(rows, device)
        # The trained M head maps text into the concatenated native d2+d3
        # visual space (128+64 channels).  Partial dot products preserve the
        # exact decomposition of the trained joint retrieval score, while
        # independently reporting which native stage carries any imprint.
        if stage == "d2":
            visual, text = visual[:, :128], text[:, :128]
        elif stage == "d3":
            visual, text = visual[:, 128:], text[:, 128:]
        elif stage != "joint":
            raise ValueError(stage)
        score = visual @ text.T
        target = torch.arange(len(rows), device=device)
        order = torch.argsort(score, 1, descending=True)
        ranks = (order == target[:, None]).nonzero()[:, 1] + 1
        negatives = score.masked_fill(torch.eye(len(rows), device=device, dtype=torch.bool), -torch.inf)
        margins = score.diagonal() - negatives.max(1).values
    return [
        {"case_id": row["case_id"], "finding_id": row["finding_id"],
         "stage": stage,
         "margin": float(margins[index]), "rank": int(ranks[index]),
         "top1": int(ranks[index] == 1)}
        for index, row in enumerate(rows)
    ]


def aggregate(rows: list[dict]) -> dict[str, float]:
    return {
        "margin": float(np.mean([row["margin"] for row in rows])),
        "top1": float(np.mean([row["top1"] for row in rows])),
        "mean_rank": float(np.mean([row["rank"] for row in rows])), "n": len(rows),
    }


def main() -> int:
    if not M.is_file() or not B0.is_file():
        raise FileNotFoundError(f"M={M.is_file()} B0={B0.is_file()}")
    OUT.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda")
    install(tr, m_head="multiscale")
    config = json.loads(pilot.ARGS.read_text())
    config.update({
        "prompt_location_label_dir": str(pilot.LOBE), "token_feature_cache": str(pilot.TOKEN),
        "less_encoder_mode": "word", "less_encoder_levels": [2, 3, 4, 5],
        "less_semantic_alignment_mode": "medplex", "less_semantic_alignment_dim": 128,
    })
    manifest = tr.load_manifest(Path(config["preprocessed_dir"]))
    cases = tr.build_case_records(manifest, "train", None)
    chosen = pilot.selected_findings(cases, 64)
    embeddings = tr.load_embedding_map(Path(config["embedding_cache"]), "qwen")
    tokens, _ = tr.load_token_feature_map(pilot.TOKEN)
    began = time.time()

    m_model = pilot.make_model(config, M, device)
    head_state = copy.deepcopy(m_model.less_semantic_alignment_heads["medplex"].state_dict())
    m_rows = pilot.extract(m_model, config, "formal_m_u2000", chosen, embeddings, tokens, device)
    del m_model; torch.cuda.empty_cache()
    b0_model = pilot.make_model(config, B0, device)
    b0_model.less_semantic_alignment_heads["medplex"].load_state_dict(head_state, strict=True)
    b0_rows = pilot.extract(b0_model, config, "historical_b0_u2000", chosen, embeddings, tokens, device)
    del b0_model; torch.cuda.empty_cache()

    readout = pilot.M1().to(device)
    readout.text.weight.data.copy_(head_state["text_projection.weight"].to(device))
    all_paired = []
    stage_payload = {}
    for stage_index, stage in enumerate(("d2", "d3", "joint")):
        m_item = per_item(readout, m_rows, device, stage)
        b0_item = per_item(readout, b0_rows, device, stage)
        lookup = {(row["case_id"], row["finding_id"]): row for row in b0_item}
        paired = []
        for row in m_item:
            key = (row["case_id"], row["finding_id"]); other = lookup[key]
            paired.append({**row, "b0_margin": other["margin"], "b0_rank": other["rank"],
                           "b0_top1": other["top1"], "margin_delta": row["margin"] - other["margin"]})
        all_paired.extend(paired)
        rng = np.random.default_rng(260904 + stage_index)
        case_ids = sorted({row["case_id"] for row in paired})
        boot = []
        for _ in range(2000):
            selected = rng.choice(case_ids, len(case_ids), replace=True)
            sample = [row for case in selected for row in paired if row["case_id"] == case]
            boot.append(float(np.mean([row["margin_delta"] for row in sample])))
        stage_payload[stage] = {
            "M_backbone_same_head": aggregate(m_item),
            "B0_backbone_same_head": aggregate(b0_item),
            "paired_margin_delta": float(np.mean([row["margin_delta"] for row in paired])),
            "paired_margin_delta_ci95": [
                float(np.quantile(boot, .025)), float(np.quantile(boot, .975))
            ],
        }
    payload = {
        "stages": stage_payload,
        "head_frozen": True, "M_checkpoint": str(M), "B0_checkpoint": str(B0),
        "runtime_seconds": time.time() - began,
    }
    with (OUT / "per_finding.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(all_paired[0])); writer.writeheader(); writer.writerows(all_paired)
    (OUT / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    (OUT / "report.md").write_text(
        "# M@2000 frozen-head backbone swap\n\n```json\n" + json.dumps(payload, indent=2) + "\n```\n"
    )
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
