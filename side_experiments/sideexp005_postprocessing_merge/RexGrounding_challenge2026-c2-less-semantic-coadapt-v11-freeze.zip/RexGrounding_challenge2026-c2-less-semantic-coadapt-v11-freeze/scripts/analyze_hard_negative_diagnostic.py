#!/usr/bin/env python3
"""Compare full-volume baseline and hard-negative sampler ablations."""

from __future__ import annotations

import argparse
import gc
import gzip
import json
import re
import shutil
import tempfile
import zlib
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd
from scipy.ndimage import generate_binary_structure, label
from tqdm import tqdm


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "outputs/analysis/hard_negative_diagnostic"
GT_DIR = ROOT / "data/segmentations"
CT_DIR = ROOT / "data/ct_rate_volumes_fixed"
FINDINGS_CSV = ROOT / "data/csv_exports/MICCAI_challenge_dataset.en.csv"

EXPERIMENTS = {
    "baseline_current_step2000": ROOT / "outputs/voxtell_rex_noaug_weightedbce_r10_step2000_fullvol_val_predictions",
    "hard_negative_triplet_step2400_bestpos": ROOT / "outputs/voxtell_rex_hardneg_step2400_bestpos_fullvol_val_predictions",
    "hard_negative_triplet_step3000": ROOT / "outputs/voxtell_rex_hardneg_step3000_fullvol_val_predictions",
    "hard_negative_triplet_step4000": ROOT / "outputs/voxtell_rex_hardneg_step4000_fullvol_val_predictions",
    "anchor85_samecase15_step3000_bestpos": ROOT / "outputs/voxtell_rex_anchor85_samecase15_step3000_bestpos_fullvol_val_predictions",
    "anchor85_samecase15_step3800_bestval": ROOT / "outputs/voxtell_rex_anchor85_step3800_bestval_fullvol_val_predictions",
}
BASELINE = "baseline_current_step2000"
CORE_EXPERIMENTS = (
    BASELINE,
    "hard_negative_triplet_step4000",
    "anchor85_samecase15_step3800_bestval",
)

HISTORIES = {
    "baseline_current": ROOT / "outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500/history.jsonl",
    "hard_negative_triplet": ROOT / "outputs/voxtell_rex_hard_negative_triplet_preprocessed_4l40s_to4000/history.jsonl",
    "anchor85_samecase15": ROOT / "outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000/history.jsonl",
}

DIFFUSE_RE = re.compile(
    r"\b(ground[- ]?glass|ggo|consolidation|opacity|opacities|infiltrate|infiltrates|"
    r"atelectasis|atelectatic|fibrotic|fibrosis|reticulation|reticular|honeycombing|"
    r"emphysema|mosaic attenuation|bronchiectasis|peribronchial thickening|"
    r"pleural effusion|pneumothorax|pleural thickening)\b",
    re.IGNORECASE,
)
FOCAL_RE = re.compile(r"\b(nodule|nodules|mass|lesion|lymph node|calcification|granuloma)\b", re.IGNORECASE)
CC_STRUCTURE = generate_binary_structure(3, 2)
CORE_METRICS = [
    "dice", "precision", "recall", "tp_volume_mm3", "fp_volume_mm3", "fn_volume_mm3",
    "pred_volume_mm3", "gt_volume_mm3", "pred_gt_volume_ratio", "num_pred_components",
    "largest_pred_component_mm3", "small_pred_component_count_lt10",
]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--limit-cases", type=int, default=None)
    p.add_argument(
        "--experiments",
        nargs="+",
        choices=tuple(EXPERIMENTS),
        default=list(CORE_EXPERIMENTS),
        help="Prediction checkpoints to compare (defaults to one representative checkpoint per sampler).",
    )
    p.add_argument("--case-list", type=Path, default=None, help="Optional newline-delimited case list.")
    p.add_argument(
        "--stratified-cases",
        type=int,
        default=None,
        help="Select this many cases, balanced across diffuse/focal case strata.",
    )
    p.add_argument("--selection-seed", type=int, default=20260710)
    p.add_argument(
        "--official-dice-only",
        action="store_true",
        help="Use completed official eval JSONs instead of rereading full NIfTI masks.",
    )
    p.add_argument(
        "--compute-components",
        action="store_true",
        help="Compute 3D connected-component statistics (substantially slower).",
    )
    return p.parse_args()


def select_stratified_cases(
    metadata: pd.DataFrame, n_cases: int, seed: int
) -> tuple[list[str], pd.DataFrame]:
    """Deterministically balance cases across diffuse/focal/both/other strata."""
    if n_cases <= 0:
        raise ValueError("--stratified-cases must be positive")
    case_rows = []
    for case, sub in metadata.groupby("case", sort=True):
        types = {finding_type(text) for text in sub["finding"]}
        has_diffuse = "diffuse" in types or "mixed" in types
        has_focal = "focal" in types or "mixed" in types
        if has_diffuse and has_focal:
            stratum = "diffuse_and_focal"
        elif has_diffuse:
            stratum = "diffuse"
        elif has_focal:
            stratum = "focal"
        else:
            stratum = "other"
        case_rows.append({"case": str(case), "case_stratum": stratum})
    case_frame = pd.DataFrame(case_rows)
    n_cases = min(n_cases, len(case_frame))
    rng = np.random.default_rng(seed)
    queues: dict[str, list[str]] = {}
    for stratum, sub in case_frame.groupby("case_stratum", sort=True):
        values = sub.case.to_numpy(copy=True)
        rng.shuffle(values)
        queues[stratum] = values.tolist()
    selected: list[str] = []
    strata = sorted(queues)
    while len(selected) < n_cases:
        advanced = False
        for stratum in strata:
            if queues[stratum] and len(selected) < n_cases:
                selected.append(queues[stratum].pop())
                advanced = True
        if not advanced:
            break
    selection = case_frame[case_frame.case.isin(selected)].copy()
    selection["selection_seed"] = seed
    selection = selection.set_index("case").loc[selected].reset_index()
    return selected, selection


def finding_type(text: str) -> str:
    diffuse = bool(DIFFUSE_RE.search(str(text)))
    focal = bool(FOCAL_RE.search(str(text)))
    if diffuse and focal:
        return "mixed"
    if diffuse:
        return "diffuse"
    if focal:
        return "focal"
    return "unknown"


def voxel_volume_mm3(case: str, fallback_img: nib.Nifti1Image) -> float:
    ct_path = CT_DIR / case
    ref = nib.load(str(ct_path)) if ct_path.exists() else fallback_img
    value = float(abs(np.linalg.det(ref.affine[:3, :3])))
    return value if np.isfinite(value) and value > 0 else float(np.prod(ref.header.get_zooms()[:3]))


def component_metrics(pred: np.ndarray, vv: float, compute: bool) -> dict[str, float | int]:
    if not compute:
        return {
            "num_pred_components": np.nan,
            "largest_pred_component_voxels": np.nan,
            "largest_pred_component_mm3": np.nan,
            "small_pred_component_count_lt10": np.nan,
        }
    cc, n = label(pred, structure=CC_STRUCTURE)
    if n == 0:
        return {
            "num_pred_components": 0,
            "largest_pred_component_voxels": 0,
            "largest_pred_component_mm3": 0.0,
            "small_pred_component_count_lt10": 0,
        }
    sizes = np.bincount(cc.ravel())[1:]
    largest = int(sizes.max())
    return {
        "num_pred_components": int(n),
        "largest_pred_component_voxels": largest,
        "largest_pred_component_mm3": float(largest * vv),
        "small_pred_component_count_lt10": int((sizes < 10).sum()),
    }


def finding_metrics(
    pred: np.ndarray, gt: np.ndarray, vv: float, compute_components: bool
) -> dict[str, float | int]:
    pred_n = int(pred.sum())
    gt_n = int(gt.sum())
    tp_n = int(np.logical_and(pred, gt).sum())
    fp_n = pred_n - tp_n
    fn_n = gt_n - tp_n
    denom = pred_n + gt_n
    out: dict[str, float | int] = {
        "dice": float(2 * tp_n / denom) if denom else 1.0,
        "global_hit": bool((2 * tp_n / denom) >= 0.1) if denom else True,
        "precision": float(tp_n / pred_n) if pred_n else (1.0 if gt_n == 0 else 0.0),
        "recall": float(tp_n / gt_n) if gt_n else 1.0,
        "tp_voxels": tp_n,
        "fp_voxels": fp_n,
        "fn_voxels": fn_n,
        "pred_voxels": pred_n,
        "gt_voxels": gt_n,
        "tp_volume_mm3": float(tp_n * vv),
        "fp_volume_mm3": float(fp_n * vv),
        "fn_volume_mm3": float(fn_n * vv),
        "pred_volume_mm3": float(pred_n * vv),
        "gt_volume_mm3": float(gt_n * vv),
        "pred_gt_volume_ratio": float(pred_n / gt_n) if gt_n else np.nan,
        "voxel_volume_mm3": vv,
    }
    out.update(component_metrics(pred, vv, compute_components))
    return out


def finding_metrics_from_counts(
    pred_n: int, gt_n: int, tp_n: int, vv: float
) -> dict[str, float | int]:
    fp_n = pred_n - tp_n
    fn_n = gt_n - tp_n
    denom = pred_n + gt_n
    out: dict[str, float | int] = {
        "dice": float(2 * tp_n / denom) if denom else 1.0,
        "global_hit": bool((2 * tp_n / denom) >= 0.1) if denom else True,
        "precision": float(tp_n / pred_n) if pred_n else (1.0 if gt_n == 0 else 0.0),
        "recall": float(tp_n / gt_n) if gt_n else 1.0,
        "tp_voxels": tp_n,
        "fp_voxels": fp_n,
        "fn_voxels": fn_n,
        "pred_voxels": pred_n,
        "gt_voxels": gt_n,
        "tp_volume_mm3": float(tp_n * vv),
        "fp_volume_mm3": float(fp_n * vv),
        "fn_volume_mm3": float(fn_n * vv),
        "pred_volume_mm3": float(pred_n * vv),
        "gt_volume_mm3": float(gt_n * vv),
        "pred_gt_volume_ratio": float(pred_n / gt_n) if gt_n else np.nan,
        "voxel_volume_mm3": vv,
    }
    out.update(component_metrics(np.empty(0, dtype=bool), vv, False))
    return out


def load_4d(path: Path) -> tuple[np.ndarray, nib.Nifti1Image]:
    img = nib.load(str(path))
    data = np.asanyarray(img.dataobj)
    if data.ndim != 4 or data.shape[0] > 64:
        raise ValueError(f"Expected channel-first 4D mask at {path}, got {data.shape}")
    return data, img


def open_4d(path: Path) -> nib.Nifti1Image:
    img = nib.load(str(path))
    if img.ndim != 4 or img.shape[0] > 64:
        raise ValueError(f"Expected channel-first 4D mask at {path}, got {img.shape}")
    return img


def decompress_nifti(source: Path, destination: Path) -> None:
    """Stage a gzipped NIfTI locally so channel slices do not re-decompress it."""
    with gzip.open(source, "rb") as src, destination.open("wb") as dst:
        shutil.copyfileobj(src, dst, length=16 * 1024 * 1024)


def paired_stream_counts(gt_path: Path, pred_path: Path) -> tuple[nib.Nifti1Image, np.ndarray, np.ndarray, np.ndarray]:
    """Count GT, prediction, and overlap voxels by channel with bounded memory."""
    gt_img = open_4d(gt_path)
    pred_img = open_4d(pred_path)
    if pred_img.shape != gt_img.shape:
        raise ValueError(f"{pred_path.name}: shape mismatch {pred_img.shape} vs {gt_img.shape}")
    gt_dtype = np.dtype(gt_img.get_data_dtype())
    pred_dtype = np.dtype(pred_img.get_data_dtype())
    channels = gt_img.shape[0]
    spatial_voxels = int(np.prod(gt_img.shape[1:]))
    gt_counts = np.zeros(channels, dtype=np.int64)
    pred_counts = np.zeros(channels, dtype=np.int64)
    tp_counts = np.zeros(channels, dtype=np.int64)
    chunk_spatial_voxels = 1_000_000
    with gzip.open(gt_path, "rb") as gt_file, gzip.open(pred_path, "rb") as pred_file:
        gt_file.seek(int(gt_img.dataobj.offset))
        pred_file.seek(int(pred_img.dataobj.offset))
        remaining = spatial_voxels
        while remaining:
            n_spatial = min(chunk_spatial_voxels, remaining)
            n_values = n_spatial * channels
            gt_bytes = gt_file.read(n_values * gt_dtype.itemsize)
            pred_bytes = pred_file.read(n_values * pred_dtype.itemsize)
            if len(gt_bytes) != n_values * gt_dtype.itemsize or len(pred_bytes) != n_values * pred_dtype.itemsize:
                raise EOFError(f"Unexpected end of NIfTI data for {pred_path.name}")
            gt_values = np.frombuffer(gt_bytes, dtype=gt_dtype).reshape((channels, n_spatial), order="F") > 0
            pred_values = np.frombuffer(pred_bytes, dtype=pred_dtype).reshape((channels, n_spatial), order="F") > 0
            gt_counts += gt_values.sum(axis=1, dtype=np.int64)
            pred_counts += pred_values.sum(axis=1, dtype=np.int64)
            tp_counts += np.logical_and(gt_values, pred_values).sum(axis=1, dtype=np.int64)
            remaining -= n_spatial
    return gt_img, gt_counts, pred_counts, tp_counts


def process_case(
    case: str,
    metadata: list[dict],
    experiments: dict[str, str],
    compute_components: bool,
) -> dict[str, list[dict]]:
    if not compute_components:
        meta_by_idx = {int(row["finding_idx"]): row for row in metadata}
        result: dict[str, list[dict]] = {}
        for experiment, pred_dir in experiments.items():
            gt_img, gt_counts, pred_counts, tp_counts = paired_stream_counts(
                GT_DIR / case, Path(pred_dir) / case
            )
            vv = voxel_volume_mm3(case, gt_img)
            rows = []
            for idx in range(gt_img.shape[0]):
                meta = meta_by_idx[idx]
                desc = str(meta["finding"])
                row = {
                    "experiment": experiment,
                    "case": case,
                    "finding_idx": idx,
                    "finding_key": f"{case}::finding_{idx}",
                    "description": desc,
                    "finding_type": finding_type(desc),
                    "category_code": meta.get("category_code", ""),
                    "dataset_focality": meta.get("focality", ""),
                    "entity_count": meta.get("entity_count", np.nan),
                }
                row.update(finding_metrics_from_counts(
                    int(pred_counts[idx]), int(gt_counts[idx]), int(tp_counts[idx]), vv
                ))
                rows.append(row)
            result[experiment] = rows
        return result

    with tempfile.TemporaryDirectory(prefix="rex_hardneg_diag_") as tmp:
        tmp_dir = Path(tmp)
        gt_local = tmp_dir / "gt.nii"
        pred_local = tmp_dir / "pred.nii"
        decompress_nifti(GT_DIR / case, gt_local)
        gt_img = open_4d(gt_local)
        vv = voxel_volume_mm3(case, gt_img)
        meta_by_idx = {int(row["finding_idx"]): row for row in metadata}
        result: dict[str, list[dict]] = {}
        for experiment, pred_dir in experiments.items():
            decompress_nifti(Path(pred_dir) / case, pred_local)
            pred_img = open_4d(pred_local)
            if pred_img.shape != gt_img.shape:
                raise ValueError(f"{case}: shape mismatch {pred_img.shape} vs {gt_img.shape}")
            rows = []
            for idx in range(gt_img.shape[0]):
                meta = meta_by_idx[idx]
                desc = str(meta["finding"])
                row = {
                    "experiment": experiment,
                    "case": case,
                    "finding_idx": idx,
                    "finding_key": f"{case}::finding_{idx}",
                    "description": desc,
                    "finding_type": finding_type(desc),
                    "category_code": meta.get("category_code", ""),
                    "dataset_focality": meta.get("focality", ""),
                    "entity_count": meta.get("entity_count", np.nan),
                }
                gt_mask = np.asanyarray(gt_img.dataobj[idx]) > 0
                pred_mask = np.asanyarray(pred_img.dataobj[idx]) > 0
                row.update(finding_metrics(pred_mask, gt_mask, vv, compute_components))
                rows.append(row)
                del gt_mask, pred_mask
            result[experiment] = rows
            del pred_img
            pred_local.unlink()
            gc.collect()
        del gt_img
        return result


def load_official_metrics(
    metadata: pd.DataFrame, experiments: dict[str, Path]
) -> pd.DataFrame:
    """Flatten completed official global-evaluation JSONs into paired finding rows."""
    meta_by_key = {
        (str(row.case), int(row.finding_idx)): row
        for row in metadata.itertuples(index=False)
    }
    rows = []
    unavailable = {
        "precision": np.nan,
        "recall": np.nan,
        "tp_volume_mm3": np.nan,
        "fp_volume_mm3": np.nan,
        "fn_volume_mm3": np.nan,
        "pred_volume_mm3": np.nan,
        "gt_volume_mm3": np.nan,
        "pred_gt_volume_ratio": np.nan,
        "num_pred_components": np.nan,
        "largest_pred_component_mm3": np.nan,
        "small_pred_component_count_lt10": np.nan,
    }
    for experiment, pred_dir in experiments.items():
        eval_path = pred_dir / "eval_rexrank_metrics_global.json"
        payload = json.loads(eval_path.read_text())
        for case_result in payload["cases"]:
            case = str(case_result["file"])
            for finding_name, finding_result in case_result["findings"].items():
                idx = int(finding_name.rsplit("_", 1)[1])
                if (case, idx) not in meta_by_key:
                    continue
                meta = meta_by_key[(case, idx)]
                desc = str(meta.finding)
                row = {
                    "experiment": experiment,
                    "case": case,
                    "finding_idx": idx,
                    "finding_key": f"{case}::finding_{idx}",
                    "description": desc,
                    "finding_type": finding_type(desc),
                    "category_code": getattr(meta, "category_code", ""),
                    "dataset_focality": getattr(meta, "focality", ""),
                    "entity_count": getattr(meta, "entity_count", np.nan),
                    "dice": float(finding_result["global_dice"]),
                    "global_hit": bool(finding_result.get("global_hit", False)),
                    **unavailable,
                }
                rows.append(row)
    return pd.DataFrame(rows)


def stat_rows(df: pd.DataFrame, keys: dict[str, object]) -> dict[str, object]:
    out = dict(keys)
    out["n"] = len(df)
    for col in CORE_METRICS:
        values = pd.to_numeric(df[col], errors="coerce")
        out[f"{col}_mean"] = values.mean()
        out[f"{col}_median"] = values.median()
        out[f"{col}_std"] = values.std()
    if "global_hit" in df:
        hits = pd.to_numeric(df["global_hit"], errors="coerce")
        out["global_hits"] = hits.sum()
        out["global_hit_rate"] = hits.mean()
    return out


def make_summaries(all_metrics: pd.DataFrame, out_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    exp_rows = [stat_rows(sub, {"experiment": exp}) for exp, sub in all_metrics.groupby("experiment", sort=False)]
    by_exp = pd.DataFrame(exp_rows)
    by_exp.to_csv(out_dir / "summary_by_experiment.csv", index=False)
    group_rows = []
    for (exp, group), sub in all_metrics.groupby(["experiment", "finding_type"], sort=False):
        group_rows.append(stat_rows(sub, {"experiment": exp, "finding_type": group}))
    by_group = pd.DataFrame(group_rows)
    by_group.to_csv(out_dir / "summary_by_group.csv", index=False)
    return by_exp, by_group


def paired_analysis(all_metrics: pd.DataFrame, out_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    baseline = all_metrics[all_metrics.experiment == BASELINE].set_index("finding_key")
    rows = []
    for experiment in all_metrics.experiment.drop_duplicates():
        if experiment == BASELINE:
            continue
        candidate = all_metrics[all_metrics.experiment == experiment].set_index("finding_key")
        common = baseline.index.intersection(candidate.index)
        for key in common:
            b = baseline.loc[key]
            c = candidate.loc[key]
            rows.append({
                "comparison": f"{experiment}_vs_{BASELINE}",
                "experiment": experiment,
                "finding_key": key,
                "case": c["case"],
                "finding_idx": c["finding_idx"],
                "description": c["description"],
                "finding_type": c["finding_type"],
                "category_code": c["category_code"],
                "baseline_dice": b["dice"],
                "candidate_dice": c["dice"],
                "delta_dice": c["dice"] - b["dice"],
                "baseline_precision": b["precision"],
                "candidate_precision": c["precision"],
                "delta_precision": c["precision"] - b["precision"],
                "baseline_recall": b["recall"],
                "candidate_recall": c["recall"],
                "delta_recall": c["recall"] - b["recall"],
                "baseline_fp_volume_mm3": b["fp_volume_mm3"],
                "candidate_fp_volume_mm3": c["fp_volume_mm3"],
                "delta_fp_volume_mm3": c["fp_volume_mm3"] - b["fp_volume_mm3"],
                "baseline_fn_volume_mm3": b["fn_volume_mm3"],
                "candidate_fn_volume_mm3": c["fn_volume_mm3"],
                "delta_fn_volume_mm3": c["fn_volume_mm3"] - b["fn_volume_mm3"],
                "baseline_pred_volume_mm3": b["pred_volume_mm3"],
                "candidate_pred_volume_mm3": c["pred_volume_mm3"],
                "delta_pred_volume_mm3": c["pred_volume_mm3"] - b["pred_volume_mm3"],
                "baseline_pred_gt_ratio": b["pred_gt_volume_ratio"],
                "candidate_pred_gt_ratio": c["pred_gt_volume_ratio"],
                "delta_pred_gt_ratio": c["pred_gt_volume_ratio"] - b["pred_gt_volume_ratio"],
                "ratio_moved_closer_to_1": (
                    abs(c["pred_gt_volume_ratio"] - 1) < abs(b["pred_gt_volume_ratio"] - 1)
                    if pd.notna(c["pred_gt_volume_ratio"]) and pd.notna(b["pred_gt_volume_ratio"])
                    else np.nan
                ),
            })
    paired = pd.DataFrame(rows)
    paired.to_csv(out_dir / "paired_comparison.csv", index=False)
    summary_rows = []
    for (experiment, group), sub in paired.groupby(["experiment", "finding_type"], sort=False):
        summary_rows.append(paired_summary_row(sub, experiment, group))
    for experiment, sub in paired.groupby("experiment", sort=False):
        summary_rows.append(paired_summary_row(sub, experiment, "all"))
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(out_dir / "paired_summary.csv", index=False)
    return paired, summary


def paired_summary_row(df: pd.DataFrame, experiment: str, group: str) -> dict[str, object]:
    fp = pd.to_numeric(df.delta_fp_volume_mm3, errors="coerce").dropna()
    fn = pd.to_numeric(df.delta_fn_volume_mm3, errors="coerce").dropna()
    ratio = pd.to_numeric(df.ratio_moved_closer_to_1, errors="coerce").dropna()
    by_case = df.groupby("case").delta_dice.agg(["sum", "size"]).to_numpy()
    seed = zlib.crc32(f"{experiment}:{group}".encode())
    rng = np.random.default_rng(seed)
    sampled = by_case[rng.integers(0, len(by_case), size=(5000, len(by_case)))]
    bootstrap_means = sampled[:, :, 0].sum(axis=1) / sampled[:, :, 1].sum(axis=1)
    ci_low, ci_high = np.quantile(bootstrap_means, [0.025, 0.975])
    return {
        "experiment": experiment,
        "finding_type": group,
        "n": len(df),
        "delta_dice_mean": df.delta_dice.mean(),
        "delta_dice_median": df.delta_dice.median(),
        "delta_dice_case_bootstrap_ci_low": ci_low,
        "delta_dice_case_bootstrap_ci_high": ci_high,
        "delta_precision_mean": df.delta_precision.mean(),
        "delta_precision_median": df.delta_precision.median(),
        "delta_recall_mean": df.delta_recall.mean(),
        "delta_recall_median": df.delta_recall.median(),
        "delta_fp_volume_mm3_mean": df.delta_fp_volume_mm3.mean(),
        "delta_fp_volume_mm3_median": df.delta_fp_volume_mm3.median(),
        "delta_fn_volume_mm3_mean": df.delta_fn_volume_mm3.mean(),
        "delta_fn_volume_mm3_median": df.delta_fn_volume_mm3.median(),
        "delta_pred_volume_mm3_mean": df.delta_pred_volume_mm3.mean(),
        "delta_pred_volume_mm3_median": df.delta_pred_volume_mm3.median(),
        "delta_pred_gt_ratio_mean": df.delta_pred_gt_ratio.mean(),
        "delta_pred_gt_ratio_median": df.delta_pred_gt_ratio.median(),
        "fraction_dice_improved": (df.delta_dice > 0).mean(),
        "fraction_fp_decreased": (fp < 0).mean() if len(fp) else np.nan,
        "fraction_fn_increased": (fn > 0).mean() if len(fn) else np.nan,
        "fraction_ratio_moved_closer_to_1": ratio.mean() if len(ratio) else np.nan,
    }


def role_status(record: dict, role_prefix: str) -> bool | None:
    roles = record.get("roles_after_shuffle")
    targets = record.get("target_voxels")
    if not isinstance(roles, list) or not isinstance(targets, list):
        return None
    for role, voxels in zip(roles, targets):
        if str(role).startswith(role_prefix):
            return int(voxels) > 0
    return None


def sampler_analysis(out_dir: Path) -> pd.DataFrame:
    rows = []
    hardness_rows = []
    for mode, path in HISTORIES.items():
        records = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        counts_nonempty = []
        counts_empty = []
        if mode == "baseline_current":
            for rec in records:
                n_nonempty = sum(int(x) > 0 for x in rec.get("positive_voxels", []))
                n_total = len(rec.get("positive_voxels", [])) + len(rec.get("negative_cases", []))
                counts_nonempty.append(n_nonempty)
                counts_empty.append(n_total - n_nonempty)
        else:
            for rec in records:
                targets = rec.get("target_voxels", [])
                counts_nonempty.append(sum(int(x) > 0 for x in targets))
                counts_empty.append(sum(int(x) == 0 for x in targets))
        total_prompts = sum(counts_nonempty) + sum(counts_empty)
        row: dict[str, object] = {
            "sampler_mode": mode,
            "samples_inspected": len(records),
            "prompts_inspected": total_prompts,
            "fraction_crop_level_nonempty_targets": sum(counts_nonempty) / total_prompts,
            "fraction_crop_level_empty_targets": sum(counts_empty) / total_prompts,
            "mean_nonempty_targets_per_sample": np.mean(counts_nonempty),
            "mean_empty_targets_per_sample": np.mean(counts_empty),
        }
        if mode == "hard_negative_triplet":
            row.update({
                "fraction_A_nonempty": np.mean([role_status(r, "A_") is True for r in records]),
                "fraction_B_empty": np.mean([role_status(r, "B_") is False for r in records]),
                "fraction_C_empty": np.mean([role_status(r, "C_") is False for r in records]),
                "fraction_prompt_order_shuffled": np.mean([r.get("final_prompt_order") != [0, 1, 2] for r in records]),
                "fraction_cross_case_source_has_foreground": np.mean([any(r.get("cross_case_source_has_foreground_after_shuffle", [])) for r in records]),
            })
        if mode == "anchor85_samecase15":
            row.update({
                "fraction_anchor_positive_mode": np.mean([r.get("crop_mode") == "anchor_positive" for r in records]),
                "fraction_same_case_negative_mode": np.mean([r.get("crop_mode") == "same_case_negative" for r in records]),
                "fraction_A_nonempty": np.mean([role_status(r, "A_") is True for r in records]),
                "fraction_B_nonempty": np.mean([role_status(r, "B_") is True for r in records]),
                "fraction_C_empty": np.mean([role_status(r, "C_") is False for r in records]),
                "fraction_prompt_order_shuffled": np.mean([r.get("final_prompt_order") != [0, 1, 2] for r in records]),
                "fraction_cross_case_source_has_foreground": np.mean([any(r.get("cross_case_source_has_foreground_after_shuffle", [])) for r in records]),
            })
        rows.append(row)

        for rec in records:
            is_same_neg = mode == "hard_negative_triplet" or (
                mode == "anchor85_samecase15" and rec.get("crop_mode") == "same_case_negative"
            )
            if not is_same_neg:
                continue
            roles = rec.get("roles_after_shuffle", [])
            targets = rec.get("target_voxels", [])
            negative_prefix = "B_" if mode == "hard_negative_triplet" else "A_"
            other = [int(v) for role, v in zip(roles, targets) if not str(role).startswith(negative_prefix) and not str(role).startswith("C_")]
            hardness_rows.append({
                "sampler_mode": mode,
                "step": rec.get("step"),
                "case": rec.get("case"),
                "crop_mode": rec.get("crop_mode"),
                "contains_other_finding_foreground": any(v > 0 for v in other),
                "other_finding_voxels_in_crop": sum(other),
                "number_of_other_findings_in_crop": sum(v > 0 for v in other),
            })
    summary = pd.DataFrame(rows)
    summary.to_csv(out_dir / "sampler_distribution_summary.csv", index=False)
    hardness = pd.DataFrame(hardness_rows)
    hardness.to_csv(out_dir / "same_case_negative_hardness.csv", index=False)
    if not hardness.empty:
        hard_summary = hardness.groupby("sampler_mode").agg(
            n=("contains_other_finding_foreground", "size"),
            fraction_contains_other_finding=("contains_other_finding_foreground", "mean"),
            fraction_easy_background=("contains_other_finding_foreground", lambda x: 1 - x.mean()),
            median_other_finding_voxels=("other_finding_voxels_in_crop", "median"),
            mean_other_finding_voxels=("other_finding_voxels_in_crop", "mean"),
        ).reset_index()
        hard_summary.to_csv(out_dir / "same_case_negative_hardness_summary.csv", index=False)
    return summary


def fmt(value: float, digits: int = 3) -> str:
    return "NA" if pd.isna(value) else f"{value:.{digits}f}"


def write_report(
    by_exp: pd.DataFrame,
    paired_summary: pd.DataFrame,
    sampler: pd.DataFrame,
    out_dir: Path,
    compute_components: bool,
    official_dice_only: bool,
) -> None:
    scope = (
        "Official full-volume paired global-Dice evaluation of 200 validation cases / 381 findings. "
        "FP/FN and component fields are unavailable in the saved official JSONs."
        if official_dice_only
        else
        "Full-volume paired evaluation of 200 validation cases / 381 findings. Predictions are binary masks; physical volumes use CT-header voxel spacing."
    )
    lines = [
        "# Hard-negative sampler diagnostic", "",
        "## Scope", "",
        scope, "",
        "## Full-volume results", "",
        "| Experiment | Dice mean | Dice median | Hit rate | FP median (mm3) | FN median (mm3) | Pred/GT median |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for _, r in by_exp.iterrows():
        lines.append(
            f"| {r.experiment} | {fmt(r.dice_mean)} | {fmt(r.dice_median)} | {fmt(r.get('global_hit_rate', np.nan))} | "
            f"{fmt(r.fp_volume_mm3_median, 1)} | {fmt(r.fn_volume_mm3_median, 1)} | {fmt(r.pred_gt_volume_ratio_median)} |"
        )
    lines += ["", "## Paired changes versus baseline", "",
              "| Experiment | Group | n | Delta Dice mean | Case-bootstrap 95% CI | Delta FP median (mm3) | Delta FN median (mm3) | FP decreased | FN increased | Ratio closer to 1 |",
              "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for _, r in paired_summary.iterrows():
        if r.finding_type not in {"all", "diffuse", "focal"}:
            continue
        lines.append(
            f"| {r.experiment} | {r.finding_type} | {int(r.n)} | {fmt(r.delta_dice_mean, 4)} | "
            f"[{fmt(r.delta_dice_case_bootstrap_ci_low, 4)}, {fmt(r.delta_dice_case_bootstrap_ci_high, 4)}] | "
            f"{fmt(r.delta_fp_volume_mm3_median, 1)} | {fmt(r.delta_fn_volume_mm3_median, 1)} | "
            f"{fmt(r.fraction_fp_decreased)} | {fmt(r.fraction_fn_increased)} | {fmt(r.fraction_ratio_moved_closer_to_1)} |"
        )
    best = by_exp.loc[by_exp.dice_mean.idxmax()]
    best_delta = paired_summary[
        (paired_summary.experiment == best.experiment)
        & (paired_summary.finding_type == "all")
    ].iloc[0]
    lines += [
        "", "## Main result", "",
        f"The best evaluated checkpoint is `{best.experiment}` (mean Dice {best.dice_mean:.6f}), "
        f"an absolute gain of {best_delta.delta_dice_mean:.6f} over `{BASELINE}` "
        f"(case-bootstrap 95% CI {best_delta.delta_dice_case_bootstrap_ci_low:.6f} to "
        f"{best_delta.delta_dice_case_bootstrap_ci_high:.6f}). The gain is consistent but small.", "",
        "The baseline prediction is from step 2000, while both sampler ablations resume from that checkpoint and continue toward step 4000. No matched current-sampler continuation to the same steps was found, so extra optimization time is confounded with sampler choice.", "",
        "## Sampler evidence", "",
              "Training histories contain sample-level metadata; baseline target counts are inferred from positive_voxels plus the negative prompt.", "",
              "| Sampler | Samples | Non-empty target fraction | Empty target fraction |",
              "|---|---:|---:|---:|"]
    for _, r in sampler.iterrows():
        lines.append(f"| {r.sampler_mode} | {int(r.samples_inspected)} | {fmt(r.fraction_crop_level_nonempty_targets)} | {fmt(r.fraction_crop_level_empty_targets)} |")
    interpretation = (
        "This run supports Dice and hit-rate comparisons only. It cannot determine whether the models became more conservative or whether false-positive volume fell; that requires rereading the NIfTI masks."
        if official_dice_only
        else
        "A negative FP delta with a positive FN delta indicates a more conservative model. A negative FP delta without meaningful FN growth is the clearest evidence that hard-negative supervision helped. The per-group rows should be used to check whether focal findings lose recall while diffuse findings reduce over-segmentation."
    )
    lines += ["", "## Interpretation guide", "",
              interpretation, "",
              "## Limitations", "",
              ("- Connected-component counts include every binary prediction component; `small_pred_component_count_lt10` records components under 10 voxels."
               if compute_components else
               "- Connected-component statistics were skipped in this run for runtime; pass `--compute-components` to populate those columns."),
              "- Same-case hardness uses saved crop roles and target voxel counts. It establishes whether another annotated finding is present, but does not identify same-organ anatomy beyond the finding text.",
              "- No empty-target inference outputs were saved, so empty-patch FP rate cannot be compared from these full-volume positive-prompt predictions.", ""]
    (out_dir / "report.md").write_text("\n".join(lines))


def main() -> int:
    args = parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    selected_experiments = {name: EXPERIMENTS[name] for name in args.experiments}
    if BASELINE not in selected_experiments:
        raise ValueError(f"Paired analysis requires baseline experiment {BASELINE}")
    missing = [str(path) for path in [GT_DIR, CT_DIR, FINDINGS_CSV, *selected_experiments.values(), *HISTORIES.values()] if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required inputs:\n" + "\n".join(missing))
    metadata = pd.read_csv(FINDINGS_CSV, encoding="utf-8-sig")
    metadata = metadata[metadata["split"] == "val"].copy()
    if args.case_list is not None and args.stratified_cases is not None:
        raise ValueError("Use only one of --case-list and --stratified-cases")
    if args.case_list is not None:
        requested = [line.strip() for line in args.case_list.read_text().splitlines() if line.strip()]
        available = set(metadata.case.unique())
        missing_cases = sorted(set(requested) - available)
        if missing_cases:
            raise ValueError(f"Cases not present in validation metadata: {missing_cases}")
        cases = requested
    elif args.stratified_cases is not None:
        cases, selection = select_stratified_cases(
            metadata, args.stratified_cases, args.selection_seed
        )
        selection.to_csv(args.out_dir / "selected_cases.csv", index=False)
    else:
        cases = sorted(metadata.case.unique())
    if args.limit_cases is not None:
        cases = cases[: args.limit_cases]
    metadata = metadata[metadata.case.isin(cases)]
    if args.official_dice_only:
        all_metrics = load_official_metrics(metadata, selected_experiments)
        frames = []
        for experiment, frame in all_metrics.groupby("experiment", sort=False):
            frame = frame.sort_values(["case", "finding_idx"])
            frame.to_csv(args.out_dir / f"per_finding_metrics_{experiment}.csv", index=False)
            frames.append(frame)
        all_metrics = pd.concat(frames, ignore_index=True)
    else:
        meta_by_case = {case: sub.to_dict("records") for case, sub in metadata.groupby("case")}
        experiment_strings = {name: str(path) for name, path in selected_experiments.items()}
        gathered = {name: [] for name in selected_experiments}
        cache_dir = args.out_dir / ("case_cache_components" if args.compute_components else "case_cache")
        cache_dir.mkdir(parents=True, exist_ok=True)
        remaining_cases = []
        for case in cases:
            cache_path = cache_dir / f"{Path(case).name}.csv"
            if cache_path.exists():
                cached = pd.read_csv(cache_path)
                if set(cached.experiment.unique()) == set(selected_experiments):
                    for experiment, frame in cached.groupby("experiment", sort=False):
                        gathered[experiment].extend(frame.to_dict("records"))
                    continue
            remaining_cases.append(case)

        def save_case_result(case: str, result: dict[str, list[dict]]) -> None:
            rows = [row for experiment_rows in result.values() for row in experiment_rows]
            cache_path = cache_dir / f"{Path(case).name}.csv"
            tmp_path = cache_path.with_suffix(cache_path.suffix + ".tmp")
            pd.DataFrame(rows).to_csv(tmp_path, index=False)
            tmp_path.replace(cache_path)

        tasks = [
            (case, meta_by_case[case], experiment_strings, args.compute_components)
            for case in remaining_cases
        ]
        if len(remaining_cases) != len(cases):
            print(f"Resuming from {len(cases) - len(remaining_cases)} cached cases")
        if args.num_workers > 1:
            with ProcessPoolExecutor(max_workers=args.num_workers) as pool:
                futures = {pool.submit(process_case, *task): task[0] for task in tasks}
                for future in tqdm(as_completed(futures), total=len(futures), desc="Cases"):
                    result = future.result()
                    save_case_result(futures[future], result)
                    for experiment, rows in result.items():
                        gathered[experiment].extend(rows)
        else:
            for task in tqdm(tasks, desc="Cases"):
                result = process_case(*task)
                save_case_result(task[0], result)
                for experiment, rows in result.items():
                    gathered[experiment].extend(rows)
        frames = []
        for experiment, rows in gathered.items():
            frame = pd.DataFrame(rows).sort_values(["case", "finding_idx"])
            frame.to_csv(args.out_dir / f"per_finding_metrics_{experiment}.csv", index=False)
            frames.append(frame)
        all_metrics = pd.concat(frames, ignore_index=True)
    all_metrics.to_csv(args.out_dir / "per_finding_metrics_all_experiments.csv", index=False)
    by_exp, _ = make_summaries(all_metrics, args.out_dir)
    _, paired_summary = paired_analysis(all_metrics, args.out_dir)
    sampler = sampler_analysis(args.out_dir)
    write_report(
        by_exp,
        paired_summary,
        sampler,
        args.out_dir,
        args.compute_components,
        args.official_dice_only,
    )
    print(f"Wrote analysis to {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
