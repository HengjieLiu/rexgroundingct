#!/usr/bin/env python3
"""Analyze post-hoc update-25/50 frozen prompt-adapter evaluations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd
import torch


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--allcategory-source", type=Path, required=True)
    parser.add_argument("--multiscale-source", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=2026)
    return parser.parse_args()


def load_variant(directory: Path) -> tuple[dict[str, Any], pd.DataFrame]:
    summary = json.loads((directory / "summary.json").read_text())
    frame = pd.read_csv(directory / "per_finding_metrics.csv")
    if len(frame) != 381 or int(summary["total_cases"]) != 200:
        raise ValueError(f"{directory}: not the canonical 200/381 cohort")
    frame["key"] = (
        frame["file"].astype(str)
        + "::"
        + frame["finding_idx"].astype(int).astype(str)
    )
    frame = frame.set_index("key").sort_index()
    if not frame.index.is_unique:
        raise ValueError(f"{directory}: duplicate finding keys")
    return summary, frame


def load_residual(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    frame["key"] = (
        frame["file"].astype(str)
        + "::"
        + frame["finding_idx"].astype(int).astype(str)
    )
    return frame.set_index("key").sort_index()


def finding_bootstrap(values: np.ndarray, samples: int, seed: int) -> list[float]:
    generator = np.random.default_rng(seed)
    means = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 500):
        count = min(500, samples - start)
        indices = generator.integers(0, len(values), size=(count, len(values)))
        means[start : start + count] = values[indices].mean(axis=1)
    return [float(value) for value in np.quantile(means, [0.025, 0.975])]


def case_bootstrap(frame: pd.DataFrame, field: str, samples: int, seed: int) -> list[float]:
    values = frame.groupby("file", sort=True)[field].mean().to_numpy(np.float64)
    return finding_bootstrap(values, samples, seed)


def correlation(left: pd.Series, right: pd.Series, method: str) -> float:
    value = left.corr(right, method=method)
    return float(value) if pd.notna(value) else float("nan")


def paired_frame(
    baseline: pd.DataFrame,
    adapter: pd.DataFrame,
    residual: pd.DataFrame,
    branch: str,
    update: int,
) -> pd.DataFrame:
    if not baseline.index.equals(adapter.index) or not baseline.index.equals(residual.index):
        raise ValueError(f"{branch} update {update}: finding identities differ")
    frame = pd.DataFrame(index=baseline.index)
    frame["branch"] = branch
    frame["update"] = update
    for field in ("file", "finding_idx", "prompt", "category", "pixels"):
        frame[field] = baseline[field]
    frame["baseline_dice"] = baseline["global_dice"].astype(float)
    frame["adapter_dice"] = adapter["global_dice"].astype(float)
    frame["dice_delta"] = frame["adapter_dice"] - frame["baseline_dice"]
    frame["baseline_hit"] = baseline["global_hit"].astype(bool)
    frame["adapter_hit"] = adapter["global_hit"].astype(bool)
    frame["new_hit"] = frame["adapter_hit"] & ~frame["baseline_hit"]
    frame["lost_hit"] = ~frame["adapter_hit"] & frame["baseline_hit"]
    for prefix, source in (("baseline", baseline), ("adapter", adapter)):
        for field in ("pred_gt_volume_ratio", "fp_mm3", "fn_mm3", "pred_voxels", "gt_voxels"):
            frame[f"{prefix}_{field}"] = source[field].astype(float)
    for field in (
        "base_query_norm",
        "residual_norm",
        "residual_base_query_ratio",
        "query_residual_cosine",
    ):
        frame[field] = residual[field].astype(float)
    return frame.reset_index(drop=True)


def summarize_paired(frame: pd.DataFrame) -> dict[str, Any]:
    delta = frame["dice_delta"].to_numpy(np.float64)
    top = frame["dice_delta"].abs().nlargest(5).index
    total_abs = float(frame["dice_delta"].abs().sum())
    return {
        "mean_delta": float(delta.mean()),
        "median_delta": float(np.median(delta)),
        "q25_delta": float(np.quantile(delta, 0.25)),
        "q75_delta": float(np.quantile(delta, 0.75)),
        "improved": int((delta > 0).sum()),
        "degraded": int((delta < 0).sum()),
        "unchanged": int((delta == 0).sum()),
        "delta_gt_0p01": int((delta > 0.01).sum()),
        "delta_lt_minus_0p01": int((delta < -0.01).sum()),
        "new_hits": int(frame["new_hit"].sum()),
        "lost_hits": int(frame["lost_hit"].sum()),
        "mean_prediction_gt_volume_ratio": float(frame["adapter_pred_gt_volume_ratio"].mean()),
        "mean_false_positive_mm3": float(frame["adapter_fp_mm3"].mean()),
        "mean_false_negative_mm3": float(frame["adapter_fn_mm3"].mean()),
        "delta_mean_prediction_gt_volume_ratio": float(
            (frame["adapter_pred_gt_volume_ratio"] - frame["baseline_pred_gt_volume_ratio"]).mean()
        ),
        "delta_mean_false_positive_mm3": float(
            (frame["adapter_fp_mm3"] - frame["baseline_fp_mm3"]).mean()
        ),
        "delta_mean_false_negative_mm3": float(
            (frame["adapter_fn_mm3"] - frame["baseline_fn_mm3"]).mean()
        ),
        "mean_delta_without_five_largest_absolute_changes": float(
            frame.drop(index=top)["dice_delta"].mean()
        ),
        "five_largest_absolute_share": (
            float(frame.loc[top, "dice_delta"].abs().sum() / total_abs)
            if total_abs else 0.0
        ),
        "pearson_residual_ratio_vs_delta": correlation(
            frame["residual_base_query_ratio"], frame["dice_delta"], "pearson"
        ),
        "spearman_residual_ratio_vs_delta": correlation(
            frame["residual_base_query_ratio"], frame["dice_delta"], "spearman"
        ),
    }


def subgroup_rows(frame: pd.DataFrame, branch: str, update: int) -> list[dict[str, Any]]:
    groupers: dict[str, Callable[[pd.DataFrame], pd.Series]] = {
        "2b": lambda x: x["category"].astype(str) == "2b",
        "2c": lambda x: x["category"].astype(str) == "2c",
        "2b_plus_2c": lambda x: x["category"].astype(str).isin(["2b", "2c"]),
        "all_except_2b2c": lambda x: ~x["category"].astype(str).isin(["2b", "2c"]),
        "category_1_diffuse": lambda x: x["category"].astype(str).str.startswith("1"),
        "category_2_focal": lambda x: x["category"].astype(str).str.startswith("2"),
        "2a": lambda x: x["category"].astype(str) == "2a",
        "2d": lambda x: x["category"].astype(str) == "2d",
        "tiny_lt_100_gt_voxels": lambda x: x["pixels"].astype(int) < 100,
        "non_tiny_ge_100_gt_voxels": lambda x: x["pixels"].astype(int) >= 100,
    }
    rows = []
    for group, grouper in groupers.items():
        subset = frame.loc[grouper(frame)]
        rows.append(
            {
                "branch": branch,
                "update": update,
                "group": group,
                "findings": len(subset),
                "cases": int(subset["file"].nunique()),
                "baseline_dice": float(subset["baseline_dice"].mean()),
                "adapter_dice": float(subset["adapter_dice"].mean()),
                "mean_dice_delta": float(subset["dice_delta"].mean()),
                "median_dice_delta": float(subset["dice_delta"].median()),
                "improved": int((subset["dice_delta"] > 0).sum()),
                "degraded": int((subset["dice_delta"] < 0).sum()),
                "new_hits": int(subset["new_hit"].sum()),
                "lost_hits": int(subset["lost_hit"].sum()),
            }
        )
    return rows


def adapter_norm(path: Path) -> float:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    values = torch.cat([value.float().flatten() for value in payload["adapter_state"].values()])
    return float(values.norm())


def label_early(delta: float, hit_delta: int, new_hits: int, lost_hits: int) -> str:
    if delta >= 0.003 and hit_delta >= 0 and new_hits > lost_hits:
        return "EXPLORATORY POSITIVE"
    if -0.003 < delta < 0.003:
        return "NEUTRAL"
    return "NEGATIVE"


def interaction_rows(
    allcategory: pd.DataFrame,
    multiscale: pd.DataFrame,
    update: int,
    samples: int,
    seed: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    keys = ["file", "finding_idx", "category", "pixels"]
    left = allcategory[keys + ["dice_delta"]].copy()
    right = multiscale[keys + ["dice_delta"]].copy()
    left["key"] = left["file"].astype(str) + "::" + left["finding_idx"].astype(int).astype(str)
    right["key"] = right["file"].astype(str) + "::" + right["finding_idx"].astype(int).astype(str)
    left = left.set_index("key").sort_index()
    right = right.set_index("key").sort_index()
    if not left.index.equals(right.index):
        raise ValueError(f"Update {update}: architecture finding identities differ")
    for field in keys:
        if not left[field].equals(right[field]):
            raise ValueError(f"Update {update}: architecture metadata differs: {field}")
    merged = left.rename(columns={"dice_delta": "delta_allcategory"})
    merged["delta_multiscale"] = right["dice_delta"]
    merged["interaction_delta"] = (
        merged["delta_allcategory"] - merged["delta_multiscale"]
    )
    groupers: dict[str, Callable[[pd.DataFrame], pd.Series]] = {
        "overall": lambda x: pd.Series(True, index=x.index),
        "2b_plus_2c": lambda x: x["category"].astype(str).isin(["2b", "2c"]),
        "all_except_2b2c": lambda x: ~x["category"].astype(str).isin(["2b", "2c"]),
        "tiny_lt_100_gt_voxels": lambda x: x["pixels"].astype(int) < 100,
        "2a": lambda x: x["category"].astype(str) == "2a",
        "2c": lambda x: x["category"].astype(str) == "2c",
        "2d": lambda x: x["category"].astype(str) == "2d",
    }
    rows = []
    details = {}
    for offset, (group, grouper) in enumerate(groupers.items()):
        subset = merged.loc[grouper(merged)].copy()
        values = subset["interaction_delta"].to_numpy(np.float64)
        record = {
            "update": update,
            "group": group,
            "findings": len(subset),
            "cases": int(subset["file"].nunique()),
            "mean_delta_allcategory": float(subset["delta_allcategory"].mean()),
            "mean_delta_multiscale": float(subset["delta_multiscale"].mean()),
            "mean_interaction_delta": float(values.mean()),
            "median_interaction_delta": float(np.median(values)),
            "finding_level_95_ci": finding_bootstrap(values, samples, seed + offset),
            "case_clustered_95_ci": case_bootstrap(
                subset, "interaction_delta", samples, seed + offset
            ),
        }
        details[group] = record
        rows.append(record)
    return rows, details


def main() -> int:
    args = parse_args()
    branches = {
        "allcategory_1over1": args.allcategory_source,
        "multiscale_2b2c": args.multiscale_source,
    }
    all_paired: dict[tuple[str, int], pd.DataFrame] = {}
    result: dict[str, Any] = {
        "samples": args.samples,
        "seed": args.seed,
        "branches": {},
    }
    subgroup_output = []
    trajectory = []
    paired_output = []

    for branch, source in branches.items():
        full = args.root / "full_eval" / branch
        baseline_summary, baseline = load_variant(full / "baseline")
        branch_result: dict[str, Any] = {"baseline": baseline_summary, "updates": {}}
        for update in (25, 50, 100):
            adapter_summary, adapter = load_variant(full / f"update_{update}")
            residual_path = (
                full / f"residual_diagnostics_update_{update}.csv"
                if update in (25, 50)
                else source / "full_eval/residual_diagnostics.csv"
            )
            residual = load_residual(residual_path)
            paired = paired_frame(baseline, adapter, residual, branch, update)
            all_paired[(branch, update)] = paired
            paired_output.append(paired)
            paired_summary = summarize_paired(paired)
            delta = float(
                adapter_summary["mean_global_dice_per_finding"]
                - baseline_summary["mean_global_dice_per_finding"]
            )
            hit_delta = int(adapter_summary["total_hits"] - baseline_summary["total_hits"])
            bootstrap = {
                "finding_level_95_ci": finding_bootstrap(
                    paired["dice_delta"].to_numpy(np.float64),
                    args.samples,
                    args.seed,
                ),
                "case_clustered_95_ci": case_bootstrap(
                    paired, "dice_delta", args.samples, args.seed
                ),
            }
            label = (
                label_early(
                    delta,
                    hit_delta,
                    paired_summary["new_hits"],
                    paired_summary["lost_hits"],
                )
                if update in (25, 50)
                else "NEGATIVE"
            )
            branch_result["updates"][str(update)] = {
                "summary": adapter_summary,
                "dice_delta": delta,
                "hit_delta": hit_delta,
                "paired": paired_summary,
                "bootstrap": bootstrap,
                "post_hoc_label": label,
            }
            subgroup_output.extend(subgroup_rows(paired, branch, update))
            checkpoint = source / f"checkpoints/prompt_adapter_update_{update}.pth"
            trajectory.append(
                {
                    "branch": branch,
                    "update": update,
                    "dice_delta": delta,
                    "hit_delta": hit_delta,
                    "adapter_parameter_norm": adapter_norm(checkpoint),
                    "mean_residual_base_query_ratio": float(
                        residual["residual_base_query_ratio"].mean()
                    ),
                    "maximum_residual_base_query_ratio": float(
                        residual["residual_base_query_ratio"].max()
                    ),
                    "mean_prediction_gt_volume_ratio": paired_summary[
                        "mean_prediction_gt_volume_ratio"
                    ],
                    "mean_false_positive_mm3": paired_summary[
                        "mean_false_positive_mm3"
                    ],
                    "mean_false_negative_mm3": paired_summary[
                        "mean_false_negative_mm3"
                    ],
                    "delta_mean_prediction_gt_volume_ratio": paired_summary[
                        "delta_mean_prediction_gt_volume_ratio"
                    ],
                    "delta_mean_false_positive_mm3": paired_summary[
                        "delta_mean_false_positive_mm3"
                    ],
                    "delta_mean_false_negative_mm3": paired_summary[
                        "delta_mean_false_negative_mm3"
                    ],
                    "pearson_residual_ratio_vs_delta": paired_summary[
                        "pearson_residual_ratio_vs_delta"
                    ],
                    "spearman_residual_ratio_vs_delta": paired_summary[
                        "spearman_residual_ratio_vs_delta"
                    ],
                }
            )
        trajectory.insert(
            len(trajectory) - 3,
            {
                "branch": branch,
                "update": 0,
                "dice_delta": 0.0,
                "hit_delta": 0,
                "adapter_parameter_norm": float("nan"),
                "mean_residual_base_query_ratio": 0.0,
                "maximum_residual_base_query_ratio": 0.0,
                "mean_prediction_gt_volume_ratio": float(
                    baseline["pred_gt_volume_ratio"].mean()
                ),
                "mean_false_positive_mm3": float(baseline["fp_mm3"].mean()),
                "mean_false_negative_mm3": float(baseline["fn_mm3"].mean()),
                "delta_mean_prediction_gt_volume_ratio": 0.0,
                "delta_mean_false_positive_mm3": 0.0,
                "delta_mean_false_negative_mm3": 0.0,
                "pearson_residual_ratio_vs_delta": float("nan"),
                "spearman_residual_ratio_vs_delta": float("nan"),
            },
        )
        result["branches"][branch] = branch_result

    pd.concat(paired_output, ignore_index=True).to_csv(
        args.root / "paired_metrics.csv", index=False
    )
    pd.DataFrame(trajectory).sort_values(["branch", "update"]).to_csv(
        args.root / "residual_trajectory.csv", index=False
    )
    pd.DataFrame(subgroup_output).to_csv(
        args.root / "subgroup_analysis.csv", index=False
    )

    interaction_output = []
    interaction_details = {}
    for update in (25, 50):
        rows, details = interaction_rows(
            all_paired[("allcategory_1over1", update)],
            all_paired[("multiscale_2b2c", update)],
            update,
            args.samples,
            args.seed,
        )
        interaction_output.extend(rows)
        interaction_details[str(update)] = details
    interaction_frame = pd.DataFrame(interaction_output)
    interaction_frame.to_csv(args.root / "architecture_interaction.csv", index=False)
    result["architecture_interaction"] = interaction_details
    (args.root / "bootstrap_results.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
