#!/usr/bin/env python3
"""Collect S3 inference-only sweep metrics."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import pandas as pd


def load_summary(run_dir: Path) -> dict:
    metrics_path = run_dir / "eval_rexrank_metrics_global.json"
    if not metrics_path.is_file():
        raise FileNotFoundError(metrics_path)
    with metrics_path.open() as f:
        return json.load(f)["summary"]


def load_category_values(run_dir: Path) -> dict[str, float | int | None]:
    path = run_dir / "per_category_metrics.csv"
    values: dict[str, float | int | None] = {}
    if not path.is_file():
        return values
    df = pd.read_csv(path)
    for category in ("2b", "2c", "2d"):
        row = df.loc[df["category"].astype(str).eq(category)]
        if row.empty:
            values[f"{category}_dice"] = None
            values[f"{category}_hit_rate"] = None
            values[f"{category}_n"] = None
            continue
        item = row.iloc[0]
        values[f"{category}_dice"] = float(item["mean_dice"])
        values[f"{category}_hit_rate"] = float(item["hit_rate"])
        values[f"{category}_n"] = int(item["n"])
    for optional in ("mean_voxel_precision", "mean_voxel_recall", "mean_fp_voxels"):
        if optional in df.columns:
            values[f"macro_{optional}"] = float(df[optional].mean())
    return values


def parse_setting_dir(path: Path) -> dict[str, str | float | int]:
    parts = path.name.split("__")
    parsed: dict[str, str | float | int] = {"setting": path.name}
    for part in parts:
        if part.startswith("step"):
            parsed["step"] = int(part.removeprefix("step"))
        elif part.startswith("rho"):
            parsed["rho"] = float(part.removeprefix("rho").replace("p", "."))
        elif part.startswith("eta"):
            parsed["eta"] = float(part.removeprefix("eta").replace("p", "."))
        elif part.startswith("policy"):
            parsed["policy"] = part.removeprefix("policy_")
    return parsed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-dir", type=Path, required=True)
    parser.add_argument("--output-csv", type=Path, default=None)
    parser.add_argument("--report", type=Path, default=None)
    args = parser.parse_args()

    rows = []
    for run_dir in sorted(args.base_dir.iterdir()):
        if not run_dir.is_dir():
            continue
        metrics_path = run_dir / "eval_rexrank_metrics_global.json"
        if not metrics_path.is_file():
            continue
        summary = load_summary(run_dir)
        row = {
            **parse_setting_dir(run_dir),
            "output_dir": str(run_dir),
            "mean_global_dice_per_finding": float(summary["mean_global_dice_per_finding"]),
            "mean_global_dice_per_case": float(summary["mean_global_dice_per_case"]),
            "hit_rate": float(summary["hit_rate"]),
            "hits": int(summary["total_hits"]),
            "misses": int(summary["total_misses"]),
        }
        row.update(load_category_values(run_dir))
        rows.append(row)

    if not rows:
        raise RuntimeError(f"No completed sweep outputs found under {args.base_dir}")

    rows.sort(key=lambda item: item["mean_global_dice_per_finding"], reverse=True)
    output_csv = args.output_csv or args.base_dir / "summary_all_settings.csv"
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = sorted({key for row in rows for key in row})
    preferred = [
        "setting", "step", "rho", "eta", "policy",
        "mean_global_dice_per_finding", "mean_global_dice_per_case",
        "hit_rate", "hits", "misses",
        "2b_dice", "2c_dice", "2d_dice",
        "2b_hit_rate", "2c_hit_rate", "2d_hit_rate",
        "macro_mean_voxel_precision", "macro_mean_voxel_recall", "macro_mean_fp_voxels",
        "output_dir",
    ]
    fieldnames = [key for key in preferred if key in fieldnames] + [
        key for key in fieldnames if key not in preferred
    ]
    with output_csv.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    report = args.report or args.base_dir / "report.txt"
    best = rows[0]
    lines = [
        f"Completed settings: {len(rows)}",
        f"Best setting: {best['setting']}",
        f"Best Dice/finding: {best['mean_global_dice_per_finding']:.6f}",
        f"Best Dice/case: {best['mean_global_dice_per_case']:.6f}",
        f"Best hit rate: {best['hit_rate']:.6f} ({best['hits']} hits)",
        "",
        f"Summary CSV: {output_csv}",
    ]
    report.write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
