#!/usr/bin/env python
"""Real-batch scale check for ReX loss ablations."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import os
import resource
import statistics
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch


REX_ROOT = Path(__file__).resolve().parents[1]
VOXTELL_ROOT = REX_ROOT / "VoxTell"
if str(VOXTELL_ROOT) not in sys.path:
    sys.path.insert(0, str(VOXTELL_ROOT))


def load_training_module():
    path = REX_ROOT / "scripts/train_voxtell_rex_full_nnunet_aug.py"
    spec = importlib.util.spec_from_file_location("train_voxtell_rex_full_nnunet_aug_debug", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--batches", type=int, default=20)
    p.add_argument("--output-dir", type=Path, default=REX_ROOT / "outputs/loss_debug")
    p.add_argument("--preprocessed-dir", type=Path, default=REX_ROOT / "data/rex_voxtell_preprocessed_v1")
    p.add_argument("--model-dir", type=Path, default=REX_ROOT / "VoxTell/voxtell_v1.1")
    p.add_argument(
        "--embedding-cache",
        type=Path,
        default=REX_ROOT
        / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt",
    )
    p.add_argument(
        "--resume",
        type=Path,
        default=REX_ROOT
        / "outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500/checkpoints/checkpoint_step_2000.pth",
    )
    p.add_argument("--max-train-cases", type=int, default=None)
    p.add_argument("--patch-size", type=int, nargs=3, default=(192, 192, 192))
    p.add_argument("--case-cache-size", type=int, default=8)
    p.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    p.add_argument("--gpu", type=int, default=0)
    p.add_argument("--amp", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--total-steps", type=int, default=4000)
    return p.parse_args()


def summarize(values: list[float]) -> dict[str, float]:
    arr = np.asarray(values, dtype=np.float64)
    q25, q75 = np.percentile(arr, [25, 75])
    return {
        "mean": float(arr.mean()),
        "median": float(np.median(arr)),
        "min": float(arr.min()),
        "max": float(arr.max()),
        "iqr": float(q75 - q25),
    }


def main() -> int:
    args = parse_args()
    train_mod = load_training_module()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.device == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but unavailable")
        torch.cuda.set_device(args.gpu)
        device = torch.device(f"cuda:{args.gpu}")
    else:
        device = torch.device("cpu")

    rows = train_mod.load_manifest(args.preprocessed_dir)
    train_cases = train_mod.build_case_records(rows, "train", args.max_train_cases)
    embedding_map = train_mod.load_embedding_map(args.embedding_cache)
    sampler = train_mod.RexPreprocessedSampler(
        args.preprocessed_dir,
        train_cases,
        embedding_map,
        tuple(args.patch_size),
        2,
        1,
        1.0,
        1.0,
        0.85,
        True,
        1,
        50,
        50,
        args.case_cache_size,
        None,
        False,
        "category_then_keyword",
        True,
        "anchor85_samecase15",
        0.85,
        0.15,
        True,
        True,
    )
    network = train_mod.instantiate_voxtell(
        args.model_dir,
        device,
        deep_supervision=True,
        enable_patch_presence_head=False,
    )
    ckpt = torch.load(args.resume, map_location="cpu", weights_only=False)
    network.load_state_dict(ckpt["network_weights"], strict=True)
    train_mod.configure_trainable(network, "full")
    network.train()
    optimizer = torch.optim.SGD(
        [p for p in network.parameters() if p.requires_grad],
        lr=1e-6,
        momentum=0.99,
        nesterov=True,
        weight_decay=3e-5,
    )

    common = {
        "voxel_bce_weighting": True,
        "voxel_dice_weighting": False,
        "bce_foreground_weight": 1.0,
        "bce_boundary_weight": 1.5,
        "bce_background_weight": 0.5,
        "bce_boundary_radius": 10,
        "empty_target_loss_mode": "bce_only",
        "empty_target_loss_weight": 0.5,
        "tversky_fp_weight": 0.3,
        "tversky_fn_weight": 0.7,
        "focal_tversky_gamma": 4.0 / 3.0,
        "focal_tversky_convention": "original_paper",
        "unified_focal_lambda": 0.5,
        "unified_focal_delta": 0.6,
        "unified_focal_gamma": 0.5,
        "boundary_warmup_fraction": 0.2,
        "boundary_normalize_sdf": True,
        "boundary_band_radius": 10,
        "total_steps": args.total_steps,
    }
    modes = [
        ("focal_tversky", {"boundary_loss_max_weight": 0.0}),
        ("unified_focal", {"boundary_loss_max_weight": 0.0}),
        ("unified_focal_boundary_probe", {"rex_loss_mode": "unified_focal_boundary", "boundary_loss_max_weight": 0.1}),
    ]
    output_rows: list[dict[str, Any]] = []
    for mode_name, overrides in modes:
        for batch_idx in range(args.batches):
            network.zero_grad(set_to_none=True)
            optimizer.zero_grad(set_to_none=True)
            image, embeddings, target, prompt_weights, meta = sampler.sample()
            image = image[None].to(device, non_blocking=True)
            embeddings = embeddings[None].to(device, non_blocking=True)
            target = target[None].to(device, non_blocking=True)
            prompt_weights = prompt_weights[None].to(device, non_blocking=True)
            kwargs = dict(common)
            kwargs["rex_loss_mode"] = overrides.get("rex_loss_mode", mode_name)
            kwargs.update({k: v for k, v in overrides.items() if k != "rex_loss_mode"})
            t0 = time.time()
            with torch.autocast(device.type, enabled=args.amp and device.type == "cuda"):
                logits = network(image, embeddings)
                loss, stats = train_mod.segmentation_loss(
                    logits,
                    target,
                    prompt_weights,
                    current_step=args.total_steps,
                    **kwargs,
                )
            scaler = torch.amp.GradScaler("cuda", init_scale=1.0, enabled=args.amp and device.type == "cuda")
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            grad_norm = torch.nn.utils.clip_grad_norm_(
                [p for p in network.parameters() if p.requires_grad],
                max_norm=1e9,
            )
            finite_grads = bool(torch.isfinite(grad_norm).item())
            for parameter in network.parameters():
                if parameter.requires_grad and parameter.grad is not None and not torch.isfinite(parameter.grad).all():
                    finite_grads = False
                    break
            elapsed = time.time() - t0
            gpu_mem_mb = (
                float(torch.cuda.max_memory_allocated(device) / (1024**2)) if device.type == "cuda" else 0.0
            )
            if device.type == "cuda":
                torch.cuda.reset_peak_memory_stats(device)
            output_rows.append(
                {
                    "mode": mode_name,
                    "batch_idx": batch_idx,
                    "case": meta["case"],
                    "loss": float(loss.detach().item()),
                    "grad_norm": float(grad_norm.detach().item()),
                    "time_sec": float(elapsed),
                    "gpu_mem_mb": gpu_mem_mb,
                    "cpu_rss_mb": float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024),
                    "finite_loss": int(torch.isfinite(loss).item()),
                    "finite_grad": int(finite_grads),
                    **{k: v for k, v in stats.items() if isinstance(v, (int, float, str))},
                }
            )
            print(json.dumps(output_rows[-1], default=str))

    csv_path = args.output_dir / "real_batch_loss_scale.csv"
    fieldnames = sorted({key for row in output_rows for key in row})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(output_rows)

    mode_groups = {mode: [row for row in output_rows if row["mode"] == mode] for mode, _ in modes}
    regional = [float(row["loss_nonempty"]) for row in mode_groups["unified_focal"]]
    raw_boundary = [abs(float(row["scale0_boundary_loss_raw"])) for row in mode_groups["unified_focal_boundary_probe"]]
    median_regional = statistics.median(regional)
    median_boundary = max(statistics.median(raw_boundary), 1e-8)
    selected_boundary_weight = min(0.1, 0.075 * median_regional / median_boundary)

    report_path = args.output_dir / "real_batch_loss_report.md"
    with report_path.open("w") as f:
        f.write("# Real-Batch ReX Loss Scale Check\n\n")
        f.write(f"- Batches per mode: `{args.batches}`\n")
        f.write(f"- Resume checkpoint: `{args.resume}`\n")
        f.write(f"- Selected boundary max weight: `{selected_boundary_weight:.6g}`\n")
        f.write("- Boundary selection rule: `0.075 * median(unified loss_nonempty) / median(abs(raw boundary))`, capped at `0.1`.\n\n")
        for mode, rows_for_mode in mode_groups.items():
            f.write(f"## {mode}\n\n")
            for key in ("loss", "loss_nonempty", "loss_empty", "grad_norm", "time_sec", "gpu_mem_mb", "cpu_rss_mb"):
                vals = [float(row[key]) for row in rows_for_mode if key in row and row[key] not in ("", None)]
                if vals:
                    f.write(f"- `{key}`: `{summarize(vals)}`\n")
            f.write("\n")
        f.write("## Safety Checks\n\n")
        f.write(f"- All finite losses: `{all(row['finite_loss'] for row in output_rows)}`\n")
        f.write(f"- All finite grad norms: `{all(row['finite_grad'] for row in output_rows)}`\n")
    print(json.dumps({"csv": str(csv_path), "report": str(report_path), "selected_boundary_weight": selected_boundary_weight}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
