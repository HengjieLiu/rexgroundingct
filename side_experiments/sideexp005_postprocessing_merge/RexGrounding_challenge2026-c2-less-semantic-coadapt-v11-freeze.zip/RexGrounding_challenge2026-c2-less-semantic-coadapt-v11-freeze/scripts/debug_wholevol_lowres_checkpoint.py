#!/usr/bin/env python3
"""Debug whole-volume low-res VoxTell checkpoints on filtered ReX validation cases."""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch


REX_ROOT = Path(__file__).resolve().parents[1]
VOXTELL_ROOT = REX_ROOT / "VoxTell"
if str(VOXTELL_ROOT) not in sys.path:
    sys.path.insert(0, str(VOXTELL_ROOT))
if str(REX_ROOT) not in sys.path:
    sys.path.insert(0, str(REX_ROOT))

from scripts.train_voxtell_rex_full import load_embedding_map  # noqa: E402
from scripts.train_voxtell_whole_volume_lowres_branch import (  # noqa: E402
    WholeVolumeLowresSampler,
    build_filtered_case_records,
    forward_lowres_ready,
)
from scripts.train_voxtell_coarse_branch_only import instantiate_lowres_model  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=REX_ROOT
        / "outputs/voxtell_rex_wholevol_lowres_filtered_from_wbce_step2000/checkpoints/checkpoint_step_900.pth",
    )
    parser.add_argument("--preprocessed-dir", type=Path, default=REX_ROOT / "data/rex_voxtell_preprocessed_v1")
    parser.add_argument("--model-dir", type=Path, default=REX_ROOT / "VoxTell/voxtell_v1.1")
    parser.add_argument(
        "--init-checkpoint",
        type=Path,
        default=REX_ROOT
        / "outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500/checkpoints/checkpoint_step_2000.pth",
    )
    parser.add_argument(
        "--embedding-cache",
        type=Path,
        default=REX_ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REX_ROOT / "outputs/voxtell_rex_wholevol_lowres_filtered_from_wbce_step2000/debug_step900",
    )
    parser.add_argument("--split", default="val")
    parser.add_argument("--max-cases", type=int, default=66)
    parser.add_argument("--num-samples", type=int, default=66)
    parser.add_argument("--lowres-size", type=int, default=96)
    parser.add_argument("--min-json-pixels", type=int, default=20000)
    parser.add_argument("--exclude-small-keywords", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--require-lung-keyword", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--target-downsample-mode", choices=["occupancy", "trilinear", "nearest"], default="occupancy")
    parser.add_argument("--thresholds", type=float, nargs="+", default=[0.01, 0.03, 0.05, 0.1, 0.2, 0.3, 0.5])
    parser.add_argument("--num-png", type=int, default=8)
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--train-mode", choices=["decoder-only", "full"], default="full")
    return parser.parse_args()


def dice_at_threshold(prob: torch.Tensor, target: torch.Tensor, threshold: float) -> tuple[float, int, int, int]:
    pred = prob > threshold
    tgt = target > 0.5
    inter = int((pred & tgt).sum().item())
    pred_vox = int(pred.sum().item())
    tgt_vox = int(tgt.sum().item())
    dice = 2 * inter / max(pred_vox + tgt_vox, 1)
    return float(dice), pred_vox, tgt_vox, inter


def save_png(path: Path, image: torch.Tensor, target: torch.Tensor, prob: torch.Tensor, title: str) -> None:
    target_np = target.detach().cpu().numpy() > 0.5
    prob_np = prob.detach().cpu().numpy()
    image_np = image.detach().cpu().numpy()
    z = int(target_np.sum(axis=(1, 2)).argmax())
    fig, axes = plt.subplots(1, 4, figsize=(14, 4))
    for ax in axes:
        ax.axis("off")
    axes[0].imshow(image_np[z], cmap="gray", vmin=-2, vmax=2)
    axes[0].set_title("CT lowres")
    axes[1].imshow(image_np[z], cmap="gray", vmin=-2, vmax=2)
    axes[1].contour(target_np[z], colors="lime", linewidths=0.8)
    axes[1].set_title("GT")
    axes[2].imshow(prob_np[z], cmap="magma", vmin=0, vmax=max(0.1, float(prob_np.max())))
    axes[2].set_title(f"prob max={prob_np.max():.3f}")
    axes[3].imshow(image_np[z], cmap="gray", vmin=-2, vmax=2)
    axes[3].contour(target_np[z], colors="lime", linewidths=0.8)
    axes[3].contour(prob_np[z] > 0.1, colors="red", linewidths=0.8)
    axes[3].set_title("GT + prob>0.1")
    fig.suptitle(title, fontsize=10)
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=160)
    plt.close(fig)


def main() -> int:
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device(f"cuda:{args.gpu}" if args.device == "cuda" and torch.cuda.is_available() else "cpu")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    embedding_map = load_embedding_map(args.embedding_cache)
    cases = build_filtered_case_records(args.preprocessed_dir, args.split, args.max_cases, args)
    sampler = WholeVolumeLowresSampler(
        args.preprocessed_dir,
        cases,
        embedding_map,
        args.lowres_size,
        positive_prompts=1,
        negative_prompts=0,
        positive_loss_weight=1.0,
        negative_loss_weight=0.0,
        target_downsample_mode=args.target_downsample_mode,
        cache_size=1,
    )

    model = instantiate_lowres_model(args, device)
    ckpt = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    missing, unexpected = model.load_state_dict(ckpt["network_weights"], strict=False)
    real_missing = [key for key in missing if key != "pos_embed"]
    if real_missing or unexpected:
        raise RuntimeError(f"Failed to load checkpoint: missing={real_missing[:10]} unexpected={unexpected[:10]}")
    model.eval()

    rows: list[dict[str, object]] = []
    threshold_sums = {
        thr: {"dice": [], "pred_vox": [], "target_vox": [], "inter": []} for thr in args.thresholds
    }
    prob_stats = []
    with torch.no_grad():
        for i in range(args.num_samples):
            image, embeddings, target, _, meta = sampler.sample()
            image_b = image[None].to(device)
            embeddings_b = embeddings[None].to(device)
            target_b = target[None].to(device)
            logits = forward_lowres_ready(model, image_b, embeddings_b)
            prob = torch.sigmoid(logits[0, 0]).float().cpu()
            tgt = target[0].float().cpu()
            img = image[0].float().cpu()
            gt_prob = prob[tgt > 0.5]
            bg_prob = prob[tgt <= 0.5]
            stat = {
                "sample": i,
                "case": meta["case"],
                "finding_idx": meta["positive_indices"][0],
                "json_pixels": meta["positive_json_pixels"][0],
                "target_voxels": int((tgt > 0.5).sum().item()),
                "prob_max": float(prob.max().item()),
                "prob_mean": float(prob.mean().item()),
                "gt_prob_mean": float(gt_prob.mean().item()) if gt_prob.numel() else float("nan"),
                "gt_prob_p95": float(torch.quantile(gt_prob, 0.95).item()) if gt_prob.numel() else float("nan"),
                "bg_prob_mean": float(bg_prob.mean().item()) if bg_prob.numel() else float("nan"),
                "bg_prob_p95": float(torch.quantile(bg_prob, 0.95).item()) if bg_prob.numel() else float("nan"),
            }
            prob_stats.append(stat)
            for thr in args.thresholds:
                dice, pred_vox, target_vox, inter = dice_at_threshold(prob, tgt, thr)
                rows.append({**stat, "threshold": thr, "dice": dice, "pred_voxels": pred_vox, "intersection": inter})
                threshold_sums[thr]["dice"].append(dice)
                threshold_sums[thr]["pred_vox"].append(pred_vox)
                threshold_sums[thr]["target_vox"].append(target_vox)
                threshold_sums[thr]["inter"].append(inter)
            if i < args.num_png:
                title = f"{meta['case']} finding {meta['positive_indices'][0]} target={stat['target_voxels']}"
                save_png(args.output_dir / "png" / f"sample_{i:03d}.png", img, tgt, prob, title)

    with (args.output_dir / "per_sample_thresholds.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with (args.output_dir / "probability_stats.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(prob_stats[0].keys()))
        writer.writeheader()
        writer.writerows(prob_stats)

    summary = []
    for thr, values in threshold_sums.items():
        summary.append(
            {
                "threshold": thr,
                "mean_dice": float(np.mean(values["dice"])),
                "median_dice": float(np.median(values["dice"])),
                "mean_pred_voxels": float(np.mean(values["pred_vox"])),
                "median_pred_voxels": float(np.median(values["pred_vox"])),
                "mean_target_voxels": float(np.mean(values["target_vox"])),
                "mean_intersection": float(np.mean(values["inter"])),
            }
        )
    with (args.output_dir / "threshold_summary.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        writer.writeheader()
        writer.writerows(summary)
    with (args.output_dir / "debug_summary.json").open("w") as f:
        json.dump({"checkpoint": str(args.checkpoint), "num_cases": len(cases), "summary": summary}, f, indent=2)

    print(json.dumps({"checkpoint": str(args.checkpoint), "num_cases": len(cases), "summary": summary}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
