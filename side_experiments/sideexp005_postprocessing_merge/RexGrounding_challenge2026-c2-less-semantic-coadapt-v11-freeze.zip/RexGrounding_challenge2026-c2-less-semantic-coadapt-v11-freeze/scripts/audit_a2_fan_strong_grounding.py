#!/usr/bin/env python3
"""FAN attention/feature grounding diagnostics for the A2 strong-checkpoint run."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
for candidate in (ROOT, ROOT / "VoxTell"):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from scripts.diagnose_token_image_text_phase0 import (  # noqa: E402
    KEYWORDS,
    PATHOLOGY,
    clean_piece,
    key,
    load_maps,
    means,
    pad_and_crop,
    ratio,
    readable_word_groups,
)
from scripts.diagnose_token_image_text_phase0b_gate import (  # noqa: E402
    make_predictor,
    run_model,
    selected_records,
)
from scripts.run_controlled_fixed30_validation import DEFAULT_CACHE, build_manifest  # noqa: E402
from scripts.run_voxtell_rex_inference import (  # noqa: E402
    load_image,
    load_reference_mask_for_window_diagnostic,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", required=True, choices=["A2_FAN_direct", "A2_FAN_preserve"])
    parser.add_argument("--update", required=True, type=int)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument(
        "--token-cache",
        type=Path,
        default=ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt",
    )
    parser.add_argument("--pooled-cache", type=Path, default=DEFAULT_CACHE)
    parser.add_argument(
        "--selected-findings",
        type=Path,
        default=ROOT
        / "outputs/prompt_standardization_rule_only_v1"
        / "stratified30_six_variant_ablation_v1"
        / "prepared_inputs/selected_findings.csv",
    )
    parser.add_argument("--dataset-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--max-findings", type=int, default=8)
    parser.add_argument("--amp-dtype", choices=["bfloat16", "float16", "none"], default="bfloat16")
    return parser.parse_args()


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    fieldnames: list[str] = []
    for row in rows:
        for name in row:
            if name not in fieldnames:
                fieldnames.append(name)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def attention_entropy(weights: torch.Tensor, valid_mask: torch.Tensor | None = None) -> dict[str, float]:
    values = weights.detach().float()
    if valid_mask is not None:
        mask = valid_mask.detach().bool()
        while mask.ndim < values.ndim:
            mask = mask.unsqueeze(0)
        values = values.masked_fill(~mask, 0.0)
        normalizer = values.sum(dim=-1, keepdim=True).clamp_min(1e-12)
        values = values / normalizer
        valid_count = int(valid_mask.detach().bool().sum().item())
    else:
        valid_count = int(values.shape[-1])
    clamped = values.clamp_min(1e-12)
    entropy = -(clamped * clamped.log()).sum(dim=-1)
    denom = max(math.log(max(valid_count, 2)), 1e-12)
    max_weight = values.amax(dim=-1)
    return {
        "valid_keys": valid_count,
        "entropy_mean": float(entropy.mean().item()),
        "entropy_norm_mean": float((entropy / denom).mean().item()),
        "effective_keys_mean": float(torch.exp(entropy).mean().item()),
        "max_weight_mean": float(max_weight.mean().item()),
        "max_weight_max": float(max_weight.amax().item()),
    }


def downsample_bool(mask: torch.Tensor, shape_dhw: tuple[int, int, int]) -> torch.Tensor:
    return F.adaptive_max_pool3d(mask[None, None].float(), output_size=shape_dhw)[0, 0].bool()


def load_lobe_patch(record: dict[str, Any], padding: list[int], starts: list[int]) -> torch.Tensor | None:
    stem = str(record["case"]).removesuffix(".nii.gz").removesuffix(".nii")
    lobe_path = ROOT / "data/rex_lobe_labels_preprocessed_v1/val" / f"{stem}.npz"
    if not lobe_path.is_file():
        return None
    with np.load(lobe_path) as payload:
        lobe = torch.from_numpy(np.asarray(payload["lobe_label"], dtype=np.uint8))
    lobe_padded = F.pad(lobe, padding)
    return lobe_padded[tuple(slice(start, start + 192) for start in starts)]


def downsample_lobe(lobe_patch: torch.Tensor | None, shape_dhw: tuple[int, int, int]) -> torch.Tensor | None:
    if lobe_patch is None:
        return None
    return F.interpolate(
        lobe_patch[None, None].float(),
        size=shape_dhw,
        mode="nearest",
    )[0, 0].to(torch.uint8)


def keyword_metric_rows(
    *,
    base: dict[str, Any],
    token_strings: list[str],
    token_ids: list[int],
    token_attention: torch.Tensor,
    target_small: torch.Tensor,
    lobe_small: torch.Tensor | None,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    word_groups = readable_word_groups(token_strings)
    for piece, group_indices in word_groups:
        clean = clean_piece(piece)
        attention = token_attention[group_indices].mean(dim=0)
        row_base = {
            **base,
            "token_index": "+".join(map(str, group_indices)),
            "token_id": "+".join(str(token_ids[index]) for index in group_indices),
            "token": "+".join(token_strings[index] for index in group_indices),
            "clean_token": clean,
        }
        if clean in {"left", "right"} and lobe_small is not None:
            correct = lobe_small >= 4 if clean == "left" else (lobe_small >= 1) & (lobe_small <= 3)
            opposite = (lobe_small >= 1) & (lobe_small <= 3) if clean == "left" else lobe_small >= 4
            inside_mean = means(attention, correct)
            outside_mean = means(attention, opposite)
            if math.isfinite(inside_mean) and math.isfinite(outside_mean):
                rows.append(
                    {
                        **row_base,
                        "metric": "laterality",
                        "inside_mean": inside_mean,
                        "outside_mean": outside_mean,
                        "ratio": ratio(inside_mean, outside_mean),
                    }
                )
        if clean in PATHOLOGY:
            body = (lobe_small > 0) if lobe_small is not None else torch.ones_like(target_small)
            outside = body & ~target_small
            inside_mean = means(attention, target_small)
            outside_mean = means(attention, outside)
            if math.isfinite(inside_mean) and math.isfinite(outside_mean):
                rows.append(
                    {
                        **row_base,
                        "metric": "pathology_gt",
                        "inside_mean": inside_mean,
                        "outside_mean": outside_mean,
                        "ratio": ratio(inside_mean, outside_mean),
                    }
                )
    text = str(base["finding"]).lower()
    if lobe_small is not None and ("upper lobe" in text or "lower lobe" in text):
        sides = {side for side in ("left", "right") if side in text}
        levels = {level for level in ("upper", "lower") if f"{level} lobe" in text}
        lobe_labels = {
            ("right", "upper"): 1,
            ("right", "lower"): 3,
            ("left", "upper"): 4,
            ("left", "lower"): 5,
        }
        mentioned = (
            lobe_small == lobe_labels[(next(iter(sides)), next(iter(levels)))]
            if len(sides) == 1 and len(levels) == 1
            else None
        )
        anatomy_indices = [
            index
            for word, indices in word_groups
            if word in {"upper", "lower", "lobe"}
            for index in indices
        ]
        if mentioned is not None and anatomy_indices:
            anatomy_attention = token_attention[anatomy_indices].mean(dim=0)
            other = (lobe_small > 0) & ~mentioned
            inside_mean = means(anatomy_attention, mentioned)
            outside_mean = means(anatomy_attention, other)
            if math.isfinite(inside_mean) and math.isfinite(outside_mean):
                rows.append(
                    {
                        **base,
                        "token_index": "+".join(map(str, anatomy_indices)),
                        "token_id": "",
                        "token": "lobe_phrase",
                        "clean_token": "lobe_phrase",
                        "metric": "lobe",
                        "inside_mean": inside_mean,
                        "outside_mean": outside_mean,
                        "ratio": ratio(inside_mean, outside_mean),
                    }
                )
    return rows


@torch.inference_mode()
def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not args.checkpoint.is_file():
        raise FileNotFoundError(args.checkpoint)
    args.experiment_dir = args.output_dir / "manifest_build"
    args.experiment_dir.mkdir(parents=True, exist_ok=True)
    manifest_path, _, selected_sha = build_manifest(args)
    records = selected_records(json.loads(manifest_path.read_text()), args.max_findings)
    token_map, pooled_map = load_maps(args.token_cache, args.pooled_cache)
    device = torch.device("cuda")
    amp_dtype = {"bfloat16": torch.bfloat16, "float16": torch.float16, "none": None}[args.amp_dtype]

    predictor = make_predictor(args.output_dir, f"{args.arm}_u{args.update}", args.checkpoint.resolve(), device)
    model = predictor.network.eval().to(device)
    if not getattr(model, "fan_image_text_blocks", None):
        raise RuntimeError("Model has no FAN image-text blocks")
    model.capture_fan_image_text_attention = True

    attention_rows: list[dict[str, Any]] = []
    audit_rows: list[dict[str, Any]] = []
    metadata: list[dict[str, Any]] = []
    for sample_index, record in enumerate(records):
        cache_key = key(record)
        token = token_map[cache_key]
        pooled = pooled_map[cache_key][None, None].to(device)
        contextual = token["feature"][None, None].to(device)
        valid = torch.ones(contextual.shape[:3], dtype=torch.bool, device=device)

        image, properties = load_image(ROOT / "data/ct_rate_volumes_fixed" / record["case"])
        data, bbox, original_shape = predictor.preprocess(image)
        target = load_reference_mask_for_window_diagnostic(
            ROOT / "data/segmentations" / record["case"],
            1,
            tuple(original_shape),
            bbox,
            image_properties=properties,
            finding_ids=[record["finding_idx"]],
        )[0]
        patch, target_patch, starts, padding = pad_and_crop(data, target)
        lobe_patch = load_lobe_patch(record, padding, starts)

        _ = run_model(
            model,
            patch[None].to(device),
            pooled,
            contextual,
            valid,
            amp_dtype,
        )
        token_strings = list(token["strings"])
        token_ids = [int(value) for value in token["ids"]]
        for level, audit in sorted(model.last_fan_image_text_audits.items()):
            shape = tuple(int(value) for value in audit["spatial_shape"])
            base = {
                "arm": args.arm,
                "update": args.update,
                "case": record["case"],
                "finding_idx": int(record["finding_idx"]),
                "finding": record["prompt"],
                "sample_index": sample_index,
                "scale": level,
            }
            preserve = audit.get("preserve_projection") or {}
            audit_rows.append(
                {
                    **base,
                    "feature_rms_before": audit.get("feature_rms_before"),
                    "fan_feature_rms_after": audit.get("feature_rms_after"),
                    "fan_feature_rms_ratio": audit.get("feature_rms_ratio"),
                    "fan_cosine_before_after": audit.get("cosine_before_after"),
                    "preserve_relative_delta_norm": preserve.get("relative_delta_norm"),
                    "preserve_cosine_visual_enriched": preserve.get("cosine_visual_enriched"),
                    "preserve_rms_enriched_over_visual": preserve.get("rms_enriched_over_visual"),
                    "n_image": audit.get("n_image"),
                    "n_text": audit.get("n_text"),
                }
            )
            attention = model.last_fan_image_text_attention.get(level)
            if not attention:
                continue
            cross = attention["image_to_word"][0, 0].detach().float().cpu()
            joint = attention["joint"][0, 0].detach().float().cpu()
            valid_1d = torch.ones(cross.shape[-1], dtype=torch.bool)
            summary_base = {**base, "metric": "attention_summary", "token_index": "", "token_id": "", "token": "", "clean_token": ""}
            attention_rows.append(
                {
                    **summary_base,
                    "attention_kind": "image_to_word",
                    **attention_entropy(cross, valid_1d),
                }
            )
            attention_rows.append(
                {
                    **summary_base,
                    "attention_kind": "joint",
                    **attention_entropy(joint, None),
                }
            )
            # [heads, image, text] -> [text, D, H, W]
            token_attention = cross.mean(dim=0).reshape(*shape, -1).permute(3, 0, 1, 2)
            target_small = downsample_bool(target_patch, shape)
            lobe_small = downsample_lobe(lobe_patch, shape)
            attention_rows.extend(
                keyword_metric_rows(
                    base=base,
                    token_strings=token_strings,
                    token_ids=token_ids,
                    token_attention=token_attention,
                    target_small=target_small,
                    lobe_small=lobe_small,
                )
            )
        metadata.append(
            {
                **record,
                "token_ids": token_ids,
                "token_strings": token_strings,
                "crop_start_after_padding": starts,
                "padding_wxyz_pairs": padding,
                "target_voxels_in_crop": int(target_patch.sum().item()),
            }
        )
        torch.cuda.empty_cache()

    write_csv(args.output_dir / "fan_attention_grounding_metrics.csv", attention_rows)
    write_csv(args.output_dir / "fan_feature_audit.csv", audit_rows)
    payload = {
        "arm": args.arm,
        "update": args.update,
        "checkpoint": str(args.checkpoint.resolve()),
        "selected_findings_sha256": selected_sha,
        "samples": metadata,
        "notes": (
            "FAN image_to_word attention is a per-image-token distribution over text tokens; "
            "the token spatial maps here are diagnostic projections and are not calibrated probabilities."
        ),
    }
    (args.output_dir / "fan_grounding_metadata.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"samples": len(metadata), "attention_rows": len(attention_rows), "audit_rows": len(audit_rows)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
