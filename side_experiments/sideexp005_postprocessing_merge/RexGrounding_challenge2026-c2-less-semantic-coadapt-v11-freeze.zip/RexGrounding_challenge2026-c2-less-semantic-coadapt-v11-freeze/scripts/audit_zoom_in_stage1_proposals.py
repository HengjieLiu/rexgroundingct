#!/usr/bin/env python3
"""Audit connected-component proposals for Zoom-In Inference Stage 1."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import ndimage
from tqdm import tqdm


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EXPERIMENT_ROOT = ROOT / "outputs/dual_s3_two_stage_zoom96"
THRESHOLDS = (0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40)
CANDIDATE_FIELDS = [
    "threshold", "case", "channel", "finding_idx", "category", "pixels",
    "component_id", "component_voxels", "component_d0", "component_d1",
    "component_h0", "component_h1", "component_w0", "component_w1",
    "peak_d", "peak_h", "peak_w", "peak_probability", "large_proposal",
    "roi_requested_d0", "roi_requested_d1", "roi_requested_h0", "roi_requested_h1",
    "roi_requested_w0", "roi_requested_w1", "roi_valid_d0", "roi_valid_d1",
    "roi_valid_h0", "roi_valid_h1", "roi_valid_w0", "roi_valid_w1",
    "roi_overlaps_gt",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--probability-dir",
        type=Path,
        default=DEFAULT_EXPERIMENT_ROOT / "context_probabilities",
    )
    parser.add_argument(
        "--preprocessed-dir",
        type=Path,
        default=ROOT / "data/rex_voxtell_preprocessed_v1",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=DEFAULT_EXPERIMENT_ROOT / "threshold_audit"
    )
    parser.add_argument("--split", default="val")
    parser.add_argument("--thresholds", type=float, nargs="+", default=THRESHOLDS)
    parser.add_argument("--roi-size", type=int, default=96)
    parser.add_argument(
        "--allow-experimental-roi-size",
        action="store_true",
        help="Allow this reusable audit outside the fixed native-96 Stage-1 protocol.",
    )
    parser.add_argument("--cases", nargs="+", default=None)
    parser.add_argument("--max-findings", type=int, default=None)
    return parser.parse_args()


def probability_path(directory: Path, case: str) -> Path:
    stem = case.removesuffix(".nii.gz").removesuffix(".nii")
    return directory / f"{stem}.npz"


def load_manifest(path: Path, split: str, cases: set[str] | None) -> list[dict]:
    rows = []
    with path.open() as handle:
        for line in handle:
            row = json.loads(line)
            if row["split"] != split or row.get("status") != "processed":
                continue
            if cases is not None and row["case"] not in cases:
                continue
            rows.append(row)
    rows.sort(key=lambda row: row["case"])
    return rows


def size_bin(pixels: int) -> str:
    if pixels < 100:
        return "tiny_lt100"
    if pixels < 1_000:
        return "small_100_999"
    if pixels < 10_000:
        return "medium_1k_9999"
    return "large_ge10k"


def roi_bounds(center: tuple[int, int, int], shape: tuple[int, ...], size: int) -> dict:
    requested_start = tuple(int(value) - size // 2 for value in center)
    requested_stop = tuple(value + size for value in requested_start)
    valid_start = tuple(max(0, value) for value in requested_start)
    valid_stop = tuple(min(int(limit), value) for limit, value in zip(shape, requested_stop))
    return {
        "requested_start": requested_start,
        "requested_stop": requested_stop,
        "valid_start": valid_start,
        "valid_stop": valid_stop,
    }


def slices_from_bounds(start: tuple[int, ...], stop: tuple[int, ...]) -> tuple[slice, ...]:
    return tuple(slice(a, b) for a, b in zip(start, stop))


def component_candidate_rows(
    probability: np.ndarray,
    target: np.ndarray,
    threshold: float,
    case: str,
    channel: int,
    finding_idx: int,
    category: str,
    pixels: int,
    roi_size: int,
) -> tuple[list[dict], dict]:
    structure = np.ones((3, 3, 3), dtype=np.uint8)
    labels, count = ndimage.label(probability >= threshold, structure=structure)
    objects = ndimage.find_objects(labels)
    union = np.zeros(probability.shape, dtype=bool)
    rows: list[dict] = []
    component_sizes: list[int] = []
    large_count = 0
    any_hit = False
    centroid = None
    target_coords = np.argwhere(target)
    if target_coords.size:
        centroid = target_coords.mean(axis=0)
    centroid_covered = False

    for component_id, component_slice in enumerate(objects, start=1):
        if component_slice is None:
            continue
        local_labels = labels[component_slice]
        member = local_labels == component_id
        component_voxels = int(member.sum())
        component_sizes.append(component_voxels)
        local_probability = probability[component_slice]
        peak_flat = int(np.argmax(np.where(member, local_probability, -np.inf)))
        peak_local = np.unravel_index(peak_flat, member.shape)
        component_start = tuple(int(axis.start) for axis in component_slice)
        component_stop = tuple(int(axis.stop) for axis in component_slice)
        peak = tuple(start + int(offset) for start, offset in zip(component_start, peak_local))
        component_extent = tuple(b - a for a, b in zip(component_start, component_stop))
        large = any(value > roi_size for value in component_extent)
        bounds = roi_bounds(peak, probability.shape, roi_size)
        overlaps = False
        if large:
            large_count += 1
        else:
            valid_slice = slices_from_bounds(bounds["valid_start"], bounds["valid_stop"])
            union[valid_slice] = True
            overlaps = bool(target[valid_slice].any())
            any_hit = any_hit or overlaps
            if centroid is not None:
                centroid_covered = centroid_covered or all(
                    start <= value < stop
                    for value, start, stop in zip(
                        centroid, bounds["valid_start"], bounds["valid_stop"]
                    )
                )
        row = {
            "threshold": threshold,
            "case": case,
            "channel": channel,
            "finding_idx": finding_idx,
            "category": category,
            "pixels": pixels,
            "component_id": component_id,
            "component_voxels": component_voxels,
            "component_d0": component_start[0], "component_d1": component_stop[0],
            "component_h0": component_start[1], "component_h1": component_stop[1],
            "component_w0": component_start[2], "component_w1": component_stop[2],
            "peak_d": peak[0], "peak_h": peak[1], "peak_w": peak[2],
            "peak_probability": float(probability[peak]),
            "large_proposal": int(large),
            "roi_requested_d0": bounds["requested_start"][0],
            "roi_requested_d1": bounds["requested_stop"][0],
            "roi_requested_h0": bounds["requested_start"][1],
            "roi_requested_h1": bounds["requested_stop"][1],
            "roi_requested_w0": bounds["requested_start"][2],
            "roi_requested_w1": bounds["requested_stop"][2],
            "roi_valid_d0": bounds["valid_start"][0],
            "roi_valid_d1": bounds["valid_stop"][0],
            "roi_valid_h0": bounds["valid_start"][1],
            "roi_valid_h1": bounds["valid_stop"][1],
            "roi_valid_w0": bounds["valid_start"][2],
            "roi_valid_w1": bounds["valid_stop"][2],
            "roi_overlaps_gt": int(overlaps),
        }
        rows.append(row)

    gt_voxels = int(target.sum())
    union_voxels = int(union.sum())
    stats = {
        "threshold": threshold,
        "case": case,
        "channel": channel,
        "finding_idx": finding_idx,
        "category": category,
        "focality": "focal" if category.startswith("2") else "diffuse",
        "pixels": pixels,
        "size_bin": size_bin(pixels),
        "gt_voxels": gt_voxels,
        "candidate_count": int(count),
        "zoom_roi_count": int(count - large_count),
        "large_proposal_count": large_count,
        "no_candidates": int(count == 0),
        "roi_recall_hit": int(any_hit),
        "gt_centroid_covered": int(centroid_covered),
        "gt_voxel_coverage": float((target & union).sum() / max(1, gt_voxels)),
        "union_roi_voxels": union_voxels,
        "union_roi_fraction": float(union_voxels / probability.size),
        "volume_voxels": int(probability.size),
        "component_size_min": min(component_sizes) if component_sizes else 0,
        "component_size_median": float(np.median(component_sizes)) if component_sizes else 0.0,
        "component_size_mean": float(np.mean(component_sizes)) if component_sizes else 0.0,
        "component_size_max": max(component_sizes) if component_sizes else 0,
    }
    return rows, stats


def strata_for_row(row: dict) -> list[str]:
    return ["all", row["focality"], row["size_bin"], f"category_{row['category']}"]


def summarize(rows: list[dict], thresholds: list[float]) -> list[dict]:
    strata = sorted({stratum for row in rows for stratum in strata_for_row(row)})
    result = []
    for threshold in thresholds:
        threshold_rows = [row for row in rows if row["threshold"] == threshold]
        for stratum in strata:
            group = [row for row in threshold_rows if stratum in strata_for_row(row)]
            if not group:
                continue
            component_medians = [row["component_size_median"] for row in group]
            result.append(
                {
                    "threshold": threshold,
                    "stratum": stratum,
                    "findings": len(group),
                    "roi_recall": float(np.mean([row["roi_recall_hit"] for row in group])),
                    "gt_centroid_coverage": float(np.mean([row["gt_centroid_covered"] for row in group])),
                    "mean_gt_voxel_coverage": float(np.mean([row["gt_voxel_coverage"] for row in group])),
                    "mean_roi_count": float(np.mean([row["zoom_roi_count"] for row in group])),
                    "median_roi_count": float(np.median([row["zoom_roi_count"] for row in group])),
                    "mean_union_roi_fraction": float(np.mean([row["union_roi_fraction"] for row in group])),
                    "median_union_roi_fraction": float(np.median([row["union_roi_fraction"] for row in group])),
                    "no_candidate_findings": int(sum(row["no_candidates"] for row in group)),
                    "large_proposals": int(sum(row["large_proposal_count"] for row in group)),
                    "component_size_median_of_finding_medians": float(np.median(component_medians)),
                    "component_size_max": int(max(row["component_size_max"] for row in group)),
                }
            )
    return result


def select_threshold(summary: list[dict]) -> dict:
    overall = [row for row in summary if row["stratum"] == "all"]
    maximum = max(row["roi_recall"] for row in overall)
    eligible = [row for row in overall if row["roi_recall"] >= maximum - 0.01]
    highest = max(row["threshold"] for row in eligible)
    finalists = [row for row in eligible if row["threshold"] == highest]
    chosen = min(finalists, key=lambda row: row["mean_union_roi_fraction"])
    return {
        "selected_threshold": float(chosen["threshold"]),
        "maximum_roi_recall": float(maximum),
        "selected_roi_recall": float(chosen["roi_recall"]),
        "selected_mean_union_roi_fraction": float(chosen["mean_union_roi_fraction"]),
        "rule": "max recall; within 1 percentage point; highest threshold; tie lower union ROI volume",
        "selection_uses_final_dice": False,
        "eligible_thresholds": [float(row["threshold"]) for row in eligible],
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise RuntimeError(f"No rows for {path}")
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    thresholds = sorted(set(float(value) for value in args.thresholds))
    if tuple(thresholds) != THRESHOLDS:
        raise ValueError(f"Formal audit thresholds must be exactly {THRESHOLDS}")
    if args.roi_size != 96 and not args.allow_experimental_roi_size:
        raise ValueError("Zoom-In Stage 1 is fixed to native 96^3 ROIs")
    requested_cases = None if args.cases is None else set(args.cases)
    manifest = load_manifest(
        args.preprocessed_dir / "manifest.jsonl", args.split, requested_cases
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    finding_rows: list[dict] = []
    findings_done = 0
    candidate_path = args.output_dir / "per_candidate.csv"
    with candidate_path.open("w", newline="") as candidate_handle:
        candidate_writer = csv.DictWriter(candidate_handle, fieldnames=CANDIDATE_FIELDS)
        candidate_writer.writeheader()
        for case_row in tqdm(manifest, desc="Proposal audit", unit="case"):
            archive = probability_path(args.probability_dir, case_row["case"])
            if not archive.exists():
                raise FileNotFoundError(f"Missing context probabilities: {archive}")
            with np.load(archive, allow_pickle=False) as stored, np.load(
                case_row["cache_path"], allow_pickle=False
            ) as cached:
                probabilities = stored["probability"]
                finding_ids = [int(value) for value in stored["finding_ids"]]
                targets = cached["masks"].astype(bool, copy=False)
                if probabilities.shape != targets.shape:
                    raise ValueError(
                        f"{case_row['case']}: probability {probabilities.shape} != GT {targets.shape}"
                    )
                if finding_ids != [int(value) for value in case_row["finding_indices"]]:
                    raise ValueError(f"{case_row['case']}: finding order mismatch")
                for channel, finding_idx in enumerate(finding_ids):
                    category = str(case_row.get("categories", {}).get(str(finding_idx), "unknown"))
                    pixels = int(case_row.get("json_pixels", {}).get(str(finding_idx), targets[channel].sum()))
                    for threshold in thresholds:
                        candidate_rows, stats = component_candidate_rows(
                            probabilities[channel], targets[channel], threshold,
                            case_row["case"], channel, finding_idx, category, pixels,
                            args.roi_size,
                        )
                        candidate_writer.writerows(candidate_rows)
                        finding_rows.append(stats)
                    findings_done += 1
                    if args.max_findings is not None and findings_done >= args.max_findings:
                        break
            if args.max_findings is not None and findings_done >= args.max_findings:
                break

    write_csv(args.output_dir / "per_finding_threshold.csv", finding_rows)
    summary_rows = summarize(finding_rows, thresholds)
    write_csv(args.output_dir / "threshold_audit.csv", summary_rows)
    selected = select_threshold(summary_rows)
    selected_dir = args.output_dir.parent / "selected_threshold"
    selected_dir.mkdir(parents=True, exist_ok=True)
    (selected_dir / "selected_threshold.json").write_text(
        json.dumps(selected, indent=2) + "\n"
    )
    summary_payload = {
        "configuration": {
            "thresholds": thresholds,
            "connectivity": 26,
            "keep_min_component_voxels": 1,
            "roi_size": [args.roi_size, args.roi_size, args.roi_size],
            "roi_center": "maximum probability voxel in connected component",
            "large_component_policy": "no zoom crop; context retained",
            "probability_comparison": ">= proposal threshold",
        },
        "selection": selected,
        "rows": summary_rows,
    }
    (args.output_dir / "threshold_summary.json").write_text(
        json.dumps(summary_payload, indent=2) + "\n"
    )
    print(json.dumps(selected, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
