#!/usr/bin/env python3
"""CPU representation/probe audit for matched PubMedBERT and BCLIP CLS caches."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from run_pubmedbert_lightweight_probes import run_task


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pubmedbert-cache", type=Path, required=True)
    parser.add_argument("--biomedclip-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    pbt = torch.load(args.pubmedbert_cache, map_location="cpu", weights_only=False)
    bclip = torch.load(args.biomedclip_cache, map_location="cpu", weights_only=False)
    key = lambda row: (str(row["split"]), str(row["case"]), int(row["finding_idx"]), str(row["prompt"]))
    if [key(row) for row in pbt["records"]] != [key(row) for row in bclip["records"]]:
        raise RuntimeError("PubMedBERT and BCLIP cache record order differs")
    records = pbt["records"]
    x = pbt["cls_embeddings"].float().numpy()
    y = bclip["cls_embeddings"].float().numpy()
    row_cos = np.sum(x * y, axis=1) / np.maximum(np.linalg.norm(x, axis=1) * np.linalg.norm(y, axis=1), 1e-12)
    rows: list[dict] = [
        {"analysis": "geometry", "embedding": "pubmedbert_cls", "metric": "mean_l2_norm", "value": float(np.linalg.norm(x, axis=1).mean()), "n": len(records)},
        {"analysis": "geometry", "embedding": "biomedclip_cls", "metric": "mean_l2_norm", "value": float(np.linalg.norm(y, axis=1).mean()), "n": len(records)},
        {"analysis": "geometry", "embedding": "pubmedbert_vs_biomedclip", "metric": "per_prompt_cosine_mean", "value": float(row_cos.mean()), "n": len(records)},
        {"analysis": "geometry", "embedding": "pubmedbert_vs_biomedclip", "metric": "per_prompt_cosine_std", "value": float(row_cos.std()), "n": len(records)},
    ]
    for embedding, values in (("pubmedbert_cls", x), ("biomedclip_cls", y)):
        for task in ("laterality", "lobe"):
            fold_rows = run_task(records, values, task)
            valid = [row for row in fold_rows if row.get("balanced_accuracy") is not None]
            base = fold_rows[0]
            rows.append({
                "analysis": "case_disjoint_linear_probe", "embedding": embedding, "task": task,
                "metric": "balanced_accuracy_mean", "value": float(np.mean([row["balanced_accuracy"] for row in valid])) if valid else None,
                "macro_f1": float(np.mean([row["macro_f1"] for row in valid])) if valid else None,
                "folds": len(valid), "n": base["n"], "n_cases": base["n_cases"],
                "class_counts": json.dumps(base["class_counts"], sort_keys=True),
            })
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(args.output, index=False)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
