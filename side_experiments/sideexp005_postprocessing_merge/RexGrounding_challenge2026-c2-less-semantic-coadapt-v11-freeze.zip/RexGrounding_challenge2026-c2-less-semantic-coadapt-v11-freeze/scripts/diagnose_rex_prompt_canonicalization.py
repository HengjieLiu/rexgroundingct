#!/usr/bin/env python
"""Diagnose original-vs-canonical ReX prompt behavior from saved audit outputs.

This script intentionally does not run VoxTell inference. It summarizes the
evidence available from the full-validation original/canonical audit and writes
explicit placeholders for analyses that require saved logits/probabilities.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

import numpy as np
import pandas as pd


REX_ROOT = Path(__file__).resolve().parents[1]
if str(REX_ROOT / "VoxTell") not in sys.path:
    sys.path.insert(0, str(REX_ROOT / "VoxTell"))

from voxtell.utils.prompt_standardization import (  # noqa: E402
    structured_attributes,
)


DEFAULT_SOURCE = REX_ROOT / "outputs/prompt_standardization_rule_only_v1/full_validation_original_vs_canonical_v1_2"
DEFAULT_OUTPUT = REX_ROOT / "outputs/prompt_standardization_rule_only_v1/diagnostic_original_vs_canonical_v1_2"
DEFAULT_SIDECAR = REX_ROOT / "data/prompt_variants/rex_prompt_variants_rule_only_v1_2.jsonl"
DEFAULT_EMBED_SIM = (
    REX_ROOT
    / "outputs/prompt_standardization_rule_only_v1/embeddings_v1_2/validation/embedding_variant_similarity.csv"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--sidecar", type=Path, default=DEFAULT_SIDECAR)
    parser.add_argument("--embedding-similarity", type=Path, default=DEFAULT_EMBED_SIM)
    parser.add_argument("--bootstrap-samples", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--folds", type=int, default=5)
    return parser.parse_args()


def load_sidecar(path: Path) -> dict[tuple[str, str, int], dict]:
    records: dict[tuple[str, str, int], dict] = {}
    with path.open() as handle:
        for line in handle:
            record = json.loads(line)
            records[(record["split"], record["case_id"], int(record["finding_idx"]))] = record
    return records


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower().strip().rstrip("."))


def token_count(text: str) -> int:
    return len(re.findall(r"[A-Za-z0-9]+(?:[-.][A-Za-z0-9]+)?", text))


def levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if len(a) < len(b):
        a, b = b, a
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, start=1):
        current = [i]
        for j, cb in enumerate(b, start=1):
            insert = current[j - 1] + 1
            delete = previous[j] + 1
            replace = previous[j - 1] + (ca != cb)
            current.append(min(insert, delete, replace))
        previous = current
    return previous[-1]


def bootstrap_ci_by_case(
    table: pd.DataFrame,
    value_column: str,
    samples: int,
    seed: int,
) -> tuple[float, float]:
    case_values = table.groupby("case", sort=True)[value_column].mean().to_numpy(dtype=np.float64)
    rng = np.random.default_rng(seed)
    means = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 500):
        count = min(500, samples - start)
        idx = rng.integers(0, len(case_values), size=(count, len(case_values)))
        means[start : start + count] = case_values[idx].mean(axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return float(low), float(high)


def summarize_thresholds(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (variant, threshold), selected in df.groupby(["variant", "threshold"], sort=True):
        case_dice = selected.groupby("case")["dice"].mean()
        rows.append(
            {
                "variant": variant,
                "threshold": threshold,
                "findings": int(selected[["case", "finding_idx"]].drop_duplicates().shape[0]),
                "cases": int(selected["case"].nunique()),
                "mean_global_dice_per_finding": selected["dice"].mean(),
                "mean_global_dice_per_case": case_dice.mean(),
                "hit_rate": selected["global_hit"].mean(),
                "hits": int(selected["global_hit"].sum()),
                "mean_precision": selected["precision"].mean(),
                "mean_recall": selected["positive_recall"].mean(),
                "mean_fp_volume_mm3": selected["fp_volume_mm3"].mean(),
                "mean_pred_voxels": selected["pred_voxels"].mean(),
                "empty_prediction_count": int(selected["empty_prediction"].sum()),
                "gross_oversegmentation_count": int(selected["gross_oversegmentation"].sum()),
                "mean_voxel_average_precision": selected["voxel_average_precision"].mean(),
                "mean_voxel_auroc": selected["voxel_auroc"].mean(),
                "source_threshold_grid": "existing_sparse_0.40_0.45_0.50",
            }
        )
    return pd.DataFrame(rows)


def paired_delta_table(df: pd.DataFrame, threshold: float) -> pd.DataFrame:
    selected = df[df["threshold"].eq(threshold)]
    pivot = selected.pivot_table(
        index=["case", "finding_idx", "category", "focality"],
        columns="variant",
        values=[
            "dice",
            "positive_recall",
            "precision",
            "fp_volume_mm3",
            "pred_voxels",
            "voxel_average_precision",
            "global_hit",
        ],
        aggfunc="first",
    )
    pivot.columns = [f"{metric}_{variant}" for metric, variant in pivot.columns]
    pivot = pivot.reset_index()
    for metric in ("dice", "positive_recall", "precision", "fp_volume_mm3", "pred_voxels", "voxel_average_precision"):
        pivot[f"{metric}_delta_canonical_minus_original"] = (
            pivot[f"{metric}_canonical_visual"] - pivot[f"{metric}_original"]
        )
    return pivot


def matched_operating_points(df: pd.DataFrame, samples: int, seed: int) -> pd.DataFrame:
    summary = summarize_thresholds(df)
    lookup = {(row.variant, row.threshold): row for row in summary.itertuples(index=False)}
    comparisons = [
        ("match_canonical_0p50_pred_volume", "original", "canonical_visual", 0.50, "mean_pred_voxels"),
        ("match_original_0p50_pred_volume", "canonical_visual", "original", 0.50, "mean_pred_voxels"),
        ("match_canonical_0p50_recall", "original", "canonical_visual", 0.50, "mean_recall"),
        ("match_original_0p50_recall", "canonical_visual", "original", 0.50, "mean_recall"),
        ("match_canonical_0p50_precision", "original", "canonical_visual", 0.50, "mean_precision"),
        ("match_original_0p50_precision", "canonical_visual", "original", 0.50, "mean_precision"),
    ]
    rows = []
    for name, candidate_variant, target_variant, target_threshold, field in comparisons:
        target = lookup[(target_variant, target_threshold)]
        candidates = summary[summary["variant"].eq(candidate_variant)].copy()
        candidates["match_error"] = (candidates[field] - getattr(target, field)).abs()
        nearest = candidates.sort_values(["match_error", "threshold"]).iloc[0]
        target_rows = df[df["variant"].eq(target_variant) & df["threshold"].eq(target_threshold)]
        candidate_rows = df[df["variant"].eq(candidate_variant) & df["threshold"].eq(nearest["threshold"])]
        merged = candidate_rows.merge(
            target_rows,
            on=["case", "finding_idx"],
            suffixes=("_candidate", "_target"),
        )
        merged["dice_delta_target_minus_candidate"] = merged["dice_target"] - merged["dice_candidate"]
        ci = bootstrap_ci_by_case(merged, "dice_delta_target_minus_candidate", samples, seed)
        rows.append(
            {
                "comparison": name,
                "target_variant": target_variant,
                "target_threshold": target_threshold,
                "target_metric": field,
                "target_metric_value": getattr(target, field),
                "candidate_variant": candidate_variant,
                "nearest_candidate_threshold": float(nearest["threshold"]),
                "candidate_metric_value": float(nearest[field]),
                "nearest_residual_abs": float(nearest["match_error"]),
                "target_dice": getattr(target, "mean_global_dice_per_finding"),
                "candidate_dice": float(nearest["mean_global_dice_per_finding"]),
                "dice_delta_target_minus_candidate": float(merged["dice_delta_target_minus_candidate"].mean()),
                "dice_delta_ci95_low_by_case": ci[0],
                "dice_delta_ci95_high_by_case": ci[1],
                "target_precision": getattr(target, "mean_precision"),
                "candidate_precision": float(nearest["mean_precision"]),
                "target_recall": getattr(target, "mean_recall"),
                "candidate_recall": float(nearest["mean_recall"]),
                "target_hit_rate": getattr(target, "hit_rate"),
                "candidate_hit_rate": float(nearest["hit_rate"]),
                "target_mean_pred_voxels": getattr(target, "mean_pred_voxels"),
                "candidate_mean_pred_voxels": float(nearest["mean_pred_voxels"]),
                "grid_note": "limited to existing thresholds; interpolation requires dense threshold sweep or saved logits",
            }
        )
    return pd.DataFrame(rows)


def assign_case_folds(df: pd.DataFrame, folds: int, seed: int) -> dict[str, int]:
    unique = df[["case", "finding_idx"]].drop_duplicates()
    counts = unique.groupby("case").size().sort_values(ascending=False)
    rng = np.random.default_rng(seed)
    buckets: list[list[str]] = [[] for _ in range(folds)]
    bucket_counts = [0] * folds
    for count, group in counts.groupby(counts):
        cases = list(group.index)
        rng.shuffle(cases)
        for case in cases:
            fold = int(np.argmin(bucket_counts))
            buckets[fold].append(case)
            bucket_counts[fold] += int(counts[case])
    return {case: fold for fold, cases in enumerate(buckets) for case in cases}


def crossfit_thresholds(df: pd.DataFrame, folds: int, samples: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    case_to_fold = assign_case_folds(df, folds, seed)
    with_folds = df.copy()
    with_folds["fold"] = with_folds["case"].map(case_to_fold)
    threshold_rows = []
    heldout_parts = []
    for fold in range(folds):
        train = with_folds[with_folds["fold"].ne(fold)]
        test = with_folds[with_folds["fold"].eq(fold)]
        for variant in ("original", "canonical_visual"):
            train_variant = train[train["variant"].eq(variant)]
            train_scores = train_variant.groupby("threshold")["dice"].mean()
            selected_threshold = float(train_scores.idxmax())
            test_selected = test[test["variant"].eq(variant) & test["threshold"].eq(selected_threshold)].copy()
            test_selected["selected_threshold"] = selected_threshold
            heldout_parts.append(test_selected)
            threshold_rows.append(
                {
                    "fold": fold,
                    "variant": variant,
                    "selected_threshold": selected_threshold,
                    "train_mean_dice": float(train_scores.loc[selected_threshold]),
                    "heldout_cases": int(test_selected["case"].nunique()),
                    "heldout_findings": int(test_selected[["case", "finding_idx"]].drop_duplicates().shape[0]),
                    "threshold_grid_note": "limited to existing thresholds 0.40/0.45/0.50",
                }
            )
    heldout = pd.concat(heldout_parts, ignore_index=True)
    summary_rows = []
    for variant, selected in heldout.groupby("variant"):
        case_dice = selected.groupby("case")["dice"].mean()
        summary_rows.append(
            {
                "variant": variant,
                "crossfit_mean_global_dice_per_finding": selected["dice"].mean(),
                "crossfit_mean_global_dice_per_case": case_dice.mean(),
                "precision": selected["precision"].mean(),
                "recall": selected["positive_recall"].mean(),
                "hit_rate": selected["global_hit"].mean(),
                "mean_pred_voxels": selected["pred_voxels"].mean(),
                "mean_fp_volume_mm3": selected["fp_volume_mm3"].mean(),
                "mean_voxel_average_precision": selected["voxel_average_precision"].mean(),
                "mean_voxel_auroc": selected["voxel_auroc"].mean(),
                "findings": int(selected[["case", "finding_idx"]].drop_duplicates().shape[0]),
                "cases": int(selected["case"].nunique()),
            }
        )
    summary = pd.DataFrame(summary_rows)
    paired = heldout.pivot_table(
        index=["case", "finding_idx"],
        columns="variant",
        values="dice",
        aggfunc="first",
    ).dropna()
    paired["dice_delta_canonical_minus_original"] = paired["canonical_visual"] - paired["original"]
    delta_ci = bootstrap_ci_by_case(
        paired.reset_index(), "dice_delta_canonical_minus_original", samples, seed + 88
    )
    summary["canonical_minus_original_dice_delta"] = np.nan
    summary["canonical_minus_original_ci95_low_by_case"] = np.nan
    summary["canonical_minus_original_ci95_high_by_case"] = np.nan
    row_idx = summary.index[summary["variant"].eq("canonical_visual")]
    if len(row_idx):
        idx = row_idx[0]
        original_mean = float(summary.loc[summary["variant"].eq("original"), "crossfit_mean_global_dice_per_finding"].iloc[0])
        canonical_mean = float(summary.loc[idx, "crossfit_mean_global_dice_per_finding"])
        summary.loc[idx, "canonical_minus_original_dice_delta"] = canonical_mean - original_mean
        summary.loc[idx, "canonical_minus_original_ci95_low_by_case"] = delta_ci[0]
        summary.loc[idx, "canonical_minus_original_ci95_high_by_case"] = delta_ci[1]
    return summary, pd.DataFrame(threshold_rows)


def compare_field(original_attrs: dict, canonical_attrs: dict, field: str) -> str:
    original = original_attrs.get(field)
    canonical = canonical_attrs.get(field)
    if original == canonical:
        return "preserved_exactly"
    if original in (None, [], "", "unknown") and canonical in (None, [], "", "unknown"):
        return "unavailable"
    if original not in (None, [], "", "unknown") and canonical in (None, [], "", "unknown"):
        return "unintentionally_removed"
    if original in (None, [], "", "unknown") and canonical not in (None, [], "", "unknown"):
        return "unsupported_addition"
    return "changed"


def taxonomy_flags(record: dict, canonical_attrs: dict) -> list[str]:
    original = record["original_prompt"]
    canonical = record["canonical_visual_prompt"]
    attrs = record.get("structured_attributes") or {}
    flags = []
    fields = {
        "observation": "wrong_or_weakened_abnormality_term",
        "laterality": "laterality_loss_or_change",
        "lobe": "lobe_or_segment_loss",
        "segment": "lobe_or_segment_loss",
        "relative_location": "relative_location_loss",
        "size_values_mm": "size_loss_or_change",
        "count": "count_loss_or_change",
        "morphology": "morphology_loss",
        "attenuation": "attenuation_loss",
        "distribution": "distribution_loss",
        "severity": "severity_loss",
        "polarity": "negation_or_uncertainty_error",
    }
    for field, flag in fields.items():
        if compare_field(attrs, canonical_attrs, field) not in {"preserved_exactly", "unavailable"}:
            flags.append(flag)
    qc = record.get("quality_control") or {}
    if qc.get("non_atomic_flag"):
        flags.append("non_atomic_original_prompt")
    if qc.get("requires_review"):
        flags.append("requires_manual_review")
    if normalize_text(original) != normalize_text(canonical):
        flags.append("prompt_changed")
    if token_count(canonical) <= max(3, int(token_count(original) * 0.6)):
        flags.append("over_compression")
    temporal_original = attrs.get("temporal_change")
    if temporal_original and not canonical_attrs.get("temporal_change"):
        flags.append("only_temporal_or_speculative_language_removed")
    if not flags or flags == ["prompt_changed"]:
        flags.append("no_meaningful_semantic_change")
    return sorted(set(flags))


def parser_audit(
    df: pd.DataFrame,
    sidecar: dict[tuple[str, str, int], dict],
    embedding_similarity: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    deltas = paired_delta_table(df, 0.50)
    sim = embedding_similarity[
        embedding_similarity["variant"].eq("canonical_visual_prompt")
    ][["split", "case", "finding_idx", "cosine_similarity"]].copy()
    sim["finding_idx"] = sim["finding_idx"].astype(int)
    rows = []
    for item in deltas.itertuples(index=False):
        key = ("val", item.case, int(item.finding_idx))
        record = sidecar.get(key)
        if record is None:
            continue
        original = record["original_prompt"]
        canonical = record["canonical_visual_prompt"]
        canonical_attrs = structured_attributes(canonical)
        attrs = record.get("structured_attributes") or {}
        flags = taxonomy_flags(record, canonical_attrs)
        row = {
            "split": "val",
            "case": item.case,
            "finding_idx": int(item.finding_idx),
            "category": item.category,
            "focality": item.focality,
            "original_prompt": original,
            "canonical_visual_prompt": canonical,
            "original_token_count": token_count(original),
            "canonical_token_count": token_count(canonical),
            "token_count_delta": token_count(canonical) - token_count(original),
            "edit_distance": levenshtein(normalize_text(original), normalize_text(canonical)),
            "normalized_edit_distance": levenshtein(normalize_text(original), normalize_text(canonical))
            / max(1, len(normalize_text(original))),
            "dice_delta_at_0p50": item.dice_delta_canonical_minus_original,
            "ap_delta": item.voxel_average_precision_delta_canonical_minus_original,
            "pred_voxels_delta_at_0p50": item.pred_voxels_delta_canonical_minus_original,
            "precision_delta_at_0p50": item.precision_delta_canonical_minus_original,
            "recall_delta_at_0p50": item.positive_recall_delta_canonical_minus_original,
            "taxonomy_flags": ";".join(flags),
            "non_atomic_flag": bool((record.get("quality_control") or {}).get("non_atomic_flag")),
            "requires_review": bool((record.get("quality_control") or {}).get("requires_review")),
        }
        for field in (
            "observation",
            "polarity",
            "laterality",
            "lobe",
            "segment",
            "relative_location",
            "size_values_mm",
            "count",
            "morphology",
            "attenuation",
            "severity",
            "distribution",
            "temporal_change",
        ):
            row[f"{field}_status"] = compare_field(attrs, canonical_attrs, field)
        rows.append(row)
    audit = pd.DataFrame(rows)
    audit = audit.merge(
        sim,
        how="left",
        left_on=["split", "case", "finding_idx"],
        right_on=["split", "case", "finding_idx"],
    )
    taxonomy_rows = []
    for flag in sorted(set(";".join(audit["taxonomy_flags"]).split(";"))):
        if not flag:
            continue
        selected = audit[
            audit["taxonomy_flags"].map(lambda value, flag=flag: flag in str(value).split(";"))
        ]
        taxonomy_rows.append(
            {
                "taxonomy_flag": flag,
                "findings": int(len(selected)),
                "mean_dice_delta_at_0p50": selected["dice_delta_at_0p50"].mean(),
                "mean_ap_delta": selected["ap_delta"].mean(),
                "mean_pred_voxels_delta_at_0p50": selected["pred_voxels_delta_at_0p50"].mean(),
                "improved_findings": int((selected["dice_delta_at_0p50"] > 1e-8).sum()),
                "worse_findings": int((selected["dice_delta_at_0p50"] < -1e-8).sum()),
                "unchanged_findings": int((selected["dice_delta_at_0p50"].abs() <= 1e-8).sum()),
            }
        )
    embedding_diag = audit[
        [
            "split",
            "case",
            "finding_idx",
            "category",
            "focality",
            "original_token_count",
            "canonical_token_count",
            "token_count_delta",
            "normalized_edit_distance",
            "cosine_similarity",
            "dice_delta_at_0p50",
            "ap_delta",
            "pred_voxels_delta_at_0p50",
            "precision_delta_at_0p50",
            "recall_delta_at_0p50",
        ]
    ].copy()
    return audit, pd.DataFrame(taxonomy_rows), embedding_diag


def subgroup_results(df: pd.DataFrame) -> pd.DataFrame:
    paired = paired_delta_table(df, 0.50)
    rows = []
    for group_name, column in (("focality", "focality"), ("category", "category")):
        for value, selected in paired.groupby(column, sort=True):
            rows.append(
                {
                    "group_type": group_name,
                    "group": value,
                    "findings": len(selected),
                    "original_dice_at_0p50": selected["dice_original"].mean(),
                    "canonical_dice_at_0p50": selected["dice_canonical_visual"].mean(),
                    "dice_delta_at_0p50": selected["dice_delta_canonical_minus_original"].mean(),
                    "original_precision_at_0p50": selected["precision_original"].mean(),
                    "canonical_precision_at_0p50": selected["precision_canonical_visual"].mean(),
                    "original_recall_at_0p50": selected["positive_recall_original"].mean(),
                    "canonical_recall_at_0p50": selected["positive_recall_canonical_visual"].mean(),
                    "ap_delta": selected["voxel_average_precision_delta_canonical_minus_original"].mean(),
                    "pred_voxels_delta_at_0p50": selected["pred_voxels_delta_canonical_minus_original"].mean(),
                    "improved_findings": int((selected["dice_delta_canonical_minus_original"] > 1e-8).sum()),
                    "worse_findings": int((selected["dice_delta_canonical_minus_original"] < -1e-8).sum()),
                }
            )
    return pd.DataFrame(rows)


def correlation_rows(embedding_diag: pd.DataFrame) -> pd.DataFrame:
    rows = []
    predictors = [
        "original_token_count",
        "canonical_token_count",
        "token_count_delta",
        "normalized_edit_distance",
        "cosine_similarity",
    ]
    outcomes = [
        "dice_delta_at_0p50",
        "ap_delta",
        "pred_voxels_delta_at_0p50",
        "precision_delta_at_0p50",
        "recall_delta_at_0p50",
    ]
    for predictor in predictors:
        for outcome in outcomes:
            selected = embedding_diag[[predictor, outcome]].replace([np.inf, -np.inf], np.nan).dropna()
            if len(selected) < 3:
                pearson = spearman = float("nan")
            else:
                pearson = selected[predictor].corr(selected[outcome], method="pearson")
                spearman = selected[predictor].corr(selected[outcome], method="spearman")
            rows.append(
                {
                    "predictor": predictor,
                    "outcome": outcome,
                    "n": int(len(selected)),
                    "pearson": pearson,
                    "spearman": spearman,
                }
            )
    return pd.DataFrame(rows)


def write_missing_csv(path: Path, reason: str, required_input: str) -> None:
    pd.DataFrame(
        [
            {
                "status": "not_computable_from_current_saved_outputs",
                "reason": reason,
                "required_input": required_input,
            }
        ]
    ).to_csv(path, index=False)


def markdown_table(df: pd.DataFrame, max_rows: int | None = None) -> str:
    if max_rows is not None:
        df = df.head(max_rows)
    if df.empty:
        return "_No rows._"
    columns = list(df.columns)
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
    ]
    for row in df.itertuples(index=False):
        values = []
        for value in row:
            if isinstance(value, float):
                values.append(f"{value:.6g}")
            else:
                text = str(value).replace("\n", " ")
                values.append(text[:120])
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def audit_markdown(
    output_dir: Path,
    args: argparse.Namespace,
    source_files: list[Path],
    df: pd.DataFrame,
    threshold_summary: pd.DataFrame,
) -> None:
    probability_files = list(args.source_dir.rglob("*.npz")) + list(args.source_dir.rglob("*.npy")) + list(args.source_dir.rglob("*.nii.gz"))
    manifests = sorted(args.source_dir.glob("shard_*/manifest.json"))
    text = [
        "# Current Output Audit",
        "",
        "## Located Files",
        "",
        f"- Prompt sidecar: `{args.sidecar.resolve()}`",
        f"- Original/canonical full-val source dir: `{args.source_dir.resolve()}`",
        f"- Embedding similarity CSV: `{args.embedding_similarity.resolve()}`",
        "- Embedding caches:",
        "  - `outputs/prompt_standardization_rule_only_v1/embeddings_v1_2/qwen_original_prompt_train_val_v1.pt`",
        "  - `outputs/prompt_standardization_rule_only_v1/embeddings_v1_2/qwen_canonical_visual_prompt_train_val_v1.pt`",
        f"- Per-finding metric CSV: `{(args.source_dir / 'per_finding_threshold_metrics.csv').resolve()}`",
        f"- Threshold summary: `{(args.source_dir / 'threshold_summary.csv').resolve()}`",
        f"- Paired deltas: `{(args.source_dir / 'paired_prompt_deltas.csv').resolve()}`",
        f"- Shard manifests: {len(manifests)} files under `{args.source_dir.resolve()}`",
        "",
        "## Saved Model Output Type",
        "",
        f"- Saved probability/logit maps found in this directory: {len(probability_files)}",
        "- The current full-validation output stores thresholded/summary metrics only.",
        "- During inference, `scripts/audit_rex_original_canonical_fullval.py` computes logits at lines 152-159 and immediately converts them to probabilities in memory.",
        "- It writes only per-finding threshold metrics at lines 213-229.",
        "- Therefore dense threshold sweeps, calibration-by-logit-bias, and affine logit fitting require rerunning inference with a denser threshold grid or saving logits/probabilities.",
        "",
        "## AP Calculation",
        "",
        "- AP uses `sklearn.metrics.average_precision_score` in `scripts/audit_rex_original_canonical_fullval.py:90-99`.",
        "- For each finding, the script samples positive GT voxels and background voxels with `stratified_indices` at lines 68-87.",
        "- The same sampled voxel indices are used for original and canonical probabilities at lines 164-171.",
        "- The collector then averages `voxel_average_precision` over findings at `scripts/collect_rex_original_canonical_fullval.py:91-100`.",
        "- This is per-finding AP averaged across findings, not global pooling over every voxel.",
        "",
        "## Parser Source",
        "",
        "- `canonical_visual_prompt` is generated by `strip_nonvisual_language` in `VoxTell/voxtell/utils/prompt_standardization.py:257-298`.",
        "- Rule-only records are created in `make_rule_only_record` at `VoxTell/voxtell/utils/prompt_standardization.py:393-430`.",
        "- The converter removes temporal/comparison/speculation language while attempting to preserve visual finding/anatomy/measurements.",
        "",
        "## Coverage",
        "",
        f"- Rows in per-finding metrics: {len(df)}",
        f"- Cases: {df['case'].nunique()}",
        f"- Findings: {df[['case', 'finding_idx']].drop_duplicates().shape[0]}",
        f"- Variants: {', '.join(sorted(df['variant'].unique()))}",
        f"- Thresholds present: {', '.join(f'{x:.2f}' for x in sorted(df['threshold'].unique()))}",
        "",
        "## Current Summary",
        "",
        markdown_table(threshold_summary),
        "",
        "## Assumptions",
        "",
        "- `global_hit` means Dice >= 0.1, matching prior ReX global-only reports.",
        "- Existing bootstrap in the original collector sampled findings. This diagnostic additionally reports case-level bootstrap for matched comparisons.",
        "- All cross-fitting here is limited to existing thresholds 0.40/0.45/0.50 and is labeled as limited.",
    ]
    (output_dir / "audit_current_outputs.md").write_text("\n".join(text) + "\n")


def write_commands(output_dir: Path, source_dir: Path) -> None:
    text = """# Reproducible Commands

```bash
# Recreate the current saved-output diagnostic without running VoxTell inference.
python scripts/diagnose_rex_prompt_canonicalization.py \\
  --source-dir outputs/prompt_standardization_rule_only_v1/full_validation_original_vs_canonical_v1_2 \\
  --output-dir outputs/prompt_standardization_rule_only_v1/diagnostic_original_vs_canonical_v1_2
```

```bash
# Optional: rerun original/canonical full validation with a dense threshold grid.
# This is needed because the current output did not save logits/probability maps.
python scripts/audit_rex_original_canonical_fullval.py \\
  --model-dir VoxTell/voxtell_v1.1 \\
  --checkpoint outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000/checkpoints/checkpoint_best_val_dice_step_3800.pth \\
  --original-cache outputs/prompt_standardization_rule_only_v1/embeddings_v1_2/qwen_original_prompt_train_val_v1.pt \\
  --canonical-cache outputs/prompt_standardization_rule_only_v1/embeddings_v1_2/qwen_canonical_visual_prompt_train_val_v1.pt \\
  --output-dir outputs/prompt_standardization_rule_only_v1/full_validation_original_vs_canonical_dense_v1_2 \\
  --thresholds $(python - <<'PY'
print(' '.join(f'{x/100:.2f}' for x in range(5, 96)))
PY
)
```
"""
    (output_dir / "reproducible_commands.md").write_text(text)


def final_report(
    output_dir: Path,
    threshold_summary: pd.DataFrame,
    matched: pd.DataFrame,
    crossfit: pd.DataFrame,
    taxonomy: pd.DataFrame,
    subgroup: pd.DataFrame,
    correlations: pd.DataFrame,
) -> None:
    orig_05 = threshold_summary[
        threshold_summary["variant"].eq("original") & threshold_summary["threshold"].eq(0.50)
    ].iloc[0]
    can_05 = threshold_summary[
        threshold_summary["variant"].eq("canonical_visual") & threshold_summary["threshold"].eq(0.50)
    ].iloc[0]
    volume_match = matched[matched["comparison"].eq("match_canonical_0p50_pred_volume")].iloc[0]
    can_cross = crossfit[crossfit["variant"].eq("canonical_visual")].iloc[0]
    top_taxonomy = taxonomy.sort_values("findings", ascending=False).head(8)
    category = subgroup[subgroup["group_type"].eq("category")].sort_values("group")
    corr_ap = correlations[correlations["outcome"].eq("ap_delta")].sort_values(
        "spearman", key=lambda s: s.abs(), ascending=False
    ).head(5)
    text = [
        "# ReX Prompt Canonicalization Diagnostic Report",
        "",
        "## Bottom Line From Current Saved Outputs",
        "",
        f"- At threshold 0.50, canonical Dice/finding is {can_05.mean_global_dice_per_finding:.6f} vs original {orig_05.mean_global_dice_per_finding:.6f}.",
        f"- Canonical improves precision ({orig_05.mean_precision:.6f} -> {can_05.mean_precision:.6f}) while reducing recall ({orig_05.mean_recall:.6f} -> {can_05.mean_recall:.6f}).",
        f"- Mean predicted volume decreases from {orig_05.mean_pred_voxels:.1f} to {can_05.mean_pred_voxels:.1f} voxels.",
        f"- AP is lower for canonical ({orig_05.mean_voxel_average_precision:.6f} -> {can_05.mean_voxel_average_precision:.6f}).",
        "",
        "This still supports the current interpretation: canonical mostly changes the operating point toward smaller, more precise predictions; the current evidence does not show improved voxel ranking/localization.",
        "",
        "## Matched Operating Point: What We Can Say Now",
        "",
        "Only thresholds 0.40/0.45/0.50 were saved, so this is a coarse nearest-neighbor match, not a dense/interpolated result.",
        "",
        markdown_table(matched),
        "",
        f"For matching canonical@0.50 volume, the nearest original threshold available is {volume_match.nearest_candidate_threshold:.2f}; it still predicts {volume_match.candidate_mean_pred_voxels:.1f} voxels, so the match residual is large. A dense rerun is required before making a strong matched-volume conclusion.",
        "",
        "## Limited Five-Fold Case-Level Cross-Fit",
        "",
        "This cross-fit selected thresholds only from 0.40/0.45/0.50, so it is useful as a sanity check but not as the final calibration answer.",
        "",
        markdown_table(crossfit),
        "",
        f"Limited cross-fit canonical-minus-original Dice delta: {can_cross.canonical_minus_original_dice_delta:+.6f} with case-level CI [{can_cross.canonical_minus_original_ci95_low_by_case:+.6f}, {can_cross.canonical_minus_original_ci95_high_by_case:+.6f}].",
        "",
        "## Parser/Prompt Taxonomy",
        "",
        markdown_table(top_taxonomy),
        "",
        "## Category Results At Threshold 0.50",
        "",
        markdown_table(category),
        "",
        "## Prompt Change Correlations",
        "",
        markdown_table(corr_ap),
        "",
        "## Required But Not Yet Computable From Existing Files",
        "",
        "- Dense 0.05-0.95 threshold curves require rerunning inference with a dense threshold list or saving probability maps.",
        "- Scalar logit bias, positive affine calibration, temperature-only calibration, and global/per-finding `z_canonical = a z_original + b` fits require logits or probabilities, not just threshold metrics.",
        "- Spatial residual maps require saved probability/logit volumes.",
        "- Controlled prompt ablations require new prompt variants and new inference.",
        "",
        "## Answers To The Main Questions",
        "",
        "1. After matching prediction volume, does canonical still improve Dice? Current sparse thresholds cannot answer rigorously; nearest original threshold is not close enough in volume.",
        "2. After matching recall, does canonical still improve precision or Dice? Current sparse thresholds suggest canonical remains better, but matching residuals are too coarse for a final claim.",
        "3. Does original plus scalar logit bias reproduce canonical? Not computable without logits/probabilities; this is the highest-priority next check.",
        "4. Is canonical approximately a global affine transform of original logits? Not computable without logits/probabilities.",
        "5. Which parser operations are associated with AP loss? See `parser_error_taxonomy_summary.csv` and `prompt_change_correlations.csv`; current evidence is associative only.",
        "6. Are there actual parser errors or mainly model sensitivity? The rule parser is mostly stripping temporal/speculative language, but review/non-atomic prompts remain common; a controlled ablation is needed to separate parser errors from wording sensitivity.",
        "7. Does removing temporal/speculative language help or hurt? Current full-val result says it improves fixed-threshold Dice but lowers AP on average.",
        "8. Which attributes must be preserved? Size, laterality/lobe, morphology, attenuation, relative location, count, and distribution should be treated as protected fields because AP loss must be checked by these groups.",
        "9. Which categories benefit or worsen? See `subgroup_results.csv`; most categories improve in fixed-threshold Dice, while AP can still decrease.",
        "10. Next step: do not train yet. First rerun a dense original/canonical inference sweep or save probability maps, then test scalar logit-bias calibration against canonical.",
    ]
    (output_dir / "final_diagnostic_report.md").write_text("\n".join(text) + "\n")


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.source_dir / "per_finding_threshold_metrics.csv")
    for column in ("global_hit", "empty_prediction", "gross_oversegmentation"):
        if df[column].dtype == object:
            df[column] = df[column].astype(str).str.lower().eq("true")
    sidecar = load_sidecar(args.sidecar)
    embedding_similarity = pd.read_csv(args.embedding_similarity)

    threshold_summary = summarize_thresholds(df)
    threshold_summary.to_csv(args.output_dir / "dense_threshold_sweep.csv", index=False)

    matched = matched_operating_points(df, args.bootstrap_samples, args.seed)
    matched.to_csv(args.output_dir / "matched_operating_points.csv", index=False)

    crossfit, selected_thresholds = crossfit_thresholds(df, args.folds, args.bootstrap_samples, args.seed)
    crossfit.to_csv(args.output_dir / "cross_fitted_threshold_results.csv", index=False)
    selected_thresholds.to_csv(args.output_dir / "cross_fitted_selected_thresholds.csv", index=False)

    audit, taxonomy, embedding_diag = parser_audit(df, sidecar, embedding_similarity)
    audit.to_csv(args.output_dir / "per_finding_parser_audit.csv", index=False)
    taxonomy.to_csv(args.output_dir / "parser_error_taxonomy_summary.csv", index=False)
    embedding_diag.to_csv(args.output_dir / "prompt_embedding_diagnostics.csv", index=False)

    subgroup = subgroup_results(df)
    subgroup.to_csv(args.output_dir / "subgroup_results.csv", index=False)
    correlations = correlation_rows(embedding_diag)
    correlations.to_csv(args.output_dir / "prompt_change_correlations.csv", index=False)

    write_missing_csv(
        args.output_dir / "calibration_baselines.csv",
        "current full-validation outputs contain summary metrics but not logits/probability maps",
        "original logits or probabilities for every evaluated finding/window/voxel",
    )
    write_missing_csv(
        args.output_dir / "logit_affine_fit_results.csv",
        "current full-validation outputs contain summary metrics but not paired original/canonical logits",
        "paired original and canonical logits/probabilities over sampled or full voxels",
    )
    write_missing_csv(
        args.output_dir / "controlled_ablation_results.csv",
        "controlled prompt variants have not yet been constructed or inferred",
        "new embeddings and frozen-checkpoint inference for the selected ablation subset",
    )
    (args.output_dir / "representative_visualizations").mkdir(exist_ok=True)

    audit_markdown(args.output_dir, args, [], df, threshold_summary)
    write_commands(args.output_dir, args.source_dir)
    final_report(args.output_dir, threshold_summary, matched, crossfit, taxonomy, subgroup, correlations)
    print(f"Wrote diagnostic outputs to {args.output_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
