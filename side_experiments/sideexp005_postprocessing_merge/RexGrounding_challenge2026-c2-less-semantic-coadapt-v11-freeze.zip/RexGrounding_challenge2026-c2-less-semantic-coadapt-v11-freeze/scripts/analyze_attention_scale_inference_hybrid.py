#!/usr/bin/env python3
"""CPU-only fixed-policy and case-cross-fitted attention-scale hybrids."""

from __future__ import annotations

import hashlib
import json
import math
import os
import resource
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/attention_scale_inference_hybrid_analysis"
RUNS = {
    "CONTROL": ROOT / "outputs/attention_scale_screen_control_u500",
    "SCALE_1_4": ROOT / "outputs/attention_scale_screen_1_4_u500",
    "SCALE_1_2": ROOT / "outputs/attention_scale_screen_1_2_u500",
    "SCALE_1_1": ROOT / "outputs/attention_scale_screen_1_1_u500",
}
ARMS = tuple(RUNS)
SCALE_ARMS = ARMS[1:]
CATEGORIES = ("1a", "1b", "1c", "1d", "1e", "1f", "2a", "2b", "2c", "2d", "2e", "2f", "2g", "2h")
FIXED_POLICY = {"1b": "SCALE_1_1", "1c": "SCALE_1_4", "2b": "SCALE_1_2", "2c": "SCALE_1_2"}
KEY = ["case_id", "finding_id", "target_channel"]
METRICS = ("dice", "hit", "tp", "fp", "fn", "pred", "precision", "recall", "pred_gt_ratio")
REFERENCE = {"CONTROL": 0.3283427324091075, "SCALE_1_4": 0.3223324417873612, "SCALE_1_2": 0.3265887439627524, "SCALE_1_1": 0.31893185885429703}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def json_dump(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, default=json_default) + "\n")


def json_default(value: Any) -> Any:
    if isinstance(value, (np.integer, np.floating, np.bool_)):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(type(value).__name__)


def counts_json(values: pd.Series) -> str:
    return json.dumps({str(key): int(count) for key, count in values.value_counts().items()})


def markdown_table(frame: pd.DataFrame) -> str:
    def render(value: Any) -> str:
        if pd.isna(value):
            return "NA"
        if isinstance(value, (float, np.floating)):
            return f"{float(value):.6f}"
        return str(value).replace("|", "\\|").replace("\n", " ")
    columns = [str(column) for column in frame.columns]
    lines = ["| " + " | ".join(columns) + " |", "| " + " | ".join("---" for _ in columns) + " |"]
    lines.extend("| " + " | ".join(render(value) for value in row) + " |" for row in frame.itertuples(index=False, name=None))
    return "\n".join(lines)


def load_and_align() -> tuple[pd.DataFrame, dict[str, Any], dict[str, Any]]:
    source_frames: dict[str, pd.DataFrame] = {}
    provenance: dict[str, Any] = {"arms": {}, "evaluation": {"threshold": 0.5, "postprocessing": "none", "global_only": True, "cohort": "val", "finding_count": 381, "case_count": 200}}
    for arm, run in RUNS.items():
        source = run / "full381/update500/per_finding_metrics.csv"
        frame = pd.read_csv(source).rename(columns={"file": "case_id", "finding_idx": "finding_id"})
        frame["target_channel"] = frame.finding_id.astype(int)
        frame["category"] = frame.category.astype(str)
        frame["finding_id"] = frame.finding_id.astype(int)
        source_frames[arm] = frame
        checkpoint = run / "checkpoints/checkpoint_update_500.pth"
        provenance["arms"][arm] = {
            "run_directory": str(run.resolve()), "per_finding_file": str(source.resolve()),
            "per_finding_sha256": sha256(source), "checkpoint": str(checkpoint.resolve()),
            "checkpoint_sha256": sha256(checkpoint), "plans": str((run / "plans.json").resolve()),
            "plans_sha256": sha256(run / "plans.json"), "args": str((run / "args.json").resolve()),
            "summary": json.loads((run / "full381/update500/summary.json").read_text()),
        }
    control = source_frames["CONTROL"]
    metadata = control[[*KEY, "category", "pixels", "prompt", "gt_voxels", "voxel_volume_mm3", "split"]].copy()
    metadata["size"] = pd.cut(metadata.gt_voxels, [-1, 99, 999, 9999, np.inf], labels=["tiny", "small", "medium", "large"]).astype(str)
    metadata["detail_group"] = np.where(metadata.category.eq("2d") & metadata["size"].eq("small"), "2d-small", np.where(metadata.category.eq("2d"), "2d-other", metadata.category))
    wide = metadata
    rename = {"global_dice": "dice", "global_hit": "hit", "tp_voxels": "tp", "fp_voxels": "fp", "fn_voxels": "fn", "pred_voxels": "pred", "voxel_precision": "precision", "voxel_recall": "recall", "pred_gt_volume_ratio": "pred_gt_ratio"}
    for arm, frame in source_frames.items():
        selected = frame[[*KEY, "category", "gt_voxels", *rename]].rename(columns=rename)
        selected = selected.rename(columns={name: f"{name}_{arm}" for name in METRICS} | {"category": f"category_{arm}", "gt_voxels": f"gt_{arm}"})
        wide = wide.merge(selected, on=KEY, how="inner", validate="one_to_one")
    checks: dict[str, Any] = {"per_arm": {}}
    reference_keys = set(map(tuple, control[KEY].to_numpy()))
    for arm, frame in source_frames.items():
        keys = set(map(tuple, frame[KEY].to_numpy()))
        checks["per_arm"][arm] = {"findings": len(frame), "cases": frame.case_id.nunique(), "unique_keys": len(keys), "duplicates": int(frame.duplicated(KEY).sum()), "missing_vs_control": len(reference_keys - keys), "extra_vs_control": len(keys - reference_keys), "positive_gt_rows": int(frame.gt_voxels.gt(0).sum())}
    checks.update({
        "aligned_rows": len(wide), "aligned_cases": wide.case_id.nunique(),
        "categories_identical": all(wide[f"category_{arm}"].equals(wide.category) for arm in ARMS),
        "gt_voxels_identical": all(wide[f"gt_{arm}"].equals(wide.gt_voxels) for arm in ARMS),
        "size_labels_derived_from_common_gt": True,
        "overall_reproduced": {arm: {"observed": wide[f"dice_{arm}"].mean(), "reference": REFERENCE[arm], "absolute_error": abs(wide[f"dice_{arm}"].mean() - REFERENCE[arm])} for arm in ARMS},
    })
    category_reproduced = {}
    for arm, run in RUNS.items():
        saved = pd.read_csv(run / "full381/update500/per_category_metrics.csv").set_index("category").mean_dice
        observed = wide.groupby("category")[f"dice_{arm}"].mean()
        common = saved.index.intersection(observed.index)
        category_reproduced[arm] = {"categories": len(common), "max_abs_error": float((saved.loc[common] - observed.loc[common]).abs().max())}
    checks["category_table_reproduced"] = category_reproduced
    required = all(item["findings"] == 381 and item["cases"] == 200 and item["duplicates"] == 0 and item["missing_vs_control"] == 0 and item["extra_vs_control"] == 0 and item["positive_gt_rows"] == 381 for item in checks["per_arm"].values())
    required = required and len(wide) == 381 and checks["categories_identical"] and checks["gt_voxels_identical"] and all(value["absolute_error"] < 1e-10 for value in checks["overall_reproduced"].values()) and all(value["max_abs_error"] < 1e-10 for value in category_reproduced.values())
    checks["status"] = "passed" if required else "failed"
    if not required:
        raise RuntimeError("Four-arm alignment/provenance audit failed")
    return wide.sort_values(KEY).reset_index(drop=True), provenance, checks


def choose_rows(wide: pd.DataFrame, routes: pd.Series) -> pd.DataFrame:
    result = wide.copy(); result["selected_arm"] = routes.to_numpy()
    row_index = np.arange(len(result))
    arm_index = {arm: np.flatnonzero(result.selected_arm.eq(arm)) for arm in ARMS}
    for metric in METRICS:
        result[f"selected_{metric}"] = False if metric == "hit" else np.nan
        for arm, indices in arm_index.items():
            result.loc[indices, f"selected_{metric}"] = result.loc[indices, f"{metric}_{arm}"].to_numpy()
    result["selected_hit"] = result.selected_hit.astype(bool)
    result["delta_dice"] = result.selected_dice - result.dice_CONTROL
    result["delta_hit"] = result.selected_hit.astype(int) - result.hit_CONTROL.astype(int)
    for metric in ("precision", "recall", "fp", "fn", "pred", "pred_gt_ratio"):
        result[f"delta_{metric}"] = result[f"selected_{metric}"] - result[f"{metric}_CONTROL"]
    result["fp_gt_CONTROL"] = result.fp_CONTROL / result.gt_voxels
    result["fn_gt_CONTROL"] = result.fn_CONTROL / result.gt_voxels
    result["selected_fp_gt"] = result.selected_fp / result.gt_voxels
    result["selected_fn_gt"] = result.selected_fn / result.gt_voxels
    del row_index
    return result


def method_summary(frame: pd.DataFrame, selected_prefix: str = "selected") -> dict[str, Any]:
    dice = frame[f"{selected_prefix}_dice"]; hit = frame[f"{selected_prefix}_hit"].astype(bool)
    tp, fp, fn = (frame[f"{selected_prefix}_{name}"].sum() for name in ("tp", "fp", "fn"))
    return {"n": len(frame), "cases": frame.case_id.nunique(), "mean_dice": dice.mean(), "hits": int(hit.sum()), "hit_rate": hit.mean(), "macro_precision": frame[f"{selected_prefix}_precision"].mean(), "macro_recall": frame[f"{selected_prefix}_recall"].mean(), "pooled_precision": tp / max(tp + fp, 1), "pooled_recall": tp / max(tp + fn, 1), "tp": int(tp), "fp": int(fp), "fn": int(fn), "mean_pred_gt_volume_ratio": frame[f"{selected_prefix}_pred_gt_ratio"].mean(), "fp_over_gt": (frame[f"{selected_prefix}_fp"] / frame.gt_voxels).mean(), "fn_over_gt": (frame[f"{selected_prefix}_fn"] / frame.gt_voxels).mean()}


def comparison_summary(frame: pd.DataFrame) -> dict[str, Any]:
    selected = method_summary(frame); control_frame = frame.copy()
    for metric in METRICS:
        control_frame[f"selected_{metric}"] = control_frame[f"{metric}_CONTROL"]
    control = method_summary(control_frame)
    delta = frame.delta_dice
    return {**{f"control_{key}": value for key, value in control.items()}, **{f"hybrid_{key}": value for key, value in selected.items()}, "paired_mean_dice_delta": delta.mean(), "hit_delta": selected["hits"] - control["hits"], "improved": int((delta > 1e-12).sum()), "degraded": int((delta < -1e-12).sum()), "tied": int((delta.abs() <= 1e-12).sum()), "new_hits": int((frame.selected_hit & ~frame.hit_CONTROL).sum()), "lost_hits": int((~frame.selected_hit & frame.hit_CONTROL).sum()), "precision_delta": selected["macro_precision"] - control["macro_precision"], "recall_delta": selected["macro_recall"] - control["macro_recall"], "fp_over_gt_delta": selected["fp_over_gt"] - control["fp_over_gt"], "fn_over_gt_delta": selected["fn_over_gt"] - control["fn_over_gt"], "pred_gt_ratio_delta": selected["mean_pred_gt_volume_ratio"] - control["mean_pred_gt_volume_ratio"]}


def grouped_summary(frame: pd.DataFrame, group: str) -> pd.DataFrame:
    rows = []
    for value, subset in frame.groupby(group, sort=True, observed=True):
        rows.append({group: value, "selected_arms": counts_json(subset.selected_arm), **comparison_summary(subset), "fp_delta_mean_voxels": subset.delta_fp.mean(), "fn_delta_mean_voxels": subset.delta_fn.mean(), "pred_volume_delta_mean_voxels": subset.delta_pred.mean()})
    return pd.DataFrame(rows)


def cluster_bootstrap(frame: pd.DataFrame, seed: int, replicates: int = 10000) -> tuple[pd.DataFrame, dict[str, Any]]:
    work = frame.assign(precision_delta=frame.selected_precision - frame.precision_CONTROL, recall_delta=frame.selected_recall - frame.recall_CONTROL, fpgt_delta=frame.selected_fp_gt - frame.fp_gt_CONTROL, fngt_delta=frame.selected_fn_gt - frame.fn_gt_CONTROL)
    fields = ["delta_dice", "delta_hit", "precision_delta", "recall_delta", "fpgt_delta", "fngt_delta"]
    per_case = work.groupby("case_id").agg(n=("case_id", "size"), **{field: (field, "sum") for field in fields}).reset_index()
    rng = np.random.default_rng(seed); indices = rng.integers(0, len(per_case), size=(replicates, len(per_case)))
    sampled_n = per_case.n.to_numpy()[indices].sum(axis=1)
    data = {"replicate": np.arange(replicates)}
    for field in fields:
        values = per_case[field].to_numpy()[indices].sum(axis=1)
        data[field if field == "delta_hit" else f"mean_{field}"] = values if field == "delta_hit" else values / sampled_n
    draws = pd.DataFrame(data)
    summary = {"replicates": replicates, "seed": seed, "cluster": "case", "mean_dice_delta": frame.delta_dice.mean(), "dice_ci95": list(np.quantile(draws.mean_delta_dice, [0.025, 0.975])), "probability_delta_gt_zero": float((draws.mean_delta_dice > 0).mean()), "hit_delta_ci95": list(np.quantile(draws.delta_hit, [0.025, 0.975])), "precision_delta_ci95": list(np.quantile(draws.mean_precision_delta, [0.025, 0.975])), "recall_delta_ci95": list(np.quantile(draws.mean_recall_delta, [0.025, 0.975])), "fp_over_gt_delta_ci95": list(np.quantile(draws.mean_fpgt_delta, [0.025, 0.975])), "fn_over_gt_delta_ci95": list(np.quantile(draws.mean_fngt_delta, [0.025, 0.975]))}
    return draws, summary


def leave_one_out(frame: pd.DataFrame, group: str) -> pd.DataFrame:
    rows = []
    for value in sorted(frame[group].unique()):
        subset = frame.loc[~frame[group].eq(value)]
        rows.append({f"excluded_{group}": value, "remaining_findings": len(subset), "remaining_cases": subset.case_id.nunique(), "mean_dice_delta": subset.delta_dice.mean(), "hit_delta": int(subset.delta_hit.sum())})
    return pd.DataFrame(rows)


def load_folds(wide: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    source = ROOT / "outputs/dual_s3_postzoom_routing/fold_assignments.csv"
    folds = pd.read_csv(source).rename(columns={"outer_fold": "fold"})[["case_id", "fold", "seed"]]
    expected = set(wide.case_id.unique()); observed = set(folds.case_id)
    if len(folds) == 200 and expected == observed and folds.fold.nunique() == 5:
        return folds.sort_values("case_id"), {"source": str(source.resolve()), "sha256": sha256(source), "kind": "existing independent official case-level assignment", "seed": int(folds.seed.iloc[0])}
    raise RuntimeError("No valid independent official 200-case fold assignment")


def select_routes(wide: pd.DataFrame, threshold: float) -> tuple[pd.DataFrame, dict[tuple[int, str], str]]:
    records, routes = [], {}
    for fold in range(5):
        selection = wide.loc[wide.fold.ne(fold)]
        for category in CATEGORIES:
            subset = selection.loc[selection.category.eq(category)]
            row: dict[str, Any] = {"fold": fold, "category": category, "selection_findings": len(subset), "selection_cases": subset.case_id.nunique(), "control_mean_dice": subset.dice_CONTROL.mean() if len(subset) else np.nan}
            eligible = []
            for arm in SCALE_ARMS:
                delta = subset[f"dice_{arm}"] - subset.dice_CONTROL
                hit_delta = int((subset[f"hit_{arm}"].astype(int) - subset.hit_CONTROL.astype(int)).sum())
                positive = delta.clip(lower=0); by_case_positive = positive.groupby(subset.case_id).sum(); positive_total = positive.sum()
                dominance = by_case_positive.max() / positive_total if positive_total > 0 else np.nan
                positive_cases = int((delta.groupby(subset.case_id).max() > 0).sum())
                fpgt_delta = ((subset[f"fp_{arm}"] - subset.fp_CONTROL) / subset.gt_voxels).mean() if len(subset) else np.nan
                precision_delta = (subset[f"precision_{arm}"] - subset.precision_CONTROL).mean() if len(subset) else np.nan
                gain = delta.mean() if len(subset) else np.nan
                passed = len(subset) >= 8 and subset.case_id.nunique() >= 5 and gain >= threshold and hit_delta >= 0 and positive_cases >= 2 and positive_total > 0 and dominance <= 0.5
                row.update({f"{arm}_mean_dice": subset[f"dice_{arm}"].mean() if len(subset) else np.nan, f"{arm}_delta_dice": gain, f"{arm}_hit_delta": hit_delta, f"{arm}_positive_cases": positive_cases, f"{arm}_max_positive_case_share": dominance, f"{arm}_fp_over_gt_delta": fpgt_delta, f"{arm}_precision_delta": precision_delta, f"{arm}_eligible": passed})
                if passed:
                    eligible.append((arm, gain, hit_delta, fpgt_delta, precision_delta))
            if not eligible:
                selected, reason = "CONTROL", "No non-control arm passed all predeclared eligibility rules"
            else:
                eligible.sort(key=lambda value: (-value[1], -value[2], value[3], -value[4], value[0]))
                selected = eligible[0][0]; reason = f"Eligible arm with best ordered criteria: delta={eligible[0][1]:+.6f}, hit_delta={eligible[0][2]}"
                if len(eligible) > 1 and abs(eligible[0][1] - eligible[1][1]) <= 0.001 and eligible[0][2:] == eligible[1][2:]:
                    selected, reason = "CONTROL", "Eligible attention arms remained effectively tied; defaulted to CONTROL"
            row.update({"selected_arm": selected, "selection_reason": reason, "minimum_delta_threshold": threshold})
            records.append(row); routes[(fold, category)] = selected
    return pd.DataFrame(records), routes


def apply_crossfit(wide: pd.DataFrame, routes: dict[tuple[int, str], str]) -> pd.DataFrame:
    selected = pd.Series([routes[(int(row.fold), str(row.category))] for row in wide.itertuples()], index=wide.index)
    return choose_rows(wide, selected)


def arm_as_selected(wide: pd.DataFrame, arm: str) -> pd.DataFrame:
    return choose_rows(wide, pd.Series(arm, index=wide.index))


def main() -> int:
    started = time.perf_counter(); OUT.mkdir(parents=True, exist_ok=True)
    wide, provenance, alignment = load_and_align(); wide.to_csv(OUT / "aligned_per_finding_all_arms.csv", index=False)
    folds, fold_provenance = load_folds(wide); folds.to_csv(OUT / "crossfit_case_folds.csv", index=False)
    wide = wide.merge(folds[["case_id", "fold"]], on="case_id", validate="many_to_one")

    fixed_routes = wide.category.map(FIXED_POLICY).fillna("CONTROL")
    fixed = choose_rows(wide, fixed_routes); fixed.to_csv(OUT / "fixed_policy_per_finding.csv", index=False)
    fixed_category = grouped_summary(fixed, "category"); fixed_category.to_csv(OUT / "fixed_policy_category_summary.csv", index=False)
    fixed_draws, fixed_boot = cluster_bootstrap(fixed, 20260806); fixed_draws.to_csv(OUT / "fixed_policy_bootstrap.csv", index=False)
    fixed_loo = leave_one_out(fixed, "case_id"); fixed_loo.to_csv(OUT / "fixed_policy_leave_one_case_out.csv", index=False)
    fixed_summary = comparison_summary(fixed)
    fixed_policy_json = {"policy": FIXED_POLICY, "default": "CONTROL", "label": "resubstitution / same-cohort policy estimate", "overall": fixed_summary, "bootstrap": fixed_boot, "leave_one_case_out": {"minimum_delta": fixed_loo.mean_dice_delta.min(), "maximum_delta": fixed_loo.mean_dice_delta.max(), "most_influential_case": fixed_loo.iloc[(fixed_loo.mean_dice_delta - fixed.delta_dice.mean()).abs().argmax()].excluded_case_id, "sign_robust": bool((fixed_loo.mean_dice_delta > 0).all())}}
    json_dump(OUT / "fixed_policy.json", fixed_policy_json)

    route_table, routes = select_routes(wide, 0.003); route_table.to_csv(OUT / "crossfit_route_selection_by_fold.csv", index=False)
    crossfit = apply_crossfit(wide, routes); crossfit.to_csv(OUT / "crossfit_per_finding.csv", index=False)
    crossfit_category = grouped_summary(crossfit, "category")
    route_strings = route_table.groupby("category").selected_arm.apply(counts_json).rename("route_frequencies")
    crossfit_category = crossfit_category.merge(route_strings, on="category", how="left")
    crossfit_category["contribution_to_overall_delta"] = crossfit_category.hybrid_n * crossfit_category.paired_mean_dice_delta / len(crossfit)
    crossfit_category.to_csv(OUT / "crossfit_category_summary.csv", index=False)
    stability = route_table.groupby(["category", "selected_arm"]).size().rename("fold_count").reset_index(); stability.to_csv(OUT / "crossfit_route_stability.csv", index=False)
    crossfit_draws, crossfit_boot = cluster_bootstrap(crossfit, 20260807); crossfit_draws.to_csv(OUT / "crossfit_bootstrap.csv", index=False)
    crossfit_loo_case = leave_one_out(crossfit, "case_id"); crossfit_loo_case.to_csv(OUT / "crossfit_leave_one_case_out.csv", index=False)
    crossfit_loo_category = leave_one_out(crossfit, "category"); crossfit_loo_category.to_csv(OUT / "crossfit_leave_one_category_out.csv", index=False)
    crossfit_summary = comparison_summary(crossfit)

    sensitivity_rows = []
    for threshold in (0.001, 0.003, 0.005):
        threshold_routes, mapping = select_routes(wide, threshold); heldout = apply_crossfit(wide, mapping); summary = comparison_summary(heldout)
        sensitivity_rows.append({"minimum_selection_delta": threshold, "mean_dice": summary["hybrid_mean_dice"], "delta_dice": summary["paired_mean_dice_delta"], "hits": summary["hybrid_hits"], "hit_delta": summary["hit_delta"], "routed_findings": int(heldout.selected_arm.ne("CONTROL").sum()), "route_frequencies": counts_json(threshold_routes.selected_arm)})
    pd.DataFrame(sensitivity_rows).to_csv(OUT / "route_threshold_sensitivity.csv", index=False)

    methods = []
    for arm in ARMS:
        frame = arm_as_selected(wide, arm); summary = method_summary(frame)
        methods.append({"method": arm, **summary, "delta_vs_control": frame.delta_dice.mean(), "dice_ci95_low": np.nan, "dice_ci95_high": np.nan, "hit_delta": int(frame.delta_hit.sum())})
    for name, frame, boot in (("FIXED_POLICY", fixed, fixed_boot), ("CROSS_FITTED", crossfit, crossfit_boot)):
        summary = method_summary(frame); methods.append({"method": name, **summary, "delta_vs_control": frame.delta_dice.mean(), "dice_ci95_low": boot["dice_ci95"][0], "dice_ci95_high": boot["dice_ci95"][1], "hit_delta": int(frame.delta_hit.sum())})
    all_methods = pd.DataFrame(methods); all_methods.to_csv(OUT / "all_methods_summary.csv", index=False)
    category_comparison = pd.DataFrame({"category": CATEGORIES})
    category_base = wide.groupby("category").agg(n=("case_id", "size"), cases=("case_id", "nunique"), control_dice=("dice_CONTROL", "mean")).reset_index()
    category_comparison = category_comparison.merge(category_base, on="category", how="left").merge(fixed_category[["category", "selected_arms", "hybrid_mean_dice", "paired_mean_dice_delta"]].rename(columns={"selected_arms": "fixed_selected_arms", "hybrid_mean_dice": "fixed_dice", "paired_mean_dice_delta": "fixed_delta"}), on="category", how="left").merge(crossfit_category[["category", "route_frequencies", "hybrid_mean_dice", "paired_mean_dice_delta"]].rename(columns={"hybrid_mean_dice": "crossfit_dice", "paired_mean_dice_delta": "crossfit_delta"}), on="category", how="left")
    category_comparison.to_csv(OUT / "category_comparison.csv", index=False)

    fixed_manifest = fixed[[*KEY, "category", "selected_arm"]].copy(); cross_manifest = crossfit[[*KEY, "fold", "category", "selected_arm"]].copy()
    for manifest, name in ((fixed_manifest, "fixed_policy_prediction_manifest.csv"), (cross_manifest, "crossfit_prediction_manifest.csv")):
        manifest["prediction_path"] = [str((RUNS[arm] / "full381/update500/predictions" / case).resolve()) for arm, case in zip(manifest.selected_arm, manifest.case_id)]
        manifest.to_csv(OUT / name, index=False)

    positive_categories = int((crossfit.groupby("category").delta_dice.sum() > 0).sum())
    decision_checks = {"dice_delta_at_least_0.001": crossfit_summary["paired_mean_dice_delta"] >= 0.001, "hit_count_not_decreased": crossfit_summary["hit_delta"] >= 0, "at_least_two_positive_categories": positive_categories >= 2, "case_removal_preserves_gain": bool((crossfit_loo_case.mean_dice_delta > 0).all()), "category_removal_preserves_gain": bool((crossfit_loo_category.mean_dice_delta > 0).all()), "category_2d_preserved": bool((crossfit.loc[crossfit.category.eq("2d"), "selected_arm"] == "CONTROL").all()), "no_material_fp_volume_explosion": crossfit_summary["fp_over_gt_delta"] <= max(0.1, 0.1 * crossfit_summary["control_fp_over_gt"])}
    if all(decision_checks.values()):
        classification = "A. CROSS-FITTED CATEGORY ROUTING IS PROMISING"
    elif fixed_summary["paired_mean_dice_delta"] > 0 and crossfit_summary["paired_mean_dice_delta"] <= 0.001:
        classification = "B. FIXED POLICY LOOKS POSITIVE, BUT CROSS-FITTED EVIDENCE IS WEAK"
    else:
        classification = "C. NO USEFUL CATEGORY-DEPENDENT INFERENCE ROUTING SIGNAL"
    decision = {"classification": classification, "recommend_unified_category_routed_training_test": classification.startswith("A."), "checks": decision_checks, "fixed_policy_delta": fixed_summary["paired_mean_dice_delta"], "crossfit_delta": crossfit_summary["paired_mean_dice_delta"], "crossfit_hit_delta": crossfit_summary["hit_delta"], "positive_contributing_categories": positive_categories}
    json_dump(OUT / "decision.json", decision)

    safety = {"status": "passed", "alignment": alignment, "fold_assignment": fold_provenance, "fixed_2d_exact_control_all_metrics": all(np.array_equal(fixed.loc[fixed.category.eq("2d"), f"selected_{metric}"].to_numpy(), fixed.loc[fixed.category.eq("2d"), f"{metric}_CONTROL"].to_numpy()) for metric in METRICS), "crossfit_findings_once": len(crossfit) == 381 and not crossfit.duplicated(KEY).any(), "crossfit_cases_unsplit": int(wide.groupby("case_id").fold.nunique().max()) == 1, "no_gpu_inference": True, "original_outputs_overwritten": False, "attention_diagnosis_dependency": False}
    json_dump(OUT / "input_provenance.json", provenance | {"fold_assignment": fold_provenance})
    json_dump(OUT / "alignment_audit.json", alignment)
    json_dump(OUT / "safety_checks.json", safety)

    git_candidates = (Path("/home/shenc2/miniconda3/envs/cmr/bin/git"), Path("/usr/bin/git"), Path("/bin/git"))
    git_binary = next((path for path in git_candidates if path.exists()), None)
    if git_binary is None:
        git_diff = git_status = "git executable unavailable on compute node"
    else:
        git_diff = subprocess.run([str(git_binary), "diff", "--stat"], cwd=ROOT, text=True, capture_output=True).stdout.strip()
        git_status = subprocess.run([str(git_binary), "status", "--short"], cwd=ROOT, text=True, capture_output=True).stdout.strip()
    runtime = time.perf_counter() - started; peak_mb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    fixed_sizes = grouped_summary(fixed, "size"); cross_sizes = grouped_summary(crossfit, "size")
    fixed_details = grouped_summary(fixed, "detail_group"); cross_details = grouped_summary(crossfit, "detail_group")
    fixed["route_group"] = np.where(fixed.category.isin(FIXED_POLICY), "predeclared-routed", "non-routed-preservation")
    crossfit["route_group"] = np.where(crossfit.selected_arm.eq("CONTROL"), "CONTROL-selected", "attention-routed")
    fixed_route_groups = grouped_summary(fixed, "route_group")
    crossfit_route_groups = grouped_summary(crossfit, "route_group")
    crossfit_folds = grouped_summary(crossfit, "fold")
    report = f"""# CPU-only category-dependent attention-scale inference hybrid

**Decision: {classification}**

## Provenance and alignment

All four inputs are the completed `full381/update500/per_finding_metrics.csv` artifacts under `{RUNS['CONTROL']}`, `{RUNS['SCALE_1_4']}`, `{RUNS['SCALE_1_2']}`, and `{RUNS['SCALE_1_1']}`. The checkpoint paths and SHA256 digests are recorded in `input_provenance.json`. Each arm contains 381 unique target findings across 200 cases, with identical keys, category labels, GT voxel counts, threshold 0.5, and no postprocessing. The reproduced Dice values are CONTROL {REFERENCE['CONTROL']:.6f}, 1/4 {REFERENCE['SCALE_1_4']:.6f}, 1/2 {REFERENCE['SCALE_1_2']:.6f}, and 1/1 {REFERENCE['SCALE_1_1']:.6f}.

## Fixed policy (same-cohort/resubstitution estimate)

The predeclared mapping is 1b→1/1, 1c→1/4, 2b→1/2, 2c→1/2, and all other categories→CONTROL. This is an optimistic feasibility estimate because it was proposed after inspecting the same cohort.

{markdown_table(pd.DataFrame([fixed_summary]))}

Bootstrap: Dice delta {fixed_summary['paired_mean_dice_delta']:+.6f}, 95% CI [{fixed_boot['dice_ci95'][0]:+.6f}, {fixed_boot['dice_ci95'][1]:+.6f}], P(delta>0)={fixed_boot['probability_delta_gt_zero']:.4f}. Leave-one-case-out range [{fixed_loo.mean_dice_delta.min():+.6f}, {fixed_loo.mean_dice_delta.max():+.6f}]. Category 2d is exactly CONTROL for every stored metric.

## Five-fold case cross-fitting

The existing independent 200-case assignment `{fold_provenance['source']}` was used; no case is split. Each held-out fold's category routes were chosen from the other four folds using the predeclared eligibility and tie rules. Full fold/category decisions are in `crossfit_route_selection_by_fold.csv`.

{markdown_table(pd.DataFrame([crossfit_summary]))}

Bootstrap: Dice delta {crossfit_summary['paired_mean_dice_delta']:+.6f}, 95% CI [{crossfit_boot['dice_ci95'][0]:+.6f}, {crossfit_boot['dice_ci95'][1]:+.6f}], P(delta>0)={crossfit_boot['probability_delta_gt_zero']:.4f}. Leave-one-case-out range [{crossfit_loo_case.mean_dice_delta.min():+.6f}, {crossfit_loo_case.mean_dice_delta.max():+.6f}]; leave-one-category-out range [{crossfit_loo_category.mean_dice_delta.min():+.6f}, {crossfit_loo_category.mean_dice_delta.max():+.6f}]. Held-out arm counts: {crossfit.selected_arm.value_counts().to_dict()}.

## Category comparison

{markdown_table(category_comparison)}

## Route stability

{markdown_table(stability)}

## Size and key groups

Fixed by size:

{markdown_table(fixed_sizes)}

Cross-fitted by size:

{markdown_table(cross_sizes)}

Fixed 2d/category detail:

{markdown_table(fixed_details)}

Cross-fitted 2d/category detail:

{markdown_table(cross_details)}

Fixed routed versus non-routed preservation group:

{markdown_table(fixed_route_groups)}

Cross-fitted CONTROL-selected versus attention-routed group:

{markdown_table(crossfit_route_groups)}

Cross-fitted held-out result by fold:

{markdown_table(crossfit_folds)}

## All methods

{markdown_table(all_methods)}

## Recommendation and limitations

Decision-rule checks: `{decision_checks}`. Fixed-policy estimates are not independent validation. Cross-fitting treats learned fold routes as fixed in the primary bootstrap. Categories with very few findings remain underpowered. This analysis routes complete stored prediction rows only; it does not average masks or probabilities and does not rerun inference.

CPU runtime: {runtime:.2f} seconds. Peak RSS: {peak_mb:.1f} MiB. Command: `{' '.join(sys.argv)}`.

## Git diff summary

```
{git_diff}
```

## Git status

```
{git_status}
```
"""
    (OUT / "report.md").write_text(report)
    print(json.dumps({"decision": decision, "fixed": fixed_summary, "crossfit": crossfit_summary, "runtime_seconds": runtime, "peak_rss_mib": peak_mb}, indent=2, default=json_default))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
