#!/usr/bin/env python3
"""Paired ReX finding-level comparison between two global evaluation JSONs."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


REX_ROOT = Path(__file__).resolve().parents[1]
KEYWORD_GROUPS = {
    "nodule": r"\bnodul|lymph node",
    "ground_glass": r"ground[- ]glass|\bGGO\b|crazy paving",
    "effusion": r"effusion",
    "atelectasis": r"atelecta",
    "emphysema": r"emphysem|paraseptal|centrilobular",
    "scarring_fibrosis": r"scar|fibro|architectural distortion|traction",
    "bronchiectasis": r"bronchiect|bronchiolect",
    "consolidation_opacity": r"consolid|opacity|opacities|infiltrat|density",
    "pleural_fissure": r"pleur|fissure",
    "calcification": r"calcif",
    "cyst_bulla": r"\bcyst|cystic|\bbulla|\bbullae",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-eval", type=Path, required=True)
    parser.add_argument("--candidate-eval", type=Path, required=True)
    parser.add_argument(
        "--dataset-json",
        type=Path,
        default=REX_ROOT / "data/MICCAI_challenge_dataset.json",
    )
    parser.add_argument("--split", default="val")
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--meaningful-delta", type=float, default=0.02)
    parser.add_argument("--top-k", type=int, default=25)
    return parser.parse_args()


def load_eval(path: Path) -> tuple[dict[tuple[str, int], dict], dict]:
    data = json.loads(path.read_text())
    values = {}
    for case in data.get("cases", []):
        for key, result in case.get("findings", {}).items():
            idx = int(key.rsplit("_", 1)[-1])
            values[(case["file"], idx)] = {
                "dice": float(result["global_dice"]),
                "hit": bool(result["global_hit"]),
            }
    return values, data.get("summary", data)


def load_metadata(path: Path, split: str) -> dict[tuple[str, int], dict]:
    dataset = json.loads(path.read_text())
    metadata = {}
    for case in dataset[split]:
        for key, prompt in case.get("findings", {}).items():
            idx = int(key)
            pixels = int(case.get("pixels", {}).get(key, 0))
            metadata[(case["name"], idx)] = {
                "category": case.get("categories", {}).get(key, "unknown"),
                "gt_pixels": pixels,
                "size_bin": size_bin(pixels),
                "prompt": prompt,
                "keyword_groups": ";".join(
                    name for name, pattern in KEYWORD_GROUPS.items() if re.search(pattern, prompt, re.I)
                )
                or "other",
            }
    return metadata


def size_bin(pixels: int) -> str:
    if pixels < 100:
        return "tiny_lt_100"
    if pixels < 1_000:
        return "small_100_1k"
    if pixels < 10_000:
        return "medium_1k_10k"
    return "large_ge_10k"


def summarize_group(df: pd.DataFrame, group: str) -> pd.DataFrame:
    rows = []
    for label, sub in df.groupby(group, dropna=False, sort=True):
        rows.append(
            {
                group: label,
                "n": len(sub),
                "baseline_dice": sub.baseline_dice.mean(),
                "candidate_dice": sub.candidate_dice.mean(),
                "mean_delta": sub.delta_dice.mean(),
                "median_delta": sub.delta_dice.median(),
                "improved_n": int((sub.delta_dice > 1e-12).sum()),
                "worsened_n": int((sub.delta_dice < -1e-12).sum()),
                "meaningful_improved_n": int((sub.meaningful_direction == "improved").sum()),
                "meaningful_worsened_n": int((sub.meaningful_direction == "worsened").sum()),
                "baseline_hit_rate": sub.baseline_hit.mean(),
                "candidate_hit_rate": sub.candidate_hit.mean(),
                "hit_gained_n": int((sub.hit_transition == "gained").sum()),
                "hit_lost_n": int((sub.hit_transition == "lost").sum()),
            }
        )
    return pd.DataFrame(rows)


def keyword_summary(df: pd.DataFrame) -> pd.DataFrame:
    expanded = df.assign(keyword_group=df.keyword_groups.str.split(";")).explode("keyword_group")
    return summarize_group(expanded, "keyword_group")


def markdown_table(df: pd.DataFrame, columns: list[str], limit: int | None = None) -> str:
    view = df[columns].head(limit) if limit else df[columns]
    header = "| " + " | ".join(columns) + " |"
    divider = "| " + " | ".join(["---"] * len(columns)) + " |"
    lines = [header, divider]
    for row in view.itertuples(index=False, name=None):
        values = []
        for value in row:
            if isinstance(value, (float, np.floating)):
                values.append(f"{value:.4f}")
            else:
                values.append(str(value).replace("|", "\\|"))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def write_plots(df: pd.DataFrame, category: pd.DataFrame, out_dir: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), constrained_layout=True)
    axes[0].scatter(df.baseline_dice, df.candidate_dice, s=18, alpha=0.55, color="#287271")
    axes[0].plot([0, 1], [0, 1], color="#555555", linewidth=1)
    axes[0].set(xlabel="Baseline Dice", ylabel="Background=1.5 Dice", title="Paired Finding Dice")
    axes[0].set_xlim(0, 1)
    axes[0].set_ylim(0, 1)
    axes[1].hist(df.delta_dice, bins=35, color="#d06c6c", edgecolor="white")
    axes[1].axvline(0, color="#333333", linewidth=1)
    axes[1].set(xlabel="Delta Dice (candidate - baseline)", ylabel="Findings", title="Dice Change Distribution")
    fig.savefig(out_dir / "paired_dice_change.png", dpi=180)
    plt.close(fig)

    ordered = category.sort_values("category")
    colors = ["#287271" if value >= 0 else "#d06c6c" for value in ordered.mean_delta]
    fig, ax = plt.subplots(figsize=(9, 5), constrained_layout=True)
    ax.bar(ordered.category, ordered.mean_delta, color=colors)
    ax.axhline(0, color="#333333", linewidth=1)
    ax.set(xlabel="ReX category", ylabel="Mean delta Dice", title="Mean Dice Change by ReX Category")
    for x, (_, row) in enumerate(ordered.iterrows()):
        ax.text(x, row.mean_delta, f"n={int(row.n)}", ha="center", va="bottom" if row.mean_delta >= 0 else "top", fontsize=8)
    fig.savefig(out_dir / "category_delta.png", dpi=180)
    plt.close(fig)


def main() -> int:
    args = parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    baseline, baseline_summary = load_eval(args.baseline_eval)
    candidate, candidate_summary = load_eval(args.candidate_eval)
    metadata = load_metadata(args.dataset_json, args.split)

    if set(baseline) != set(candidate):
        missing_candidate = sorted(set(baseline) - set(candidate))
        missing_baseline = sorted(set(candidate) - set(baseline))
        raise RuntimeError(
            f"Evaluation finding sets differ: missing candidate={missing_candidate[:5]}, "
            f"missing baseline={missing_baseline[:5]}"
        )

    rows = []
    threshold = args.meaningful_delta
    for key in sorted(baseline):
        old = baseline[key]
        new = candidate[key]
        delta = new["dice"] - old["dice"]
        if delta >= threshold:
            meaningful = "improved"
        elif delta <= -threshold:
            meaningful = "worsened"
        else:
            meaningful = "stable"
        if not old["hit"] and new["hit"]:
            transition = "gained"
        elif old["hit"] and not new["hit"]:
            transition = "lost"
        else:
            transition = "unchanged"
        rows.append(
            {
                "file": key[0],
                "finding_idx": key[1],
                **metadata.get(key, {}),
                "baseline_dice": old["dice"],
                "candidate_dice": new["dice"],
                "delta_dice": delta,
                "baseline_hit": old["hit"],
                "candidate_hit": new["hit"],
                "hit_transition": transition,
                "meaningful_direction": meaningful,
            }
        )
    findings = pd.DataFrame(rows)
    findings.to_csv(args.out_dir / "paired_findings.csv", index=False)
    findings.sort_values("delta_dice", ascending=False).head(args.top_k).to_csv(
        args.out_dir / "top_improved.csv", index=False
    )
    findings.sort_values("delta_dice").head(args.top_k).to_csv(
        args.out_dir / "top_worsened.csv", index=False
    )
    findings.loc[findings.hit_transition != "unchanged"].sort_values(
        ["hit_transition", "delta_dice"], ascending=[True, False]
    ).to_csv(args.out_dir / "hit_transitions.csv", index=False)

    cases = (
        findings.groupby("file")
        .agg(
            n_findings=("finding_idx", "size"),
            baseline_dice=("baseline_dice", "mean"),
            candidate_dice=("candidate_dice", "mean"),
            mean_delta=("delta_dice", "mean"),
            min_delta=("delta_dice", "min"),
            max_delta=("delta_dice", "max"),
        )
        .reset_index()
        .sort_values("mean_delta", ascending=False)
    )
    cases.to_csv(args.out_dir / "paired_cases.csv", index=False)

    category = summarize_group(findings, "category")
    size = summarize_group(findings, "size_bin")
    keyword = keyword_summary(findings)
    category.to_csv(args.out_dir / "category_summary.csv", index=False)
    size.to_csv(args.out_dir / "size_summary.csv", index=False)
    keyword.to_csv(args.out_dir / "keyword_summary.csv", index=False)
    write_plots(findings, category, args.out_dir)

    improved = int((findings.delta_dice > 1e-12).sum())
    worsened = int((findings.delta_dice < -1e-12).sum())
    unchanged = len(findings) - improved - worsened
    meaningful_improved = int((findings.meaningful_direction == "improved").sum())
    meaningful_worsened = int((findings.meaningful_direction == "worsened").sum())
    hit_gained = int((findings.hit_transition == "gained").sum())
    hit_lost = int((findings.hit_transition == "lost").sum())

    report = [
        "# Paired Full-volume Checkpoint Analysis",
        "",
        "## Overall",
        "",
        f"- Findings: {len(findings)} across {findings.file.nunique()} cases.",
        f"- Mean Dice: {baseline_summary['mean_global_dice_per_finding']:.6f} -> "
        f"{candidate_summary['mean_global_dice_per_finding']:.6f} "
        f"(delta {candidate_summary['mean_global_dice_per_finding'] - baseline_summary['mean_global_dice_per_finding']:+.6f}).",
        f"- Any numerical change: improved {improved}, worsened {worsened}, unchanged {unchanged}.",
        f"- Meaningful change (|delta Dice| >= {threshold:g}): improved {meaningful_improved}, "
        f"worsened {meaningful_worsened}.",
        f"- Hit transitions at Dice >= 0.1: gained {hit_gained}, lost {hit_lost}, net {hit_gained-hit_lost:+d}.",
        "",
        "## ReX Category",
        "",
        markdown_table(
            category.sort_values("category"),
            ["category", "n", "baseline_dice", "candidate_dice", "mean_delta", "hit_gained_n", "hit_lost_n"],
        ),
        "",
        "## GT Size",
        "",
        markdown_table(
            size,
            ["size_bin", "n", "baseline_dice", "candidate_dice", "mean_delta", "hit_gained_n", "hit_lost_n"],
        ),
        "",
        "## Prompt Keyword Groups",
        "",
        markdown_table(
            keyword.sort_values("mean_delta", ascending=False),
            ["keyword_group", "n", "baseline_dice", "candidate_dice", "mean_delta", "hit_gained_n", "hit_lost_n"],
        ),
        "",
        "## Largest Improvements",
        "",
        markdown_table(
            findings.sort_values("delta_dice", ascending=False),
            ["file", "finding_idx", "category", "gt_pixels", "baseline_dice", "candidate_dice", "delta_dice", "prompt"],
            15,
        ),
        "",
        "## Largest Regressions",
        "",
        markdown_table(
            findings.sort_values("delta_dice"),
            ["file", "finding_idx", "category", "gt_pixels", "baseline_dice", "candidate_dice", "delta_dice", "prompt"],
            15,
        ),
        "",
    ]
    (args.out_dir / "report.md").write_text("\n".join(report))
    print("\n".join(report[:10]))
    print(f"Saved analysis to {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
