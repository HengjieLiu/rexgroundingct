#!/usr/bin/env python3
"""Hash the shared update-0 network and verify fresh ReX optimizer state."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import torch

ROOT = Path("outputs/original_voxtell_semantic_screen_1k").resolve()
CANONICAL = Path("outputs/voxtell_v11_e1e-5_d1e-4_1gpu_bs1_acc4_10kupd/checkpoints/checkpoint_initial.pth").resolve()
RUNS = ["b0_original", "lobe_direct", "a5_dense_e4", "a5_contrast_e4", "p_d3", "p_d4"]


def digest(state: dict[str, torch.Tensor]) -> tuple[str, int]:
    value = hashlib.sha256()
    count = 0
    for key in sorted(k for k in state if not k.startswith("semantic_screen_head.")):
        tensor = state[key].detach().cpu().contiguous()
        value.update(key.encode())
        value.update(str(tuple(tensor.shape)).encode())
        value.update(tensor.numpy().tobytes())
        count += 1
    return value.hexdigest(), count


def optimizer_state(payload: dict) -> dict:
    state = payload.get("optimizer_state_dict") or payload.get("optimizer") or {}
    slots = state.get("state", {}) if isinstance(state, dict) else {}
    return {"state_slot_count": len(slots), "fresh": len(slots) == 0}


def main() -> None:
    canonical_payload = torch.load(CANONICAL, map_location="cpu", weights_only=False)
    canonical_hash, canonical_count = digest(canonical_payload["network_weights"])
    del canonical_payload
    result = {"canonical": str(CANONICAL), "canonical_shared_hash": canonical_hash,
              "canonical_tensor_count": canonical_count, "arms": {}}
    for run in RUNS:
        path = ROOT / run / "checkpoints/checkpoint_initial.pth"
        payload = torch.load(path, map_location="cpu", weights_only=False)
        shared_hash, tensor_count = digest(payload["network_weights"])
        result["arms"][run] = {
            "checkpoint": str(path), "shared_hash": shared_hash,
            "shared_tensor_count": tensor_count, "matches_canonical": shared_hash == canonical_hash,
            "optimizer": optimizer_state(payload), "optimizer_update": int(payload.get("optimizer_update", 0)),
            "semantic_head_tensor_count": sum(k.startswith("semantic_screen_head.") for k in payload["network_weights"]),
        }
        del payload
    result["all_shared_weights_identical"] = all(x["matches_canonical"] for x in result["arms"].values())
    result["all_start_at_zero"] = all(x["optimizer_update"] == 0 for x in result["arms"].values())
    (ROOT / "initialization_identity.json").write_text(json.dumps(result, indent=2) + "\n")
    if not result["all_shared_weights_identical"] or not result["all_start_at_zero"]:
        raise SystemExit(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
