#!/usr/bin/env python3
"""Read-only propagation audit for the trained Direct token-spatial C1 model.

For matched validation crops, compare the normal C1 forward with a temporary
residual-OFF forward.  The OFF intervention changes only
``z_hat_1_8 = z_1_8 + R`` to ``z_hat_1_8 = z_1_8``; all model weights, prompt
paths, decoder text fusion, attention, and skip connections are unchanged.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from contextlib import contextmanager, nullcontext
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from scripts.audit_encoder_token_spatial_18 import make_model  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path,
                        default=ROOT / "outputs/encoder_token_spatial_18_direct_connector_screen/f1_text/checkpoints/checkpoint_update_250.pth")
    parser.add_argument("--token-cache", type=Path,
                        default=ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt")
    parser.add_argument("--pooled-cache", type=Path,
                        default=ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt")
    parser.add_argument("--connector-init-scale", type=float, default=0.0005673532434397772)
    parser.add_argument("--max-findings", type=int, default=12)
    parser.add_argument("--output-dir", type=Path,
                        default=ROOT / "outputs/encoder_token_spatial_18_direct_propagation_audit")
    return parser.parse_args()


def crop(case: str, finding_idx: int) -> tuple[torch.Tensor, torch.Tensor]:
    arrays = np.load(ROOT / "data/rex_voxtell_preprocessed_v1/cases/val" / case.replace(".nii.gz", ".npz"))
    mask = arrays["masks"][finding_idx]
    center = np.argwhere(mask > 0).mean(axis=0).round().astype(int)
    start = np.maximum(0, np.minimum(center - 96, np.asarray(mask.shape) - 192))
    slices = tuple(slice(int(value), int(value + 192)) for value in start)
    image = torch.from_numpy(arrays["image"][(slice(None), *slices)]).float()[None]
    target = torch.from_numpy(mask[slices]).float()[None, None]
    return image, target


def locations(x: torch.Tensor) -> torch.Tensor:
    """[B,C,D,H,W] -> [B*D*H*W,C], without retaining gradients."""
    if x.ndim != 5:
        raise ValueError(f"Expected [B,C,D,H,W], got {tuple(x.shape)}")
    return x.detach().float().permute(0, 2, 3, 4, 1).reshape(-1, x.shape[1])


def pearson(a: torch.Tensor, b: torch.Tensor) -> float:
    a, b = a.float().flatten(), b.float().flatten()
    a, b = a - a.mean(), b - b.mean()
    return float((a @ b / (a.norm() * b.norm()).clamp_min(1e-12)).item())


def rank(x: torch.Tensor) -> torch.Tensor:
    # Exact ties are very rare for norm maps; this is sufficient for Spearman.
    return x.argsort().argsort().float()


def vector_metrics(conditioned: torch.Tensor, off: torch.Tensor, initial_map: torch.Tensor) -> dict[str, float]:
    c, o = locations(conditioned), locations(off)
    d = c - o
    d_norm = d.norm(dim=-1)
    mean = d.mean(dim=0, keepdim=True)
    feature_cosine = F.cosine_similarity(c, o, dim=-1, eps=1e-12)
    difference_cosine = F.cosine_similarity(d, mean.expand_as(d), dim=-1, eps=1e-12)
    relative_variation = (d - mean).norm(dim=-1).mean() / d_norm.mean().clamp_min(1e-12)
    norm_map = d_norm.reshape(conditioned.shape[0], 1, *conditioned.shape[2:])
    resized = F.interpolate(norm_map, size=initial_map.shape[2:], mode="trilinear", align_corners=False)
    return {
        "relative_norm": float((d.norm() / o.norm().clamp_min(1e-12)).item()),
        "mean_per_position_difference_norm": float(d_norm.mean().item()),
        "spatial_norm_cv": float((d_norm.std(unbiased=False) / d_norm.mean().clamp_min(1e-12)).item()),
        "mean_cosine_to_global_difference": float(difference_cosine.mean().item()),
        "median_cosine_to_global_difference": float(difference_cosine.median().item()),
        "relative_vector_spatial_variation": float(relative_variation.item()),
        "conditioned_off_spatial_cosine_mean": float(feature_cosine.mean().item()),
        "conditioned_off_spatial_cosine_median": float(feature_cosine.median().item()),
        "conditioned_off_fraction_cosine_lt_099": float((feature_cosine < 0.99).float().mean().item()),
        "conditioned_off_fraction_cosine_lt_095": float((feature_cosine < 0.95).float().mean().item()),
        "pattern_pearson_vs_1_8": pearson(resized, initial_map),
        "pattern_spearman_vs_1_8": pearson(rank(resized), rank(initial_map)),
    }


def lesion_metrics(conditioned: torch.Tensor, off: torch.Tensor, target: torch.Tensor) -> dict[str, float]:
    d_norm = (conditioned.detach().float() - off.detach().float()).norm(dim=1, keepdim=True)
    target = F.interpolate(target.float(), size=d_norm.shape[2:], mode="nearest") > 0.5
    inside = d_norm[target]
    outside = d_norm[~target]
    return {
        "difference_norm_inside_gt": float(inside.mean().item()) if inside.numel() else float("nan"),
        "difference_norm_outside_gt": float(outside.mean().item()) if outside.numel() else float("nan"),
        "inside_to_outside_difference_ratio": float((inside.mean() / outside.mean().clamp_min(1e-12)).item()) if inside.numel() and outside.numel() else float("nan"),
    }


def output_metrics(conditioned: torch.Tensor, off: torch.Tensor) -> dict[str, float]:
    c, o = conditioned.detach().float(), off.detach().float()
    probs_c, probs_o = c.sigmoid(), o.sigmoid()
    pred_c, pred_o = probs_c >= 0.5, probs_o >= 0.5
    changed = pred_c != pred_o
    denom = pred_c.sum() + pred_o.sum()
    mask_dice = 1.0 if denom == 0 else float((2 * (pred_c & pred_o).sum() / denom).item())
    return {
        "max_absolute_logit_difference": float((c - o).abs().max().item()),
        "mean_absolute_logit_difference": float((c - o).abs().mean().item()),
        "relative_logit_difference": float(((c - o).norm() / o.norm().clamp_min(1e-12)).item()),
        "probability_map_pearson": pearson(probs_c, probs_o),
        "binary_prediction_changed_voxels": int(changed.sum().item()),
        "binary_prediction_changed_fraction": float(changed.float().mean().item()),
        "conditioned_off_prediction_dice": mask_dice,
    }


@contextmanager
def residual_off(block: torch.nn.Module):
    """Temporarily replace only the encoder residual with exact zero."""
    original_forward = block.forward

    def off_forward(image_feature: torch.Tensor, token_features: torch.Tensor, token_valid_mask: torch.Tensor):
        batch, channels, depth, height, width = image_feature.shape
        prompts = token_features.shape[1]
        conditioned = image_feature[:, None].expand(batch, prompts, channels, depth, height, width)
        conditioned = conditioned.reshape(batch * prompts, channels, depth, height, width)
        delta = image_feature.new_zeros((batch, prompts, channels, depth, height, width))
        return conditioned, delta

    block.forward = off_forward  # type: ignore[method-assign]
    try:
        yield
    finally:
        block.forward = original_forward  # type: ignore[method-assign]


def capture_forward(model: torch.nn.Module, image: torch.Tensor, pooled: torch.Tensor,
                    tokens: torch.Tensor, valid: torch.Tensor, off: bool) -> tuple[dict[str, torch.Tensor], torch.Tensor]:
    block = model.encoder_token_spatial_block
    assert block is not None
    decoder = model.decoder
    captured: dict[str, torch.Tensor] = {}
    handles = []

    def save(name: str):
        def hook(_module: torch.nn.Module, _inputs: tuple[Any, ...], output: Any) -> None:
            value = output[0] if isinstance(output, tuple) else output
            captured[name] = value.detach()
        return hook

    # S0 is post-injection.  S1/S2 are encoder stages 4/5. Decoder stage 0
    # fuses 1/16; stage 1 then fuses the deliberately unconditioned 1/8 skip.
    handles.extend([
        block.register_forward_hook(save("s0_injection_1_8")),
        model.encoder.stages[4].register_forward_hook(save("s1_encoder_1_16")),
        model.encoder.stages[5].register_forward_hook(save("s2_bottleneck_1_32")),
        decoder.transpconvs[0].register_forward_hook(save("s3_decoder_early_pre_1_16_skip")),
        decoder.stages[0].register_forward_hook(save("s3_decoder_early_post_1_16_skip")),
        decoder.transpconvs[1].register_forward_hook(save("s4_decoder_1_8_pre_skip")),
        decoder.stages[1].register_forward_hook(save("s4_decoder_1_8_post_skip")),
    ])
    try:
        context = residual_off(block) if off else nullcontext()
        with context:
            logits = model(image, pooled, token_features=tokens, token_valid_mask=valid)
    finally:
        for handle in handles:
            handle.remove()
    return captured, logits.detach()


def numeric_summary(values: list[float]) -> dict[str, float]:
    x = np.asarray(values, dtype=np.float64)
    return {
        "mean": float(np.nanmean(x)), "median": float(np.nanmedian(x)),
        "q1": float(np.nanquantile(x, .25)), "q3": float(np.nanquantile(x, .75)),
        "iqr": float(np.nanquantile(x, .75) - np.nanquantile(x, .25)),
        "min": float(np.nanmin(x)), "max": float(np.nanmax(x)),
    }


def aggregate(rows: list[dict[str, Any]], stages: list[str]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for stage in stages:
        metric_names = rows[0]["stages"][stage].keys()
        result[stage] = {metric: numeric_summary([row["stages"][stage][metric] for row in rows]) for metric in metric_names}
    out_names = rows[0]["output"].keys()
    result["final_output"] = {metric: numeric_summary([row["output"][metric] for row in rows]) for metric in out_names}
    return result


def fmt(summary: dict[str, Any], metric: str) -> str:
    value = summary[metric]
    return f"{value['median']:.6g} ({value['q1']:.3g}–{value['q3']:.3g})"


def report_text(args: argparse.Namespace, summary: dict[str, Any], stages: list[str]) -> str:
    lines = [
        "# Direct C1 token-spatial propagation audit", "",
        "This is a post-hoc paired forward audit of the trained Direct C1 update-250 checkpoint. "
        "For each of 12 matched validation findings, residual-OFF replaced only `z_hat_1_8 = z_1_8 + R` with `z_hat_1_8 = z_1_8`; weights, prompt, decoder text fusion, S3 1/1 attention, and skips were unchanged.", "",
        "## Aggregate stage metrics", "",
        "Values are median (IQR) over findings. Pattern correlation resamples perturbation norm maps to the 1/8 injection grid.", "",
        "| Stage | Relative perturbation norm | Spatial norm CV | Mean cosine to global difference | Relative spatial variation | Pattern Pearson vs 1/8 |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    labels = {
        "s0_injection_1_8": "S0 injection 1/8", "s1_encoder_1_16": "S1 encoder 1/16",
        "s2_bottleneck_1_32": "S2 bottleneck 1/32", "s3_decoder_early_pre_1_16_skip": "S3 decoder pre 1/16 skip",
        "s3_decoder_early_post_1_16_skip": "S3 decoder post 1/16 skip", "s4_decoder_1_8_pre_skip": "S4 decoder pre 1/8 skip",
        "s4_decoder_1_8_post_skip": "S4 decoder post 1/8 skip",
    }
    for stage in stages:
        s = summary[stage]
        lines.append("| " + " | ".join([labels[stage], fmt(s, "relative_norm"), fmt(s, "spatial_norm_cv"), fmt(s, "mean_cosine_to_global_difference"), fmt(s, "relative_vector_spatial_variation"), fmt(s, "pattern_pearson_vs_1_8")]) + " |")
    early, post16 = summary["s3_decoder_early_pre_1_16_skip"], summary["s3_decoder_early_post_1_16_skip"]
    pre8, post8 = summary["s4_decoder_1_8_pre_skip"], summary["s4_decoder_1_8_post_skip"]
    lines += ["", "## Skip-fusion comparison", "", "| Fusion | Relative norm before | Relative norm after | Post / pre (median) |", "| --- | ---: | ---: | ---: |",
              f"| 1/16 skip | {fmt(early, 'relative_norm')} | {fmt(post16, 'relative_norm')} | {post16['relative_norm']['median'] / max(early['relative_norm']['median'], 1e-12):.6g} |",
              f"| original 1/8 skip | {fmt(pre8, 'relative_norm')} | {fmt(post8, 'relative_norm')} | {post8['relative_norm']['median'] / max(pre8['relative_norm']['median'], 1e-12):.6g} |", "",
              "## Final-output sensitivity", "",
              "| Metric | Median (IQR) |", "| --- | ---: |"]
    for metric in ["max_absolute_logit_difference", "mean_absolute_logit_difference", "relative_logit_difference", "probability_map_pearson", "binary_prediction_changed_fraction", "conditioned_off_prediction_dice"]:
        lines.append(f"| {metric} | {fmt(summary['final_output'], metric)} |")
    lines += ["", "Detailed per-finding values are in `per_finding_metrics.json` and `per_finding_metrics.csv`; aggregate statistics are in `aggregate_metrics.json`."]
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("A CUDA GPU is required for 192^3 propagation audit")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(2026); torch.cuda.manual_seed_all(2026); torch.backends.cudnn.benchmark = False
    device = torch.device("cuda")
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    model = make_model(True, device, checkpoint, "direct", args.connector_init_scale).eval().float()
    token_payload = torch.load(args.token_cache, map_location="cpu", weights_only=False)
    pooled_payload = torch.load(args.pooled_cache, map_location="cpu", weights_only=False)
    records = [record for record in token_payload["records"] if record["split"] == "val"][:args.max_findings]
    token_index = {(r["split"], r["case"], int(r["finding_idx"])): i for i, r in enumerate(token_payload["records"])}
    pooled_index = {(r["split"], r["case"], int(r["finding_idx"])): i for i, r in enumerate(pooled_payload["records"])}
    stages = ["s0_injection_1_8", "s1_encoder_1_16", "s2_bottleneck_1_32", "s3_decoder_early_pre_1_16_skip", "s3_decoder_early_post_1_16_skip", "s4_decoder_1_8_pre_skip", "s4_decoder_1_8_post_skip"]
    rows: list[dict[str, Any]] = []
    with torch.inference_mode():
        for number, record in enumerate(records, 1):
            key = (record["split"], record["case"], int(record["finding_idx"]))
            image_cpu, target_cpu = crop(record["case"], int(record["finding_idx"]))
            image, target = image_cpu.to(device), target_cpu.to(device)
            tokens = token_payload["token_features"][token_index[key]].float()[None, None].to(device)
            valid = tokens.abs().sum(dim=-1).ne(0)
            pooled = pooled_payload["embeddings"][pooled_index[key]].float()[None, None, None].to(device)
            conditioned, logits_conditioned = capture_forward(model, image, pooled, tokens, valid, off=False)
            off, logits_off = capture_forward(model, image, pooled, tokens, valid, off=True)
            missing = [stage for stage in stages if stage not in conditioned or stage not in off]
            if missing:
                raise RuntimeError(f"Missing feature captures: {missing}")
            initial_map = (conditioned[stages[0]].float() - off[stages[0]].float()).norm(dim=1, keepdim=True)
            stage_metrics = {stage: vector_metrics(conditioned[stage], off[stage], initial_map) | lesion_metrics(conditioned[stage], off[stage], target) for stage in stages}
            row = {"ordinal": number, "case": record["case"], "finding_idx": int(record["finding_idx"]), "prompt": record.get("prompt"), "valid_tokens": int(valid.sum().item()), "stages": stage_metrics, "output": output_metrics(logits_conditioned, logits_off)}
            rows.append(row)
            print(json.dumps({"finding": number, "case": row["case"], "s0_rel": stage_metrics[stages[0]]["relative_norm"], "s2_rel": stage_metrics[stages[2]]["relative_norm"], "s4_post_1_8_rel": stage_metrics[stages[-1]]["relative_norm"], "logit_mean_abs": row["output"]["mean_absolute_logit_difference"]}), flush=True)
            del conditioned, off, logits_conditioned, logits_off, image, target, tokens, valid, pooled
            torch.cuda.empty_cache()
    summary = aggregate(rows, stages)
    metadata = {"checkpoint": str(args.checkpoint.resolve()), "connector": "direct", "connector_init_scale": args.connector_init_scale, "findings": len(rows), "gpu": torch.cuda.get_device_name(0), "intervention": "residual OFF only at encoder 1/8; all trained weights and other paths unchanged", "stages": stages}
    (args.output_dir / "per_finding_metrics.json").write_text(json.dumps({"metadata": metadata, "findings": rows}, indent=2, allow_nan=True) + "\n")
    (args.output_dir / "aggregate_metrics.json").write_text(json.dumps({"metadata": metadata, "aggregate": summary}, indent=2, allow_nan=True) + "\n")
    flat = []
    for row in rows:
        base = {key: row[key] for key in ("ordinal", "case", "finding_idx", "prompt", "valid_tokens")}
        for stage, values in row["stages"].items(): flat.append(base | {"kind": "stage", "stage": stage} | values)
        flat.append(base | {"kind": "output", "stage": "final_output"} | row["output"])
    with (args.output_dir / "per_finding_metrics.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=sorted({key for row in flat for key in row}))
        writer.writeheader(); writer.writerows(flat)
    (args.output_dir / "propagation_report.md").write_text(report_text(args, summary, stages))
    print(json.dumps({"output_dir": str(args.output_dir), "findings": len(rows), "s0_median_relative_norm": summary[stages[0]]["relative_norm"]["median"], "bottleneck_median_relative_norm": summary[stages[2]]["relative_norm"]["median"]}, indent=2))


if __name__ == "__main__":
    main()
