#!/usr/bin/env python3
"""Assemble the prespecified incremental-value statistics and final report."""

from __future__ import annotations

import argparse
import csv
import json
import math
import subprocess
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
ROUTE_ONLY_DETAILS = ROOT / "outputs/aca_anatomy_p0_route_only_ablation_probe_20260731T200448Z_l40s/fixed30_representation_details.json"
LOBE_NAMES = ("RUL", "RML", "RLL", "LUL", "LLL")
PRIMARY_METHODS = (
    "FULL",
    "native_full_probability_sum",
    "native_full_probability_mean",
    "native_crop_logit_mean",
    "control_text_only_mlp_seed_mean",
    "control_type_only_seed_mean",
    "control_type_spatial_seed_mean",
    "baseline_parser_rules",
    "baseline_p0_train_crop_frequency",
    "baseline_cohort_majority_descriptive",
    "baseline_uniform",
)
SUBSETS = {
    "all": lambda row: True,
    "explicit_lobe_text": lambda row: as_bool(row["cohort_explicit_lobe_text"]),
    "side_only": lambda row: as_bool(row["cohort_side_only"]),
    "partial_location": lambda row: as_bool(row["cohort_partial_location"]),
    "no_reliable_text_location": lambda row: as_bool(row["cohort_no_reliable_text_location"]),
    "ambiguous_bilateral_diffuse": lambda row: as_bool(row["cohort_ambiguous_bilateral_diffuse"]),
    "parser_gt_agreement": lambda row: as_bool(row["cohort_parser_gt_agreement"]),
    "parser_gt_disagreement": lambda row: as_bool(row["cohort_parser_gt_disagreement"]),
    "image_text_disagreement_or_nonidentical": lambda row: as_bool(row["cohort_image_text_disagreement_or_nonidentical"]),
    "low_dominance": lambda row: as_bool(row["cohort_low_dominance"]),
    "high_dominance": lambda row: as_bool(row["cohort_high_dominance"]),
    "focal": lambda row: as_bool(row["cohort_focal"]),
    "diffuse": lambda row: as_bool(row["cohort_diffuse"]),
    "nontrivial_location": lambda row: as_bool(row["cohort_nontrivial_location"]),
}


def as_bool(value: Any) -> bool:
    return str(value).lower() in {"1", "true", "yes"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--bootstrap-resamples", type=int, default=10_000)
    parser.add_argument("--bootstrap-seed", type=int, default=2028)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    fields: list[str] = []
    for row in rows:
        for field in row:
            if field not in fields:
                fields.append(field)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def normalize(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    total = float(values.sum())
    return values / total if total > 0 else np.full(5, 0.2)


def canonical_target(cohort: dict[str, str]) -> np.ndarray:
    return normalize(np.asarray([float(cohort[f"gt_soft_{name}"]) for name in LOBE_NAMES]))


def calculate_score(
    method: str,
    cohort: dict[str, str],
    probability: np.ndarray,
    **extra: Any,
) -> dict[str, Any]:
    probability = normalize(probability)
    target = canonical_target(cohort)
    dominant = int(target.argmax())
    prediction = int(probability.argmax())
    right, left = float(probability[:3].sum()), float(probability[3:].sum())
    predicted_side = "right" if right > left else "left"
    true_side = cohort["gt_dominant_side"]
    wrong = float(np.max(np.delete(probability, dominant)))
    return {
        "method": method,
        "case_id": cohort["case_id"],
        "finding_idx": int(cohort["finding_idx"]),
        "predicted_lobe": LOBE_NAMES[prediction],
        "top1_correct": prediction == dominant,
        "top2_correct": dominant in np.argsort(-probability, kind="stable")[:2],
        "predicted_side": predicted_side,
        "laterality_correct": predicted_side == true_side,
        "target_lobe_mass": float(probability[dominant]),
        "target_side_mass": right if true_side == "right" else left,
        "lobe_margin": float(probability[dominant] - wrong),
        "side_margin": abs(right - left) * (1 if predicted_side == true_side else -1),
        "cross_entropy": float(-(target * np.log(np.clip(probability, 1e-8, 1))).sum()),
        "brier": float(np.square(probability - target).sum()),
        **{f"score_{name}": float(probability[index]) for index, name in enumerate(LOBE_NAMES)},
        **extra,
    }


def numeric_score(row: dict[str, Any]) -> dict[str, Any]:
    booleans = {"top1_correct", "top2_correct", "laterality_correct"}
    integers = {"finding_idx", "seed"}
    output: dict[str, Any] = dict(row)
    for field in booleans & row.keys():
        output[field] = as_bool(row[field])
    for field in integers & row.keys():
        output[field] = int(row[field])
    for field in (
        "target_lobe_mass", "target_side_mass", "lobe_margin", "side_margin",
        "cross_entropy", "brier", *(f"score_{name}" for name in LOBE_NAMES),
    ):
        if field in row and row[field] != "":
            output[field] = float(row[field])
    return output


def ensemble_controls(
    rows: list[dict[str, Any]],
    cohort_by_key: dict[tuple[str, int], dict[str, str]],
) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, int], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(row["method"], row["case_id"], int(row["finding_idx"]))].append(row)
    result: list[dict[str, Any]] = []
    for (method, case_id, finding_idx), members in grouped.items():
        probability = np.mean(
            [[float(member[f"score_{name}"]) for name in LOBE_NAMES] for member in members], axis=0
        )
        result.append(
            calculate_score(
                f"control_{method}_seed_mean",
                cohort_by_key[(case_id, finding_idx)],
                probability,
                seeds_used="+".join(str(member["seed"]) for member in members),
            )
        )
    return result


def baseline_rows(
    output_root: Path,
    cohort_rows: list[dict[str, str]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    with np.load(output_root / "p0_train_components.npz", allow_pickle=True) as payload:
        target = np.asarray(payload["target"], dtype=np.float64)[:, :5]
        nonempty = np.asarray(payload["nonempty"], dtype=bool)
    eligible = nonempty & (target.sum(1) > 0)
    train_counts = np.bincount(target[eligible].argmax(1), minlength=5).astype(np.float64)
    train_frequency = normalize(train_counts)
    heldout_counts = np.bincount(
        [canonical_target(row).argmax() for row in cohort_rows], minlength=5
    ).astype(np.float64)
    heldout_majority = np.zeros(5)
    heldout_majority[int(heldout_counts.argmax())] = 1
    rows: list[dict[str, Any]] = []
    for cohort in cohort_rows:
        parser = np.zeros(5)
        parsed_lobes = [value for value in cohort["parser_lobes"].split("+") if value]
        if parsed_lobes:
            for name in parsed_lobes:
                parser[LOBE_NAMES.index(name)] = 1 / len(parsed_lobes)
        elif cohort["parser_side"] == "right":
            parser[:3] = 1 / 3
        elif cohort["parser_side"] == "left":
            parser[3:] = 1 / 2
        else:
            parser[:] = 0.2
        uniform = calculate_score("baseline_uniform", cohort, np.full(5, 0.2))
        uniform.update(
            {
                "predicted_lobe": "TIE_ALL",
                "predicted_side": "TIE",
                "top1_correct": 0.2,
                "top2_correct": 0.4,
                "laterality_correct": 0.5,
            }
        )
        rows.extend(
            (
                uniform,
                calculate_score("baseline_parser_rules", cohort, parser),
                calculate_score("baseline_p0_train_crop_frequency", cohort, train_frequency),
                calculate_score("baseline_cohort_majority_descriptive", cohort, heldout_majority),
            )
        )
    definitions = {
        "baseline_uniform": "Uniform 20% over five lobes.",
        "baseline_parser_rules": "One-hot exact parser lobe; uniform across parsed lobes/side; otherwise uniform.",
        "baseline_p0_train_crop_frequency": "Constant distribution from dominant nonempty five-lobe crop targets in the exact 100-update P0 replay.",
        "baseline_cohort_majority_descriptive": "Constant most-common canonical held-out lobe; descriptive upper-bound frequency baseline (uses evaluation labels).",
        "p0_train_crop_counts": dict(zip(LOBE_NAMES, train_counts.astype(int).tolist())),
        "p0_train_crop_probability": dict(zip(LOBE_NAMES, train_frequency.tolist())),
        "heldout_counts": dict(zip(LOBE_NAMES, heldout_counts.astype(int).tolist())),
    }
    return rows, definitions


def metric_value(row: dict[str, Any], metric: str) -> float:
    return float(row[metric])


def aggregate(rows: list[dict[str, Any]], cohort_keys: set[tuple[str, int]] | None = None) -> dict[str, Any]:
    selected = rows if cohort_keys is None else [
        row for row in rows if (row["case_id"], int(row["finding_idx"])) in cohort_keys
    ]
    if not selected:
        return {"cases": 0, "findings": 0}
    return {
        "cases": len({row["case_id"] for row in selected}),
        "findings": len(selected),
        **{
            metric: float(np.mean([metric_value(row, metric) for row in selected]))
            for metric in (
                "top1_correct", "top2_correct", "laterality_correct", "target_lobe_mass",
                "target_side_mass", "lobe_margin", "side_margin", "cross_entropy", "brier",
            )
        },
    }


def cluster_bootstrap_delta(
    rows_a: list[dict[str, Any]],
    rows_b: list[dict[str, Any]],
    metric: str,
    resamples: int,
    seed: int,
    eligible_keys: set[tuple[str, int]] | None = None,
) -> tuple[float, float, float, float, np.ndarray]:
    map_a = {(row["case_id"], int(row["finding_idx"])): metric_value(row, metric) for row in rows_a}
    map_b = {(row["case_id"], int(row["finding_idx"])): metric_value(row, metric) for row in rows_b}
    keys = set(map_a) & set(map_b)
    if eligible_keys is not None:
        keys &= eligible_keys
    cases = sorted({case for case, _ in keys})
    case_deltas = {
        case: np.asarray([map_a[key] - map_b[key] for key in sorted(keys) if key[0] == case])
        for case in cases
    }
    observed = float(np.mean(np.concatenate(list(case_deltas.values()))))
    rng = np.random.default_rng(seed)
    samples = np.empty(resamples, dtype=np.float64)
    for index in range(resamples):
        picked = rng.choice(cases, size=len(cases), replace=True)
        samples[index] = np.mean(np.concatenate([case_deltas[case] for case in picked]))
    low, high = np.percentile(samples, (2.5, 97.5))
    p_low = (np.count_nonzero(samples <= 0) + 1) / (resamples + 1)
    p_high = (np.count_nonzero(samples >= 0) + 1) / (resamples + 1)
    p = min(1.0, 2 * min(p_low, p_high))
    return observed, float(low), float(high), float(p), samples


def cluster_bootstrap_mean(
    rows: list[dict[str, Any]], metric: str, resamples: int, seed: int
) -> tuple[float, float, float]:
    by_case: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        by_case[row["case_id"]].append(metric_value(row, metric))
    cases = sorted(by_case)
    observed = float(np.mean([value for values in by_case.values() for value in values]))
    rng = np.random.default_rng(seed)
    samples = np.empty(resamples)
    for index in range(resamples):
        picked = rng.choice(cases, size=len(cases), replace=True)
        samples[index] = np.mean([value for case in picked for value in by_case[case]])
    low, high = np.percentile(samples, (2.5, 97.5))
    return observed, float(low), float(high)


def holm_adjust(rows: list[dict[str, Any]]) -> None:
    order = sorted(range(len(rows)), key=lambda index: rows[index]["p_value_raw"])
    running = 0.0
    count = len(rows)
    for rank, index in enumerate(order):
        adjusted = min(1.0, (count - rank) * rows[index]["p_value_raw"])
        running = max(running, adjusted)
        rows[index]["p_value_holm"] = running
        rows[index]["holm_reject_0_05"] = running < 0.05


def retrieval_results(output_root: Path, cohort_rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    with np.load(output_root / "inference_ablation_embeddings.npz") as payload:
        conditions = payload["conditions"].astype(str)
        image = np.asarray(payload["image_embeddings"], dtype=np.float64)
        text = np.asarray(payload["text_embeddings"], dtype=np.float64)
        embedding_keys = list(zip(payload["case_ids"].astype(str), payload["finding_ids"].astype(int)))
    cohort_by_key = {(row["case_id"], int(row["finding_idx"])): row for row in cohort_rows}
    ordered_cohort = [cohort_by_key[key] for key in embedding_keys]
    results: list[dict[str, Any]] = []
    for condition_index, condition in enumerate(conditions):
        for anatomy_index, anatomy in enumerate(LOBE_NAMES):
            eligible = [
                index for index, row in enumerate(ordered_cohort)
                if float(row[f"gt_soft_{anatomy}"]) >= 0.05
            ]
            if len(eligible) < 2:
                continue
            similarity = image[condition_index, eligible, anatomy_index] @ text[condition_index, eligible].T
            labels = np.arange(len(eligible))
            results.append(
                {
                    "condition": condition,
                    "anatomy": anatomy,
                    "eligible_findings": len(eligible),
                    "retrieval_top1": float(np.mean(similarity.argmax(1) == labels)),
                    "mean_matched_similarity": float(np.mean(np.diag(similarity))),
                    "mean_mismatched_similarity": float(
                        (similarity.sum() - np.trace(similarity)) / (similarity.size - len(eligible))
                    ),
                }
            )
    return results


def confusion_matrices(
    output_root: Path,
    by_method: dict[str, list[dict[str, Any]]],
    cohort_by_key: dict[tuple[str, int], dict[str, str]],
) -> None:
    for method in PRIMARY_METHODS:
        if method not in by_method:
            continue
        matrix = np.zeros((5, 5), dtype=int)
        for row in by_method[method]:
            key = (row["case_id"], int(row["finding_idx"]))
            truth_index = int(canonical_target(cohort_by_key[key]).argmax())
            if row["predicted_lobe"] not in LOBE_NAMES:
                continue
            predicted = LOBE_NAMES.index(row["predicted_lobe"])
            matrix[truth_index, predicted] += 1
        records = [
            {"true_lobe": LOBE_NAMES[index], **dict(zip(LOBE_NAMES, matrix[index].tolist()))}
            for index in range(5)
        ]
        safe = method.replace("/", "_")
        write_csv(output_root / "confusion_matrices" / f"{safe}.csv", records)


def make_plots(output_root: Path, primary_rows: list[dict[str, Any]], comparisons: list[dict[str, Any]]) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    display = [
        row for row in primary_rows
        if row["method"] in {
            "FULL", "native_full_probability_sum", "native_crop_logit_mean",
            "control_text_only_mlp_seed_mean", "control_type_only_seed_mean",
            "control_type_spatial_seed_mean", "baseline_parser_rules", "baseline_uniform",
        }
    ]
    fig, axis = plt.subplots(figsize=(10, 5))
    x = np.arange(len(display))
    values = np.asarray([row["top1_correct"] for row in display])
    low = np.asarray([row["top1_ci_low"] for row in display])
    high = np.asarray([row["top1_ci_high"] for row in display])
    axis.bar(x, values, color=["#2455a4" if row["method"] == "FULL" else "#8aa4c8" for row in display])
    axis.errorbar(x, values, yerr=np.vstack((values - low, high - values)), fmt="none", color="black", capsize=3)
    axis.set_xticks(x, [row["method"].replace("control_", "").replace("baseline_", "") for row in display], rotation=35, ha="right")
    axis.set_ylim(0, 1)
    axis.set_ylabel("Canonical five-lobe Top-1 accuracy")
    fig.tight_layout()
    fig.savefig(output_root / "plots" / "primary_top1_accuracy.png", dpi=180)
    plt.close(fig)

    visual = [row for row in comparisons if row["comparison_id"] in {"C6", "C7", "C8"}]
    fig, axis = plt.subplots(figsize=(7, 4))
    axis.bar([row["comparison"] for row in visual], [row["delta"] for row in visual], color="#bd4b4b")
    axis.axhline(0, color="black", linewidth=0.8)
    axis.set_ylabel("Full P0 − corruption (Top-1)")
    axis.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(output_root / "plots" / "visual_corruption_degradation.png", dpi=180)
    plt.close(fig)


def main() -> int:
    args = parse_args()
    output_root = args.output_root
    cohort_rows = read_csv(output_root / "cohort_manifest.csv")
    cohort_by_key = {(row["case_id"], int(row["finding_idx"])): row for row in cohort_rows}

    scores: list[dict[str, Any]] = []
    for filename in (
        "inference_ablation_results.csv", "native_voxtell_scores.csv",
        "native_internal_response_scores.csv", "control_per_finding.csv",
    ):
        scores.extend(numeric_score(row) for row in read_csv(output_root / filename))
    controls = [row for row in scores if "seed" in row]
    scores.extend(ensemble_controls(controls, cohort_by_key))
    route_only_details = json.loads(ROUTE_ONLY_DETAILS.read_text())
    for row in route_only_details:
        key = (row["case_id"], int(row["finding_idx"]))
        probability = normalize(np.asarray(row["probability"], dtype=np.float64)[:5])
        scores.append(calculate_score("route_only_prior_matched", cohort_by_key[key], probability))
    baselines, baseline_definitions = baseline_rows(output_root, cohort_rows)
    scores.extend(baselines)
    by_method: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in scores:
        by_method[row["method"]].append(row)

    # Preserve all per-finding predictions in one auditable long table.
    write_csv(output_root / "all_method_per_finding.csv", scores)

    primary_results: list[dict[str, Any]] = []
    bootstrap_results: list[dict[str, Any]] = []
    for method in PRIMARY_METHODS:
        if method not in by_method:
            raise KeyError(f"Missing prespecified method {method}")
        result = {"method": method, **aggregate(by_method[method])}
        for metric, label in (("top1_correct", "top1"), ("laterality_correct", "laterality")):
            observed, low, high = cluster_bootstrap_mean(
                by_method[method], metric, args.bootstrap_resamples,
                args.bootstrap_seed + len(primary_results) * 17 + (0 if label == "top1" else 1),
            )
            result[f"{label}_ci_low"] = low
            result[f"{label}_ci_high"] = high
            bootstrap_results.append(
                {"kind": "method", "method": method, "metric": metric, "estimate": observed, "ci_low": low, "ci_high": high}
            )
        primary_results.append(result)
    write_csv(output_root / "primary_method_results.csv", primary_results)

    nontrivial_keys = {
        key for key, row in cohort_by_key.items() if as_bool(row["cohort_nontrivial_location"])
    }
    comparison_specs = (
        ("C1", "Full P0 vs native full probability SUM", "FULL", "native_full_probability_sum", "top1_correct", None),
        ("C2", "Full P0 vs native full probability SUM, laterality", "FULL", "native_full_probability_sum", "laterality_correct", None),
        ("C3", "Full P0 vs text-only MLP (3-seed mean)", "FULL", "control_text_only_mlp_seed_mean", "top1_correct", None),
        ("C4", "Full P0 vs type-only (3-seed mean)", "FULL", "control_type_only_seed_mean", "top1_correct", None),
        ("C5", "Full P0 vs type+spatial (3-seed mean)", "FULL", "control_type_spatial_seed_mean", "top1_correct", None),
        ("C6", "Full P0 vs zero visual", "FULL", "ZERO_VISUAL", "top1_correct", None),
        ("C7", "Full P0 vs within-scan lobe permutation", "FULL", "WITHIN_SCAN_LOBE_PERMUTED", "top1_correct", None),
        ("C8", "Full P0 vs other-patient same-anatomy visual", "FULL", "OTHER_PATIENT_SAME_ANATOMY", "top1_correct", None),
        ("C9", "Full P0 vs native on nontrivial-location subset", "FULL", "native_full_probability_sum", "top1_correct", nontrivial_keys),
    )
    comparisons: list[dict[str, Any]] = []
    for index, (identifier, label, a, b, metric, subset) in enumerate(comparison_specs):
        delta, low, high, p, _ = cluster_bootstrap_delta(
            by_method[a], by_method[b], metric, args.bootstrap_resamples,
            args.bootstrap_seed + 1000 + index, subset,
        )
        row = {
            "comparison_id": identifier,
            "comparison": label,
            "method_a": a,
            "method_b": b,
            "metric": metric,
            "subset": "all" if subset is None else "nontrivial_location",
            "delta": delta,
            "ci_low": low,
            "ci_high": high,
            "p_value_raw": p,
        }
        comparisons.append(row)
        bootstrap_results.append({"kind": "paired", **row})
    holm_adjust(comparisons)
    write_csv(output_root / "paired_comparisons.csv", comparisons)
    write_csv(output_root / "bootstrap_results.csv", bootstrap_results)

    secondary_specs = (
        ("S1", "Full P0 vs matched-crop native probability SUM", "FULL", "native_crop_probability_sum", "top1_correct"),
        ("S2", "Full P0 vs matched-crop native probability MEAN", "FULL", "native_crop_probability_mean", "top1_correct"),
        ("S3", "Full P0 vs matched-crop native logit MEAN", "FULL", "native_crop_logit_mean", "top1_correct"),
        ("S4", "Full P0 vs matched route-only", "FULL", "route_only_prior_matched", "top1_correct"),
        ("S5", "Full P0 vs no type token", "FULL", "NO_TYPE", "top1_correct"),
        ("S6", "Full P0 vs no spatial token", "FULL", "NO_SPATIAL", "top1_correct"),
        ("S7", "Full P0 vs same-scan global visual", "FULL", "SAME_SCAN_GLOBAL", "top1_correct"),
        ("S8", "Full P0 vs left/right visual swap", "FULL", "LEFT_RIGHT_VISUAL_SWAP", "top1_correct"),
        ("S9", "Full P0 vs other-patient random anatomy", "FULL", "OTHER_PATIENT_RANDOM_ANATOMY", "top1_correct"),
        ("S10", "Full P0 vs random Gaussian matched norm", "FULL", "RANDOM_GAUSSIAN_MATCHED_NORM", "top1_correct"),
    )
    secondary_comparisons = []
    for index, (identifier, label, a, b, metric) in enumerate(secondary_specs):
        delta, low, high, p, _ = cluster_bootstrap_delta(
            by_method[a], by_method[b], metric, args.bootstrap_resamples,
            args.bootstrap_seed + 2000 + index,
        )
        secondary_comparisons.append(
            {
                "comparison_id": identifier, "comparison": label,
                "method_a": a, "method_b": b, "metric": metric,
                "delta": delta, "ci_low": low, "ci_high": high,
                "p_value_raw_uncorrected": p,
                "status": "prespecified robustness/secondary; not in nine-test Holm family",
            }
        )
    write_csv(output_root / "secondary_comparisons.csv", secondary_comparisons)

    subset_results: list[dict[str, Any]] = []
    for subset_name, predicate in SUBSETS.items():
        keys = {key for key, row in cohort_by_key.items() if predicate(row)}
        for method in PRIMARY_METHODS:
            subset_results.append(
                {"subset": subset_name, "method": method, **aggregate(by_method[method], keys)}
            )
    write_csv(output_root / "subset_results.csv", subset_results)

    retrieval = retrieval_results(output_root, cohort_rows)
    write_csv(output_root / "retrieval_results.csv", retrieval)
    confusion_matrices(output_root, by_method, cohort_by_key)
    (output_root / "baseline_definitions.json").write_text(
        json.dumps(baseline_definitions, indent=2) + "\n"
    )

    c = {row["comparison_id"]: row for row in comparisons}
    p0 = next(row for row in primary_results if row["method"] == "FULL")
    native = next(row for row in primary_results if row["method"] == "native_full_probability_sum")
    criteria = {
        "C1_incremental_lobe_value": c["C1"]["ci_low"] > 0 and c["C1"]["p_value_holm"] < 0.05,
        "C2_laterality_significant_or_noninferior": (
            c["C2"]["ci_low"] > 0 and c["C2"]["p_value_holm"] < 0.05
        ) or c["C2"]["ci_low"] > -0.03,
        "C3_beats_text_only": c["C3"]["ci_low"] > 0 and c["C3"]["p_value_holm"] < 0.05,
        "C4_beats_type_only": c["C4"]["ci_low"] > 0 and c["C4"]["p_value_holm"] < 0.05,
        "C5_beats_type_spatial": c["C5"]["ci_low"] > 0 and c["C5"]["p_value_holm"] < 0.05,
        "C6_visual_zero_degrades": c["C6"]["ci_low"] > 0 and c["C6"]["p_value_holm"] < 0.05,
        "C7_lobe_permutation_degrades": c["C7"]["ci_low"] > 0 and c["C7"]["p_value_holm"] < 0.05,
        "C8_patient_visual_replacement_degrades": c["C8"]["ci_low"] > 0 and c["C8"]["p_value_holm"] < 0.05,
        "C9_nontrivial_incremental_value": c["C9"]["ci_low"] > 0 and c["C9"]["p_value_holm"] < 0.05,
    }
    matched_crop_support = secondary_comparisons[0]["ci_low"] > 0
    conclusion = (
        "CONFIRMED_STRONG" if all(criteria.values()) and matched_crop_support else
        "SUPPORTED_PRIMARY_BUT_NOT_MATCHED_CROP_ROBUST" if criteria["C1_incremental_lobe_value"] and not matched_crop_support else
        "SUPPORTED_BUT_NOT_ALL_STRICT_CRITERIA" if criteria["C1_incremental_lobe_value"] else
        "NOT_CONFIRMED"
    )
    aggregate_json = {
        "schema": "aca_p0_incremental_value_final_v1",
        "conclusion": conclusion,
        "criteria": criteria,
        "matched_crop_native_incremental_support": matched_crop_support,
        "canonical_cohort": {"cases": 30, "findings": 49},
        "full_p0": p0,
        "native_voxtell_primary": native,
        "primary_comparisons": comparisons,
        "secondary_comparisons": secondary_comparisons,
        "bootstrap": {"unit": "case", "resamples": args.bootstrap_resamples, "seed": args.bootstrap_seed},
        "p1_used": False,
        "secondary_route_only": aggregate(by_method["route_only_prior_matched"]),
    }
    prompt_swap = json.loads((output_root / "prompt_swap_summary.json").read_text())
    aggregate_json["left_right_prompt_swap"] = prompt_swap
    inference_summary = json.loads((output_root / "inference_ablation_summary.json").read_text())
    aggregate_json["inference_ablation_summary"] = inference_summary
    saved_reproduction = json.loads((output_root / "reproduced_p0_metrics.json").read_text())
    aggregate_json["saved_p0_reproduction"] = saved_reproduction
    (output_root / "aggregate.json").write_text(json.dumps(aggregate_json, indent=2) + "\n")

    make_plots(output_root, primary_results, comparisons)

    def pct(value: float) -> str:
        return f"{100 * value:.1f}%"

    report = [
        "# ACA P0 incremental-value confirmation study",
        "",
        f"**Decision: {conclusion}.** This is a frozen-P0 confirmation study; the failed P1 checkpoint was never loaded, repaired, continued, or deployed.",
        "",
        "## Primary answer",
        "",
        "The originally reported P0 Top-1 is now independently verified as **31/49 (63.3%)** under its original six-way crop-overlap target (five lobes plus GLOBAL). Under the stricter common comparison target used here—full-volume five-lobe GT overlap, GLOBAL removed—the same frozen predictions score **27/49 (55.1%)**. The four-point count difference is target-definition drift, not checkpoint drift.",
        "",
        f"On the canonical full-volume five-lobe target (30 cases, 49 findings), full ACA P0 Top-1 was **{pct(p0['top1_correct'])}** "
        f"(case-bootstrap 95% CI {pct(p0['top1_ci_low'])}–{pct(p0['top1_ci_high'])}), versus native VoxTell probability-SUM **{pct(native['top1_correct'])}** "
        f"({pct(native['top1_ci_low'])}–{pct(native['top1_ci_high'])}). The paired delta was **{100*c['C1']['delta']:+.1f} pp** "
        f"(95% CI {100*c['C1']['ci_low']:+.1f} to {100*c['C1']['ci_high']:+.1f} pp; Holm-adjusted p={c['C1']['p_value_holm']:.4g}).",
        "",
        "Native VoxTell here means the unchanged S3 VoxTell segmentation model: its foreground sigmoid response is integrated within each TotalSegmentator lobe mask only for post-hoc measurement. It receives no lobe mask and no ACA parameters. This is distinct from the frequency baselines.",
        "",
        "## Primary method table",
        "",
        "| Method | Top-1 | Top-2 | Laterality | Target-lobe mass |",
        "|---|---:|---:|---:|---:|",
        *[
            f"| {row['method']} | {pct(row['top1_correct'])} | {pct(row['top2_correct'])} | "
            f"{pct(row['laterality_correct'])} | {pct(row['target_lobe_mass'])} |"
            for row in primary_results
        ],
        "",
        "## Left/right prompt counterfactual",
        "",
        f"Among {prompt_swap['single_side_evaluable']} single-side prompts, swapping whole-word left/right shifted response toward the counterfactual side in "
        f"**{pct(prompt_swap['p0_fraction_shifted_toward_swapped_side'])}** of P0 routes (mean desired-side mass shift {100*prompt_swap['p0_mean_desired_side_mass_shift']:+.1f} pp) and "
        f"**{pct(prompt_swap['native_fraction_shifted_toward_swapped_side'])}** of native VoxTell responses ({100*prompt_swap['native_mean_desired_side_mass_shift']:+.1f} pp).",
        "",
        "## Matched-crop native robustness",
        "",
        f"The exact-crop native VoxTell probability-SUM comparator scored **{pct(aggregate(by_method['native_crop_probability_sum'])['top1_correct'])}** Top-1. "
        f"Full P0 minus this matched-crop baseline was **{100*secondary_comparisons[0]['delta']:+.1f} pp** "
        f"(95% CI {100*secondary_comparisons[0]['ci_low']:+.1f} to {100*secondary_comparisons[0]['ci_high']:+.1f} pp; uncorrected paired bootstrap p={secondary_comparisons[0]['p_value_raw_uncorrected']:.4g}). "
        "This robustness result is reported alongside, not substituted for, the predeclared full-volume native comparison.",
        "",
        "## Frozen-P0 causal component ablations",
        "",
        "| Condition | Top-1 | Laterality | Target-lobe mass |",
        "|---|---:|---:|---:|",
        *[
            f"| {condition} | {pct(inference_summary[condition]['top1'])} | "
            f"{pct(inference_summary[condition]['laterality'])} | "
            f"{pct(inference_summary[condition]['target_lobe_mass'])} |"
            for condition in (
                "FULL", "ZERO_VISUAL", "NO_TYPE", "NO_SPATIAL",
                "WITHIN_SCAN_LOBE_PERMUTED", "OTHER_PATIENT_SAME_ANATOMY",
                "OTHER_PATIENT_RANDOM_ANATOMY", "RANDOM_GAUSSIAN_MATCHED_NORM",
            )
        ],
        "",
        "## Prespecified comparisons",
        "",
        "| ID | Comparison | Delta | 95% case-bootstrap CI | Holm p |",
        "|---|---|---:|---:|---:|",
    ]
    for row in comparisons:
        report.append(
            f"| {row['comparison_id']} | {row['comparison']} | {100*row['delta']:+.1f} pp | "
            f"{100*row['ci_low']:+.1f} to {100*row['ci_high']:+.1f} pp | {row['p_value_holm']:.4g} |"
        )
    report.extend(
        (
            "",
            "## Interpretation guardrails",
            "",
            "- `frequency baseline` is a constant predictor. The primary non-leaky version uses the dominant-lobe frequencies from nonempty crop targets in the exact P0 training replay. A held-out majority baseline is also shown but explicitly marked descriptive because it uses evaluation-label frequencies.",
            "- `native_full_probability_sum` is the prespecified original-VoxTell comparator; MEAN, binary-mask, and exact-crop logit/probability aggregations are robustness checks.",
            "- `FULL` is the saved update-100 P0 checkpoint, rescored against full-volume canonical GT rather than the older parser-mixed six-way target.",
            "- Three-seed control results are averaged at the per-finding probability level; no seed or checkpoint is selected on the held-out cohort.",
            f"- The previously completed matched route-only run is a secondary loss ablation: canonical Top-1 {pct(aggregate(by_method['route_only_prior_matched'])['top1_correct'])}. It still uses TotalSegmentator masks through L_route, so it does not substitute for the native/no-mask VoxTell comparison.",
            "- Statistical resampling is clustered by case, retains all findings within a sampled case, uses 10,000 resamples, and applies Holm correction to the nine prespecified comparisons.",
            "",
            "## Strict criteria",
            "",
        )
    )
    for name, passed in criteria.items():
        report.append(f"- {'PASS' if passed else 'FAIL'} — {name}")
    report.extend(
        (
            "",
            "## Artifacts",
            "",
            "The machine-readable source of truth is `aggregate.json`. Per-finding predictions, paired comparisons, bootstrap results, subset tables, retrieval diagnostics, alignment audit, confusion matrices, and plots are stored beside this report.",
            "",
        )
    )
    (output_root / "report.md").write_text("\n".join(report))
    zh_summary = f"""# ACA P0 增量价值确认实验摘要

## 结论

**{conclusion}：当前结果不支持“TotalSegmentator mask 驱动的 ACA P0 在原始 VoxTell 之上带来 anatomy learning 增量价值”这一主张。**

- 原始 P0 口径已精确复现：六类 crop-overlap target（五肺叶 + GLOBAL）Top-1 = **31/49（63.3%）**。
- 统一为本实验的 full-volume 五肺叶 GT target 后，同一冻结 P0 Top-1 = **27/49（55.1%）**，laterality = **36/49（73.5%）**。
- 未修改的原始 VoxTell full-volume probability-SUM Top-1 = **{int(round(native['top1_correct']*49))}/49（{pct(native['top1_correct'])}）**，laterality = **{int(round(native['laterality_correct']*49))}/49（{pct(native['laterality_correct'])}）**。
- P0 − native 的配对 Top-1 差值 = **{100*c['C1']['delta']:+.1f} pp**（case-cluster bootstrap 95% CI {100*c['C1']['ci_low']:+.1f} 到 {100*c['C1']['ci_high']:+.1f} pp；Holm p={c['C1']['p_value_holm']:.4g}）。
- 完全匹配 P0 crop 的原始 VoxTell probability-SUM 同样是 **36/49（73.5%）**。

## 因果解释

- `ZERO_VISUAL`、`WITHIN_SCAN_LOBE_PERMUTED`、`OTHER_PATIENT_SAME_ANATOMY` 的 Top-1 都保持 **27/49**，没有出现病人特异视觉信息被破坏后的下降。
- `NO_TYPE` 降为 **16/49（32.7%）**，说明现有 P0 主要依赖 anatomy type embedding / 文本到肺叶类型的映射。
- left/right prompt swap 在 21 个单侧可判定 finding 上，仅有 **{pct(prompt_swap['p0_fraction_shifted_toward_swapped_side'])}** 的 P0 route 向反事实侧移动，平均移动 **{100*prompt_swap['p0_mean_desired_side_mass_shift']:+.1f} pp**；原始 VoxTell 分别为 **{pct(prompt_swap['native_fraction_shifted_toward_swapped_side'])}** 和 **{100*prompt_swap['native_mean_desired_side_mass_shift']:+.1f} pp**。

因此，P0 确实学到了一个可读出的 route，但现有证据不能把它解释为优于原始 VoxTell 的、由 TotalSegmentator mask 监督产生的病人特异视觉 anatomy learning。严格结果与所有机器可读表见 `aggregate.json`、`paired_comparisons.csv` 和 `subset_results.csv`。
"""
    (output_root / "summary_zh.md").write_text(zh_summary)

    try:
        git_commit = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, stderr=subprocess.DEVNULL
        ).strip()
    except subprocess.CalledProcessError:
        git_commit = "unborn/no-commit"
    manifest = {
        "schema": "aca_p0_incremental_experiment_manifest_v1",
        "branch": "aca-p0-incremental-value-20260731",
        "git_commit": git_commit,
        "output_root": str(output_root.resolve()),
        "p0_checkpoint": str((ROOT / "outputs/aca_anatomy_p0_probe_20260730T225800Z_retry5_l40s/checkpoints/checkpoint_update_100.pth").resolve()),
        "native_model": str((ROOT / "outputs/azure_ckpt_sync_stage/s3_allcategory_1over1_step6000/fold_0/checkpoint_final.pth").resolve()),
        "failed_p1_policy": "excluded",
        "bootstrap_resamples": args.bootstrap_resamples,
        "bootstrap_seed": args.bootstrap_seed,
    }
    (output_root / "experiment_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"conclusion": conclusion, "criteria": criteria}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
