#!/usr/bin/env python3
"""Exploratory bronchiectasis-only airway soft-prior sweep.

Uses genuine, non-anchored frozen step-6000 probabilities. It never changes the
archived baseline or writes deployable predictions.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import pandas as pd

from totalseg_specialized_p0_audit import dice, load_channels, safe_div, safe_stem, to_model_grid


ROOT = Path(".")
B_ROOT = ROOT / "outputs/totalseg_targeted_relation_audit_v2.15.0"
DEFAULT_OUT = B_ROOT / "bronchiectasis_soft_prior_sweep"
CACHE = ROOT / "outputs/totalseg_lung_vessels_shared_cache_v2.15.0"
PROBS = ROOT / "outputs/totalseg_vessel_component_audit_v2.15.0/genuine_step6000_probabilities"
FRESH_BINARY = ROOT / "outputs/totalseg_vessel_component_audit_v2.15.0/genuine_step6000_binary"
RADII = (5, 10)
FLOORS = (0.75, 0.90)
SEED = 20260804


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=True) + "\n")
    tmp.replace(path)


def atomic_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    fields = sorted({key for row in rows for key in row}) if rows else []
    with tmp.open("w", newline="", encoding="utf-8") as handle:
        if fields:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader(); writer.writerows(rows)
    tmp.replace(path)


def soft_prior(probability: np.ndarray, support: np.ndarray, floor: float) -> np.ndarray:
    if probability.shape != support.shape:
        raise ValueError(f"probability/support shape mismatch: {probability.shape} vs {support.shape}")
    if not 0.0 <= floor <= 1.0:
        raise ValueError(f"floor must be in [0,1], got {floor}")
    return probability * (floor + (1.0 - floor) * support.astype(np.float32))


def binary_metrics(pred: np.ndarray, gt: np.ndarray) -> dict:
    tp = int((pred & gt).sum()); fp = int((pred & ~gt).sum()); fn = int((~pred & gt).sum())
    return {
        "dice": dice(pred, gt), "hit": bool(tp), "pred_voxels": int(pred.sum()),
        "tp_voxels": tp, "fp_voxels": fp, "fn_voxels": fn,
        "precision": safe_div(tp, tp + fp), "recall": safe_div(tp, tp + fn),
    }


def load_probability(case: str, finding_idx: int) -> tuple[np.ndarray, list[int], dict]:
    with np.load(PROBS / f"{safe_stem(case)}.npz") as payload:
        ids = list(map(int, payload["finding_ids"]))
        if finding_idx not in ids:
            raise KeyError(f"{case}: finding {finding_idx} absent from genuine probability IDs {ids}")
        probability = np.asarray(payload["probability"][ids.index(finding_idx)], dtype=np.float32)
        metadata = json.loads(str(payload["metadata_json"]))
    return probability, ids, metadata


def case_bootstrap(frame: pd.DataFrame, metric: str, iterations: int = 10000) -> dict:
    rng = np.random.default_rng(SEED)
    cases = frame.case_id.unique()
    per_case = {case: frame.loc[frame.case_id == case, metric].to_numpy(dtype=float) for case in cases}
    values = np.empty(iterations, dtype=np.float64)
    for index in range(iterations):
        selected = rng.choice(cases, len(cases), replace=True)
        values[index] = np.concatenate([per_case[case] for case in selected]).mean()
    return {
        "cluster": "case", "seed": SEED, "iterations": iterations,
        "mean": float(frame[metric].mean()), "bootstrap_median": float(np.median(values)),
        "ci_low": float(np.quantile(values, 0.025)), "ci_high": float(np.quantile(values, 0.975)),
    }


def run(out: Path) -> None:
    started = time.perf_counter()
    out.mkdir(parents=True, exist_ok=True); (out / "visualizations").mkdir(exist_ok=True)
    cohort = pd.read_csv(B_ROOT / "airway_cohort_manifest.csv")
    cohort = cohort[cohort.airway_group == "bronchiectasis"].copy()
    if len(cohort) != 11 or cohort.case_id.nunique() != 9:
        raise RuntimeError(f"Expected 11 bronchiectasis findings / 9 cases, got {len(cohort)} / {cohort.case_id.nunique()}")
    rows: list[dict] = []
    provenance: list[dict] = []
    for case, case_frame in cohort.groupby("case_id", sort=False):
        first = case_frame.iloc[0]; stem = safe_stem(case)
        ct = nib.load(str(first.ct_path)); affine = ct.affine
        gt_all = load_channels(Path(first.gt_path), affine) > 0
        archived_all = load_channels(Path(first.baseline_binary_path), affine) > 0
        distance_img = nib.load(str(CACHE / "distance_maps" / stem / "distance_to_airway_plus_wall_union_mm.nii.gz"))
        distance = to_model_grid(np.asanyarray(distance_img.dataobj), affine).astype(np.float32)
        fresh_all = load_channels(FRESH_BINARY / f"{stem}.nii.gz", affine) > 0
        for finding in case_frame.itertuples(index=False):
            idx = int(finding.finding_idx); probability, ids, metadata = load_probability(case, idx)
            if metadata.get("schema") != "voxtell_foreground_probability_v1" or metadata.get("model_dir", "").split("/")[-1] != "full200_s3_allcategory_1over1_step6000":
                raise RuntimeError(f"{case}: unexpected probability provenance")
            if probability.shape != distance.shape:
                raise ValueError(f"{case}: probability {probability.shape} != airway distance {distance.shape}")
            channel = ids.index(idx); fresh = probability > 0.5
            if channel >= len(fresh_all) or not np.array_equal(fresh, fresh_all[channel]):
                raise AssertionError(f"{case}/{idx}: saved genuine probability does not reproduce fresh binary")
            gt = gt_all[idx]; archived = archived_all[idx]
            fresh_metrics = binary_metrics(fresh, gt); archived_metrics = binary_metrics(archived, gt)
            mismatch = int(np.count_nonzero(fresh != archived))
            provenance.append({"finding_id": finding.finding_id, "case_id": case, "finding_idx": idx, "probability_path": str(PROBS / f"{stem}.npz"), "fresh_binary_path": str(FRESH_BINARY / f"{stem}.nii.gz"), "archived_binary_path": finding.baseline_binary_path, "airway_distance_path": str(CACHE / "distance_maps" / stem / "distance_to_airway_plus_wall_union_mm.nii.gz"), "fresh_archived_mismatch_voxels": mismatch, "threshold_boundary_repairs": metadata.get("threshold_boundary_repairs"), "binary_reference_used": False})
            for radius in RADII:
                support = distance <= radius
                for floor in FLOORS:
                    adjusted = soft_prior(probability, support, floor)
                    pred = adjusted > 0.5; item = binary_metrics(pred, gt)
                    rows.append({
                        **finding._asdict(), "support_mode": "binary_within_radius", "radius_mm": radius, "floor": floor,
                        "effective_outside_probability_threshold": 0.5 / floor,
                        "fresh_archived_mismatch_voxels": mismatch,
                        "fresh_dice": fresh_metrics["dice"], "archived_dice": archived_metrics["dice"],
                        "soft_dice": item["dice"], "delta_dice_vs_fresh": item["dice"] - fresh_metrics["dice"],
                        "delta_dice_vs_archived": item["dice"] - archived_metrics["dice"],
                        "fresh_hit": fresh_metrics["hit"], "archived_hit": archived_metrics["hit"], "soft_hit": item["hit"],
                        "fresh_tp_voxels": fresh_metrics["tp_voxels"], "fresh_fp_voxels": fresh_metrics["fp_voxels"],
                        "soft_tp_voxels": item["tp_voxels"], "soft_fp_voxels": item["fp_voxels"],
                        "tp_retention_vs_fresh": safe_div(item["tp_voxels"], fresh_metrics["tp_voxels"]),
                        "fp_retention_vs_fresh": safe_div(item["fp_voxels"], fresh_metrics["fp_voxels"]),
                        "prediction_voxels_removed": fresh_metrics["pred_voxels"] - item["pred_voxels"],
                        "soft_precision": item["precision"], "soft_recall": item["recall"],
                    })
    atomic_csv(out / "cohort_manifest.csv", cohort.to_dict("records"))
    atomic_csv(out / "provenance_manifest.csv", provenance)
    atomic_csv(out / "per_finding_results.csv", rows)
    frame = pd.DataFrame(rows); aggregates = []; bootstrap = {}
    for (radius, floor), group in frame.groupby(["radius_mm", "floor"]):
        key = f"r{int(radius)}_floor{floor:.2f}"
        ci = case_bootstrap(group, "delta_dice_vs_fresh"); bootstrap[key] = ci
        delta = group.delta_dice_vs_fresh
        aggregates.append({
            "variant": key, "radius_mm": radius, "floor": floor, "findings": group.finding_id.nunique(), "cases": group.case_id.nunique(),
            "fresh_dice_mean": group.fresh_dice.mean(), "fresh_dice_median": group.fresh_dice.median(),
            "soft_dice_mean": group.soft_dice.mean(), "soft_dice_median": group.soft_dice.median(),
            "delta_dice_mean": delta.mean(), "delta_dice_median": delta.median(),
            "delta_dice_ci_low": ci["ci_low"], "delta_dice_ci_high": ci["ci_high"],
            "improved": int((delta > 1e-9).sum()), "unchanged": int((delta.abs() <= 1e-9).sum()), "degraded": int((delta < -1e-9).sum()),
            "fresh_hit_rate": group.fresh_hit.mean(), "soft_hit_rate": group.soft_hit.mean(), "hit_losses": int((group.fresh_hit & ~group.soft_hit).sum()),
            "mean_tp_retention": group.tp_retention_vs_fresh.mean(), "mean_fp_retention": group.fp_retention_vs_fresh.mean(),
            "total_fp_removed_fraction": safe_div(group.fresh_fp_voxels.sum() - group.soft_fp_voxels.sum(), group.fresh_fp_voxels.sum()),
            "total_prediction_voxels_removed": int(group.prediction_voxels_removed.sum()),
        })
    atomic_csv(out / "aggregate_results.csv", aggregates); atomic_json(out / "bootstrap_results.json", bootstrap)
    aggregate = pd.DataFrame(aggregates).sort_values("delta_dice_mean", ascending=False)
    best = aggregate.iloc[0]
    go = bool(best.delta_dice_mean >= 0.01 and best.delta_dice_ci_low > 0 and best.hit_losses == 0 and best.total_fp_removed_fraction >= 0.10)
    conditional = bool(not go and best.delta_dice_mean > 0 and best.delta_dice_ci_low > 0 and best.hit_losses == 0)
    decision = "GO" if go else "CONDITIONAL GO" if conditional else "NO-GO"
    config = {"schema": "bronchiectasis_airway_soft_prior_sweep_v1", "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "cohort": {"findings": len(cohort), "cases": cohort.case_id.nunique(), "group": "bronchiectasis"}, "probability_provenance": "genuine non-anchored frozen step-6000 float16 sigmoid", "formula": "p_new = p * (floor + (1-floor) * I(distance_to_airway_plus_wall <= radius_mm))", "radii_mm": RADII, "floors": FLOORS, "threshold": "> 0.5", "paired_baseline": "fresh genuine probability > 0.5", "archived_baseline_role": "secondary reference only", "seed": SEED, "deployable": False}
    atomic_json(out / "config.json", config)
    atomic_json(out / "runtime_summary.json", {"cpu_seconds": time.perf_counter() - started, "slurm_job_id": os.environ.get("SLURM_JOB_ID")})
    fig, ax = plt.subplots(figsize=(7, 4)); labels = aggregate.variant.tolist(); means = aggregate.delta_dice_mean.to_numpy(); low = means - aggregate.delta_dice_ci_low.to_numpy(); high = aggregate.delta_dice_ci_high.to_numpy() - means
    ax.errorbar(np.arange(len(labels)), means, yerr=np.vstack([low, high]), fmt="o", capsize=4); ax.axhline(0, color="black", linewidth=.8); ax.axhline(.01, color="red", linestyle="--", linewidth=.8); ax.set_xticks(np.arange(len(labels)), labels, rotation=25); ax.set_ylabel("Mean Dice change vs fresh baseline"); fig.tight_layout(); fig.savefig(out / "visualizations/dice_delta_with_case_bootstrap.png", dpi=170); plt.close(fig)
    (out / "report.md").write_text(f"# Bronchiectasis-only airway soft-prior sweep\n\nDecision: **{decision}**. This is an exploratory, non-deployable analysis.\n\n- Cohort: {len(cohort)} findings / {cohort.case_id.nunique()} cases.\n- Best variant: `{best.variant}`.\n- Mean Dice change vs genuine fresh baseline: {best.delta_dice_mean:+.6f} (case-bootstrap 95% CI {best.delta_dice_ci_low:+.6f} to {best.delta_dice_ci_high:+.6f}).\n- Hit losses: {int(best.hit_losses)}; total FP removal: {best.total_fp_removed_fraction:.2%}; mean TP retention: {best.mean_tp_retention:.2%}.\n- GO required mean Dice gain >=0.01, CI lower bound >0, zero hit losses, and >=10% total FP removal.\n- No official prediction was changed or written.\n")
    print((out / "report.md").read_text())


def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUT); args = parser.parse_args(); run(args.output_dir.resolve())


if __name__ == "__main__":
    main()
