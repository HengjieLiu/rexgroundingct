#!/usr/bin/env python3
"""Compare native VoxTell original and left/right-swapped prompt responses."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from scripts.aca_p0_incremental_score_native import ROOT, LOBE_NAMES, LOBE_VALUES, load_preprocessed_manifest, normalized_nonnegative


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    return parser.parse_args()


def side_mass(probability: np.ndarray, side: str) -> float:
    return float(probability[:3].sum() if side == "right" else probability[3:].sum())


def main() -> int:
    args = parse_args()
    source = list(csv.DictReader((args.output_root / "prompt_swap_manifest.csv").open(newline="", encoding="utf-8")))
    manifest = load_preprocessed_manifest()
    rows = []
    for record in source:
        case_id = record["case_id"]
        finding = int(record["finding_idx"])
        stem = case_id.removesuffix(".nii.gz").removesuffix(".nii")
        arrays = []
        for directory in ("native_voxtell_probabilities", "native_prompt_swap_probabilities"):
            with np.load(args.output_root / directory / f"{stem}.npz") as payload:
                ids = [int(value) for value in payload["finding_ids"]]
                arrays.append(np.asarray(payload["probability"], dtype=np.float32)[ids.index(finding)])
        split = manifest[case_id]["split"]
        lobe = np.load(ROOT / "data/rex_lobe_labels_preprocessed_v1" / split / f"{stem}.npz")["lobe_label"]
        flat_lobe = lobe.reshape(-1)
        label_order = np.asarray([LOBE_VALUES[name] for name in LOBE_NAMES], dtype=np.int64)
        probabilities = [
            normalized_nonnegative(
                np.asarray(
                    np.bincount(flat_lobe, weights=array.reshape(-1), minlength=6)[label_order]
                )
            )
            for array in arrays
        ]
        original, swapped = probabilities
        parser_side = record["parser_side"]
        desired = "left" if parser_side == "right" else "right" if parser_side == "left" else ""
        rows.append(
            {
                **record,
                "desired_swapped_side": desired,
                "original_right_mass": float(original[:3].sum()),
                "swapped_right_mass": float(swapped[:3].sum()),
                "original_desired_side_mass": "" if not desired else side_mass(original, desired),
                "swapped_desired_side_mass": "" if not desired else side_mass(swapped, desired),
                "desired_side_mass_shift": "" if not desired else side_mass(swapped, desired) - side_mass(original, desired),
            }
        )
    with (args.output_root / "native_prompt_swap_results.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    evaluable = [row for row in rows if row["evaluable_single_side"].lower() == "true"]
    p0 = json.loads((args.output_root / "p0_prompt_swap_summary.json").read_text())
    summary = {
        **p0,
        "native_mean_desired_side_mass_shift": float(np.mean([float(row["desired_side_mass_shift"]) for row in evaluable])),
        "native_fraction_shifted_toward_swapped_side": float(np.mean([float(row["desired_side_mass_shift"]) > 0 for row in evaluable])),
    }
    (args.output_root / "prompt_swap_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
