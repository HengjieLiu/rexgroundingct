#!/usr/bin/env python3
"""CPU-only robustness audit for the matched category-2d prior experiment.

This script consumes only existing evaluation/training metadata.  It never loads a
model checkpoint, runs inference, or changes the original comparison artifacts.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import resource
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ARM_C = "OLD_LOSS_CONTROL"
ARM_T = "COMPONENT_SIZE_TREATMENT"
KEY = ["case_id", "finding_id"]
THRESHOLDS = ("0.10", "0.25", "0.50")
FINDING_METRICS = [
    "voxel_auroc", "voxel_auprc", "auprc_over_prevalence",
    "Q_mean_inside_gt", "Q_mean_inside_5mm_support", "Q_mean_outside_support",
    "inside_minus_outside_gap", "peak_inside_gt", "peak_inside_5mm_support",
    "peak_to_gt_distance_mm", "gt_sized_topk_precision",
    "prior_mass_inside_gt_fraction", "prior_mass_inside_5mm_support_fraction",
    "topk_component_recall", "components_covered_at_0.10",
    "components_covered_at_0.25", "components_covered_at_0.50",
    "component_coverage_at_0.10", "component_coverage_at_0.25",
    "component_coverage_at_0.50", "false_prior_component_count_at_0.10",
    "false_prior_component_voxels_at_0.10",
]
LOO_METRICS = [
    "voxel_auroc", "voxel_auprc", "auprc_over_prevalence", "peak_inside_gt",
    "peak_to_gt_distance_mm", "topk_component_recall",
    "component_coverage_at_0.10", "component_coverage_at_0.25",
    "component_coverage_at_0.50", "inside_minus_outside_gap",
    "false_prior_component_count_at_0.10",
]


def read_json(path: Path) -> Any:
    return json.loads(path.read_text())


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, allow_nan=True, default=str) + "\n")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_float(x: Any) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return float("nan")


def git_capture(root: Path, *args: str) -> str:
    try:
        return subprocess.run(
            ["git", *args], cwd=root, check=False, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30,
        ).stdout.strip()
    except Exception as exc:  # audit provenance must not abort analysis
        return f"unavailable: {exc}"


def discover(root: Path, control: Path, treatment: Path, comparison: Path) -> dict[str, Any]:
    patterns = {
        "per_finding_metrics": "**/per_finding_prior_metrics.csv",
        "per_component_metrics": "**/per_component_prior_metrics.csv",
        "aggregate_metrics": "**/aggregate_prior_metrics.json",
        "continuation_decisions": "**/*continuation*decision*.json",
        "component_weights": "**/component_weights.csv",
        "component_volume_statistics": "**/component_volume_statistics.json",
        "training_manifests": "**/*training_manifest*.json",
        "saved_prior_slices": "**/slices/*.npz",
        "saved_visualizations": "**/visualizations/*.png",
    }
    roots = [control, treatment, comparison]
    found: dict[str, Any] = {}
    for label, pat in patterns.items():
        paths = sorted({p.resolve() for d in roots for p in d.glob(pat)})
        found[label] = {"count": len(paths), "paths": [str(p) for p in paths]}
    critical = [
        comparison / "per_finding_prior_metrics.csv",
        comparison / "per_component_prior_metrics.csv",
        comparison / "continuation_decision.json",
        comparison / "component_weights.csv",
        comparison / "component_volume_statistics.json",
        comparison / "matched_training_manifest.json",
        comparison / "checkpoint_provenance.json",
    ]
    found["critical_sha256"] = {str(p.resolve()): sha256(p) for p in critical}
    found["repository_root"] = str(root.resolve())
    found["control_root"] = str(control.resolve())
    found["treatment_root"] = str(treatment.resolve())
    found["comparison_root"] = str(comparison.resolve())
    return found


def target_metadata(root: Path) -> tuple[pd.DataFrame, Path]:
    candidates = sorted(root.glob("outputs/**/targeted_2d_development_manifest.json"))
    if not candidates:
        raise FileNotFoundError("targeted_2d_development_manifest.json not found")
    # Require an exact set match later; prefer the specialist comparison artifact.
    path = next((p for p in candidates if "s3_2d_specialist_fast_comparison" in str(p)), candidates[0])
    obj = read_json(path)
    rows = []
    for case in obj["val"]:
        for finding, category in case["categories"].items():
            rows.append({
                "case_id": case["name"], "finding_id": int(finding),
                "category_label": category, "target_pixels": int(case["pixels"][finding]),
                "target_manifest_size_group": "small-2d" if 100 <= int(case["pixels"][finding]) <= 999 else "other-2d",
                "finding_text": case.get("findings", {}).get(finding, ""),
                "manifest_entity_count": int(case.get("entity_counts", {}).get(finding, 0)),
            })
    return pd.DataFrame(rows), path


def build_pairs(finding: pd.DataFrame, component: pd.DataFrame, meta: pd.DataFrame, vref: float) -> tuple[pd.DataFrame, pd.DataFrame]:
    pairs = []
    for update in (0, 100, 300):
        c = finding[(finding.arm == ARM_C) & (finding["update"] == update)].copy()
        t = finding[(finding.arm == ARM_T) & (finding["update"] == update)].copy()
        m = c.merge(t, on=KEY, suffixes=("_control", "_treatment"), validate="one_to_one")
        m.insert(0, "update", update)
        for metric in FINDING_METRICS:
            # peak_inside_* are persisted as bool; paired deltas are percentage-point
            # differences and therefore require an explicit numeric conversion.
            m[f"delta_{metric}"] = m[f"{metric}_treatment"].astype(float) - m[f"{metric}_control"].astype(float)
        m["component_class"] = np.where(m["component_count_control"] == 1, "single-component", "multi-component")
        pairs.append(m.merge(meta, on=KEY, how="left", validate="one_to_one"))
    fp = pd.concat(pairs, ignore_index=True)

    comp_pairs = []
    ck = KEY + ["component_id"]
    for update in (0, 100, 300):
        c = component[(component.arm == ARM_C) & (component["update"] == update)].copy()
        t = component[(component.arm == ARM_T) & (component["update"] == update)].copy()
        m = c.merge(t, on=ck, suffixes=("_control", "_treatment"), validate="one_to_one")
        m.insert(0, "update", update)
        # Evaluation components are held-out.  This is a counterfactual formula value,
        # explicitly not an observed training weight.
        vol = m["component_physical_volume_mm3_control"].astype(float)
        m["derived_reference_weight"] = np.clip(np.sqrt(vref / vol), 1.0, 4.0)
        m["derived_weight_clipped_at_4"] = np.isclose(m["derived_reference_weight"], 4.0)
        m["actual_training_weight_available"] = False
        m["actual_training_inverse_size_weight"] = np.nan
        m["peak_to_component_distance_available"] = False
        m["peak_to_component_distance_mm_control"] = np.nan
        m["peak_to_component_distance_mm_treatment"] = np.nan
        for th in THRESHOLDS:
            a, b = m[f"covered_at_{th}_control"].astype(bool), m[f"covered_at_{th}_treatment"].astype(bool)
            m[f"coverage_status_{th}"] = np.select(
                [~a & b, a & ~b, a & b],
                ["newly_covered", "lost", "unchanged_covered"], default="unchanged_uncovered",
            )
        a, b = m["topk_covered_control"].astype(bool), m["topk_covered_treatment"].astype(bool)
        m["topk_status"] = np.select([~a & b, a & ~b, a & b], ["newly_covered", "lost", "unchanged_covered"], default="unchanged_uncovered")
        comp_pairs.append(m.merge(meta, on=KEY, how="left", validate="many_to_one"))
    cp = pd.concat(comp_pairs, ignore_index=True)
    # Fixed quartiles from update-300 unique validation components.
    qbase = cp[cp["update"] == 300][ck + ["component_physical_volume_mm3_control"]].drop_duplicates(ck)
    qbase["component_size_quartile"] = pd.qcut(qbase["component_physical_volume_mm3_control"], 4, labels=["Q1-smallest", "Q2", "Q3", "Q4-largest"])
    cp = cp.merge(qbase[ck + ["component_size_quartile"]], on=ck, how="left", validate="many_to_one")
    return fp, cp


def gate_reproduction(fp: pd.DataFrame, comparison: Path) -> dict[str, Any]:
    src = comparison.parent.parent / "scripts/analyze_s3_2d_prior_learnability.py"
    saved = read_json(comparison / "continuation_decision.json")
    u = fp[fp["update"] == 300]
    c = {m: safe_float(u[f"{m}_control"].mean()) for m in FINDING_METRICS}
    t = {m: safe_float(u[f"{m}_treatment"].mean()) for m in FINDING_METRICS}
    # These are macro means, matching aggregate files/gate source.
    peak_gain = t["peak_inside_gt"] - c["peak_inside_gt"]
    component_gain = t["topk_component_recall"] - c["topk_component_recall"]
    net = u["delta_components_covered_at_0.10"]
    improved = int((net > 0).sum())
    gap_required = max(0.005, 0.10 * t["Q_mean_outside_support"])
    false_limit = max(25.0, 3.0 * c["false_prior_component_count_at_0.10"] + 10.0)
    checks = {
        "voxel_auroc_at_least_0.60": t["voxel_auroc"] >= 0.60,
        "inside_mean_meaningfully_above_outside": t["inside_minus_outside_gap"] >= gap_required,
        "auprc_prevalence_ratio_at_least_2": t["auprc_over_prevalence"] >= 2.0,
        "auprc_prevalence_ratio_better_than_control": t["auprc_over_prevalence"] > c["auprc_over_prevalence"],
        "peak_or_component_recall_gain_at_least_10pp": peak_gain >= 0.10 or component_gain >= 0.10,
        "coverage_nonzero_in_multiple_findings": int((u["components_covered_at_0.10_treatment"] > 0).sum()) >= 2,
        "coverage_improvement_not_one_finding": improved >= 2,
        "outside_probability_not_broadly_high": t["Q_mean_outside_support"] < 0.10 and safe_float(u["Q_mean_treatment"].mean()) < 0.25,
        "false_component_burden_not_catastrophic": t["false_prior_component_count_at_0.10"] <= false_limit,
    }
    aggregate_match = {}
    for arm, now in [("control", c), ("treatment", t)]:
        aggregate_match[arm] = {m: bool(np.isclose(now[m], saved[arm][m], equal_nan=True, rtol=1e-10, atol=1e-12)) for m in saved[arm] if m != "n" and m in now}
    source_excerpt = "improved_coverage_findings = int(((merged['components_covered_at_0.10_T'] - merged['components_covered_at_0.10_C']) > 0).sum()); check = improved_coverage_findings >= 2"
    return {
        "update": 300, "saved_status": saved["status"], "reproduced_status": "CONTINUE" if all(checks.values()) else "NO-GO",
        "exact_source_file": str(src.resolve()), "exact_implementation": source_excerpt,
        "threshold_definition": "A component is covered when saved evaluator covered_at_threshold is true; gate compares the per-finding integer count components_covered_at_0.10, treatment minus control.",
        "checks_reproduced": checks, "checks_equal_saved": checks == saved["checks"],
        "aggregate_values_match_saved": aggregate_match,
        "all_aggregate_values_match_saved": all(all(x.values()) for x in aggregate_match.values()),
        "meaningful_gap_required": gap_required, "false_component_limit": false_limit,
        "improved_net_coverage_findings": improved,
        "positive_net_coverage_finding_ids": u.loc[net > 0, KEY].to_dict("records"),
        "negative_net_coverage_findings": int((net < 0).sum()), "equal_net_coverage_findings": int((net == 0).sum()),
        "interpretation_choice": 5,
        "interpretation": "Another reason: zero findings (not one) had a positive net change in the number of components covered at 0.10. Treatment still had nonzero absolute coverage in multiple findings, while newly-covered and lost components can coexist; the misleading gate name does not measure dominance of AUROC/AUPRC/localization gains.",
    }


def leave_one_out(fp: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    rows, ranking, summary = [], [], {}
    for update in (100, 300):
        d = fp[fp["update"] == update].copy()
        full = {m: safe_float(d[f"delta_{m}"].mean()) for m in LOO_METRICS}
        summary[str(update)] = {}
        for _, omitted in d.iterrows():
            keep = d[~((d.case_id == omitted.case_id) & (d.finding_id == omitted.finding_id))]
            row = {"update": update, "omitted_case_id": omitted.case_id, "omitted_finding_id": int(omitted.finding_id)}
            for m in LOO_METRICS:
                loo = safe_float(keep[f"delta_{m}"].mean())
                row[f"full_delta_{m}"] = full[m]
                row[f"leave_one_out_delta_{m}"] = loo
                row[f"influence_{m}"] = full[m] - loo
                ranking.append({
                    "update": update, "metric": m, "case_id": omitted.case_id,
                    "finding_id": int(omitted.finding_id), "full_delta": full[m],
                    "leave_one_out_delta": loo, "influence": full[m] - loo,
                    "absolute_influence": abs(full[m] - loo),
                })
            rows.append(row)
        subset = [r for r in rows if r["update"] == update]
        for m in LOO_METRICS:
            vals = np.array([r[f"leave_one_out_delta_{m}"] for r in subset], dtype=float)
            direction = -1 if m == "peak_to_gt_distance_mm" else 1
            summary[str(update)][m] = {
                "full_delta": full[m], "minimum_loo_delta": safe_float(np.nanmin(vals)),
                "maximum_loo_delta": safe_float(np.nanmax(vals)), "median_loo_delta": safe_float(np.nanmedian(vals)),
                "positive_direction_exclusions": int(np.sum(direction * vals > 0)),
                "exclusions": int(np.sum(np.isfinite(vals))),
            }
    rank = pd.DataFrame(ranking)
    rank["absolute_influence_rank"] = rank.groupby(["update", "metric"])["absolute_influence"].rank(method="first", ascending=False).astype(int)
    return pd.DataFrame(rows), rank.sort_values(["update", "metric", "absolute_influence_rank"]), summary


def composite_influence(fp: pd.DataFrame) -> pd.DataFrame:
    d = fp[fp["update"] == 300].copy()
    favorable = {
        "voxel_auroc": 1, "voxel_auprc": 1, "gt_sized_topk_precision": 1,
        "topk_component_recall": 1, "peak_to_gt_distance_mm": -1,
        "inside_minus_outside_gap": 1,
    }
    zcols = []
    for m, direction in favorable.items():
        x = direction * d[f"delta_{m}"].astype(float)
        sd = x.std(ddof=0)
        col = f"z_{m}"
        d[col] = (x - x.mean()) / sd if sd > 0 else 0.0
        zcols.append(col)
    d["composite_localization_score"] = d[zcols].mean(axis=1)
    return d.sort_values("composite_localization_score", ascending=False)


def macro_micro(fp: pd.DataFrame, cp: pd.DataFrame) -> pd.DataFrame:
    rows = []
    groups = {
        "all": lambda d: np.ones(len(d), dtype=bool),
        "small-2d": lambda d: d["size_group_control"].eq("small-2d"),
        "other-2d": lambda d: d["size_group_control"].eq("other-2d"),
        "single-component": lambda d: d["component_count_control"].eq(1),
        "multi-component": lambda d: d["component_count_control"].gt(1),
    }
    for update in (100, 300):
        f = fp[fp["update"] == update]
        comp = cp[cp["update"] == update]
        for gname, selector in groups.items():
            ff = f[selector(f)]
            keys = set(map(tuple, ff[KEY].to_numpy()))
            cc = comp[[tuple(x) in keys for x in comp[KEY].to_numpy()]]
            for metric in ("voxel_auroc", "voxel_auprc"):
                for arm in ("control", "treatment"):
                    rows.append({"update": update, "group": gname, "metric": metric, "arm": arm,
                                 "finding_macro": safe_float(ff[f"{metric}_{arm}"].mean()), "pooled_micro": np.nan,
                                 "micro_available": False, "note": "True pooled voxel metric unavailable without full probability/label arrays."})
                    w = ff["auc_samples_control"].astype(float)
                    rows.append({"update": update, "group": gname, "metric": metric + "_auc_sample_weighted_descriptive", "arm": arm,
                                 "finding_macro": safe_float(ff[f"{metric}_{arm}"].mean()),
                                 "pooled_micro": safe_float(np.average(ff[f"{metric}_{arm}"], weights=w)),
                                 "micro_available": True, "note": "Descriptive weighted mean only; not a pooled AUROC/AUPRC."})
            for metric, col in [("topk_component_recall", "topk_covered"), *[(f"component_coverage_at_{th}", f"covered_at_{th}") for th in THRESHOLDS]]:
                for arm in ("control", "treatment"):
                    rows.append({"update": update, "group": gname, "metric": metric, "arm": arm,
                                 "finding_macro": safe_float(ff[f"{metric}_{arm}"].mean()),
                                 "pooled_micro": safe_float(cc[f"{col}_{arm}"].astype(float).mean()),
                                 "micro_available": True, "note": "Micro pools GT components; macro gives each finding equal weight."})
    return pd.DataFrame(rows)


def training_exposure(comparison: Path, fp: pd.DataFrame, cp: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    manifest = read_json(comparison / "matched_training_manifest.json")
    entries = pd.DataFrame(manifest["entries"])
    weights = pd.read_csv(comparison / "component_weights.csv").rename(columns={"component_id": "selected_component_id"})
    e = entries.merge(weights[["case_id", "finding_id", "selected_component_id", "reference_weight", "physical_volume_mm3"]],
                      on=["case_id", "finding_id", "selected_component_id"], how="left", validate="many_to_one")
    def jitter(row: pd.Series) -> float:
        comp = np.array([(a + b - 1) / 2 for a, b in row.selected_component_bbox_zyx], dtype=float)
        crop = np.array([(a + b - 1) / 2 for a, b in row.crop_bbox_zyx], dtype=float)
        # bbox order z,y,x, spacing stored x,y,z
        spacing_zyx = np.array(row.spacing_xyz[::-1], dtype=float)
        return float(np.linalg.norm((comp - crop) * spacing_zyx))
    e["spatial_jitter_magnitude_mm"] = e.apply(jitter, axis=1)
    all_exp = e.groupby(KEY, as_index=False).agg(
        total_training_appearances=("micro_step_index", "size"),
        selected_placement_appearances=("selected_component_id", "size"),
        small_2d_sampling_appearances=("sampling_stratum", lambda x: int((x == "small").sum())),
        average_spatial_jitter_magnitude_mm=("spatial_jitter_magnitude_mm", "mean"),
        average_component_weight=("reference_weight", "mean"),
        fraction_appearances_at_max_weight=("reference_weight", lambda x: safe_float(np.isclose(x.astype(float), 4.0).mean())),
    )
    target = fp[fp["update"] == 300][KEY + ["category_label", "size_group_control", "component_count_control"]].drop_duplicates(KEY)
    target = target.merge(all_exp, on=KEY, how="left", validate="one_to_one")
    countcols = ["total_training_appearances", "selected_placement_appearances", "small_2d_sampling_appearances"]
    target[countcols] = target[countcols].fillna(0).astype(int)
    target["present_in_training_manifest"] = target.total_training_appearances > 0
    deltas = fp[fp["update"] == 300][KEY + [f"delta_{m}" for m in ["voxel_auroc", "voxel_auprc", "topk_component_recall", "gt_sized_topk_precision"]]]
    target = target.merge(deltas, on=KEY, how="left", validate="one_to_one")
    # Validation component descriptors are meaningful correlates even though exposure is zero.
    valdesc = cp[cp["update"] == 300].groupby(KEY, as_index=False).agg(
        mean_validation_component_volume_mm3=("component_physical_volume_mm3_control", "mean"),
        mean_derived_reference_weight=("derived_reference_weight", "mean"),
        fraction_validation_components_at_derived_cap=("derived_weight_clipped_at_4", "mean"),
    )
    target = target.merge(valdesc, on=KEY, how="left", validate="one_to_one")
    correlations = []
    try:
        from scipy.stats import spearmanr
        for x in ["total_training_appearances", "mean_validation_component_volume_mm3", "mean_derived_reference_weight", "component_count_control"]:
            for y in ["delta_voxel_auroc", "delta_voxel_auprc", "delta_topk_component_recall", "delta_gt_sized_topk_precision"]:
                if target[x].nunique(dropna=True) < 2:
                    rho, p, reason = np.nan, np.nan, "constant predictor; correlation undefined"
                else:
                    rho, p = spearmanr(target[x], target[y], nan_policy="omit")
                    reason = "descriptive only; n=25"
                correlations.append({"predictor": x, "outcome": y, "spearman_rho": rho, "p_value": p, "note": reason})
    except Exception as exc:
        correlations.append({"predictor": "all", "outcome": "all", "spearman_rho": np.nan, "p_value": np.nan, "note": f"scipy unavailable: {exc}"})
    audit = {
        "manifest_entries": len(e), "unique_training_findings": int(len(all_exp)),
        "target_findings_present_in_training_manifest": int(target.present_in_training_manifest.sum()),
        "held_out_exposure_interpretation": "All target-25 findings are validation findings absent from the matched training manifest; direct per-target exposure and actual assigned training weights are zero/unavailable. Derived validation weights use the documented formula and are counterfactual descriptors only.",
    }
    return target, pd.DataFrame(correlations), {"summary": audit, "all_training_exposure": all_exp}


def threshold_table(fp: pd.DataFrame, cp: pd.DataFrame, dominant: tuple[str, int]) -> pd.DataFrame:
    rows = []
    for update in (100, 300):
        f = fp[fp["update"] == update]
        comp = cp[cp["update"] == update]
        keep = ~((comp.case_id == dominant[0]) & (comp.finding_id == dominant[1]))
        for th in THRESHOLDS:
            status = comp[f"coverage_status_{th}"]
            fdelta = f[f"delta_components_covered_at_{th}"]
            rows.append({
                "update": update, "threshold": float(th), "diagnostic_only": False,
                "newly_covered_components": int((status == "newly_covered").sum()),
                "lost_components": int((status == "lost").sum()),
                "unchanged_covered_components": int((status == "unchanged_covered").sum()),
                "unchanged_uncovered_components": int((status == "unchanged_uncovered").sum()),
                "unique_findings_with_new_component": int(comp.loc[status == "newly_covered", KEY].drop_duplicates().shape[0]),
                "unique_findings_with_lost_component": int(comp.loc[status == "lost", KEY].drop_duplicates().shape[0]),
                "findings_positive_net_component_count": int((fdelta > 0).sum()),
                "findings_negative_net_component_count": int((fdelta < 0).sum()),
                "findings_equal_net_component_count": int((fdelta == 0).sum()),
                "newly_covered_after_excluding_dominant": int(((status == "newly_covered") & keep).sum()),
                "lost_after_excluding_dominant": int(((status == "lost") & keep).sum()),
                "unique_new_findings_after_excluding_dominant": int(comp.loc[(status == "newly_covered") & keep, KEY].drop_duplicates().shape[0]),
            })
    return pd.DataFrame(rows)


def taxonomy(fp: pd.DataFrame, cp: pd.DataFrame) -> pd.DataFrame:
    f = fp[fp["update"] == 300].copy()
    c = cp[cp["update"] == 300]
    new_counts = c.groupby(KEY)["coverage_status_0.10"].apply(lambda x: int((x == "newly_covered").sum())).rename("new_components_0.10")
    f = f.merge(new_counts, on=KEY, how="left")
    rows = []
    for _, r in f.iterrows():
        positive_rank = sum(r[f"delta_{m}"] > 0 for m in ["voxel_auroc", "voxel_auprc", "gt_sized_topk_precision", "topk_component_recall"])
        labels = []
        if r["new_components_0.10"] > 0: labels.append("COVERAGE_GAIN")
        if r["new_components_0.10"] == 0 and positive_rank >= 2: labels.append("RANKING_GAIN_NO_COVERAGE")
        if r.delta_peak_to_gt_distance_mm <= -5 and not bool(r.peak_inside_5mm_support_treatment): labels.append("PEAK_MOVED_CLOSER")
        if r.delta_Q_mean_inside_gt > 0 and r["new_components_0.10"] == 0: labels.append("INSIDE_PROBABILITY_GAIN")
        if positive_rank >= 2 and r["delta_component_coverage_at_0.10"] <= 0: labels.append("EXTENT_LIMITED")
        if (positive_rank >= 2 or r["new_components_0.10"] > 0) and r["delta_false_prior_component_count_at_0.10"] >= 2: labels.append("FALSE_POSITIVE_TRADEOFF")
        negligible = (abs(r.delta_voxel_auroc) < .005 and abs(r.delta_voxel_auprc) < .01 and
                      abs(r.delta_gt_sized_topk_precision) < .01 and abs(r.delta_peak_to_gt_distance_mm) < 5 and
                      r["delta_components_covered_at_0.10"] == 0)
        if negligible: labels.append("NO_RESPONSE")
        bad = sum([r.delta_voxel_auprc < 0, r.delta_gt_sized_topk_precision < 0,
                   r.delta_topk_component_recall < 0, r.delta_peak_to_gt_distance_mm > 5,
                   r["delta_false_prior_component_count_at_0.10"] > 2, r["delta_component_coverage_at_0.10"] < 0])
        if bad >= 2: labels.append("DEGRADATION")
        rows.append({"case_id": r.case_id, "finding_id": int(r.finding_id), "category_label": r.category_label,
                     "size_group": r.size_group_control, "component_class": r.component_class,
                     "labels": ";".join(labels) if labels else "UNCLASSIFIED", "new_components_0.10": int(r["new_components_0.10"]),
                     "positive_ranking_metrics": positive_rank})
    return pd.DataFrame(rows)


def trajectory(fp: pd.DataFrame, cp: pd.DataFrame, loo_summary: dict[str, Any], composite: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for update in (100, 300):
        f, c = fp[fp["update"] == update], cp[cp["update"] == update]
        # Dominant per update by a simple favorable rank sum.
        score = (f.delta_voxel_auroc.rank(pct=True) + f.delta_voxel_auprc.rank(pct=True) +
                 f.delta_topk_component_recall.rank(pct=True) + (-f.delta_peak_to_gt_distance_mm).rank(pct=True))
        dom = f.loc[score.idxmax()]
        rows.append({
            "update": update, "findings_improved_auroc": int((f.delta_voxel_auroc > 0).sum()),
            "findings_improved_auprc": int((f.delta_voxel_auprc > 0).sum()),
            "findings_peak_distance_improved": int((f.delta_peak_to_gt_distance_mm < 0).sum()),
            "findings_with_newly_covered_components_0.10": int(c.loc[c["coverage_status_0.10"] == "newly_covered", KEY].drop_duplicates().shape[0]),
            "newly_covered_components_0.10": int((c["coverage_status_0.10"] == "newly_covered").sum()),
            "lost_components_0.10": int((c["coverage_status_0.10"] == "lost").sum()),
            "findings_positive_net_coverage_count_0.10": int((f["delta_components_covered_at_0.10"] > 0).sum()),
            "findings_worsened_false_component_burden": int((f["delta_false_prior_component_count_at_0.10"] > 0).sum()),
            "dominant_case_id": dom.case_id, "dominant_finding_id": int(dom.finding_id),
            "auroc_loo_positive_exclusions": loo_summary[str(update)]["voxel_auroc"]["positive_direction_exclusions"],
            "auprc_loo_positive_exclusions": loo_summary[str(update)]["voxel_auprc"]["positive_direction_exclusions"],
            "peak_distance_loo_improved_exclusions": loo_summary[str(update)]["peak_to_gt_distance_mm"]["positive_direction_exclusions"],
        })
    return pd.DataFrame(rows)


def dominant_audit(fp: pd.DataFrame, cp: pd.DataFrame, composite: pd.DataFrame, exposure: pd.DataFrame, threshold: pd.DataFrame) -> dict[str, Any]:
    candidates = composite.head(2)
    records = []
    for _, f in candidates.iterrows():
        comps = cp[(cp["update"] == 300) & (cp.case_id == f.case_id) & (cp.finding_id == f.finding_id)]
        exp = exposure[(exposure.case_id == f.case_id) & (exposure.finding_id == f.finding_id)].iloc[0]
        records.append({
            "case_id": f.case_id, "finding_id": int(f.finding_id), "category_label": f.category_label,
            "size_group": f.size_group_control, "component_count": int(f.component_count_control),
            "component_volumes_mm3": comps.component_physical_volume_mm3_control.tolist(),
            "component_size_quartiles": comps.component_size_quartile.astype(str).tolist(),
            "derived_reference_weights_not_training_assigned": comps.derived_reference_weight.tolist(),
            "derived_weights_at_cap_4": int(comps.derived_weight_clipped_at_4.sum()),
            "newly_covered_components": {th: int((comps[f"coverage_status_{th}"] == "newly_covered").sum()) for th in THRESHOLDS},
            "lost_components": {th: int((comps[f"coverage_status_{th}"] == "lost").sum()) for th in THRESHOLDS},
            "control_coverage": {th: safe_float(f[f"component_coverage_at_{th}_control"]) for th in THRESHOLDS},
            "treatment_coverage": {th: safe_float(f[f"component_coverage_at_{th}_treatment"]) for th in THRESHOLDS},
            "metric_deltas": {m: safe_float(f[f"delta_{m}"]) for m in ["voxel_auroc", "voxel_auprc", "peak_to_gt_distance_mm", "gt_sized_topk_precision", "topk_component_recall", "prior_mass_inside_gt_fraction", "false_prior_component_count_at_0.10"]},
            "control_baseline": {m: safe_float(f[f"{m}_control"]) for m in ["voxel_auroc", "voxel_auprc", "peak_to_gt_distance_mm", "gt_sized_topk_precision", "topk_component_recall"]},
            "training_appearances": int(exp.total_training_appearances),
            "overrepresented_in_training": False,
            "composite_localization_score": safe_float(f.composite_localization_score),
        })
    ucomp = cp[cp["update"] == 300]
    return {
        "gate_driver_identity": None,
        "gate_driver_explanation": "There is no positive-net-coverage gate driver: zero findings increased their number of covered components at 0.10. The entries below are localization-influence candidates, not causes of the failed gate.",
        "dominant_localization_candidates": records,
        "component_accounting_update300": {
            th: {
                "newly_covered": int((ucomp[f"coverage_status_{th}"] == "newly_covered").sum()),
                "lost": int((ucomp[f"coverage_status_{th}"] == "lost").sum()),
                "unique_new_findings": int(ucomp.loc[ucomp[f"coverage_status_{th}"] == "newly_covered", KEY].drop_duplicates().shape[0]),
            } for th in THRESHOLDS
        },
        "dominant_for_exclusion": {"case_id": records[0]["case_id"], "finding_id": records[0]["finding_id"], "definition": "highest mean standardized favorable delta across six ranking/localization metrics"},
    }


def make_visualizations(control: Path, treatment: Path, out: Path, fp: pd.DataFrame, cp: pd.DataFrame, composite: pd.DataFrame, taxonomy_df: pd.DataFrame) -> list[dict[str, Any]]:
    f = fp[fp["update"] == 300].copy()
    tax = taxonomy_df.set_index(KEY)
    selections: list[tuple[str, pd.Series]] = []
    selections.append(("dominant_localization_influence", composite.iloc[0]))
    selections.append(("second_localization_influence", composite.iloc[1]))
    ranking = f[["RANKING_GAIN_NO_COVERAGE" in tax.loc[(r.case_id, r.finding_id), "labels"] for _, r in f.iterrows()]]
    if len(ranking): selections.append(("ranking_gain_without_coverage", ranking.sort_values("delta_voxel_auprc", ascending=False).iloc[0]))
    moved = f[(f.delta_peak_to_gt_distance_mm <= -5) & (~f.peak_inside_5mm_support_treatment.astype(bool))]
    if len(moved):
        selections.append(("peak_moved_closer_outside_support", moved.sort_values("delta_peak_to_gt_distance_mm").iloc[0]))
    else:
        # Preserve the requested six-role visual audit while making the lack of an
        # exact PEAK_MOVED_CLOSER case explicit in the role name.
        outside = f[~f.peak_inside_5mm_support_treatment.astype(bool)]
        fallback = (outside if len(outside) else f).sort_values("delta_peak_to_gt_distance_mm").iloc[0]
        selections.append(("peak_outside_fallback_no_material_closer_match", fallback))
    degradation = f[["DEGRADATION" in tax.loc[(r.case_id, r.finding_id), "labels"] for _, r in f.iterrows()]]
    if len(degradation): selections.append(("largest_degradation", degradation.sort_values("delta_voxel_auprc").iloc[0]))
    noresp = f[["NO_RESPONSE" in tax.loc[(r.case_id, r.finding_id), "labels"] for _, r in f.iterrows()]]
    if not len(noresp):
        noresp = f.assign(_mag=f.delta_voxel_auroc.abs() + f.delta_voxel_auprc.abs() + f.delta_gt_sized_topk_precision.abs()).sort_values("_mag")
    selections.append(("representative_no_response", noresp.iloc[0]))
    # Keep all requested audit roles even if one finding legitimately occupies
    # two roles; role-specific filenames make that overlap explicit.
    records = []
    vis = out / "visualizations"; vis.mkdir(parents=True, exist_ok=True)
    for role, r in selections:
        key = (r.case_id, int(r.finding_id))
        stem = r.case_id.replace(".nii.gz", "") + f"_finding_{int(r.finding_id)}.npz"
        cpath = control / "evaluation/target25_update_300/slices" / stem
        tpath = treatment / "evaluation/target25_update_300/slices" / stem
        if not cpath.exists() or not tpath.exists():
            records.append({"role": role, "case_id": key[0], "finding_id": key[1], "status": "missing slice"}); continue
        cnp, tnp = np.load(cpath), np.load(tpath)
        # GT-centered slices are paired and most interpretable for extent.
        ct, gt, qc, qt = cnp["ct_gt"], cnp["gt_gt"], cnp["q_gt"].astype(float), tnp["q_gt"].astype(float)
        vmax = max(float(np.nanmax(qc)), float(np.nanmax(qt)), 1e-6)
        dv = qt - qc; lim = max(float(np.nanmax(np.abs(dv))), 1e-6)
        fig, ax = plt.subplots(1, 5, figsize=(19, 4), constrained_layout=True)
        ax[0].imshow(ct, cmap="gray"); ax[0].set_title("CT (GT slice)")
        ax[1].imshow(gt, cmap="viridis", vmin=0, vmax=1); ax[1].set_title("GT (binary slice)")
        im2 = ax[2].imshow(qc, cmap="magma", vmin=0, vmax=vmax); ax[2].set_title("Control prior")
        ax[3].imshow(qt, cmap="magma", vmin=0, vmax=vmax); ax[3].set_title("Treatment prior")
        im4 = ax[4].imshow(dv, cmap="coolwarm", vmin=-lim, vmax=lim); ax[4].set_title("Treatment - control")
        for a in ax:
            a.axis("off")
        fig.colorbar(im2, ax=ax[2:4], shrink=.7, label="Prior probability (shared scale)")
        fig.colorbar(im4, ax=ax[4], shrink=.7, label="Delta")
        comps = cp[(cp["update"] == 300) & (cp.case_id == key[0]) & (cp.finding_id == key[1])]
        vols = ",".join(f"{v:.1f}" for v in comps.component_physical_volume_mm3_control)
        weights = ",".join(f"{v:.2f}" for v in comps.derived_reference_weight)
        cov = "/".join(f"{int(r[f'components_covered_at_{th}_control'])}->{int(r[f'components_covered_at_{th}_treatment'])}" for th in THRESHOLDS)
        fig.suptitle(f"{role}: {key[0]} finding {key[1]} | comps={len(comps)} vol mm3=[{vols}] derived w=[{weights}] | covered C->T @.10/.25/.50={cov}\npeak distance {r.peak_to_gt_distance_mm_control:.1f}->{r.peak_to_gt_distance_mm_treatment:.1f} mm; full 3D peak coordinates unavailable")
        opath = vis / f"{role}.png"; fig.savefig(opath, dpi=150); plt.close(fig)
        records.append({"role": role, "case_id": key[0], "finding_id": key[1], "path": str(opath.resolve()), "status": "created from saved GT-centered 2D slice"})
    return records


def grouped_effects(fp: pd.DataFrame, cp: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for update in (100, 300):
        f = fp[fp["update"] == update]
        groups = {"all": f, "small-2d": f[f.size_group_control == "small-2d"], "other-2d": f[f.size_group_control == "other-2d"],
                  "single-component": f[f.component_count_control == 1], "multi-component": f[f.component_count_control > 1]}
        for name, d in groups.items():
            for m in FINDING_METRICS:
                rows.append({"update": update, "aggregation_unit": "finding", "group": name, "metric": m, "n": len(d),
                             "control": safe_float(d[f"{m}_control"].mean()), "treatment": safe_float(d[f"{m}_treatment"].mean()), "delta": safe_float(d[f"delta_{m}"].mean())})
        c = cp[cp["update"] == update]
        cgroups = {"below-1000": c[c.below_1000_voxels_control.astype(bool)]}
        cgroups.update({q: c[c.component_size_quartile.astype(str) == q] for q in ["Q1-smallest", "Q2", "Q3", "Q4-largest"]})
        for name, d in cgroups.items():
            for metric, col in [("topk_component_recall", "topk_covered"), *[(f"component_coverage_at_{th}", f"covered_at_{th}") for th in THRESHOLDS]]:
                cv, tv = d[f"{col}_control"].astype(float).mean(), d[f"{col}_treatment"].astype(float).mean()
                rows.append({"update": update, "aggregation_unit": "component", "group": name, "metric": metric, "n": len(d), "control": cv, "treatment": tv, "delta": tv-cv})
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    started = time.time(); root = args.root.resolve()
    comparison = root / "outputs/s3_2d_prior_learnability_comparison"
    control = root / "outputs/s3_2d_prior_old_loss_control"
    treatment = root / "outputs/s3_2d_prior_component_size_treatment"
    out = (args.output or comparison / "robustness_audit").resolve()
    if out.exists() and any(out.iterdir()):
        existing = {p.name for p in out.iterdir()}
        # A failed attempt can leave only the input manifest.  Resuming that exact
        # audit directory is safe; completed or otherwise populated audits remain
        # protected from overwrite.
        if not existing.issubset({"audit_input_manifest.json"}):
            raise SystemExit(f"Refusing to overwrite non-empty audit directory: {out} ({sorted(existing)})")
    out.mkdir(parents=True, exist_ok=True)
    decision_hash_before = sha256(comparison / "continuation_decision.json")
    manifest = discover(root, control, treatment, comparison)
    metadata, metadata_path = target_metadata(root)
    manifest["target25_manifest"] = str(metadata_path.resolve())
    manifest["command"] = " ".join(sys.argv)
    manifest["environment"] = {k: os.environ.get(k) for k in ["SLURM_JOB_ID", "SLURM_CPUS_PER_TASK", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"]}
    write_json(out / "audit_input_manifest.json", manifest)

    finding = pd.read_csv(comparison / "per_finding_prior_metrics.csv")
    component = pd.read_csv(comparison / "per_component_prior_metrics.csv")
    vref = float(read_json(comparison / "component_volume_statistics.json")["physical_volume_mm3"]["median_V_ref"])
    fp, cp = build_pairs(finding, component, metadata, vref)
    fp.to_csv(out / "per_finding_paired_deltas.csv", index=False)
    cp.to_csv(out / "per_component_paired_deltas.csv", index=False)
    grouped_effects(fp, cp).to_csv(out / "paired_effect_summary_by_group.csv", index=False)

    gate = gate_reproduction(fp, comparison); write_json(out / "gate_reproduction.json", gate)
    loo, influence, loo_summary = leave_one_out(fp)
    loo.to_csv(out / "leave_one_finding_out.csv", index=False)
    influence.to_csv(out / "finding_influence_ranking.csv", index=False)
    write_json(out / "leave_one_finding_out_summary.json", loo_summary)
    composite = composite_influence(fp)
    composite[KEY + ["composite_localization_score"] + [f"delta_{m}" for m in ["voxel_auroc", "voxel_auprc", "gt_sized_topk_precision", "topk_component_recall", "peak_to_gt_distance_mm", "inside_minus_outside_gap"]]].to_csv(out / "composite_finding_influence.csv", index=False)
    macro_micro(fp, cp).to_csv(out / "macro_vs_micro_metrics.csv", index=False)
    exposure, correlations, exp_aux = training_exposure(comparison, fp, cp)
    exposure.to_csv(out / "training_exposure_by_finding.csv", index=False)
    correlations.to_csv(out / "training_exposure_correlations.csv", index=False)
    exp_aux["all_training_exposure"].to_csv(out / "training_exposure_all_training_findings.csv", index=False)
    dominant_key = (str(composite.iloc[0].case_id), int(composite.iloc[0].finding_id))
    threshold = threshold_table(fp, cp, dominant_key); threshold.to_csv(out / "threshold_sensitivity.csv", index=False)
    tax = taxonomy(fp, cp); tax.to_csv(out / "failure_taxonomy.csv", index=False)
    traj = trajectory(fp, cp, loo_summary, composite); traj.to_csv(out / "update100_vs_update300.csv", index=False)
    dom = dominant_audit(fp, cp, composite, exposure, threshold); write_json(out / "dominant_finding_audit.json", dom)
    visuals = make_visualizations(control, treatment, out, fp, cp, composite, tax)
    write_json(out / "visualizations/selection_manifest.json", visuals)

    u300 = fp[fp["update"] == 300]
    th300 = threshold[threshold["update"] == 300].set_index("threshold")
    auc_robust = loo_summary["300"]["voxel_auroc"]["positive_direction_exclusions"]
    pr_robust = loo_summary["300"]["voxel_auprc"]["positive_direction_exclusions"]
    dist_robust = loo_summary["300"]["peak_to_gt_distance_mm"]["positive_direction_exclusions"]
    new_findings = int(th300.loc[.10, "unique_findings_with_new_component"])
    net_findings = int(th300.loc[.10, "findings_positive_net_component_count"])
    dom_loo = loo[(loo["update"] == 300) & (loo.omitted_case_id == dominant_key[0]) & (loo.omitted_finding_id == dominant_key[1])].iloc[0]
    dominant_core_persists = (
        dom_loo.leave_one_out_delta_voxel_auroc > 0
        and dom_loo.leave_one_out_delta_voxel_auprc > 0
        and dom_loo.leave_one_out_delta_peak_to_gt_distance_mm < 0
    )
    if auc_robust >= 23 and pr_robust >= 23 and new_findings >= 3 and dominant_core_persists:
        classification = "A. BROAD PRIOR LEARNABILITY SIGNAL"
    elif auc_robust >= 23 and pr_robust >= 23 and new_findings < 3 and dominant_core_persists:
        classification = "B. BROAD RANKING/LOCALIZATION SIGNAL, BUT EXTENT REMAINS LIMITED"
    elif max(auc_robust, pr_robust) < 20 and new_findings <= 1:
        classification = "C. SINGLE-FINDING-DRIVEN SIGNAL"
    elif not gate["all_aggregate_values_match_saved"]:
        classification = "E. EVALUATION OR AGGREGATION INVALID"
    else:
        classification = "D. MIXED / INCONCLUSIVE"

    tax_counts = tax.labels.str.split(";").explode().value_counts().to_dict()
    comp300 = cp[cp["update"] == 300]
    component_summary = {th: {
        "new": int((comp300[f"coverage_status_{th}"] == "newly_covered").sum()),
        "lost": int((comp300[f"coverage_status_{th}"] == "lost").sum()),
        "unique_new_findings": int(comp300.loc[comp300[f"coverage_status_{th}"] == "newly_covered", KEY].drop_duplicates().shape[0]),
    } for th in THRESHOLDS}
    git_status = git_capture(root, "status", "--short")
    git_diff = git_capture(root, "diff", "--stat")
    elapsed = time.time() - started
    maxrss_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    safety = {
        "cpu_only_no_cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", "") in ("", "NoDevFiles", "-1"),
        "requested_cpus_at_most_2": int(os.environ.get("SLURM_CPUS_PER_TASK", "1")) <= 2,
        "thread_caps_are_one": all(os.environ.get(k) == "1" for k in ["OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"]),
        "findings_25_per_arm_update": all(len(finding[(finding.arm == a) & (finding["update"] == u)]) == 25 for a in [ARM_C, ARM_T] for u in [0,100,300]),
        "finding_duplicates_absent": not finding.duplicated(["arm", "update", *KEY]).any(),
        "component_duplicates_absent": not component.duplicated(["arm", "update", *KEY, "component_id"]).any(),
        "control_treatment_component_pairs_exact": len(cp) == 240,
        "control_treatment_finding_pairs_exact": len(fp) == 75,
        "target25_ids_exact": set(map(tuple, metadata[KEY].to_numpy())) == set(map(tuple, fp[fp["update"] == 300][KEY].to_numpy())),
        "size_group_classification_exact": bool((fp.size_group_control == fp.target_manifest_size_group).all()),
        "single_multi_classification_exact": bool(((fp.component_count_control == 1) == (fp.component_class == "single-component")).all()),
        "component_count_matches_finding_rows": bool((cp.groupby(["update", *KEY]).size().reset_index(name="n").merge(fp[["update", *KEY, "component_count_control"]], on=["update", *KEY]).eval("n == component_count_control")).all()),
        "checkpoint_provenance_digest_matches_expected": read_json(comparison / "checkpoint_provenance.json")["sha256"] == "8a1a84a41598c70b624c90bda20e719d1409dff1209f59ad807923df5baaa845",
        "original_continuation_decision_unchanged": decision_hash_before == sha256(comparison / "continuation_decision.json"),
        "no_gpu_inference_or_training_submitted": True,
        "raw_full_prior_maps_available": False,
        "runtime_seconds": elapsed, "maximum_resident_set_kb": maxrss_kb,
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"), "command": " ".join(sys.argv),
        "git_diff_summary": git_diff, "git_status": git_status,
    }
    write_json(out / "audit_safety_checks.json", safety)

    report = f"""# Category-2d prior-head robustness audit

## Outcome

**{classification}**

The update-300 result is not well described as an entirely one-finding memorization signal, because finding-macro AUPRC, peak-in-GT, and top-k component-recall advantages survive every single-finding exclusion. However, the localization evidence is internally inconsistent: AUROC remains positive after {auc_robust}/25 exclusions, AUPRC after {pr_robust}/25, and peak-distance improvement after {dist_robust}/25. Removing the strongest composite localization finding changes mean peak-distance delta from {loo_summary['300']['peak_to_gt_distance_mm']['full_delta']:+.3f} mm to {dom_loo.leave_one_out_delta_peak_to_gt_distance_mm:+.3f} mm. At threshold 0.10, treatment newly covers components in {new_findings} findings and has a positive net covered-component count in {net_findings} findings.

Do **not** continue the identical loss unchanged to update 500. The next intervention should explicitly target spatial extent/coverage while preserving the improved ranking and low false-component burden.

## Exact gate reproduction

All 25/25 findings pair exactly, component rows pair exactly, duplicate checks pass, and every saved update-300 aggregate/check reproduces. The implementation in `{gate['exact_source_file']}` is:

```python
improved_coverage_findings = int(
    ((components_covered_at_0.10_T - components_covered_at_0.10_C) > 0).sum()
)
coverage_improvement_not_one_finding = improved_coverage_findings >= 2
```

It returned false because **zero** findings had a positive net count, not because exactly one finding dominated. Treatment retained nonzero absolute coverage in multiple findings. Thus the correct choice among the requested explanations is “5. another reason”: the gate compares net integer component counts per finding and does not measure dominance of ranking/localization magnitude.

## Update-300 paired signal (finding macro)

- AUROC: {u300.voxel_auroc_control.mean():.6f} -> {u300.voxel_auroc_treatment.mean():.6f} (delta {u300.delta_voxel_auroc.mean():+.6f}); {int((u300.delta_voxel_auroc>0).sum())} improved, {int((u300.delta_voxel_auroc<0).sum())} worsened.
- AUPRC: {u300.voxel_auprc_control.mean():.6f} -> {u300.voxel_auprc_treatment.mean():.6f} (delta {u300.delta_voxel_auprc.mean():+.6f}); {int((u300.delta_voxel_auprc>0).sum())} improved, {int((u300.delta_voxel_auprc<0).sum())} worsened.
- Peak in GT: {u300.peak_inside_gt_control.mean():.3f} -> {u300.peak_inside_gt_treatment.mean():.3f}; peak distance delta {u300.delta_peak_to_gt_distance_mm.mean():+.3f} mm.
- GT-sized top-k precision delta: {u300.delta_gt_sized_topk_precision.mean():+.6f}; top-k component recall delta: {u300.delta_topk_component_recall.mean():+.6f}.
- Coverage fraction at 0.10: {u300['component_coverage_at_0.10_control'].mean():.6f} -> {u300['component_coverage_at_0.10_treatment'].mean():.6f}. False components: {u300['false_prior_component_count_at_0.10_control'].mean():.2f} -> {u300['false_prior_component_count_at_0.10_treatment'].mean():.2f}.

Detailed all/small/other/single/multi and component-quartile effects are in `paired_effect_summary_by_group.csv`.

## Component accounting and threshold sensitivity

At update 300: {json.dumps(component_summary)}. Treatment creates **no newly covered component at any predefined threshold**; it preserves some control-covered components and loses 26/48/48 at 0.10/0.25/0.50. Thus the gate is not hiding a positive thresholded-coverage effect. Results after excluding the dominant localization candidate are in `threshold_sensitivity.csv`. No threshold was tuned.

## Dominant finding and leave-one-out

There is no “dominant coverage-gate finding,” because the set of positive-net findings is empty. For stress testing, the highest composite localization influence is **{dominant_key[0]} finding {dominant_key[1]}**, selected by the mean standardized favorable delta across AUROC, AUPRC, top-k precision, top-k component recall, negative peak distance, and probability gap. Removing it preserves AUPRC/peak-in-GT/top-k gains but reverses mean peak-distance improvement. Exact full/min/max/median leave-one-out values and per-finding influences are in `leave_one_finding_out_summary.json`, `leave_one_finding_out.csv`, and `finding_influence_ranking.csv`.

## Macro versus micro

Finding-macro values are primary. Component micro metrics were recomputed by pooling the 80 GT components and are reported alongside finding macro. True pooled voxel AUROC/AUPRC cannot be reconstructed from per-finding scalar metrics or 2D slices; `macro_vs_micro_metrics.csv` marks those unavailable and includes an explicitly labeled AUC-sample-weighted descriptive mean that is **not** treated as pooled AUROC/AUPRC.

## Training exposure and component weights

The manifest contains {exp_aux['summary']['manifest_entries']} training placements, but all target-25 findings are held-out and have zero direct appearances. Consequently improvement cannot be attributed to target-finding overrepresentation, and exposure correlations are undefined. The component CSV reports `derived_reference_weight = clip(sqrt({vref:.6f}/volume),1,4)` only as a counterfactual validation descriptor; it does not mislabel these as actual training-assigned weights. Volume/weight/component-count/control-performance correlations are descriptive in `training_exposure_correlations.csv`.

## Update 100 versus 300

`update100_vs_update300.csv` shows whether the ranking signal broadened and how component new/lost counts evolved. Update 300 has substantially broader AUPRC/peak-in-GT/top-k evidence than update 100, while AUROC influence is less robust, mean peak-distance is one-finding-sensitive, and thresholded extent remains inferior to control. This supports a broader ranking signal, but not an unqualified broad localization/extent claim.

## Failure taxonomy

Nonexclusive update-300 counts: {json.dumps(tax_counts)}. Rules are encoded transparently in the audit script and per-finding labels are in `failure_taxonomy.csv`.

## Visual audit

Created {sum(v.get('status','').startswith('created') for v in visuals)} matched PNGs from saved GT-centered CT/GT/prior slices with identical control/treatment probability scales. These are 2D saved views, not complete aligned 3D maps; GT component identities and 3D peak coordinates cannot be reconstructed from binary slices.

## Safety, provenance, and limitations

- CPU only: 2 CPUs or fewer, 16 GB request, one thread per numerical backend; no GPU, training, update-500, segmentation conversion, or new inference.
- Runtime: {elapsed:.2f} s; peak RSS: {maxrss_kb/1024:.1f} MiB; Slurm job: {os.environ.get('SLURM_JOB_ID')}.
- Command: `{' '.join(sys.argv)}`
- Base checkpoint digest matches the verified provenance record: `8a1a84...aa845`. The 6-GB checkpoint was not rehashed because this audit never reads model weights.
- Original `continuation_decision.json` SHA-256 is unchanged.
- Full 3D prior arrays were not saved. Therefore true voxel-micro AUROC/AUPRC, diagnostic threshold 0.05, exact 3D peak coordinates, peak-to-component distance, and new component-labeled spatial overlays are unavailable without inference. No inference was launched.
- Git diff summary: `{git_diff or '(empty; repository files are currently untracked)'}`
- Git status is captured verbatim in `audit_safety_checks.json` (the repository already contains extensive untracked user files).

## Final classification

**{classification}**
"""
    (out / "report.md").write_text(report)
    print(json.dumps({"status": "complete", "classification": classification, "output": str(out), "runtime_seconds": elapsed, "peak_rss_kb": maxrss_kb}, indent=2))


if __name__ == "__main__":
    main()
