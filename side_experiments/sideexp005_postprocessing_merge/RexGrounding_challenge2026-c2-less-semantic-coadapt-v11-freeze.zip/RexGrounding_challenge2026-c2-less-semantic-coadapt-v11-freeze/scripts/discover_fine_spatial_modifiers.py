#!/usr/bin/env python3
"""Discover and deterministically assign fine spatial modifiers in findings."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd


MODIFIERS = {
    "apical": {
        "canonical": "apical / apex",
        "proxy": "superior_fraction",
        "patterns": [r"\bbiapical\b", r"\bapices?\b", r"\bapical\b", r"\bapicoposterior\b"],
        "notes": "Includes apex/apices, apical, biapical, and apicoposterior variants.",
    },
    "basal": {
        "canonical": "basal / basilar / lung base",
        "proxy": "inferior_fraction",
        "patterns": [r"\b(?:postero|latero|antero|medio)?basal\b", r"\bbasilar\b", r"\blung base\b", r"\bbasal levels?\b"],
        "notes": "Includes named basal segment compounds; each may also enter a directional cluster.",
    },
    "diaphragmatic": {
        "canonical": "diaphragmatic / juxtadiaphragmatic",
        "proxy": "inferior_diaphragmatic_band",
        "patterns": [r"\bjuxtadiaphragmatic\b", r"\bdiaphragmatic\b", r"\badjacent to the diaphragm\b"],
        "notes": "Narrower inferior-location family than generic basal language.",
    },
    "subpleural_peripheral": {
        "canonical": "subpleural / peripheral / pleural-based",
        "proxy": "lung_boundary_shell",
        "patterns": [r"\bsubpleural\b", r"\bperipheral(?:ly)?\b", r"\bpleural-based\b", r"\bpleural surface\b"],
        "notes": "Excludes plain pleural effusion and morphology-only pleural terms.",
    },
    "central": {
        "canonical": "central / centrally distributed",
        "proxy": "lung_central_core",
        "patterns": [r"\bcentral(?:ly)?\b", r"\bcentral zones?\b", r"\bcentral levels?\b", r"\bperi-?hilar\b", r"\bhilar\b"],
        "notes": "A broad central-core proxy; hilar language is retained as a discoverable variant.",
    },
    "anterior": {
        "canonical": "anterior",
        "proxy": "anterior_fraction",
        "patterns": [r"\banterior\b", r"\banterobasal\b", r"\banteromedial\b"],
        "notes": "Includes compound segment names with an antero- prefix.",
    },
    "posterior": {
        "canonical": "posterior",
        "proxy": "posterior_fraction",
        "patterns": [r"\bposterior\b", r"\bposterobasal\b", r"\bapicoposterior\b"],
        "notes": "Includes posterior segment/aspect/portion and compound segment names.",
    },
    "medial": {
        "canonical": "medial",
        "proxy": "medial_fraction",
        "patterns": [r"\bmedial\b", r"\bmediobasal\b", r"\banteromedial\b"],
        "notes": "Does not match bilateral/bilaterally.",
    },
    "lateral": {
        "canonical": "lateral",
        "proxy": "lateral_fraction",
        "patterns": [r"\blateral\b", r"\blaterobasal\b", r"\bperipherally located\b"],
        "notes": "Does not match bilateral/bilaterally.",
    },
    "fissural": {
        "canonical": "fissural / perifissural",
        "proxy": "interlobe_boundary_shell",
        "patterns": [r"\bperi-?fissural\b", r"\bfissure-based\b", r"\bfissural\b", r"\bfissures?\b"],
        "notes": "Includes named major/minor/oblique fissure phrases.",
    },
    "lingular": {
        "canonical": "lingula / lingular",
        "proxy": "inferior_anterior_lul",
        "patterns": [r"\blingula\b", r"\blingular\b"],
        "notes": "Audit-only geometric proxy because TotalSegmentator has no separate lingula label.",
    },
    "dependent": {
        "canonical": "dependent",
        "proxy": "posterior_fraction",
        "patterns": [r"\bdependent\b", r"\bdependently\b"],
        "notes": "Assumes the usual supine CT acquisition; audited rather than presumed reliable.",
    },
    "paramediastinal": {
        "canonical": "paramediastinal",
        "proxy": "medial_fraction",
        "patterns": [r"\bparamediastinal\b", r"\bparamediastinum\b"],
        "notes": "Simple medial-lung proxy; likely low count.",
    },
    "superior_within_base": {
        "canonical": "superior within lobe/side",
        "proxy": "superior_fraction",
        "patterns": [r"\bsuperior\b", r"\buppermost\b"],
        "notes": "Excludes generic upper-lobe wording; targets superior segment/aspect language.",
    },
    "inferior_within_base": {
        "canonical": "inferior within lobe/side",
        "proxy": "inferior_fraction",
        "patterns": [r"\binferior\b", r"\blowermost\b"],
        "notes": "Excludes generic lower-lobe wording; targets inferior segment/aspect language.",
    },
    "paraspinal_or_costovertebral": {
        "canonical": "paraspinal / costovertebral",
        "proxy": None,
        "patterns": [r"\bparaspinal\b", r"\bparavertebral\b", r"\bcostovertebral\b", r"\badjacent to osteophytes\b"],
        "notes": "Semantically spatial, but no robust proxy is defined from lung/lobe geometry alone.",
    },
    "retrocardiac": {
        "canonical": "retrocardiac",
        "proxy": None,
        "patterns": [r"\bretrocardiac\b", r"\bparacardiac\b"],
        "notes": "Requires a heart mask or a better validated geometric proxy.",
    },
}

MORPHOLOGY = {
    "irregular", "patchy", "nodular", "multifocal", "diffuse", "linear",
    "scattered", "focal", "bandlike", "reticulonodular",
}
ANATOMY_CONTEXT = re.compile(
    r"\b(lung|lungs|lobe|lobes|segment|segments|pleura|fissure|fissures|"
    r"apex|apices|lingula|diaphragm|parenchyma|bronchus|bronchi)\b"
)
LOCATION_CONTEXT = re.compile(r"\b(in|at|within|along|adjacent|near|level|aspect|portion|region|surface)\b")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--findings-csv", type=Path, required=True)
    p.add_argument("--parser-assignments", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    return p.parse_args()


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z]+(?:-[a-z]+)?", text.lower())


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    findings = pd.read_csv(args.findings_csv).rename(
        columns={"finding_idx": "finding_id", "prompt": "finding_text"}
    )
    assignments = pd.read_csv(args.parser_assignments)
    findings = findings.merge(
        assignments[["case_id", "finding_id", "group", "side", "lobes"]],
        on=["case_id", "finding_id"], how="inner", validate="one_to_one",
    )
    if len(findings) != 381:
        raise RuntimeError(f"Expected 381 findings, got {len(findings)}")

    doc_counts: dict[int, Counter[str]] = {n: Counter() for n in range(1, 5)}
    examples: dict[str, str] = {}
    for text in findings["finding_text"].fillna("").astype(str):
        tokens = tokenize(text)
        for n in range(1, 5):
            grams = {" ".join(tokens[i:i+n]) for i in range(len(tokens)-n+1)}
            doc_counts[n].update(grams)
            for gram in grams:
                examples.setdefault(gram, text)

    ngram_rows = []
    all_pattern = re.compile("|".join(
        f"(?:{pattern})" for spec in MODIFIERS.values() for pattern in spec["patterns"]
    ), re.I)
    for n, counts in doc_counts.items():
        for gram, count in counts.items():
            if count < 2:
                continue
            context = examples[gram]
            spatial_context = bool(ANATOMY_CONTEXT.search(context) and LOCATION_CONTEXT.search(context))
            morphology_only = n == 1 and gram in MORPHOLOGY
            ngram_rows.append({
                "n": n, "ngram": gram, "finding_frequency": count,
                "spatial_context": spatial_context,
                "matches_modifier_rule": bool(all_pattern.search(gram)),
                "morphology_only_token": morphology_only,
                "example_text": context,
            })
    ngrams = pd.DataFrame(ngram_rows).sort_values(
        ["matches_modifier_rule", "spatial_context", "finding_frequency", "n"],
        ascending=[False, False, False, True],
    )
    ngrams.to_csv(args.output_dir / "modifier_token_ngram_frequencies.csv", index=False)

    candidate_rows = []
    assignment_rows = []
    cluster_counts: dict[str, set[tuple[str, int]]] = defaultdict(set)
    for row in findings.to_dict(orient="records"):
        text = str(row["finding_text"])
        lowered = text.lower()
        for cluster, spec in MODIFIERS.items():
            raw_matches = []
            for pattern in spec["patterns"]:
                raw_matches.extend(match.group(0).lower() for match in re.finditer(pattern, lowered, re.I))
            raw_matches = sorted(set(raw_matches))
            if not raw_matches:
                continue
            key = (str(row["case_id"]), int(row["finding_id"]))
            cluster_counts[cluster].add(key)
            assignment_rows.append({
                "case_id": row["case_id"], "finding_id": int(row["finding_id"]),
                "finding_text": text, "parser_group": row["group"],
                "parsed_side": row.get("side"), "parsed_lobes": row.get("lobes"),
                "modifier_cluster": cluster, "canonical_name": spec["canonical"],
                "matched_raw_phrases": ";".join(raw_matches),
                "proxy_defined": spec["proxy"] is not None,
                "proxy_family": spec["proxy"] or "none",
            })

    assignments_out = pd.DataFrame(assignment_rows).sort_values(
        ["case_id", "finding_id", "modifier_cluster"]
    )
    assignments_out.to_csv(args.output_dir / "modifier_assignments.csv", index=False)

    for cluster, spec in MODIFIERS.items():
        subset = assignments_out[assignments_out["modifier_cluster"] == cluster]
        phrase_counts: Counter[str] = Counter()
        phrase_examples: dict[str, pd.Series] = {}
        for _, row in subset.iterrows():
            for phrase in str(row["matched_raw_phrases"]).split(";"):
                phrase_counts[phrase] += 1
                phrase_examples.setdefault(phrase, row)
        if not phrase_counts:
            candidate_rows.append({
                "modifier_cluster": cluster, "canonical_name": spec["canonical"],
                "raw_keyword_or_phrase": "(not observed)", "frequency": 0,
                "example_finding_id": "", "example_text": "", "notes": spec["notes"],
            })
        else:
            for phrase, frequency in phrase_counts.most_common():
                example = phrase_examples[phrase]
                candidate_rows.append({
                    "modifier_cluster": cluster, "canonical_name": spec["canonical"],
                    "raw_keyword_or_phrase": phrase, "frequency": frequency,
                    "example_finding_id": f"{example['case_id']}#{int(example['finding_id'])}",
                    "example_text": example["finding_text"], "notes": spec["notes"],
                })
    pd.DataFrame(candidate_rows).to_csv(
        args.output_dir / "discovered_modifier_candidates.csv", index=False
    )

    counts = {cluster: len(keys) for cluster, keys in cluster_counts.items()}
    lines = [
        "# Fine spatial-modifier discovery", "",
        "Discovery used all 381 real finding texts. Token and 1–4-gram document",
        "frequencies were computed before deterministic synonym clustering. The full",
        "frequency table is in `modifier_token_ngram_frequencies.csv`.", "",
        "## Candidate clusters", "", "| cluster | findings | proxy status | representative phrases |", "|---|---:|---|---|",
    ]
    for cluster, spec in MODIFIERS.items():
        subset = assignments_out[assignments_out["modifier_cluster"] == cluster]
        phrases = Counter(
            phrase for value in subset.get("matched_raw_phrases", pd.Series(dtype=str)).astype(str)
            for phrase in value.split(";") if phrase
        )
        reps = ", ".join(f"{p} ({c})" for p, c in phrases.most_common(5)) or "not observed"
        status = "audit" if spec["proxy"] else "no clear proxy"
        lines.append(f"| {cluster} | {counts.get(cluster, 0)} | {status} | {reps} |")
    lines += [
        "", "## Exclusions", "",
        "Morphology-only terms such as irregular, patchy, nodular, multifocal, diffuse,",
        "linear, scattered, and focal were retained in the n-gram table but were not",
        "treated as locations unless a separate explicit anatomical modifier was present.",
        "Plain `pleural` was not sufficient for the peripheral cluster, preventing pleural",
        "effusion from being silently equated with subpleural parenchymal disease.", "",
        "## Audit routing", "",
        "Clusters with a deterministic proxy and at least one observed finding proceed to",
        "the geometry audit. Paraspinal/costovertebral and retrocardiac candidates remain",
        "discovery-only because lung/lobe masks alone do not define a defensible proxy.",
    ]
    (args.output_dir / "modifier_discovery_summary.md").write_text("\n".join(lines) + "\n")
    (args.output_dir / "modifier_discovery_manifest.json").write_text(json.dumps({
        "findings": len(findings), "assignment_rows": len(assignments_out),
        "findings_with_any_modifier": int(assignments_out[["case_id", "finding_id"]].drop_duplicates().shape[0]),
        "cluster_counts": counts, "modifier_specs": MODIFIERS,
        "gt_used_for_discovery": False,
    }, indent=2) + "\n")
    print(json.dumps({"findings": len(findings), "assignment_rows": len(assignments_out), "cluster_counts": counts}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
