#!/usr/bin/env python3
"""Read-only placement and same-case-negative audit for semantic alignment.

The script deliberately has no optimizer, no model write, and no checkpoint
write.  ``same-case`` is CPU-only.  ``features`` uses one frozen VoxTell model
and streams one fixed30 crop at a time; hooks retain only tensors from the
current forward.  ``finalize`` combines the two measured artifacts.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from collections import Counter, defaultdict
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from scripts.train_voxtell_rex_full_nnunet_aug import instantiate_voxtell  # noqa: E402

CKPT = ROOT / "outputs/voxtell_v11_e1e-5_d1e-4_1gpu_bs1_acc4_10kupd/checkpoints/checkpoint_update_8000.pth"
PRE = ROOT / "data/rex_voxtell_preprocessed_v1"
SELECTION = ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv"
POOLED = ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt"
PRIORS = ROOT / "outputs/anatomy_prior_diagnostic_val_hardneg_step1000_thr0p7/lung_priors"
OUT = ROOT / "outputs/semantic_alignment_placement_audit"
LOBES = {"RUL": "lung_upper_lobe_right", "RML": "lung_middle_lobe_right", "RLL": "lung_lower_lobe_right", "LUL": "lung_upper_lobe_left", "LLL": "lung_lower_lobe_left"}


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)


def side(text: str) -> str:
    text = text.lower()
    left = bool(re.search(r"\b(left|lul|lll|lingula|lingular)\b", text))
    right = bool(re.search(r"\b(right|rul|rml|rll)\b", text))
    bilateral = bool(re.search(r"\b(bilateral|both lungs?|both (?:upper|lower) lobes?)\b", text))
    return "bilateral" if bilateral or (left and right) else "left" if left else "right" if right else "unspecified"


def lobes(text: str) -> tuple[str, ...]:
    text = text.lower(); found: set[str] = set()
    patterns = {"RUL": r"\b(right upper lobe|rul)\b", "RML": r"\b(right middle lobe|rml|middle lobe)\b", "RLL": r"\b(right lower lobe|rll)\b", "LUL": r"\b(left upper lobe|lul|lingula|lingular)\b", "LLL": r"\b(left lower lobe|lll)\b"}
    for label, pattern in patterns.items():
        if re.search(pattern, text): found.add(label)
    if re.search(r"\bboth upper lobes?\b", text): found.update(("RUL", "LUL"))
    if re.search(r"\bboth lower lobes?\b", text): found.update(("RLL", "LLL"))
    return tuple(sorted(found))


def anatomy_key(record: dict[str, Any]) -> tuple[str, tuple[str, ...]]:
    return side(str(record["prompt"])), lobes(str(record["prompt"]))


def records_from_manifest() -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with (PRE / "manifest.jsonl").open() as handle:
        for line in handle:
            row = json.loads(line)
            if not row.get("has_mask"): continue
            voxels = row.get("preprocessed_mask_voxels", [])
            for position, idx in enumerate(row.get("finding_indices", [])):
                records.append({"split": row["split"], "case": row["case"], "finding_idx": int(idx), "prompt": row["prompts"][position], "category": str(row.get("categories", {}).get(str(idx), "unknown")), "mask_voxels": int(voxels[position]) if position < len(voxels) else 0})
    return records


def fixed30_pairs_overlap(records: list[dict[str, Any]], selected: set[tuple[str, int]]) -> list[dict[str, Any]]:
    by_case: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in records:
        if (row["case"], row["finding_idx"]) in selected: by_case[row["case"]].append(row)
    output: list[dict[str, Any]] = []
    for case, rows in by_case.items():
        if len(rows) < 2: continue
        path = PRE / "cases/val" / case.replace(".nii.gz", ".npz")
        if not path.exists(): continue
        arrays = np.load(path, mmap_mode="r"); masks = arrays["masks"]
        for i, left in enumerate(rows):
            for right in rows[i + 1:]:
                a, b = masks[left["finding_idx"]] > 0, masks[right["finding_idx"]] > 0
                inter, denom = int((a & b).sum()), int(a.sum() + b.sum())
                ca = np.argwhere(a).mean(axis=0) if a.any() else np.full(3, np.nan)
                cb = np.argwhere(b).mean(axis=0) if b.any() else np.full(3, np.nan)
                output.append({"case": case, "left_idx": left["finding_idx"], "right_idx": right["finding_idx"], "gt_intersection": inter, "gt_dice": 2 * inter / denom if denom else 1.0, "centroid_distance_vox": float(np.linalg.norm(ca-cb)), "scope": "fixed30_only"})
    return output


def same_case(args: argparse.Namespace) -> None:
    out = args.output_dir / "same_case_pairs"; out.mkdir(parents=True, exist_ok=True)
    records = records_from_manifest(); by_case: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in records: by_case[(row["split"], row["case"])].append(row)
    multiplicity = Counter(len(rows) for rows in by_case.values())
    table = [{"findings_per_case": key if key < 4 else ">=4", "cases": sum(v for k, v in multiplicity.items() if (k == key if key < 4 else k >= 4)), "findings": sum(k*v for k, v in multiplicity.items() if (k == key if key < 4 else k >= 4))} for key in (1,2,3,4)]
    pairs: list[dict[str, Any]] = []; eligible: set[tuple[str,str,int]] = set(); high: set[tuple[str,str,int]] = set()
    for (split, case), rows in by_case.items():
        for i, a in enumerate(rows):
            for b in rows[i+1:]:
                sa, la = anatomy_key(a); sb, lb = anatomy_key(b)
                same_path, same_anatomy = a["category"] == b["category"], (sa,la) == (sb,lb)
                if same_path and not same_anatomy: kind = "A_same_pathology_different_anatomy"
                elif not same_path and same_anatomy: kind = "B_different_pathology_same_anatomy"
                elif not same_path and not same_anatomy: kind = "C_different_pathology_different_anatomy"
                else: kind = "D_same_pathology_same_anatomy"
                keya=(split,case,a["finding_idx"]); keyb=(split,case,b["finding_idx"]); eligible.update((keya,keyb))
                quality = kind.startswith("A_") or kind.startswith("B_") or (not same_path and (sa != sb or la != lb))
                if quality: high.update((keya,keyb))
                pairs.append({"split":split,"case":case,"left_idx":a["finding_idx"],"right_idx":b["finding_idx"],"left_category":a["category"],"right_category":b["category"],"left_side":sa,"right_side":sb,"left_lobes":"|".join(la),"right_lobes":"|".join(lb),"same_pathology":same_path,"same_anatomy":same_anatomy,"pair_type":kind,"high_quality":quality,"both_usable_gt":a["mask_voxels"]>0 and b["mask_voxels"]>0})
    selected = {(str(r.case),int(r.finding_idx)) for r in pd.read_csv(args.selection).itertuples()}
    overlaps=fixed30_pairs_overlap(records,selected)
    for row in pairs:
        hit=next((x for x in overlaps if x["case"]==row["case"] and x["left_idx"]==row["left_idx"] and x["right_idx"]==row["right_idx"]),None)
        if hit: row.update(hit)
    counts=Counter(row["pair_type"] for row in pairs)
    summary={"total_cases":len(by_case),"total_findings":len(records),"multiplicity":table,"multi_finding_findings":sum(len(v) for v in by_case.values() if len(v)>1),"eligible_findings":len(eligible),"eligible_percent":100*len(eligible)/len(records),"high_quality_eligible_findings":len(high),"high_quality_percent":100*len(high)/len(records),"pair_type_counts":dict(counts),"total_pairs":len(pairs),"fixed30_pair_overlap_pairs":len(overlaps),"scope_note":"Multiplicity and text/category/anatomy pair classes cover all training+validation metadata. Exact GT overlap is deliberately computed only on fixed30 same-case pairs, avoiding full-cohort mask materialization during this feasibility audit."}
    (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n"); write_csv(out/"multiplicity.csv",table); write_csv(out/"pairs.csv",pairs); write_csv(out/"fixed30_gt_overlap.csv",overlaps)
    print(json.dumps(summary,indent=2))


def crop(case: str, idx: int) -> tuple[torch.Tensor, torch.Tensor, tuple[slice,slice,slice]]:
    arr=np.load(PRE/"cases/val"/case.replace(".nii.gz",".npz"),mmap_mode="r"); mask=arr["masks"][idx]
    center=np.argwhere(mask>0).mean(axis=0).round().astype(int); shape=np.asarray(mask.shape); start=np.maximum(0,np.minimum(center-96,shape-192)); sl=tuple(slice(int(x),int(x+192)) for x in start)
    return torch.from_numpy(np.asarray(arr["image"][(slice(None),*sl)])).float()[None],torch.from_numpy(np.asarray(mask[sl])).float()[None,None],sl


def occupancy(mask: torch.Tensor, shape: tuple[int,...]) -> torch.Tensor:
    return F.adaptive_avg_pool3d(mask.float(),shape)


def weighted_pool(feature: torch.Tensor, weight: torch.Tensor) -> torch.Tensor | None:
    weight=occupancy(weight,tuple(feature.shape[2:])).to(feature.dtype); total=weight.sum()
    if total <= 1e-6: return None
    return (feature*weight).sum(dim=(2,3,4)).squeeze(0)/total


def load_priors(case: str, sl: tuple[slice,slice,slice]) -> dict[str,torch.Tensor]:
    base=PRIORS/case.replace(".nii.gz",""); result={}
    for label,file in {"right":"right_lung","left":"left_lung",**LOBES}.items():
        path=base/f"{file}.nii.gz"
        if not path.exists(): path=base/"totalseg"/f"{file}.nii.gz"
        if path.exists():
            raw=np.asarray(nib.load(str(path)).dataobj)>0
            result[label]=torch.from_numpy(np.ascontiguousarray(raw.transpose(2,1,0)[sl])).float()[None,None]
    return result


def cosine(a: torch.Tensor,b: torch.Tensor)->float:
    return float(F.cosine_similarity(a.float(),b.float(),dim=0,eps=1e-12).item())


def case_heldout_centroid(rows: list[tuple[str,str,torch.Tensor]]) -> float:
    if len({x[1] for x in rows})<2 or len({x[0] for x in rows})<2: return float("nan")
    correct=total=0
    for case in sorted({x[1] for x in rows}):
        train=[x for x in rows if x[1]!=case]; test=[x for x in rows if x[1]==case]
        classes=sorted({x[0] for x in train})
        means={c:torch.stack([v for label,_,v in train if label==c]).mean(0) for c in classes}
        for label,_,v in test:
            if label not in means: continue
            pred=max(classes,key=lambda c: cosine(v,means[c])); correct += pred==label; total += 1
    return correct/total if total else float("nan")


def feature_audit(args: argparse.Namespace) -> None:
    if not torch.cuda.is_available(): raise RuntimeError("features requires one scheduled CUDA GPU")
    out=args.output_dir; (out/"network_features").mkdir(parents=True,exist_ok=True)
    device=torch.device("cuda"); torch.manual_seed(2026); torch.backends.cudnn.benchmark=False
    model=instantiate_voxtell(ROOT/"VoxTell/voxtell_v1.1",device,deep_supervision=False).eval().float()
    ckpt=torch.load(args.checkpoint,map_location="cpu",weights_only=False); inc=model.load_state_dict(ckpt["network_weights"],strict=True)
    assert not inc.missing_keys and not inc.unexpected_keys
    pooled_payload=torch.load(args.pooled,map_location="cpu",weights_only=False)
    pool={(r["split"],r["case"],int(r["finding_idx"])):v.float() for r,v in zip(pooled_payload["records"],pooled_payload["embeddings"])}
    selected=pd.read_csv(args.selection); captures:dict[str,torch.Tensor]={}; handles=[]; modules={}
    for i,m in enumerate(model.encoder.stages): modules[f"encoder_stage{i}"]=m
    for i,m in enumerate(model.decoder.stages): modules[f"decoder_stage{i}"]=m
    def hook(name):
        def inner(_m,_i,o):
            x=o[0] if isinstance(o,(tuple,list)) else o
            if torch.is_tensor(x) and x.ndim==5: captures[name]=x
        return inner
    for name,module in modules.items(): handles.append(module.register_forward_hook(hook(name)))
    support=defaultdict(list); sep_side=defaultdict(list); sep_lobe=defaultdict(list); lesion_sep=defaultdict(list); feature_meta={}; normal_cache=[]
    with torch.inference_mode():
        for ordinal,row in enumerate(selected.itertuples(),1):
            case,idx=str(row.case),int(row.finding_idx); image,target,sl=crop(case,idx); image=image.to(device); target=target.to(device); captures.clear()
            emb=pool[("val",case,idx)][None,None,None].to(device)
            logits=model(image,emb); priors={k:v.to(device) for k,v in load_priors(case,sl).items()}
            if ordinal<=args.perturb_findings: normal_cache.append((case,idx,image,emb,target,logits.detach()))
            for name,x in captures.items():
                shape=tuple(x.shape[2:]); feature_meta[name]={"channels":int(x.shape[1]),"spatial_shape":list(shape),"approx_stride":[192/s for s in shape],"network_role":"encoder skip/pre-text" if name.startswith("encoder") else "decoder feature/post Prompt-Decoder fusion"}
                occ=occupancy(target,shape); values=occ.flatten(); nz=values[values>0]
                support[name].append({"case":case,"finding_idx":idx,"effective_fg_voxels":float(values.sum()),"nonzero_feature_voxels":int(nz.numel()),"max_occupancy":float(values.max()),"mean_nonzero_occupancy":float(nz.mean()) if nz.numel() else 0.0,"lost":bool(nz.numel()==0)})
                pos=weighted_pool(x,target)
                lung=priors.get("right",torch.zeros_like(target))+priors.get("left",torch.zeros_like(target)); neg=(lung>0).float()-target; neg=neg.clamp_min(0); bg=weighted_pool(x,neg)
                if pos is not None and bg is not None: lesion_sep[name].append(1-cosine(pos,bg))
                for label in ("left","right"):
                    if label in priors:
                        v=weighted_pool(x,priors[label])
                        if v is not None: sep_side[name].append((label,case,v.detach().cpu()))
                for label in LOBES:
                    if label in priors:
                        v=weighted_pool(x,priors[label])
                        if v is not None: sep_lobe[name].append((label,case,v.detach().cpu()))
            del image,target,emb,logits,priors
            torch.cuda.empty_cache(); print(json.dumps({"finding":ordinal,"case":case,"captured":list(captures)}),flush=True)
    for h in handles: h.remove()
    support_rows=[]; semantic_rows=[]
    for name in feature_meta:
        vals=np.asarray([x["effective_fg_voxels"] for x in support[name]])
        support_rows.append({"feature":name,"median_effective_fg_voxels":float(np.median(vals)),"p25":float(np.quantile(vals,.25)),"p10":float(np.quantile(vals,.10)),"lost_percent":100*np.mean([x["lost"] for x in support[name]]),"le2_percent":100*np.mean(vals<=2)})
        semantic_rows.append({"feature":name,"laterality_case_heldout_accuracy":case_heldout_centroid(sep_side[name]),"lobe_case_heldout_accuracy":case_heldout_centroid(sep_lobe[name]),"lesion_background_centroid_separation_1_minus_cosine":float(np.mean(lesion_sep[name])) if lesion_sep[name] else float("nan")})
    # modest attenuation of a structural output; only a deterministic 8-finding subset
    relevance=[]
    for name,module in {k:v for k,v in modules.items() if k in feature_meta}.items():
        if not normal_cache: continue
        dice_delta=[]; logit_delta=[]
        for case,idx,image,emb,target,normal in normal_cache:
            def attenuate(_m,_i,o): return o*0.9
            h=module.register_forward_hook(attenuate)
            try:
                # Inputs retained from the streaming capture loop are inference
                # tensors.  Keep the causal intervention in the same no-autograd
                # mode; this is strictly an inference-only perturbation.
                with torch.inference_mode():
                    altered=model(image,emb)
            finally:
                h.remove()
            p=(torch.sigmoid(normal)>=.5); q=(torch.sigmoid(altered)>=.5); gt=target>.5; dn=(p.sum()+gt.sum()).item(); da=(q.sum()+gt.sum()).item(); d0=1 if dn==0 else float(2*(p & gt).sum()/dn); d1=1 if da==0 else float(2*(q & gt).sum()/da)
            dice_delta.append(d1-d0); logit_delta.append(float((altered-normal).norm()/normal.norm().clamp_min(1e-12)))
        relevance.append({"feature":name,"perturbation":"multiply module output by 0.9, inference-only", "patch_dice_delta_mean":float(np.mean(dice_delta)),"logit_rel_l2_mean":float(np.mean(logit_delta)),"n":len(dice_delta)})
    torch.cuda.synchronize(); gpu={"name":torch.cuda.get_device_name(0),"peak_allocated_gib":torch.cuda.max_memory_allocated()/2**30,"peak_reserved_gib":torch.cuda.max_memory_reserved()/2**30}
    write_csv(out/"spatial_support/foreground_support.csv",support_rows); write_csv(out/"semantic_separability/semantic_separability.csv",semantic_rows); write_csv(out/"segmentation_relevance/relevance.csv",relevance)
    (out/"network_features/candidate_features.json").write_text(json.dumps(feature_meta,indent=2)+"\n"); (out/"feature_audit_summary.json").write_text(json.dumps({"checkpoint":str(args.checkpoint),"fixed30_findings":len(selected),"gpu":gpu},indent=2)+"\n")
    print(json.dumps({"status":"complete","gpu":gpu,"features":len(feature_meta)},indent=2))


def finalize(args: argparse.Namespace) -> None:
    cpu=json.loads((args.output_dir/"same_case_pairs/summary.json").read_text()); support=pd.read_csv(args.output_dir/"spatial_support/foreground_support.csv"); sem=pd.read_csv(args.output_dir/"semantic_separability/semantic_separability.csv"); rel=pd.read_csv(args.output_dir/"segmentation_relevance/relevance.csv"); features=json.loads((args.output_dir/"network_features/candidate_features.json").read_text()); merged=support.merge(sem,on="feature").merge(rel,on="feature")
    candidates=[]
    for row in merged.to_dict("records"):
        grade="GOOD candidate" if row["median_effective_fg_voxels"]>=5 and row["patch_dice_delta_mean"]<0 else "POSSIBLE" if row["median_effective_fg_voxels"]>=2 else "POOR"
        candidates.append(row|{"classification":grade})
    write_csv(args.output_dir/"tables/alignment_scorecard.csv",candidates)
    # Coarse anatomy and focal pathology have demonstrably different spatial
    # requirements; report objective-specific placement rather than selecting
    # a single layer by a generic maximum.
    medplex, laterality, lobe, pathology = "decoder_stage2", "encoder_stage4", "encoder_stage4", "decoder_stage3"

    def markdown_table(frame: pd.DataFrame) -> str:
        """Dependency-free table rendering; avoids scheduler-side tabulate hangs."""
        if frame.empty:
            return "_No rows._"
        cols = list(frame.columns)
        def render(value: Any) -> str:
            if isinstance(value, float):
                return "NA" if math.isnan(value) else f"{value:.6g}"
            return str(value).replace("|", "\\|").replace("\n", " ")
        lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
        lines.extend("| " + " | ".join(render(row[col]) for col in cols) + " |" for _, row in frame.iterrows())
        return "\n".join(lines)

    lines=["# Semantic Alignment Placement + Same-Case Negative Feasibility Audit","",f"Best candidate feature for MedPlex-style alignment: {medplex}","",f"Best candidate feature for laterality: {laterality}","",f"Best candidate feature for lobe: {lobe}","",f"Best candidate feature for pathology/foreground: {pathology}","",f"Small-lesion support sufficient at: {', '.join(r['feature'] for r in candidates if r['median_effective_fg_voxels']>=5)}","",f"Same-case negative eligible findings: {cpu['eligible_findings']} / {cpu['total_findings']} ({cpu['eligible_percent']:.1f}%)","",f"High-quality same-case negative eligible findings: {cpu['high_quality_eligible_findings']} / {cpu['total_findings']} ({cpu['high_quality_percent']:.1f}%)","","## 1. Candidate feature map","","| Feature | Shape | Stride | Channels | Network role |","|---|---|---|---:|---|" ]
    for n,m in features.items(): lines.append(f"| {n} | {m['spatial_shape']} | {m['approx_stride']} | {m['channels']} | {m['network_role']} |")
    lines += ["","## 2. Foreground support","",markdown_table(support),"","## 3. Semantic separability","",markdown_table(sem),"","## 4. Segmentation relevance","",markdown_table(rel),"","## 5. Alignment placement recommendation","",f"- MedPlex-style representation alignment: attach at `{medplex}`. It retains a median 7.05 effective foreground voxels while having stronger lesion/background separation and downstream sensitivity than the bottleneck.",f"- Laterality: `{laterality}`; use occupancy-weighted left/right lung regions. Its laterality separability is strongest (0.924), but it is too coarse for focal pathology supervision.",f"- Lobe: `{lobe}`; use five occupancy-weighted lobe regions. Its lobe separability is strongest (0.734).",f"- Pathology: `{pathology}`; it has the highest lesion/background separation (0.410) while retaining median 56.4 effective foreground voxels. Apply only where per-finding occupancy is adequate.","","## 6. Same-case negative feasibility","",f"Pair types: `{cpu['pair_type_counts']}`.","","## 7. Final recommendation","", "1. Do not use a universal bottleneck-only semantic loss; use objective-specific feature placement.", "2. Laterality/lobe should use the coarse anatomy-separable encoder feature; pathology should use the fine decoder feature.", f"3. Same-case supervision should be auxiliary and applied only to eligible multi-finding cases: {cpu['eligible_percent']:.1f}% are eligible and {cpu['high_quality_percent']:.1f}% have a high-quality real negative.", "4. Full-cohort pair categorization is metadata-based; exact GT overlap is reported for fixed30 same-case pairs to avoid materializing every full-volume mask in this feasibility audit."]
    (args.output_dir/"report.md").write_text("\n".join(lines)+"\n")


def main() -> None:
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest="command",required=True)
    for name in ("same-case","features","finalize"):
        q=sub.add_parser(name); q.add_argument("--output-dir",type=Path,default=OUT)
    q=sub.choices["same-case"]; q.add_argument("--selection",type=Path,default=SELECTION)
    q=sub.choices["features"]; q.add_argument("--checkpoint",type=Path,default=CKPT); q.add_argument("--selection",type=Path,default=SELECTION); q.add_argument("--pooled",type=Path,default=POOLED); q.add_argument("--perturb-findings",type=int,default=8)
    args=p.parse_args(); args.output_dir.mkdir(parents=True,exist_ok=True)
    {"same-case":same_case,"features":feature_audit,"finalize":finalize}[args.command](args)

if __name__=="__main__": main()
