#!/usr/bin/env python3
"""Startup safety audit for the Direct C1 conditioned-1/8-skip arm."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from scripts.audit_encoder_token_spatial_18 import load_case, make_model, norm  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--target-ratio", type=float, default=3e-4)
    parser.add_argument("--updates", type=int, default=10)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA required")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(2026); torch.cuda.manual_seed_all(2026)
    device = torch.device("cuda")
    checkpoint_path = ROOT / "outputs/s3d_matched_continue_from_weakdiffuse_control_step1000/allcat_1over1_only_to_step6000/checkpoints/checkpoint_step_6000.pth"
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    image, target, pooled, tokens, valid = [
        value.to(device)
        for value in load_case(
            ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt"
        )
    ]
    baseline = make_model(False, device, checkpoint).eval().float()
    with torch.no_grad():
        baseline_logits = baseline(image, pooled)

    # Calibrate the shared Direct residual exactly as C1: condition-skip has no
    # additional trainable path and uses this already-calibrated residual once
    # in the deep path and once in the original 1/8 decoder skip.
    probe = make_model(True, device, checkpoint, "direct", 1.0).eval().float()
    with torch.no_grad():
        probe(image, pooled, token_features=tokens, token_valid_mask=valid)
        unit_ratio = float(probe.last_encoder_token_spatial_audit["residual_to_feature_norm"])
    scale = args.target_ratio / unit_ratio
    del probe; torch.cuda.empty_cache()

    deep_only = make_model(True, device, checkpoint, "direct", scale).eval().float()
    conditioned_skip = make_model(
        True, device, checkpoint, "direct", scale, conditioned_skip=True, skip_scale=1.0
    ).eval().float()
    with torch.no_grad():
        deep_logits = deep_only(image, pooled, token_features=tokens, token_valid_mask=valid)
        skip_logits = conditioned_skip(image, pooled, token_features=tokens, token_valid_mask=valid)
        audit = dict(conditioned_skip.last_encoder_token_spatial_audit)
    prediction = torch.sigmoid(skip_logits) >= 0.5
    base_prediction = torch.sigmoid(baseline_logits) >= 0.5
    deep_prediction = torch.sigmoid(deep_logits) >= 0.5
    skip_effect = (skip_logits - deep_logits).abs()
    total_effect = (skip_logits - baseline_logits).abs()
    safety = {
        "calibrated_init_scale": scale,
        "unit_residual_ratio": unit_ratio,
        "initial_deep_residual_ratio": audit["residual_to_feature_norm"],
        "initial_skip_residual_ratio": audit["conditioned_skip_residual_to_feature_norm"],
        "conditioned_skip_enabled": audit["conditioned_skip_enabled"],
        "conditioned_skip_scale": audit["conditioned_skip_scale"],
        "skip_path_max_absolute_logit_effect_vs_deep_only": float(skip_effect.max()),
        "skip_path_mean_absolute_logit_effect_vs_deep_only": float(skip_effect.mean()),
        "skip_path_prediction_disagreement_vs_deep_only": int((prediction != deep_prediction).sum()),
        "total_max_absolute_logit_effect_vs_baseline": float(total_effect.max()),
        "total_mean_absolute_logit_effect_vs_baseline": float(total_effect.mean()),
        "total_prediction_disagreement_vs_baseline": int((prediction != base_prediction).sum()),
        "audit": audit,
    }

    conditioned_skip.train()
    block = conditioned_skip.encoder_token_spatial_block
    assert block is not None
    optimizer = torch.optim.SGD(
        block.parameters(), lr=1e-3, momentum=.99, nesterov=True, weight_decay=3e-5
    )
    startup = []
    for update in range(1, args.updates + 1):
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            logits = conditioned_skip(image, pooled, token_features=tokens, token_valid_mask=valid)
            loss = F.binary_cross_entropy_with_logits(logits.float(), target)
        loss.backward()
        finite = all(parameter.grad is None or bool(torch.isfinite(parameter.grad).all()) for parameter in block.parameters())
        entry = {
            "update": update, "loss": float(loss.detach()), "finite": finite,
            "q_grad": norm(block.q_proj), "k_grad": norm(block.k_proj),
            "v_grad": norm(block.v_proj),
            "alpha_grad": 0.0 if block.alpha is None or block.alpha.grad is None else float(block.alpha.grad.detach().float().norm()),
        }
        optimizer.step()
        with torch.no_grad():
            conditioned_skip(image, pooled, token_features=tokens, token_valid_mask=valid)
        entry.update({
            "alpha": None if block.alpha is None else float(block.alpha.detach()),
            "deep_residual_ratio": conditioned_skip.last_encoder_token_spatial_audit["residual_to_feature_norm"],
            "skip_residual_ratio": conditioned_skip.last_encoder_token_spatial_audit["conditioned_skip_residual_to_feature_norm"],
        })
        startup.append(entry)
    report = {
        "schema": "token_spatial_direct_conditioned_skip_startup_v1",
        "checkpoint": str(checkpoint_path.resolve()), "target_ratio": args.target_ratio,
        "safety": safety, "startup": startup,
    }
    report["passed"] = bool(
        1e-4 <= safety["initial_deep_residual_ratio"] <= 1e-3
        and abs(safety["initial_skip_residual_ratio"] - safety["initial_deep_residual_ratio"]) < 1e-9
        and safety["conditioned_skip_enabled"]
        and safety["skip_path_mean_absolute_logit_effect_vs_deep_only"] > 0
        and all(row["finite"] and row["q_grad"] > 0 and row["k_grad"] > 0 and row["v_grad"] > 0 for row in startup)
    )
    (args.output_dir / "conditioned_skip_startup_audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
