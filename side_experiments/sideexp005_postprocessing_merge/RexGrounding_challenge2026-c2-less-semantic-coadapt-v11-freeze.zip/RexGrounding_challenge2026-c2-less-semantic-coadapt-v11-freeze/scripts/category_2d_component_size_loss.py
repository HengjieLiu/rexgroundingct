#!/usr/bin/env python3
"""Component-local, size-aware supervision for final VoxTell segmentation logits.

This module deliberately contains no model, routing, prior, presence, localization,
or proposal logic.  It operates only on the final full-resolution segmentation
logits and the prompted ground-truth masks.
"""

from __future__ import annotations

import math
from typing import Any, Sequence

import numpy as np
import torch
import torch.nn.functional as F
from scipy import ndimage


CONNECTIVITY = 26
ROI_MARGIN_MM = 12.0
SMALL_COMPONENT_VOXELS = 1000
WEIGHT_MIN = 1.0
WEIGHT_MAX = 4.0


def primary_logits(logits_or_list: torch.Tensor | Sequence[torch.Tensor]) -> torch.Tensor:
    """Return the final, full-resolution segmentation logits."""
    logits = logits_or_list[0] if isinstance(logits_or_list, (list, tuple)) else logits_or_list
    if logits.ndim != 5:
        raise ValueError(f"Expected [B,P,D,H,W] final logits, got {tuple(logits.shape)}")
    return logits


def _component_roi(
    obj: tuple[slice, slice, slice],
    shape: Sequence[int],
    spacing_xyz: Sequence[float],
) -> tuple[slice, slice, slice]:
    spacing_zyx = np.asarray(tuple(float(v) for v in spacing_xyz)[::-1], dtype=np.float64)
    if spacing_zyx.shape != (3,) or np.any(~np.isfinite(spacing_zyx)) or np.any(spacing_zyx <= 0):
        raise ValueError(f"Invalid spacing_xyz={spacing_xyz}")
    margin = np.ceil(ROI_MARGIN_MM / spacing_zyx).astype(np.int64)
    lower = np.maximum(0, np.asarray([axis.start for axis in obj], dtype=np.int64) - margin)
    upper = np.minimum(
        np.asarray(shape, dtype=np.int64),
        np.asarray([axis.stop for axis in obj], dtype=np.int64) + margin,
    )
    return tuple(slice(int(start), int(stop)) for start, stop in zip(lower, upper))


def component_size_aware_segmentation_loss(
    logits_or_list: torch.Tensor | Sequence[torch.Tensor],
    target: torch.Tensor,
    prompt_weights: torch.Tensor,
    prompt_categories: Sequence[Sequence[str]] | Sequence[str],
    spacing_xyz: Sequence[float],
    reference_volume_mm3: float,
    *,
    target_category: str = "2d",
    eps: float = 1e-6,
) -> tuple[torch.Tensor, dict[str, Any]]:
    """Compute the normalized component-local loss on final segmentation logits.

    Positive and local-background BCE are averaged separately.  Tversky uses
    ``alpha_fp`` on FP and ``beta_fn`` on FN.  Other prompted GT components are
    excluded from the eligible local background and from the FP term.
    """
    logits = primary_logits(logits_or_list).float()
    if logits.shape != target.shape:
        raise ValueError(f"Final logits/target mismatch: {tuple(logits.shape)} != {tuple(target.shape)}")
    if logits.shape[0] != 1:
        raise ValueError("The matched experiment requires batch_per_gpu=1")
    if reference_volume_mm3 <= 0 or not math.isfinite(reference_volume_mm3):
        raise ValueError(f"Invalid reference_volume_mm3={reference_volume_mm3}")

    categories = list(prompt_categories[0] if prompt_categories and isinstance(prompt_categories[0], (list, tuple)) else prompt_categories)  # type: ignore[index]
    if len(categories) != logits.shape[1]:
        raise ValueError(f"Category count {len(categories)} != prompt count {logits.shape[1]}")
    active = prompt_weights[0].detach().float().cpu().numpy() > 0
    target_cpu = target[0].detach().float().cpu().numpy() > 0.5
    prompted_gt_union = np.any(target_cpu[active], axis=0) if bool(active.any()) else np.zeros(target_cpu.shape[1:], dtype=bool)
    structure = ndimage.generate_binary_structure(3, 3)
    voxel_volume_mm3 = float(math.prod(float(v) for v in spacing_xyz))

    component_losses: list[torch.Tensor] = []
    positive_terms: list[torch.Tensor] = []
    negative_terms: list[torch.Tensor] = []
    tversky_terms: list[torch.Tensor] = []
    fp_terms: list[torch.Tensor] = []
    fn_terms: list[torch.Tensor] = []
    weights: list[float] = []
    audit: list[dict[str, Any]] = []

    for prompt_index, category in enumerate(categories):
        if str(category) != target_category or not active[prompt_index] or not bool(target_cpu[prompt_index].any()):
            continue
        labels, count = ndimage.label(target_cpu[prompt_index], structure=structure)
        objects = ndimage.find_objects(labels)
        if len(objects) != count:
            raise AssertionError("Connected-component extraction did not preserve every label")
        for component_id, obj in enumerate(objects, start=1):
            if obj is None:
                raise AssertionError(f"Missing connected component {component_id}/{count}")
            roi = _component_roi(obj, target_cpu.shape[1:], spacing_xyz)
            local_component_np = labels[roi] == component_id
            component_voxels = int(local_component_np.sum())
            if component_voxels <= 0:
                raise AssertionError("Extracted an empty GT component")
            physical_volume = component_voxels * voxel_volume_mm3
            weight = float(np.clip(math.sqrt(reference_volume_mm3 / physical_volume), WEIGHT_MIN, WEIGHT_MAX))

            local_logits = logits[(0, prompt_index, *roi)]
            local_component = torch.from_numpy(np.ascontiguousarray(local_component_np)).to(
                device=local_logits.device, dtype=torch.bool
            )
            local_union = torch.from_numpy(np.ascontiguousarray(prompted_gt_union[roi])).to(
                device=local_logits.device, dtype=torch.bool
            )
            eligible_background = ~local_union
            if not bool(eligible_background.any()):
                raise RuntimeError("Component ROI has no eligible local background")

            positive_bce = F.softplus(-local_logits[local_component]).mean()
            negative_bce = F.softplus(local_logits[eligible_background]).mean()
            probability = local_logits.sigmoid()
            tp = probability[local_component].sum()
            fn = (1.0 - probability[local_component]).sum()
            fp = probability[eligible_background].sum()
            alpha_fp, beta_fn = ((0.3, 0.7) if component_voxels < SMALL_COMPONENT_VOXELS else (0.5, 0.5))
            fp_contribution = alpha_fp * fp
            fn_contribution = beta_fn * fn
            tversky = 1.0 - (tp + eps) / (tp + fp_contribution + fn_contribution + eps)
            component_loss = positive_bce + negative_bce + tversky

            component_losses.append(component_loss)
            positive_terms.append(positive_bce)
            negative_terms.append(negative_bce)
            tversky_terms.append(tversky)
            fp_terms.append(fp_contribution)
            fn_terms.append(fn_contribution)
            weights.append(weight)
            audit.append(
                {
                    "prompt_index": int(prompt_index),
                    "component_id": int(component_id),
                    "voxel_count": component_voxels,
                    "physical_volume_mm3": physical_volume,
                    "bbox_zyx": [[int(axis.start), int(axis.stop)] for axis in obj],
                    "roi_zyx": [[int(axis.start), int(axis.stop)] for axis in roi],
                    "size_group": "small_lt1000" if component_voxels < SMALL_COMPONENT_VOXELS else "large_ge1000",
                    "weight": weight,
                    "alpha_fp": alpha_fp,
                    "beta_fn": beta_fn,
                    "eligible_background_voxels": int(eligible_background.sum().item()),
                    "positive_bce": float(positive_bce.detach()),
                    "negative_bce": float(negative_bce.detach()),
                    "local_tversky": float(tversky.detach()),
                    "weighted_fp_contribution": float(fp_contribution.detach()),
                    "weighted_fn_contribution": float(fn_contribution.detach()),
                }
            )

    if not component_losses:
        zero = logits.sum() * 0.0
        return zero, {
            "component_loss": 0.0,
            "component_count": 0,
            "component_audit": [],
            "component_loss_applied": False,
        }

    weight_tensor = torch.tensor(weights, device=logits.device, dtype=torch.float32)
    normalized = weight_tensor / weight_tensor.sum().clamp_min(eps)

    def weighted(values: list[torch.Tensor]) -> torch.Tensor:
        return (normalized * torch.stack(values)).sum()

    total = weighted(component_losses)
    small_mask = torch.tensor(
        [entry["voxel_count"] < SMALL_COMPONENT_VOXELS for entry in audit],
        device=logits.device,
        dtype=torch.bool,
    )
    per_component = torch.stack(component_losses)
    small_contribution = (normalized[small_mask] * per_component[small_mask]).sum() if bool(small_mask.any()) else total * 0.0
    large_contribution = (normalized[~small_mask] * per_component[~small_mask]).sum() if bool((~small_mask).any()) else total * 0.0
    return total, {
        "component_loss": float(total.detach()),
        "component_balanced_bce_positive": float(weighted(positive_terms).detach()),
        "component_balanced_bce_negative": float(weighted(negative_terms).detach()),
        "component_local_tversky": float(weighted(tversky_terms).detach()),
        "component_weighted_fp_contribution": float(weighted(fp_terms).detach()),
        "component_weighted_fn_contribution": float(weighted(fn_terms).detach()),
        "component_small_loss_contribution": float(small_contribution.detach()),
        "component_large_loss_contribution": float(large_contribution.detach()),
        "component_count": len(component_losses),
        "component_small_count": int(small_mask.sum().item()),
        "component_large_count": int((~small_mask).sum().item()),
        "component_weight_min": min(weights),
        "component_weight_max": max(weights),
        "component_weight_mean": float(np.mean(weights)),
        "component_audit": audit,
        "component_loss_applied": True,
        "component_connectivity": CONNECTIVITY,
        "component_roi_margin_mm": ROI_MARGIN_MM,
        "component_reference_volume_mm3": float(reference_volume_mm3),
    }

