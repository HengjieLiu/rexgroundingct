#!/usr/bin/env python3
"""CPU-only paired full-validation analysis for PBT-CLS@7200 vs Qwen B0@4000."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "outputs/pbt_cls_fullval_qwen_complementarity"
FIXED30 = ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    p.add_argument("--bootstrap-reps", type=int, default=10000)
    p.add_argument("--seed", type=int, default=20260822)
    return p.parse_args()


def read_metrics(root: Path, label: str) -> pd.DataFrame:
    p = root / "full_validation" / label / "summary_tables" / "per_finding_metrics.csv"
    if not p.is_file():
        raise FileNotFoundError(p)
    frame = pd.read_csv(p)
    required = {"file", "finding_idx", "global_dice", "global_hit", "tp_voxels", "fp_voxels", "fn_voxels", "pred_voxels", "gt_voxels", "prompt", "category"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"{p}: missing columns {sorted(missing)}")
    frame["file"] = frame["file"].astype(str)
    frame["finding_idx"] = frame["finding_idx"].astype(int)
    if len(frame) != 381 or frame[["file", "finding_idx"]].duplicated().any():
        raise ValueError(f"{p}: expected 381 unique val findings, found {len(frame)}")
    return frame


def as_bool(series: pd.Series) -> pd.Series:
    return series.astype(str).str.lower().isin(["true", "1", "yes"])


def bootstrap_case_clustered(frame: pd.DataFrame, reps: int, seed: int) -> dict[str, float]:
    case = frame["case_id"].astype(str)
    delta = frame["delta_dice"].to_numpy(float)
    groups = pd.DataFrame({"case": case, "delta": delta}).groupby("case", sort=True)["delta"].agg(["sum", "count"])
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(groups), size=(reps, len(groups)))
    sums = groups["sum"].to_numpy()[indices].sum(axis=1)
    counts = groups["count"].to_numpy()[indices].sum(axis=1)
    values = sums / counts
    return {"point_estimate": float(delta.mean()), "ci95_low": float(np.quantile(values, .025)), "ci95_high": float(np.quantile(values, .975)), "cases": int(len(groups)), "findings": int(len(frame)), "bootstrap_reps": int(reps)}


def spatial_flags(prompt: pd.Series) -> pd.DataFrame:
    s = prompt.fillna("").astype(str).str.lower()
    out = pd.DataFrame(index=s.index)
    out["laterality"] = np.select(
        [s.str.contains(r"\bbilateral|both lungs|both lung\b", regex=True), s.str.contains(r"\bleft\b", regex=True), s.str.contains(r"\bright\b", regex=True)],
        ["bilateral", "left", "right"], default="none")
    out["lobe"] = np.select(
        [s.str.contains(r"\bright middle lobe|\bmiddle lobe\b", regex=True), s.str.contains(r"\blingular|lingula\b", regex=True), s.str.contains(r"\bupper lobe\b", regex=True), s.str.contains(r"\blower lobe\b", regex=True)],
        ["middle", "lingula", "upper", "lower"], default="none")
    out["spatial_modifier"] = np.select(
        [s.str.contains(r"\banterior\b", regex=True), s.str.contains(r"\bposterior|posterobasal\b", regex=True)],
        ["anterior", "posterior"], default="none")
    out["explicit_laterality"] = out["laterality"].ne("none")
    out["explicit_lobe"] = out["lobe"].ne("none")
    out["prompt_words"] = s.str.findall(r"\b\w+\b").str.len()
    return out


def subgroup_rows(frame: pd.DataFrame) -> pd.DataFrame:
    work = frame.copy()
    flags = spatial_flags(work["prompt"])
    for col in flags:
        work[col] = flags[col]
    work["size_quartile"] = pd.qcut(work["gt_voxels"], q=4, duplicates="drop", labels=["Q1", "Q2", "Q3", "Q4"]).astype(str)
    work["prompt_length_quartile"] = pd.qcut(work["prompt_words"], q=4, duplicates="drop", labels=["Q1", "Q2", "Q3", "Q4"]).astype(str)
    result = []
    for kind, col in [("category", "category"), ("laterality", "laterality"), ("lobe", "lobe"), ("spatial_modifier", "spatial_modifier"), ("size_quartile", "size_quartile"), ("prompt_length_quartile", "prompt_length_quartile"), ("explicit_laterality", "explicit_laterality"), ("explicit_lobe", "explicit_lobe")]:
        for group, g in work.groupby(col, dropna=False):
            if len(g) < 10 or str(group) in {"none", "False"}:
                continue
            result.append({"group_type": kind, "group": str(group), "n": len(g), "qwen_dice": g["dice_qwen"].mean(), "pbt_cls_dice": g["dice_pbt_cls"].mean(), "delta_dice": g["delta_dice"].mean(), "qwen_hit_rate": g["hit_qwen"].mean(), "pbt_cls_hit_rate": g["hit_pbt_cls"].mean()})
    return pd.DataFrame(result).sort_values(["group_type", "group"]).reset_index(drop=True)


def metrics_summary(frame: pd.DataFrame, subset: str) -> list[dict[str, object]]:
    rows = []
    for model, prefix in [("Qwen", "qwen"), ("PBT-CLS", "pbt_cls")]:
        hit = frame[f"hit_{prefix}"]
        all_row = {"subset": subset, "population": "all", "model": model, "findings": len(frame), "dice": frame[f"dice_{prefix}"].mean(), "hit_count": int(hit.sum()), "hit_rate": hit.mean(), "mean_tp": frame[f"tp_{prefix}"].mean(), "mean_fp": frame[f"fp_{prefix}"].mean(), "mean_fn": frame[f"fn_{prefix}"].mean(), "mean_pred_volume": frame[f"pred_volume_{prefix}"].mean(), "empty_predictions": int((frame[f"pred_volume_{prefix}"] == 0).sum())}
        rows.append(all_row)
        own = frame.loc[hit]
        rows.append({**all_row, "population": "model_hit_positive", "findings": len(own), "dice": own[f"dice_{prefix}"].mean(), "hit_count": int(len(own)), "hit_rate": 1.0, "mean_tp": own[f"tp_{prefix}"].mean(), "mean_fp": own[f"fp_{prefix}"].mean(), "mean_fn": own[f"fn_{prefix}"].mean(), "mean_pred_volume": own[f"pred_volume_{prefix}"].mean(), "empty_predictions": int((own[f"pred_volume_{prefix}"] == 0).sum())})
    both = frame.loc[frame.hit_qwen & frame.hit_pbt_cls]
    for model, prefix in [("Qwen", "qwen"), ("PBT-CLS", "pbt_cls")]:
        rows.append({"subset": subset, "population": "both_hit", "model": model, "findings": len(both), "dice": both[f"dice_{prefix}"].mean(), "hit_count": int(len(both)), "hit_rate": 1.0, "mean_tp": both[f"tp_{prefix}"].mean(), "mean_fp": both[f"fp_{prefix}"].mean(), "mean_fn": both[f"fn_{prefix}"].mean(), "mean_pred_volume": both[f"pred_volume_{prefix}"].mean(), "empty_predictions": int((both[f"pred_volume_{prefix}"] == 0).sum())})
    return rows


def main() -> int:
    args = parse_args()
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    pbt = read_metrics(out, "pbt_cls_7200")
    qwen = read_metrics(out, "qwen_b0_4000")
    common = ["file", "finding_idx"]
    p = pbt.rename(columns={c: f"{c}_pbt" for c in pbt.columns if c not in common})
    q = qwen.rename(columns={c: f"{c}_qwen" for c in qwen.columns if c not in common})
    pair = q.merge(p, on=common, how="inner", validate="one_to_one")
    if len(pair) != 381:
        raise ValueError(f"Expected 381 matched findings; got {len(pair)}")
    pair = pair.rename(columns={"file":"case_id", "global_dice_qwen":"dice_qwen", "global_dice_pbt":"dice_pbt_cls", "global_hit_qwen":"hit_qwen", "global_hit_pbt":"hit_pbt_cls", "tp_voxels_qwen":"tp_qwen", "tp_voxels_pbt":"tp_pbt_cls", "fp_voxels_qwen":"fp_qwen", "fp_voxels_pbt":"fp_pbt_cls", "fn_voxels_qwen":"fn_qwen", "fn_voxels_pbt":"fn_pbt_cls", "pred_voxels_qwen":"pred_volume_qwen", "pred_voxels_pbt":"pred_volume_pbt_cls", "gt_voxels_qwen":"gt_voxels", "prompt_qwen":"prompt", "category_qwen":"category"})
    pair["hit_qwen"] = as_bool(pair.hit_qwen); pair["hit_pbt_cls"] = as_bool(pair.hit_pbt_cls)
    pair["delta_dice"] = pair.dice_pbt_cls - pair.dice_qwen
    pair["tie"] = pair.delta_dice.abs() < .005
    pair["winner"] = np.where(pair.tie, "tie", np.where(pair.delta_dice > 0, "pbt_cls", "qwen"))
    fixed = pd.read_csv(FIXED30)[["case", "finding_idx"]].rename(columns={"case":"case_id"})
    fixed["is_fixed30"] = True
    pair = pair.merge(fixed, on=["case_id", "finding_idx"], how="left")
    pair["is_fixed30"] = pair.is_fixed30.fillna(False).astype(bool)
    if int(pair.is_fixed30.sum()) != 49:
        raise ValueError(f"Fixed30 overlap must be 49, got {pair.is_fixed30.sum()}")
    pair["hit_disagreement"] = np.select([pair.hit_qwen & pair.hit_pbt_cls, pair.hit_qwen & ~pair.hit_pbt_cls, ~pair.hit_qwen & pair.hit_pbt_cls], ["both_hit", "qwen_only", "pbt_only"], default="neither")
    flags = spatial_flags(pair["prompt"])
    for col in ["laterality", "lobe", "spatial_modifier"]:
        pair[col] = flags[col]
    keep = ["case_id", "finding_idx", "prompt", "category", "laterality", "lobe", "spatial_modifier", "is_fixed30", "dice_qwen", "dice_pbt_cls", "delta_dice", "hit_qwen", "hit_pbt_cls", "hit_disagreement", "winner", "tp_qwen", "tp_pbt_cls", "fp_qwen", "fp_pbt_cls", "fn_qwen", "fn_pbt_cls", "pred_volume_qwen", "pred_volume_pbt_cls", "gt_voxels"]
    pair[keep].sort_values(["case_id", "finding_idx"]).to_csv(out / "per_finding_comparison.csv", index=False)
    pair.loc[pair.hit_disagreement.isin(["pbt_only", "qwen_only"]), keep].sort_values(["hit_disagreement", "delta_dice"], ascending=[True, False]).to_csv(out / "hit_disagreement.csv", index=False)
    rows = metrics_summary(pair, "all_full_validation") + metrics_summary(pair.loc[~pair.is_fixed30].copy(), "fixed30_excluded")
    summary = pd.DataFrame(rows); summary.to_csv(out / "fullval_summary.csv", index=False)
    subgroups = subgroup_rows(pair); subgroups.to_csv(out / "subgroup_analysis.csv", index=False)
    boot = {"all_full_validation": bootstrap_case_clustered(pair, args.bootstrap_reps, args.seed), "fixed30_excluded": bootstrap_case_clustered(pair.loc[~pair.is_fixed30], args.bootstrap_reps, args.seed + 1)}
    oracle = pd.DataFrame([{"subset": name, "findings": len(f), "qwen_dice": f.dice_qwen.mean(), "pbt_cls_dice": f.dice_pbt_cls.mean(), "oracle_dice": np.maximum(f.dice_qwen, f.dice_pbt_cls).mean(), "oracle_gain_over_qwen": np.maximum(f.dice_qwen, f.dice_pbt_cls).mean()-f.dice_qwen.mean(), "oracle_gain_over_pbt_cls": np.maximum(f.dice_qwen, f.dice_pbt_cls).mean()-f.dice_pbt_cls.mean(), "qwen_hit": int(f.hit_qwen.sum()), "pbt_cls_hit": int(f.hit_pbt_cls.sum()), "oracle_hit_either": int((f.hit_qwen|f.hit_pbt_cls).sum())} for name,f in [("all_full_validation",pair),("fixed30_excluded",pair.loc[~pair.is_fixed30])]])
    oracle.to_csv(out / "oracle_summary.csv", index=False)
    correlations = {"dice_pearson": float(pearsonr(pair.dice_qwen, pair.dice_pbt_cls).statistic), "dice_spearman": float(spearmanr(pair.dice_qwen, pair.dice_pbt_cls).statistic), "fp_pearson": float(pearsonr(pair.fp_qwen, pair.fp_pbt_cls).statistic), "prediction_volume_pearson": float(pearsonr(pair.pred_volume_qwen, pair.pred_volume_pbt_cls).statistic), "hit_phi": float(np.corrcoef(pair.hit_qwen.astype(int), pair.hit_pbt_cls.astype(int))[0,1])}
    table = pair.hit_disagreement.value_counts().reindex(["both_hit","qwen_only","pbt_only","neither"], fill_value=0)
    wins = pair.winner.value_counts().to_dict()
    per_case = pair.groupby("case_id", as_index=False).agg(findings=("finding_idx","count"), qwen_dice=("dice_qwen","mean"), pbt_cls_dice=("dice_pbt_cls","mean"), delta_dice=("delta_dice","mean"), qwen_hits=("hit_qwen","sum"), pbt_cls_hits=("hit_pbt_cls","sum"))
    per_case.to_csv(out / "per_case_summary.csv", index=False)
    ensemble_path = out / "ensemble_summary.csv"
    ensemble_lines = []
    recommendation = "Pending predefined probability-average screen."
    if ensemble_path.is_file():
        ensemble = pd.read_csv(ensemble_path)
        qwen_dice = float(pair.dice_qwen.mean())
        best = ensemble.loc[ensemble.dice.idxmax()]
        ensemble_lines = ["", "## Predefined probability-average screen", "", *[f"- {r.rule}: Dice {r.dice:.6f}, HIT {int(r.hit_count)}/{len(pair)} (Qwen weight {r.qwen_weight:g})." for r in ensemble.itertuples()]]
        oracle_gain = float(oracle.loc[oracle.subset == "all_full_validation", "oracle_gain_over_qwen"].iloc[0])
        pbt_only_rate = float(table["pbt_only"] / len(pair))
        if float(best.dice) > qwen_dice + .005:
            recommendation = "B. Complementarity exists but the predefined simple average already improves over Qwen; keep fusion non-trained unless a held-out router study is justified."
        elif oracle_gain >= .02 and pbt_only_rate >= .05:
            recommendation = "C. Strong oracle complementarity remains despite no simple-average gain; a strictly held-out Qwen+PBT router/fusion study is justified."
        else:
            recommendation = "A. No meaningful deployable complementarity demonstrated; keep Qwen."
    report = ["# PBT-CLS@7200 versus Qwen B0@4000 full-validation complementarity", "", "Full canonical validation contains 200 cases and 381 findings; fixed30 overlap is 49 findings, leaving 332 fixed30-excluded findings.", "", "## Paired results", "", f"- Mean Dice difference (PBT − Qwen), all findings: {boot['all_full_validation']['point_estimate']:.6f} (case-clustered 95% CI {boot['all_full_validation']['ci95_low']:.6f} to {boot['all_full_validation']['ci95_high']:.6f}).", f"- Fixed30-excluded difference: {boot['fixed30_excluded']['point_estimate']:.6f} (95% CI {boot['fixed30_excluded']['ci95_low']:.6f} to {boot['fixed30_excluded']['ci95_high']:.6f}).", f"- Practical ties (|ΔDice| < 0.005): {wins.get('tie',0)}; Qwen wins: {wins.get('qwen',0)}; PBT wins: {wins.get('pbt_cls',0)}.", "", "## HIT complementarity", "", *[f"- {k}: {int(v)} / {len(pair)} ({v/len(pair):.1%})" for k,v in table.items()], "", "## Error correlation", "", *[f"- {k}: {v:.4f}" for k,v in correlations.items()], "", "## Oracle upper bound — uses ground truth for model selection", "", *[f"- {r.subset}: oracle Dice {r.oracle_dice:.6f}; gain over Qwen {r.oracle_gain_over_qwen:.6f}; either-model HIT {int(r.oracle_hit_either)}/{int(r.findings)}." for r in oracle.itertuples()], *ensemble_lines, "", "## Recommendation", "", recommendation, "", "See CSV files for all per-finding, subgroup, and TP/FP/FN details."]
    (out / "report.md").write_text("\n".join(report) + "\n")
    (out / "analysis_summary.json").write_text(json.dumps({"bootstrap":boot,"correlations":correlations,"hit_table":table.to_dict(),"wins":wins},indent=2)+"\n")
    print(json.dumps({"findings":len(pair),"fixed30":int(pair.is_fixed30.sum()),"bootstrap":boot,"correlations":correlations},indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
