#!/usr/bin/env python3
"""Validate normal-path identity and stage-local LESS bypass on a real case."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit-dir", type=Path, required=True)
    parser.add_argument("--case", required=True)
    parser.add_argument("--existing-normal", type=Path, required=True)
    return parser.parse_args()


def probability(path: Path) -> np.ndarray:
    with np.load(path, allow_pickle=False) as payload:
        return np.asarray(payload["probability"], dtype=np.float32)


def main() -> int:
    args = parse_args()
    regression = args.audit_dir / "regression"
    stem = args.case.removesuffix(".nii.gz").removesuffix(".nii")
    default_prob = probability(regression / "default/probabilities" / f"{stem}.npz")
    explicit_prob = probability(
        regression / "explicit_normal/probabilities" / f"{stem}.npz"
    )
    if default_prob.shape != explicit_prob.shape:
        raise RuntimeError("Default and explicit-normal probability shapes differ")
    probability_delta = np.abs(default_prob - explicit_prob)

    default_binary = np.asarray(
        nib.load(str(regression / "default" / args.case)).dataobj
    )
    existing_binary = np.asarray(nib.load(str(args.existing_normal)).dataobj)
    binary_equal = bool(np.array_equal(default_binary, existing_binary))
    different_binary_voxels = int(np.count_nonzero(default_binary != existing_binary))
    different_binary_fraction = float(different_binary_voxels / default_binary.size)

    normal_audit = json.loads((regression / "normal_feature_audit.json").read_text())
    bypass_audit = json.loads((regression / "bypass_feature_audit.json").read_text())
    normal_levels = normal_audit["levels"]
    bypass_levels = bypass_audit["levels"]
    if set(normal_levels) != set(bypass_levels):
        raise RuntimeError("Normal and bypass feature-audit levels differ")
    feature_rows = []
    for level in sorted(normal_levels):
        normal = normal_levels[level]
        bypass = bypass_levels[level]
        feature_rows.append(
            {
                "level": level,
                "recorded_calls": int(normal["recorded_calls"]),
                "normal_post_minus_pre_rel_l2": float(
                    normal["mean_post_minus_pre_rel_l2"]
                ),
                "normal_post_minus_pre_mean_abs": float(
                    normal["mean_post_minus_pre_mean_abs"]
                ),
                "normal_post_minus_pre_max_abs": float(
                    normal["mean_post_minus_pre_max_abs"]
                ),
                "bypass_downstream_minus_pre_max_abs": float(
                    bypass["max_downstream_minus_pre_max_abs"]
                ),
            }
        )

    result = {
        "case": args.case,
        "default_vs_explicit_normal": {
            "max_absolute_probability_difference": float(probability_delta.max()),
            "mean_absolute_probability_difference": float(probability_delta.mean()),
            "binary_equal": bool(
                np.array_equal(
                    default_prob > np.float32(0.5),
                    explicit_prob > np.float32(0.5),
                )
            ),
        },
        "new_default_vs_existing_normal": {
            "binary_equal": binary_equal,
            "different_voxels": different_binary_voxels,
            "different_fraction": different_binary_fraction,
        },
        "feature_checks": feature_rows,
    }
    (args.audit_dir / "regression_checks.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    table = "\n".join(
        [
            "| Level | Calls | Normal rel-L2 | Normal mean abs | Normal max abs | Bypass delivered-pre max |",
            "|---|---:|---:|---:|---:|---:|",
            *[
                f"| {row['level']} | {row['recorded_calls']} | "
                f"{row['normal_post_minus_pre_rel_l2']:.8g} | "
                f"{row['normal_post_minus_pre_mean_abs']:.8g} | "
                f"{row['normal_post_minus_pre_max_abs']:.8g} | "
                f"{row['bypass_downstream_minus_pre_max_abs']:.8g} |"
                for row in feature_rows
            ],
        ]
    )
    report = f"""# LESS regression and bypass checks

Real diagnostic case: `{args.case}`.

## Normal-path regression

- Default vs explicit `--less-encoder-ablation normal` maximum absolute probability difference: `{probability_delta.max():.8g}`
- Mean absolute probability difference: `{probability_delta.mean():.8g}`
- Thresholded predictions equal: `{result['default_vs_explicit_normal']['binary_equal']}`
- Newly generated default prediction equals the previously completed normal Full200 prediction: `{binary_equal}`
- Differing binary voxels against the previous run: `{different_binary_voxels}` / `{default_binary.size}` (`{different_binary_fraction:.8g}`)

## Stage-local identity bypass

The diagnostic hook first measures the learned normal output and is followed by
the bypass hook. A final hook observes the tensor actually delivered downstream.
The bypass is accepted only when delivered input equals the pre-LESS tensor.

{table}
"""
    (args.audit_dir / "regression_checks.md").write_text(report)

    # The newly repeated default and explicit-normal probabilities are the
    # definitive code-path regression. Historical compressed binary output can
    # differ at a minute fraction of threshold-boundary voxels across GPU/runtime
    # builds; retain and report that comparison, but reject only a material drift.
    if probability_delta.max() > 1e-6 or different_binary_fraction > 1e-5:
        raise RuntimeError("Normal-path regression failed")
    if not all(
        row["normal_post_minus_pre_rel_l2"] > 0
        and row["bypass_downstream_minus_pre_max_abs"] <= 1e-7
        for row in feature_rows
    ):
        raise RuntimeError("LESS feature-change or identity-bypass check failed")
    print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
