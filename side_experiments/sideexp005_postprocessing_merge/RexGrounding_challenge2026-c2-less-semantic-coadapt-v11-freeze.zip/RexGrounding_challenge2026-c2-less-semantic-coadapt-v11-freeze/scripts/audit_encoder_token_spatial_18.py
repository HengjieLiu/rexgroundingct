#!/usr/bin/env python3
"""Audit safe token-specific spatial conditioning at the 1/8 encoder stage."""

from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from scripts.train_voxtell_rex_full_nnunet_aug import instantiate_voxtell


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, default=ROOT / "outputs/s3d_matched_continue_from_weakdiffuse_control_step1000/allcat_1over1_only_to_step6000/checkpoints/checkpoint_step_6000.pth")
    parser.add_argument("--token-cache", type=Path, default=ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--updates", type=int, default=3)
    parser.add_argument("--lr", type=float, default=1e-5)
    return parser.parse_args()


def load_case(token_cache: Path) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    case, finding_idx = "train_2664_a_2.nii.gz", 0
    arrays = np.load(ROOT / "data/rex_voxtell_preprocessed_v1/cases/val/train_2664_a_2.npz")
    mask = arrays["masks"][finding_idx]
    center = np.argwhere(mask > 0).mean(axis=0).round().astype(int)
    start = np.maximum(0, np.minimum(center - 96, np.asarray(mask.shape) - 192))
    slices = tuple(slice(int(value), int(value + 192)) for value in start)
    image = torch.from_numpy(arrays["image"][(slice(None), *slices)]).float()[None]
    target = torch.from_numpy(mask[slices]).float()[None, None]
    pooled_payload = torch.load(ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt", map_location="cpu", weights_only=False)
    key = ("val", case, finding_idx)
    pooled_index = next(i for i, record in enumerate(pooled_payload["records"]) if (record["split"], record["case"], int(record["finding_idx"])) == key)
    pooled = pooled_payload["embeddings"][pooled_index].float()[None, None, None]
    token_payload = torch.load(token_cache, map_location="cpu", weights_only=False)
    token_index = next(i for i, record in enumerate(token_payload["records"]) if (record["split"], record["case"], int(record["finding_idx"])) == key)
    tokens = token_payload["token_features"][token_index].float()[None, None]
    valid = torch.ones(tokens.shape[:3], dtype=torch.bool)
    return image, target, pooled, tokens, valid


def make_model(
    enabled: bool,
    device: torch.device,
    checkpoint: dict,
    connector_type: str = "dense",
    connector_init_scale: float = 5e-4,
    conditioned_skip: bool = False,
    skip_scale: float = 1.0,
):
    model = instantiate_voxtell(
        ROOT / "VoxTell/voxtell_v1.1", device, deep_supervision=False,
        enable_s3_voxel_text_matching_attention=True, s3_attention_hidden_channels=128,
        s3_rho_mode="fixed", s3_rho_fixed=0.25, s3_logit_scale_init=10.0,
        s3_attention_scales=("1/1",), token_image_text_mode="original",
        encoder_token_spatial_mode="text" if enabled else "none",
        encoder_token_spatial_stage=3, encoder_token_spatial_hidden_dim=256,
        encoder_token_spatial_heads=8, encoder_token_spatial_dropout=0.0,
        encoder_token_spatial_init_seed=260813,
        encoder_token_spatial_connector_type=connector_type,
        encoder_token_spatial_connector_init_scale=connector_init_scale,
        encoder_token_spatial_conditioned_skip=conditioned_skip,
        encoder_token_spatial_skip_scale=skip_scale,
    )
    incompatible = model.load_state_dict(checkpoint["network_weights"], strict=False)
    allowed = ("s3_extra_attention_gates.",)
    if enabled:
        allowed += ("encoder_token_spatial_block.",)
    invalid = [key for key in incompatible.missing_keys if not key.startswith(allowed)]
    if invalid or incompatible.unexpected_keys:
        raise RuntimeError(f"Checkpoint mismatch missing={invalid}, unexpected={list(incompatible.unexpected_keys)}")
    model.s3_extra_attention_gates.load_state_dict(checkpoint["s3_extra_attention_weights"], strict=True)
    return model.to(device)


def dice(logits: torch.Tensor, target: torch.Tensor) -> float:
    prediction, truth = torch.sigmoid(logits) >= 0.5, target > 0.5
    denominator = prediction.sum() + truth.sum()
    return 1.0 if denominator == 0 else float(2 * (prediction & truth).sum() / denominator)


def norm(module: torch.nn.Module) -> float:
    values = [p.grad.detach().float().square().sum() for p in module.parameters() if p.grad is not None]
    return 0.0 if not values else float(torch.stack(values).sum().sqrt().item())


def main() -> None:
    args = parse_args(); args.output_dir.mkdir(parents=True, exist_ok=True)
    if not torch.cuda.is_available():
        raise RuntimeError("Scheduled GPU required for full 192^3 audit")
    torch.manual_seed(2026); torch.cuda.manual_seed_all(2026)
    torch.backends.cudnn.benchmark = False
    device = torch.device("cuda")
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    image, target, pooled, tokens, valid = [x.to(device) for x in load_case(args.token_cache)]
    logits, initial_audit = {}, {}
    for label, enabled in (("baseline", False), ("token_spatial_update0", True)):
        model = make_model(enabled, device, checkpoint).eval().float()
        with torch.no_grad():
            kwargs = {"token_features": tokens, "token_valid_mask": valid} if enabled else {}
            logits[label] = model(image, pooled, **kwargs).cpu()
        if enabled:
            initial_audit = model.last_encoder_token_spatial_audit
        del model; gc.collect(); torch.cuda.empty_cache()
    difference = (logits["baseline"] - logits["token_spatial_update0"]).abs()
    model = make_model(True, device, checkpoint).train()
    for name, parameter in model.named_parameters():
        parameter.requires_grad_(name.startswith("encoder_token_spatial_block."))
    block = model.encoder_token_spatial_block
    assert block is not None
    optimizer = torch.optim.SGD(block.parameters(), lr=args.lr, momentum=0.99, nesterov=True, weight_decay=3e-5)
    startup = []
    for update in range(1, args.updates + 1):
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            output = model(image, pooled, token_features=tokens, token_valid_mask=valid)
            loss = F.binary_cross_entropy_with_logits(output.float(), target)
        loss.backward()
        gradients = {"connector_gradient_norm": norm(block.out_proj), "q_gradient_norm": norm(block.q_proj), "k_gradient_norm": norm(block.k_proj), "v_gradient_norm": norm(block.v_proj)}
        finite = all(p.grad is None or bool(torch.isfinite(p.grad).all()) for p in block.parameters())
        optimizer.step()
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
            model(image, pooled, token_features=tokens, token_valid_mask=valid)
        startup.append({"update": update, "loss": float(loss.detach().item()), "finite_gradients": finite, **gradients, **block.last_audit})
    report = {
        "schema": "encoder_token_spatial_18_screen_audit_v1", "checkpoint": str(args.checkpoint.resolve()),
        "gpu": torch.cuda.get_device_name(0), "text_representation": "Qwen contextual content-token hidden states", "text_dimension": int(tokens.shape[-1]),
        "token_spatial_parameter_count": block.parameter_count(), "shape_and_initialization": initial_audit,
        "equivalence": {"max_absolute_logit_difference": float(difference.max()), "mean_absolute_logit_difference": float(difference.mean()), "dice_difference": dice(logits["token_spatial_update0"], target.cpu()) - dice(logits["baseline"], target.cpu())},
        "startup": startup,
    }
    report["passed"] = bool(report["equivalence"]["max_absolute_logit_difference"] <= 1e-5 and initial_audit["max_conditioned_minus_base"] == 0.0 and initial_audit["residual_to_feature_norm"] == 0.0 and startup[0]["connector_gradient_norm"] > 0 and any(row["q_gradient_norm"] > 0 and row["k_gradient_norm"] > 0 and row["v_gradient_norm"] > 0 for row in startup[1:]) and all(row["finite_gradients"] for row in startup))
    (args.output_dir / "audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if not report["passed"]: raise SystemExit(1)


if __name__ == "__main__":
    main()
