#!/usr/bin/env python3
"""Aggregate paired specialist results and enforce dual-expert decision gates."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

SPECIALIST = ["1c", "1d", "1f", "2b", "2c"]


def normalize(frame: pd.DataFrame, prefix: str) -> pd.DataFrame:
    keys = ["file", "finding_idx", "category"]
    columns = keys + [column for column in ("global_dice", "global_hit", "pred_voxels", "gt_voxels", "voxel_precision", "voxel_recall", "pred_gt_volume_ratio") if column in frame]
    result = frame[columns].copy()
    return result.rename(columns={column: f"{prefix}_{column}" for column in columns if column not in keys})


def cluster_bootstrap(frame: pd.DataFrame, mask: pd.Series, rng: np.random.Generator, draws: int = 10_000) -> tuple[np.ndarray, np.ndarray]:
    subset = frame.loc[mask].copy()
    cases = subset["file"].unique()
    grouped = {case: subset[subset["file"] == case] for case in cases}
    ba = np.empty(draws)
    bb = np.empty(draws)
    for index in range(draws):
        sampled = rng.choice(cases, size=len(cases), replace=True)
        draw = pd.concat([grouped[case] for case in sampled], ignore_index=True)
        ba[index] = (draw["attention_global_dice"] - draw["control_global_dice"]).mean()
        bb[index] = (draw["attention_global_dice"] - draw["baseline_global_dice"]).mean()
    return ba, bb


def summarize_history(path: Path) -> dict:
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    training = [row for row in rows if int(row.get("step", 0)) > 0]
    return {
        "records": len(training),
        "all_loss_finite": all(math.isfinite(float(row["train_loss"])) for row in training),
        "amp_skip_count": sum(bool(row.get("amp_step_skipped", False)) for row in training),
        "peak_reserved_gib": max(float(row.get("gpu_peak_reserved_gib") or 0) for row in training),
        "max_iteration_seconds": max(float(row.get("iteration_seconds") or 0) for row in training),
        "last_loss": float(training[-1]["train_loss"]),
    }


def trace_matches_manifest(trace_path: Path, expected: list[dict]) -> bool:
    observed = [json.loads(line) for line in trace_path.read_text().splitlines() if line.strip()]
    if len(observed) != len(expected):
        return False
    fields = ("case_id", "finding_ids", "categories", "roles", "crop_bbox", "crop_mode")
    return all(all(row.get(field) == target.get(field) for field in fields) for row, target in zip(observed, expected))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--update", type=int, default=500)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--control-dir", type=Path)
    parser.add_argument("--attention-dir", type=Path)
    parser.add_argument("--training-manifest", type=Path)
    parser.add_argument(
        "--skip-arm-artifacts",
        action="store_true",
        help="Do not rewrite summaries inside reused control/attention run directories.",
    )
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    suffix = "u500" if args.update == 500 else "u1000"
    control_dir = args.control_dir or args.root / f"outputs/dual_expert_specialist_control_{suffix}"
    attention_dir = args.attention_dir or args.root / f"outputs/dual_expert_attention_{suffix}"
    baseline_path = args.root / "outputs/nonattention_baseline_selection/full381_update10000/summary_tables/per_finding_metrics.csv"
    control = normalize(pd.read_csv(control_dir / "fullvolume_specialist_metrics.csv"), "control")
    attention = normalize(pd.read_csv(attention_dir / "fullvolume_specialist_metrics.csv"), "attention")
    baseline_full = pd.read_csv(baseline_path)
    baseline = normalize(baseline_full[baseline_full["category"].astype(str).isin(SPECIALIST)], "baseline")
    paired = control.merge(attention, on=["file", "finding_idx", "category"], validate="one_to_one").merge(baseline, on=["file", "finding_idx", "category"], validate="one_to_one")
    if len(paired) != 136:
        raise RuntimeError(f"expected 136 paired specialist findings, got {len(paired)}")
    paired["attention_minus_control_dice"] = paired["attention_global_dice"] - paired["control_global_dice"]
    paired["attention_minus_baseline_dice"] = paired["attention_global_dice"] - paired["baseline_global_dice"]
    paired.to_csv(args.output_dir / "paired_specialist_comparison.csv", index=False)

    summaries = []
    for category, group in [("SPECIALIST_ALL", paired), *[(category, paired[paired["category"].astype(str) == category]) for category in SPECIALIST], ("2b+2c", paired[paired["category"].astype(str).isin(["2b", "2c"])]), ("1c+1d+1f", paired[paired["category"].astype(str).isin(["1c", "1d", "1f"])])]:
        row = {"category": category, "n": len(group)}
        for arm in ("control", "attention", "baseline"):
            row[f"{arm}_mean_dice"] = group[f"{arm}_global_dice"].mean()
            row[f"{arm}_hits"] = int(group[f"{arm}_global_hit"].sum())
            if f"{arm}_pred_gt_volume_ratio" in group:
                row[f"{arm}_mean_pred_gt_volume_ratio"] = group[f"{arm}_pred_gt_volume_ratio"].mean()
        row["attention_minus_control_dice"] = row["attention_mean_dice"] - row["control_mean_dice"]
        row["attention_minus_baseline_dice"] = row["attention_mean_dice"] - row["baseline_mean_dice"]
        row["attention_minus_control_hits"] = row["attention_hits"] - row["control_hits"]
        row["attention_minus_baseline_hits"] = row["attention_hits"] - row["baseline_hits"]
        summaries.append(row)
    category_summary = pd.DataFrame(summaries)
    category_summary.to_csv(args.output_dir / "category_specialist_summary.csv", index=False)

    rng = np.random.default_rng(731945)
    bootstrap_rows = []
    draw_cache = {}
    for category in ["SPECIALIST_ALL", *SPECIALIST, "2b+2c", "1c+1d+1f"]:
        mask = pd.Series(True, index=paired.index)
        if category in SPECIALIST:
            mask = paired["category"].astype(str) == category
        elif category == "2b+2c":
            mask = paired["category"].astype(str).isin(["2b", "2c"])
        elif category == "1c+1d+1f":
            mask = paired["category"].astype(str).isin(["1c", "1d", "1f"])
        ba, bb = cluster_bootstrap(paired, mask, rng)
        draw_cache[category] = (ba, bb)
        for contrast, values in (("attention-control", ba), ("attention-baseline", bb)):
            bootstrap_rows.append({
                "category": category,
                "contrast": contrast,
                "mean": float(values.mean()),
                "ci_lower_95": float(np.quantile(values, 0.025)),
                "ci_upper_95": float(np.quantile(values, 0.975)),
                "probability_greater_than_zero": float((values > 0).mean()),
                "draws": len(values),
                "resampling_unit": "case",
                "seed": 731945,
            })
    bootstrap = pd.DataFrame(bootstrap_rows)
    bootstrap.to_csv(args.output_dir / "bootstrap_case_clustered_ci.csv", index=False)

    full_delta = paired["attention_minus_control_dice"].mean()
    loco = []
    for case in sorted(paired["file"].unique()):
        subset = paired[paired["file"] != case]
        value = subset["attention_minus_control_dice"].mean()
        loco.append({"left_out_case": case, "attention_minus_control_dice": value, "influence_vs_full": value - full_delta, "remaining_findings": len(subset)})
    pd.DataFrame(loco).to_csv(args.output_dir / "leave_one_case_out_sensitivity.csv", index=False)

    stability = {
        "control": summarize_history(control_dir / "history.jsonl"),
        "attention": summarize_history(attention_dir / "history.jsonl"),
    }
    manifest_path = args.training_manifest or args.root / "outputs/dual_expert_matched_comparison/matched_training_manifest.json"
    manifest = json.loads(manifest_path.read_text())["entries"]
    expected_trace = manifest[:2000] if args.update == 500 else manifest[2000:4000]
    stability["control"]["trace_matches_manifest"] = trace_matches_manifest(control_dir / "sampler_trace_rank0.jsonl", expected_trace)
    stability["attention"]["trace_matches_manifest"] = trace_matches_manifest(attention_dir / "sampler_trace_rank0.jsonl", expected_trace)
    stability["arm_traces_identical"] = (control_dir / "sampler_trace_rank0.jsonl").read_bytes() == (attention_dir / "sampler_trace_rank0.jsonl").read_bytes()
    stability["passed"] = all(value["all_loss_finite"] and value["amp_skip_count"] == 0 and value["peak_reserved_gib"] < 80 and value["max_iteration_seconds"] < 60 for value in stability.values() if isinstance(value, dict) and "all_loss_finite" in value)
    stability["passed"] = bool(
        stability["passed"]
        and stability["control"]["trace_matches_manifest"]
        and stability["attention"]["trace_matches_manifest"]
        and stability["arm_traces_identical"]
    )
    (args.output_dir / "training_stability_summary.json").write_text(json.dumps(stability, indent=2) + "\n")
    if not args.skip_arm_artifacts:
        for arm, directory in (("control", control_dir), ("attention", attention_dir)):
            arm_rows = category_summary[["category", "n", f"{arm}_mean_dice", f"{arm}_hits"]].copy()
            arm_rows.columns = ["category", "n", "mean_dice", "hits"]
            training_summary = {
                "arm": arm,
                "optimizer_update": args.update,
                "checkpoint": str(directory / f"checkpoints/checkpoint_update_{args.update}.pth"),
                "stability": stability[arm],
                "specialist_metrics": arm_rows.to_dict(orient="records"),
            }
            (directory / "training_summary.json").write_text(json.dumps(training_summary, indent=2) + "\n")
            (directory / "fullvolume_specialist_summary.json").write_text(
                json.dumps(
                    {
                        "arm": arm,
                        "optimizer_update": args.update,
                        "findings": int(arm_rows.loc[arm_rows["category"] == "SPECIALIST_ALL", "n"].iloc[0]),
                        "category_metrics": arm_rows.to_dict(orient="records"),
                    },
                    indent=2,
                )
                + "\n"
            )
            specialist_row = arm_rows[arm_rows["category"] == "SPECIALIST_ALL"].iloc[0]
            (directory / "result_card.md").write_text(
                f"# {arm} specialist result — update {args.update}\n\n"
                f"Specialist findings: {int(specialist_row['n'])}; mean Dice: "
                f"{float(specialist_row['mean_dice']):.6f}; hits: {int(specialist_row['hits'])}.\n\n"
                f"See `fullvolume_specialist_metrics.csv` for paired per-finding values.\n"
            )

    specialist_keys = set(zip(paired["file"], paired["finding_idx"]))
    hybrid = baseline_full.copy()
    attention_lookup = {(row.file, int(row.finding_idx)): row.attention_global_dice for row in paired.itertuples()}
    hybrid["hybrid_global_dice"] = [attention_lookup.get((row.file, int(row.finding_idx)), row.global_dice) for row in hybrid.itertuples()]
    hybrid["routed_expert"] = ["attention" if (row.file, int(row.finding_idx)) in specialist_keys else "frozen_baseline" for row in hybrid.itertuples()]
    hybrid.to_csv(args.output_dir / "hybrid_offline_metrics.csv", index=False)
    non_specialist = hybrid[hybrid["routed_expert"] == "frozen_baseline"]
    category_2d = hybrid[hybrid["category"].astype(str) == "2d"]
    hybrid_summary = {
        "findings": len(hybrid),
        "specialist_findings_routed_to_attention": int((hybrid["routed_expert"] == "attention").sum()),
        "overall_baseline_dice": float(hybrid["global_dice"].mean()),
        "overall_hybrid_dice": float(hybrid["hybrid_global_dice"].mean()),
        "overall_delta": float((hybrid["hybrid_global_dice"] - hybrid["global_dice"]).mean()),
        "non_specialist_exactly_preserved": bool(np.array_equal(non_specialist["global_dice"].to_numpy(), non_specialist["hybrid_global_dice"].to_numpy())),
        "category_2d_exactly_preserved": bool(np.array_equal(category_2d["global_dice"].to_numpy(), category_2d["hybrid_global_dice"].to_numpy())),
    }

    rows = category_summary.set_index("category")
    overall = rows.loc["SPECIALIST_ALL"]
    combined = rows.loc["2b+2c"]
    diffuse = rows.loc["1c+1d+1f"]
    overall_ci = bootstrap[(bootstrap["category"] == "SPECIALIST_ALL") & (bootstrap["contrast"] == "attention-control")].iloc[0]
    category_wins = sum(bool(rows.loc[category, "attention_minus_control_dice"] > 0 and rows.loc[category, "attention_minus_baseline_dice"] > 0) for category in SPECIALIST)
    primary_gates = {
        "attention_minus_control_gt_0p005_and_ci_lower_gt_0": bool(overall["attention_minus_control_dice"] > 0.005 and overall_ci["ci_lower_95"] > 0),
        "attention_minus_frozen_baseline_gt_0": bool(overall["attention_minus_baseline_dice"] > 0),
        "at_least_four_of_five_categories_win_both": bool(category_wins >= 4),
        "combined_2b2c_attention_minus_control_ge_0p005": bool(combined["attention_minus_control_dice"] >= 0.005),
        "diffuse_nonnegative_vs_control_and_baseline": bool(diffuse["attention_minus_control_dice"] >= 0 and diffuse["attention_minus_baseline_dice"] >= 0),
        "hits_not_down_more_than_two": bool(overall["attention_minus_control_hits"] >= -2 and overall["attention_minus_baseline_hits"] >= -2),
        "no_training_instability": bool(stability["passed"]),
    }
    ba_draws, _ = draw_cache["SPECIALIST_ALL"]
    worst_category_regression = min(float(rows.loc[category, "attention_minus_control_dice"]) for category in SPECIALIST)
    best_category_improvement = max(float(rows.loc[category, "attention_minus_control_dice"]) for category in SPECIALIST)
    continuation_gates = {
        "attention_minus_control_gt_0_with_one_sided_prob_ge_0p95": bool(overall["attention_minus_control_dice"] > 0 and float((ba_draws > 0).mean()) >= 0.95),
        "attention_not_worse_than_baseline_by_more_than_0p002": bool(overall["attention_minus_baseline_dice"] >= -0.002),
        "no_uncompensated_category_regression": bool(worst_category_regression >= -0.01 or best_category_improvement > 0.02),
    }
    gates = {
        "update": args.update,
        "primary": primary_gates,
        "primary_pass": all(primary_gates.values()),
        "continuation": continuation_gates,
        "continue_to_1000": bool(args.update == 500 and all(continuation_gates.values())),
        "category_wins_both": category_wins,
        "hybrid": hybrid_summary,
    }
    (args.output_dir / "gate_decision.json").write_text(json.dumps(gates, indent=2) + "\n")
    full_summary = {"update": args.update, "specialist": overall.to_dict(), "hybrid": hybrid_summary, "gates": gates}
    (args.output_dir / "fullvolume_specialist_summary.json").write_text(json.dumps(full_summary, indent=2) + "\n")

    historical = {
        "baseline_2b": 0.3418, "allcat_1over1_2b": 0.3578, "strict_multiscale_2b": 0.3625,
        "baseline_2c": 0.3762, "allcat_1over1_2c": 0.3866, "strict_multiscale_2c": 0.3782,
        "baseline_2d": 0.3799, "allcat_1over1_2d": 0.3692, "strict_multiscale_2d": 0.3669,
    }
    (args.output_dir / "historical_context_comparison.csv").write_text("metric,value\n" + "\n".join(f"{key},{value}" for key, value in historical.items()) + "\n")
    report = f"""# Dual-expert feasibility result — update {args.update}

Specialist Dice: control `{overall['control_mean_dice']:.6f}`, attention `{overall['attention_mean_dice']:.6f}`, frozen baseline `{overall['baseline_mean_dice']:.6f}`.

Attention minus control: `{overall['attention_minus_control_dice']:+.6f}`; 95% case-clustered bootstrap CI `[{overall_ci['ci_lower_95']:+.6f}, {overall_ci['ci_upper_95']:+.6f}]`.

Offline hybrid overall Dice: `{hybrid_summary['overall_hybrid_dice']:.6f}` (`{hybrid_summary['overall_delta']:+.6f}` vs frozen baseline). Non-specialist and category 2d preservation are exact by construction: `{hybrid_summary['non_specialist_exactly_preserved']}` / `{hybrid_summary['category_2d_exactly_preserved']}`.

Primary gate: **{'GO' if gates['primary_pass'] else 'NO-GO'}**. Conditional continuation to update 1000: **{'YES' if gates['continue_to_1000'] else 'NO'}**.
"""
    (args.output_dir / "go_no_go_report.md").write_text(report)
    print(json.dumps(gates, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
