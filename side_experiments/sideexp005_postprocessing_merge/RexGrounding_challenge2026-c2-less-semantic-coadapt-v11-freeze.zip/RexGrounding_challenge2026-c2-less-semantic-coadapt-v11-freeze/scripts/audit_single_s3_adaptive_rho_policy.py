#!/usr/bin/env python3
"""Export non-destructive parameter and policy diagnostics for adaptive-rho B/C/D."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
BCD = ROOT / "outputs/single_s3_adaptive_rho_BCD"
DEFAULT_OUT = ROOT / "outputs/single_s3_adaptive_rho_policy_audit"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    return parser.parse_args()


def load_adapter(path: Path) -> dict:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("format_version") != "voxtell_s3_adaptive_rho.v1":
        raise ValueError(f"Unexpected adapter format: {path}")
    return payload


def tensor_for(payload: dict, scale: str, field: str) -> torch.Tensor:
    key = scale.replace("/", "over")
    return payload["adapter_state"][f"scale_modules.{key}.{field}"].float()


def save_heatmap(
    values: np.ndarray,
    categories: list[str],
    scales: list[str],
    path: Path,
    title: str,
    colorbar: str,
) -> None:
    fig, ax = plt.subplots(figsize=(max(7, len(scales) * 2.1), 7), constrained_layout=True)
    image = ax.imshow(values, aspect="auto", cmap="viridis")
    ax.set_xticks(range(len(scales)), scales)
    ax.set_yticks(range(len(categories)), categories)
    ax.set_xlabel("S3 scale")
    ax.set_ylabel("ReX category")
    ax.set_title(title)
    fig.colorbar(image, ax=ax, label=colorbar)
    fig.savefig(path, dpi=180)
    plt.close(fig)


def export_b(payload: dict, out_dir: Path) -> list[dict]:
    config = payload["adapter_config"]
    rows = []
    matrix = np.zeros((len(config["categories"]), len(config["scales"])))
    for scale_index, scale in enumerate(config["scales"]):
        rho = tensor_for(payload, scale, "rho_raw").clamp(0, config["rho_max"])
        initial = tensor_for(payload, scale, "rho_init")
        for category_index, category in enumerate(config["categories"]):
            current = float(rho[category_index])
            start = float(initial[category_index])
            matrix[category_index, scale_index] = current
            rows.append(
                {
                    "category": category,
                    "scale": scale,
                    "initial_rho": start,
                    "final_rho": current,
                    "absolute_change": abs(current - start),
                    "near_zero_lt_0p01": current < 0.01,
                    "near_upper_gt_0p49": current > 0.49,
                    "original_fixed_policy_active": category in {"2b", "2c"},
                    "current_checkpoint_applies_at_inference": True,
                }
            )
    pd.DataFrame(rows).to_csv(out_dir / "B_update150_rho_by_category_scale.csv", index=False)
    (out_dir / "B_update150_rho_by_category_scale.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )
    save_heatmap(
        matrix,
        list(config["categories"]),
        list(config["scales"]),
        out_dir / "B_update150_rho_heatmap.png",
        "Experiment B update 150: learned scalar rho",
        "rho",
    )
    return rows


def export_c(payload: dict, out_dir: Path) -> tuple[list[dict], list[dict]]:
    config = payload["adapter_config"]
    value_rows = []
    summary_rows = []
    means = np.zeros((len(config["categories"]), len(config["scales"])))
    stds = np.zeros_like(means)
    active = np.zeros_like(means)
    histogram_dir = out_dir / "C_update300_histograms"
    histogram_dir.mkdir(exist_ok=True)
    for scale_index, scale in enumerate(config["scales"]):
        rho = tensor_for(payload, scale, "rho_raw").clamp(0, config["rho_max"])
        initial = tensor_for(payload, scale, "rho_init")
        for category_index, category in enumerate(config["categories"]):
            values = rho[category_index].numpy()
            starts = initial[category_index].numpy()
            for channel, (current, start) in enumerate(zip(values, starts)):
                value_rows.append(
                    {
                        "category": category,
                        "scale": scale,
                        "channel": channel,
                        "initial_rho": float(start),
                        "rho": float(current),
                        "absolute_change": float(abs(current - start)),
                    }
                )
            row = {
                "category": category,
                "scale": scale,
                "channel_count": int(values.size),
                "initial_scalar": float(np.mean(starts)),
                "mean": float(np.mean(values)),
                "median": float(np.median(values)),
                "std": float(np.std(values)),
                "min": float(np.min(values)),
                "max": float(np.max(values)),
                "p05": float(np.percentile(values, 5)),
                "p25": float(np.percentile(values, 25)),
                "p75": float(np.percentile(values, 75)),
                "p95": float(np.percentile(values, 95)),
                "fraction_lt_0p01": float(np.mean(values < 0.01)),
                "fraction_lt_0p05": float(np.mean(values < 0.05)),
                "fraction_gt_0p40": float(np.mean(values > 0.40)),
                "fraction_near_0p50": float(np.mean(values > 0.49)),
                "mean_absolute_change": float(np.mean(np.abs(values - starts))),
                "original_fixed_policy_active": category in {"2b", "2c"},
                "current_checkpoint_applies_at_inference": True,
            }
            summary_rows.append(row)
            means[category_index, scale_index] = row["mean"]
            stds[category_index, scale_index] = row["std"]
            active[category_index, scale_index] = 1.0 - row["fraction_lt_0p05"]

            fig, ax = plt.subplots(figsize=(6, 4), constrained_layout=True)
            ax.hist(values, bins=np.linspace(0, 0.5, 31), color="#287271", edgecolor="white")
            ax.axvline(np.mean(starts), color="#d06c6c", linestyle="--", label="initial")
            ax.set(
                xlabel="rho",
                ylabel="channels",
                title=f"C update 300: {category} at {scale}",
                xlim=(0, 0.5),
            )
            ax.legend()
            fig.savefig(
                histogram_dir / f"{category}_{scale.replace('/', 'over')}.png", dpi=150
            )
            plt.close(fig)

    pd.DataFrame(value_rows).to_csv(out_dir / "C_update300_channel_rho.csv", index=False)
    torch.save(
        {
            "adapter_config": config,
            "rho_by_scale": {
                scale: tensor_for(payload, scale, "rho_raw").clamp(0, config["rho_max"])
                for scale in config["scales"]
            },
        },
        out_dir / "C_update300_channel_rho.pt",
    )
    pd.DataFrame(summary_rows).to_csv(out_dir / "C_update300_rho_summary.csv", index=False)
    (out_dir / "C_update300_rho_summary.json").write_text(
        json.dumps(summary_rows, indent=2) + "\n"
    )
    for matrix, suffix, title, label in (
        (means, "mean", "C update 300: mean rho", "mean rho"),
        (stds, "std", "C update 300: channel rho standard deviation", "rho std"),
        (active, "active_fraction", "C update 300: active-channel fraction", "fraction rho >= 0.05"),
    ):
        save_heatmap(
            matrix,
            list(config["categories"]),
            list(config["scales"]),
            out_dir / f"C_update300_rho_{suffix}_heatmap.png",
            title,
            label,
        )
    return value_rows, summary_rows


def describe_alpha(values: np.ndarray) -> dict:
    return {
        "n": int(values.size),
        "mean": float(np.mean(values)),
        "median": float(np.median(values)),
        "std": float(np.std(values)),
        "min": float(np.min(values)),
        "max": float(np.max(values)),
        "p05": float(np.percentile(values, 5)),
        "p25": float(np.percentile(values, 25)),
        "p75": float(np.percentile(values, 75)),
        "p95": float(np.percentile(values, 95)),
        "fraction_lt_0p50": float(np.mean(values < 0.50)),
        "fraction_lt_0p25": float(np.mean(values < 0.25)),
        "fraction_gt_1p25": float(np.mean(values > 1.25)),
        "fraction_gt_1p50": float(np.mean(values > 1.50)),
        "fraction_gt_1p90": float(np.mean(values > 1.90)),
        "fraction_near_2p0": float(np.mean(values >= 1.99)),
        "mean_absolute_deviation_from_identity": float(np.mean(np.abs(values - 1.0))),
    }


def export_d_alpha(out_dir: Path) -> dict:
    source = BCD / "D/fast_eval/update_300/adaptive_rho_alpha_observations.csv"
    frame = pd.read_csv(source)
    grouped = []
    for (category, scale), group in frame.groupby(["category", "scale"], sort=True):
        grouped.append({"category": category, "scale": scale, **describe_alpha(group.alpha.values)})
    category_rows = [
        {"category": category, **describe_alpha(group.alpha.values)}
        for category, group in frame.groupby("category", sort=True)
    ]
    scale_rows = [
        {"scale": scale, **describe_alpha(group.alpha.values)}
        for scale, group in frame.groupby("scale", sort=True)
    ]
    payload = {
        "source": str(source.resolve()),
        "observation_unit": "sliding-window-patch finding",
        "overall": describe_alpha(frame.alpha.values),
        "by_category_and_scale": grouped,
        "by_category": category_rows,
        "by_scale": scale_rows,
        "categories_without_subset_observations": sorted(
            set(["unknown", "1a", "1b", "1c", "1d", "1e", "1f", "2a", "2b", "2c", "2d", "2e", "2f", "2g", "2h"])
            - set(frame.category.astype(str))
        ),
    }
    pd.DataFrame(grouped).to_csv(out_dir / "D_update300_alpha_by_category_scale.csv", index=False)
    pd.DataFrame(category_rows).to_csv(out_dir / "D_update300_alpha_by_category.csv", index=False)
    pd.DataFrame(scale_rows).to_csv(out_dir / "D_update300_alpha_by_scale.csv", index=False)
    (out_dir / "D_update300_alpha_summary.json").write_text(
        json.dumps(payload, indent=2) + "\n"
    )
    return payload


def source_location(path: Path, pattern: str) -> str:
    for index, line in enumerate(path.read_text().splitlines(), 1):
        if pattern in line:
            return f"{path.resolve()}:{index}"
    raise ValueError(f"Pattern {pattern!r} not found in {path}")


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    checkpoints = {
        "baseline": ROOT / "outputs/s3_selective_categories_matched_from_control_step6000_2h100/selective_2a_weak1c1d_3000/checkpoints/checkpoint_step_2500.pth",
        "B_update150": BCD / "B/checkpoints/adaptive_rho_B_update_150.pth",
        "C_update300": BCD / "C/checkpoints/adaptive_rho_C_update_300.pth",
        "D_update0": BCD / "D/checkpoints/adaptive_rho_D_update_0.pth",
        "D_update300": BCD / "D/checkpoints/adaptive_rho_D_update_300.pth",
    }
    artifacts = {
        "checkpoints": {key: str(path.resolve()) for key, path in checkpoints.items()},
        "baseline_existing_full_output_non_strict": str((BCD / "full_eval/baseline").resolve()),
        "C_existing_full_output_current_policy": str((BCD / "full_eval/C_update_300").resolve()),
        "fixed_subset_manifest": str((ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/stratified_subset_manifest.json").resolve()),
        "complete_validation_manifest": str((ROOT / "data/MICCAI_challenge_dataset.json").resolve()),
        "complete_validation_existing_prediction_manifest": str((BCD / "full_eval/baseline/manifest.json").resolve()),
        "threshold": 0.5,
        "split": "val",
        "preprocessing_plans": str((ROOT / "VoxTell/voxtell_v1.1/plans.json").resolve()),
        "prompt_embedding_cache": str((ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt").resolve()),
        "evaluator": str((ROOT / "scripts/evaluate_rex_predictions.py").resolve()),
        "existing_evaluation_scripts": [
            str((ROOT / "scripts/preflight_single_s3_adaptive_rho_4h100.sbatch").resolve()),
            str((ROOT / "scripts/evaluate_single_s3_adaptive_rho_stage_4h100.sbatch").resolve()),
            str((ROOT / "scripts/evaluate_single_s3_adaptive_rho_full200_4h100.sbatch").resolve()),
        ],
    }
    for path in checkpoints.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    (args.output_dir / "artifact_registry.json").write_text(
        json.dumps(artifacts, indent=2) + "\n"
    )

    b = load_adapter(checkpoints["B_update150"])
    c = load_adapter(checkpoints["C_update300"])
    d0 = load_adapter(checkpoints["D_update0"])
    d300 = load_adapter(checkpoints["D_update300"])
    b_rows = export_b(b, args.output_dir)
    _, c_rows = export_c(c, args.output_dir)
    d_alpha = export_d_alpha(args.output_dir)

    rho_differences = {}
    for scale in c["adapter_config"]["scales"]:
        c_rho = tensor_for(c, scale, "rho_raw")
        d0_rho = tensor_for(d0, scale, "rho_raw")
        rho_differences[scale] = float((c_rho - d0_rho).abs().max())
    d0_last_layers = {
        key: float(value.abs().max())
        for key, value in d0["adapter_state"].items()
        if key.endswith("alpha_predictor.head.3.weight")
        or key.endswith("alpha_predictor.head.3.bias")
    }
    policy_source = ROOT / "VoxTell/voxtell/model/adaptive_rho.py"
    model_source = ROOT / "VoxTell/voxtell/model/voxtell_experimental.py"
    run_source = ROOT / "scripts/run_voxtell_rex_inference.py"
    policy = {
        "classification_of_existing_B_C_D_results": "all-category learned routing plus channel-adaptive gating",
        "hard_category_mask_in_existing_current_policy": False,
        "zero_initialized_categories_could_learn_nonzero": True,
        "mask_order_in_new_strict_policy": (
            "The active mask is applied before AdaptiveRhoScale.forward. Inactive "
            "samples return effective rho zero; D alpha predictor is not evaluated."
        ),
        "non_gating_code_path_difference": (
            "The frozen base network and evaluator are shared. Existing adaptive "
            "inference replaces only S3 gate rho; its external baseline category gamma "
            "is ignored in the adapter branch."
        ),
        "existing_category_classification": {
            category: {
                "baseline_required_policy": (
                    "applies fixed gating" if category in {"2b", "2c"} else "permanently bypasses gating"
                ),
                "B_C_existing_training": (
                    "initialized rho then allowed to learn; learned rho applies at inference"
                ),
                "D_existing_training": (
                    "learned rho and alpha apply at inference"
                ),
                "new_strict_policy": (
                    "learned rho/alpha applies"
                    if category in {"2b", "2c"}
                    else "rho forced to zero and alpha bypassed"
                ),
            }
            for category in b["adapter_config"]["categories"]
        },
        "code_locations": {
            "adapter_direct_rho_selection": source_location(policy_source, "selected = rho[category_indices]"),
            "new_strict_mask_before_controller": source_location(policy_source, "if bool(active_mask.all())"),
            "model_adapter_replaces_fixed_gate": source_location(model_source, "rho_override = self.adaptive_rho_adapter("),
            "strict_cli": source_location(run_source, '"--attention-category-policy"'),
            "strict_category_membership": source_location(run_source, 'str(category) in {"2b", "2c"}'),
        },
        "D0_equivalence_to_C": {
            "maximum_rho_tensor_difference_by_scale": rho_differences,
            "zero_initialized_alpha_last_layer_max_abs": d0_last_layers,
            "state_equivalent": max(rho_differences.values()) == 0.0
            and max(d0_last_layers.values()) == 0.0,
        },
        "B_non_2b2c_nonzero_rows": [
            row
            for row in b_rows
            if row["category"] not in {"2b", "2c"} and row["final_rho"] >= 0.01
        ],
        "C_non_2b2c_nonzero_summary": [
            row
            for row in c_rows
            if row["category"] not in {"2b", "2c"} and row["mean"] >= 0.01
        ],
        "D_update300_alpha_overall": d_alpha["overall"],
    }
    (args.output_dir / "inference_category_policy_audit.json").write_text(
        json.dumps(policy, indent=2) + "\n"
    )
    print(json.dumps({"artifacts": artifacts, "policy": policy}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
