#!/usr/bin/env python3
"""Aggregate one completed B1/B2/B3 fixed30 causal checkpoint audit."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
EXP = ROOT / "outputs/word_global_v11_0to2000"
ARMS = {
    "B1": EXP / "B1_late_word_ca",
    "B2": EXP / "B2_word_query_prompt_decoder",
    "B3": EXP / "B3_candidates_global_router",
}
PAIRS = ROOT / "outputs/c2_semantic_p_token_causal_audit/samecase/eligible_pairs.csv"


def table(root: Path, update: int) -> pd.DataFrame:
    path = root / "full_volume" / f"update_{update:05d}" / "summary_tables/per_finding_metrics.csv"
    if not path.is_file():
        matches = list(
            (root / "full_volume").glob(
                f"update_{update:05d}*/summary_tables/per_finding_metrics.csv"
            )
        )
        if len(matches) != 1:
            raise FileNotFoundError(f"Expected one update{update} table under {root}: {matches}")
        path = matches[0]
    return pd.read_csv(path)


def summary(data: pd.DataFrame) -> dict[str, float | int]:
    return {
        "n": int(len(data)),
        "dice": float(data.global_dice.mean()),
        "hit": int(data.global_hit.astype(bool).sum()),
        "mean_predicted_voxels": float(data.pred_voxels.mean()),
        "median_predicted_voxels": float(data.pred_voxels.median()),
        "empty": int((data.pred_voxels == 0).sum()),
    }


def filter_pairs(data: pd.DataFrame, pairs: pd.DataFrame) -> pd.DataFrame:
    return data.merge(
        pairs,
        left_on=["file", "finding_idx"],
        right_on=["case", "finding_idx"],
        how="inner",
        validate="one_to_one",
    )


def paired(correct: pd.DataFrame, other: pd.DataFrame, seed: int) -> dict:
    keys = ["file", "finding_idx"]
    merged = correct[keys + ["global_dice", "global_hit"]].merge(
        other[keys + ["global_dice", "global_hit"]],
        on=keys,
        suffixes=("_correct", "_other"),
        validate="one_to_one",
    )
    merged["delta"] = merged.global_dice_correct - merged.global_dice_other
    case_groups = {
        case: frame.delta.to_numpy()
        for case, frame in merged.groupby("file", sort=False)
    }
    cases = list(case_groups)
    rng = np.random.default_rng(seed)
    draws = []
    for _ in range(5000):
        sampled = rng.choice(cases, len(cases), replace=True)
        draws.append(float(np.concatenate([case_groups[case] for case in sampled]).mean()))
    tolerance = 1e-12
    return {
        "n": int(len(merged)),
        "cases": int(len(cases)),
        "mean_gap": float(merged.delta.mean()),
        "median_gap": float(merged.delta.median()),
        "fraction_correct_gt_other": float((merged.delta > tolerance).mean()),
        "improved": int((merged.delta > tolerance).sum()),
        "worsened": int((merged.delta < -tolerance).sum()),
        "tied": int((merged.delta.abs() <= tolerance).sum()),
        "hit_delta": int(
            merged.global_hit_correct.astype(bool).sum()
            - merged.global_hit_other.astype(bool).sum()
        ),
        "case_cluster_bootstrap_ci95": [
            float(np.quantile(draws, 0.025)),
            float(np.quantile(draws, 0.975)),
        ],
    }


def markdown(result: dict) -> str:
    lines = [
        f"# {result['arm']} update{result['update']} word/global causal audit",
        "",
        f"Checkpoint: `{result['checkpoint']}`",
        "",
        "## Fixed30 conditions",
        "",
        "| Condition | N | Dice | HIT | Mean pred voxels | Median | Empty |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for condition, values in result["conditions"].items():
        lines.append(
            f"| {condition} | {values['n']} | {values['dice']:.6f} | "
            f"{values['hit']}/{values['n']} | {values['mean_predicted_voxels']:.1f} | "
            f"{values['median_predicted_voxels']:.1f} | {values['empty']} |"
        )
    lines += [
        "",
        "## Paired causal comparisons",
        "",
        "| Comparison | N | Mean gap | Median gap | Correct>Other | 95% CI |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for name, values in result["paired"].items():
        ci = values["case_cluster_bootstrap_ci95"]
        lines.append(
            f"| {name} | {values['n']} | {values['mean_gap']:.6f} | "
            f"{values['median_gap']:.6f} | {values['fraction_correct_gt_other']:.3f} | "
            f"[{ci[0]:.6f}, {ci[1]:.6f}] |"
        )
    lines += [
        "",
        "## Route sensitivity",
        "",
        f"See `{result['route_sensitivity_csv']}`.",
    ]
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=list(ARMS), required=True)
    parser.add_argument("--update", type=int, choices=[1000, 2000], required=True)
    args = parser.parse_args()
    run = ARMS[args.arm]
    correct = table(run, args.update)
    pair_manifest = pd.read_csv(PAIRS)
    pair_manifest = pair_manifest[pair_manifest.eligible][
        ["case", "finding_idx", "pair_type"]
    ]
    correct_eligible = filter_pairs(correct, pair_manifest)

    conditions: dict[str, pd.DataFrame] = {"correct" if args.arm != "B3" else "CC": correct}
    if args.arm in {"B1", "B2"}:
        for name in ("shuffle", "neutral", "samecase_wrong"):
            conditions[name] = table(run / f"causal_{args.update}" / name, args.update)
        comparisons = {
            "Correct-Shuffle": (correct, conditions["shuffle"]),
            "Correct-Neutral": (correct, conditions["neutral"]),
            "Correct-SameCaseWrong": (
                correct_eligible,
                filter_pairs(conditions["samecase_wrong"], pair_manifest),
            ),
        }
    else:
        for name in ("WC", "CW", "WW", "shuffle", "neutral"):
            conditions[name] = table(run / f"causal_{args.update}" / name, args.update)
        comparisons = {
            "WordGap_CC-WC": (correct_eligible, filter_pairs(conditions["WC"], pair_manifest)),
            "RouterGap_CC-CW": (correct_eligible, filter_pairs(conditions["CW"], pair_manifest)),
            "BothGap_CC-WW": (correct_eligible, filter_pairs(conditions["WW"], pair_manifest)),
            "CC-Shuffle": (correct, conditions["shuffle"]),
            "CC-Neutral": (correct, conditions["neutral"]),
        }

    condition_summary = {}
    for name, frame in conditions.items():
        if name in {"samecase_wrong", "WC", "CW", "WW"}:
            condition_summary[name] = summary(filter_pairs(frame, pair_manifest))
        elif name in {"correct", "CC"}:
            condition_summary[name] = summary(frame)
            condition_summary[f"{name}_samecase_eligible"] = summary(correct_eligible)
        else:
            condition_summary[name] = summary(frame)

    paired_results = {
        name: paired(left, right, seed=260900 + index + args.update)
        for index, (name, (left, right)) in enumerate(comparisons.items())
    }
    if args.arm == "B1" and args.update == 2000:
        bypass = table(run / "route_bypass", args.update)
        condition_summary["B1_bypass"] = summary(bypass)
        paired_results["Correct-B1Bypass"] = paired(correct, bypass, 261999)

    route_csv = run / f"causal_{args.update}/route_sensitivity/route_sensitivity_summary.csv"
    result = {
        "arm": args.arm,
        "update": args.update,
        "checkpoint": str((run / f"checkpoints/checkpoint_update_{args.update}.pth").resolve()),
        "samecase_pair_manifest": str(PAIRS.resolve()),
        "samecase_eligible": int(len(pair_manifest)),
        "samecase_pair_types": pair_manifest.pair_type.value_counts().to_dict(),
        "conditions": condition_summary,
        "paired": paired_results,
        "route_sensitivity_csv": str(route_csv.resolve()),
        "route_sensitivity": (
            pd.read_csv(route_csv).to_dict(orient="records") if route_csv.is_file() else []
        ),
    }
    output = run / f"causal_{args.update}/analysis"
    output.mkdir(parents=True, exist_ok=True)
    (output / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
    (output / "report.md").write_text(markdown(result))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
