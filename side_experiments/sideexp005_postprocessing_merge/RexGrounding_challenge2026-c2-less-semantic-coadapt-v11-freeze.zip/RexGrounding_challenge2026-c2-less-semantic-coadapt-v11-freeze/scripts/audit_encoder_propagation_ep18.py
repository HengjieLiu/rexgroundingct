#!/usr/bin/env python3
"""Full-model shape, FP32 equivalence, and short EP trainability audit."""

from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "VoxTell"))

from scripts.train_voxtell_rex_full_nnunet_aug import instantiate_voxtell  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=ROOT
        / "outputs/s3d_matched_continue_from_weakdiffuse_control_step1000"
        / "allcat_1over1_only_to_step6000/checkpoints/checkpoint_step_6000.pth",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "outputs/encoder_propagation_ep18_phase0/audits/full_model",
    )
    parser.add_argument("--trainability-updates", type=int, default=5)
    return parser.parse_args()


def crop_case() -> tuple[
    torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor
]:
    case = "train_2664_a_2.nii.gz"
    finding_idx = 0
    arrays = np.load(
        ROOT / "data/rex_voxtell_preprocessed_v1/cases/val/train_2664_a_2.npz"
    )
    mask = arrays["masks"][0]
    center = np.argwhere(mask > 0).mean(axis=0).round().astype(int)
    start = np.maximum(0, np.minimum(center - 96, np.asarray(mask.shape) - 192))
    slices = tuple(slice(int(value), int(value + 192)) for value in start)
    image = torch.from_numpy(arrays["image"][(slice(None), *slices)]).float()[None]
    target = torch.from_numpy(mask[slices]).float()[None, None]

    pooled_payload = torch.load(
        ROOT
        / "outputs/voxtell_rex_miccai_val/text_embedding_analysis"
        / "qwen_prompt_embeddings_train_val.pt",
        map_location="cpu",
        weights_only=False,
    )
    token_payload = torch.load(
        ROOT
        / "outputs/token_image_text_attention_phase0/cache"
        / "qwen_contextual_content_tokens_train_val.pt",
        map_location="cpu",
        weights_only=False,
    )
    key = ("val", case, finding_idx)
    pooled_index = next(
        index
        for index, record in enumerate(pooled_payload["records"])
        if (record["split"], record["case"], int(record["finding_idx"])) == key
    )
    token_index = next(
        index
        for index, record in enumerate(token_payload["records"])
        if (record["split"], record["case"], int(record["finding_idx"])) == key
    )
    pooled = pooled_payload["embeddings"][pooled_index].float()[None, None, None]
    tokens = token_payload["token_features"][token_index].float()[None, None]
    valid = torch.ones(tokens.shape[:3], dtype=torch.bool)
    return image, target, pooled, tokens, valid


def make_model(mode: str, device: torch.device, checkpoint: dict):
    model = instantiate_voxtell(
        ROOT / "VoxTell/voxtell_v1.1",
        device,
        deep_supervision=False,
        enable_s3_voxel_text_matching_attention=True,
        s3_attention_hidden_channels=128,
        s3_rho_mode="fixed",
        s3_rho_fixed=0.25,
        s3_logit_scale_init=10.0,
        s3_attention_scales=("1/1",),
        token_image_text_mode="original",
        encoder_propagation_mode=mode,
        encoder_propagation_hidden_dim=2048,
        encoder_propagation_heads=8,
        encoder_propagation_dropout=0.1,
        encoder_propagation_init_seed=260810,
    )
    incompatible = model.load_state_dict(checkpoint["network_weights"], strict=False)
    allowed_missing = ("s3_extra_attention_gates.",)
    if mode != "none":
        allowed_missing += ("encoder_propagation_block.",)
    invalid = [
        key
        for key in incompatible.missing_keys
        if not key.startswith(allowed_missing)
    ]
    if invalid or incompatible.unexpected_keys:
        raise RuntimeError(
            f"Checkpoint mismatch missing={invalid}, "
            f"unexpected={list(incompatible.unexpected_keys)}"
        )
    s3_extra = checkpoint.get("s3_extra_attention_weights")
    if s3_extra is None:
        raise RuntimeError("Canonical checkpoint is missing separate 1/1 S3 weights")
    model.s3_extra_attention_gates.load_state_dict(s3_extra, strict=True)
    return model.to(device)


def dice(logits: torch.Tensor, target: torch.Tensor) -> float:
    prediction = torch.sigmoid(logits) >= 0.5
    truth = target > 0.5
    denominator = prediction.sum() + truth.sum()
    if denominator == 0:
        return 1.0
    return float((2 * (prediction & truth).sum() / denominator).item())


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not torch.cuda.is_available():
        raise RuntimeError("The full 192^3 audit requires a scheduled CUDA GPU")
    device = torch.device("cuda")
    torch.manual_seed(2026)
    torch.cuda.manual_seed_all(2026)
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True, warn_only=True)
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    image, target, pooled, tokens, valid = crop_case()
    image, target, pooled = image.to(device), target.to(device), pooled.to(device)
    tokens, valid = tokens.to(device), valid.to(device)

    logits: dict[str, torch.Tensor] = {}
    shape_audits: dict[str, dict] = {}
    for label, mode in (("baseline", "none"), ("ep_text", "text"), ("ep_null", "null")):
        model = make_model(mode, device, checkpoint).eval().float()
        with torch.no_grad():
            kwargs = {}
            if mode != "none":
                kwargs = {"token_features": tokens, "token_valid_mask": valid}
            output = model(image, pooled, **kwargs)
        logits[label] = output.detach().cpu()
        if mode != "none":
            shape_audits[label] = model.last_encoder_propagation_audit
        del model
        gc.collect()
        torch.cuda.empty_cache()

    baseline = logits["baseline"]
    equivalence = {}
    for label in ("ep_text", "ep_null"):
        difference = (logits[label] - baseline).abs()
        equivalence[label] = {
            "max_absolute_logit_difference": float(difference.max().item()),
            "mean_absolute_logit_difference": float(difference.mean().item()),
            "baseline_dice": dice(baseline, target.cpu()),
            "candidate_dice": dice(logits[label], target.cpu()),
            "dice_difference": dice(logits[label], target.cpu())
            - dice(baseline, target.cpu()),
        }

    # Trainability: freeze the loaded VoxTell/S3 baseline and optimize only EP.
    model = make_model("text", device, checkpoint).train()
    for name, parameter in model.named_parameters():
        parameter.requires_grad_(name.startswith("encoder_propagation_block."))
    optimizer = torch.optim.SGD(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=1e-4,
        momentum=0.99,
        nesterov=True,
        weight_decay=3e-5,
    )
    trainability = []
    for update in range(1, args.trainability_updates + 1):
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            output = model(
                image, pooled, token_features=tokens, token_valid_mask=valid
            )
            loss = F.binary_cross_entropy_with_logits(output.float(), target)
        loss.backward()
        block = model.encoder_propagation_block
        assert block is not None
        branch_grad_norm = torch.sqrt(
            sum(
                parameter.grad.detach().float().square().sum()
                for name, parameter in block.named_parameters()
                if name != "gamma" and parameter.grad is not None
            )
        )
        gamma_grad = float(block.gamma.grad.detach().float().item())
        optimizer.step()
        trainability.append(
            {
                "update": update,
                "loss": float(loss.detach().item()),
                "finite_loss": bool(torch.isfinite(loss.detach()).item()),
                "gamma": float(block.gamma.detach().float().item()),
                "gamma_gradient": gamma_grad,
                "branch_gradient_norm": float(branch_grad_norm.item()),
            }
        )

    report = {
        "schema": "encoder_propagation_ep18_full_model_audit_v1",
        "checkpoint": str(args.checkpoint.resolve()),
        "gpu": torch.cuda.get_device_name(0),
        "input_dtype": str(image.dtype),
        "equivalence_precision": "FP32",
        "case": "val/train_2664_a_2.nii.gz",
        "finding_idx": 0,
        "prompt_count": 1,
        "shape_audits": shape_audits,
        "equivalence": equivalence,
        "trainability": trainability,
        "trainability_optimizer_note": (
            "Audit-only SGD lr=1e-4 with loaded baseline frozen; formal training uses "
            "the matched full-model optimizer and configured EP lr."
        ),
    }
    report["passed"] = bool(
        all(
            values["max_absolute_logit_difference"] <= 1e-5
            and abs(values["dice_difference"]) <= 1e-8
            for values in equivalence.values()
        )
        and all(row["finite_loss"] for row in trainability)
        and trainability[0]["gamma_gradient"] != 0.0
        and trainability[-1]["gamma"] != 0.0
        and any(row["branch_gradient_norm"] > 0 for row in trainability[1:])
        and all(
            audit["decoder_skip_is_original"]
            and audit["z_1_8_shape"] == [1, 256, 24, 24, 24]
            for audit in shape_audits.values()
        )
    )
    (args.output_dir / "audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if not report["passed"]:
        raise SystemExit("EP-1/8 audit gate failed; refusing dependent training")


if __name__ == "__main__":
    main()
