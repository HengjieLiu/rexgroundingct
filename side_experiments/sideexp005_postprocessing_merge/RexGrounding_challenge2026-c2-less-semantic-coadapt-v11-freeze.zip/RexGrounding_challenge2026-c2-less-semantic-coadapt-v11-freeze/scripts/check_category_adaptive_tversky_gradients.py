#!/usr/bin/env python3
"""Compare baseline Dice and category-adaptive Tversky logit gradients."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch

from scripts.train_voxtell_rex_full_nnunet_aug import segmentation_loss


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mapping-json", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    return parser.parse_args()


def fixed_batch() -> tuple[torch.Tensor, torch.Tensor, list[str]]:
    target = torch.zeros(1, 4, 16, 16, 16)
    logits = torch.full_like(target, -4.0)

    target[0, 0, 5:11, 5:11, 5:11] = 1
    logits[0, 0, 5:11, 5:11, 5:11] = 3.0
    logits[0, 0, 2:5, 5:11, 5:11] = 2.0

    target[0, 1, 3:9, 3:9, 3:9] = 1
    logits[0, 1, 3:6, 3:9, 3:9] = 2.0

    target[0, 2, 7:13, 7:13, 7:13] = 1
    logits[0, 2, 7:11, 7:13, 7:13] = 2.0
    logits[0, 2, 4:7, 7:13, 7:13] = 1.5

    logits[0, 3, 1:4, 1:4, 1:4] = 1.0
    return logits, target, ["synthetic_fp", "synthetic_fn", "synthetic_mixed", "unknown_empty"]


def run_loss(
    mode: str,
    base_logits: torch.Tensor,
    target: torch.Tensor,
    categories: list[str],
    mapping: dict,
) -> tuple[dict, list[dict]]:
    logits = base_logits.clone().requires_grad_(True)
    loss, stats = segmentation_loss(
        logits,
        target,
        prompt_weights=torch.ones(1, 4),
        prompt_categories=[categories],
        rex_loss_mode=mode,
        category_tversky_mapping=mapping,
        category_tversky_weight=1.0,
        voxel_bce_weighting=True,
        bce_foreground_weight=1.0,
        bce_boundary_weight=1.5,
        bce_background_weight=0.5,
        bce_boundary_radius=4,
        empty_target_loss_mode="bce_only",
        empty_target_loss_weight=0.5,
    )
    loss.backward()
    grad = logits.grad.detach()
    pred = torch.sigmoid(logits.detach()) >= 0.5
    tgt = target.bool()
    rows = []
    labels = ["fp_heavy", "fn_heavy", "mixed", "empty"]
    for prompt_idx, label in enumerate(labels):
        prompt_grad = grad[0, prompt_idx]
        prompt_target = tgt[0, prompt_idx]
        prompt_pred = pred[0, prompt_idx]
        regions = {
            "foreground": prompt_target,
            "background": ~prompt_target,
            "true_positive": prompt_target & prompt_pred,
            "false_positive": ~prompt_target & prompt_pred,
            "false_negative": prompt_target & ~prompt_pred,
        }
        row = {
            "loss_mode": mode,
            "prompt_group": label,
            "logit_gradient_norm": float(prompt_grad.norm()),
        }
        for name, mask in regions.items():
            row[f"mean_abs_gradient_{name}"] = float(
                prompt_grad[mask].abs().mean() if mask.any() else 0.0
            )
        rows.append(row)
    summary = {
        "loss_mode": mode,
        "total_loss": float(loss.detach()),
        "scale0_bce": stats["scale0_bce"],
        "scale0_overlap_loss": (
            stats["scale0_dice_loss"]
            if mode == "dice_bce"
            else stats["scale0_tversky_loss"]
        ),
        "final_logits_gradient_norm": float(grad.norm()),
    }
    return summary, rows


def main() -> int:
    args = parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    mapping = json.loads(args.mapping_json.read_text())
    mapping.update(
        {
            "synthetic_fp": {"group": "fp_heavy", "alpha_fp": 0.7, "beta_fn": 0.3},
            "synthetic_fn": {"group": "fn_heavy", "alpha_fp": 0.3, "beta_fn": 0.7},
            "synthetic_mixed": {"group": "mixed", "alpha_fp": 0.5, "beta_fn": 0.5},
        }
    )
    logits, target, categories = fixed_batch()
    summaries = []
    rows = []
    for mode in ("dice_bce", "category_adaptive_tversky"):
        summary, mode_rows = run_loss(mode, logits, target, categories, mapping)
        summaries.append(summary)
        rows.extend(mode_rows)
    summary_frame = pd.DataFrame(summaries)
    gradient_frame = pd.DataFrame(rows)
    baseline_norm = float(summary_frame.loc[summary_frame.loss_mode == "dice_bce", "final_logits_gradient_norm"].iloc[0])
    adaptive_norm = float(
        summary_frame.loc[
            summary_frame.loss_mode == "category_adaptive_tversky", "final_logits_gradient_norm"
        ].iloc[0]
    )
    ratio = adaptive_norm / max(baseline_norm, 1e-12)
    if not 0.5 <= ratio <= 2.0:
        raise RuntimeError(f"Adaptive/baseline gradient norm ratio {ratio:.4f} is outside [0.5, 2.0]")
    summary_frame["adaptive_to_baseline_grad_norm_ratio"] = ratio
    summary_frame.to_csv(args.out_dir / "gradient_summary.csv", index=False)
    gradient_frame.to_csv(args.out_dir / "gradient_regions.csv", index=False)
    report = [
        "# Category-adaptive Tversky gradient sanity",
        "",
        "```text",
        summary_frame.round(7).to_string(index=False),
        "```",
        "",
        "```text",
        gradient_frame.round(9).to_string(index=False),
        "```",
        "",
        f"Adaptive/baseline final-logit gradient norm ratio: {ratio:.6f}",
        "",
    ]
    (args.out_dir / "report.md").write_text("\n".join(report))
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
