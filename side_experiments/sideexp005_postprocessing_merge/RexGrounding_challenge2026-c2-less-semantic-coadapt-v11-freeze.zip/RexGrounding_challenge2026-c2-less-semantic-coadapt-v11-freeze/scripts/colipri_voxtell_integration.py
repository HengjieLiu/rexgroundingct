#!/usr/bin/env python3
"""Strict encoder routing for the COLIPRI/VoxTell go/no-go pilots."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence

import torch
from torch import nn


def tensor_shape(value: Any) -> Any:
    if isinstance(value, torch.Tensor):
        return list(value.shape)
    if isinstance(value, (list, tuple)):
        return [tensor_shape(item) for item in value]
    return str(type(value).__name__)


def first_tensor(value: Any) -> torch.Tensor | None:
    if isinstance(value, torch.Tensor):
        return value
    if isinstance(value, (list, tuple)):
        for item in value:
            tensor = first_tensor(item)
            if tensor is not None:
                return tensor
    return None


@dataclass
class ForwardAudit:
    colipri_text_forward_count: int = 0
    colipri_image_forward_count: int = 0
    voxtell_image_forward_count: int = 0
    qwen_embedding_use_count: int = 0
    shape_trace: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "colipri_text_forward_count": self.colipri_text_forward_count,
            "colipri_image_forward_count": self.colipri_image_forward_count,
            "voxtell_image_forward_count": self.voxtell_image_forward_count,
            "qwen_embedding_use_count": self.qwen_embedding_use_count,
            "shape_trace": self.shape_trace,
        }


class ColipriTextAdapter(nn.Module):
    """Map normalized COLIPRI text vectors onto the Qwen input distribution."""

    def __init__(
        self,
        input_dim: int = 768,
        output_dim: int = 2560,
        qwen_component_std: float = 2.71138,
    ) -> None:
        super().__init__()
        self.linear = nn.Linear(input_dim, output_dim)
        self.norm = nn.LayerNorm(output_dim)
        self.register_buffer(
            "qwen_component_std",
            torch.tensor(float(qwen_component_std), dtype=torch.float32),
        )
        nn.init.xavier_uniform_(self.linear.weight)
        nn.init.zeros_(self.linear.bias)

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return self.norm(self.linear(value)) * self.qwen_component_std


class StrictEncoderRoutedVoxTell(nn.Module):
    """Route image and text through explicitly selected encoders without fallback."""

    VALID_TEXT_SOURCES = {"qwen", "colipri"}
    VALID_IMAGE_SOURCES = {"voxtell", "colipri"}

    def __init__(
        self,
        voxtell: nn.Module,
        *,
        text_encoder_source: str,
        image_encoder_source: str,
        colipri_text_encoder: nn.Module | None = None,
        colipri_tokenizer: Any | None = None,
        text_adapter: nn.Module | None = None,
        colipri_image_encoder: nn.Module | None = None,
    ) -> None:
        super().__init__()
        if text_encoder_source not in self.VALID_TEXT_SOURCES:
            raise ValueError(f"Unknown text_encoder_source={text_encoder_source!r}")
        if image_encoder_source not in self.VALID_IMAGE_SOURCES:
            raise ValueError(f"Unknown image_encoder_source={image_encoder_source!r}")
        if text_encoder_source == "colipri" and (
            colipri_text_encoder is None or colipri_tokenizer is None or text_adapter is None
        ):
            raise RuntimeError("COLIPRI text mode requires encoder, tokenizer, and adapter")
        if image_encoder_source == "colipri" and colipri_image_encoder is None:
            raise RuntimeError("COLIPRI image mode requires an explicit image encoder")

        self.voxtell = voxtell
        self.text_encoder_source = text_encoder_source
        self.image_encoder_source = image_encoder_source
        self.colipri_text_encoder = colipri_text_encoder
        self.colipri_tokenizer = colipri_tokenizer
        self.text_adapter = text_adapter
        self.colipri_image_encoder = colipri_image_encoder
        self.audit = ForwardAudit()
        self._install_shape_hooks()

    def _install_shape_hooks(self) -> None:
        def hook(name: str):
            def capture(_module, inputs, output):
                if name not in self.audit.shape_trace:
                    tensor = first_tensor(output)
                    self.audit.shape_trace[name] = {
                        "input": tensor_shape(inputs),
                        "output": tensor_shape(output),
                        "output_norm_mean": (
                            float(tensor.detach().float().flatten(1).norm(dim=1).mean().item())
                            if tensor is not None and tensor.ndim > 0
                            else None
                        ),
                    }

            return capture

        self.voxtell.encoder.register_forward_hook(hook("voxtell_encoder_skips"))
        self.voxtell.project_bottleneck_embed.register_forward_hook(
            hook("project_bottleneck_embed")
        )
        self.voxtell.project_text_embed.register_forward_hook(hook("project_text_embed"))
        self.voxtell.transformer_decoder.register_forward_hook(hook("prompt_decoder"))
        self.voxtell.decoder.register_forward_hook(hook("image_decoder"))
        if self.text_adapter is not None:
            self.text_adapter.register_forward_hook(hook("colipri_text_adapter"))

    def reset_audit(self) -> None:
        self.audit = ForwardAudit()

    def _encode_colipri_text(
        self,
        prompt_texts: Sequence[Sequence[str]],
        device: torch.device,
        *,
        track_grad: bool,
    ) -> torch.Tensor:
        if self.colipri_text_encoder is None or self.colipri_tokenizer is None:
            raise RuntimeError("COLIPRI text components are unavailable")
        if not prompt_texts or not prompt_texts[0]:
            raise ValueError("prompt_texts must have shape [batch, prompts]")
        prompt_count = len(prompt_texts[0])
        if any(len(item) != prompt_count for item in prompt_texts):
            raise ValueError("Every batch item must contain the same number of prompts")
        flat = [text for item in prompt_texts for text in item]
        encoded = self.colipri_tokenizer(
            flat,
            max_length=512,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        token_ids = encoded["input_ids"].to(device)
        attention_mask = encoded["attention_mask"].to(device)
        self.audit.colipri_text_forward_count += 1
        context = torch.enable_grad() if track_grad else torch.no_grad()
        with context:
            text = self.colipri_text_encoder(
                token_ids,
                attention_mask,
                pool=True,
                normalize=True,
            )
        text = text.reshape(len(prompt_texts), prompt_count, -1)
        self.audit.shape_trace.setdefault("colipri_text", list(text.shape))
        return text

    def forward(
        self,
        image: torch.Tensor,
        *,
        prompt_texts: Sequence[Sequence[str]] | None = None,
        qwen_embeddings: torch.Tensor | None = None,
        train_colipri_text: bool = False,
    ):
        self.audit.shape_trace.setdefault("image_input", list(image.shape))
        if self.text_encoder_source == "qwen":
            if qwen_embeddings is None:
                raise RuntimeError("Qwen mode requires explicit qwen_embeddings")
            if prompt_texts is not None:
                raise RuntimeError("Qwen mode does not accept prompt_texts")
            self.audit.qwen_embedding_use_count += 1
            text_embedding = qwen_embeddings
        else:
            if qwen_embeddings is not None:
                raise RuntimeError("COLIPRI text mode forbids Qwen embeddings")
            if prompt_texts is None:
                raise RuntimeError("COLIPRI text mode requires raw prompt_texts")
            text = self._encode_colipri_text(
                prompt_texts,
                image.device,
                track_grad=train_colipri_text,
            )
            adapted = self.text_adapter(text)
            self.audit.shape_trace.setdefault(
                "colipri_text_norms",
                {
                    "encoder_output_mean": float(
                        text.detach().float().norm(dim=-1).mean().item()
                    ),
                    "adapter_output_mean": float(
                        adapted.detach().float().norm(dim=-1).mean().item()
                    ),
                },
            )
            text_embedding = adapted.unsqueeze(2)
            self.audit.shape_trace.setdefault("adapted_text", list(text_embedding.shape))

        if self.image_encoder_source == "voxtell":
            self.audit.voxtell_image_forward_count += 1
            output = self.voxtell(image, text_embedding)
        else:
            self.audit.colipri_image_forward_count += 1
            raise NotImplementedError(
                "Primus-M exposes only one 24^3 grid. A learned feature pyramid "
                "requires explicit approval before it can call the VoxTell decoder."
            )
        self.audit.shape_trace.setdefault("logits", tensor_shape(output))
        return output

    def assert_experiment_path(self, experiment: int) -> None:
        counters = self.audit
        if experiment == 5:
            expected = (
                counters.colipri_text_forward_count > 0
                and counters.qwen_embedding_use_count == 0
                and counters.voxtell_image_forward_count > 0
                and counters.colipri_image_forward_count == 0
            )
        elif experiment == 6:
            expected = (
                counters.colipri_text_forward_count > 0
                and counters.colipri_image_forward_count > 0
                and counters.qwen_embedding_use_count == 0
                and counters.voxtell_image_forward_count == 0
            )
        else:
            raise ValueError(f"Unsupported experiment={experiment}")
        if not expected:
            raise RuntimeError(f"Unexpected encoder execution: {counters.as_dict()}")


def finite_or_raise(name: str, value: torch.Tensor | Sequence[torch.Tensor]) -> None:
    tensors = value if isinstance(value, (list, tuple)) else [value]
    for index, tensor in enumerate(tensors):
        if not torch.isfinite(tensor).all():
            raise FloatingPointError(f"{name}[{index}] contains NaN or Inf")
