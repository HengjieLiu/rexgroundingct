"""CPU construction/coverage plus small-grid progressive multi-prompt checks."""
import json
from pathlib import Path
import torch
import train_voxtell_rex_full_nnunet_aug as tr

ROOT = Path(__file__).resolve().parents[1]


def main():
    torch.set_num_threads(2)
    out = ROOT / 'b3_bico_e345_audit'
    out.mkdir(exist_ok=True)
    a = tr.parse_args([])
    for key, value in json.loads((ROOT / 'outputs/b3_plus_less_v11/args.json').read_text()).items():
        setattr(a, key, value)
    a.less_encoder_mode = 'bico_e345'
    a.less_encoder_levels = [3, 4, 5]
    model = tr.instantiate_voxtell(
        ROOT / 'VoxTell/voxtell_v1.1', torch.device('cpu'), True,
        less_encoder_mode='bico_e345', less_encoder_levels=[3, 4, 5],
        less_encoder_attention_dim=256, less_encoder_heads=8,
        less_encoder_dropout=0, less_encoder_prompt_chunk_size=1,
        word_global_mode='b3', word_global_bridge_checkpoint=a.word_global_bridge_checkpoint)
    optimizer = tr.build_optimizer(model, a)
    coverage = tr.audit_optimizer_parameter_coverage(model, optimizer, out)
    assert coverage['status'] == 'pass'
    counts = {key: sum(p.numel() for p in value.parameters())
              for key, value in model.less_encoder_blocks.items()}
    assert list(counts) == ['level3', 'level4', 'level5']
    # Six prompt-flattened entries demonstrate no cross-batch/query mixing.
    tokens = torch.randn(6, 7, 2560)
    valid = torch.ones(6, 7, dtype=torch.bool)
    valid[:, -2:] = False
    initial = tokens.clone()
    for level, size in [(3, 4), (4, 2), (5, 1)]:
        block = model.less_encoder_blocks[f'level{level}']
        image = torch.randn(6, block.image_reads_text.image_dim, size, size, size)
        image_out, token_out = block(image, tokens, valid)
        assert torch.equal(token_out[:, -2:], initial[:, -2:])
        assert token_out.requires_grad and image_out.shape == image.shape
        token_out.retain_grad()
        tokens = token_out
    q = model.word_global_candidate_bridge(tokens.reshape(2, 3, 7, 2560), valid.reshape(2, 3, 7))
    assert q.shape == (2, 3, 4, 2048)
    # Here text progression is tested; full segmentation backward is a GPU gate.
    q.square().mean().backward()
    assert tokens.grad is not None and tokens.grad.norm() > 0
    assert not initial.requires_grad
    result = {'status': 'PASS_STATIC', 'bico_counts': counts,
              'bico_total': sum(counts.values()),
              'total_registered': sum(p.numel() for p in model.parameters() if p.requires_grad),
              'cpu_query_shape': list(q.shape), 'optimizer_status': coverage['status'],
              'cached_tokens_frozen': True, 'padding_preserved': True}
    (out / 'static_results.json').write_text(json.dumps(result, indent=2) + '\n')
    (out / 'parameter_count.md').write_text('# CPU parameter count\n\n```json\n' + json.dumps(result, indent=2) + '\n```\n')
    (out / 'optimizer_audit.md').write_text('# Optimizer coverage\n\n' + json.dumps(coverage['group_summaries'], indent=2) + '\n\nCoverage: PASS; every registered trainable parameter included exactly once. GPU gradient gate remains pending.\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
