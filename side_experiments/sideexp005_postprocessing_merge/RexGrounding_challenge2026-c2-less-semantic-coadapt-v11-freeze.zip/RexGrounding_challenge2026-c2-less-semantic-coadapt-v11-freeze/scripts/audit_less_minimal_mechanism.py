"""Prepare/run exactly three checkpoints x three LESS-only conditions."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(os.environ.get('LESS_MINIMAL_AUDIT_ROOT', str(ROOT / 'less_minimal_mechanism_audit')))
RUN = ROOT / 'outputs/b3_plus_less_v11'
MANIFEST = RUN / 'fixed30_manifest.json'
CACHE = ROOT / 'outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt'
PROMPTS = ROOT / 'outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/qwen_original_subset30.pt'
UPDATES = [1000, 3000, 5000]


def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2)+'\n')


def prepare():
    import numpy as np
    from scipy.optimize import linear_sum_assignment
    OUT.mkdir(exist_ok=True)
    entries = json.loads(MANIFEST.read_text())['val']
    findings = sorted([{'case': e['name'], 'finding_idx': int(k), 'prompt': v,
                        'category': e.get('categories', {}).get(k, '')}
                       for e in entries for k,v in e['findings'].items()],
                      key=lambda x: (x['case'], x['finding_idx']))
    assert len(entries) == 30 and len(findings) == 49
    cost = np.random.default_rng(1701).uniform(0, .001, (49,49))
    for i,a in enumerate(findings):
        for j,b in enumerate(findings):
            cost[i,j] += (1e6 if a['case']==b['case'] or a['prompt']==b['prompt'] else 0)
            cost[i,j] += (1 if a['category']==b['category'] else 0)
    ii,jj = linear_sum_assignment(cost)
    mapping = {}
    for i,j in zip(ii,jj):
        a,b=findings[i],findings[j]
        assert a['case'] != b['case'] and a['prompt'] != b['prompt']
        mapping[a['case']+':'+str(a['finding_idx'])] = b
    # First three manifest cases: predetermined, not selected on outputs.
    mapping['_feature_cases'] = [e['name'] for e in entries[:3]]
    save(OUT/'wrong_less_mapping.json', mapping)
    git = lambda *a: subprocess.check_output(['/usr/bin/git', *a],cwd=ROOT,text=True).strip()
    provenance = {'parent_head': git('rev-parse','HEAD'), 'parent_status':git('status','--short'),
                  'voxtell_head':git('-C','VoxTell','rev-parse','HEAD'),
                  'manifest':str(MANIFEST), 'manifest_sha256':hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
                  'checkpoints':{}, 'git_executable':'/usr/bin/git', 'captured_on':os.uname().nodename}
    for u in UPDATES:
        ck=RUN/'checkpoints'/f'checkpoint_update_{u}.pth'
        assert ck.is_file()
        provenance['checkpoints'][str(u)]=str(ck)
        model=OUT/str(u)/'model'
        (model/'fold_0').mkdir(parents=True,exist_ok=True)
        for source,dest in [(RUN/'plans.json',model/'plans.json'),(ck,model/'fold_0/checkpoint_final.pth')]:
            if dest.is_symlink(): assert dest.resolve()==source.resolve()
            elif dest.exists(): raise RuntimeError(f'Unexpected existing model file {dest}')
            else: dest.symlink_to(source)
    save(OUT/'provenance.json',provenance)
    (OUT/'provenance.md').write_text('# Minimal LESS audit provenance\n\n'+
        'Exact checkpoints: '+json.dumps(provenance['checkpoints'],indent=2)+'\n\n'+
        'All descend from the same v1.1 initialization, continuous B3+LESS 0–5000 run. '
        'See ../less_functional_audit/provenance.md and less_implementation.md.\n\n'
        'LESSImageWordConditioning3D in VoxTell/voxtell/model/less_word_conditioning.py; '
        'ExperimentalVoxTellModel._forward_less_encoder executes levels 2,3,4,5. '
        'Pre X, post X+tanh(MLP(LN(ImageToWordCA(X,T)))). T is cached frozen Qwen contextual tokens.\n\n'
        'The independent wrapper changes only _forward_less_encoder arguments for WRONG; '
        'the caller retains its factual tokens and global sentence. BYPASS delivers inputs[0] at each block. '
        'No checkpoint or shared inference/model source is edited.\n\n'
        'Fixed30: 30 cases/49 findings; '+str(MANIFEST)+'; SHA256 '+provenance['manifest_sha256']+'. '
        'BF16, canonical preprocessing/restoration, threshold 0.5, HIT Dice>0.1, no postprocessing.\n\n'
        'Wrong text is a fixed one-to-one assignment (seed1701 tie-break), all cross-case/nonidentical, '
        'favoring different pathology categories; no predictions used. See wrong_less_mapping.json.\n\n'
        'Feature cohort: '+', '.join(mapping['_feature_cases'])+'. Exact full tensors at first window/first prompt '
        'per level; later levels include upstream propagation. No full-cohort feature storage.\n\n'
        'Normal outputs are recomputed because exact paired full-tensor features were not cached. '
        'Default vs instrumented normal probability regression precedes formal runs. '
        'Provenance captured on submission host with /usr/bin/git (absent on some compute nodes).\n')


def command(argv):
    print('RUN', ' '.join(map(str,argv)),flush=True)
    subprocess.run(list(map(str,argv)),cwd=ROOT,check=True)


def infer(u, condition, phase, cases=None, baseline=False):
    dest=OUT/str(u)/phase/condition
    if (dest/'manifest.json').is_file(): return dest
    common=['--rex-json',MANIFEST,'--splits','val','--image-dir',ROOT/'data/ct_rate_volumes_fixed',
            '--reference-mask-dir',ROOT/'data/segmentations','--model-dir',OUT/str(u)/'model',
            '--prompt-embedding-cache',PROMPTS,'--token-feature-cache',CACHE,'--text-representation','qwen',
            '--output-dir',dest,'--device','cuda','--amp-dtype','bfloat16','--threshold','0.5',
            '--presence-logit-weight','0','--spatial-attention-rho-scale','1','--overwrite']
    if cases: common += ['--cases',*cases,'--probability-output-dir',dest/'probabilities']
    if baseline: cmd=[sys.executable,ROOT/'scripts/run_less_minimal_baseline.py']
    else: cmd=[sys.executable,ROOT/'scripts/run_less_minimal_condition.py','--condition',condition,
               '--audit-root',OUT,'--update',u,'--phase',phase,'--mapping',OUT/'wrong_less_mapping.json','--cache',CACHE]
    command(cmd+common)
    return dest


def run():
    import numpy as np
    started=time.time()
    mapping=json.loads((OUT/'wrong_less_mapping.json').read_text())
    cases=mapping['_feature_cases']
    for u in UPDATES:
        gate=OUT/str(u)/'regression_pass.json'
        if not gate.exists():
            default=infer(u,'default','regression',cases,True)
            for c in ['normal','bypass','wrong']: infer(u,c,'regression',cases)
            regress=[]
            for case in cases:
                name=case.removesuffix('.nii.gz')+'.npz'
                with np.load(default/'probabilities'/name) as f: a=f['probability']
                with np.load(OUT/str(u)/'regression/normal/probabilities'/name) as f: b=f['probability']
                diff=float(np.max(np.abs(a-b)))
                assert diff<=1e-6 and np.array_equal(a>.5,b>.5), f'Normal regression failed {u} {case}: {diff}'
                hashes=[]
                for c in ['normal','bypass','wrong']:
                    records=[json.loads(x) for x in (OUT/str(u)/'regression'/f'{c}_audit.jsonl').read_text().splitlines()]
                    row=[r for r in records if r['case']==case][-1]
                    assert row['main_inputs_unchanged']
                    hashes.append(row['main_input_hashes'])
                    if c=='bypass': assert all(x['bypass_identity'] for x in row['features'])
                    if c=='wrong': assert row['less_replaced_calls']>0
                assert hashes[0]==hashes[1]==hashes[2]
                regress.append({'case':case,'normal_max_abs_probability_difference':diff,'main_hashes_identical':True})
            save(gate,regress)
        for c in ['normal','bypass','wrong']:
            dest=infer(u,c,'formal')
            summary=dest/'summary_tables/summary.json'
            if not summary.exists():
                command([sys.executable,ROOT/'scripts/evaluate_rex_predictions.py','--dataset-json',MANIFEST,
                         '--splits','val','--gt-dir',ROOT/'data/segmentations','--pred-dir',dest,
                         '--output-json',dest/'eval.json','--num-workers','2','--overwrite','--global-only'])
                command([sys.executable,ROOT/'scripts/summarize_rex_global_eval.py','--dataset-json',MANIFEST,
                         '--splits','val','--gt-dir',ROOT/'data/segmentations','--pred-dir',dest,
                         '--eval-json',dest/'eval.json','--out-dir',dest/'summary_tables',
                         '--run-label',f'{u}_{c}','--compute-voxel-metrics'])
        command([sys.executable,ROOT/'scripts/analyze_less_minimal_mechanism.py'])
    save(OUT/'runtime.json',{'job_id':os.environ.get('SLURM_JOB_ID'),'wall_seconds':time.time()-started})
    command([sys.executable,ROOT/'scripts/analyze_less_minimal_mechanism.py'])


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--prepare',action='store_true'); a=p.parse_args()
    prepare() if a.prepare else run()
