#!/usr/bin/env python3
"""Diagnose why P0-B2-lite geometric coverage does not translate to Dice."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from p0b2_lite_common import (
    FINAL_THRESHOLD,
    OUT,
    PREP,
    SAFE_MARGIN,
    ZOOM,
    ZOOM_SOURCE,
    archive_path,
    atomic_csv,
    atomic_json,
    fixed_crop_slices,
    insert_zoom_max,
    load_manifest,
    proposal_cache_path,
)


def selected_canvas(
    shape: tuple[int, int, int],
    rows: pd.DataFrame,
    case: str,
    finding_idx: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    canvas = np.zeros(shape, dtype=np.float16)
    coverage = np.zeros(shape, dtype=bool)
    safe_union = np.zeros(shape, dtype=bool)
    for _, candidate in rows.iterrows():
        cache = proposal_cache_path(
            ZOOM, case, finding_idx, int(candidate.component_id)
        )
        with np.load(cache, allow_pickle=False) as archive:
            patch = archive["zoom_probability"].astype(np.float16)
        start = tuple(
            int(candidate[f"roi_requested_{axis}0"]) for axis in "dhw"
        )
        insert_zoom_max(canvas, coverage, patch, start)
        safe_union[fixed_crop_slices(start, shape, margin=SAFE_MARGIN)] = True
    return canvas, coverage, safe_union


def counts(mask: np.ndarray, gt: np.ndarray) -> tuple[int, int]:
    return int(np.logical_and(mask, gt).sum()), int(
        np.logical_and(mask, ~gt).sum()
    )


def main() -> int:
    proposal = pd.read_csv(OUT / "per_finding_proposal_results.csv")
    downstream = pd.read_csv(OUT / "per_finding_max_fusion_results.csv")
    candidates = pd.read_csv(OUT / "candidate_manifest_top8.csv")
    learned = pd.read_csv(OUT / "learned_selected_crops.csv")
    findings = pd.read_csv(OUT / "case_finding_split_manifest.csv")
    findings = findings.loc[findings.outer_fold.eq(0)].copy()
    manifest = {
        row["case"]: row for row in load_manifest(PREP / "manifest.jsonl", "val", None)
    }
    proposal_lookup = proposal.set_index("finding_key")
    downstream_lookup = downstream.set_index("finding_key")
    rows = []
    for case, case_findings in findings.groupby("file", sort=True):
        with np.load(manifest[case]["cache_path"], allow_pickle=False) as archive:
            masks = archive["masks"].astype(bool)
        with np.load(
            archive_path(ZOOM_SOURCE / "context_probabilities", case),
            allow_pickle=False,
        ) as archive:
            context = archive["probability"].astype(np.float16)
            finding_ids = [int(value) for value in archive["finding_ids"]]
        for _, finding in case_findings.sort_values("channel").iterrows():
            finding_idx = int(finding.finding_idx)
            channel = int(finding.channel)
            if finding_ids[channel] != finding_idx:
                raise AssertionError(f"{case}/{finding_idx}: context alignment failed")
            key = finding.finding_key
            gt = masks[channel]
            base = context[channel] > np.float16(FINAL_THRESHOLD)
            bank = candidates.loc[candidates.finding_key.eq(key)]
            heuristic_rows = bank.sort_values("heuristic_rank").head(3)
            learned_rows = learned.loc[learned.finding_key.eq(key)].sort_values(
                "learned_rank"
            )
            heuristic_canvas, heuristic_coverage, heuristic_safe = selected_canvas(
                gt.shape, heuristic_rows, case, finding_idx
            )
            learned_canvas, learned_coverage, learned_safe = selected_canvas(
                gt.shape, learned_rows, case, finding_idx
            )
            heuristic_zoom = heuristic_coverage & (
                heuristic_canvas > np.float16(FINAL_THRESHOLD)
            )
            learned_zoom = learned_coverage & (
                learned_canvas > np.float16(FINAL_THRESHOLD)
            )
            heuristic_max = base | heuristic_zoom
            learned_max = base | learned_zoom
            heuristic_added = heuristic_max & ~base
            learned_added = learned_max & ~base
            heuristic_only = heuristic_max & ~learned_max
            learned_only = learned_max & ~heuristic_max
            h_added_tp, h_added_fp = counts(heuristic_added, gt)
            l_added_tp, l_added_fp = counts(learned_added, gt)
            h_only_tp, h_only_fp = counts(heuristic_only, gt)
            l_only_tp, l_only_fp = counts(learned_only, gt)
            h_zoom_tp, h_zoom_fp = counts(heuristic_zoom, gt)
            l_zoom_tp, l_zoom_fp = counts(learned_zoom, gt)
            base_tp, base_fp = counts(base, gt)
            h_safe_gt = int(np.logical_and(heuristic_safe, gt).sum())
            l_safe_gt = int(np.logical_and(learned_safe, gt).sum())
            h_safe_zoom_tp = int(
                np.logical_and.reduce((heuristic_zoom, heuristic_safe, gt)).sum()
            )
            l_safe_zoom_tp = int(
                np.logical_and.reduce((learned_zoom, learned_safe, gt)).sum()
            )
            h_uids = set(heuristic_rows.candidate_uid.astype(str))
            l_uids = set(learned_rows.candidate_uid.astype(str))
            p = proposal_lookup.loc[key]
            d = downstream_lookup.loc[key]
            rows.append(
                {
                    "finding_key": key,
                    "file": case,
                    "finding_idx": finding_idx,
                    "size_bin": finding.size_bin,
                    "focality": finding.focality,
                    "baseline_hit": int(finding.baseline_hit),
                    "top3_set_changed": h_uids != l_uids,
                    "heuristic_top3_ge0p90": int(
                        p.heuristic_top3_safe_recall_90
                    ),
                    "learned_top3_ge0p90": int(p.learned_top3_safe_recall_90),
                    "proposal_rescue": int(
                        p.heuristic_top3_safe_recall_90 == 0
                        and p.learned_top3_safe_recall_90 == 1
                    ),
                    "proposal_loss": int(
                        p.heuristic_top3_safe_recall_90 == 1
                        and p.learned_top3_safe_recall_90 == 0
                    ),
                    "union_coverage_delta": float(
                        p.learned_top3_union_gt_coverage
                        - p.heuristic_top3_union_gt_coverage
                    ),
                    "dice_delta": float(d.learned_minus_heuristic_dice),
                    "gt_voxels": int(gt.sum()),
                    "base_tp": base_tp,
                    "base_fp": base_fp,
                    "heuristic_added_tp": h_added_tp,
                    "heuristic_added_fp": h_added_fp,
                    "learned_added_tp": l_added_tp,
                    "learned_added_fp": l_added_fp,
                    "learned_minus_heuristic_added_tp": l_added_tp - h_added_tp,
                    "learned_minus_heuristic_added_fp": l_added_fp - h_added_fp,
                    "heuristic_only_tp": h_only_tp,
                    "heuristic_only_fp": h_only_fp,
                    "learned_only_tp": l_only_tp,
                    "learned_only_fp": l_only_fp,
                    "heuristic_zoom_tp": h_zoom_tp,
                    "heuristic_zoom_fp": h_zoom_fp,
                    "learned_zoom_tp": l_zoom_tp,
                    "learned_zoom_fp": l_zoom_fp,
                    "heuristic_safe_gt_voxels": h_safe_gt,
                    "learned_safe_gt_voxels": l_safe_gt,
                    "heuristic_safe_region_zoom_recall": (
                        h_safe_zoom_tp / max(1, h_safe_gt)
                    ),
                    "learned_safe_region_zoom_recall": (
                        l_safe_zoom_tp / max(1, l_safe_gt)
                    ),
                }
            )
    frame = pd.DataFrame(rows)
    atomic_csv(frame, OUT / "coverage_vs_dice_voxel_diagnostic.csv")

    changed = frame.loc[frame.top3_set_changed]
    rescues = frame.loc[frame.proposal_rescue.eq(1)]
    baseline_miss = frame.loc[frame.baseline_hit.eq(0)]
    correlations = frame[
        [
            "union_coverage_delta",
            "learned_minus_heuristic_added_tp",
            "learned_minus_heuristic_added_fp",
            "dice_delta",
        ]
    ].corr(method="spearman")
    summary = {
        "findings": len(frame),
        "same_top3_set": int((~frame.top3_set_changed).sum()),
        "changed_top3_set": int(frame.top3_set_changed.sum()),
        "changed_set_improved_dice": int((changed.dice_delta > 1e-12).sum()),
        "changed_set_tied_dice": int((changed.dice_delta.abs() <= 1e-12).sum()),
        "changed_set_worsened_dice": int((changed.dice_delta < -1e-12).sum()),
        "proposal_rescues": len(rescues),
        "proposal_rescue_mean_dice_delta": float(rescues.dice_delta.mean()),
        "proposal_rescue_positive_dice_count": int(
            (rescues.dice_delta > 1e-12).sum()
        ),
        "proposal_rescue_nonpositive_dice_count": int(
            (rescues.dice_delta <= 1e-12).sum()
        ),
        "all_findings_added_voxels": {
            "heuristic_tp": int(frame.heuristic_added_tp.sum()),
            "heuristic_fp": int(frame.heuristic_added_fp.sum()),
            "learned_tp": int(frame.learned_added_tp.sum()),
            "learned_fp": int(frame.learned_added_fp.sum()),
            "learned_minus_heuristic_tp": int(
                frame.learned_minus_heuristic_added_tp.sum()
            ),
            "learned_minus_heuristic_fp": int(
                frame.learned_minus_heuristic_added_fp.sum()
            ),
        },
        "changed_findings_added_voxels": {
            "learned_minus_heuristic_tp": int(
                changed.learned_minus_heuristic_added_tp.sum()
            ),
            "learned_minus_heuristic_fp": int(
                changed.learned_minus_heuristic_added_fp.sum()
            ),
        },
        "baseline_miss_added_voxels": {
            "learned_minus_heuristic_tp": int(
                baseline_miss.learned_minus_heuristic_added_tp.sum()
            ),
            "learned_minus_heuristic_fp": int(
                baseline_miss.learned_minus_heuristic_added_fp.sum()
            ),
        },
        "mean_safe_region_zoom_recall": {
            "heuristic": float(frame.heuristic_safe_region_zoom_recall.mean()),
            "learned": float(frame.learned_safe_region_zoom_recall.mean()),
        },
        "spearman_correlations": {
            row: {
                column: float(correlations.loc[row, column])
                for column in correlations.columns
            }
            for row in correlations.index
        },
    }
    atomic_json(summary, OUT / "coverage_vs_dice_diagnostic_summary.json")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
