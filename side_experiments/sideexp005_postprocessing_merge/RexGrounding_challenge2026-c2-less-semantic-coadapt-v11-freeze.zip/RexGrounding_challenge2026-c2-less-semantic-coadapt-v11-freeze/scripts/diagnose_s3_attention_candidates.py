#!/usr/bin/env python3
"""Restart-safe S3 top-tail and low-threshold component diagnostics.

This diagnostic tests whether the high-AUROC 1/1 S3 map can recover lesion
support that is present in low-confidence segmentation candidates.  Each case
is committed independently, so rerunning a preempted Slurm job skips completed
cases.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy import ndimage


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))

from diagnose_spatial_attention_localization import (  # noqa: E402
    dice_score,
    load_rex_masks_in_preprocessed_ras,
)
from run_voxtell_rex_inference import (  # noqa: E402
    add_voxtell_to_path,
    load_entries,
    load_image,
    sorted_finding_keys,
    sorted_prompts,
)


COMPONENT_COLUMNS = [
    "case_id", "finding_idx", "category", "prompt", "baseline_dice",
    "candidate_threshold", "component_id", "component_size", "gt_voxels",
    "gt_overlap", "is_gt_component", "component_precision", "gt_recall",
    "seg_prob_mean", "seg_prob_max", "seg_prob_p90", "attention_mean",
    "attention_max", "attention_p90", "attention_global_contrast",
    "component_extent_x", "component_extent_y", "component_extent_z",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rex-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--mask-dir", type=Path, default=ROOT / "data/segmentations")
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--finding-metrics", type=Path, required=True)
    parser.add_argument("--category-gamma-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--voxtell-repo", type=Path, default=ROOT / "VoxTell")
    parser.add_argument("--focus-categories", nargs="+", default=["2b", "2c"])
    parser.add_argument("--candidate-thresholds", nargs="+", type=float, default=[0.05, 0.10, 0.20, 0.30, 0.40])
    parser.add_argument("--attention-top-fractions", nargs="+", type=float, default=[0.001, 0.005, 0.01, 0.05])
    parser.add_argument("--min-component-voxels", type=int, default=3)
    parser.add_argument("--attention-scale", default="1/1", choices=["1/4", "1/2", "1/1"])
    parser.add_argument("--splits", nargs="+", default=["val"])
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--gpu", type=int, default=None)
    parser.add_argument("--max-cases", type=int, default=0)
    parser.add_argument("--collect", action="store_true")
    return parser.parse_args()


def rank_info() -> tuple[int, int, int]:
    return (
        int(os.environ.get("RANK", "0")),
        int(os.environ.get("WORLD_SIZE", "1")),
        int(os.environ.get("LOCAL_RANK", "0")),
    )


def safe_case_name(name: str) -> str:
    return name.replace(".nii.gz", "").replace("/", "_")


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def atomic_json(payload: dict, path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True))
    temporary.replace(path)


def select_metrics(args: argparse.Namespace, entries: list[dict]) -> pd.DataFrame:
    available = {entry["name"] for entry in entries}
    metrics = pd.read_csv(args.finding_metrics)
    metrics = metrics.loc[
        metrics["file"].isin(available)
        & metrics["category"].astype(str).isin(set(args.focus_categories))
    ].copy()
    metrics = metrics.loc[
        metrics["file"].map(lambda value: (args.image_dir / value).exists())
        & metrics["file"].map(lambda value: (args.mask_dir / value).exists())
    ]
    metrics = metrics.sort_values(["file", "finding_idx"]).reset_index(drop=True)
    if args.max_cases > 0:
        keep = sorted(metrics["file"].unique())[: args.max_cases]
        metrics = metrics.loc[metrics["file"].isin(keep)].copy()
    if metrics.empty:
        raise RuntimeError("No focus-category findings are available")
    return metrics


def top_tail_rows(
    base: dict,
    attention: np.ndarray,
    target: np.ndarray,
    fractions: list[float],
) -> list[dict]:
    flat_attention = attention.reshape(-1)
    flat_target = target.reshape(-1)
    gt_voxels = int(flat_target.sum())
    rows = []
    for fraction in fractions:
        count = max(1, min(flat_attention.size, int(np.ceil(fraction * flat_attention.size))))
        indices = np.argpartition(flat_attention, flat_attention.size - count)[-count:]
        overlap = int(flat_target[indices].sum())
        threshold = float(flat_attention[indices].min())
        rows.append({
            **base,
            "attention_top_fraction": float(fraction),
            "attention_tail_threshold": threshold,
            "selected_voxels": count,
            "gt_voxels": gt_voxels,
            "gt_overlap": overlap,
            "attention_tail_precision": overlap / count,
            "attention_tail_gt_recall": overlap / gt_voxels,
            "attention_tail_dice": (2.0 * overlap) / (count + gt_voxels),
        })
    return rows


def component_rows(
    base: dict,
    probability: np.ndarray,
    attention: np.ndarray,
    target: np.ndarray,
    thresholds: list[float],
    min_component_voxels: int,
) -> tuple[list[dict], list[dict]]:
    rows: list[dict] = []
    summaries: list[dict] = []
    gt_voxels = int(target.sum())
    global_attention_mean = float(attention.mean())
    structure = ndimage.generate_binary_structure(3, 2)
    for threshold in thresholds:
        labels, component_count = ndimage.label(probability > threshold, structure=structure)
        kept_components: list[tuple[tuple[slice, slice, slice], np.ndarray, int]] = []
        for component_id, component_slice in enumerate(ndimage.find_objects(labels), start=1):
            if component_slice is None:
                continue
            local_labels = labels[component_slice]
            component = local_labels == component_id
            size = int(component.sum())
            if size < min_component_voxels:
                continue
            local_target = target[component_slice]
            overlap = int((component & local_target).sum())
            kept_components.append((component_slice, component, overlap))
            indices = np.where(component)
            probability_values = probability[component_slice][component]
            attention_values = attention[component_slice][component]
            rows.append({
                **base,
                "candidate_threshold": float(threshold),
                "component_id": int(component_id),
                "component_size": size,
                "gt_voxels": gt_voxels,
                "gt_overlap": overlap,
                "is_gt_component": int(overlap > 0),
                "component_precision": overlap / size,
                "gt_recall": overlap / gt_voxels,
                "seg_prob_mean": float(probability_values.mean()),
                "seg_prob_max": float(probability_values.max()),
                "seg_prob_p90": float(np.quantile(probability_values, 0.90)),
                "attention_mean": float(attention_values.mean()),
                "attention_max": float(attention_values.max()),
                "attention_p90": float(np.quantile(attention_values, 0.90)),
                "attention_global_contrast": float(attention_values.mean()) - global_attention_mean,
                "component_extent_x": int(indices[0].max() - indices[0].min() + 1),
                "component_extent_y": int(indices[1].max() - indices[1].min() + 1),
                "component_extent_z": int(indices[2].max() - indices[2].min() + 1),
            })
        oracle = np.zeros_like(target, dtype=bool)
        for component_slice, component, overlap in kept_components:
            if overlap > 0:
                oracle_view = oracle[component_slice]
                oracle_view |= component
        summaries.append({
            **base,
            "candidate_threshold": float(threshold),
            "candidate_components": len(kept_components),
            "gt_components": sum(overlap > 0 for _, _, overlap in kept_components),
            "candidate_voxel_recall": float(((probability > threshold) & target).sum()) / gt_voxels,
            "oracle_component_dice": dice_score(oracle, target),
            "oracle_component_hit": bool((oracle & target).any()),
        })
    return rows, summaries


def run_shard(args: argparse.Namespace) -> None:
    rank, world_size, local_rank = rank_info()
    entries = load_entries(args.rex_json, args.splits)
    entry_map = {entry["name"]: entry for entry in entries}
    metrics = select_metrics(args, entries)
    case_names = sorted(metrics["file"].unique())
    shard_cases = case_names[rank::world_size]
    shard_dir = args.output_dir / "cases" / f"shard_{rank:03d}"
    shard_dir.mkdir(parents=True, exist_ok=True)

    add_voxtell_to_path(args.voxtell_repo)
    from voxtell.inference.predictor import VoxTellPredictor

    gpu = local_rank if args.gpu is None else args.gpu
    device = torch.device(f"cuda:{gpu}" if args.device == "cuda" else args.device)
    predictor = VoxTellPredictor(str(args.model_dir), device=device)
    model = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    configured_scales = tuple(getattr(model, "s3_attention_scales", ()))
    if args.attention_scale not in configured_scales:
        raise RuntimeError(
            f"Requested {args.attention_scale} attention, checkpoint has {configured_scales}"
        )
    with args.category_gamma_json.open() as handle:
        category_gamma = {str(key): float(value) for key, value in json.load(handle).items()}

    for case_number, case_name in enumerate(shard_cases, start=1):
        stem = safe_case_name(case_name)
        done_path = shard_dir / f"{stem}.done.json"
        if done_path.exists():
            print(f"rank {rank}: [{case_number}/{len(shard_cases)}] skip {case_name}", flush=True)
            continue
        entry = entry_map[case_name]
        case_metrics = metrics.loc[metrics["file"] == case_name].sort_values("finding_idx")
        image, properties = load_image(args.image_dir / case_name)
        data, bbox, _ = predictor.preprocess(image)
        prompts = sorted_prompts(entry)
        finding_keys = sorted_finding_keys(entry)
        categories = [(entry.get("categories") or {}).get(key, "unknown") for key in finding_keys]
        target = load_rex_masks_in_preprocessed_ras(
            args.mask_dir / case_name, properties, len(prompts), bbox
        ).numpy().astype(bool)
        embeddings = predictor.embed_text_prompts(prompts)
        gate_scales = torch.tensor(
            [category_gamma.get(str(category), 1.0) for category in categories],
            dtype=torch.float32,
        )
        logits, attention_by_scale = predictor.predict_sliding_window_return_logits(
            data,
            embeddings,
            spatial_attention_rho_scale=gate_scales,
            return_spatial_attention_maps_by_scale=True,
        )
        probability = torch.sigmoid(logits.float()).cpu().numpy()
        attention = attention_by_scale[args.attention_scale].float().cpu().numpy()
        finding_rows: list[dict] = []
        components: list[dict] = []
        component_summaries: list[dict] = []
        tails: list[dict] = []
        for _, source in case_metrics.iterrows():
            index = int(source["finding_idx"])
            truth = target[index]
            if not truth.any():
                raise RuntimeError(f"{case_name}: finding {index} has empty preprocessed GT")
            baseline = dice_score(probability[index] > 0.5, truth)
            base = {
                "case_id": case_name,
                "finding_idx": index,
                "category": str(source["category"]),
                "prompt": str(source["prompt"]),
                "baseline_dice": baseline,
            }
            finding_rows.append(base)
            tails.extend(top_tail_rows(base, attention[index], truth, args.attention_top_fractions))
            detail, summary = component_rows(
                base,
                probability[index],
                attention[index],
                truth,
                args.candidate_thresholds,
                args.min_component_voxels,
            )
            components.extend(detail)
            component_summaries.extend(summary)

        atomic_csv(pd.DataFrame(finding_rows), shard_dir / f"{stem}.findings.csv")
        atomic_csv(pd.DataFrame(tails), shard_dir / f"{stem}.attention_tails.csv")
        atomic_csv(pd.DataFrame(components, columns=COMPONENT_COLUMNS), shard_dir / f"{stem}.components.csv")
        atomic_csv(pd.DataFrame(component_summaries), shard_dir / f"{stem}.component_summary.csv")
        atomic_json(
            {
                "case_id": case_name,
                "rank": rank,
                "findings": len(finding_rows),
                "components": len(components),
                "status": "complete",
            },
            done_path,
        )
        print(f"rank {rank}: [{case_number}/{len(shard_cases)}] done {case_name}", flush=True)
        del logits, attention_by_scale, probability, attention, embeddings
        if device.type == "cuda":
            torch.cuda.empty_cache()


def read_case_tables(output_dir: Path, suffix: str) -> pd.DataFrame:
    paths = sorted((output_dir / "cases").glob(f"shard_*/*.{suffix}.csv"))
    if not paths:
        raise RuntimeError(f"No completed case tables found for {suffix}")
    frames = [pd.read_csv(path) for path in paths if path.stat().st_size > 0]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def collect(args: argparse.Namespace) -> None:
    args.output_dir.mkdir(parents=True, exist_ok=True)
    findings = read_case_tables(args.output_dir, "findings").drop_duplicates(
        ["case_id", "finding_idx"]
    )
    tails = read_case_tables(args.output_dir, "attention_tails").drop_duplicates(
        ["case_id", "finding_idx", "attention_top_fraction"]
    )
    components = read_case_tables(args.output_dir, "components").drop_duplicates(
        ["case_id", "finding_idx", "candidate_threshold", "component_id"]
    )
    component_summary = read_case_tables(args.output_dir, "component_summary").drop_duplicates(
        ["case_id", "finding_idx", "candidate_threshold"]
    )
    atomic_csv(findings, args.output_dir / "findings.csv")
    atomic_csv(tails, args.output_dir / "attention_top_tail.csv")
    atomic_csv(components, args.output_dir / "candidate_components.csv")
    atomic_csv(component_summary, args.output_dir / "candidate_component_summary.csv")

    tail_summary = tails.groupby(["category", "attention_top_fraction"], as_index=False).agg(
        n=("baseline_dice", "size"),
        mean_baseline_dice=("baseline_dice", "mean"),
        median_attention_tail_gt_recall=("attention_tail_gt_recall", "median"),
        mean_attention_tail_gt_recall=("attention_tail_gt_recall", "mean"),
        median_attention_tail_precision=("attention_tail_precision", "median"),
        attention_tail_hit_rate=("gt_overlap", lambda values: float((values > 0).mean())),
    )
    component_rollup = component_summary.groupby(["category", "candidate_threshold"], as_index=False).agg(
        n=("baseline_dice", "size"),
        mean_baseline_dice=("baseline_dice", "mean"),
        mean_candidate_voxel_recall=("candidate_voxel_recall", "mean"),
        mean_oracle_component_dice=("oracle_component_dice", "mean"),
        oracle_component_hit_rate=("oracle_component_hit", "mean"),
        mean_candidate_components=("candidate_components", "mean"),
    )
    atomic_csv(tail_summary, args.output_dir / "attention_top_tail_summary.csv")
    atomic_csv(component_rollup, args.output_dir / "candidate_component_rollup.csv")
    report = [
        "# S3 Attention Candidate Diagnostic",
        "",
        f"Completed cases: {findings['case_id'].nunique()}; findings: {len(findings)}.",
        "",
        "The attention top-tail table measures how much GT is retained by fixed high-attention voxel budgets. "
        "The component table starts from low-threshold segmentation candidates; its oracle keeps exactly the "
        "connected components that overlap GT and therefore measures the maximum room available to a component rescorer.",
        "",
        "## Attention top-tail",
        "",
        tail_summary.to_csv(index=False),
        "",
        "## Low-threshold component oracle",
        "",
        component_rollup.to_csv(index=False),
    ]
    (args.output_dir / "report.md").write_text("\n".join(report))
    print(f"Wrote collected diagnostic to {args.output_dir}", flush=True)


def main() -> int:
    args = parse_args()
    if args.collect:
        collect(args)
    else:
        run_shard(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
