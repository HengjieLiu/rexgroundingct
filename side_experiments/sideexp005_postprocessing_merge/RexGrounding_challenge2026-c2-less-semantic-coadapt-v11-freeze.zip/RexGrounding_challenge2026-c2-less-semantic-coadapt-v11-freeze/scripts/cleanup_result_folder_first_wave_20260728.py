#!/usr/bin/env python3
"""Archive records and remove the approved first-wave result directories.

The cleanup scope is intentionally limited to:
  * empty or symlink-only wrapper directories;
  * top-level NIfTI result directories with completed >=190-case evaluation,
    best Dice/finding below 0.274, and no regular checkpoint;
  * five superseded smoke training runs;
  * seventeen explicitly closed experiment/artifact directories.

Run without --execute first. Execution requires an unchanged dry-run manifest.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path


EXPECTED_ROOT = Path(".")
OUTPUTS = EXPECTED_ROOT / "outputs"
ARCHIVE_PARENT = OUTPUTS / "archived_experiment_records" / "20260728"
ARCHIVE_ROOT = ARCHIVE_PARENT / "result_folder_first_wave"
STAGING_ROOT = ARCHIVE_PARENT / ".result_folder_first_wave_staging"
MANIFEST = ARCHIVE_PARENT / "result_folder_first_wave_manifest.json"
EXECUTION = ARCHIVE_PARENT / "result_folder_first_wave_execution.json"

FULL_CASE_MIN = 190
DICE_CUTOFF = 0.274
EXPECTED_PREDICTION_DIRS = 118

DIRECT_DIRS = [
    "H-S1_beta1p5_step1000_inference_model",
    "H-S1_beta1p5_step400_inference_model",
    "H-S1_beta1p5_step600_inference_model",
    "anatomy_prior_ablation_val_hardneg_step1000_thr0p7_smoke",
    "anatomy_prior_diagnostic_gtbucket_sanity5",
    "coarse_to_fine_debug",
    "dvsm_tie_probe_frozen_round1_smoke",
    "eval_models",
    "failed_sanity_anchor85_hardneg70_hybrid75_dp_job5246680",
    "presence_v2_step1500_inference_model",
    "presence_v2_step600_inference_model",
    "uf_lr4_step1500_inference_model",
    "ufb10_step3000_inference_model",
    "voxtell_mask_prompt_cycle_lam005_20260723_aborted_5265593",
    "voxtell_rex_anchor85_loss_focal_tversky_step3000_model",
    "voxtell_rex_anchor85_loss_unified_focal_step3000_model",
    "voxtell_rex_finetune_phase1_ddp_step125_model",
    "voxtell_rex_finetune_phase1_orifix_full_step50_model",
]

SMOKE_DIRS = [
    "smoke_s3_1over1_allcat_v11_single_gpu_acc4_3upd_20260727",
    "smoke_voxtell_v11_single_gpu_acc4_3upd_20260727",
    "prompt_standardization_smoke_E0_50steps_1l40s",
    "prompt_standardization_smoke_E0_50steps_1l40s_v1_2",
    "prompt_standardization_smoke_E3a_75steps_1l40s_v1_2",
]

CLOSED_DIRS = [
    "p0b_prompt_conditioned_proposal_head",
    "crop_offset_audit",
    "tta_frozen_teacher_consistency_30case",
    "prompt_residual_adapter_s3_allcategory_1over1_frozen",
    "prompt_residual_adapter_s3_multiscale_2b2c_frozen",
    "colipri_dual_preprocess_residual",
    "single_s3_adaptive_rho_BCD",
    "single_s3_adaptive_rho_policy_audit",
    "category_adaptive_tversky_threshold_sweep_subset30",
    "category_adaptive_tversky_subset30",
    "l1_l2_loss_subset30",
    "l3_category_focal_tversky_subset30",
    "prompt_residual_adapter_s3_early_checkpoint_diagnostic",
    "prompt_residual_adapter_normal_voxtell_step3800_pilot",
    "category_embedding_normal_voxtell_step3800_pilot",
    "prompt_residual_adapter_mechanism_analysis",
    "s3_per_scale_control_step6000",
]

PROTECTED_TOP_DIRS = {
    "archived_experiment_records",
    "azure_ckpt_sync_stage",
    "anatomy_prior_diagnostic_val_hardneg_step1000_thr0p7",
    "totalseg_level1_train_v1",
    "voxtell_lobe_input_from_allcat1over1_step6000",
    "voxtell_rex_miccai_val",
    "voxtell_v11_e1e-5_d1e-4_1gpu_bs1_acc4_10kupd",
    "s3_1over1_allcat_v11_e1e-5_d1e-4_s3e1e-4_1gpu_bs1_acc4_10kupd",
    "zoom_out_256_matched",
    "s3d_matched_continue_from_weakdiffuse_control_step1000",
    "s3_diffuse_coverage_tv_matched_from_s3d_step400",
    "s3d_multiscale_2b2c_train_nowrong_from_adaptive_step600",
    "s3_selective_categories_matched_from_control_step6000_2h100",
    "anchor85_hardneg70_no_topk",
    "loss_adaptive_cat_tversky_short",
    "voxtell_rex_full_preprocessed_from_lr1e6_step2000_nnunet_aug_lr1e6_3000steps",
    "voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500",
    "voxtell_rex_hard_negative_triplet_preprocessed_4l40s_to4000",
    "voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000",
    "voxtell_rex_patch_presence_hardneg_from_baseline_4l40s_2000steps",
    "dual_s3_multifov",
    "dual_s3_two_stage_zoom96",
    "dual_s3_two_stage_zoom96_bounded_update2000",
    "dual_s3_postzoom_routing",
    "prompt_standardization_rule_only_v1",
    "prompt_residual_adapter_best_s3_frozen",
}

RECORD_SUFFIXES = {
    ".json",
    ".jsonl",
    ".csv",
    ".tsv",
    ".md",
    ".txt",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".cfg",
    ".log",
    ".out",
    ".err",
}
CHECKPOINT_SUFFIXES = {".pth", ".pt", ".ckpt"}

TOTAL_CASES_RE = re.compile(rb'"total_cases"\s*:\s*(\d+)')
DICE_RE = re.compile(
    rb'"mean_global_dice_per_finding"\s*:\s*([0-9.eE+-]+)'
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(
        dir=path.parent, prefix=f".{path.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(fd, "w") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def is_within(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def assert_safe_top(path: Path) -> None:
    if path.parent != OUTPUTS:
        raise RuntimeError(f"cleanup target is not an outputs top directory: {path}")
    if path.name in PROTECTED_TOP_DIRS:
        raise RuntimeError(f"protected directory selected: {path}")
    if path in {OUTPUTS, EXPECTED_ROOT, ARCHIVE_ROOT, STAGING_ROOT}:
        raise RuntimeError(f"unsafe cleanup target: {path}")


def metric_summary(path: Path) -> tuple[int, float] | None:
    try:
        with path.open("rb") as handle:
            prefix = handle.read(8192)
    except OSError:
        return None
    total_match = TOTAL_CASES_RE.search(prefix)
    dice_match = DICE_RE.search(prefix)
    if not total_match or not dice_match:
        return None
    return int(total_match.group(1)), float(dice_match.group(1))


def scan_tree(path: Path) -> dict:
    digest = hashlib.sha256()
    file_count = 0
    symlink_count = 0
    bytes_total = 0
    allocated_bytes = 0
    nii_count = 0
    nii_bytes = 0
    checkpoint_count = 0
    checkpoint_bytes = 0
    record_count = 0
    record_bytes = 0
    full_metrics: list[dict] = []
    record_paths: list[str] = []

    for directory, dirnames, filenames in os.walk(path, followlinks=False):
        dirnames.sort()
        filenames.sort()
        directory_path = Path(directory)
        for name in [*dirnames, *filenames]:
            item = directory_path / name
            relative = item.relative_to(path)
            if item.is_symlink():
                target = os.readlink(item)
                digest.update(
                    f"L\0{relative}\0{target}\n".encode("utf-8", errors="surrogateescape")
                )
                symlink_count += 1
                continue
            if not item.is_file():
                continue
            stat = item.stat()
            digest.update(
                f"F\0{relative}\0{stat.st_size}\0{stat.st_mtime_ns}\n".encode(
                    "utf-8", errors="surrogateescape"
                )
            )
            file_count += 1
            bytes_total += stat.st_size
            allocated_bytes += stat.st_blocks * 512
            lowered = name.lower()
            if lowered.endswith(".nii.gz"):
                nii_count += 1
                nii_bytes += stat.st_size
            if item.suffix.lower() in CHECKPOINT_SUFFIXES:
                checkpoint_count += 1
                checkpoint_bytes += stat.st_size
            if item.suffix.lower() in RECORD_SUFFIXES:
                record_count += 1
                record_bytes += stat.st_size
                record_paths.append(str(relative))
            if name == "eval_rexrank_metrics_global.json":
                summary = metric_summary(item)
                if summary is not None and summary[0] >= FULL_CASE_MIN:
                    full_metrics.append(
                        {
                            "path": str(relative),
                            "total_cases": summary[0],
                            "dice_per_finding": summary[1],
                        }
                    )

    return {
        "file_count": file_count,
        "symlink_count": symlink_count,
        "bytes": bytes_total,
        "allocated_bytes": allocated_bytes,
        "nii_count": nii_count,
        "nii_bytes": nii_bytes,
        "checkpoint_count": checkpoint_count,
        "checkpoint_bytes": checkpoint_bytes,
        "record_count": record_count,
        "record_bytes": record_bytes,
        "record_paths": record_paths,
        "full_metrics": full_metrics,
        "snapshot_sha256": digest.hexdigest(),
    }


def prediction_candidates() -> tuple[list[str], dict[str, dict]]:
    candidates = []
    scans: dict[str, dict] = {}
    excluded = set(DIRECT_DIRS) | set(SMOKE_DIRS) | set(CLOSED_DIRS)
    for path in sorted(OUTPUTS.iterdir(), key=lambda item: item.name):
        if (
            not path.is_dir()
            or path.is_symlink()
            or path.name in PROTECTED_TOP_DIRS
            or path.name in excluded
        ):
            continue
        scan = scan_tree(path)
        if (
            scan["nii_count"] > 0
            and scan["checkpoint_count"] == 0
            and scan["full_metrics"]
            and max(
                item["dice_per_finding"] for item in scan["full_metrics"]
            )
            < DICE_CUTOFF
        ):
            candidates.append(path.name)
            scans[path.name] = scan
    if len(candidates) != EXPECTED_PREDICTION_DIRS:
        raise RuntimeError(
            "prediction candidate count changed: "
            f"expected {EXPECTED_PREDICTION_DIRS}, found {len(candidates)}"
        )
    return candidates, scans


def current_jobs() -> list[dict]:
    result = subprocess.run(
        ["squeue", "-u", os.environ.get("USER", ""), "-h", "-o", "%i|%T|%j"],
        check=True,
        text=True,
        capture_output=True,
    )
    jobs = []
    for line in result.stdout.splitlines():
        if not line:
            continue
        job_id, state, name = line.split("|", 2)
        jobs.append({"job_id": job_id, "state": state, "name": name})
    return jobs


def external_inbound_links(candidate_names: set[str]) -> list[dict]:
    candidate_roots = [(OUTPUTS / name).resolve() for name in candidate_names]
    links = []
    for directory, dirnames, filenames in os.walk(OUTPUTS, followlinks=False):
        for name in [*dirnames, *filenames]:
            path = Path(directory) / name
            if not path.is_symlink():
                continue
            source_top = path.relative_to(OUTPUTS).parts[0]
            if source_top in candidate_names:
                continue
            target = path.resolve(strict=False)
            for root in candidate_roots:
                if target == root or is_within(target, root):
                    links.append(
                        {
                            "source": str(path.relative_to(EXPECTED_ROOT)),
                            "target": str(target.relative_to(EXPECTED_ROOT)),
                        }
                    )
                    break
    return sorted(links, key=lambda item: item["source"])


def build_state() -> dict:
    if Path.cwd().resolve() != EXPECTED_ROOT:
        raise RuntimeError(f"must run from {EXPECTED_ROOT}, got {Path.cwd().resolve()}")

    prediction_dirs, scans = prediction_candidates()
    groups = {
        "direct": DIRECT_DIRS,
        "historical_predictions": prediction_dirs,
        "superseded_smoke": SMOKE_DIRS,
        "closed_negative_experiments": CLOSED_DIRS,
    }
    flat = [name for names in groups.values() for name in names]
    if len(flat) != len(set(flat)):
        raise RuntimeError("cleanup groups overlap")
    if len(flat) != 158:
        raise RuntimeError(f"expected 158 total targets, found {len(flat)}")

    directories = {}
    for group, names in groups.items():
        for name in names:
            path = OUTPUTS / name
            assert_safe_top(path)
            if not path.is_dir() or path.is_symlink():
                raise RuntimeError(f"target missing or not a real directory: {path}")
            scan = scans.get(name) or scan_tree(path)
            if group == "direct" and scan["file_count"] != 0:
                raise RuntimeError(f"direct target has regular files: {path}")
            directories[name] = {"group": group, **scan}

    inbound = external_inbound_links(set(flat))
    if inbound:
        formatted = "\n".join(
            f"{item['source']} -> {item['target']}" for item in inbound
        )
        raise RuntimeError(f"external inbound symlinks block cleanup:\n{formatted}")

    totals = {}
    for group, names in groups.items():
        totals[group] = {
            "directory_count": len(names),
            "file_count": sum(directories[name]["file_count"] for name in names),
            "symlink_count": sum(
                directories[name]["symlink_count"] for name in names
            ),
            "bytes": sum(directories[name]["bytes"] for name in names),
            "allocated_bytes": sum(
                directories[name]["allocated_bytes"] for name in names
            ),
            "record_count": sum(
                directories[name]["record_count"] for name in names
            ),
            "record_bytes": sum(
                directories[name]["record_bytes"] for name in names
            ),
        }
    totals["all"] = {
        key: sum(totals[group][key] for group in groups)
        for key in [
            "directory_count",
            "file_count",
            "symlink_count",
            "bytes",
            "allocated_bytes",
            "record_count",
            "record_bytes",
        ]
    }
    return {
        "schema_version": 1,
        "created_at": utc_now(),
        "workspace": str(EXPECTED_ROOT),
        "archive_root": str(ARCHIVE_ROOT.relative_to(EXPECTED_ROOT)),
        "criteria": {
            "full_case_min": FULL_CASE_MIN,
            "dice_cutoff": DICE_CUTOFF,
            "expected_prediction_dirs": EXPECTED_PREDICTION_DIRS,
        },
        "groups": groups,
        "directories": directories,
        "totals": totals,
        "external_inbound_links": inbound,
        "current_jobs": current_jobs(),
    }


def stable_payload(state: dict) -> dict:
    return {
        "schema_version": state["schema_version"],
        "workspace": state["workspace"],
        "archive_root": state["archive_root"],
        "criteria": state["criteria"],
        "groups": state["groups"],
        "directories": state["directories"],
        "totals": state["totals"],
        "external_inbound_links": state["external_inbound_links"],
    }


def copy_records(state: dict) -> dict:
    if ARCHIVE_ROOT.exists():
        raise RuntimeError(f"final archive already exists: {ARCHIVE_ROOT}")
    if STAGING_ROOT.exists():
        raise RuntimeError(f"staging archive already exists: {STAGING_ROOT}")
    STAGING_ROOT.mkdir(parents=True)

    copied_count = 0
    copied_bytes = 0
    try:
        for name, entry in sorted(state["directories"].items()):
            if entry["group"] == "direct":
                continue
            source_root = OUTPUTS / name
            destination_root = STAGING_ROOT / entry["group"] / name
            for relative_text in entry["record_paths"]:
                relative = Path(relative_text)
                source = source_root / relative
                destination = destination_root / relative
                if source.is_symlink() or not source.is_file():
                    raise RuntimeError(f"record changed before archive: {source}")
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
                if source.stat().st_size != destination.stat().st_size:
                    raise RuntimeError(f"archive size mismatch: {source}")
                copied_count += 1
                copied_bytes += source.stat().st_size

        expected_count = state["totals"]["all"]["record_count"]
        expected_bytes = state["totals"]["all"]["record_bytes"]
        if copied_count != expected_count or copied_bytes != expected_bytes:
            raise RuntimeError(
                "archive totals mismatch: "
                f"copied {copied_count}/{copied_bytes}, "
                f"expected {expected_count}/{expected_bytes}"
            )
        index = {
            "created_at": utc_now(),
            "source_workspace": str(EXPECTED_ROOT),
            "record_count": copied_count,
            "record_bytes": copied_bytes,
            "groups": state["groups"],
        }
        atomic_json(STAGING_ROOT / "archive_index.json", index)
        os.replace(STAGING_ROOT, ARCHIVE_ROOT)
    except Exception:
        if STAGING_ROOT.exists():
            shutil.rmtree(STAGING_ROOT)
        raise
    return {"record_count": copied_count, "record_bytes": copied_bytes}


def execute(state: dict) -> dict:
    if not MANIFEST.is_file():
        raise RuntimeError(f"dry-run manifest is missing: {MANIFEST}")
    with MANIFEST.open() as handle:
        prior = json.load(handle)
    if stable_payload(prior) != stable_payload(state):
        raise RuntimeError("current state differs from dry-run manifest; rerun dry-run")

    archive = copy_records(state)
    deleted = []
    errors = []
    for group, names in state["groups"].items():
        for name in names:
            path = OUTPUTS / name
            assert_safe_top(path)
            try:
                shutil.rmtree(path)
                deleted.append(
                    {
                        "group": group,
                        "name": name,
                        "bytes": state["directories"][name]["bytes"],
                        "file_count": state["directories"][name]["file_count"],
                    }
                )
            except Exception as error:
                errors.append({"group": group, "name": name, "error": repr(error)})
                break
        if errors:
            break

    remaining = [
        name
        for names in state["groups"].values()
        for name in names
        if (OUTPUTS / name).exists() or (OUTPUTS / name).is_symlink()
    ]
    result = {
        "executed_at": utc_now(),
        "archive": archive,
        "deleted": deleted,
        "errors": errors,
        "remaining_targets": remaining,
        "current_jobs_after": current_jobs(),
    }
    atomic_json(EXECUTION, result)
    if errors or remaining:
        raise RuntimeError(
            f"cleanup incomplete: errors={len(errors)}, remaining={len(remaining)}"
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--execute",
        action="store_true",
        help="archive records and delete the manifest-approved directories",
    )
    args = parser.parse_args()

    state = build_state()
    if args.execute:
        result = execute(state)
        print(
            "EXECUTED "
            f"dirs={len(result['deleted'])} "
            f"bytes={sum(item['bytes'] for item in result['deleted'])} "
            f"archived_records={result['archive']['record_count']}"
        )
    else:
        atomic_json(MANIFEST, state)
        totals = state["totals"]["all"]
        print(
            "DRY_RUN "
            f"dirs={totals['directory_count']} "
            f"files={totals['file_count']} "
            f"bytes={totals['bytes']} "
            f"allocated_bytes={totals['allocated_bytes']} "
            f"records={totals['record_count']} "
            f"record_bytes={totals['record_bytes']}"
        )
        for group, summary in state["totals"].items():
            if group == "all":
                continue
            print(
                f"{group} "
                f"dirs={summary['directory_count']} "
                f"bytes={summary['bytes']} "
                f"records={summary['record_count']}"
            )


if __name__ == "__main__":
    main()
