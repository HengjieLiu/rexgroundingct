#!/usr/bin/env python3
"""Analyze paired B/C strict/current results and write the final policy audit."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


TIE_TOLERANCE = 1e-9
BOOTSTRAP_SEED = 20260723
BOOTSTRAP_SAMPLES = 10_000


def load_rows(path: Path) -> dict[tuple[str, int], dict]:
    result = {}
    with path.open(newline="") as handle:
        for row in csv.DictReader(handle):
            item = dict(row)
            for field in (
                "global_dice",
                "pixels",
                "tp_voxels",
                "fp_voxels",
                "fn_voxels",
                "pred_voxels",
                "gt_voxels",
                "voxel_volume_mm3",
            ):
                item[field] = float(item[field])
            item["global_hit"] = str(item["global_hit"]).lower() == "true"
            key = (str(item["file"]), int(item["finding_idx"]))
            result[key] = item
    return result


def describe(values: np.ndarray) -> dict:
    return {
        "n": int(values.size),
        "mean": float(values.mean()) if values.size else None,
        "median": float(np.median(values)) if values.size else None,
        "min": float(values.min()) if values.size else None,
        "max": float(values.max()) if values.size else None,
    }


def bootstrap_by_case(records: list[dict]) -> dict:
    grouped: dict[str, list[float]] = defaultdict(list)
    for record in records:
        grouped[record["file"]].append(record["delta"])
    cases = sorted(grouped)
    sums = np.asarray([sum(grouped[case]) for case in cases], dtype=np.float64)
    counts = np.asarray([len(grouped[case]) for case in cases], dtype=np.float64)
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    sampled = rng.integers(0, len(cases), size=(BOOTSTRAP_SAMPLES, len(cases)))
    means = sums[sampled].sum(axis=1) / counts[sampled].sum(axis=1)
    return {
        "unit": "case_cluster",
        "seed": BOOTSTRAP_SEED,
        "samples": BOOTSTRAP_SAMPLES,
        "case_count": len(cases),
        "ci95": [
            float(np.quantile(means, 0.025)),
            float(np.quantile(means, 0.975)),
        ],
        "bootstrap_mean": float(means.mean()),
    }


def size_group(pixels: float) -> str:
    if pixels < 100:
        return "tiny_lt100"
    if pixels < 1_000:
        return "small_100_999"
    if pixels < 10_000:
        return "medium_1k_9999"
    return "large_ge10k"


def compare(label: str, reference_path: Path, candidate_path: Path) -> tuple[dict, list[dict]]:
    reference = load_rows(reference_path)
    candidate = load_rows(candidate_path)
    if set(reference) != set(candidate):
        raise AssertionError(
            f"{label}: finding sets differ: reference={len(reference)}, "
            f"candidate={len(candidate)}"
        )
    records = []
    for key in sorted(reference):
        base = reference[key]
        new = candidate[key]
        if base["category"] != new["category"]:
            raise AssertionError(f"{label}: category mismatch for {key}")
        delta = new["global_dice"] - base["global_dice"]
        records.append(
            {
                "comparison": label,
                "file": key[0],
                "finding_idx": key[1],
                "category": base["category"],
                "pixels": base["pixels"],
                "size_group": size_group(base["pixels"]),
                "prompt": base["prompt"],
                "reference_dice": base["global_dice"],
                "candidate_dice": new["global_dice"],
                "delta": delta,
                "reference_hit": base["global_hit"],
                "candidate_hit": new["global_hit"],
                "reference_pred_voxels": base["pred_voxels"],
                "candidate_pred_voxels": new["pred_voxels"],
            }
        )

    deltas = np.asarray([record["delta"] for record in records])
    improved = deltas > TIE_TOLERANCE
    degraded = deltas < -TIE_TOLERANCE
    tied = ~(improved | degraded)
    ordered = sorted(records, key=lambda record: record["delta"], reverse=True)
    positive = [record for record in ordered if record["delta"] > TIE_TOLERANCE]
    total_delta = float(deltas.sum())
    sensitivity = {}
    for count in (1, 3, 5):
        removed = positive[:count]
        kept = positive[count:] + [
            record for record in records if record["delta"] <= TIE_TOLERANCE
        ]
        removed_sum = float(sum(record["delta"] for record in removed))
        sensitivity[f"top_{count}"] = {
            "removed_positive_delta_sum": removed_sum,
            "contribution_to_overall_mean_delta": removed_sum / len(records),
            "fraction_of_total_delta_sum": (
                None if abs(total_delta) < 1e-15 else removed_sum / total_delta
            ),
            "mean_delta_after_removal": float(
                np.mean([record["delta"] for record in kept])
            ),
        }

    by_case: dict[str, list[float]] = defaultdict(list)
    for record in records:
        by_case[record["file"]].append(record["delta"])
    leave_one_out = []
    for case in sorted(by_case):
        remaining_sum = total_delta - sum(by_case[case])
        remaining_n = len(records) - len(by_case[case])
        leave_one_out.append(remaining_sum / remaining_n)

    group_stats = {}
    for group, selector in {
        "2b": lambda record: record["category"] == "2b",
        "2c": lambda record: record["category"] == "2c",
        "non_2b2c": lambda record: record["category"] not in {"2b", "2c"},
    }.items():
        values = np.asarray(
            [record["delta"] for record in records if selector(record)],
            dtype=np.float64,
        )
        group_stats[group] = describe(values)
        group_stats[group]["findings_with_nonzero_dice_difference"] = int(
            np.sum(np.abs(values) > TIE_TOLERANCE)
        )

    by_category = {}
    for category in sorted({record["category"] for record in records}):
        selected = [record for record in records if record["category"] == category]
        by_category[category] = {
            "n": len(selected),
            "reference_mean_dice": float(
                np.mean([record["reference_dice"] for record in selected])
            ),
            "candidate_mean_dice": float(
                np.mean([record["candidate_dice"] for record in selected])
            ),
            "mean_delta": float(np.mean([record["delta"] for record in selected])),
        }
    by_size = {}
    for group in ("tiny_lt100", "small_100_999", "medium_1k_9999", "large_ge10k"):
        selected = [record for record in records if record["size_group"] == group]
        by_size[group] = {
            "n": len(selected),
            "reference_mean_dice": float(
                np.mean([record["reference_dice"] for record in selected])
            ),
            "candidate_mean_dice": float(
                np.mean([record["candidate_dice"] for record in selected])
            ),
            "mean_delta": float(np.mean([record["delta"] for record in selected])),
        }

    summary = {
        "comparison": label,
        "reference_csv": str(reference_path.resolve()),
        "candidate_csv": str(candidate_path.resolve()),
        "tie_tolerance": TIE_TOLERANCE,
        "finding_count": len(records),
        "case_count": len(by_case),
        "reference_mean_dice": float(
            np.mean([record["reference_dice"] for record in records])
        ),
        "candidate_mean_dice": float(
            np.mean([record["candidate_dice"] for record in records])
        ),
        "mean_delta": float(deltas.mean()),
        "median_delta": float(np.median(deltas)),
        "improved": int(improved.sum()),
        "degraded": int(degraded.sum()),
        "tied": int(tied.sum()),
        "new_hits": int(
            sum(not record["reference_hit"] and record["candidate_hit"] for record in records)
        ),
        "lost_hits": int(
            sum(record["reference_hit"] and not record["candidate_hit"] for record in records)
        ),
        "reference_hits": int(sum(record["reference_hit"] for record in records)),
        "candidate_hits": int(sum(record["candidate_hit"] for record in records)),
        "reference_empty_predictions": int(
            sum(record["reference_pred_voxels"] == 0 for record in records)
        ),
        "candidate_empty_predictions": int(
            sum(record["candidate_pred_voxels"] == 0 for record in records)
        ),
        "reference_mean_predicted_voxels": float(
            np.mean([record["reference_pred_voxels"] for record in records])
        ),
        "candidate_mean_predicted_voxels": float(
            np.mean([record["candidate_pred_voxels"] for record in records])
        ),
        "case_bootstrap": bootstrap_by_case(records),
        "leave_one_case_out_mean_delta_range": [
            float(min(leave_one_out)),
            float(max(leave_one_out)),
        ],
        "top_positive_sensitivity": sensitivity,
        "paired_groups": group_stats,
        "by_category": by_category,
        "by_gt_size": by_size,
        "top_10_positive": positive[:10],
        "top_10_negative": list(reversed(ordered[-10:])),
        "component_count": "not supported by the existing evaluator",
    }
    return summary, records


def fmt(value: float | None, digits: int = 6) -> str:
    return "n/a" if value is None else f"{value:.{digits}f}"


def fmt_hits(row: dict, prefix: str) -> str:
    hits = row[f"{prefix}_hits"]
    findings = row[f"{prefix}_findings"]
    return "n/a" if hits is None else f"{hits}/{findings}"


def fmt_signed(value: float | None) -> str:
    return "n/a" if value is None else f"{value:+.6f}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--audit-dir",
        type=Path,
        default=Path("outputs/single_s3_adaptive_rho_policy_audit"),
    )
    parser.add_argument(
        "--existing-dir",
        type=Path,
        default=Path("outputs/single_s3_adaptive_rho_BCD"),
    )
    parser.add_argument("--job-id", default="5260908")
    parser.add_argument("--initial-job-id", default="5260908")
    args = parser.parse_args()
    audit = args.audit_dir
    existing = args.existing_dir

    baseline_full = existing / "full_eval/baseline/per_finding_metrics.csv"
    baseline_subset = existing / "preflight/fast_eval/baseline/per_finding_metrics.csv"
    specs = [
        ("full_C_current_vs_baseline", baseline_full, existing / "full_eval/C_update_300/per_finding_metrics.csv"),
        ("full_C_strict_vs_baseline", baseline_full, audit / "full_eval/C_strict/per_finding_metrics.csv"),
        ("full_C_strict_vs_C_current", existing / "full_eval/C_update_300/per_finding_metrics.csv", audit / "full_eval/C_strict/per_finding_metrics.csv"),
        ("full_B_current_vs_baseline", baseline_full, audit / "full_eval/B_current/per_finding_metrics.csv"),
        ("full_B_strict_vs_baseline", baseline_full, audit / "full_eval/B_strict/per_finding_metrics.csv"),
        ("full_B_strict_vs_B_current", audit / "full_eval/B_current/per_finding_metrics.csv", audit / "full_eval/B_strict/per_finding_metrics.csv"),
        ("subset_C_current_vs_baseline", baseline_subset, existing / "C/fast_eval/update_300/per_finding_metrics.csv"),
        ("subset_C_strict_vs_baseline", baseline_subset, audit / "subset_eval/C_strict/per_finding_metrics.csv"),
        ("subset_C_strict_vs_C_current", existing / "C/fast_eval/update_300/per_finding_metrics.csv", audit / "subset_eval/C_strict/per_finding_metrics.csv"),
        ("subset_B_current_vs_baseline", baseline_subset, existing / "B/fast_eval/update_150/per_finding_metrics.csv"),
        ("subset_B_strict_vs_baseline", baseline_subset, audit / "subset_eval/B_strict/per_finding_metrics.csv"),
        ("subset_B_strict_vs_B_current", existing / "B/fast_eval/update_150/per_finding_metrics.csv", audit / "subset_eval/B_strict/per_finding_metrics.csv"),
    ]
    summaries = {}
    all_records = []
    outlier_dir = audit / "paired_outliers"
    outlier_dir.mkdir(parents=True, exist_ok=True)
    for label, reference, candidate in specs:
        summary, records = compare(label, reference, candidate)
        summaries[label] = summary
        all_records.extend(records)
        fields = list(records[0])
        for suffix, selected in (
            ("top10_positive", summary["top_10_positive"]),
            ("top10_negative", summary["top_10_negative"]),
        ):
            with (outlier_dir / f"{label}_{suffix}.csv").open("w", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                writer.writerows(selected)

    (audit / "paired_comparison_summary.json").write_text(
        json.dumps(summaries, indent=2) + "\n"
    )
    flat_fields = [
        "comparison", "finding_count", "case_count", "reference_mean_dice",
        "candidate_mean_dice", "mean_delta", "median_delta", "improved",
        "degraded", "tied", "new_hits", "lost_hits", "reference_hits",
        "candidate_hits", "reference_empty_predictions",
        "candidate_empty_predictions", "reference_mean_predicted_voxels",
        "candidate_mean_predicted_voxels", "bootstrap_ci_low", "bootstrap_ci_high",
        "loo_low", "loo_high",
    ]
    with (audit / "paired_comparison_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=flat_fields)
        writer.writeheader()
        for summary in summaries.values():
            writer.writerow(
                {
                    **{field: summary.get(field) for field in flat_fields},
                    "bootstrap_ci_low": summary["case_bootstrap"]["ci95"][0],
                    "bootstrap_ci_high": summary["case_bootstrap"]["ci95"][1],
                    "loo_low": summary["leave_one_case_out_mean_delta_range"][0],
                    "loo_high": summary["leave_one_case_out_mean_delta_range"][1],
                }
            )
    with (audit / "paired_finding_deltas.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(all_records[0]))
        writer.writeheader()
        writer.writerows(all_records)

    methods = [
        ("Fixed single-S3", "baseline", "fixed baseline predictions", None, None),
        ("B update 150 current", "B150", "all-category learned scalar rho", "subset_B_current_vs_baseline", "full_B_current_vs_baseline"),
        ("B update 150 strict", "B150", "adaptive only for 2b/2c; baseline otherwise", "subset_B_strict_vs_baseline", "full_B_strict_vs_baseline"),
        ("C update 300 current", "C300", "all-category learned channel rho", "subset_C_current_vs_baseline", "full_C_current_vs_baseline"),
        ("C update 300 strict", "C300", "adaptive only for 2b/2c; baseline otherwise", "subset_C_strict_vs_baseline", "full_C_strict_vs_baseline"),
        ("D update 0", "duplicate of C300", "alpha=1 identity", None, None),
        ("D update 300", "D300", "adaptive alpha current", None, None),
    ]
    baseline_full_summary = json.loads((existing / "full_eval/baseline/summary.json").read_text())
    baseline_subset_summary = json.loads((existing / "preflight/fast_eval/baseline/summary.json").read_text())
    table_rows = []
    for method, checkpoint, policy, subset_key, full_key in methods:
        subset = summaries.get(subset_key) if subset_key else None
        full = summaries.get(full_key) if full_key else None
        table_rows.append(
            {
                "method": method,
                "checkpoint": checkpoint,
                "category_policy": policy,
                "subset_dice": (
                    baseline_subset_summary["mean_global_dice_per_finding"]
                    if method == "Fixed single-S3"
                    else None if subset is None else subset["candidate_mean_dice"]
                ),
                "subset_hits": (
                    baseline_subset_summary["total_hits"]
                    if method == "Fixed single-S3"
                    else None if subset is None else subset["candidate_hits"]
                ),
                "subset_findings": (
                    baseline_subset_summary["total_findings"]
                    if method == "Fixed single-S3"
                    else None if subset is None else subset["finding_count"]
                ),
                "full_dice": (
                    baseline_full_summary["mean_global_dice_per_finding"]
                    if method == "Fixed single-S3"
                    else None if full is None else full["candidate_mean_dice"]
                ),
                "full_hits": (
                    baseline_full_summary["total_hits"]
                    if method == "Fixed single-S3"
                    else None if full is None else full["candidate_hits"]
                ),
                "full_findings": (
                    baseline_full_summary["total_findings"]
                    if method == "Fixed single-S3"
                    else None if full is None else full["finding_count"]
                ),
                "delta_vs_baseline": None if full is None else full["mean_delta"],
            }
        )
    with (audit / "final_comparison_table.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(table_rows[0]))
        writer.writeheader()
        writer.writerows(table_rows)

    policy = json.loads((audit / "inference_category_policy_audit.json").read_text())
    d_alpha = json.loads((audit / "D_update300_alpha_summary.json").read_text())
    d0_equivalence = json.loads((audit / "C300_D0_subset_equivalence.json").read_text())
    c_strict = summaries["full_C_strict_vs_baseline"]
    b_strict = summaries["full_B_strict_vs_baseline"]
    b_current = summaries["full_B_current_vs_baseline"]
    c_pilot = summaries["subset_C_strict_vs_baseline"]
    c_ci = c_strict["case_bootstrap"]["ci95"]
    b_ci = b_strict["case_bootstrap"]["ci95"]
    recommendation = (
        "Continue only the strict 2b/2c scalar-B branch as a narrow follow-up; "
        "do not continue all-category C/D."
        if b_strict["mean_delta"] > 0
        else "Discontinue this adaptive-rho branch; neither strict C nor strict B improves the fixed baseline."
    )
    report = [
        "# Single-S3 adaptive-rho category-policy audit",
        "",
        "## Executive result",
        "",
        f"- Existing B/C/D inference is classified as **{policy['classification_of_existing_B_C_D_results']}**, not strict 2b/2c.",
        f"- C strict full: Dice {c_strict['candidate_mean_dice']:.6f}, delta {c_strict['mean_delta']:+.6f}, hit {c_strict['candidate_hits']}/{c_strict['finding_count']}, case-bootstrap CI [{c_ci[0]:+.6f}, {c_ci[1]:+.6f}].",
        f"- B current full: Dice {b_current['candidate_mean_dice']:.6f}, delta {b_current['mean_delta']:+.6f}, hit {b_current['candidate_hits']}/{b_current['finding_count']}.",
        f"- B strict full: Dice {b_strict['candidate_mean_dice']:.6f}, delta {b_strict['mean_delta']:+.6f}, hit {b_strict['candidate_hits']}/{b_strict['finding_count']}, case-bootstrap CI [{b_ci[0]:+.6f}, {b_ci[1]:+.6f}].",
        f"- Recommendation: {recommendation}",
        "",
        "## Consolidated comparison",
        "",
        "| Method | Policy | 30-case Dice | 30-case hits | Full Dice | Full hits | Delta vs baseline |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in table_rows:
        report.append(
            f"| {row['method']} | {row['category_policy']} | {fmt(row['subset_dice'])} | "
            f"{fmt_hits(row, 'subset')} | "
            f"{fmt(row['full_dice'])} | "
            f"{fmt_hits(row, 'full')} | "
            f"{fmt_signed(row['delta_vs_baseline'])} |"
        )
    report += [
        "",
        "## Paired comparison statistics",
        "",
        "| Comparison | Mean delta | Median delta | Improved/degraded/tied | New/lost hits | Case-bootstrap 95% CI | Empty ref→new |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for label, summary in summaries.items():
        ci = summary["case_bootstrap"]["ci95"]
        report.append(
            f"| {label} | {summary['mean_delta']:+.6f} | {summary['median_delta']:+.6f} | "
            f"{summary['improved']}/{summary['degraded']}/{summary['tied']} | "
            f"{summary['new_hits']}/{summary['lost_hits']} | "
            f"[{ci[0]:+.6f}, {ci[1]:+.6f}] | "
            f"{summary['reference_empty_predictions']}→{summary['candidate_empty_predictions']} |"
        )

    full_variant_keys = {
        "baseline": None,
        "B current": "full_B_current_vs_baseline",
        "B strict": "full_B_strict_vs_baseline",
        "C current": "full_C_current_vs_baseline",
        "C strict": "full_C_strict_vs_baseline",
    }
    categories = sorted(
        summaries["full_C_current_vs_baseline"]["by_category"],
        key=lambda value: (value == "unknown", value),
    )
    report += [
        "",
        "## Full-validation category Dice",
        "",
        "| Category | n | Baseline | B current | B strict | C current | C strict |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for category in categories:
        base = summaries["full_C_current_vs_baseline"]["by_category"][category]
        values = []
        for method, key in list(full_variant_keys.items())[1:]:
            values.append(
                summaries[key]["by_category"][category]["candidate_mean_dice"]
            )
        report.append(
            f"| {category} | {base['n']} | {base['reference_mean_dice']:.6f} | "
            + " | ".join(f"{value:.6f}" for value in values)
            + " |"
        )
    report += [
        "",
        "## Full-validation GT-size Dice",
        "",
        "| GT size | n | Baseline | B current | B strict | C current | C strict |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for group in ("tiny_lt100", "small_100_999", "medium_1k_9999", "large_ge10k"):
        base = summaries["full_C_current_vs_baseline"]["by_gt_size"][group]
        values = [
            summaries[key]["by_gt_size"][group]["candidate_mean_dice"]
            for key in list(full_variant_keys.values())[1:]
        ]
        report.append(
            f"| {group} | {base['n']} | {base['reference_mean_dice']:.6f} | "
            + " | ".join(f"{value:.6f}" for value in values)
            + " |"
        )
    report += [
        "",
        "## Required conclusions",
        "",
        "1. **Original policy preservation:** No. There was no permanent category mask. Zero- or weak-initialized categories remained trainable, and learned rho was applied to every category at inference. The adapter branch replaced the fixed gate rho and ignored the external gamma for effective adapter rho.",
        "2. **Originally bypassed categories:** Yes. The exported B/C tables show clearly nonzero rho for categories including 2a and 2h; 2a C channels also reach the 0.5 clamp.",
        "3. **Learned patterns:** B learned one bounded scalar per category/scale. For 2b its 1/4, 1/2, 1/1 values are 0.2319, 0.3405, 0.1002; for 2c they are 0.2624, 0.1726, 0.3630. B also moved bypassed 2h from 0 to 0.2726/0.3222/0.2576 and clamped 2a full-resolution rho at 0.5. C expanded each scalar into channel-wise values with substantial spread: for example 2b means are 0.1773/0.2917/0.1996 with standard deviations 0.1505/0.1528/0.1732; 2c means are 0.2394/0.2110/0.3571 with standard deviations 0.1505/0.1595/0.1750. At full resolution 40.6% of both 2a and 2c channels are near 0.5, while 18.8% of 2b channels are below 0.01. This is routing behavior, not interpretable medical channel semantics.",
        f"4. **D alpha:** D300 overall alpha mean is {d_alpha['overall']['mean']:.6f}; {d_alpha['overall']['fraction_near_2p0']:.2%} are near 2.0 and mean |alpha-1| is {d_alpha['overall']['mean_absolute_deviation_from_identity']:.6f}. The 1/2 scale is exactly 2.0 (std 0), 1/1 is 1.99993 (std 0.00027), and the limited variation is concentrated at 1/4 (mean 1.85983, std 0.36061) with category-dependent differences. It mostly learned stronger, near-saturated suppression; genuine sample variation is confined to a small minority.",
        f"5. **C pilot robustness:** C strict pilot delta is {c_pilot['mean_delta']:+.6f}; removing its top improvement changes the mean to {c_pilot['top_positive_sensitivity']['top_1']['mean_delta_after_removal']:+.6f}. Its case-bootstrap CI is [{c_pilot['case_bootstrap']['ci95'][0]:+.6f}, {c_pilot['case_bootstrap']['ci95'][1]:+.6f}], so the pilot signal is assessed from the paired/outlier analysis rather than the mean alone.",
        f"6. **C strict full:** {'Improves' if c_strict['mean_delta'] > 0 else 'Does not improve'} the 381-finding baseline (delta {c_strict['mean_delta']:+.6f}).",
        f"7. **B generalization:** B current delta is {b_current['mean_delta']:+.6f}; B strict delta is {b_strict['mean_delta']:+.6f}. The strict case-bootstrap CI is [{b_ci[0]:+.6f}, {b_ci[1]:+.6f}].",
        "8. **B versus C stability:** B is structurally more regularized (45 scalars) than C's channel-wise routing. Whether it is empirically more stable is determined by the full deltas and bootstrap intervals above; parameter count alone is not treated as efficacy evidence.",
        f"9. **Decision:** {recommendation}",
        "10. **Duplicate selection cause:** The selector ranked stage-best rows without semantic deduplication, so C300 and its exact D0 alpha=1 warm start occupied both slots. The corrected dry run selects C300 and B150.",
        "",
        "## Identity and equivalence checks",
        "",
        "- C-current versus baseline inference settings: exact equality of recorded checkpoint path, preprocessing, prompt/category mapping, threshold, sliding-window settings and 200-case manifest, with only the C adapter intentionally added.",
        "- C-strict and B-strict non-2b/2c binary channels: maximum difference 0 and changed voxels 0 by direct baseline-channel reuse. No new logits/probabilities were recomputed for those channels; identity is source identity rather than a tolerance claim.",
        "- D0 versus C300 state: rho tensor difference 0 at every scale; D0 alpha head is zero-initialized, so alpha=1. Patch verifier maximum logit and mean probability differences are 0.",
        f"- Existing independently saved 30-case C300/D0 binaries differ in {d0_equivalence['differing_binary_voxels_in_independent_saved_subset_runs']} voxels across {d0_equivalence['cases_with_differing_binary_voxels']} cases; their mean Dice/finding difference is {d0_equivalence['mean_dice_per_finding_difference_D0_minus_C']:+.9f}. These are repeat-run threshold-boundary effects: state and deterministic patch logits/probabilities are exactly identical.",
        "",
        "## Important baseline artifact note",
        "",
        "The existing output labeled fixed baseline (Dice 0.274422) records `s3_category_gamma_weakdiffuse_1a_to_1d_plus_2a2b2c.json`, not an all-zero-except-2b/2c gamma file. Per the follow-up instruction, strict adaptive results reuse this exact fixed-baseline prediction for every non-2b/2c channel. Thus the strict comparison isolates where the adaptive checkpoint is allowed to replace baseline behavior; it does not retroactively change the stored baseline run.",
        "",
        "## Paths and provenance",
        "",
        f"- Audit directory: `{audit.resolve()}`",
        f"- Baseline checkpoint: `{policy_path(existing / 'eval_base_model/fold_0/checkpoint_final.pth')}`",
        f"- B150: `{policy_path(existing / 'B/checkpoints/adaptive_rho_B_update_150.pth')}`",
        f"- C300: `{policy_path(existing / 'C/checkpoints/adaptive_rho_C_update_300.pth')}`",
        f"- D0: `{policy_path(existing / 'D/checkpoints/adaptive_rho_D_update_0.pth')}`",
        f"- D300: `{policy_path(existing / 'D/checkpoints/adaptive_rho_D_update_300.pth')}`",
        f"- Initial SLURM job: `{args.initial_job_id}` (4×H100, 17m41s; B-current completed, B-strict target-only save failed on compressed/full channel shape).",
        f"- Resume SLURM job: `{args.job_id}` (4×H100, 35m37s, completed; 96 GB requested, 15.8 GB MaxRSS).",
        "- Main outputs: `paired_comparison_summary.json`, `paired_finding_deltas.csv`, `final_comparison_table.csv`, learned-rho CSV/JSON/heatmaps, D-alpha CSV/JSON, `paired_outliers/`, and `output_file_inventory.json`.",
        "",
        "## Code changes",
        "",
        "- Added inference-only `strict_2b2c` active-mask plumbing through runner, predictor and VoxTell model.",
        "- Inactive samples force effective rho=0 before the scale controller; D alpha is not evaluated for them.",
        "- Added category-subset inference, strict prediction composition, shard merging, policy verification, learned-parameter audit, paired bootstrap/outlier analysis and semantic candidate deduplication.",
        "- Corrected selector dry run: C300 + B150; D0 is recorded as a duplicate of C300.",
        "- Git diff note: this workspace snapshot has no usable tracked baseline (`git status` reports repository content as untracked), so a conventional line-count diff is unavailable; the file-level change summary above is the auditable diff summary.",
        "",
        "## Commands used",
        "",
        f"- `sbatch scripts/evaluate_adaptive_rho_policy_audit_4h100.sbatch` → job `{args.initial_job_id}`.",
        f"- `sbatch --dependency=afterany:{args.initial_job_id} scripts/resume_adaptive_rho_policy_audit_4h100.sbatch` → job `{args.job_id}`.",
        "- The resume script validated/merged the existing B-current shards, ran only the filtered 2b/2c B-strict JSON with `--preserve-reference-channels`, constructed C/B hybrids, evaluated full/subset outputs, checked C/D0, and generated this report.",
        "- `python scripts/select_adaptive_rho_top2.py --root outputs/single_s3_adaptive_rho_BCD --dry-run` verified C300 + B150 after semantic deduplication.",
        "- `pytest -q tests/test_adaptive_rho.py` passed 7 tests.",
        "",
        "## Runs and exceptions",
        "",
        "- No B/C/D retraining and no D300 full inference were performed.",
        "- C-strict full did not rerun 381 findings; it reuses C-current for 2b/2c and baseline for all other categories.",
        "- B-strict inferred only 109 target findings (49 category 2b, 60 category 2c) across 76 cases; all other channels reuse baseline.",
        "- Early serial/local C hybrid materialization was terminated because network-filesystem gzip I/O was slow; construction was moved to four shards in the recorded SLURM job. A first subset reuse verifier treated probability-archive boundary-repair metadata as behavioral; that diagnostic-only field was excluded and the substantive equality checks then passed.",
    ]
    (audit / "single_s3_adaptive_rho_policy_audit_summary.md").write_text(
        "\n".join(report) + "\n"
    )
    inventory = []
    for path in sorted(audit.rglob("*")):
        if path.is_file() or path.is_symlink():
            inventory.append(
                {
                    "path": str(path.relative_to(audit)),
                    "type": "symlink" if path.is_symlink() else "file",
                    "size_bytes": path.lstat().st_size,
                    "symlink_target": (
                        str(path.resolve()) if path.is_symlink() else None
                    ),
                }
            )
    (audit / "output_file_inventory.json").write_text(
        json.dumps(
            {
                "audit_dir": str(audit.resolve()),
                "artifact_count_excluding_this_inventory": len(inventory),
                "artifacts": inventory,
            },
            indent=2,
        )
        + "\n"
    )
    print(json.dumps({"comparisons": len(summaries), "report": str((audit / "single_s3_adaptive_rho_policy_audit_summary.md").resolve())}, indent=2))
    return 0


def policy_path(path: Path) -> str:
    return str(path.resolve())


if __name__ == "__main__":
    raise SystemExit(main())
