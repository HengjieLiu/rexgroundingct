#!/usr/bin/env python3
"""Apply the predeclared fixed-30 GO/NO-GO criteria to one joint-gamma job."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "outputs/s3_1over1_allcat_v11_e1e-5_d1e-4_s3e1e-4_1gpu_bs1_acc4_10kupd"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", choices=["P", "F"], required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    baseline_update = 8000 if args.job == "P" else 9000
    baseline = pd.read_csv(
        BASE
        / f"full_volume/update_{baseline_update:05d}/summary_tables/per_finding_metrics.csv"
    )
    candidate = pd.read_csv(
        args.run_dir / "fixed30/final/per_finding_metrics.csv"
    )
    keys = ["file", "finding_idx"]
    paired = baseline.merge(candidate, on=keys, suffixes=("_base", "_candidate"))
    if len(paired) != 49:
        raise AssertionError(f"Expected 49 paired findings, got {len(paired)}")
    paired["delta"] = paired.global_dice_candidate - paired.global_dice_base
    tolerance = 1e-12
    checkpoint = torch.load(
        args.run_dir / "checkpoints/category_gamma_update_8400.pth",
        map_location="cpu",
        weights_only=False,
    )
    categories = checkpoint["router_config"]["categories"]
    values = checkpoint["router_state"]["g_raw"].float().clamp(0, 1).tolist()
    gamma = dict(zip(categories, values))
    history = [
        json.loads(line)
        for line in (args.run_dir / "history.jsonl").read_text().splitlines()
        if line.strip()
    ]
    exposure = history[-1]["category_update_counts"]
    adequately_sampled_below = [
        category
        for category, value in gamma.items()
        if int(exposure.get(category, 0)) >= 20 and value < 0.98
    ]
    delta = float(paired.delta.mean())
    without_largest = float(
        paired.drop(index=paired.delta.idxmax()).delta.mean()
    )
    baseline_hits = int(paired.global_hit_base.sum())
    candidate_hits = int(paired.global_hit_candidate.sum())
    common = (
        delta >= 0.002
        and candidate_hits >= baseline_hits
        and int((paired.delta > tolerance).sum())
        > int((paired.delta < -tolerance).sum())
        and without_largest > 0
    )
    nontrivial_pattern = max(gamma.values()) - min(gamma.values()) >= 0.02
    go = (
        common and len(adequately_sampled_below) >= 2
        if args.job == "P"
        else common and nontrivial_pattern
    )
    summary = {
        "job": args.job,
        "baseline_update": baseline_update,
        "historical_control_quality": (
            "own_exact_start" if args.job == "P" else "weak_non_step_matched"
        ),
        "findings": len(paired),
        "baseline_dice": float(paired.global_dice_base.mean()),
        "candidate_dice": float(paired.global_dice_candidate.mean()),
        "mean_delta": delta,
        "mean_delta_without_largest_improvement": without_largest,
        "baseline_hits": baseline_hits,
        "candidate_hits": candidate_hits,
        "improved": int((paired.delta > tolerance).sum()),
        "degraded": int((paired.delta < -tolerance).sum()),
        "tied": int((paired.delta.abs() <= tolerance).sum()),
        "new_hits": int(
            ((~paired.global_hit_base) & paired.global_hit_candidate).sum()
        ),
        "lost_hits": int(
            (paired.global_hit_base & (~paired.global_hit_candidate)).sum()
        ),
        "gamma": gamma,
        "category_update_counts": exposure,
        "adequately_sampled_categories_below_0p98": adequately_sampled_below,
        "nontrivial_gamma_pattern": nontrivial_pattern,
        "decision": "GO" if go else "SCREENING_NO_GO",
        "launch_381_finding_evaluation": go,
    }
    paired.to_csv(args.run_dir / "fixed30/paired_final.csv", index=False)
    (args.run_dir / "screen_result.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
