#!/usr/bin/env python3
"""Build small fixed30 lexical-token cache overlays for a causal audit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260820)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    source = torch.load(args.cache, map_location="cpu", weights_only=False)
    index = {
        (str(record["case"]), int(record["finding_idx"])): position
        for position, record in enumerate(source["records"])
    }
    selected = pd.read_csv(args.selection)
    positions = []
    for row in selected.itertuples(index=False):
        key = (str(row.case), int(row.finding_idx))
        if key not in index:
            raise KeyError(f"Fixed30 finding absent from cache: {key}")
        positions.append(index[key])
    records = [source["records"][position] for position in positions]
    tokens = [source["token_features"][position].clone() for position in positions]
    keys = [(str(r["split"]), str(r["case"]), int(r["finding_idx"])) for r in records]
    generator = torch.Generator(device="cpu").manual_seed(int(args.seed))

    conditions: dict[str, list[torch.Tensor]] = {"T0_normal": [x.clone() for x in tokens]}
    conditions["T1_token_shuffle"] = [
        value[torch.randperm(value.shape[0], generator=generator)].clone() for value in tokens
    ]
    conditions["T2_mean_token_repeat"] = [
        value.float().mean(dim=0, keepdim=True).to(value.dtype).expand_as(value).clone()
        for value in tokens
    ]
    sorted_indices = sorted(range(len(keys)), key=lambda i: keys[i])
    source_index: dict[int, int] = {}
    for rank, target in enumerate(sorted_indices):
        for offset in range(1, len(sorted_indices)):
            candidate = sorted_indices[(rank + offset) % len(sorted_indices)]
            if keys[candidate][1] != keys[target][1]:
                source_index[target] = candidate
                break
        else:
            raise RuntimeError(f"No cross-case source for {keys[target]}")
    conditions["T3_cross_case_prompt_swap"] = [tokens[source_index[i]].clone() for i in range(len(tokens))]

    mapping_rows = []
    for condition, values in conditions.items():
        payload = {
            "metadata": {
                "source_cache": str(args.cache.resolve()),
                "selection": str(args.selection.resolve()),
                "condition": condition,
                "seed": int(args.seed),
                "token_definition": "final-layer lexical PubMedBERT WordPieces; special tokens excluded upstream",
            },
            "records": records,
            "token_features": values,
        }
        torch.save(payload, args.output_dir / f"{condition}.pt")
        for target, value in enumerate(values):
            mapping_rows.append(
                {
                    "condition": condition,
                    "target_split": keys[target][0],
                    "target_case": keys[target][1],
                    "target_finding_idx": keys[target][2],
                    "token_count": int(value.shape[0]),
                    "source_split": keys[source_index[target]][0] if condition == "T3_cross_case_prompt_swap" else keys[target][0],
                    "source_case": keys[source_index[target]][1] if condition == "T3_cross_case_prompt_swap" else keys[target][1],
                    "source_finding_idx": keys[source_index[target]][2] if condition == "T3_cross_case_prompt_swap" else keys[target][2],
                }
            )
    pd.DataFrame(mapping_rows).to_csv(args.output_dir / "token_perturbation_manifest.csv", index=False)
    (args.output_dir / "token_perturbation_summary.json").write_text(
        json.dumps(
            {
                "conditions": list(conditions),
                "findings": len(records),
                "seed": int(args.seed),
                "lengths": {name: [int(x.shape[0]) for x in values] for name, values in conditions.items()},
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
