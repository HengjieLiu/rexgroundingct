#!/usr/bin/env python3
"""Create a deterministic, type-balanced capped component list for the mini-pilot."""

from __future__ import annotations

import argparse
import csv
import json
import random
from collections import Counter
from pathlib import Path
from typing import Any


TYPE_ORDER = (
    "whole_lung_outside_fp",
    "side_outside_fp",
    "exact_lobe_outside_fp",
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-csv", type=Path, required=True)
    parser.add_argument("--input-summary", type=Path, required=True)
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--output-summary", type=Path, required=True)
    parser.add_argument("--max-components", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=2027)
    args = parser.parse_args()
    with args.input_csv.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    by_type: dict[str, list[dict[str, str]]] = {
        kind: [row for row in rows if row["hard_negative_type"] == kind]
        for kind in TYPE_ORDER
    }
    quotas = {
        "whole_lung_outside_fp": round(args.max_components * 0.4),
        "side_outside_fp": round(args.max_components * 0.4),
        "exact_lobe_outside_fp": args.max_components
        - 2 * round(args.max_components * 0.4),
    }
    selected: list[dict[str, str]] = []
    selected_keys: set[tuple[str, ...]] = set()
    rng = random.Random(args.seed)
    for kind_index, kind in enumerate(TYPE_ORDER):
        candidates = by_type[kind][:]
        random.Random(args.seed + kind_index).shuffle(candidates)
        # Round-robin after deterministic shuffle prevents a few scans/findings
        # from dominating the capped pilot list.
        candidates.sort(
            key=lambda row: (
                int(row.get("component_rank") or 999),
                -int(row.get("same_side_priority") == "True"),
            )
        )
        for row in candidates[: quotas[kind]]:
            key = (
                row["case_id"],
                row["finding_id"],
                row["hard_negative_type"],
                row["component_rank"],
            )
            selected.append(row)
            selected_keys.add(key)
    remaining = [
        row
        for row in rows
        if (
            row["case_id"],
            row["finding_id"],
            row["hard_negative_type"],
            row["component_rank"],
        )
        not in selected_keys
    ]
    rng.shuffle(remaining)
    selected.extend(remaining[: max(0, args.max_components - len(selected))])
    selected = selected[: args.max_components]
    selected.sort(
        key=lambda row: (
            TYPE_ORDER.index(row["hard_negative_type"]),
            row["case_id"],
            int(row["finding_id"]),
            int(row["component_rank"]),
        )
    )
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(selected)
    original_summary = json.loads(args.input_summary.read_text())
    payload: dict[str, Any] = {
        "schema": "prompt_location_v2_streamlined_hard_negative_cap_v1",
        "seed": args.seed,
        "max_components": args.max_components,
        "raw_components": len(rows),
        "raw_components_by_type": dict(Counter(row["hard_negative_type"] for row in rows)),
        "usable_components": len(selected),
        "usable_components_by_type": dict(
            Counter(row["hard_negative_type"] for row in selected)
        ),
        "usable_cases": len({row["case_id"] for row in selected}),
        "usable_findings": len(
            {(row["case_id"], row["finding_id"]) for row in selected}
        ),
        "requested_type_mix": {
            "whole_lung_outside_fp": 0.4,
            "side_outside_fp": 0.4,
            "exact_lobe_outside_fp": 0.2,
        },
        "source_components_csv": str(args.input_csv.resolve()),
        "usable_components_csv": str(args.output_csv.resolve()),
        "source_mining_summary": original_summary,
    }
    args.output_summary.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload, indent=2))
    if not selected:
        raise RuntimeError("The capped hard-negative list is empty")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
