#!/usr/bin/env python
"""Report-prior post-hoc analysis for existing Anchor85 and S1 predictions."""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import pandas as pd
from scipy.ndimage import generate_binary_structure, label
from tqdm import tqdm


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BASELINE = ROOT / "outputs/voxtell_rex_anchor85_step3800_bestval_fullvol_val_predictions"
DEFAULT_GT = ROOT / "data/segmentations"
DEFAULT_CT = ROOT / "data/ct_rate_volumes_fixed"
DEFAULT_OUT = ROOT / "outputs/report_prior_posthoc_analysis"
CC_STRUCTURE = generate_binary_structure(3, 2)


SIZE_RE = re.compile(
    r"\b(?:tiny|small|punctate|sub[- ]?centimeter|millimet(?:er|ric)s?)\b|"
    r"\b\d+(?:\.\d+)?\s*(?:mm|millimeters?)\b",
    re.I,
)
NODULE_RE = re.compile(r"\b(?:nodule|nodules|nodular|mass|masses)\b", re.I)
GROUNDGLASS_RE = re.compile(r"ground[- ]?glass|\bggo\b|subsolid|sub-solid|part[- ]?solid", re.I)
PLEURAL_RE = re.compile(
    r"pleural[- ]?based|subpleural|perifissural|fissural|\bfissure\b|peripheral|juxtapleural",
    re.I,
)
MULTIPLE_RE = re.compile(r"\b(?:solitary|single|multiple|scattered|innumerable|bilateral|multifocal|several|few)\b|both lungs", re.I)
MULTIPLE_ONLY_RE = re.compile(r"\b(?:multiple|scattered|innumerable|bilateral|multifocal|several)\b|both lungs", re.I)
LARGE_RE = re.compile(r"\b(?:large|mass|masses)\b", re.I)
SOLID_RE = re.compile(r"\bsolid\b|subsolid|sub-solid|part[- ]?solid", re.I)
CALCIFIED_RE = re.compile(r"calcif", re.I)
CAVITARY_RE = re.compile(r"cavitar|cavitation", re.I)
SPICULATED_RE = re.compile(r"spiculat", re.I)
DIFFUSE_GGO_RE = re.compile(r"ground[- ]?glass|\bggo\b|\bopacit(?:y|ies)\b", re.I)
DIFFUSE_CONSOL_RE = re.compile(r"consolidat|atelecta", re.I)
DIFFUSE_EMPHYSEMA_RE = re.compile(r"emphysema|emphysematous", re.I)
DIFFUSE_EFFUSION_RE = re.compile(r"effusion|pleural", re.I)
DIFFUSE_ANY_RE = re.compile(
    r"diffuse|patchy|bilateral|multifocal|scattered|ground[- ]?glass|\bggo\b|"
    r"opacit|consolidat|atelecta|edema|emphysema|effusion",
    re.I,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-pred-dir", type=Path, default=DEFAULT_BASELINE)
    parser.add_argument("--gt-dir", type=Path, default=DEFAULT_GT)
    parser.add_argument("--ct-dir", type=Path, default=DEFAULT_CT)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--min-component-voxels", type=int, default=10)
    parser.add_argument("--limit-cases", type=int, default=0)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def add_prior_flags(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    text = out["prompt"].fillna("").astype(str)
    out["is_nodule_analysis"] = (out["category"] == "2d") | text.str.contains(NODULE_RE)
    out["nodule_tiny_or_small"] = text.str.contains(SIZE_RE)
    out["nodule_groundglass_or_subsolid"] = text.str.contains(GROUNDGLASS_RE)
    out["nodule_pleural_or_fissural"] = text.str.contains(PLEURAL_RE)
    out["nodule_multiple_or_scattered"] = text.str.contains(MULTIPLE_ONLY_RE)
    out["nodule_solitary_or_single"] = text.str.contains(r"\b(?:solitary|single)\b", case=False, regex=True)
    out["nodule_large_or_mass"] = text.str.contains(LARGE_RE)
    out["nodule_solid"] = text.str.contains(SOLID_RE)
    out["nodule_calcified"] = text.str.contains(CALCIFIED_RE)
    out["nodule_cavitary"] = text.str.contains(CAVITARY_RE)
    out["nodule_spiculated"] = text.str.contains(SPICULATED_RE)
    out["diffuse_ggo_opacity"] = text.str.contains(DIFFUSE_GGO_RE)
    out["diffuse_consolidation_atelectasis"] = text.str.contains(DIFFUSE_CONSOL_RE)
    out["diffuse_emphysema"] = text.str.contains(DIFFUSE_EMPHYSEMA_RE)
    out["diffuse_effusion_or_pleural"] = text.str.contains(DIFFUSE_EFFUSION_RE)
    out["has_diffuse_keyword"] = text.str.contains(DIFFUSE_ANY_RE)

    def coarse(row: pd.Series) -> str:
        if row.is_nodule_analysis:
            if row.nodule_tiny_or_small:
                return "nodule_tiny_or_small"
            if row.nodule_groundglass_or_subsolid:
                return "nodule_groundglass_or_subsolid"
            if row.nodule_pleural_or_fissural:
                return "nodule_pleural_or_fissural"
            if row.nodule_multiple_or_scattered:
                return "nodule_multiple_or_scattered"
            if row.nodule_large_or_mass:
                return "nodule_large_or_mass"
            return "unspecified_nodule"
        if row.diffuse_ggo_opacity:
            return "diffuse_ggo_opacity"
        if row.diffuse_consolidation_atelectasis:
            return "diffuse_consolidation_atelectasis"
        if row.diffuse_emphysema:
            return "diffuse_emphysema"
        if row.diffuse_effusion_or_pleural:
            return "diffuse_effusion_or_pleural"
        return "other"

    out["report_prior_subgroup"] = out.apply(coarse, axis=1)
    return out


def metadata_frame() -> pd.DataFrame:
    csv_path = ROOT / "data/csv_exports/MICCAI_challenge_dataset.en.csv"
    frame = pd.read_csv(csv_path, encoding="utf-8-sig")
    frame = frame[frame["split"] == "val"].copy()
    frame = frame.rename(
        columns={
            "case": "case_id",
            "category_code": "category",
            "finding": "prompt",
            "pixels": "dataset_gt_voxels",
        }
    )
    frame["finding_id"] = frame["finding_idx"].astype(int)
    return add_prior_flags(frame)


def metrics_from_counts(pred_n: int, gt_n: int, tp_n: int) -> dict[str, float | int | bool]:
    fp_n = pred_n - tp_n
    fn_n = gt_n - tp_n
    denom = pred_n + gt_n
    dice = 2.0 * tp_n / denom if denom else 1.0
    return {
        "pred_voxels": pred_n,
        "gt_voxels": gt_n,
        "tp_voxels": tp_n,
        "fp_voxels": fp_n,
        "fn_voxels": fn_n,
        "dice": dice,
        "hit": dice >= 0.1,
        "precision": tp_n / pred_n if pred_n else (1.0 if gt_n == 0 else 0.0),
        "recall": tp_n / gt_n if gt_n else 1.0,
        "pred_gt_volume_ratio": pred_n / gt_n if gt_n else np.nan,
    }


def component_rule_counts(
    component_sizes: np.ndarray,
    component_tp: np.ndarray,
    keep_ids: np.ndarray,
) -> tuple[int, int]:
    if keep_ids.size == 0:
        return 0, 0
    indices = keep_ids - 1
    return int(component_sizes[indices].sum()), int(component_tp[indices].sum())


def analyze_finding(
    pred: np.ndarray,
    gt: np.ndarray,
    is_nodule: bool,
    is_small: bool,
    is_multiple: bool,
    min_component_voxels: int,
    cap_voxels: int,
) -> dict[str, Any]:
    pred = pred > 0
    gt = gt > 0
    pred_n = int(pred.sum())
    gt_n = int(gt.sum())
    tp_n = int(np.logical_and(pred, gt).sum())
    result: dict[str, Any] = metrics_from_counts(pred_n, gt_n, tp_n)
    result.update(
        {
            "num_pred_components": np.nan,
            "largest_pred_component_voxels": np.nan,
        }
    )
    for rule in ("largest_component", "top2_components", "remove_lt10", "small_component_cap"):
        for key in ("dice", "hit", "precision", "recall", "pred_gt_volume_ratio"):
            result[f"{rule}_{key}"] = np.nan
    result["oracle_fpfirst_volume_cap_dice"] = np.nan
    result["oracle_fpfirst_volume_cap_improved"] = np.nan
    if not is_nodule:
        return result

    cc, n_components = label(pred, structure=CC_STRUCTURE)
    result["num_pred_components"] = int(n_components)
    if n_components == 0:
        component_sizes = np.empty(0, dtype=np.int64)
        component_tp = np.empty(0, dtype=np.int64)
    else:
        component_sizes = np.bincount(cc.ravel())[1:].astype(np.int64, copy=False)
        component_tp = np.bincount(cc[gt].ravel(), minlength=n_components + 1)[1:].astype(np.int64, copy=False)
    order = np.argsort(component_sizes)[::-1] + 1 if n_components else np.empty(0, dtype=int)
    result["largest_pred_component_voxels"] = int(component_sizes.max()) if n_components else 0
    rule_ids: dict[str, np.ndarray] = {
        "largest_component": order[:1],
        "top2_components": order[:2],
        "remove_lt10": np.where(component_sizes >= min_component_voxels)[0] + 1,
    }

    cap_ids = order.copy()
    if is_small and not is_multiple and n_components:
        selected: list[int] = []
        running = 0
        for component_id in order:
            size = int(component_sizes[component_id - 1])
            if not selected or running + size <= cap_voxels:
                selected.append(int(component_id))
                running += size
        cap_ids = np.asarray(selected, dtype=int)
    rule_ids["small_component_cap"] = cap_ids

    for rule, ids in rule_ids.items():
        rule_pred, rule_tp = component_rule_counts(component_sizes, component_tp, ids)
        for key, value in metrics_from_counts(rule_pred, gt_n, rule_tp).items():
            if key in {"dice", "hit", "precision", "recall", "pred_gt_volume_ratio"}:
                result[f"{rule}_{key}"] = value

    if is_small:
        oracle_pred = max(tp_n, min(pred_n, cap_voxels))
        oracle_dice = metrics_from_counts(oracle_pred, gt_n, tp_n)["dice"]
        result["oracle_fpfirst_volume_cap_dice"] = oracle_dice
        result["oracle_fpfirst_volume_cap_improved"] = oracle_dice > result["dice"] + 1e-12
    return result


def case_voxel_volume(case_id: str, fallback: nib.Nifti1Image, ct_dir: Path) -> float:
    path = ct_dir / case_id
    image = nib.load(path) if path.exists() else fallback
    volume = float(abs(np.linalg.det(image.affine[:3, :3])))
    if not np.isfinite(volume) or volume <= 0:
        volume = float(np.prod(image.header.get_zooms()[:3]))
    return volume


def process_case(task: tuple[Any, ...]) -> list[dict[str, Any]]:
    case_id, records, pred_dir, gt_dir, ct_dir, min_component_voxels, cap_voxels = task
    pred_img = nib.load(pred_dir / case_id)
    gt_img = nib.load(gt_dir / case_id)
    if pred_img.shape != gt_img.shape:
        raise ValueError(f"{case_id}: prediction shape {pred_img.shape} != GT {gt_img.shape}")
    if pred_img.shape[0] != len(records):
        raise ValueError(f"{case_id}: {pred_img.shape[0]} mask channels != {len(records)} findings")
    voxel_mm3 = case_voxel_volume(case_id, gt_img, ct_dir)
    rows = []
    for channel, metadata in enumerate(records):
        pred = np.asanyarray(pred_img.dataobj[channel])
        gt = np.asanyarray(gt_img.dataobj[channel])
        metrics = analyze_finding(
            pred,
            gt,
            bool(metadata["is_nodule_analysis"]),
            bool(metadata["nodule_tiny_or_small"]),
            bool(metadata["nodule_multiple_or_scattered"]),
            min_component_voxels,
            cap_voxels,
        )
        rows.append(
            {
                "case_id": case_id,
                "finding_id": int(metadata["finding_id"]),
                **metrics,
                "voxel_volume_mm3": voxel_mm3,
            }
        )
    return rows


def run_mask_analysis(meta: pd.DataFrame, args: argparse.Namespace) -> pd.DataFrame:
    small_gt = meta.loc[
        meta["is_nodule_analysis"] & meta["nodule_tiny_or_small"], "dataset_gt_voxels"
    ].dropna().astype(float)
    cap_voxels = int(max(10, math.ceil(float(small_gt.quantile(0.95))))) if len(small_gt) else 10000
    grouped = {
        case_id: group.sort_values("finding_id").to_dict("records")
        for case_id, group in meta.groupby("case_id", sort=True)
    }
    case_ids = [
        case_id
        for case_id in grouped
        if (args.baseline_pred_dir / case_id).exists() and (args.gt_dir / case_id).exists()
    ]
    if args.limit_cases:
        case_ids = case_ids[: args.limit_cases]
    tasks = [
        (
            case_id,
            grouped[case_id],
            args.baseline_pred_dir,
            args.gt_dir,
            args.ct_dir,
            args.min_component_voxels,
            cap_voxels,
        )
        for case_id in case_ids
    ]
    rows: list[dict[str, Any]] = []
    if args.num_workers <= 1:
        for task in tqdm(tasks, desc="Analyzing masks", unit="case"):
            rows.extend(process_case(task))
    else:
        with ProcessPoolExecutor(max_workers=args.num_workers) as pool:
            futures = [pool.submit(process_case, task) for task in tasks]
            for future in tqdm(as_completed(futures), total=len(futures), desc="Analyzing masks", unit="case"):
                rows.extend(future.result())
    result = pd.DataFrame(rows)
    result["small_nodule_gt_cap_voxels_p95"] = cap_voxels
    for column in ("pred_voxels", "gt_voxels", "tp_voxels", "fp_voxels", "fn_voxels"):
        result[column.replace("voxels", "volume_mm3")] = result[column] * result["voxel_volume_mm3"]
    return result


def merge_anatomy_reference(frame: pd.DataFrame) -> pd.DataFrame:
    path = ROOT / "outputs/anatomy_prior_diagnostic_val_hardneg_step1000_thr0p7/diagnostic/per_finding_metrics.csv"
    if not path.exists():
        frame["anatomy_reference_source"] = pd.NA
        frame["reference_fp_outside_whole_lung_mm3"] = np.nan
        frame["reference_fp_inside_whole_lung_mm3"] = np.nan
        return frame
    anatomy = pd.read_csv(path).rename(columns={"case": "case_id", "finding_idx": "finding_id"})
    columns = [
        "case_id",
        "finding_id",
        "fp_outside_whole_lung_mm3",
        "fp_inside_whole_lung_mm3",
        "pred_outside_whole_lung_fraction",
    ]
    anatomy = anatomy[columns].rename(
        columns={column: f"reference_{column}" for column in columns if column not in {"case_id", "finding_id"}}
    )
    out = frame.merge(anatomy, on=["case_id", "finding_id"], how="left")
    out["anatomy_reference_source"] = "hardneg_step1000_thr0p7_not_anchor85"
    return out


def summarize_group(group: pd.DataFrame) -> dict[str, Any]:
    ratio = group["pred_gt_volume_ratio"].replace([np.inf, -np.inf], np.nan)
    return {
        "n": len(group),
        "confidence": "low" if len(group) < 5 else "standard",
        "mean_dice": group["dice"].mean(),
        "median_dice": group["dice"].median(),
        "hit_rate": group["hit"].mean(),
        "median_precision": group["precision"].median(),
        "median_recall": group["recall"].median(),
        "median_pred_gt_volume_ratio": ratio.median(),
        "fraction_pred_gt_volume_ratio_gt2": (ratio > 2).mean(),
        "fraction_recall_lt0p1": (group["recall"] < 0.1).mean(),
        "fraction_precision_lt0p3": (group["precision"] < 0.3).mean(),
        "median_num_pred_components": group["num_pred_components"].median(),
        "median_gt_voxels": group["gt_voxels"].median(),
    }


def nodule_groups(frame: pd.DataFrame) -> list[tuple[str, pd.Series]]:
    nodule = frame["is_nodule_analysis"]
    any_specific = (
        frame["nodule_tiny_or_small"]
        | frame["nodule_groundglass_or_subsolid"]
        | frame["nodule_pleural_or_fissural"]
        | frame["nodule_multiple_or_scattered"]
        | frame["nodule_large_or_mass"]
    )
    return [
        ("all_nodule", nodule),
        ("tiny_small_subcentimeter", nodule & frame["nodule_tiny_or_small"]),
        ("groundglass_subsolid", nodule & frame["nodule_groundglass_or_subsolid"]),
        ("pleural_fissural_subpleural", nodule & frame["nodule_pleural_or_fissural"]),
        ("multiple_scattered", nodule & frame["nodule_multiple_or_scattered"]),
        ("large_mass", nodule & frame["nodule_large_or_mass"]),
        ("unspecified_nodule", nodule & ~any_specific),
    ]


def create_nodule_summary(frame: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for name, mask in nodule_groups(frame):
        group = frame[mask]
        if len(group):
            rows.append({"subgroup": name, "overlapping_subgroups": True, **summarize_group(group)})
    return pd.DataFrame(rows)


def postprocessing_summary(frame: pd.DataFrame) -> pd.DataFrame:
    rows = []
    rules = {
        "baseline_binary": "",
        "keep_largest_component": "largest_component_",
        "keep_top2_components": "top2_components_",
        "remove_components_lt10_voxels": "remove_lt10_",
        "small_nodule_component_cap": "small_component_cap_",
    }
    for subgroup, mask in nodule_groups(frame):
        group = frame[mask]
        if not len(group):
            continue
        for rule, prefix in rules.items():
            dice_col = f"{prefix}dice" if prefix else "dice"
            hit_col = f"{prefix}hit" if prefix else "hit"
            precision_col = f"{prefix}precision" if prefix else "precision"
            recall_col = f"{prefix}recall" if prefix else "recall"
            ratio_col = f"{prefix}pred_gt_volume_ratio" if prefix else "pred_gt_volume_ratio"
            valid = group[dice_col].notna()
            selected = group[valid]
            delta = selected[dice_col] - selected["dice"]
            rows.append(
                {
                    "subgroup": subgroup,
                    "rule": rule,
                    "n": len(selected),
                    "confidence": "low" if len(selected) < 5 else "standard",
                    "mean_dice": selected[dice_col].mean(),
                    "delta_mean_dice_vs_binary": selected[dice_col].mean() - selected["dice"].mean(),
                    "hit_rate": selected[hit_col].mean(),
                    "median_precision": selected[precision_col].median(),
                    "median_recall": selected[recall_col].median(),
                    "median_pred_gt_volume_ratio": selected[ratio_col].median(),
                    "improved_findings": int((delta > 1e-12).sum()),
                    "worsened_findings": int((delta < -1e-12).sum()),
                    "unchanged_findings": int((delta.abs() <= 1e-12).sum()),
                }
            )
        oracle = group[group["oracle_fpfirst_volume_cap_dice"].notna()].copy()
        if len(oracle):
            oracle_delta = oracle["oracle_fpfirst_volume_cap_dice"] - oracle["dice"]
            rows.append(
                {
                    "subgroup": subgroup,
                    "rule": "oracle_fpfirst_volume_cap_upper_bound",
                    "n": len(oracle),
                    "confidence": "low" if len(oracle) < 5 else "standard",
                    "mean_dice": oracle["oracle_fpfirst_volume_cap_dice"].mean(),
                    "delta_mean_dice_vs_binary": oracle_delta.mean(),
                    "hit_rate": (oracle["oracle_fpfirst_volume_cap_dice"] >= 0.1).mean(),
                    "median_precision": np.nan,
                    "median_recall": np.nan,
                    "median_pred_gt_volume_ratio": np.nan,
                    "improved_findings": int((oracle_delta > 1e-12).sum()),
                    "worsened_findings": int((oracle_delta < -1e-12).sum()),
                    "unchanged_findings": int((oracle_delta.abs() <= 1e-12).sum()),
                }
            )
    return pd.DataFrame(rows)


def load_s1_diffuse(meta: pd.DataFrame) -> pd.DataFrame:
    base = ROOT / "outputs/spatial_attention_ablation_s1_beta1p5_step1000"
    settings = {
        "Anchor85_step3800": DEFAULT_BASELINE / "per_finding_metrics.csv",
        "S1_gamma1": base / "gamma1/per_finding_metrics.csv",
        "S1_focaloff": base / "category_focaloff/per_finding_metrics.csv",
        "S1_focaloff_2c_on": base / "category_focaloff_2c_on/per_finding_metrics.csv",
        "S1_only_2d_off": base / "category_only_2d_off/per_finding_metrics.csv",
        "S1_global_gamma0": base / "global_rho_sweep/gamma_0p00/per_finding_metrics.csv",
    }
    meta_small = meta[["case_id", "finding_id", "focality", "category_name"]].copy()
    baseline_by_category: dict[str, tuple[float, float]] = {}
    all_rows = []
    merged_settings: dict[str, pd.DataFrame] = {}
    for setting, path in settings.items():
        data = pd.read_csv(path).rename(
            columns={"file": "case_id", "finding_idx": "finding_id", "global_dice": "dice", "global_hit": "hit"}
        )
        data["hit"] = data["hit"].map(truthy)
        data = data.merge(meta_small, on=["case_id", "finding_id"], how="left")
        merged_settings[setting] = data
        if setting == "Anchor85_step3800":
            for category, group in data.groupby("category"):
                baseline_by_category[str(category)] = (group["dice"].mean(), group["hit"].mean())
    baseline = merged_settings["Anchor85_step3800"]
    baseline_nonfocal = baseline[baseline["focality"].str.lower().eq("non-focal")]
    baseline_nonfocal_values = (baseline_nonfocal["dice"].mean(), baseline_nonfocal["hit"].mean())
    for setting, data in merged_settings.items():
        nonfocal = data[data["focality"].str.lower().eq("non-focal")]
        all_rows.append(
            {
                "setting": setting,
                "scope": "all_non_focal",
                "category": "ALL",
                "n": len(nonfocal),
                "mean_dice": nonfocal["dice"].mean(),
                "hit_rate": nonfocal["hit"].mean(),
                "delta_dice_vs_anchor85": nonfocal["dice"].mean() - baseline_nonfocal_values[0],
                "delta_hit_vs_anchor85": nonfocal["hit"].mean() - baseline_nonfocal_values[1],
            }
        )
        for category, group in data.groupby("category", sort=True):
            focality = group["focality"].dropna().mode()
            focality_value = focality.iloc[0] if len(focality) else "unknown"
            if str(focality_value).lower() != "non-focal":
                continue
            reference = baseline_by_category[str(category)]
            all_rows.append(
                {
                    "setting": setting,
                    "scope": "non_focal_category",
                    "category": category,
                    "n": len(group),
                    "mean_dice": group["dice"].mean(),
                    "hit_rate": group["hit"].mean(),
                    "delta_dice_vs_anchor85": group["dice"].mean() - reference[0],
                    "delta_hit_vs_anchor85": group["hit"].mean() - reference[1],
                }
            )
        for category in ("2c", "2d"):
            group = data[data["category"] == category]
            reference = baseline_by_category[category]
            all_rows.append(
                {
                    "setting": setting,
                    "scope": "focus_category",
                    "category": category,
                    "n": len(group),
                    "mean_dice": group["dice"].mean(),
                    "hit_rate": group["hit"].mean(),
                    "delta_dice_vs_anchor85": group["dice"].mean() - reference[0],
                    "delta_hit_vs_anchor85": group["hit"].mean() - reference[1],
                }
            )
    out = pd.DataFrame(all_rows)
    out["confidence"] = np.where(out["n"] < 5, "low", "standard")
    out["probability_threshold_sweep_available"] = False
    return out


def format_metric(value: float) -> str:
    return "NA" if pd.isna(value) else f"{value:.4f}"


def write_inventory(args: argparse.Namespace, probability_maps: bool) -> None:
    candidates = {
        "Anchor85 global evaluation and 200 binary prediction masks": args.baseline_pred_dir,
        "Anchor85 per-finding Dice/hit metadata": args.baseline_pred_dir / "per_finding_metrics.csv",
        "Earlier category-2d size/keyword analysis": ROOT / "outputs/analysis_prompt_embedding_failures_aug_step500/2d_nodule_failure_analysis",
        "Hard-negative anatomy FP diagnostic (different checkpoint)": ROOT / "outputs/anatomy_prior_diagnostic_val_hardneg_step1000_thr0p7/diagnostic/per_finding_metrics.csv",
        "S1 step600 category-gamma summary": ROOT / "outputs/spatial_attention_ablation_s1_beta1p5_step600/category_gamma_summary.csv",
        "S1 step1000 category-gamma summary and per-finding rules": ROOT / "outputs/spatial_attention_ablation_s1_beta1p5_step1000/category_gamma_summary.csv",
        "Presence V2 category gating report": ROOT / "outputs/presence_v2_category_gating_report.csv",
        "Prior hard-negative probability threshold sweep": ROOT / "outputs/threshold_sweeps/hardneg_weightedbce_r10_step1000_threshold_sweep_summary.csv",
    }
    lines = [
        "Existing report-prior/post-hoc result inventory",
        "=" * 52,
        "",
        "Found and reused:",
    ]
    for description, path in candidates.items():
        lines.append(f"- [{ 'FOUND' if path.exists() else 'MISSING' }] {description}: {path}")
    lines.extend(
        [
            "",
            "Questions already answered by prior outputs:",
            "- Anchor85 global Dice/hit and category 2d size/keyword failure trends.",
            "- S1 step600/step1000 global and category-specific gamma-rule behavior.",
            "- Anatomy FP localization for hardneg step1000 (reference only; not the Anchor85 mask source).",
            "- A threshold sweep for a different hard-negative checkpoint; it is not reused as Anchor85 evidence.",
            "",
            "Newly computed here:",
            "- Anchor85 voxel TP/FP/FN, precision/recall/volume ratio and nodule connected components.",
            "- Report-prior keyword flags and subgroup summaries.",
            "- Binary connected-component post-processing and a clearly labeled oracle volume-cap bound.",
            "- Integrated diffuse/non-focal S1 rule comparison from existing per-finding CSVs.",
            "",
            f"Probability maps available for Anchor85: {probability_maps}",
            "- Probability threshold sweep is skipped because saved Anchor85 outputs are binary masks only.",
            "",
            "Primary predictions/checkpoints:",
            f"- Anchor85 step3800 binary predictions: {args.baseline_pred_dir}",
            "- Strongest saved Presence V2 row is step600/no_gate Dice=0.267019, below Anchor85 Dice=0.267057; Anchor85 remains primary.",
            "- S1 step1000 rule outputs: outputs/spatial_attention_ablation_s1_beta1p5_step1000/",
            "- No new model inference or training was run.",
        ]
    )
    (args.out_dir / "inventory_existing_results.txt").write_text("\n".join(lines) + "\n")


def nodule_report(frame: pd.DataFrame, summary: pd.DataFrame, post: pd.DataFrame) -> str:
    indexed = summary.set_index("subgroup")
    small = indexed.loc["tiny_small_subcentimeter"] if "tiny_small_subcentimeter" in indexed.index else None
    ggo = indexed.loc["groundglass_subsolid"] if "groundglass_subsolid" in indexed.index else None
    pleural = indexed.loc["pleural_fissural_subpleural"] if "pleural_fissural_subpleural" in indexed.index else None
    all_nodule = indexed.loc["all_nodule"]
    spearman = frame.loc[frame["is_nodule_analysis"], ["gt_voxels", "dice"]].corr(method="spearman").iloc[0, 1]

    def failure_readout(row: pd.Series | None) -> str:
        if row is None:
            return "not available"
        miss = row["fraction_recall_lt0p1"]
        over = max(row["fraction_precision_lt0p3"], row["fraction_pred_gt_volume_ratio_gt2"])
        if miss >= 0.25 and over >= 0.25:
            return "mixed missed-lesion and over-segmentation behavior"
        if miss > over:
            return "predominantly missed/under-segmented, with a secondary over-segmented subset"
        if over > miss:
            qualifier = ", with a substantial missed subset" if miss >= 0.15 else ""
            return f"predominantly over-segmented{qualifier}"
        return "mixed/indeterminate"

    deployable = post[
        (post["subgroup"] == "all_nodule")
        & (post["rule"] != "baseline_binary")
        & ~post["rule"].str.startswith("oracle_")
    ]
    best = deployable.sort_values(
        "mean_dice", ascending=False
    ).head(1)
    best_text = (
        f"{best.iloc[0]['rule']} (delta mean Dice {best.iloc[0]['delta_mean_dice_vs_binary']:+.4f})"
        if len(best)
        else "none"
    )
    oracle = post[
        (post["subgroup"] == "all_nodule")
        & (post["rule"] == "oracle_fpfirst_volume_cap_upper_bound")
    ].head(1)
    lines = [
        "Nodule report-prior analysis",
        "=" * 36,
        f"Nodule-analysis findings: {int(all_nodule['n'])}",
        "Subgroups overlap when a report contains multiple priors.",
        "Subgroups with n < 5 are marked low-confidence in the CSV.",
        "",
        "1. Small/tiny nodule failure mode",
        f"- Readout: {failure_readout(small)}.",
    ]
    if small is not None:
        lines.append(
            f"- n={int(small['n'])}; Dice={small['mean_dice']:.4f}; hit={small['hit_rate']:.4f}; "
            f"recall<0.1={small['fraction_recall_lt0p1']:.3f}; precision<0.3={small['fraction_precision_lt0p3']:.3f}; "
            f"volume ratio>2={small['fraction_pred_gt_volume_ratio_gt2']:.3f}."
        )
    lines.extend(["", "2. Ground-glass/subsolid nodules"])
    if ggo is not None:
        lines.append(
            f"- n={int(ggo['n'])}; Dice={ggo['mean_dice']:.4f} vs all nodules {all_nodule['mean_dice']:.4f}; "
            f"hit={ggo['hit_rate']:.4f}; median recall={ggo['median_recall']:.3f}; "
            f"median ratio={ggo['median_pred_gt_volume_ratio']:.3f}."
        )
        lines.append(
            "- In this cohort they perform better than nodules overall, so they do not behave like a uniquely difficult diffuse subgroup."
        )
    else:
        lines.append("- No matching findings.")
    lines.extend(["", "3. Pleural/perifissural nodules"])
    if pleural is not None:
        lines.append(
            f"- n={int(pleural['n'])}; precision<0.3={pleural['fraction_precision_lt0p3']:.3f}; "
            f"ratio>2={pleural['fraction_pred_gt_volume_ratio_gt2']:.3f}; Dice={pleural['mean_dice']:.4f}."
        )
        lines.append(
            "- This supports frequent over-segmentation; the binary masks alone cannot prove that the excess specifically leaks across pleura/fissures."
        )
    else:
        lines.append("- No matching findings.")
    lines.extend(
        [
            "",
            "4. Size versus report subtype",
            f"- Spearman(GT voxels, Dice)={spearman:.4f}; this is only a weak positive association, so size alone is insufficient.",
            "- Subgroup differences in nodule_prior_summary.csv support additional report-subtype/extent effects; overlapping flags prevent causal attribution.",
            "- Conclusion: use both mask size and report subtype/extent, and avoid claiming subtype effects for n < 5.",
            "",
            "5. Binary post-processing",
            f"- Best tested overall nodule rule: {best_text}.",
            "- The best deployable delta is negligible; no generic binary component rule provides a meaningful aggregate gain.",
            "- Largest-component rules are not recommended for multiple/scattered prompts without subgroup gating.",
            "- The FP-first volume cap is an oracle upper bound, not a deployable rule.",
            "- Probability threshold sweeps were unavailable because only binary Anchor85 masks were saved.",
        ]
    )
    if len(oracle):
        row = oracle.iloc[0]
        lines.insert(
            -1,
            f"- Oracle cap upper bound: n={int(row['n'])}, mean Dice delta={row['delta_mean_dice_vs_binary']:+.4f}, "
            f"improved/worsened={int(row['improved_findings'])}/{int(row['worsened_findings'])}.",
        )
    return "\n".join(lines) + "\n"


def diffuse_report(diffuse: pd.DataFrame) -> str:
    overall = pd.read_csv(
        ROOT / "outputs/spatial_attention_ablation_s1_beta1p5_step1000/category_gamma_summary.csv"
    ).set_index("model_config_name")
    gamma1 = overall.loc["S1_step1000_gamma1"]
    focaloff_2c = overall.loc["S1_step1000_focaloff_2c_on"]
    focus = diffuse[diffuse["scope"] == "focus_category"].copy()
    nonfocal = diffuse[diffuse["scope"] == "all_non_focal"].sort_values("mean_dice", ascending=False)
    best_nonfocal = nonfocal.iloc[0]
    lines = [
        "Diffuse/non-focal S1 rule analysis",
        "=" * 38,
        "All values are reused from existing step1000 per-finding rule outputs; no inference was rerun.",
        "Probability threshold sweeps were not run because the saved Anchor85 outputs are binary.",
        "",
        f"Best mean Dice over all non-focal findings: {best_nonfocal['setting']} = {best_nonfocal['mean_dice']:.4f}.",
        f"Overall S1 gamma1 changes Dice by {gamma1['Delta_Dice_finding_vs_Anchor85']:+.4f} and hit rate by "
        f"{gamma1['Delta_hit_rate_vs_Anchor85']:+.4f}; its main aggregate benefit is hit/detection, not overlap Dice.",
        f"The focal-off + 2c-ON rule changes overall Dice by {focaloff_2c['Delta_Dice_finding_vs_Anchor85']:+.4f} "
        f"and hit rate by {focaloff_2c['Delta_hit_rate_vs_Anchor85']:+.4f}.",
        "",
    ]
    for category in ("2c", "2d"):
        rows = focus[focus["category"] == category].sort_values("mean_dice", ascending=False)
        lines.append(f"Category {category}:")
        for _, row in rows.iterrows():
            lines.append(
                f"- {row['setting']}: Dice={row['mean_dice']:.4f} ({row['delta_dice_vs_anchor85']:+.4f}); "
                f"hit={row['hit_rate']:.4f} ({row['delta_hit_vs_anchor85']:+.4f}); n={int(row['n'])}."
            )
        lines.append("")
    lines.extend(
        [
            "Interpretation:",
            "- Diffuse/non-focal errors are heterogeneous; the sign and magnitude of S1 effects differ by category.",
            "- Compare S1_focaloff_2c_on against S1_focaloff to isolate the 2c-ON rule.",
            "- Compare S1_only_2d_off against S1_gamma1 to isolate disabling attention for 2d.",
            "- 2c ON recovers Dice relative to focal-off but remains below Anchor85 for 2c.",
            "- 2d OFF recovers most of the S1 gamma1 loss for 2d but remains below Anchor85 for 2d.",
        ]
    )
    return "\n".join(lines) + "\n"


def integrated_report(
    frame: pd.DataFrame,
    nodule_summary: pd.DataFrame,
    post: pd.DataFrame,
    diffuse: pd.DataFrame,
) -> str:
    nodule = nodule_summary.set_index("subgroup")
    all_nodule = nodule.loc["all_nodule"]
    small = nodule.loc["tiny_small_subcentimeter"] if "tiny_small_subcentimeter" in nodule.index else None
    s1 = diffuse[(diffuse["scope"] == "focus_category")]
    two_c = s1[s1["category"] == "2c"].set_index("setting")
    two_d = s1[s1["category"] == "2d"].set_index("setting")
    best_post = post[
        (post["subgroup"] == "all_nodule")
        & (post["rule"] != "baseline_binary")
        & ~post["rule"].str.startswith("oracle_")
    ].sort_values(
        "mean_dice", ascending=False
    ).head(1)
    oracle_post = post[
        (post["subgroup"] == "all_nodule")
        & (post["rule"] == "oracle_fpfirst_volume_cap_upper_bound")
    ].head(1)
    lines = [
        "Report-prior-aware VoxTell post-hoc analysis",
        "=" * 48,
        "",
        "1. Reused analyses",
        "- Anchor85 step3800 binary predictions/global evaluation and prior 2d size/keyword analysis.",
        "- Existing S1 step600/step1000 category-gamma ablations and per-finding rule outputs.",
        "- Hardneg step1000 anatomy diagnostic only as a clearly labeled cross-checkpoint reference.",
        "- No training and no model inference were run.",
        "",
        "2. Nodule / category 2d",
        f"- n={int(all_nodule['n'])}; mean Dice={all_nodule['mean_dice']:.4f}; hit={all_nodule['hit_rate']:.4f}.",
    ]
    if small is not None:
        lines.append(
            f"- Small/tiny n={int(small['n'])}: Dice={small['mean_dice']:.4f}, recall<0.1={small['fraction_recall_lt0p1']:.3f}, "
            f"precision<0.3={small['fraction_precision_lt0p3']:.3f}, ratio>2={small['fraction_pred_gt_volume_ratio_gt2']:.3f}."
        )
    lines.extend(
        [
            "- Failure is explained by both GT size and report subtype; subgroup overlap and small n limit causal claims.",
            "- Ground-glass/subsolid and pleural/fissural findings are reported separately in nodule_prior_summary.csv.",
            "",
            "3. Diffuse findings and S1",
            "- Effects are category-dependent rather than a single diffuse-versus-focal rule.",
        ]
    )
    if "S1_focaloff_2c_on" in two_c.index and "S1_focaloff" in two_c.index:
        delta = two_c.loc["S1_focaloff_2c_on", "mean_dice"] - two_c.loc["S1_focaloff", "mean_dice"]
        anchor_delta = two_c.loc["S1_focaloff_2c_on", "delta_dice_vs_anchor85"]
        lines.append(
            f"- Enabling 2c on top of focal-off changes 2c Dice by {delta:+.4f}, but remains {anchor_delta:+.4f} versus Anchor85."
        )
    if "S1_only_2d_off" in two_d.index and "S1_gamma1" in two_d.index:
        delta = two_d.loc["S1_only_2d_off", "mean_dice"] - two_d.loc["S1_gamma1", "mean_dice"]
        anchor_delta = two_d.loc["S1_only_2d_off", "delta_dice_vs_anchor85"]
        lines.append(
            f"- Disabling attention only for 2d changes 2d Dice by {delta:+.4f} versus S1 gamma1, "
            f"but remains {anchor_delta:+.4f} versus Anchor85."
        )
    lines.extend(["", "4. Promising inference/post-processing rules"])
    if len(best_post):
        row = best_post.iloc[0]
        lines.append(
            f"- Best tested binary nodule rule: {row['rule']}, overall nodule Dice delta {row['delta_mean_dice_vs_binary']:+.4f}; "
            f"improved/worsened={int(row['improved_findings'])}/{int(row['worsened_findings'])}."
        )
        lines.append("- This aggregate gain is negligible; none of the deployable binary component rules is recommended globally.")
    if len(oracle_post):
        row = oracle_post.iloc[0]
        lines.append(
            f"- FP-first oracle cap upper bound: n={int(row['n'])}, Dice delta {row['delta_mean_dice_vs_binary']:+.4f}, "
            f"improved/worsened={int(row['improved_findings'])}/{int(row['worsened_findings'])}; this is not deployable."
        )
    lines.extend(
        [
            "- Use component rules only with extent-aware gating; do not collapse multiple/scattered nodules to one component.",
            "- Use category-specific S1 rules only where the paired per-finding ablation is positive.",
            "- A report-driven probability threshold remains untested because Anchor85 probability maps were not saved.",
            "",
            "5. Recommended next training/inference tests",
            "- Save probability maps for a small fixed validation subset and test report/category-aware thresholds.",
            "- Test nodule subtype/extent-aware component filtering prospectively, especially tiny solitary versus multiple prompts.",
            "- Keep 2c/2d S1 behavior category-specific; avoid a global attention gate.",
            "- Consider category-aware auxiliary Tversky only after confirming stable FP-heavy or FN-heavy behavior in fixed subgroups.",
            "",
            "Limitations",
            "- Binary masks prevent true threshold sweeps and confidence-ranked volume truncation.",
            "- Anatomy FP columns come from a different hard-negative checkpoint and are reference-only.",
            "- Subgroups overlap; n < 5 is labeled low-confidence.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> int:
    args = parse_args()
    deliverable = args.out_dir / "per_finding_report_prior_metrics.csv"
    if deliverable.exists() and not args.overwrite:
        raise FileExistsError(f"Refusing to overwrite existing analysis: {deliverable}; pass --overwrite explicitly")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    meta = metadata_frame()
    expected = len(meta)
    binary_files = list(args.baseline_pred_dir.glob("*.nii.gz"))
    probability_maps = any(
        next(args.baseline_pred_dir.rglob(pattern), None) is not None
        for pattern in ("*.npz", "*.npy", "*prob*.nii.gz")
    )
    write_inventory(args, probability_maps)
    metrics = run_mask_analysis(meta, args)
    frame = meta.merge(metrics, on=["case_id", "finding_id"], how="inner")
    if not args.limit_cases and len(frame) != expected:
        raise RuntimeError(f"Expected {expected} findings, computed {len(frame)}")
    if len(binary_files) < 200 and not args.limit_cases:
        raise RuntimeError(f"Expected at least 200 prediction masks, found {len(binary_files)}")
    frame = merge_anatomy_reference(frame)
    frame = frame.sort_values(["case_id", "finding_id"]).reset_index(drop=True)
    frame.to_csv(deliverable, index=False)
    flag_columns = [
        "case_id",
        "finding_id",
        "prompt",
        "category",
        "focality",
        "category_name",
        "is_nodule_analysis",
        "nodule_tiny_or_small",
        "nodule_groundglass_or_subsolid",
        "nodule_pleural_or_fissural",
        "nodule_multiple_or_scattered",
        "nodule_solitary_or_single",
        "nodule_large_or_mass",
        "nodule_solid",
        "nodule_calcified",
        "nodule_cavitary",
        "nodule_spiculated",
        "diffuse_ggo_opacity",
        "diffuse_consolidation_atelectasis",
        "diffuse_emphysema",
        "diffuse_effusion_or_pleural",
        "has_diffuse_keyword",
        "report_prior_subgroup",
    ]
    frame[flag_columns].to_csv(args.out_dir / "report_prior_flags.csv", index=False)
    nodule_summary = create_nodule_summary(frame)
    nodule_summary.to_csv(args.out_dir / "nodule_prior_summary.csv", index=False)
    post = postprocessing_summary(frame)
    post.to_csv(args.out_dir / "nodule_postprocessing_summary.csv", index=False)
    (args.out_dir / "nodule_prior_report.txt").write_text(nodule_report(frame, nodule_summary, post))
    diffuse = load_s1_diffuse(meta)
    diffuse.to_csv(args.out_dir / "diffuse_s1_threshold_summary.csv", index=False)
    (args.out_dir / "diffuse_s1_report.txt").write_text(diffuse_report(diffuse))
    (args.out_dir / "report_prior_posthoc_report.txt").write_text(
        integrated_report(frame, nodule_summary, post, diffuse)
    )
    print(f"Analyzed {len(frame)} findings from {frame['case_id'].nunique()} cases")
    print(f"Saved report-prior analysis to {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
