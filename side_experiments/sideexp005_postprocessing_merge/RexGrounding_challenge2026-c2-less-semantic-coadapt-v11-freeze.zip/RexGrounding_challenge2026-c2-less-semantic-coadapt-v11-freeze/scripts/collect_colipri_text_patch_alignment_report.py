#!/usr/bin/env python3
"""Create the requested final comparison of Experiment 5 and Experiment B."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import nibabel as nib


ROOT = Path(__file__).resolve().parents[1]
EXP5 = ROOT / "outputs/colipri_voxtell_nextstep_v1/text_replacement_600step"
EXPB = ROOT / "outputs/colipri_text_and_voxtell_patch_alignment_v1"
BASELINE_DIR = ROOT / "outputs/voxtell_rex_anchor85_step3800_bestval_fullvol_val_predictions"
SELECTED = ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv"


def metric_summary(frame: pd.DataFrame) -> dict[str, float]:
    return {
        "dice": float(frame.dice.mean()),
        "hit_rate": float(frame.hit.mean()),
        "mean_fp": float(frame.fp_voxels.mean()),
        "mean_pred": float(frame.pred_voxels.mean()),
        "median_ratio": float(frame.pred_gt_volume_ratio.median()),
        "empty": int(frame.empty_prediction.sum()),
    }


def baseline_frame() -> pd.DataFrame:
    case_ids = pd.read_csv(SELECTED)["case"].drop_duplicates().tolist()
    rows = []
    for case_id in case_ids:
        prediction = np.asanyarray(nib.load(BASELINE_DIR / case_id).dataobj) > 0
        target = np.asanyarray(nib.load(ROOT / "data/segmentations" / case_id).dataobj) > 0
        if prediction.shape != target.shape:
            raise RuntimeError(f"Baseline shape mismatch for {case_id}: {prediction.shape} vs {target.shape}")
        for finding_idx in range(target.shape[0]):
            pred = prediction[finding_idx]
            gt = target[finding_idx]
            tp = int(np.logical_and(pred, gt).sum())
            fp = int(np.logical_and(pred, ~gt).sum())
            fn = int(np.logical_and(~pred, gt).sum())
            pred_voxels = int(pred.sum())
            gt_voxels = int(gt.sum())
            rows.append({
                "dice": 2 * tp / max(2 * tp + fp + fn, 1),
                "hit": int(tp > 0),
                "fp_voxels": fp,
                "pred_voxels": pred_voxels,
                "gt_voxels": gt_voxels,
                "pred_gt_volume_ratio": pred_voxels / max(gt_voxels, 1),
                "empty_prediction": int(pred_voxels == 0),
            })
    return pd.DataFrame(rows)


def main() -> int:
    exp5 = pd.read_csv(EXP5 / "text_replacement_30case_results.csv")
    expb = pd.read_csv(EXPB / "patch_alignment_30case_results.csv")
    exp5_trajectory = pd.read_csv(EXP5 / "text_replacement_validation_trajectory.csv")
    expb_trajectory = pd.read_csv(EXPB / "patch_alignment_patch_validation.csv")
    cached_summary_path = EXPB / "final_two_experiment_summary.csv"
    if cached_summary_path.is_file():
        cached = pd.read_csv(cached_summary_path)
        baseline_row = cached[cached.experiment == "Anchor85 baseline"].iloc[0]
        baseline_summary = {
            key: baseline_row[key]
            for key in ("dice", "hit_rate", "mean_fp", "mean_pred", "median_ratio", "empty")
        }
    else:
        baseline_summary = metric_summary(baseline_frame())
    exp5_summary = metric_summary(exp5)
    expb_summary = metric_summary(expb)
    row300 = exp5_trajectory.iloc[(exp5_trajectory.step - 300).abs().argsort()[:1]].iloc[0]
    row0 = exp5_trajectory.iloc[(exp5_trajectory.step - 0).abs().argsort()[:1]].iloc[0]
    align_final = expb_trajectory.iloc[-1]
    patch_recovered = float(row300.positive_dice) > float(row0.positive_dice) + 0.002
    meaningful = exp5_summary["dice"] >= 0.10 and exp5_summary["hit_rate"] >= 0.50
    separation_auroc = float(align_final.alignment_auroc)
    separation_margin = float(align_final.positive_minus_negative_margin)
    reliable_separation = separation_auroc >= 0.60 and separation_margin >= 0.01
    weak_separation = separation_auroc > 0.55 and separation_margin > 0
    fp_change = expb_summary["mean_fp"] - baseline_summary["mean_fp"]
    pred_change = expb_summary["mean_pred"] - baseline_summary["mean_pred"]
    dice_change = expb_summary["dice"] - baseline_summary["dice"]
    if fp_change < 0 and dice_change >= 0:
        fp_answer = "reduced FP without reducing mean Dice"
    elif fp_change < 0 and pred_change < 0:
        fp_answer = "reduced FP while shrinking masks; the Dice change determines whether shrinkage was useful"
    else:
        fp_answer = "did not reduce mean FP"
    continuation = "neither"
    if patch_recovered and meaningful and exp5_summary["dice"] > baseline_summary["dice"]:
        continuation = "COLIPRI text replacement"
    if reliable_separation and expb_summary["dice"] > max(baseline_summary["dice"], exp5_summary["dice"]):
        continuation = "VoxTell patch-level sigmoid alignment"

    table = pd.DataFrame([
        {"experiment": "Anchor85 baseline", **baseline_summary},
        {"experiment": "Experiment 5 COLIPRI text", **exp5_summary},
        {"experiment": "Experiment B patch alignment", **expb_summary},
    ])
    table.to_csv(EXPB / "final_two_experiment_summary.csv", index=False)
    report = f"""# Final Two-Experiment Report

All full-volume comparisons use the same fixed stratified 30 cases (49 findings) and threshold 0.5.

## Results

```
{table.to_string(index=False)}
```

## Required Answers

1. **Did COLIPRI text replacement recover positive Dice by 300 steps?** Partial numerical recovery: {patch_recovered}, from {float(row0.positive_dice):.6f} to {float(row300.positive_dice):.6f}, but the recovered value remained very low.
2. **Did it produce meaningful 30-case full-volume masks?** {meaningful}. Dice={exp5_summary['dice']:.6f}, hit rate={exp5_summary['hit_rate']:.4f}, empty predictions={exp5_summary['empty']}/{len(exp5)} findings.
3. **Did patch-level alignment learn positive/negative separation?** Reliable separation: {reliable_separation}; weak trend: {weak_separation}. Final validation AUROC={separation_auroc:.4f}, margin={separation_margin:+.5f}.
4. **Did patch alignment reduce FP or merely shrink masks?** It {fp_answer}. Mean FP delta={fp_change:+.1f} voxels, mean predicted-volume delta={pred_change:+.1f}, Dice delta={dice_change:+.6f} versus Anchor85.
5. **Which direction deserves continuation?** {continuation}.

## Provenance

- Experiment 5 results: `{EXP5 / 'text_replacement_30case_results.csv'}`
- Experiment B results: `{EXPB / 'patch_alignment_30case_results.csv'}`
- Anchor85 exact-subset reference predictions: `{BASELINE_DIR}`
"""
    (EXPB / "final_two_experiment_report.md").write_text(report)
    print(json.dumps({"status": "success", "continuation": continuation}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
