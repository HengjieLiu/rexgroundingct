#!/usr/bin/env python3
"""Patch-level LESS Correct-vs-Neutral/Wrong attenuation for the rescue pilot."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from acvl_utils.cropping_and_padding.padding import pad_nd_image
from voxtell.inference.predictor import VoxTellPredictor
from run_voxtell_rex_inference import load_entries, load_image, sorted_finding_keys


def measure(a: torch.Tensor, b: torch.Tensor) -> dict[str, float | int]:
    a = a.detach().float().flatten(); b = b.detach().float().flatten()
    return {
        "rel_l2": float((a - b).norm() / a.norm().clamp_min(1e-12)),
        "cosine": float(torch.nn.functional.cosine_similarity(a, b, dim=0, eps=1e-12)),
        "rms": float(torch.sqrt((a - b).square().mean())),
        "num_values": int(a.numel()),
    }


def load_cache(path: Path) -> dict[tuple[str, str, int], torch.Tensor]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    return {
        (str(record["split"]), str(record["case"]), int(record["finding_idx"])): value
        for record, value in zip(payload["records"], payload["token_features"])
    }


def pack(mapping: dict, keys: list[tuple[str, str, int]]) -> tuple[torch.Tensor, torch.Tensor]:
    values = [mapping[key] for key in keys]
    length = max(int(value.shape[0]) for value in values); hidden = int(values[0].shape[1])
    tokens = torch.zeros(1, len(values), length, hidden, dtype=torch.float16)
    valid = torch.zeros(1, len(values), length, dtype=torch.bool)
    for index, value in enumerate(values):
        tokens[0, index, : len(value)] = value.to(torch.float16)
        valid[0, index, : len(value)] = True
    return tokens, valid


def first_patch(predictor: VoxTellPredictor, image: np.ndarray) -> torch.Tensor:
    image = np.asarray(image, dtype=np.float32); image = image[None] if image.ndim == 3 else image
    data, _, _ = predictor.preprocess(image)
    data, _ = pad_nd_image(data, tuple(predictor.patch_size), "constant", {"value": 0}, True, None)
    slicer = predictor._internal_get_sliding_window_slicers(
        data.shape[1:], patch_size=tuple(predictor.patch_size)
    )[0]
    return data[slicer][None].contiguous().float().to(predictor.device)


def forward(model, patch, embedding, tokens, valid) -> dict[str, torch.Tensor]:
    final_decoder: list[torch.Tensor] = []
    handle = model.decoder.stages[-1].register_forward_hook(
        lambda _module, _inputs, output: final_decoder.append(output.detach())
    )
    try:
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            output = model(
                patch, embedding, token_features=tokens, token_valid_mask=valid
            )
        logits = output[0] if isinstance(output, (tuple, list)) else output
        skips = model.last_less_prompt_skips
        if skips is None or 2 not in skips or 4 not in skips:
            raise RuntimeError("Expected prompt-specific LESS level2/level4 features")
        if len(final_decoder) != int(embedding.shape[1]):
            raise RuntimeError(
                f"Expected one final-decoder call per prompt, got {len(final_decoder)}"
            )
        final = torch.stack(final_decoder, dim=1)
        return {
            "less_level2": skips[2].detach(),
            "less_level4": skips[4].detach(),
            "prompt_decoder_kv": skips[4].detach(),
            "final_decoder": final,
            "final_logits": logits.detach(),
        }
    finally:
        handle.remove()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--arm", required=True)
    parser.add_argument("--update", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--selected", type=Path,
        default=ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv",
    )
    parser.add_argument(
        "--prompt-cache", type=Path,
        default=ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/qwen_original_subset30.pt",
    )
    parser.add_argument("--dataset", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument(
        "--token-dir", type=Path,
        default=ROOT / "outputs/c2_semantic_p_token_causal_audit/token_caches",
    )
    parser.add_argument(
        "--samecase-pairs", type=Path,
        default=ROOT / "outputs/c2_semantic_p_token_causal_audit/samecase/eligible_pairs.csv",
    )
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)

    predictor = VoxTellPredictor(
        model_dir=str(ROOT / "VoxTell/voxtell_v1.1"),
        checkpoint_path=str(args.checkpoint.resolve()), device=torch.device("cuda:0"),
        load_text_backbone=False, amp_dtype="bfloat16",
    )
    model = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    model = model.to(predictor.device).eval()
    prompts = torch.load(args.prompt_cache, map_location="cpu", weights_only=False)
    embeddings = {
        (str(record["split"]), str(record["case"]), int(record["finding_idx"])): prompts["embeddings"][index].float()
        for index, record in enumerate(prompts["records"])
    }
    token_maps = {
        "correct": load_cache(args.token_dir / "correct.pt"),
        "neutral": load_cache(args.token_dir / "neutral.pt"),
        "wrong": load_cache(args.token_dir / "samecase_wrong.pt"),
    }
    eligible_frame = pd.read_csv(args.samecase_pairs)
    wrong_eligible = {
        (str(row.case), int(row.finding_idx))
        for row in eligible_frame[eligible_frame["eligible"]].itertuples()
    }
    cases = pd.read_csv(args.selected)["case"].astype(str).drop_duplicates().tolist()
    entries = {entry["name"]: entry for entry in load_entries(args.dataset, ["val"])}
    rows: list[dict] = []
    for case_number, case in enumerate(cases, 1):
        entry = entries[case]; entry["_split"] = "val"
        keys = [("val", case, int(index)) for index in sorted_finding_keys(entry)]
        embedding = torch.stack([embeddings[key] for key in keys])[None].to(predictor.device)
        patch = first_patch(predictor, load_image(args.image_dir / case)[0])
        packed = {name: pack(mapping, keys) for name, mapping in token_maps.items()}
        features = {
            name: forward(
                model, patch, embedding,
                values[0].to(predictor.device), values[1].to(predictor.device),
            )
            for name, values in packed.items()
        }
        for condition in ("neutral", "wrong"):
            for prompt_position, key in enumerate(keys):
                if condition == "wrong" and (case, key[2]) not in wrong_eligible:
                    continue
                for stage in features["correct"]:
                    rows.append({
                        "arm": args.arm, "update": args.update, "case": case,
                        "finding_idx": key[2], "condition": condition, "stage": stage,
                        **measure(
                            features["correct"][stage][:, prompt_position],
                            features[condition][stage][:, prompt_position],
                        ),
                    })
        del patch, embedding, packed, features
        torch.cuda.empty_cache()
        print(f"[{case_number}/30] {case}", flush=True)

    detail = pd.DataFrame(rows); detail.to_csv(args.output / "per_finding.csv", index=False)
    summary = detail.groupby(["arm", "update", "condition", "stage"], sort=False)[
        ["rel_l2", "cosine", "rms"]
    ].agg(["count", "mean", "median"]).reset_index()
    summary.columns = ["_".join(filter(None, map(str, column))).rstrip("_") for column in summary.columns]
    summary.to_csv(args.output / "summary.csv", index=False)
    (args.output / "metadata.json").write_text(json.dumps({
        "checkpoint": str(args.checkpoint.resolve()), "arm": args.arm, "update": args.update,
        "whole_sentence": "correct and byte-identical across conditions",
        "wrong_subset": "validated fixed30 same-case eligible findings only",
        "prompt_decoder_kv": "exact alias of conditioned LESS level4 memory",
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
