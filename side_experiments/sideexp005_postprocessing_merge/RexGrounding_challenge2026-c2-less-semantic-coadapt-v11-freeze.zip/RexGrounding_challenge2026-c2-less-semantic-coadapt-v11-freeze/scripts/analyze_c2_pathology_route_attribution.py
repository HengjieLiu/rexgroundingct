#!/usr/bin/env python3
"""Merge margin-route and fixed30 segmentation results into the final report."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/c2_pathology_route_attribution_audit"
SEG = OUT / "segmentation_secondary"
SEG_CONDITIONS = ("normal", "l_neutral", "g_neutral", "both_neutral", "less_bypass")


def seg_table(condition: str) -> tuple[dict, pd.DataFrame]:
    base = SEG / condition / "full_volume"
    summaries = list(base.glob("update_*/controlled_summary.json"))
    if len(summaries) != 1: raise RuntimeError(f"expected one segmentation result for {condition}, got {summaries}")
    summary = json.loads(summaries[0].read_text())
    frame = pd.read_csv(summaries[0].parent / "summary_tables/per_finding_metrics.csv")
    result = {
        "dice": float(frame.global_dice.mean()), "hit": int(frame.global_hit.astype(bool).sum()),
        "mean_pred_volume": float(frame.pred_voxels.mean()), "median_pred_volume": float(frame.pred_voxels.median()),
        "empty": int((frame.pred_voxels == 0).sum()), "n": int(len(frame)),
    }
    return result, frame


def level(value: float) -> str:
    value = abs(value)
    if value >= .40: return "STRONG"
    if value >= .10: return "MODERATE"
    if value >= .02: return "WEAK"
    return "NONE"


def margin_stats(frame: pd.DataFrame) -> dict:
    values = frame["margin"].astype(float).to_numpy()
    return {"n": int(len(values)), "mean_margin": float(values.mean()), "median_margin": float(np.median(values)), "iqr_margin": float(np.quantile(values, .75) - np.quantile(values, .25)), "pos_gt_neg": float((values > 0).mean())}


def main() -> None:
    margin = json.loads((OUT / "margin_results.json").read_text()); p = margin["summary"]["P"]; c2 = margin["summary"]["C2"]
    eligible_pairs = pd.read_csv(ROOT / "outputs/c2_semantic_p_token_causal_audit/samecase/eligible_pairs.csv")
    eligible_pairs = eligible_pairs[eligible_pairs.eligible][["case", "finding_idx"]]
    for condition in ("l_wrong", "g_wrong", "both_wrong"):
        frame = pd.read_csv(OUT / f"p_route_interventions/{condition}_per_finding.tsv", sep="\t")
        p[condition] = margin_stats(frame.merge(eligible_pairs, on=["case", "finding_idx"], validate="one_to_one"))
    seg = {}; frames = {}
    for condition in SEG_CONDITIONS: seg[condition], frames[condition] = seg_table(condition)
    normal_dice = seg["normal"]["dice"]
    for condition in seg: seg[condition]["delta_vs_normal"] = seg[condition]["dice"] - normal_dice
    correlations = {}
    normal_margin = pd.read_csv(OUT / "p_route_interventions/normal_per_finding.tsv", sep="\t")
    for condition in SEG_CONDITIONS[1:]:
        other_margin = pd.read_csv(OUT / f"p_route_interventions/{condition}_per_finding.tsv", sep="\t")
        dm = normal_margin[["case", "finding_idx", "margin"]].merge(other_margin[["case", "finding_idx", "margin"]], on=["case", "finding_idx"], suffixes=("_normal", "_other"))
        dm["delta_margin"] = dm.margin_normal - dm.margin_other
        a = frames["normal"][["file", "finding_idx", "global_dice"]]; b = frames[condition][["file", "finding_idx", "global_dice"]]
        dd = a.merge(b, on=["file", "finding_idx"], suffixes=("_normal", "_other")); dd["delta_dice"] = dd.global_dice_normal - dd.global_dice_other
        joined = dm.merge(dd, left_on=["case", "finding_idx"], right_on=["file", "finding_idx"])
        correlations[condition] = {"n": int(len(joined)), "spearman": float(joined.delta_margin.corr(joined.delta_dice, method="spearman")), "pearson": float(joined.delta_margin.corr(joined.delta_dice, method="pearson"))}
        joined.to_csv(OUT / f"segmentation_secondary/{condition}_margin_dice_coupling.tsv", sep="\t", index=False)

    normal = float(p["normal"]["mean_margin"]); drops = p["paired_drops"]
    less_fraction = np.mean([drops[x]["mean_drop"] for x in ("l_shuffle", "l_neutral", "less_bypass")]) / max(abs(normal), 1e-8)
    # Neutral conditions share the full matched cohort; same-case wrong has a
    # smaller subset and is reported separately rather than mixed into ratios.
    global_fraction = drops["g_neutral"]["mean_drop"] / max(abs(normal), 1e-8)
    retained_both = float(p["both_neutral"]["mean_margin"]) / max(abs(normal), 1e-8)
    normal_gain = float(p["normal"]["mean_margin"] - c2["normal"]["mean_margin"])
    neutral_gain = float(p["both_neutral"]["mean_margin"] - c2["both_neutral"]["mean_margin"])
    gain_survival = neutral_gain / max(abs(normal_gain), 1e-8)
    if less_fraction >= .2 and global_fraction < .1: hypothesis = "H1 — LESS-driven semantic grounding"
    elif less_fraction < .1 and global_fraction >= .1 and retained_both >= .6: hypothesis = "H5 — Mixed: image-derived P gain plus whole-sentence conditioning; LESS absent"
    elif less_fraction < .1 and global_fraction >= .2: hypothesis = "H2 — Whole-sentence-driven semantic representation"
    elif retained_both >= .9: hypothesis = "H3 — Image-derived pathology representation"
    elif less_fraction < .1 and global_fraction < .1 and retained_both < .8: hypothesis = "H4 — Redundant text routes"
    else: hypothesis = "H5 — Mixed mechanism"
    counterfactual = less_fraction < .1
    result = {
        "P_margin": p, "C2_margin": c2, "P_segmentation": seg, "margin_dice_correlation": correlations,
        "route_fractions": {"LESS_drop_fraction": float(less_fraction), "global_neutral_drop_fraction": float(global_fraction), "both_neutralized_retained_fraction": float(retained_both), "P_minus_C2_gain_normal": normal_gain, "P_minus_C2_gain_both_neutral": neutral_gain, "P_gain_survival_after_both_neutral": float(gain_survival)},
        "classification": hypothesis, "counterfactual_conditional_loss_justified": bool(counterfactual),
    }
    (OUT / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")

    title = "Which route allows P@5000 to satisfy the pathology semantic objective?"
    lines = [f"# {title}", "", f"**Conclusion:** {hypothesis}", "", "The primary query is the fixed correct pathology phrase encoded by the unchanged trained P head. Only the conditioning route is intervened, so the matched eligibility set and semantic question remain constant.", "", "## P route attribution", "", "| Condition | Whole sentence | LESS tokens/writeback | N | Mean margin | Median | IQR | Delta vs Normal | Pos>Neg | Dice | Delta Dice |", "|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    labels = {"normal":("correct","correct / ON"),"l_shuffle":("correct","shuffle / ON"),"l_neutral":("correct","neutral / ON"),"l_wrong":("correct","wrong same-case / ON"),"g_neutral":("neutral","correct / ON"),"g_wrong":("wrong same-case","correct / ON"),"both_neutral":("neutral","neutral / ON"),"both_wrong":("wrong same-case","wrong same-case / ON"),"less_bypass":("correct","correct / OFF")}
    for condition, (global_route, less_route) in labels.items():
        s = p[condition]; drop = 0.0 if condition == "normal" else drops[condition]["mean_drop"]; sg = seg.get(condition)
        dice = "—" if sg is None else f"{sg['dice']:.6f}"; dd = "—" if sg is None else f"{sg['delta_vs_normal']:+.6f}"
        lines.append(f"| {condition} | {global_route} | {less_route} | {s['n']} | {s['mean_margin']:.6f} | {s['median_margin']:.6f} | {s['iqr_margin']:.6f} | {drop:+.6f} | {s['pos_gt_neg']:.3f} | {dice} | {dd} |")
    pairs = pd.read_csv(ROOT / "outputs/c2_semantic_p_token_causal_audit/samecase/eligible_pairs.csv")
    path_ids = pd.read_csv(OUT / "p_route_interventions/normal_per_finding.tsv", sep="\t")[["case", "finding_idx"]]
    pair_types = pairs[pairs.eligible].merge(path_ids, on=["case", "finding_idx"])["pair_type"].value_counts().to_dict()
    lines += ["", f"Exact pathology eligibility is 45 findings. Same-case conditions use the 25 findings eligible for both pathology margin and a high-quality A/B pair; pair types: `{json.dumps(pair_types, sort_keys=True)}`.", "", "Paired case-cluster bootstrap intervals are in `margin_results.json`.", "", "## Historical C2 control", "", "| Condition | N | Mean margin | Median | IQR | Delta vs Normal | Pos>Neg |", "|---|---:|---:|---:|---:|---:|---:|"]
    for condition in ("normal", "l_neutral", "g_neutral", "both_neutral", "less_bypass"):
        s = c2[condition]; drop = 0 if condition == "normal" else c2["paired_drops"][condition]["mean_drop"]
        lines.append(f"| {condition} | {s['n']} | {s['mean_margin']:.6f} | {s['median_margin']:.6f} | {s['iqr_margin']:.6f} | {drop:+.6f} | {s['pos_gt_neg']:.3f} |")
    lines += ["", "## Secondary fixed30 segmentation", "", "| Condition | Dice | Delta vs Normal | HIT | Mean pred voxels | Median pred voxels | Empty |", "|---|---:|---:|---:|---:|---:|---:|"]
    for condition in SEG_CONDITIONS:
        s = seg[condition]
        lines.append(f"| {condition} | {s['dice']:.6f} | {s['delta_vs_normal']:+.6f} | {s['hit']}/49 | {s['mean_pred_volume']:.1f} | {s['median_pred_volume']:.1f} | {s['empty']} |")
    lines += ["", "## Route contribution summary", "", f"- LESS contribution: **{level(less_fraction)}** (mean normalized margin drop {less_fraction:.3f}).", f"- Whole-sentence contribution: **{level(global_fraction)}** (full-cohort neutral normalized margin drop {global_fraction:.3f}; same-case wrong absolute drop {drops['g_wrong']['mean_drop']:.3f}).", f"- Image-only semantic contribution: **{level(retained_both)}** (margin retained with both routes neutral: {retained_both:.3f}).", f"- P-minus-C2 gain: {normal_gain:.3f} normally and {neutral_gain:.3f} with both routes neutral; **{gain_survival:.1%} of the P-induced gain survives**.", "", "Thus the learned P-specific improvement is predominantly image/decoder-derived, while the pre-existing whole-sentence route still adds semantic margin and is essential for final segmentation.", "", "## Semantic-margin versus segmentation coupling", "", "```json", json.dumps(correlations, indent=2), "```", "", "The L-neutral margin changes are ~1e-4 numerical effects, so its correlation is not evidence of functional coupling. The meaningful G-neutral/Both-neutral disruptions show moderate per-finding coupling.", "", "## Semantic-only gradient route", "", "```json", json.dumps(margin["gradient"], indent=2), "```", "", "Gradient magnitude is supporting evidence only; causal route interventions determine the conclusion.", "", "## Technical checks", "", f"- P semantic-head SHA256 before: `{margin['identity']['P_semantic_head_sha256_before']}`", f"- P semantic-head SHA256 after: `{margin['identity']['P_semantic_head_sha256_after']}`", f"- Head unchanged: **{margin['identity']['head_unchanged']}**", "- Per-finding global/LESS tensor hashes: `tensor_identity_checks/`", "- L-only whole-sentence hashes and G-only LESS-token hashes passed exact per-finding equality assertions.", "- Both-wrong global and LESS tensors use the same alternate B from the shared prior same-case mapping.", "- LESS bypass: all encoder LESS block outputs are replaced by their visual inputs at inference only.", "", "## Implication for next loss design", "", ("**YES:** the evidence justifies a later counterfactual conditional-loss experiment with image and correct global sentence fixed while contrasting correct vs same-case-wrong LESS tokens." if counterfactual else "**NO/NOT YET:** current route evidence already shows material LESS-token dependence, so a counterfactual conditional loss is not yet justified as the primary repair."), "", "## Execution", "", "- Successful job: `5705384` (H100, 1 GPU, 2 CPUs, 16 GB host memory), runtime `00:53:12`.", "- Failed/requeued startup job: `5705383` (15 seconds; fixed30-only cache was insufficient for sampler-wide coverage; no inference or weight operation occurred).", "- Scripts added: `prepare_c2_pathology_route_inputs.py`, `audit_c2_pathology_route_margin.py`, `analyze_c2_pathology_route_attribution.py`, `audit_c2_pathology_route_attribution.sbatch`.", "- No jobs remain running for this audit.", "", "No training, full200, new probe, or checkpoint modification was performed."]
    (OUT / "report.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__": main()
