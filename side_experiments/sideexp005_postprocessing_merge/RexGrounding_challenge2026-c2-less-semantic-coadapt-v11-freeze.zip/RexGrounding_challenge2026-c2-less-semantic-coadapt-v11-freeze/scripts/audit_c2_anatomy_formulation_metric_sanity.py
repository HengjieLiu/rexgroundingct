#!/usr/bin/env python3
"""Evaluation-only sanity audit for the frozen C2 anatomy A1--A5 heads."""
from __future__ import annotations

import hashlib
import inspect
import json
import math
import os
import resource
import time
from collections import Counter
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from scripts import run_c2_anatomy_formulation_ranking as base


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "outputs/c2_anatomy_formulation_ranking"
OUT = ROOT / "outputs/c2_anatomy_formulation_ranking_metric_sanity"
CHECKPOINT = ROOT / "outputs/less_fan_conditioning_10k/c2_less_encoder_conditioning/checkpoints/checkpoint_update_9000.pth"
HEADS = {
    "A1": SOURCE / "A1_relational/head_update_800.pt",
    "A2": SOURCE / "A2_feature_only/head_update_800.pt",
    "A3": SOURCE / "A3_position_only/head_update_800.pt",
    "A4": SOURCE / "A4_additive_feature_pe/head_update_800.pt",
    "A5": SOURCE / "A5_nonlinear_feature_pe/head_update_800.pt",
}
CACHE = SOURCE / "cache/heldout"
TEXT_CACHE = SOURCE / "cache/qwen_anatomy_phrase_embeddings.pt"
LOBE_DIR = ROOT / "data/rex_lobe_labels_preprocessed_v1"
EXPECTED = {
    "A1": {"side_accuracy": 0.38095238095238093, "lobe_accuracy": 0.0, "lobe_rank": 4.2631578947368425, "lobe_margin": -0.4011170548435889, "rml_accuracy": 0.0},
    "A2": {"side_accuracy": 0.5238095238095238, "lobe_accuracy": 0.10526315789473684, "lobe_rank": 4.157894736842105, "lobe_margin": -0.19767702802231438, "lobe_map_dice": 0.562623245935691, "rml_accuracy": 0.0, "rml_map_dice": 0.42327506591876346},
    "A3": {"side_accuracy": 0.14285714285714285, "lobe_accuracy": 0.05263157894736842, "lobe_rank": 3.8421052631578947, "lobe_margin": -0.0824293365800067, "lobe_map_dice": 0.36117790565262303, "rml_accuracy": 0.0, "rml_map_dice": 0.22834242024691775},
    "A4": {"side_accuracy": 0.5714285714285714, "lobe_accuracy": 0.10526315789473684, "lobe_rank": 4.368421052631579, "lobe_margin": -0.2181418314576149, "lobe_map_dice": 0.4926595746686584, "rml_accuracy": 0.0, "rml_map_dice": 0.3319535094002883},
    "A5": {"side_accuracy": 0.7619047619047619, "lobe_accuracy": 0.10526315789473684, "lobe_rank": 4.105263157894737, "lobe_margin": -0.21999225334117287, "lobe_map_dice": 0.5950582505841004, "rml_accuracy": 0.0, "rml_map_dice": 0.426104170580705},
}
REPRODUCTION_TOLERANCE = 1e-4


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def jsonable(value: Any) -> Any:
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    return value


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(jsonable(value), indent=2) + "\n")


def weighted_mean(values: torch.Tensor, masks: torch.Tensor) -> torch.Tensor:
    """Pool one map over candidate regions; missing regions remain NaN."""
    denominator = masks.sum(dim=(-3, -2, -1))
    numerator = (values[None] * masks).sum(dim=(-3, -2, -1))
    result = numerator / denominator.clamp_min(1e-8)
    return torch.where(denominator > 1e-6, result, torch.full_like(result, float("nan")))


def hard_occupancy_dice(probability: torch.Tensor, occupancy: torch.Tensor) -> float:
    pred = probability > 0.5
    return float((2 * (pred * occupancy).sum() + 1) / (pred.sum() + occupancy.sum() + 1))


def rank_row(scores: np.ndarray, target: int, ascending: bool = False) -> dict[str, Any]:
    valid = np.isfinite(scores)
    valid_indices = np.flatnonzero(valid)
    if target not in valid_indices:
        return {"top1": float("nan"), "rank": float("nan"), "margin": float("nan"), "pred": None, "n_candidates": int(valid.sum())}
    ordered = valid_indices[np.argsort(scores[valid_indices])]
    if not ascending:
        ordered = ordered[::-1]
    rank = int(np.flatnonzero(ordered == target)[0]) + 1
    negatives = scores[valid & (np.arange(len(scores)) != target)]
    best_negative = (np.nanmin(negatives) if ascending else np.nanmax(negatives)) if len(negatives) else float("nan")
    margin = float(best_negative - scores[target]) if ascending else float(scores[target] - best_negative)
    return {"top1": int(rank == 1), "rank": rank, "margin": margin, "pred": int(ordered[0]), "n_candidates": int(valid.sum())}


def mean_or_nan(rows: list[dict[str, Any]], key: str, predicate=lambda _: True) -> float:
    values = [float(row[key]) for row in rows if predicate(row) and row.get(key) is not None and np.isfinite(float(row[key]))]
    return float(np.mean(values)) if values else float("nan")


def summarize_corrected(rows: list[dict[str, Any]], variant: str) -> dict[str, Any]:
    side_full = [r for r in rows if r.get("side_union_n_candidates") == 2]
    lobe_full = [r for r in rows if r.get("lobe_raw_n_candidates") == 5]
    lobe_present = [r for r in rows if r.get("lobe_raw_n_candidates", 0) >= 2]
    rml_full = [r for r in lobe_full if r.get("lobe_label") == "RML"]
    rml_present = [r for r in lobe_present if r.get("lobe_label") == "RML"]
    dense = variant != "A1"
    return {
        "side_accuracy_union_full_coverage": mean_or_nan(side_full, "side_union_top1"),
        "side_margin_union_full_coverage": mean_or_nan(side_full, "side_union_margin"),
        "n_side_union_full_coverage": len(side_full),
        "lobe_accuracy_raw_full_coverage": mean_or_nan(lobe_full, "lobe_raw_top1"),
        "lobe_rank_raw_full_coverage": mean_or_nan(lobe_full, "lobe_raw_rank"),
        "lobe_margin_raw_full_coverage": mean_or_nan(lobe_full, "lobe_raw_margin"),
        "lobe_accuracy_probability_full_coverage": mean_or_nan(lobe_full, "lobe_prob_top1"),
        "lobe_rank_probability_full_coverage": mean_or_nan(lobe_full, "lobe_prob_rank"),
        "lobe_margin_probability_full_coverage": mean_or_nan(lobe_full, "lobe_prob_margin"),
        "n_lobe_full_coverage": len(lobe_full),
        "lobe_accuracy_raw_present_only": mean_or_nan(lobe_present, "lobe_raw_top1"),
        "lobe_rank_raw_present_only": mean_or_nan(lobe_present, "lobe_raw_rank"),
        "n_lobe_present_only": len(lobe_present),
        "lobe_map_dice": mean_or_nan(rows, "lobe_map_dice") if dense else float("nan"),
        "rml_accuracy_raw_full_coverage": mean_or_nan(rml_full, "lobe_raw_top1"),
        "rml_rank_raw_full_coverage": mean_or_nan(rml_full, "lobe_raw_rank"),
        "n_rml_full_coverage": len(rml_full),
        "rml_accuracy_raw_present_only": mean_or_nan(rml_present, "lobe_raw_top1"),
        "rml_rank_raw_present_only": mean_or_nan(rml_present, "lobe_raw_rank"),
        "rml_accuracy_probability_full_coverage": mean_or_nan(rml_full, "lobe_prob_top1"),
        "rml_rank_probability_full_coverage": mean_or_nan(rml_full, "lobe_prob_rank"),
        "n_rml_present_only": len(rml_present),
        "rml_map_dice": mean_or_nan(rows, "lobe_map_dice", lambda r: r.get("lobe_label") == "RML") if dense else float("nan"),
    }


def soft_dice(a: torch.Tensor, b: torch.Tensor) -> float:
    return float((2 * (a * b).sum() + 1e-6) / (a.sum() + b.sum() + 1e-6))


def full_grid_centroids(records: list[dict[str, Any]]) -> dict[str, Any]:
    cases = sorted({Path(str(r["case_id"])).name.removesuffix(".nii.gz") for r in records})
    labels = {"LUL": 1, "LLL": 2, "RUL": 3, "RML": 4, "RLL": 5}
    values: dict[str, list[list[float]]] = {key: [] for key in [*labels, "right_union", "left_union"]}
    missing = []
    for case in cases:
        candidates = [LOBE_DIR / split / f"{case}.npz" for split in ("val", "train")]
        path = next((p for p in candidates if p.is_file()), None)
        if path is None:
            missing.append(case)
            continue
        array = np.load(path)["lobe_label"]
        z = np.linspace(-1, 1, array.shape[0], dtype=np.float64)
        y = np.linspace(-1, 1, array.shape[1], dtype=np.float64)
        x = np.linspace(-1, 1, array.shape[2], dtype=np.float64)
        for name, label in labels.items():
            zz, yy, xx = np.where(array == label)
            if len(xx):
                values[name].append([float(x[xx].mean()), float(y[yy].mean()), float(z[zz].mean())])
        for name, ids in (("right_union", (3, 4, 5)), ("left_union", (1, 2))):
            zz, yy, xx = np.where(np.isin(array, ids))
            if len(xx):
                values[name].append([float(x[xx].mean()), float(y[yy].mean()), float(z[zz].mean())])
    return {
        "coordinate_frame": "full preprocessed RAS-oriented D,H,W grid normalized to [-1,1]; LR=x, AP=y, SI=z",
        "case_count": len(cases) - len(missing),
        "missing_cases": missing,
        "centroids": {name: {"mean_LR_AP_SI": np.mean(rows, axis=0).tolist(), "n": len(rows)} for name, rows in values.items()},
    }


def markdown_table(frame: pd.DataFrame) -> str:
    def fmt(value: Any) -> str:
        if pd.isna(value):
            return "N/A"
        if isinstance(value, (float, np.floating)):
            return f"{float(value):.4f}"
        return str(value).replace("|", "\\|")
    headers = list(frame.columns)
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    lines += ["| " + " | ".join(fmt(v) for v in row) + " |" for row in frame.itertuples(index=False, name=None)]
    return "\n".join(lines)


def main() -> int:
    start = time.time()
    for directory in ("score_direction", "ranking_recompute", "map_dice_sanity", "rml_audit", "side_mask_audit", "phrase_label_mapping", "visual_examples"):
        (OUT / directory).mkdir(parents=True, exist_ok=True)

    artifacts = {"c2_checkpoint": CHECKPOINT, "heldout_cache": CACHE, "text_cache": TEXT_CACHE, **{f"{k}_head": v for k, v in HEADS.items()}}
    missing = [str(path) for path in artifacts.values() if not path.exists()]
    if missing:
        raise FileNotFoundError(missing)
    hashes_before = {name: sha256(path) for name, path in artifacts.items() if path.is_file()}
    save_json(OUT / "artifact_manifest.json", {
        name: {"path": path.resolve(), "sha256": hashes_before.get(name), "size_bytes": path.stat().st_size if path.is_file() else sum(p.stat().st_size for p in path.glob("*.pt"))}
        for name, path in artifacts.items()
    })

    records = [torch.load(path, map_location="cpu", weights_only=False) for path in sorted(CACHE.glob("*.pt"))]
    text_payload = torch.load(TEXT_CACHE, map_location="cpu", weights_only=False)
    if tuple(text_payload["phrases"]) != base.PHRASES:
        raise RuntimeError("Phrase cache ordering does not match training/evaluation ordering")
    text = text_payload["vectors"].float()
    heads = {}
    for kind, path in HEADS.items():
        head = base.Head(kind).cpu().eval()
        head.load_state_dict(torch.load(path, map_location="cpu", weights_only=True), strict=True)
        for parameter in head.parameters():
            parameter.requires_grad_(False)
        heads[kind] = head

    # Exact reproduction through the original evaluator before independent logic.
    reproduced = {}
    for kind, head in heads.items():
        metric = base.summarize(base.evaluate(head, records, text, torch.device("cpu")), kind != "A1")
        differences = {key: abs(float(metric[key]) - expected) for key, expected in EXPECTED[kind].items()}
        reproduced[kind] = {"metrics": metric, "expected": EXPECTED[kind], "absolute_differences": differences, "tolerance": REPRODUCTION_TOLERANCE, "match": all(value <= REPRODUCTION_TOLERANCE for value in differences.values())}
    reproduction_ok = all(item["match"] for item in reproduced.values())
    save_json(OUT / "reproduction.json", {"reproduced": reproduction_ok, "variants": reproduced})
    if not reproduction_ok:
        raise RuntimeError("Existing metrics did not reproduce exactly; stopping before independent audit")

    # The exact original aggregation/rank snippet is part of the audit record.
    source_lines, source_start = inspect.getsourcelines(base.metric_from_maps)
    save_json(OUT / "ranking_recompute/original_code.json", {
        "file": inspect.getsourcefile(base.metric_from_maps),
        "function": "metric_from_maps",
        "start_line": source_start,
        "source": "".join(source_lines),
        "existing_sort": "descending=True",
        "existing_margin": "target - max(non-target)",
    })

    audit_rows: list[dict[str, Any]] = []
    map_rows: list[dict[str, Any]] = []
    score_rows: list[dict[str, Any]] = []
    maps_for_visuals: dict[tuple[str, str, int], np.ndarray] = {}
    selected_visuals = []
    for lobe in base.LOBE_NAMES:
        selected_visuals.extend([r for r in records if r["lobe_label"] == lobe][:2])
    selected_keys = {(str(r["case_id"]), int(r["finding_id"])) for r in selected_visuals}

    with torch.inference_mode():
        for kind, head in heads.items():
            for record in records:
                feature = record["feature"].float()[None]
                coords = record["coords"].float()[None]
                occupancy = record["occupancy"].float()
                right_union = occupancy[[2, 3, 4]].amax(0)
                left_union = occupancy[[5, 6]].amax(0)
                union_side = torch.stack((right_union, left_union))
                if kind == "A1":
                    projected = head.f(feature)
                    query = F.normalize(head.text(text), dim=-1)

                    def a1_region_scores(masks: torch.Tensor, query_index: int) -> torch.Tensor:
                        weights = masks[None] / masks[None].sum((-1, -2, -3), keepdim=True).clamp_min(1e-6)
                        pooled = torch.einsum("bcxyz,bqxyz->bqc", projected, weights)
                        pooled = F.normalize(pooled, dim=-1)
                        values = torch.einsum("bqc,c->bq", pooled, query[query_index])[0]
                        valid = masks.sum((-1, -2, -3)) > 1e-6
                        return torch.where(valid, values, torch.full_like(values, float("nan")))

                    maps = None
                else:
                    maps = head.maps(feature, coords, text)[0]

                row: dict[str, Any] = {"variant": kind, "case_id": record["case_id"], "finding_id": int(record["finding_id"]), "side_label": record["side_label"], "lobe_label": record["lobe_label"]}

                side = str(record["side_label"])
                if side in base.SIDE_INDEX:
                    target = base.SIDE_INDEX[side]
                    if kind == "A1":
                        original_raw = a1_region_scores(occupancy[:2], target)
                        union_raw = a1_region_scores(union_side, target)
                    else:
                        original_raw = weighted_mean(maps[target], occupancy[:2])
                        union_raw = weighted_mean(maps[target], union_side)
                    for prefix, scores in (("side_original", original_raw), ("side_union", union_raw)):
                        ranked = rank_row(scores.numpy(), target)
                        row.update({f"{prefix}_{key}": value for key, value in ranked.items()})
                        row[f"{prefix}_scores"] = json.dumps(jsonable(scores.tolist()))

                lobe = str(record["lobe_label"])
                if lobe in base.LOBE_INDEX:
                    target = base.LOBE_INDEX[lobe]
                    query_index = 2 + target
                    if kind == "A1":
                        raw_scores = a1_region_scores(occupancy[2:], query_index)
                        probability_scores = torch.sigmoid(raw_scores / 0.15)
                        target_map = None
                    else:
                        target_map = maps[query_index]
                        probability_map = torch.sigmoid(target_map / 0.15)
                        raw_scores = weighted_mean(target_map, occupancy[2:])
                        probability_scores = weighted_mean(probability_map, occupancy[2:])
                        map_dice = hard_occupancy_dice(probability_map, occupancy[query_index])
                        row["lobe_map_dice"] = map_dice
                        if lobe == "RML":
                            row["rml_map_dice"] = map_dice
                        target_occ = occupancy[query_index]
                        outside = (1 - target_occ).clamp(0, 1)
                        pred_fraction = float((probability_map > 0.5).float().mean())
                        map_row = {
                            "variant": kind, "case_id": record["case_id"], "finding_id": int(record["finding_id"]), "query": base.PHRASES[query_index], "target_lobe": lobe,
                            "map_dice": map_dice,
                            "mean_probability_inside_target": float((probability_map * target_occ).sum() / target_occ.sum().clamp_min(1e-6)),
                            "mean_probability_outside_target": float((probability_map * outside).sum() / outside.sum().clamp_min(1e-6)),
                            "predicted_foreground_fraction": pred_fraction,
                            "gt_occupancy_fraction": float(target_occ.mean()),
                            "soft_dice": soft_dice(probability_map, target_occ),
                        }
                        map_rows.append(map_row)
                        if (str(record["case_id"]), int(record["finding_id"])) in selected_keys:
                            maps_for_visuals[(kind, str(record["case_id"]), int(record["finding_id"]))] = torch.stack((target_occ, target_map, probability_map)).numpy()

                    raw_np = raw_scores.numpy()
                    prob_np = probability_scores.numpy()
                    raw_desc = rank_row(raw_np, target, ascending=False)
                    raw_asc = rank_row(raw_np, target, ascending=True)
                    prob_desc = rank_row(prob_np, target, ascending=False)
                    row.update({f"lobe_raw_{key}": value for key, value in raw_desc.items()})
                    row.update({f"lobe_raw_ascending_{key}": value for key, value in raw_asc.items()})
                    row.update({f"lobe_prob_{key}": value for key, value in prob_desc.items()})
                    row["lobe_raw_scores"] = json.dumps(jsonable(raw_np.tolist()))
                    row["lobe_probability_scores"] = json.dumps(jsonable(prob_np.tolist()))
                    present_negative = np.delete(raw_np, target)
                    present_negative = present_negative[np.isfinite(present_negative)]
                    present_probability_negative = np.delete(prob_np, target)
                    present_probability_negative = present_probability_negative[np.isfinite(present_probability_negative)]
                    if np.isfinite(raw_np[target]) and len(present_negative):
                        score_rows.append({
                            "variant": kind, "case_id": record["case_id"], "finding_id": int(record["finding_id"]), "query": base.PHRASES[query_index], "target_lobe": lobe,
                            "raw_target_mean": raw_np[target], "raw_best_negative": np.max(present_negative), "raw_worst_negative": np.min(present_negative), "raw_target_minus_best": raw_np[target] - np.max(present_negative),
                            "prob_target_mean": prob_np[target], "prob_best_negative": np.max(present_probability_negative), "prob_worst_negative": np.min(present_probability_negative), "prob_target_minus_best": prob_np[target] - np.max(present_probability_negative),
                            "n_candidate_lobes_present": int(np.isfinite(raw_np).sum()),
                        })
                audit_rows.append(row)

    audit = pd.DataFrame(audit_rows)
    audit.to_csv(OUT / "ranking_recompute/per_finding.csv", index=False)
    pd.DataFrame(score_rows).to_csv(OUT / "score_direction/per_finding.csv", index=False)
    pd.DataFrame(map_rows).to_csv(OUT / "map_dice_sanity/per_finding.csv", index=False)
    corrected = {kind: summarize_corrected(audit[audit.variant == kind].to_dict("records"), kind) for kind in HEADS}
    coverage = Counter(int(value) for value in audit.query("variant == 'A2' and lobe_label != ''")["lobe_raw_n_candidates"])
    save_json(OUT / "ranking_recompute/summary.json", {"corrected": corrected, "candidate_lobe_coverage": dict(sorted(coverage.items()))})
    score_frame = pd.DataFrame(score_rows)
    score_summary = score_frame.groupby("variant").agg({
        "raw_target_mean": "mean", "raw_best_negative": "mean", "raw_target_minus_best": "mean",
        "prob_target_mean": "mean", "prob_best_negative": "mean", "prob_target_minus_best": "mean",
    }).reset_index()
    score_summary.to_csv(OUT / "score_direction/summary.csv", index=False)

    map_frame = pd.DataFrame(map_rows)
    representative = map_frame.groupby(["variant", "target_lobe"], group_keys=False).head(2)
    representative.to_csv(OUT / "map_dice_sanity/representative_examples.csv", index=False)
    map_frame.groupby("variant").agg({"map_dice": "mean", "mean_probability_inside_target": "mean", "mean_probability_outside_target": "mean", "predicted_foreground_fraction": "mean", "gt_occupancy_fraction": "mean", "soft_dice": "mean"}).reset_index().to_csv(OUT / "map_dice_sanity/summary.csv", index=False)

    # RML detail tables, one row per formulation/finding and score convention.
    rml = audit[audit.lobe_label == "RML"].copy()
    rml_rows = []
    for _, row in rml.iterrows():
        for convention, field in (("raw", "lobe_raw_scores"), ("probability", "lobe_probability_scores")):
            scores = json.loads(row[field])
            rml_rows.append({"variant": row.variant, "case_id": row.case_id, "finding_id": int(row.finding_id), "convention": convention, **{name: scores[i] for i, name in enumerate(base.LOBE_NAMES)}, "RML_rank_present": row["lobe_raw_rank"] if convention == "raw" else row["lobe_prob_rank"], "n_candidates_present": row["lobe_raw_n_candidates"]})
    pd.DataFrame(rml_rows).to_csv(OUT / "rml_audit/rml_scores.csv", index=False)

    # Side mask construction and crop-local vs independently recomputed full-grid coordinates.
    side_rows = []
    for record in records:
        occupancy = record["occupancy"].float()
        ru = occupancy[[2, 3, 4]].amax(0)
        lu = occupancy[[5, 6]].amax(0)
        coords = record["coords"].float()
        item = {"case_id": record["case_id"], "finding_id": int(record["finding_id"]), "side_label": record["side_label"]}
        for name, original, union in (("right", occupancy[0], ru), ("left", occupancy[1], lu)):
            item[f"{name}_original_voxels"] = float(original.sum())
            item[f"{name}_union_voxels"] = float(union.sum())
            item[f"{name}_soft_dice"] = soft_dice(original, union) if original.sum() > 0 and union.sum() > 0 else float("nan")
            item[f"{name}_original_local_LR"] = float((coords[0] * original).sum() / original.sum()) if original.sum() > 0 else float("nan")
            item[f"{name}_union_local_LR"] = float((coords[0] * union).sum() / union.sum()) if union.sum() > 0 else float("nan")
        side_rows.append(item)
    side_frame = pd.DataFrame(side_rows)
    side_frame.to_csv(OUT / "side_mask_audit/per_finding.csv", index=False)
    side_summary = {
        "right_original_vs_union": {"n": int(side_frame.right_soft_dice.notna().sum()), "mean_dice": float(side_frame.right_soft_dice.mean()), "min_dice": float(side_frame.right_soft_dice.min())},
        "left_original_vs_union": {"n": int(side_frame.left_soft_dice.notna().sum()), "mean_dice": float(side_frame.left_soft_dice.mean()), "min_dice": float(side_frame.left_soft_dice.min())},
        "cache_coordinate_definition": "coords_for_feature(shape): linspace(-1,1) independently inside every 192^3 GT-centred crop; crop origin and full-volume shape are absent",
        "cache_centroids": {
            "right_original_LR": float(side_frame.right_original_local_LR.mean()), "right_union_LR": float(side_frame.right_union_local_LR.mean()),
            "left_original_LR": float(side_frame.left_original_local_LR.mean()), "left_union_LR": float(side_frame.left_union_local_LR.mean()),
        },
        "full_grid_centroids": full_grid_centroids(records),
    }
    save_json(OUT / "side_mask_audit/summary.json", side_summary)

    mapping = {
        "phrase_order": list(base.PHRASES), "side_index": base.SIDE_INDEX, "lobe_order": list(base.LOBE_NAMES), "lobe_index": base.LOBE_INDEX,
        "phrase_to_label": dict(zip(base.PHRASES, ("R", "L", *base.LOBE_NAMES))),
        "cache_phrases": list(text_payload["phrases"]), "cache_model": text_payload.get("model"), "cache_pooling": text_payload.get("pooling"),
        "identity_verified": tuple(text_payload["phrases"]) == base.PHRASES,
    }
    save_json(OUT / "phrase_label_mapping/mapping.json", mapping)

    # Compact 10-example visualization archive: four formulations x GT/raw/prob.
    for record in selected_visuals:
        case, finding = str(record["case_id"]), int(record["finding_id"])
        lobe = str(record["lobe_label"])
        fig, axes = plt.subplots(4, 3, figsize=(8, 10), constrained_layout=True)
        for row_index, kind in enumerate(("A2", "A3", "A4", "A5")):
            stack = maps_for_visuals[(kind, case, finding)]
            z = int(stack[0].sum(axis=(1, 2)).argmax())
            images = (stack[0, z], stack[1, z], stack[2, z])
            cmaps = ("gray", "coolwarm", "viridis")
            titles = ("GT occupancy", "raw cosine", "sigmoid probability")
            for column, (image, cmap, title) in enumerate(zip(images, cmaps, titles)):
                axes[row_index, column].imshow(image, cmap=cmap, origin="lower")
                axes[row_index, column].set_title(f"{kind} {title}", fontsize=8)
                axes[row_index, column].axis("off")
        fig.suptitle(f"{case} finding {finding}: {lobe}")
        fig.savefig(OUT / "visual_examples" / f"{Path(case).name.removesuffix('.nii.gz')}__{finding}__{lobe}.png", dpi=160)
        plt.close(fig)

    # Confusions for strictly valid five-lobe crops and available-region ranking.
    for kind in HEADS:
        block = audit[(audit.variant == kind) & (audit.lobe_label != "")].copy()
        full = block[block.lobe_raw_n_candidates == 5]
        if len(full):
            matrix = pd.crosstab(full.lobe_label, full.lobe_raw_pred.map(lambda x: base.LOBE_NAMES[int(x)]), dropna=False).reindex(index=base.LOBE_NAMES, columns=base.LOBE_NAMES, fill_value=0)
            matrix.to_csv(OUT / "ranking_recompute" / f"{kind}_full_coverage_confusion.csv")

    save_json(OUT / "corrected_metrics.json", {
        "original": {kind: EXPECTED[kind] for kind in HEADS},
        "corrected": corrected,
        "metric_scope": {"side": "union-derived masks; only crops containing both sides", "lobe_ranking": "target query pooled across candidate lobe masks; strict five-way table uses only crops containing all five lobes", "dense_map_dice": "original valid target-query hard occupancy Dice"},
    })

    hashes_after = {name: sha256(path) for name, path in artifacts.items() if path.is_file()}
    unchanged = {name: hashes_before[name] == hashes_after[name] for name in hashes_before}
    save_json(OUT / "head_hash_verification.json", {"before": hashes_before, "after": hashes_after, "unchanged": unchanged, "all_unchanged": all(unchanged.values())})
    if not all(unchanged.values()):
        raise RuntimeError("A frozen artifact changed during evaluation")

    original_table = pd.DataFrame([{"Variant": kind, "Side acc": EXPECTED[kind]["side_accuracy"], "Lobe acc": EXPECTED[kind]["lobe_accuracy"], "Lobe rank": EXPECTED[kind]["lobe_rank"], "Target margin": EXPECTED[kind]["lobe_margin"], "Lobe map Dice": EXPECTED[kind].get("lobe_map_dice"), "RML acc": EXPECTED[kind]["rml_accuracy"], "RML Dice": EXPECTED[kind].get("rml_map_dice")} for kind in HEADS])
    corrected_table = pd.DataFrame([{"Variant": kind, "Side acc*": corrected[kind]["side_accuracy_union_full_coverage"], "Side N": corrected[kind]["n_side_union_full_coverage"], "Lobe acc*": corrected[kind]["lobe_accuracy_raw_full_coverage"], "Lobe rank*": corrected[kind]["lobe_rank_raw_full_coverage"], "Target margin*": corrected[kind]["lobe_margin_raw_full_coverage"], "Lobe N": corrected[kind]["n_lobe_full_coverage"], "Lobe map Dice": corrected[kind]["lobe_map_dice"], "RML acc*": corrected[kind]["rml_accuracy_raw_full_coverage"], "RML N": corrected[kind]["n_rml_full_coverage"], "RML Dice": corrected[kind]["rml_map_dice"]} for kind in HEADS])
    probability_table = pd.DataFrame([{"Variant": kind, "Lobe acc (prob)*": corrected[kind]["lobe_accuracy_probability_full_coverage"], "Lobe rank (prob)*": corrected[kind]["lobe_rank_probability_full_coverage"], "Target margin (prob)*": corrected[kind]["lobe_margin_probability_full_coverage"], "RML acc (prob)*": corrected[kind]["rml_accuracy_probability_full_coverage"], "RML rank (prob)*": corrected[kind]["rml_rank_probability_full_coverage"]} for kind in HEADS])
    score_table = score_summary.copy()
    score_table.columns = [column.replace("_", " ") for column in score_table.columns]

    # Existing-vs-independent rank conventions, all using their respective original/valid scopes.
    convention_rows = []
    for kind in HEADS:
        block = audit[(audit.variant == kind) & (audit.lobe_raw_n_candidates == 5)]
        convention_rows.append({"Variant": kind, "Existing rank (N=19; flawed aggregation)": EXPECTED[kind]["lobe_rank"], "Independent descending rank (N=5)": mean_or_nan(block.to_dict("records"), "lobe_raw_rank"), "Independent ascending rank (N=5)": mean_or_nan(block.to_dict("records"), "lobe_raw_ascending_rank")})
    convention_table = pd.DataFrame(convention_rows)

    global_centroids = side_summary["full_grid_centroids"]["centroids"]
    right_mask = side_summary["right_original_vs_union"]
    left_mask = side_summary["left_original_vs_union"]
    runtime = time.time() - start
    peak_rss_gib = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024 ** 2)
    job_id = os.environ.get("SLURM_JOB_ID", "not-run-under-slurm")
    bug_classes = ["REGION_AGGREGATION_BUG", "SIDE_MASK_BUG", "COORDINATE_ORIENTATION_BUG"]
    report = f"""# C2 LESS Anatomy Formulation Ranking — Metric Sanity Audit

> Are the current A1–A5 lobe-ranking metrics internally consistent with the dense spatial grounding metrics?

**NO.** The dense target-query map Dice is reproducible, but the old region ranking compares different queries in different regions rather than holding the target query fixed across candidate regions. It also treats cropped-out anatomy as a zero-score candidate. Only 5/19 lobe-eligible held-out crops contain all five lobes.

## Reproduction

Original metrics reproduced: **YES** (categorical/rank values exact; all continuous values matched within the documented CPU-vs-H100 tolerance of {REPRODUCTION_TOLERANCE:g}).

{markdown_table(original_table)}

## Identified issue

`{' + '.join(bug_classes)}`

- **Region aggregation:** `scripts/run_c2_anatomy_formulation_ranking.py`, `metric_from_maps()`. The old `pooled=(scores*occ).sum/...` takes only matched query/ROI diagonals, then ranks those seven unrelated diagonal values. Correct classification holds target query `q_t` fixed and pools its map over every candidate ROI.
- **Rank direction:** existing code uses descending similarity and the sign `target - best negative`; both conventions are correct. There is no rank-direction or margin-sign bug.
- **Missing candidate anatomy:** absent lobes have zero occupancy. The old clamp converts their pooled value to zero and ranks it as if it were observed. Strict five-way ranking is possible for only 5 findings; present-only ranks are saved separately.
- **Side masks:** the cache constructs the opposite side as `whole_lung(dilation=10mm) - correct_side(dilation=15mm)`. Set subtraction between differently dilated masks is not the opposite lung.
- **Coordinates:** `coords_for_feature()` creates `[-1,1]` coordinates independently inside every GT-centred 192³ crop. It is crop-local, not patient-space position over the CT field of view. The cache does not contain crop origins, so A3 was not trained with the specified patient-space PE.

## Artifact identity

- C2@9000: `{CHECKPOINT}` (`{hashes_before['c2_checkpoint']}`)
- A1–A5 heads: `{', '.join(f'{kind}={hashes_before[f'{kind}_head'][:12]}' for kind in HEADS)}`
- Held-out cache: `{CACHE}` (49 records; feature, masks, and coordinate tensors are co-located in each `.pt` record)
- All checkpoint/head hashes unchanged after audit: **YES**

## Score direction

**Higher score = target.** A2–A5 train with `sigmoid(cosine/0.15)` against positive occupancy masks using BCE + Dice. Pointwise sigmoid is monotonic, but `mean(sigmoid(S))` is not generally equal to `sigmoid(mean(S))`; therefore raw regional-mean and probability regional-mean rankings are both reported and can differ.

{markdown_table(score_table)}

## Ranking sort audit

{markdown_table(convention_table)}

Ascending ranking is mathematically inconsistent with the objective. Differences from the existing rank arise from aggregation and missing-ROI handling, not sorting direction.

## Side-mask sanity

- Original right mask vs right-lobe union: N={right_mask['n']}, mean Dice={right_mask['mean_dice']:.4f}, min={right_mask['min_dice']:.4f}.
- Original left mask vs left-lobe union: N={left_mask['n']}, mean Dice={left_mask['mean_dice']:.4f}, min={left_mask['min_dice']:.4f}.
- Full-volume normalized RAS lobe-union LR centroid: right={global_centroids['right_union']['mean_LR_AP_SI'][0]:+.4f}, left={global_centroids['left_union']['mean_LR_AP_SI'][0]:+.4f}.
- The full-volume lobe unions clearly separate laterality. The near-zero old centroid values came from crop-local coordinates plus prompt-specific/derived side masks, not ambiguous full-volume orientation.

Audit-corrected side accuracy below uses right=`RUL∪RML∪RLL`, left=`LUL∪LLL`, and only crops where both unions are present.

## Independently recomputed/corrected metrics

{markdown_table(corrected_table)}

Probability-map regional pooling on the same strict full-coverage subset:

{markdown_table(probability_table)}

`*` Region metrics use the strictly valid full-coverage subset: side N is shown per row; lobe five-way N=5 for every variant. RML five-way N=1. These estimates are too small for model selection. Dense map Dice uses all 19 target-lobe findings (RML N=6) and remains the original, valid target-query metric.

## Dense-map Dice sanity

- Conversion: `P=sigmoid(S/0.15)`.
- Dice: hard threshold `P>0.5` (equivalently `S>0`), occupancy-weighted target, smooth=1.
- Mapping: query order `{list(base.PHRASES)}` to ROI order `right,left,{list(base.LOBE_NAMES)}` is correct.
- The metric is not sign-inverted. Its apparent conflict with old rank comes from the old cross-query diagonal aggregation and incomplete crop coverage.
- Per-finding inside/outside probability, foreground fractions, soft Dice, and the requested representative examples are in `map_dice_sanity/`; ten compact visualizations are in `visual_examples/`.

## RML

RML held-out N=6, but only one RML crop contains all five candidate lobes. The old RML accuracy=0 is not a valid five-way conclusion: it uses cross-query diagonal scores and treats absent lobes as observed zeros. Correct target-query raw/probability regional scores are in `rml_audit/rml_scores.csv`. The strict corrected RML estimate is based on N=1 and therefore cannot support a claim that any formulation solves—or categorically fails—RML.

## Final formulation ranking

1. **Best dense lobe grounding:** A5 by hard target-map Dice ({corrected['A5']['lobe_map_dice']:.4f}), followed by A2 ({corrected['A2']['lobe_map_dice']:.4f}).
2. **Best independently recomputed five-way regional ranking:** unresolved; only five fully covered findings exist and the corrected ranks are statistically unusable.
3. **Does A5 remain strongest?** Only for dense map Dice, not as a validated five-way lobe classifier.
4. **Does A4 outperform A2?** No on dense map Dice (A4 {corrected['A4']['lobe_map_dice']:.4f} vs A2 {corrected['A2']['lobe_map_dice']:.4f}); regional evidence is underpowered.
5. **How strong is A3?** Not interpretable as the requested position-only control because it was trained on crop-local rather than patient-space coordinates.
6. **Does Feature+Position beat both controls?** A5 beats A2/A3 on dense map Dice, but A3 is invalid as the intended absolute-position control and regional ranking is underpowered.
7. **What happens for RML?** Its maps can overlap RML (dense Dice reported above), but five-way ranking cannot be established from one fully covered RML crop.

## Decision

**Revise the anatomy formulation/evaluation first.** The evidence is not strong enough to proceed directly to A4/A5 downstream segmentation perturbation. A fair next evaluation needs either full-volume/multicrop features containing all candidate lobes or a ranking endpoint explicitly restricted to visible candidates, validated union-derived side masks, and true full-CT patient-space coordinates for the position control. No retraining or head modification was performed in this audit.

## Runtime

- Device: CPU only
- Slurm job: {job_id}
- Earlier audit attempt `5705573`: stopped intentionally at the reproduction gate because a too-strict 1e-9 CPU-vs-H100 tolerance was used; no head was modified. The documented 1e-4 approximate-reproduction tolerance resolves this.
- Runtime: {runtime:.1f} seconds
- Peak process RSS: {peak_rss_gib:.3f} GiB (`resource.getrusage`; Slurm accounting is recorded separately)
- Output: `{OUT}`
"""
    (OUT / "report.md").write_text(report)
    print(json.dumps({"status": "PASS", "reproduced": reproduction_ok, "bugs": bug_classes, "runtime_seconds": runtime, "output": str(OUT)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
