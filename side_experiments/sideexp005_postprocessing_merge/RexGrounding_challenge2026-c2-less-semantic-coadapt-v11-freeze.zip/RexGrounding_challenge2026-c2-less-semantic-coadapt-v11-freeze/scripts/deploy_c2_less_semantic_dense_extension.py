#!/usr/bin/env python3
"""Guard and deploy the corrected P1/P2 continuation from +1000 to +3000."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
from pathlib import Path


def load_json(path: Path) -> dict:
    if not path.is_file():
        raise FileNotFoundError(path)
    return json.loads(path.read_text())


def fixed30_summary(run: Path, relative: int) -> dict:
    raw = load_json(run / "full_volume" / f"update_{relative:05d}" / "controlled_summary.json")
    return {
        "relative_update": relative,
        "absolute_update": 9000 + relative,
        "dice": float(raw["mean_dice_per_finding"]),
        "hit": int(raw["hit_count"]),
        "mean_predicted_voxels": float(raw["mean_predicted_voxels"]),
        "empty": int(raw["empty_prediction_count"]),
    }


def semantic_training_summary(run: Path, arm: str) -> dict:
    rows = [json.loads(line) for line in (run / "history.jsonl").read_text().splitlines() if line.strip()]
    if not rows:
        raise RuntimeError(f"No training history in {run}")
    # Four microbatches per optimizer update; compare deterministic-length
    # beginning/end windows without pretending that sampled prompts are paired.
    window = min(800, len(rows))
    first, last = rows[:window], rows[-window:]

    def eligible_mean(part: list[dict], value_key: str, count_key: str) -> float | None:
        count = sum(int(row.get(count_key, 0)) for row in part)
        if count == 0:
            return None
        return sum(float(row.get(value_key, 0.0)) * int(row.get(count_key, 0)) for row in part) / count

    if arm == "P1":
        metrics = {
            "side_loss_first": eligible_mean(first, "less_semantic_side_loss_raw", "less_semantic_side_eligible_count"),
            "side_loss_last": eligible_mean(last, "less_semantic_side_loss_raw", "less_semantic_side_eligible_count"),
            "side_margin_first": eligible_mean(first, "less_semantic_side_margin_mean", "less_semantic_side_eligible_count"),
            "side_margin_last": eligible_mean(last, "less_semantic_side_margin_mean", "less_semantic_side_eligible_count"),
            "lobe_loss_first": eligible_mean(first, "less_semantic_lobe_loss_raw", "less_semantic_lobe_eligible_count"),
            "lobe_loss_last": eligible_mean(last, "less_semantic_lobe_loss_raw", "less_semantic_lobe_eligible_count"),
            "lobe_rank_first": eligible_mean(first, "less_semantic_lobe_target_rank_mean", "less_semantic_lobe_eligible_count"),
            "lobe_rank_last": eligible_mean(last, "less_semantic_lobe_target_rank_mean", "less_semantic_lobe_eligible_count"),
        }
    else:
        metrics = {
            "path_loss_first": eligible_mean(first, "less_semantic_path_loss_raw", "less_semantic_path_eligible_count"),
            "path_loss_last": eligible_mean(last, "less_semantic_path_loss_raw", "less_semantic_path_eligible_count"),
            "path_margin_first": eligible_mean(first, "less_semantic_path_margin_mean", "less_semantic_path_eligible_count"),
            "path_margin_last": eligible_mean(last, "less_semantic_path_margin_mean", "less_semantic_path_eligible_count"),
        }
    return {"history_rows": len(rows), "window_rows": window, **metrics}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--experiment", type=Path, required=True)
    parser.add_argument("--submit", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    experiment = args.experiment.resolve()
    source = load_json(
        root
        / "outputs/less_fan_conditioning_10k/c2_less_encoder_conditioning/full_volume/update_09000/controlled_summary.json"
    )
    baseline = {
        "dice": float(source["mean_dice_per_finding"]),
        "hit": int(source["hit_count"]),
        "mean_predicted_voxels": float(source["mean_predicted_voxels"]),
        "empty": int(source["empty_prediction_count"]),
    }
    decisions: dict[str, dict] = {}
    for arm, dirname in (("P1", "p1_dense_anatomy"), ("P2", "p2_dense_pathology")):
        run = experiment / dirname
        trajectory = [fixed30_summary(run, value) for value in (200, 500, 1000)]
        best = max(trajectory, key=lambda row: row["dice"])
        final = trajectory[-1]
        deltas = [row["dice"] - baseline["dice"] for row in trajectory]
        stable_count = sum(delta >= -0.001 for delta in deltas)
        volume_ratios = [row["mean_predicted_voxels"] / baseline["mean_predicted_voxels"] for row in trajectory]
        performance_pass = (
            (max(deltas) >= 0.002 or (max(deltas) >= 0.001 and final["dice"] >= baseline["dice"]))
            and stable_count >= 2
            and best["hit"] >= baseline["hit"] - 1
        )
        volume_pass = all(0.70 <= ratio <= 1.50 for ratio in volume_ratios) and all(
            row["empty"] <= baseline["empty"] + 2 for row in trajectory
        )
        checkpoint = run / "checkpoints/checkpoint_update_10000.pth"
        decision = {
            "baseline": baseline,
            "trajectory": trajectory,
            "dice_deltas": deltas,
            "volume_ratios": volume_ratios,
            "best": best,
            "semantic_training": semantic_training_summary(run, arm),
            "criteria": {
                "performance_pass": performance_pass,
                "volume_pass": volume_pass,
                "stable_checkpoint_count": stable_count,
            },
            "extend": bool(performance_pass and volume_pass and checkpoint.is_file()),
            "checkpoint": str(checkpoint),
        }
        decisions[arm] = decision

    output = experiment / "extension_decision.json"
    output.write_text(json.dumps(decisions, indent=2) + "\n")
    if args.submit:
        job_manifest: dict[str, dict] = {}
        prior_manifest = experiment / "extension_jobs.json"
        if prior_manifest.exists():
            raise RuntimeError(f"Refusing duplicate deployment; {prior_manifest} already exists")
        for arm, decision in decisions.items():
            if not decision["extend"]:
                job_manifest[arm] = {"submitted": False, "reason": "guard_not_passed"}
                continue
            env = os.environ.copy()
            env.update(
                {
                    "ROOT": str(root),
                    "EXP": str(experiment),
                    "ARM": arm,
                    "STAGE": "extend",
                    "START": decision["checkpoint"],
                }
            )
            result = subprocess.run(
                ["sbatch", "--parsable", "scripts/train_c2_less_semantic_alignment_dense_9000.sbatch"],
                cwd=root,
                env=env,
                check=True,
                text=True,
                capture_output=True,
            )
            training_job = result.stdout.strip().split(";")[0]
            validation_jobs: dict[str, str] = {}
            dependency = training_job
            for relative in (1200, 1500, 2000, 2500, 3000):
                validation_env = os.environ.copy()
                validation_env.update(
                    {
                        "ROOT": str(root),
                        "EXP": str(experiment),
                        "ARM": arm,
                        "RELATIVE": str(relative),
                    }
                )
                validation = subprocess.run(
                    [
                        "sbatch",
                        "--parsable",
                        f"--dependency=afterok:{dependency}",
                        "scripts/evaluate_c2_less_semantic_alignment_dense_fixed30.sbatch",
                    ],
                    cwd=root,
                    env=validation_env,
                    check=True,
                    text=True,
                    capture_output=True,
                )
                validation_job = validation.stdout.strip().split(";")[0]
                validation_jobs[str(relative)] = validation_job
                dependency = validation_job
            job_manifest[arm] = {
                "submitted": True,
                "training_job_id": training_job,
                "fixed30_job_ids": validation_jobs,
            }
        prior_manifest.write_text(json.dumps(job_manifest, indent=2) + "\n")
    print(json.dumps(decisions, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
