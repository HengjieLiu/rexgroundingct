#!/usr/bin/env python3
"""Matched safety decision for the control/treatment 2-update prechecks."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def history(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip() and '"train_loss"' in line]


def debug_identity(path: Path) -> list[tuple[str, ...]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return [
            (
                row.get("micro_step", ""), row.get("rank", ""), row.get("case_id", ""),
                row.get("finding_id", ""), row.get("prompt_position", ""),
                row.get("finding_text", ""), row.get("base_roi_kind", ""),
                row.get("fine_signature", ""), row.get("gate_applied", ""),
            )
            for row in csv.DictReader(handle)
        ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--control", type=Path, required=True)
    parser.add_argument("--treatment", type=Path, required=True)
    parser.add_argument("--router-audit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    control_summary = json.loads((args.control / "precheck_summary.json").read_text())
    treatment_summary = json.loads((args.treatment / "precheck_summary.json").read_text())
    control_history = history(args.control / "history.jsonl")
    treatment_history = history(args.treatment / "history.jsonl")
    same_samples = debug_identity(args.control / "roi_weight_debug.csv") == debug_identity(
        args.treatment / "roi_weight_debug.csv"
    )
    control_diag = control_summary["precheck_diagnostics"]
    treatment_diag = treatment_summary["precheck_diagnostics"]
    control_volume = sum(int(item["final_patch_predicted_voxels"]) for item in control_diag)
    treatment_volume = sum(int(item["final_patch_predicted_voxels"]) for item in treatment_diag)
    volume_ratio = treatment_volume / control_volume if control_volume else None
    first_control = float(control_history[0]["train_loss"])
    first_treatment = float(treatment_history[0]["train_loss"])
    # Compare the complete first accumulation window.  These losses are all
    # evaluated from identical parameters; after the first optimizer step the
    # two trajectories are intentionally no longer identical.
    first_step_end = next(
        (i + 1 for i, row in enumerate(control_history) if bool(row.get("optimizer_step_performed"))),
        1,
    )
    preupdate_loss_deltas = [
        float(treatment_history[i]["train_loss"]) - float(control_history[i]["train_loss"])
        for i in range(first_step_end)
    ]
    treatment_has_weighted_voxels = treatment_summary["upweighted_voxel_observations"] > 0
    decoder_grad_nonzero = all(
        float(row.get("grad_norm_decoder", 0) or 0) > 0
        for row in control_history + treatment_history
        if bool(row.get("optimizer_step_performed"))
    )
    # This experiment uses the 1/1 ``s3_extra_attention_gates`` path.  The
    # legacy ``grad_norm_s3_attention`` bucket is expected to be zero here.
    s3_grad_nonzero = all(
        (
            float(row.get("grad_norm_s3_attention", 0) or 0)
            + float(row.get("grad_norm_s3_extra_attention", 0) or 0)
        ) > 0
        for row in control_history + treatment_history
        if bool(row.get("optimizer_step_performed"))
    )
    router_audit = json.loads(args.router_audit.read_text())
    fine_router_audit_pass = bool(
        router_audit.get("status") == "PASS"
        and int(router_audit.get("selection_mismatch_rows", -1)) == 0
        and int(router_audit.get("training_router_selected", 0)) > 0
        and not bool(router_audit.get("roi_selection_uses_gt", True))
    )
    result = {
        "control_basic_pass": bool(control_summary["basic_pass"]),
        "treatment_basic_pass": bool(treatment_summary["basic_pass"]),
        "matched_sample_sequence": same_samples,
        "first_control_loss": first_control,
        "first_treatment_loss": first_treatment,
        "treatment_initial_loss_not_lower": first_treatment >= first_control,
        "preupdate_loss_deltas": preupdate_loss_deltas,
        "preupdate_mean_loss_delta": sum(preupdate_loss_deltas) / len(preupdate_loss_deltas),
        "treatment_preupdate_loss_differs_in_expected_direction": bool(
            max(preupdate_loss_deltas) > 0 and sum(preupdate_loss_deltas) > 0
        ),
        "treatment_has_upweighted_voxels": treatment_has_weighted_voxels,
        "decoder_grad_nonzero": decoder_grad_nonzero,
        "s3_grad_nonzero": s3_grad_nonzero,
        "fine_routed_in_random_gpu_microbatch_control": int(control_summary["fine_routed_count"]),
        "fine_routed_in_random_gpu_microbatch_treatment": int(treatment_summary["fine_routed_count"]),
        "fine_router_frozen_audit_pass": fine_router_audit_pass,
        "fine_router_audit_selected_rows": int(router_audit.get("training_router_selected", 0)),
        "control_final_patch_predicted_voxels": control_volume,
        "treatment_final_patch_predicted_voxels": treatment_volume,
        "treatment_control_patch_volume_ratio": volume_ratio,
        "volume_not_immediately_collapsed": bool(
            volume_ratio is not None and 0.5 <= volume_ratio <= 1.5
        ),
    }
    result["pass"] = all(
        (
            result["control_basic_pass"], result["treatment_basic_pass"],
            result["matched_sample_sequence"], result["treatment_initial_loss_not_lower"],
            result["treatment_preupdate_loss_differs_in_expected_direction"],
            result["treatment_has_upweighted_voxels"], result["decoder_grad_nonzero"],
            result["s3_grad_nonzero"], result["fine_router_frozen_audit_pass"],
            result["volume_not_immediately_collapsed"],
        )
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
