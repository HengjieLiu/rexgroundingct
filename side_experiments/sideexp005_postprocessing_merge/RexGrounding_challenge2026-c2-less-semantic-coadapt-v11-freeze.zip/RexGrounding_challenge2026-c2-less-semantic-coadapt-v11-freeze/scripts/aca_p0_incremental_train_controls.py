#!/usr/bin/env python3
"""Train three-seed cached lightweight controls for ACA P0 incremental value."""

from __future__ import annotations

import argparse
import csv
import json
import random
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn

from scripts.aca_p0_incremental_inference_ablation import forward_components, load_npz
from voxtell.model.aca_anatomy import (
    ACAAnatomyEncoder,
    ANATOMY_NAMES,
    PerAnatomyQueue,
    aca_contrastive_loss,
    soft_target_cross_entropy_rows,
)


ROOT = Path(__file__).resolve().parents[1]
LOBE_NAMES = ANATOMY_NAMES[:5]
SEEDS = (2027, 2028, 2029)
COMPONENT_VARIANTS = {
    "type_only": (False, True, False),
    "type_spatial": (False, True, True),
    "visual_only": (True, False, False),
    "visual_type": (True, True, False),
    "visual_spatial": (True, False, True),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


class TextClassifier(nn.Module):
    def __init__(self, mlp: bool) -> None:
        super().__init__()
        self.network = (
            nn.Sequential(nn.Linear(2560, 256), nn.GELU(), nn.LayerNorm(256), nn.Linear(256, 5))
            if mlp
            else nn.Linear(2560, 5)
        )

    def forward(self, text: torch.Tensor) -> torch.Tensor:
        return self.network(text)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def canonical_target(row: dict[str, str]) -> np.ndarray:
    target = np.asarray([float(row[f"gt_soft_{name}"]) for name in LOBE_NAMES])
    return target / max(target.sum(), 1e-12)


def score_rows(
    method: str,
    seed: int,
    probabilities: np.ndarray,
    cohort_rows: list[dict[str, str]],
) -> list[dict[str, Any]]:
    output = []
    for probability, cohort in zip(probabilities, cohort_rows):
        target = canonical_target(cohort)
        dominant = int(target.argmax())
        prediction = int(probability.argmax())
        right = float(probability[:3].sum())
        left = float(probability[3:].sum())
        true_side = cohort["gt_dominant_side"]
        predicted_side = "right" if right > left else "left"
        wrong = float(np.max(np.delete(probability, dominant)))
        output.append(
            {
                "method": method,
                "seed": seed,
                "case_id": cohort["case_id"],
                "finding_idx": int(cohort["finding_idx"]),
                "predicted_lobe": LOBE_NAMES[prediction],
                "top1_correct": prediction == dominant,
                "top2_correct": dominant in np.argsort(-probability, kind="stable")[:2],
                "predicted_side": predicted_side,
                "laterality_correct": predicted_side == true_side,
                "target_lobe_mass": float(probability[dominant]),
                "target_side_mass": right if true_side == "right" else left,
                "lobe_margin": float(probability[dominant] - wrong),
                "side_margin": abs(right - left) * (1 if predicted_side == true_side else -1),
                "cross_entropy": float(-(target * np.log(np.clip(probability, 1e-8, 1))).sum()),
                "brier": float(np.square(probability - target).sum()),
                **{f"score_{name}": float(probability[index]) for index, name in enumerate(LOBE_NAMES)},
            }
        )
    return output


def grouped_updates(train: dict[str, np.ndarray]) -> list[np.ndarray]:
    return [np.flatnonzero(train["update"] == update) for update in range(1, 101)]


def train_text(
    train: dict[str, np.ndarray],
    fixed: dict[str, np.ndarray],
    cohort_rows: list[dict[str, str]],
    *,
    mlp: bool,
    seed: int,
    device: torch.device,
    checkpoint_dir: Path,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    set_seed(seed)
    model = TextClassifier(mlp).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=3e-5)
    started = time.time()
    for indices in grouped_updates(train):
        valid = [index for index in indices if train["nonempty"][index] and train["target"][index, :5].sum() > 0]
        if not valid:
            continue
        text = torch.tensor(train["text"][valid, 0], device=device)
        target = torch.tensor(train["target"][valid, :5], device=device)
        target = target / target.sum(-1, keepdim=True).clamp_min(1e-8)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device.type, enabled=True, dtype=torch.bfloat16):
            logits = model(text)
            loss = soft_target_cross_entropy_rows(logits, target).mean()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 12.0)
        optimizer.step()
    with torch.no_grad(), torch.autocast(device.type, enabled=True, dtype=torch.bfloat16):
        logits = model(torch.tensor(fixed["text"][:, 0], device=device)).float()
        probability = torch.softmax(logits, -1).cpu().numpy()
    name = "text_only_mlp" if mlp else "text_only_linear"
    torch.save(model.state_dict(), checkpoint_dir / f"{name}_seed{seed}.pth")
    metadata = {
        "method": name,
        "seed": seed,
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
        "runtime_seconds": time.time() - started,
    }
    return score_rows(name, seed, probability, cohort_rows), metadata


def configure_component_gradients(
    model: ACAAnatomyEncoder,
    use_visual: bool,
    use_type: bool,
    use_spatial: bool,
) -> None:
    if not use_visual:
        for parameter in model.visual_projection.parameters():
            parameter.requires_grad_(False)
    if not use_type:
        for parameter in model.anatomy_type_embedding.parameters():
            parameter.requires_grad_(False)
    if not use_spatial:
        for parameter in model.spatial_mlp.parameters():
            parameter.requires_grad_(False)
        model.global_spatial_embedding.requires_grad_(False)


def train_component(
    train: dict[str, np.ndarray],
    fixed: dict[str, np.ndarray],
    cohort_rows: list[dict[str, str]],
    *,
    method: str,
    toggles: tuple[bool, bool, bool],
    seed: int,
    device: torch.device,
    checkpoint_dir: Path,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    use_visual, use_type, use_spatial = toggles
    set_seed(seed)
    model = ACAAnatomyEncoder(
        visual_dim=320,
        text_dim=2560,
        hidden_dim=256,
        projection_dim=256,
        transformer_layers=2,
        attention_heads=4,
        dropout=0.1,
    ).to(device)
    configure_component_gradients(model, use_visual, use_type, use_spatial)
    parameters = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.AdamW(parameters, lr=1e-4, weight_decay=3e-5)
    queue = PerAnatomyQueue(128, 256).to(device)
    started = time.time()
    for indices in grouped_updates(train):
        visual = torch.tensor(train["visual"][indices[:1]], device=device)
        if not use_visual:
            visual.zero_()
        present = torch.tensor(train["present"][indices[:1]], device=device, dtype=torch.bool)
        if method == "type_only":
            present[:] = True
        spatial = torch.tensor(train["spatial"][indices[:1]], device=device)
        text = torch.tensor(train["text"][indices][None], device=device)
        target = torch.tensor(train["target"][indices][None], device=device)
        overlap = torch.tensor(train["overlap"][indices][None], device=device)
        nonempty = torch.tensor(train["nonempty"][indices][None], device=device, dtype=torch.bool)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device.type, enabled=True, dtype=torch.bfloat16):
            output = forward_components(
                model, visual, present, spatial, text,
                use_type=use_type, use_spatial=use_spatial,
            )
            route_loss = soft_target_cross_entropy_rows(
                output["logits"][nonempty], target[nonempty]
            ).mean()
            patient_ids = [[str(train["source_case"][index]) for index in indices]]
            finding_ids = [[
                f"{train['source_case'][index]}:{int(train['finding_idx'][index])}"
                for index in indices
            ]]
            aca = aca_contrastive_loss(
                output["image_embedding"], output["text_embedding"],
                overlap, nonempty, patient_ids, finding_ids, queue,
                model.temperature(), min_overlap_threshold=0.05, update_queue=True,
            )
            loss = route_loss + aca.loss
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 12.0)
        optimizer.step()
    probabilities = []
    model.eval()
    with torch.no_grad():
        for row in range(len(cohort_rows)):
            visual = torch.tensor(fixed["visual"][row][None], device=device)
            if not use_visual:
                visual.zero_()
            present = torch.tensor(fixed["present"][row][None], device=device, dtype=torch.bool)
            if method == "type_only":
                present[:] = True
            spatial = torch.tensor(fixed["spatial"][row][None], device=device)
            text = torch.tensor(fixed["text"][row][None, None], device=device)
            with torch.autocast(device.type, enabled=True, dtype=torch.bfloat16):
                output = forward_components(
                    model, visual, present, spatial, text,
                    use_type=use_type, use_spatial=use_spatial,
                )
            probability = output["probability"][0, 0, :5].float()
            probability /= probability.sum().clamp_min(1e-8)
            probabilities.append(probability.cpu().numpy())
    torch.save(model.state_dict(), checkpoint_dir / f"{method}_seed{seed}.pth")
    metadata = {
        "method": method,
        "seed": seed,
        "parameter_count": sum(parameter.numel() for parameter in parameters),
        "runtime_seconds": time.time() - started,
        "use_visual": use_visual,
        "use_type": use_type,
        "use_spatial": use_spatial,
    }
    return score_rows(method, seed, np.asarray(probabilities), cohort_rows), metadata


def main() -> int:
    args = parse_args()
    device = torch.device(args.device)
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("Control training requires CUDA")
    torch.cuda.set_device(0 if device.index is None else device.index)
    train = load_npz(args.output_root / "p0_train_components.npz")
    fixed = load_npz(args.output_root / "p0_fixed30_components.npz")
    cohort_source = list(
        csv.DictReader((args.output_root / "cohort_manifest.csv").open(newline="", encoding="utf-8"))
    )
    cohort_by_key = {
        (row["case_id"], int(row["finding_idx"])): row for row in cohort_source
    }
    cohort_rows = [
        cohort_by_key[(str(fixed["anchor_case"][row]), int(fixed["finding_idx"][row]))]
        for row in range(len(fixed["finding_idx"]))
    ]
    checkpoint_dir = args.output_root / "checkpoints_for_controls"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    all_scores: list[dict[str, Any]] = []
    metadata: list[dict[str, Any]] = []
    for seed in SEEDS:
        for mlp in (False, True):
            scores, meta = train_text(
                train, fixed, cohort_rows, mlp=mlp, seed=seed,
                device=device, checkpoint_dir=checkpoint_dir,
            )
            all_scores.extend(scores)
            metadata.append(meta)
            print(meta, flush=True)
        for method, toggles in COMPONENT_VARIANTS.items():
            scores, meta = train_component(
                train, fixed, cohort_rows, method=method, toggles=toggles,
                seed=seed, device=device, checkpoint_dir=checkpoint_dir,
            )
            all_scores.extend(scores)
            metadata.append(meta)
            print(meta, flush=True)

    with (args.output_root / "control_per_finding.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(all_scores[0]))
        writer.writeheader()
        writer.writerows(all_scores)
    aggregate_rows = []
    for meta in metadata:
        selected = [
            row for row in all_scores
            if row["method"] == meta["method"] and row["seed"] == meta["seed"]
        ]
        aggregate_rows.append(
            {
                **meta,
                "cases": len({row["case_id"] for row in selected}),
                "findings": len(selected),
                "top1_accuracy": float(np.mean([row["top1_correct"] for row in selected])),
                "top2_accuracy": float(np.mean([row["top2_correct"] for row in selected])),
                "laterality_accuracy": float(np.mean([row["laterality_correct"] for row in selected])),
                "target_lobe_mass": float(np.mean([row["target_lobe_mass"] for row in selected])),
                "cross_entropy": float(np.mean([row["cross_entropy"] for row in selected])),
            }
        )
    with (args.output_root / "retrained_ablation_results.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        aggregate_fields = list(
            dict.fromkeys(field for row in aggregate_rows for field in row)
        )
        writer = csv.DictWriter(handle, fieldnames=aggregate_fields)
        writer.writeheader()
        writer.writerows(aggregate_rows)
    for filename, methods in (
        ("text_only_results.csv", {"text_only_linear", "text_only_mlp"}),
        ("type_only_results.csv", {"type_only", "type_spatial"}),
    ):
        selected = [row for row in aggregate_rows if row["method"] in methods]
        with (args.output_root / filename).open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=aggregate_fields)
            writer.writeheader()
            writer.writerows(selected)
    (args.output_root / "control_training_metadata.json").write_text(
        json.dumps(
            {
                "seeds": list(SEEDS),
                "updates": 100,
                "selection": "fixed update100; no validation selection because original P0 had none",
                "optimizer": "AdamW lr=1e-4 weight_decay=3e-5 clip=12",
                "runs": metadata,
                "gpu": torch.cuda.get_device_name(0),
            },
            indent=2,
        )
        + "\n"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
