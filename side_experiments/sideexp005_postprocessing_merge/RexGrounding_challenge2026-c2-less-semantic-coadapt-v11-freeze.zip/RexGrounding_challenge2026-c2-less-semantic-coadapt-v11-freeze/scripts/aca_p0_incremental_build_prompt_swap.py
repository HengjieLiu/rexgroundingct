#!/usr/bin/env python3
"""Build fixed30 left/right counterfactual embeddings and score frozen P0 routes."""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

import numpy as np
import torch
from transformers import AutoModel, AutoTokenizer

from scripts.aca_p0_incremental_inference_ablation import forward_components, load_npz
from voxtell.model.aca_anatomy import ACAAnatomyEncoder
from voxtell.utils.text_embedding import last_token_pool, wrap_with_instruction


ROOT = Path(__file__).resolve().parents[1]
ORIGINAL_CACHE = ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt"
P0_CHECKPOINT = ROOT / "outputs/aca_anatomy_p0_probe_20260730T225800Z_retry5_l40s/checkpoints/checkpoint_update_100.pth"
LR_PATTERN = re.compile(r"\b(left|right)\b", flags=re.IGNORECASE)
LOBE_NAMES = ("RUL", "RML", "RLL", "LUL", "LLL")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--text-model", default="Qwen/Qwen3-Embedding-4B")
    parser.add_argument("--batch-size", type=int, default=8)
    return parser.parse_args()


def preserve_case(source: str, replacement: str) -> str:
    if source.isupper():
        return replacement.upper()
    if source[:1].isupper():
        return replacement.capitalize()
    return replacement


def swap_left_right(text: str) -> str:
    def replace(match: re.Match[str]) -> str:
        source = match.group(0)
        replacement = "right" if source.lower() == "left" else "left"
        return preserve_case(source, replacement)
    return LR_PATTERN.sub(replace, text)


@torch.inference_mode()
def embed(prompts: list[str], model_name: str, device: torch.device, batch_size: int) -> torch.Tensor:
    tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side="left", local_files_only=True)
    model = AutoModel.from_pretrained(model_name, local_files_only=True).eval().to(device)
    output = []
    for start in range(0, len(prompts), batch_size):
        tokens = tokenizer(
            wrap_with_instruction(prompts[start : start + batch_size]),
            padding=True, truncation=True, max_length=8192, return_tensors="pt",
        ).to(device)
        hidden = model(**tokens).last_hidden_state
        output.append(last_token_pool(hidden, tokens["attention_mask"]).float().cpu())
        print(f"embedded {min(start + batch_size, len(prompts))}/{len(prompts)}", flush=True)
    del model, tokenizer
    torch.cuda.empty_cache()
    return torch.cat(output)


def side_mass(probability: np.ndarray, side: str) -> float:
    return float(probability[:3].sum() if side == "right" else probability[3:5].sum())


def main() -> int:
    args = parse_args()
    device = torch.device(args.device)
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("Prompt embedding requires CUDA")
    cohort = list(csv.DictReader((args.output_root / "cohort_manifest.csv").open(newline="", encoding="utf-8")))
    directional = [row for row in cohort if LR_PATTERN.search(row["prompt"])]
    swapped_prompts = [swap_left_right(row["prompt"]) for row in directional]
    swapped_embeddings = embed(swapped_prompts, args.text_model, device, args.batch_size)

    cache = torch.load(ORIGINAL_CACHE, map_location="cpu", weights_only=False)
    embeddings = cache["embeddings"].clone()
    record_index: dict[tuple[str, int], list[int]] = {}
    for index, record in enumerate(cache["records"]):
        record_index.setdefault((str(record["case"]), int(record["finding_idx"])), []).append(index)
    swap_records = []
    swapped_by_key = {}
    for row, embedding in zip(directional, swapped_embeddings):
        key = (row["case_id"], int(row["finding_idx"]))
        indices = record_index.get(key, [])
        if len(indices) != 1:
            raise AssertionError(f"Expected one embedding-cache record for {key}, found {indices}")
        embeddings[indices[0]] = embedding.to(embeddings.dtype)
        swapped_by_key[key] = embedding
        swap_records.append(
            {
                "case_id": key[0], "finding_idx": key[1],
                "original_prompt": row["prompt"], "swapped_prompt": swap_left_right(row["prompt"]),
                "parser_side": row["parser_side"],
                "evaluable_single_side": row["parser_side"] in {"left", "right"},
                "embedding_cache_index": indices[0],
            }
        )
    swapped_cache = {
        **cache,
        "embeddings": embeddings,
        "counterfactual_metadata": {
            "schema": "aca_p0_incremental_lr_swap_cache_v1",
            "source_cache": str(ORIGINAL_CACHE.resolve()),
            "semantic_transform": "whole-word left/right swap; all other text unchanged",
            "changed_records": len(swap_records),
        },
    }
    torch.save(swapped_cache, args.output_root / "qwen_prompt_embeddings_fixed30_lr_swapped.pt")
    base_manifest = json.loads((args.output_root / "fixed30_rex_manifest.json").read_text())
    directional_keys = {(row["case_id"], str(row["finding_idx"])) for row in swap_records}
    swap_entries = []
    for entry in base_manifest["val"]:
        if not any(
            (entry["name"], str(key)) in directional_keys
            for key in entry["findings"]
        ):
            continue
        # Keep every reference channel for selected cases so restored NIfTI output
        # remains shape-compatible; only directional cache entries are replaced.
        swap_entries.append(entry)
    swap_manifest = {
        "provenance": {
            "schema": "aca_p0_incremental_lr_swap_inference_manifest_v1",
            "source": str((args.output_root / "fixed30_rex_manifest.json").resolve()),
            "cases": len(swap_entries),
            "inference_findings_including_unchanged_channels": sum(
                len(entry["findings"]) for entry in swap_entries
            ),
            "counterfactual_findings": len(swap_records),
            "p1_artifacts_used": False,
        },
        "val": swap_entries,
    }
    (args.output_root / "fixed30_lr_swap_rex_manifest.json").write_text(
        json.dumps(swap_manifest, indent=2) + "\n"
    )

    fixed = load_npz(args.output_root / "p0_fixed30_components.npz")
    checkpoint = torch.load(P0_CHECKPOINT, map_location="cpu", weights_only=False)
    config = checkpoint["resolved_config"]
    model = ACAAnatomyEncoder(
        visual_dim=320, text_dim=2560, hidden_dim=int(config["hidden_dim"]),
        projection_dim=int(config["projection_dim"]), transformer_layers=2,
        attention_heads=4, dropout=0.1,
    ).to(device)
    model.load_state_dict(checkpoint["aca_weights"], strict=True)
    model.eval()
    fixed_index = {
        (str(fixed["anchor_case"][index]), int(fixed["finding_idx"][index])): index
        for index in range(len(fixed["finding_idx"]))
    }
    p0_rows = []
    for record in swap_records:
        key = (record["case_id"], int(record["finding_idx"]))
        row = fixed_index[key]
        visual = torch.tensor(fixed["visual"][row][None], device=device)
        present = torch.tensor(fixed["present"][row][None], device=device, dtype=torch.bool)
        spatial = torch.tensor(fixed["spatial"][row][None], device=device)
        texts = torch.stack((
            torch.tensor(fixed["text"][row, 0]), swapped_by_key[key],
        ))[None].to(device)
        with torch.no_grad(), torch.autocast(device.type, enabled=True, dtype=torch.bfloat16):
            probability = forward_components(model, visual, present, spatial, texts)["probability"][0, :, :5].float()
        probability /= probability.sum(-1, keepdim=True).clamp_min(1e-8)
        original, swapped = probability.cpu().numpy()
        original_side = record["parser_side"]
        desired_side = "left" if original_side == "right" else "right" if original_side == "left" else ""
        p0_rows.append(
            {
                **record,
                "desired_swapped_side": desired_side,
                "original_right_mass": float(original[:3].sum()),
                "swapped_right_mass": float(swapped[:3].sum()),
                "original_desired_side_mass": "" if not desired_side else side_mass(original, desired_side),
                "swapped_desired_side_mass": "" if not desired_side else side_mass(swapped, desired_side),
                "desired_side_mass_shift": "" if not desired_side else side_mass(swapped, desired_side) - side_mass(original, desired_side),
                **{f"original_{name}": float(original[index]) for index, name in enumerate(LOBE_NAMES)},
                **{f"swapped_{name}": float(swapped[index]) for index, name in enumerate(LOBE_NAMES)},
            }
        )
    for path, rows in (
        (args.output_root / "prompt_swap_manifest.csv", swap_records),
        (args.output_root / "p0_prompt_swap_results.csv", p0_rows),
    ):
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
    evaluable = [row for row in p0_rows if row["evaluable_single_side"]]
    summary = {
        "directional_findings": len(swap_records),
        "directional_cases": len(swap_entries),
        "single_side_evaluable": len(evaluable),
        "p0_mean_desired_side_mass_shift": float(np.mean([row["desired_side_mass_shift"] for row in evaluable])),
        "p0_fraction_shifted_toward_swapped_side": float(np.mean([row["desired_side_mass_shift"] > 0 for row in evaluable])),
    }
    (args.output_root / "p0_prompt_swap_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
