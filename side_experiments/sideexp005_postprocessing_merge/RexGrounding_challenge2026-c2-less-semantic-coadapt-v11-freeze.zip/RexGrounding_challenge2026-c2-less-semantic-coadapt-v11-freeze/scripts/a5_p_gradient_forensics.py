#!/usr/bin/env python3
"""Read-only gradient forensics for the original-VoxTell A5/P semantic screen.

This script intentionally makes no optimizer step, does not alter a checkpoint,
and never runs validation inference.  It replays one deterministic canonical
positive crop at a time, then measures separate autograd gradients for the
historical segmentation and auxiliary objectives.
"""
from __future__ import annotations

import argparse
import inspect
import json
import math
import random
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]

from scripts import run_c2_anatomy_formulation_ranking as historical  # noqa: E402
from scripts import train_voxtell_rex_full_nnunet_aug as tr  # noqa: E402
from scripts.original_voxtell_semantic_screen_losses import (  # noqa: E402
    ANATOMY_PHRASES,
    A5ImagePositionHead,
    NativeFeatureCapture,
    PathologyRegionAlignmentHead,
    a5_contrast_objective,
    a5_dense_objective,
    anatomy_occupancy,
    global_preprocessed_coordinates,
)

EXP = ROOT / "outputs/original_voxtell_semantic_screen_1k"
OUT = ROOT / "outputs/a5_p_gradient_forensics"
ARMS = ("a5_dense_e4", "a5_contrast_e4", "p_d3", "p_d4")
SEED = 20260903
EPS = 1e-12


def args_parse() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=OUT)
    parser.add_argument("--samples", type=int, default=32)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--arm", choices=(*ARMS, "b0"), default=None)
    parser.add_argument("--state", choices=("T0", "T1000"), default=None)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def checkpoint_for(arm: str, state: str) -> Path:
    run = "b0_original" if arm == "b0" else arm
    name = "checkpoint_initial.pth" if state == "T0" else "checkpoint_update_1000.pth"
    return EXP / run / "checkpoints" / name


def config_for(arm: str) -> dict[str, Any]:
    run = "b0_original" if arm == "b0" else arm
    return json.loads((EXP / run / "args.json").read_text())


def build_model(arm: str, state: str, device: torch.device) -> tuple[torch.nn.Module, NativeFeatureCapture | None]:
    config = config_for(arm)
    params = inspect.signature(tr.instantiate_voxtell).parameters
    call = {key: config[key] for key in params if key in config}
    call.update(model_dir=Path(config["model_dir"]), device=device, deep_supervision=False)
    model = tr.instantiate_voxtell(**call)
    capture: NativeFeatureCapture | None = None
    if arm != "b0":
        if arm.startswith("a5_"):
            head: torch.nn.Module = A5ImagePositionHead(int(model.encoder.output_channels[4]), 128)
        else:
            stage_index = 1 if arm == "p_d3" else 0
            head = PathologyRegionAlignmentHead(int(model.encoder.output_channels[stage_index]), 2560, 128)
        model.add_module("semantic_screen_head", head.to(device))
        capture = NativeFeatureCapture(arm)
        capture.attach(model)
    checkpoint = torch.load(checkpoint_for(arm, state), map_location="cpu", weights_only=False)
    incompatible = model.load_state_dict(checkpoint["network_weights"], strict=True)
    if incompatible.missing_keys or incompatible.unexpected_keys:
        raise RuntimeError(f"{arm}/{state}: checkpoint mismatch {incompatible}")
    model.eval()
    for parameter in model.parameters():
        # Checkpoints are inference artifacts and may retain an arbitrary
        # requires_grad flag from their construction process.  This is a
        # measurement-only autograd pass, so make all network parameters
        # differentiable without ever constructing an optimizer or stepping.
        parameter.requires_grad_(True)
    return model, capture


def parameter_groups(model: torch.nn.Module, arm: str) -> tuple[dict[str, list[tuple[str, torch.nn.Parameter]]], dict[str, str]]:
    shared = [(name, parameter) for name, parameter in model.named_parameters()
              if parameter.requires_grad and not name.startswith("semantic_screen_head.")]

    def take(predicate):
        return [(name, parameter) for name, parameter in shared if predicate(name)]

    encoder_early = take(lambda name: name.startswith("encoder.") and not name.startswith("encoder.stages.4"))
    prompt_decoder = take(lambda name: name.startswith("decoder."))
    if arm.startswith("a5_"):
        g1 = take(lambda name: name.startswith("encoder.stages.4"))
        g2 = prompt_decoder
        g1_desc = "encoder.stages.4: native E4 feature-producing block captured by A5"
        g2_desc = "decoder.*: segmentation decoder downstream of encoder features"
    elif arm == "p_d3":
        g1 = take(lambda name: name.startswith("decoder.stages.3"))
        g2 = take(lambda name: name.startswith("decoder.stages.4") or "seg_layers" in name)
        g1_desc = "decoder.stages.3: native D3 feature-producing block captured by P-D3"
        g2_desc = "decoder.stages.4 plus seg_layers: later decoder/output path"
    elif arm == "p_d4":
        g1 = take(lambda name: name.startswith("decoder.stages.4"))
        g2 = take(lambda name: "seg_layers" in name or "output" in name)
        g1_desc = "decoder.stages.4: native D4 feature-producing block captured by P-D4"
        g2_desc = "seg_layers/output: separable final segmentation-output path"
    else:
        # B0 has no insertion module, but retaining the same late encoder
        # reference block gives its segmentation-gradient scale a useful
        # layer-wise anchor without fabricating an auxiliary gradient.
        g1 = take(lambda name: name.startswith("encoder.stages.4"))
        g2 = prompt_decoder
        g1_desc = "encoder.stages.4: late-encoder reference block for B0 segmentation gradients"
        g2_desc = "decoder.*: segmentation decoder"
    groups = {
        "G1_insertion_representation": g1,
        "G2_downstream_output": g2,
        "G3_prompt_decoder": prompt_decoder,
        "G4_early_encoder": encoder_early,
        "G5_all_shared": shared,
    }
    descriptions = {
        "G1_insertion_representation": g1_desc,
        "G2_downstream_output": g2_desc,
        "G3_prompt_decoder": "decoder.*: full prompt-conditioned segmentation decoder path",
        "G4_early_encoder": "encoder.* excluding encoder.stages.4",
        "G5_all_shared": "all trainable segmentation-network parameters; semantic_screen_head excluded",
    }
    if any(not values for values in groups.values()):
        empty = [name for name, values in groups.items() if not values]
        raise RuntimeError(f"{arm}: empty parameter group(s): {empty}")
    return groups, descriptions


def load_audit_context(seed: int):
    config = config_for("a5_dense_e4")
    manifest = tr.load_manifest(Path(config["preprocessed_dir"]))
    cases = tr.build_case_records(manifest, "train", None)
    embeddings = tr.load_embedding_map(Path(config["embedding_cache"]), "qwen")
    token_path = EXP / "p_d3" / "args.json"
    token_config = json.loads(token_path.read_text())
    tokens, token_meta = tr.load_token_feature_map(Path(token_config["token_feature_cache"]))
    sampler = historical.construct_sampler(config, cases, embeddings, tokens, seed)
    lookup = {(str(case["case"]), int(finding["finding_idx"])): (case, position)
              for case in cases for position, finding in enumerate(case["findings"])}
    phrase_payload = torch.load(Path(config["semantic_screen_anatomy_cache"]), map_location="cpu", weights_only=False)
    if tuple(phrase_payload["phrases"]) != ANATOMY_PHRASES:
        raise RuntimeError("Historical anatomy phrase ordering changed")
    return config, cases, sampler, lookup, phrase_payload["vectors"].float(), token_meta


def build_manifest(output: Path, samples: int, seed: int, lookup: dict, sampler: Any) -> pd.DataFrame:
    path = output / "manifest.tsv"
    if path.exists():
        frame = pd.read_csv(path, sep="\t")
        if len(frame) != samples:
            raise RuntimeError(f"Existing manifest has {len(frame)} rows, requested {samples}; choose a new output directory")
        return frame
    candidates = sorted(lookup)
    if samples > len(candidates):
        raise ValueError(f"Requested {samples} samples but only {len(candidates)} usable findings")
    # The train manifest can contain a small number of stale/empty finding
    # channels.  Shuffle the *whole* ordinary positive population once, then
    # retain the first usable GT-centred crops.  This remains deterministic
    # and avoids cherry-picking semantic-easy examples.
    shuffled = candidates[:]
    random.Random(seed).shuffle(shuffled)
    rows = []
    for case_id, finding_id in shuffled:
        if len(rows) == samples:
            break
        case, position = lookup[(case_id, finding_id)]
        try:
            _image, _embedding, target, _weight, meta = historical.anchor_sample(sampler, case, position)
        except RuntimeError as exc:
            if "empty source mask" in str(exc):
                continue
            raise
        finding = case["findings"][position]
        prompt = str(finding["prompt"])
        parsed = tr.semantic_parse(prompt)
        spacing = meta.get("spacing_xyz", (1.0, 1.0, 1.0))
        rows.append({
            "case_id": case_id,
            "finding_id": int(finding_id),
            "channel": int(finding["channel"]),
            "prompt": prompt,
            "category": str(finding.get("category", "unknown")),
            "gt_voxels_crop": int(target[0].sum().item()),
            "gt_volume_mm3_crop": float(target[0].sum().item()) * float(np.prod(spacing)),
            "anatomy_group": str(parsed.get("group", "nonlocalizable")),
            "anatomy_side": str(parsed.get("side", "")),
            "anatomy_lobes": ";".join(map(str, parsed.get("lobes", []))),
            "pathology_phrase": tr.fan_semantic_pathology_phrase(prompt) or "",
            "crop_empty": False,
            "selection": "seeded_uniform_without_replacement_from_ordinary_nonempty_train_findings",
            "seed": seed,
        })
    if len(rows) != samples:
        raise RuntimeError(f"Only found {len(rows)} nonempty train findings for requested manifest of {samples}")
    frame = pd.DataFrame(rows)
    output.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, sep="\t", index=False)
    return frame


def grads(loss: torch.Tensor, parameters: list[torch.nn.Parameter], retain_graph: bool) -> list[torch.Tensor | None]:
    if not loss.requires_grad:
        return [None] * len(parameters)
    return list(torch.autograd.grad(loss, parameters, retain_graph=retain_graph, allow_unused=True))


def group_metrics(all_parameters, seg_grads, aux_grads, parameter_pairs, lambda_weight: float, aux_active: bool) -> dict[str, float]:
    indices = {id(parameter) for _name, parameter in parameter_pairs}
    seg_sq = aux_sq = dot = 0.0
    for parameter, g_seg, g_aux in zip(all_parameters, seg_grads, aux_grads):
        if id(parameter) not in indices:
            continue
        if g_seg is not None:
            seg_sq += float(torch.sum(g_seg.detach().float().square()).item())
        if g_aux is not None:
            aux_sq += float(torch.sum(g_aux.detach().float().square()).item())
        if g_seg is not None and g_aux is not None:
            dot += float(torch.sum(g_seg.detach().float() * g_aux.detach().float()).item())
    seg_norm, aux_norm = math.sqrt(seg_sq), math.sqrt(aux_sq)
    weighted_norm = lambda_weight * aux_norm
    raw_ratio = aux_norm / (seg_norm + EPS)
    weighted_ratio = weighted_norm / (seg_norm + EPS)
    active = bool(aux_active and aux_norm > 0.0)
    cosine = dot / (seg_norm * aux_norm + EPS) if active and seg_norm > 0 else float("nan")
    total_sq = seg_sq + 2.0 * lambda_weight * dot + (lambda_weight * lambda_weight) * aux_sq
    total_norm = math.sqrt(max(total_sq, 0.0))
    combined_cos = (seg_sq + lambda_weight * dot) / (seg_norm * total_norm + EPS) if seg_norm > 0 and total_norm > 0 else float("nan")
    angle = math.degrees(math.acos(float(np.clip(combined_cos, -1.0, 1.0)))) if math.isfinite(combined_cos) else float("nan")
    local_ratio = (seg_sq + lambda_weight * dot) / (seg_sq + EPS)
    return {
        "seg_norm": seg_norm, "aux_norm_raw": aux_norm, "aux_norm_weighted": weighted_norm,
        "raw_norm_ratio": raw_ratio, "weighted_norm_ratio": weighted_ratio,
        "cosine": cosine, "aux_active": int(active), "dot_seg_aux": dot,
        "combined_cosine_to_seg": combined_cos, "angular_deviation_deg": angle,
        "relative_perturbation": weighted_ratio, "local_descent_ratio": local_ratio,
        "harmful_score": max(-lambda_weight * dot, 0.0), "total_norm": total_norm,
    }


def measure_one(model, capture, arm: str, config: dict, sample, phrases: torch.Tensor, device: torch.device, groups):
    image, embedding, target, prompt_weights, meta = sample
    image = image.unsqueeze(0).to(device, non_blocking=True)
    embedding = embedding.unsqueeze(0).to(device, non_blocking=True)
    target = target.unsqueeze(0).to(device, non_blocking=True)
    prompt_weights = prompt_weights.unsqueeze(0).to(device, non_blocking=True)
    if capture is not None:
        capture.reset()
    all_parameters = [parameter for _name, parameter in model.named_parameters()
                      if parameter.requires_grad and not _name.startswith("semantic_screen_head.")]
    # args.json serializes pathlib values.  The historical loss factory keeps
    # its category map as a Path and opens it directly, so restore that one
    # typed field before calling the unmodified loss implementation.
    loss_config = dict(config)
    if loss_config.get("category_tversky_map") is not None:
        loss_config["category_tversky_map"] = Path(loss_config["category_tversky_map"])
    loss_args = tr.loss_kwargs_from_args(argparse.Namespace(**loss_config))
    with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
        logits = model(image, embedding)
        seg_loss, _stats = tr.segmentation_loss(
            logits, target, prompt_weights,
            prompt_categories=[meta.get("categories_after_shuffle", [])],
            current_step=0, **loss_args,
        )
        raw_aux = None
        aux_stats: dict[str, float] = {"semantic_screen_active": 0.0}
        if arm.startswith("a5_"):
            assert capture is not None and capture.encoder_feature is not None
            feature = capture.encoder_feature
            shape = tuple(map(int, feature.shape[-3:]))
            coordinates = global_preprocessed_coordinates(meta, shape, device)
            lobe5 = meta["_prompt_location_lobe5_rois"].unsqueeze(0).to(device, non_blocking=True)
            occupancy = anatomy_occupancy(lobe5, shape)
            if arm == "a5_dense_e4":
                raw_aux, aux_stats = a5_dense_objective(model.semantic_screen_head, feature, coordinates, phrases, occupancy, float(config["semantic_screen_a5_temperature"]))
            else:
                raw_aux, aux_stats = a5_contrast_objective(model.semantic_screen_head, feature, coordinates, phrases, occupancy, float(config["semantic_screen_contrast_temperature"]))
        elif arm in {"p_d3", "p_d4"}:
            assert capture is not None
            feature = torch.stack(capture.decoder_features, dim=1)
            token = meta["_token_features"].unsqueeze(0).to(device, non_blocking=True)
            lung = meta["_prompt_location_lung_rois"].unsqueeze(0).to(device, non_blocking=True)
            side = meta["_prompt_location_side_rois"].unsqueeze(0).to(device, non_blocking=True)
            lobe5 = meta["_prompt_location_lobe5_rois"].unsqueeze(0).to(device, non_blocking=True)
            raw_aux, aux_stats = tr.semantic_screen_pathology_loss(
                model.semantic_screen_head, feature, target, prompt_weights, token, lung, side, lobe5, meta, 1.0, arm,
            )
    aux_active = bool(aux_stats.get("semantic_screen_active", 0.0))
    aux_grads = grads(raw_aux, all_parameters, retain_graph=True) if raw_aux is not None else [None] * len(all_parameters)
    seg_grads = grads(seg_loss, all_parameters, retain_graph=False)
    lambda_weight = float(config.get("semantic_screen_lambda", 0.0)) if arm != "b0" else 0.0
    rows = []
    for group_name, members in groups.items():
        values = group_metrics(all_parameters, seg_grads, aux_grads, members, lambda_weight, aux_active)
        rows.append({"parameter_group": group_name, "lambda": lambda_weight, "seg_loss": float(seg_loss.detach()),
                     "aux_loss_raw": float(raw_aux.detach()) if raw_aux is not None else float("nan"),
                     "aux_active_flag": int(aux_active), **values})
    del image, embedding, target, prompt_weights, logits, seg_loss, raw_aux, seg_grads, aux_grads
    return rows, aux_stats


def output_path(output: Path, arm: str) -> Path:
    return output / "raw" / ("b0" if arm == "b0" else arm) / "gradient_rows.tsv"


def main() -> int:
    args = args_parse()
    if args.device != "cuda" or not torch.cuda.is_available():
        raise SystemExit("This audit requires one CUDA GPU; refusing CPU fallback")
    output = args.output_dir.resolve()
    _config, _cases, sampler, lookup, phrase_vectors, token_meta = load_audit_context(args.seed)
    manifest = build_manifest(output, args.samples, args.seed, lookup, sampler)
    (output / "audit_metadata.json").write_text(json.dumps({
        "seed": args.seed, "samples": len(manifest), "protocol": "read_only_separate_autograd_gradients",
        "token_cache_metadata": token_meta, "states": ["T0", "T1000"], "arms": list(ARMS),
        "no_optimizer_step": True, "no_full200_inference": True,
    }, indent=2) + "\n")
    arms = [args.arm] if args.arm else [*ARMS, "b0"]
    states = [args.state] if args.state else ["T0", "T1000"]
    phrases = phrase_vectors.to(args.device)
    for arm in arms:
        config = config_for(arm)
        path = output_path(output, arm)
        path.parent.mkdir(parents=True, exist_ok=True)
        if args.overwrite and path.exists():
            path.unlink()
        existing = pd.read_csv(path, sep="\t") if path.exists() else pd.DataFrame()
        done = set(zip(existing.get("state", []), existing.get("case_id", []), existing.get("finding_id", [])))
        for state in states:
            model, capture = build_model(arm, state, torch.device(args.device))
            groups, descriptions = parameter_groups(model, arm)
            (path.parent / "parameter_groups.json").write_text(json.dumps({
                key: {"description": descriptions[key], "parameter_names": [name for name, _ in value]}
                for key, value in groups.items()
            }, indent=2) + "\n")
            for record in manifest.itertuples(index=False):
                key = (state, record.case_id, int(record.finding_id))
                if key in done:
                    continue
                case, position = lookup[(record.case_id, int(record.finding_id))]
                sample = historical.anchor_sample(sampler, case, position)
                values, aux_stats = measure_one(model, capture, arm, config, sample, phrases, torch.device(args.device), groups)
                common = {"arm": arm, "state": state, "case_id": record.case_id, "finding_id": int(record.finding_id),
                          "gt_volume_mm3_crop": float(record.gt_volume_mm3_crop), "category": record.category,
                          "anatomy_group": record.anatomy_group, "anatomy_side": record.anatomy_side,
                          "anatomy_lobes": record.anatomy_lobes, "pathology_phrase": record.pathology_phrase,
                          "crop_empty": bool(record.crop_empty)}
                rows = [{**common, **value, **{f"aux_stat_{k}": v for k, v in aux_stats.items()}} for value in values]
                existing = pd.concat((existing, pd.DataFrame(rows)), ignore_index=True)
                existing.to_csv(path, sep="\t", index=False)
                done.add(key)
                print(json.dumps({"arm": arm, "state": state, "done_samples": len({x for x in done if x[0] == state}), "case": record.case_id, "finding": int(record.finding_id)}), flush=True)
            if capture is not None:
                capture.remove()
            del model
            torch.cuda.empty_cache()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
