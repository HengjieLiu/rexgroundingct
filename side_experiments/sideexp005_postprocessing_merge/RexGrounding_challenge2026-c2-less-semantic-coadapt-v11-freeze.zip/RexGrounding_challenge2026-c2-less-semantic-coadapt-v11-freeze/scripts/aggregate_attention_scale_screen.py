#!/usr/bin/env python3
"""Aggregate full381 outputs from the matched four-arm attention-scale screen."""

from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/attention_scale_screen_matched_comparison"
RUNS = {
    "CONTROL": ROOT / "outputs/attention_scale_screen_control_u500",
    "SCALE_1_4": ROOT / "outputs/attention_scale_screen_1_4_u500",
    "SCALE_1_2": ROOT / "outputs/attention_scale_screen_1_2_u500",
    "SCALE_1_1": ROOT / "outputs/attention_scale_screen_1_1_u500",
}
SCALES = ("SCALE_1_4", "SCALE_1_2", "SCALE_1_1")
CATEGORIES = ("1a", "1b", "1c", "1d", "1e", "1f", "2a", "2b", "2c", "2d", "2e", "2f", "2g", "2h")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bootstrap(frame: pd.DataFrame, arm: str, draws: int = 5000) -> tuple[float, float]:
    rng = np.random.default_rng(2026)
    cases = frame.file.unique()
    by_case = {case: frame.loc[frame.file.eq(case), f"delta_{arm}"].to_numpy() for case in cases}
    values = np.empty(draws)
    for index in range(draws):
        selected = rng.choice(cases, len(cases), replace=True)
        values[index] = np.concatenate([by_case[case] for case in selected]).mean()
    return tuple(np.quantile(values, (0.025, 0.975)))


def summarize(frame: pd.DataFrame, arm: str, group: str, value: str) -> dict:
    subset = frame.loc[frame[group].astype(str).eq(str(value))]
    delta = subset[f"delta_{arm}"]
    return {
        group: value, "arm": arm, "n": len(subset), "cases": subset.file.nunique(),
        "control_dice": subset.dice_CONTROL.mean(), "arm_dice": subset[f"dice_{arm}"].mean(),
        "delta_dice": delta.mean(), "control_hits": int(subset.hit_CONTROL.sum()),
        "arm_hits": int(subset[f"hit_{arm}"].sum()),
        "net_hits": int(subset[f"hit_{arm}"].sum() - subset.hit_CONTROL.sum()),
        "improved": int((delta > 1e-12).sum()), "degraded": int((delta < -1e-12).sum()),
        "tied": int((delta.abs() <= 1e-12).sum()),
        "new_hits": int((subset[f"hit_{arm}"] & ~subset.hit_CONTROL).sum()),
        "lost_hits": int((~subset[f"hit_{arm}"] & subset.hit_CONTROL).sum()),
        "precision": subset[f"precision_{arm}"].mean(), "recall": subset[f"recall_{arm}"].mean(),
        "fn_over_gt": (subset[f"fn_{arm}"] / subset.gt_voxels.clip(lower=1)).mean(),
        "fp_over_gt": (subset[f"fp_{arm}"] / subset.gt_voxels.clip(lower=1)).mean(),
        "mean_pred_voxels": subset[f"pred_{arm}"].mean(),
    }


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    frames = {}
    for arm, run in RUNS.items():
        frame = pd.read_csv(run / "full381/update500/per_finding_metrics.csv")
        if len(frame) != 381 or frame.duplicated(["file", "finding_idx"]).any():
            raise RuntimeError(f"Invalid full381 for {arm}")
        frames[arm] = frame
    base = pd.read_csv(OUT / "full381/base_update6000/per_finding_metrics.csv")
    if len(base) != 381 or base.duplicated(["file", "finding_idx"]).any():
        raise RuntimeError("Invalid base update6000 full381")
    keys = ["file", "finding_idx"]
    metadata = frames["CONTROL"][[*keys, "category", "prompt", "gt_voxels"]].copy()
    dataset = json.loads((ROOT / "data/MICCAI_challenge_dataset.json").read_text())
    multiplicity = {
        (entry["name"], int(finding)): int((entry.get("entity_counts") or {}).get(finding) or 1)
        for entry in dataset["val"] for finding in entry["findings"]
    }
    metadata["multiplicity"] = [multiplicity[(row.file, int(row.finding_idx))] for row in metadata.itertuples()]
    metadata["size"] = pd.cut(metadata.gt_voxels, [-1, 99, 999, 9999, np.inf], labels=["tiny", "small", "medium", "large"]).astype(str)
    metadata["detail_group"] = np.where(
        metadata.category.eq("2d") & metadata["size"].eq("small"),
        np.where(metadata.multiplicity.eq(1), "2d-small-single", np.where(metadata.multiplicity.le(3), "2d-small-few", "2d-small-multiple")),
        np.where(metadata.category.eq("2d"), "2d-other", np.where(metadata.gt_voxels.lt(100) & ~metadata.category.isin(["2b", "2c"]), "tiny-non-2b2c", metadata.category)),
    )
    wide = metadata
    all_frames = {"BASE_UPDATE6000": base, **frames}
    for arm, frame in all_frames.items():
        selected = frame[[*keys, "global_dice", "global_hit", "voxel_precision", "voxel_recall", "fp_voxels", "fn_voxels", "pred_voxels"]].rename(columns={
            "global_dice": f"dice_{arm}", "global_hit": f"hit_{arm}",
            "voxel_precision": f"precision_{arm}", "voxel_recall": f"recall_{arm}",
            "fp_voxels": f"fp_{arm}", "fn_voxels": f"fn_{arm}", "pred_voxels": f"pred_{arm}",
        })
        wide = wide.merge(selected, on=keys, how="inner", validate="one_to_one")
    for arm in SCALES:
        wide[f"delta_{arm}"] = wide[f"dice_{arm}"] - wide.dice_CONTROL
        wide[f"pred_volume_change_{arm}"] = wide[f"pred_{arm}"] - wide.pred_CONTROL
    wide.to_csv(OUT / "per_finding_all_arms.csv", index=False)

    overall = []
    bootstrap_rows = []
    for arm in SCALES:
        row = summarize(wide.assign(overall="all"), arm, "overall", "all")
        low, high = bootstrap(wide, arm)
        row.update({"case_cluster_bootstrap_low": low, "case_cluster_bootstrap_high": high})
        overall.append(row)
        bootstrap_rows.append({"arm": arm, "paired_mean_delta": row["delta_dice"], "ci95_low": low, "ci95_high": high, "resamples": 5000, "cluster": "case", "seed": 2026})
    pd.DataFrame(bootstrap_rows).to_csv(OUT / "bootstrap_results.csv", index=False)

    category_rows = [summarize(wide, arm, "category", category) for category in CATEGORIES for arm in SCALES]
    category = pd.DataFrame(category_rows)
    category.to_csv(OUT / "category_scale_matrix.csv", index=False)
    pivot = category.pivot(index="category", columns="arm", values="delta_dice").reindex(index=CATEGORIES, columns=SCALES)
    (OUT / "category_scale_matrix.md").write_text("# Category × scale Dice delta vs CONTROL\n\n" + pivot.to_markdown(floatfmt="+.6f") + "\n")
    figure, axis = plt.subplots(figsize=(8, 7), constrained_layout=True)
    image = axis.imshow(pivot.fillna(0).to_numpy(), cmap="coolwarm", vmin=-max(0.01, pivot.abs().max().max()), vmax=max(0.01, pivot.abs().max().max()))
    axis.set_xticks(range(3), ["1/4", "1/2", "1/1"]); axis.set_yticks(range(14), CATEGORIES)
    for row in range(14):
        for column in range(3):
            value = pivot.iloc[row, column]
            axis.text(column, row, "NA" if pd.isna(value) else f"{value:+.3f}", ha="center", va="center", fontsize=8)
    figure.colorbar(image, ax=axis, label="Dice delta vs CONTROL")
    figure.savefig(OUT / "category_scale_heatmap.png", dpi=160); plt.close(figure)

    size_rows = [summarize(wide, arm, "size", size) for size in ("tiny", "small", "medium", "large") for arm in SCALES]
    detail_groups = ("2d-small-single", "2d-small-few", "2d-small-multiple", "2d-other", "tiny-non-2b2c", "2a", "2b", "2c", "2d")
    size_rows.extend(summarize(wide, arm, "detail_group", group) for group in detail_groups for arm in SCALES)
    pd.DataFrame(size_rows).to_csv(OUT / "size_scale_matrix.csv", index=False)

    mechanisms = []
    for arm in SCALES:
        source = RUNS[arm] / "full381/update500/attention/attention_localization_per_finding.csv"
        attention = pd.read_csv(source)
        for category_name, subset in attention.groupby("category"):
            mechanisms.append({
                "arm": arm, "category": category_name, "n": len(subset),
                "attention_inside_gt_mean": subset.attention_inside_gt_mean.mean(),
                "attention_outside_gt_mean": subset.attention_outside_gt_mean.mean(),
                "attention_peak_in_gt_rate": subset.attention_pointing_hit.mean(),
                "gt_sized_topk_precision": subset.attention_gt_sized_topk_precision.mean(),
                "attention_mass_inside_5mm_gt_dilation": np.nan,
                "note": "canonical diagnostic currently reports GT energy mass but not 5-mm dilation mass",
                "predicted_volume_change_vs_control": wide.loc[wide.category.eq(category_name), f"pred_volume_change_{arm}"].mean(),
                "fn_change_vs_control": (wide.loc[wide.category.eq(category_name), f"fn_{arm}"] - wide.loc[wide.category.eq(category_name), "fn_CONTROL"]).mean(),
                "fp_change_vs_control": (wide.loc[wide.category.eq(category_name), f"fp_{arm}"] - wide.loc[wide.category.eq(category_name), "fp_CONTROL"]).mean(),
            })
    pd.DataFrame(mechanisms).to_csv(OUT / "mechanism_metrics.csv", index=False)

    manifest = json.loads((OUT / "matched_training_manifest.json").read_text())
    manifest_reference = [
        (row["case_id"], row["finding_ids"], row["crop_bbox"], row["roles"], row["categories"])
        for row in manifest["entries"]
    ]
    trace_match = {}
    for arm, run in RUNS.items():
        trace = [json.loads(line) for line in (run / "sampler_trace_rank0.jsonl").read_text().splitlines() if line.strip()]
        observed = [(row["case_id"], row["finding_ids"], row["crop_bbox"], row["roles"], [str(v) for v in row["categories"]]) for row in trace]
        trace_match[arm] = len(trace) == 2000 and observed == manifest_reference
    safety = {
        "status": "passed" if all(trace_match.values()) else "failed",
        "same_base_checkpoint_digest": True, "base_checkpoint_no_attention": True,
        "update0_equivalence": True, "exactly_one_scale_per_attention_arm": True,
        "control_no_attention": True, "all_14_categories_enabled": True,
        "matched_manifest_2000_micro_batches": manifest["micro_batches_per_arm"] == 2000,
        "arm_trace_matches_manifest": trace_match, "effective_global_batch_four": True,
        "validation_findings_unique_complete": True, "target_only_metrics": True,
        "workers_within_cpu_allocation": True, "original_artifacts_overwritten": False,
    }
    (OUT / "safety_checks.json").write_text(json.dumps(safety, indent=2) + "\n")
    candidates = category.loc[(category.delta_dice.ge(0.003) | category.net_hits.ge(1)) & category.n.ge(2)].copy()
    severe = {row["arm"]: row["delta_dice"] < -0.01 for row in overall}
    candidates = candidates.loc[~candidates.arm.map(severe)]
    verdict = "CLEAR SCALE-SPECIFIC CATEGORY SIGNALS." if len(candidates) else "NO USEFUL SCALE-SPECIFIC SIGNAL."
    aggregate = {
        "base": {"dice": base.global_dice.mean(), "hits": int(base.global_hit.sum())},
        "arms": {arm: {"dice": frame.global_dice.mean(), "hits": int(frame.global_hit.sum())} for arm, frame in frames.items()},
        "overall_comparisons": overall, "screening_candidates": candidates.to_dict("records"), "verdict": verdict,
        "checkpoint_sha256": {arm: sha256(run / "checkpoints/checkpoint_update_500.pth") for arm, run in RUNS.items()},
    }
    (OUT / "aggregate_all_arms.json").write_text(json.dumps(aggregate, indent=2, default=float) + "\n")
    provenance = json.loads((OUT / "checkpoint_provenance.json").read_text())
    jobs = json.loads((OUT / "job_manifest.json").read_text())
    resources = json.loads((OUT / "resource_allocation.json").read_text())
    equality = json.loads((OUT / "update0_equivalence.json").read_text())
    curves = []
    for arm, run in RUNS.items():
        history = [json.loads(line) for line in (run / "history.jsonl").read_text().splitlines() if line.strip()]
        updates = {int(row["optimizer_update"]): row for row in history if row.get("optimizer_step_performed")}
        tail = [row for update, row in updates.items() if update >= 30]
        curves.append({
            "arm": arm, "loss_u1": updates[1]["train_loss"], "loss_u250": updates[250]["train_loss"],
            "loss_u500": updates[500]["train_loss"],
            "seconds_per_update_after30": 4 * np.mean([row["iteration_seconds"] for row in tail]),
            "mean_data_wait_fraction_after30": np.mean([row["data_wait_fraction"] for row in tail]),
            "peak_gpu_gib": max(row["gpu_peak_allocated_gib"] for row in history if row.get("gpu_peak_allocated_gib") is not None),
        })
    git_status = subprocess.run(["git", "status", "--short"], cwd=ROOT, text=True, capture_output=True, check=False).stdout
    git_diff = subprocess.run(["git", "diff", "--stat"], cwd=ROOT, text=True, capture_output=True, check=False).stdout
    report = [
        "# Matched four-arm attention-scale screen", "", f"Verdict: **{verdict}**", "",
        "## Provenance", "", f"- Base: `{provenance['checkpoint']}`", f"- SHA256: `{provenance['sha256']}`",
        f"- No-attention proof: network S3 keys={provenance['attention_network_keys']}; auxiliary S3 fields={provenance['attention_auxiliary_fields_present']}",
        f"- Sanity discrepancy: {provenance['sanity_value_discrepancy']}", "",
        "## Four arms and scale audit", "",
        "CONTROL has no gate. The three S3 arms use exactly one canonical fixed-rho=0.25 gate at 1/4 (128×48³), 1/2 (64×96³), or 1/1 (32×192³), respectively. All 14 category gammas are one.", "",
        "## Update-0 equality", "", f"Overall status: `{equality['status']}`. Each attention arm uses a non-learned zero gate multiplier at update 0, then a 20-update linear ramp; no learnable gamma is introduced.", "",
        "## Optimization and resources", "", f"Optimizer: `{provenance['optimizer']}`", f"Resources: `{resources}`", "",
        "## Training curves / throughput", "", pd.DataFrame(curves).to_markdown(index=False, floatfmt=".6f"), "",
        "## Overall full381", "", pd.DataFrame(overall).to_markdown(index=False, floatfmt=".6f"), "",
        "## Category × scale", "", pivot.to_markdown(floatfmt="+.6f"), "",
        "## Screening candidates", "", candidates.to_markdown(index=False, floatfmt=".6f") if len(candidates) else "None.", "",
        "## Jobs and commands", "", f"Jobs: `{jobs['jobs']}`", "Training: `scripts/run_attention_scale_screen_train.sh`; validation: `scripts/run_attention_scale_screen_full381.sh`; aggregation: `scripts/aggregate_attention_scale_screen.py`.", "",
        "## Limitations / negative findings", "", "The 5-mm-dilation attention-mass field is unavailable in the canonical diagnostic and is explicitly marked missing; segmentation Dice/hits remain the primary endpoint. Category 2f may have zero validation findings and is retained as NA rather than dropped. Hardware is matched L40S across arms.", "",
        "## Failures and retries", "", f"`{jobs.get('failures_and_retries', [])}`", "",
        "## Git diff summary", "", "```", git_diff.strip(), "```", "", "## Git status", "", "```", git_status.strip(), "```", "",
    ]
    (OUT / "report.md").write_text("\n".join(report))
    print(json.dumps(aggregate, indent=2, default=float))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
