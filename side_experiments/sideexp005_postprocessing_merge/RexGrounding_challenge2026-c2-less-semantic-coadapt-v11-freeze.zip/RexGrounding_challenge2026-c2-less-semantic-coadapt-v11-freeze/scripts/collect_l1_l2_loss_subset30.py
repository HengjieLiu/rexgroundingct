#!/usr/bin/env python3
"""Collect paired L1/L2 subset results and select full-validation candidates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ("l1", "l2")
REFERENCES = ("control", "adaptive")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT / "outputs/l1_l2_loss_subset30")
    parser.add_argument(
        "--reference-root",
        type=Path,
        default=ROOT / "outputs/category_adaptive_tversky_subset30",
    )
    parser.add_argument(
        "--mapping-csv",
        type=Path,
        default=ROOT / "outputs/category_adaptive_tversky_audit/category_mapping.csv",
    )
    parser.add_argument("--steps", nargs="+", type=int, default=[200, 400, 600])
    return parser.parse_args()


def load_frame(root: Path, branch: str, step: int) -> pd.DataFrame:
    path = root / branch / f"step{step}" / "per_finding_metrics.csv"
    if not path.is_file():
        raise FileNotFoundError(path)
    frame = pd.read_csv(path)
    required = {
        "file", "finding_idx", "category", "global_dice", "global_hit",
        "voxel_precision", "voxel_recall", "fp_mm3", "fn_mm3",
        "pred_gt_volume_ratio", "pred_voxels", "voxel_volume_mm3",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"{path} missing columns: {missing}")
    return frame


def summarize(frame: pd.DataFrame, branch: str, step: int) -> dict:
    return {
        "branch": branch,
        "step": step,
        "findings": len(frame),
        "cases": frame.file.nunique(),
        "dice_per_finding": frame.global_dice.mean(),
        "dice_per_case": frame.groupby("file").global_dice.mean().mean(),
        "hit_rate": frame.global_hit.mean(),
        "hits": int(frame.global_hit.sum()),
        "misses": int((~frame.global_hit.astype(bool)).sum()),
        "precision": frame.voxel_precision.mean(),
        "recall": frame.voxel_recall.mean(),
        "total_fp_mm3": frame.fp_mm3.sum(),
        "total_fn_mm3": frame.fn_mm3.sum(),
        "median_pred_gt_volume_ratio": frame.pred_gt_volume_ratio.median(),
    }


def pair(
    candidate: pd.DataFrame,
    reference: pd.DataFrame,
    candidate_name: str,
    reference_name: str,
    step: int,
    group_map: dict[str, str],
) -> pd.DataFrame:
    keys = ["file", "finding_idx"]
    metrics = [
        "global_dice", "global_hit", "voxel_precision", "voxel_recall",
        "fp_mm3", "fn_mm3", "pred_gt_volume_ratio",
    ]
    left = reference[keys + ["category", "prompt"] + metrics]
    right = candidate[keys + metrics]
    paired = left.merge(
        right, on=keys, suffixes=("_reference", "_candidate"), validate="one_to_one"
    )
    paired.insert(0, "reference", reference_name)
    paired.insert(0, "candidate", candidate_name)
    paired.insert(0, "step", step)
    paired["assigned_group"] = paired.category.astype(str).map(group_map).fillna("mixed")
    for metric in metrics:
        paired[f"delta_{metric}"] = (
            paired[f"{metric}_candidate"].astype(float)
            - paired[f"{metric}_reference"].astype(float)
        )
    paired["dice_improved"] = paired.delta_global_dice > 0
    return paired


def summarize_pairs(paired: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for keys, sub in paired.groupby(
        ["candidate", "reference", "step", "assigned_group"], sort=True
    ):
        candidate, reference, step, group = keys
        ref_fp = sub.fp_mm3_reference.sum()
        cand_fp = sub.fp_mm3_candidate.sum()
        rows.append(
            {
                "candidate": candidate,
                "reference": reference,
                "step": step,
                "assigned_group": group,
                "n": len(sub),
                "reference_dice": sub.global_dice_reference.mean(),
                "candidate_dice": sub.global_dice_candidate.mean(),
                "paired_mean_dice_delta": sub.delta_global_dice.mean(),
                "fraction_findings_improved": sub.dice_improved.mean(),
                "reference_precision": sub.voxel_precision_reference.mean(),
                "candidate_precision": sub.voxel_precision_candidate.mean(),
                "reference_recall": sub.voxel_recall_reference.mean(),
                "candidate_recall": sub.voxel_recall_candidate.mean(),
                "recall_delta": sub.delta_voxel_recall.mean(),
                "reference_total_fp_mm3": ref_fp,
                "candidate_total_fp_mm3": cand_fp,
                "relative_fp_change": (cand_fp - ref_fp) / max(ref_fp, np.finfo(float).eps),
                "reference_hits": int(sub.global_hit_reference.sum()),
                "candidate_hits": int(sub.global_hit_candidate.sum()),
            }
        )
    return pd.DataFrame(rows)


def make_decision(overall: pd.DataFrame, grouped: pd.DataFrame) -> dict:
    rows = []
    for candidate in CANDIDATES:
        branch = overall[overall.branch == candidate].sort_values("step")
        for row in branch.itertuples(index=False):
            control = overall[(overall.branch == "control") & (overall.step == row.step)].iloc[0]
            adaptive = overall[(overall.branch == "adaptive") & (overall.step == row.step)].iloc[0]
            fp_group = grouped[
                (grouped.candidate == candidate)
                & (grouped.reference == "control")
                & (grouped.step == row.step)
                & (grouped.assigned_group == "fp_heavy")
            ]
            fp_change = float(fp_group.iloc[0].relative_fp_change) if not fp_group.empty else np.nan
            dice_gain = float(row.dice_per_finding - control.dice_per_finding)
            recall_restored = bool(row.recall > adaptive.recall)
            fp_reduced = bool(np.isfinite(fp_change) and fp_change <= -0.02)
            hits_preserved = bool(row.hits >= control.hits)
            passes = bool(
                dice_gain >= 0.001 and (recall_restored or fp_reduced or hits_preserved)
            )
            rows.append(
                {
                    "candidate": candidate,
                    "step": int(row.step),
                    "dice_per_finding": float(row.dice_per_finding),
                    "paired_dice_gain_vs_control": dice_gain,
                    "recall": float(row.recall),
                    "recall_gain_vs_adaptive": float(row.recall - adaptive.recall),
                    "recall_restored_vs_adaptive": recall_restored,
                    "fp_heavy_relative_fp_change_vs_control": fp_change,
                    "fp_heavy_fp_reduced_at_least_2pct": fp_reduced,
                    "hits": int(row.hits),
                    "control_hits": int(control.hits),
                    "hits_preserved": hits_preserved,
                    "passes": passes,
                }
            )
    candidates = pd.DataFrame(rows)
    selected = []
    for branch in CANDIDATES:
        passing = candidates[(candidates.candidate == branch) & candidates.passes].copy()
        if passing.empty:
            continue
        passing = passing.sort_values(
            ["dice_per_finding", "recall", "step"], ascending=[False, False, True]
        )
        winner = passing.iloc[0]
        selected.append({"branch": branch, "step": int(winner.step)})
    return {
        "criteria": {
            "paired_dice_gain_vs_control_min": 0.001,
            "secondary_any_of": [
                "recall higher than adaptive at matching step",
                "FP-heavy FP volume at least 2% lower than control",
                "hit count at least control",
            ],
        },
        "recommend_full_200_case_evaluation": bool(selected),
        "selected": selected,
        "per_checkpoint": candidates.to_dict(orient="records"),
    }


def main() -> int:
    args = parse_args()
    args.root.mkdir(parents=True, exist_ok=True)
    mapping = pd.read_csv(args.mapping_csv)
    group_map = dict(zip(mapping.category.astype(str), mapping.assigned_group.astype(str)))
    frames: dict[tuple[str, int], pd.DataFrame] = {}
    overall_rows = []
    for step in args.steps:
        for branch in REFERENCES:
            frame = load_frame(args.reference_root, branch, step)
            frames[(branch, step)] = frame
            overall_rows.append(summarize(frame, branch, step))
        for branch in CANDIDATES:
            frame = load_frame(args.root, branch, step)
            frames[(branch, step)] = frame
            overall_rows.append(summarize(frame, branch, step))

    paired_frames = []
    for step in args.steps:
        for candidate in CANDIDATES:
            for reference in REFERENCES:
                paired_frames.append(
                    pair(
                        frames[(candidate, step)], frames[(reference, step)],
                        candidate, reference, step, group_map,
                    )
                )
    overall = pd.DataFrame(overall_rows).sort_values(["step", "branch"])
    paired = pd.concat(paired_frames, ignore_index=True)
    grouped = summarize_pairs(paired)
    decision = make_decision(overall, grouped)

    overall.to_csv(args.root / "overall_summary.csv", index=False)
    paired.to_csv(args.root / "paired_per_finding.csv", index=False)
    grouped.to_csv(args.root / "paired_group_summary.csv", index=False)
    (args.root / "decision.json").write_text(json.dumps(decision, indent=2) + "\n")
    report = [
        "# L1/L2 fixed 30-case evaluation",
        "",
        "## Overall",
        "",
        "```text",
        overall.round(6).to_string(index=False),
        "```",
        "",
        "## Full-validation decision",
        "",
        f"Recommend full validation: **{decision['recommend_full_200_case_evaluation']}**",
        f"Selected candidates: `{decision['selected']}`",
        "",
        "The gate requires paired Dice gain >= 0.001 versus matching control and at least one predeclared secondary condition.",
        "",
    ]
    (args.root / "report.md").write_text("\n".join(report))
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
