#!/usr/bin/env python3
"""Archive records and remove the approved second-wave training directories.

Run without --execute to create an exact dry-run manifest. Execution is allowed
only if the directory snapshots, dependency checks, and protected checkpoints
still match that manifest.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import runpy
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(".")
OUTPUTS = ROOT / "outputs"
ARCHIVE_PARENT = OUTPUTS / "archived_experiment_records" / "20260730"
ARCHIVE_ROOT = ARCHIVE_PARENT / "result_folder_second_wave"
STAGING_ROOT = ARCHIVE_PARENT / ".result_folder_second_wave_staging"
MANIFEST = ARCHIVE_PARENT / "result_folder_second_wave_manifest.json"
EXECUTION = ARCHIVE_PARENT / "result_folder_second_wave_execution.json"

TARGETS = [
    "H-P1_spatial_grounded_presence_anchor85_step3800_base_lr_reset_4h200",
    "H-P1_spatial_grounded_presence_hardneg",
    "H-P1_spatial_grounded_presence_hardneg_base_lr_reset",
    "H-S1_prompt_residual_spatial_attention_anchor85_step3800_beta1p5_base_lr_reset_3h200",
    "H-S1_prompt_residual_spatial_attention_anchor85_step3800_beta1p5_base_lr_reset_4l40s",
    "H-S1_prompt_residual_spatial_attention_anchor85_step3800_beta3_base_lr_reset_4h200",
    "H-S1_prompt_residual_spatial_attention_hardneg",
    "H-S1_prompt_residual_spatial_attention_hardneg_base_lr_reset",
    "autonomous_balancer_s2_pipeline",
    "s2_localized_multiscale_attention_2c_anchor85_step3800",
    "s2b_autonomous_selected",
    "s2c_prompt_contrast_selected",
    "loss_control_cat_tversky_short",
    "loss_l1_cat_tversky_a0p6_b0p4_2gpu",
    "loss_l2_dice0p5_cat_tversky0p5_2gpu",
    "hnt_spatial_empty_topk_groupweighted",
    "s3_voxel_text_matching_2b2c_focus_from_hardneg70_step500",
    "voxtell_rex_from_first_weightedbce_bg1p5_r10_2pos1neg_to2500",
]

EXPECTED_DIRECTORY_COUNT = 18
EXPECTED_CHECKPOINT_COUNT = 210
CHECKPOINT_SUFFIXES = {".pth", ".pt", ".ckpt"}
RECORD_SUFFIXES = {
    ".json",
    ".jsonl",
    ".csv",
    ".tsv",
    ".md",
    ".txt",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".cfg",
    ".log",
    ".out",
    ".err",
}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        dir=path.parent, prefix=f".{path.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(descriptor, "w") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def within(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def scan(path: Path) -> dict:
    digest = hashlib.sha256()
    result = {
        "file_count": 0,
        "symlink_count": 0,
        "bytes": 0,
        "allocated_bytes": 0,
        "checkpoint_count": 0,
        "checkpoint_bytes": 0,
        "record_count": 0,
        "record_bytes": 0,
        "record_paths": [],
    }
    for directory, dirnames, filenames in os.walk(path, followlinks=False):
        dirnames.sort()
        filenames.sort()
        base = Path(directory)
        for name in [*dirnames, *filenames]:
            item = base / name
            relative = item.relative_to(path)
            if item.is_symlink():
                target = os.readlink(item)
                digest.update(
                    f"L\0{relative}\0{target}\n".encode(
                        "utf-8", errors="surrogateescape"
                    )
                )
                result["symlink_count"] += 1
                continue
            if not item.is_file():
                continue
            stat = item.stat()
            digest.update(
                f"F\0{relative}\0{stat.st_size}\0{stat.st_mtime_ns}\n".encode(
                    "utf-8", errors="surrogateescape"
                )
            )
            result["file_count"] += 1
            result["bytes"] += stat.st_size
            result["allocated_bytes"] += stat.st_blocks * 512
            if item.suffix.lower() in CHECKPOINT_SUFFIXES:
                result["checkpoint_count"] += 1
                result["checkpoint_bytes"] += stat.st_size
            elif item.suffix.lower() in RECORD_SUFFIXES:
                result["record_count"] += 1
                result["record_bytes"] += stat.st_size
                result["record_paths"].append(str(relative))
    result["snapshot_sha256"] = digest.hexdigest()
    return result


def current_jobs() -> list[dict]:
    queue = subprocess.run(
        ["squeue", "-u", os.environ.get("USER", ""), "-h", "-o", "%i|%T|%j"],
        check=True,
        text=True,
        capture_output=True,
    )
    jobs = []
    for line in queue.stdout.splitlines():
        if not line:
            continue
        job_id, state, name = line.split("|", 2)
        detail = subprocess.run(
            ["scontrol", "show", "job", "-o", job_id],
            check=True,
            text=True,
            capture_output=True,
        ).stdout.strip()
        jobs.append(
            {"job_id": job_id, "state": state, "name": name, "detail": detail}
        )
    return jobs


def job_target_matches(jobs: list[dict]) -> list[dict]:
    matches = []
    for job in jobs:
        found = [target for target in TARGETS if target in job["detail"]]
        if found:
            matches.append(
                {
                    "job_id": job["job_id"],
                    "name": job["name"],
                    "targets": found,
                }
            )
    return matches


def inbound_links() -> list[dict]:
    target_names = set(TARGETS)
    target_roots = {name: (OUTPUTS / name).resolve() for name in TARGETS}
    links = []
    for directory, dirnames, filenames in os.walk(OUTPUTS, followlinks=False):
        for name in [*dirnames, *filenames]:
            path = Path(directory) / name
            if not path.is_symlink():
                continue
            source_top = path.relative_to(OUTPUTS).parts[0]
            if source_top in target_names:
                continue
            resolved = path.resolve(strict=False)
            for target_name, target_root in target_roots.items():
                if resolved == target_root or within(resolved, target_root):
                    links.append(
                        {
                            "source": str(path.relative_to(ROOT)),
                            "target_directory": target_name,
                            "resolved_target": str(resolved.relative_to(ROOT)),
                        }
                    )
                    break
    return sorted(links, key=lambda item: item["source"])


def protected_checkpoints() -> list[dict]:
    prior_script = ROOT / "scripts/cleanup_experiment_checkpoints_abc_20260728.py"
    namespace = runpy.run_path(str(prior_script))
    protected = []
    for relative_text in namespace["KEEP"]:
        path = ROOT / relative_text
        target_top = Path(relative_text).parts[1]
        if target_top in TARGETS:
            raise RuntimeError(f"protected checkpoint selected: {relative_text}")
        protected.append(
            {
                "path": relative_text,
                "exists_regular": path.is_file() and not path.is_symlink(),
                "bytes": path.stat().st_size if path.is_file() else None,
            }
        )
    missing = [item["path"] for item in protected if not item["exists_regular"]]
    if missing:
        raise RuntimeError(f"protected checkpoints missing: {missing}")
    return protected


def build_state() -> dict:
    if Path.cwd().resolve() != ROOT:
        raise RuntimeError(f"must run from {ROOT}")
    if len(TARGETS) != EXPECTED_DIRECTORY_COUNT or len(set(TARGETS)) != len(TARGETS):
        raise RuntimeError("invalid target declaration")

    directories = {}
    for name in TARGETS:
        path = OUTPUTS / name
        if path.parent != OUTPUTS or not path.is_dir() or path.is_symlink():
            raise RuntimeError(f"target missing or unsafe: {path}")
        directories[name] = scan(path)

    checkpoint_count = sum(
        item["checkpoint_count"] for item in directories.values()
    )
    if checkpoint_count != EXPECTED_CHECKPOINT_COUNT:
        raise RuntimeError(
            f"checkpoint count changed: expected {EXPECTED_CHECKPOINT_COUNT}, "
            f"found {checkpoint_count}"
        )

    links = inbound_links()
    if links:
        raise RuntimeError(f"external inbound links block cleanup: {links}")
    jobs = current_jobs()
    job_matches = job_target_matches(jobs)
    if job_matches:
        raise RuntimeError(f"current jobs reference cleanup targets: {job_matches}")

    totals = {
        key: sum(item[key] for item in directories.values())
        for key in [
            "file_count",
            "symlink_count",
            "bytes",
            "allocated_bytes",
            "checkpoint_count",
            "checkpoint_bytes",
            "record_count",
            "record_bytes",
        ]
    }
    totals["directory_count"] = len(TARGETS)
    return {
        "schema_version": 1,
        "created_at": now(),
        "workspace": str(ROOT),
        "archive_root": str(ARCHIVE_ROOT.relative_to(ROOT)),
        "targets": TARGETS,
        "directories": directories,
        "totals": totals,
        "external_inbound_links": links,
        "job_target_matches": job_matches,
        "current_jobs": jobs,
        "protected_checkpoints": protected_checkpoints(),
    }


def stable(state: dict) -> dict:
    return {
        key: state[key]
        for key in [
            "schema_version",
            "workspace",
            "archive_root",
            "targets",
            "directories",
            "totals",
            "external_inbound_links",
            "job_target_matches",
            "protected_checkpoints",
        ]
    }


def archive_records(state: dict) -> dict:
    if ARCHIVE_ROOT.exists():
        raise RuntimeError(f"archive already exists: {ARCHIVE_ROOT}")
    if STAGING_ROOT.exists():
        raise RuntimeError(f"staging already exists: {STAGING_ROOT}")
    STAGING_ROOT.mkdir(parents=True)
    count = 0
    byte_count = 0
    try:
        for name in TARGETS:
            source_root = OUTPUTS / name
            destination_root = STAGING_ROOT / name
            for relative_text in state["directories"][name]["record_paths"]:
                relative = Path(relative_text)
                source = source_root / relative
                destination = destination_root / relative
                if source.is_symlink() or not source.is_file():
                    raise RuntimeError(f"record changed before archive: {source}")
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
                if source.stat().st_size != destination.stat().st_size:
                    raise RuntimeError(f"archive copy mismatch: {source}")
                count += 1
                byte_count += source.stat().st_size

        if count != state["totals"]["record_count"]:
            raise RuntimeError("archived record count mismatch")
        if byte_count != state["totals"]["record_bytes"]:
            raise RuntimeError("archived record byte count mismatch")
        atomic_json(
            STAGING_ROOT / "archive_index.json",
            {
                "created_at": now(),
                "source_workspace": str(ROOT),
                "targets": TARGETS,
                "record_count": count,
                "record_bytes": byte_count,
                "deleted_checkpoint_count": state["totals"]["checkpoint_count"],
                "deleted_checkpoint_bytes": state["totals"]["checkpoint_bytes"],
            },
        )
        os.replace(STAGING_ROOT, ARCHIVE_ROOT)
    except Exception:
        if STAGING_ROOT.exists():
            shutil.rmtree(STAGING_ROOT)
        raise
    return {"record_count": count, "record_bytes": byte_count}


def execute(state: dict) -> dict:
    if not MANIFEST.is_file():
        raise RuntimeError(f"dry-run manifest missing: {MANIFEST}")
    with MANIFEST.open() as handle:
        prior = json.load(handle)
    if stable(prior) != stable(state):
        raise RuntimeError("state differs from dry-run manifest")

    archive = archive_records(state)
    deleted = []
    errors = []
    for name in TARGETS:
        path = OUTPUTS / name
        if path.parent != OUTPUTS:
            raise RuntimeError(f"unsafe target: {path}")
        try:
            shutil.rmtree(path)
            deleted.append(
                {
                    "name": name,
                    "bytes": state["directories"][name]["bytes"],
                    "checkpoint_count": state["directories"][name][
                        "checkpoint_count"
                    ],
                    "checkpoint_bytes": state["directories"][name][
                        "checkpoint_bytes"
                    ],
                }
            )
        except Exception as error:
            errors.append({"name": name, "error": repr(error)})
            break

    remaining = [
        name
        for name in TARGETS
        if (OUTPUTS / name).exists() or (OUTPUTS / name).is_symlink()
    ]
    result = {
        "executed_at": now(),
        "archive": archive,
        "deleted": deleted,
        "errors": errors,
        "remaining_targets": remaining,
        "current_jobs_after": current_jobs(),
    }
    atomic_json(EXECUTION, result)
    if errors or remaining:
        raise RuntimeError(
            f"cleanup incomplete: errors={len(errors)}, remaining={len(remaining)}"
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    state = build_state()
    if not args.execute:
        atomic_json(MANIFEST, state)
        total = state["totals"]
        print(
            "DRY_RUN "
            f"dirs={total['directory_count']} "
            f"files={total['file_count']} "
            f"checkpoints={total['checkpoint_count']} "
            f"checkpoint_bytes={total['checkpoint_bytes']} "
            f"records={total['record_count']} "
            f"record_bytes={total['record_bytes']} "
            f"total_bytes={total['bytes']}"
        )
        return
    result = execute(state)
    print(
        "EXECUTED "
        f"dirs={len(result['deleted'])} "
        f"checkpoints={sum(item['checkpoint_count'] for item in result['deleted'])} "
        f"checkpoint_bytes={sum(item['checkpoint_bytes'] for item in result['deleted'])} "
        f"archived_records={result['archive']['record_count']}"
    )


if __name__ == "__main__":
    main()
