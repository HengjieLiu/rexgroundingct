#!/usr/bin/env python3
"""Submit matched full validation only when the fixed-subset gate passes."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SUBSET_DIR = ROOT / "outputs/category_adaptive_tversky_subset30"


def submit(*args: str) -> str:
    result = subprocess.run(["sbatch", "--parsable", *args], check=True, text=True, capture_output=True)
    return result.stdout.strip().split(";")[0]


def main() -> int:
    decision = json.loads((SUBSET_DIR / "decision.json").read_text())
    record = {"decision": decision, "submitted": False}
    if not decision["recommend_full_200_case_evaluation"]:
        (SUBSET_DIR / "full200_submission.json").write_text(json.dumps(record, indent=2) + "\n")
        print(decision["reason"])
        return 0
    step = int(decision["selected_step"])
    jobs = {}
    for branch in ("control", "adaptive"):
        jobs[branch] = submit(
            f"--job-name=ctv_full_{branch[0]}{step}",
            f"--export=ALL,LOSS_BRANCH={branch},STEP={step}",
            str(ROOT / "scripts/evaluate_category_adaptive_tversky_full200.sbatch"),
        )
    dependency = ":".join(jobs.values())
    collector = submit(
        f"--dependency=afterok:{dependency}",
        "--job-name=ctv_full_collect",
        "--partition=defq",
        "--cpus-per-task=2",
        "--mem=16G",
        "--time=00:30:00",
        "--wrap",
        (
            f"cd {ROOT} && source ./miniconda3/etc/profile.d/conda.sh && "
            "conda activate voxtell && "
            f"python scripts/collect_category_adaptive_tversky_subset30.py "
            f"--root outputs/category_adaptive_tversky_full200 --steps {step}"
        ),
    )
    record.update({"submitted": True, "selected_step": step, "jobs": jobs, "collector": collector})
    (SUBSET_DIR / "full200_submission.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
