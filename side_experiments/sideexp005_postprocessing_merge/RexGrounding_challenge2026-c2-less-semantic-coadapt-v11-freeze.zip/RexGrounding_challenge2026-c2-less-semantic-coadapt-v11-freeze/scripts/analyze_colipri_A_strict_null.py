#!/usr/bin/env python3
"""Run fresh-pairing semantic nulls through the canonical Experiment A router."""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import re
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy.optimize import linear_sum_assignment

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import colipri_experiment_a_router as canonical  # noqa: E402
import postzoom_routing_pipeline as p0  # noqa: E402

P0_DIR = ROOT / "outputs/dual_s3_postzoom_routing"
SOURCE = ROOT / "outputs/colipri_experiment_A_router_retry1_20260805"
PREVIOUS = ROOT / "outputs/colipri_experiment_A_statistical_closure_20260806"

_STATE: dict = {}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--embedding-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--nulls", type=int, default=100)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=20260806)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalized(prompt: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", prompt.lower()).strip()


def permitted(prompts: list[str], cases: np.ndarray) -> np.ndarray:
    count = len(prompts)
    allowed = np.ones((count, count), dtype=bool)
    signatures = [canonical.semantic_signature(value) for value in prompts]
    token_sets = [set(normalized(value).split()) for value in prompts]
    for row in range(count):
        allowed[row, cases == cases[row]] = False
        for col in range(count):
            if not allowed[row, col]:
                continue
            if normalized(prompts[row]) == normalized(prompts[col]):
                allowed[row, col] = False
                continue
            if signatures[row] and signatures[col] and set(signatures[row]) & set(signatures[col]):
                allowed[row, col] = False
                continue
            union = token_sets[row] | token_sets[col]
            if union and len(token_sets[row] & token_sets[col]) / len(union) >= 0.5:
                allowed[row, col] = False
    return allowed


def solve_assignment(allowed: np.ndarray, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    cost = rng.random(allowed.shape, dtype=np.float64)
    cost[~allowed] = 1e9
    rows, cols = linear_sum_assignment(cost)
    assignment = np.full(allowed.shape[0], -1, dtype=np.int32)
    assignment[rows] = cols
    if np.any(assignment < 0) or not np.all(allowed[np.arange(len(assignment)), assignment]):
        raise RuntimeError(f"No valid constrained prompt permutation for seed {seed}")
    if len(np.unique(assignment)) != len(assignment):
        raise RuntimeError("Prompt assignment does not preserve the prompt pool")
    return assignment


def same_case_eligible_allowed(
    cross_allowed: np.ndarray, prompts: list[str], cases: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    result = cross_allowed.copy()
    eligible = np.zeros(len(prompts), dtype=bool)
    for case in np.unique(cases):
        indices = np.flatnonzero(cases == case)
        if len(indices) < 2:
            continue
        block = np.zeros((len(indices), len(indices)), dtype=bool)
        for i, row in enumerate(indices):
            for j, col in enumerate(indices):
                block[i, j] = row != col and canonical.semantically_distinct(
                    prompts[row], prompts[col]
                )
        rows, cols = linear_sum_assignment(np.where(block, 0.0, 1e9))
        if len(rows) == len(indices) and np.all(block[rows, cols]):
            eligible[indices] = True
            result[indices] = False
            result[np.ix_(indices, indices)] = block
    return result, eligible


def bf16_scores(image: np.ndarray, text: np.ndarray, assignment: np.ndarray) -> np.ndarray:
    left = torch.from_numpy(image).bfloat16()
    right = torch.from_numpy(text[assignment]).bfloat16()
    return torch.bmm(left[:, None, :], right[:, :, None])[:, 0, 0].bfloat16().float().numpy()


def build_features(
    manifest: pd.DataFrame,
    arrays: dict[str, np.ndarray],
    primary: np.ndarray,
    contrast: np.ndarray,
) -> pd.DataFrame:
    row_index = np.arange(len(manifest))
    if "native_scores" in arrays and "zoom_scores" in arrays:
        native = arrays["native_scores"][row_index, primary]
        native_control = arrays["native_scores"][row_index, contrast]
    else:
        native = bf16_scores(arrays["native"], arrays["text"], primary)
        native_control = bf16_scores(arrays["native"], arrays["text"], contrast)
    zoom = np.full((len(manifest), 3), np.nan, dtype=np.float32)
    zoom_control = np.full_like(zoom, np.nan)
    for rank in range(3):
        valid = arrays["zoom_valid"][:, rank]
        if "zoom_scores" in arrays:
            zoom[valid, rank] = arrays["zoom_scores"][row_index, rank, primary][valid]
            zoom_control[valid, rank] = arrays["zoom_scores"][row_index, rank, contrast][valid]
        else:
            zoom[valid, rank] = bf16_scores(
                arrays["zoom"][:, rank], arrays["text"], primary
            )[valid]
            zoom_control[valid, rank] = bf16_scores(
                arrays["zoom"][:, rank], arrays["text"], contrast
            )[valid]
    rows = []
    for index, row in manifest.iterrows():
        valid = np.flatnonzero(arrays["zoom_valid"][index])
        values = zoom[index, valid]
        controls = zoom_control[index, valid]
        order = np.argsort(values)[::-1] if len(values) else np.array([], dtype=int)
        best = int(order[0]) if len(order) else -1
        rows.append({
            "finding_key": row.finding_key,
            "file": row.file,
            "finding_idx": int(row.finding_idx),
            "prompt": row.prompt,
            "colipri_native_correct": float(native[index]),
            "colipri_native_shuffled": float(native_control[index]),
            "colipri_zoom_rank1_correct": float(zoom[index, 0]),
            "colipri_zoom_rank2_correct": float(zoom[index, 1]),
            "colipri_zoom_rank3_correct": float(zoom[index, 2]),
            "colipri_zoom_rank1_shuffled": float(zoom_control[index, 0]),
            "colipri_zoom_rank2_shuffled": float(zoom_control[index, 1]),
            "colipri_zoom_rank3_shuffled": float(zoom_control[index, 2]),
            "colipri_zoom_correct_max": float(np.max(values)) if len(values) else np.nan,
            "colipri_zoom_correct_mean": float(np.mean(values)) if len(values) else np.nan,
            "colipri_zoom_minus_native": float(np.max(values) - native[index]) if len(values) else np.nan,
            "colipri_zoom_correct_gap12": float(values[order[0]] - values[order[1]]) if len(order) > 1 else 0.0,
            "colipri_native_prompt_margin": float(native[index] - native_control[index]),
            "colipri_best_zoom_prompt_margin": float(values[best] - controls[best]) if best >= 0 else np.nan,
            "colipri_zoom_shuffled_max": float(np.max(controls)) if len(controls) else np.nan,
            "colipri_zoom_shuffled_mean": float(np.mean(controls)) if len(controls) else np.nan,
            "colipri_zoom_shuffled_gap12": float(np.sort(controls)[-1] - np.sort(controls)[-2]) if len(controls) > 1 else 0.0,
            "colipri_zoom_shuffled_minus_native": float(np.max(controls) - native_control[index]) if len(controls) else np.nan,
            "zoom_roi_count": int(len(values)),
        })
    return pd.DataFrame(rows)


def calibrate_score_matrices(
    arrays: dict[str, np.ndarray],
    old_features: pd.DataFrame,
    contrast: np.ndarray,
) -> dict[str, float]:
    """Match canonical H200 score scale using two real prompt anchors per ROI.

    The complete newly scored prompt matrix is transformed row-wise. Nulls still
    select genuinely new prompt columns; no selected scalar feature is shuffled.
    """
    row_index = np.arange(len(old_features))
    slope_values = []

    def calibrate(matrix: np.ndarray, correct_y: np.ndarray, contrast_y: np.ndarray) -> None:
        correct_x = matrix[row_index, row_index].copy()
        contrast_x = matrix[row_index, contrast].copy()
        denominator = correct_x - contrast_x
        slope = np.ones(len(matrix), dtype=np.float32)
        stable = np.abs(denominator) > 1e-7
        slope[stable] = (correct_y[stable] - contrast_y[stable]) / denominator[stable]
        intercept = correct_y - slope * correct_x
        matrix[:] = matrix * slope[:, None] + intercept[:, None]
        slope_values.extend(slope[stable].tolist())

    calibrate(
        arrays["native_scores"],
        old_features.colipri_native_correct.to_numpy(dtype=np.float32),
        old_features.colipri_native_shuffled.to_numpy(dtype=np.float32),
    )
    for rank in range(3):
        valid = arrays["zoom_valid"][:, rank]
        matrix = arrays["zoom_scores"][:, rank]
        correct_y = old_features[f"colipri_zoom_rank{rank + 1}_correct"].to_numpy(dtype=np.float32)
        contrast_y = old_features[f"colipri_zoom_rank{rank + 1}_shuffled"].to_numpy(dtype=np.float32)
        # Invalid ROI rows remain NaN and are never used by build_features.
        sub_rows = np.flatnonzero(valid)
        if not len(sub_rows):
            continue
        correct_x = matrix[sub_rows, sub_rows].copy()
        contrast_x = matrix[sub_rows, contrast[sub_rows]].copy()
        denominator = correct_x - contrast_x
        slope = np.ones(len(sub_rows), dtype=np.float32)
        stable = np.abs(denominator) > 1e-7
        slope[stable] = (
            correct_y[sub_rows][stable] - contrast_y[sub_rows][stable]
        ) / denominator[stable]
        intercept = correct_y[sub_rows] - slope * correct_x
        matrix[sub_rows] = matrix[sub_rows] * slope[:, None] + intercept[:, None]
        slope_values.extend(slope[stable].tolist())
    return {
        "calibration_anchor_count": len(slope_values),
        "slope_min": float(np.min(slope_values)),
        "slope_median": float(np.median(slope_values)),
        "slope_max": float(np.max(slope_values)),
    }


def init_worker(state: dict) -> None:
    global _STATE
    _STATE = state


def run_one(task: tuple[str, int, int]) -> dict:
    null_type, realization, seed = task
    prompts, cases = _STATE["prompts"], _STATE["cases"]
    allowed = _STATE["cross_allowed"] if null_type == "cross_case" else _STATE["same_allowed"]
    primary = solve_assignment(allowed, seed)
    # Canonical A2 used one fixed contrast control. Keep that control fixed for
    # comparability; only repair rows where it collides with the new primary.
    contrast = _STATE["canonical_contrast"].copy()
    rng = np.random.default_rng(seed + 10_000_000)
    for row in range(len(primary)):
        if contrast[row] != primary[row] and canonical.semantically_distinct(
            prompts[primary[row]], prompts[contrast[row]]
        ):
            continue
        candidates = [
            col for col in np.flatnonzero(_STATE["cross_allowed"][row])
            if col != primary[row]
            and canonical.semantically_distinct(prompts[primary[row]], prompts[col])
        ]
        if not candidates:
            raise RuntimeError(f"No valid fixed-control repair for row {row}, seed {seed}")
        contrast[row] = int(candidates[int(rng.integers(len(candidates)))])
    features = build_features(_STATE["manifest"], _STATE["arrays"], primary, contrast)
    merged = _STATE["base"].merge(
        features, on=["finding_key", "file", "finding_idx", "prompt"], validate="one_to_one"
    )
    oof = p0.nested_finding_router(merged, _STATE["folds"])
    return {
        "null_type": null_type,
        "realization": realization,
        "seed": seed,
        "mean_dice": float(oof.dice.mean()),
        "delta_vs_A0": float(oof.dice.mean() - _STATE["a0_mean"]),
        "hits": int(oof.hit.sum()),
        "assignment": primary,
        "contrast": contrast,
    }


def summarize_null(frame: pd.DataFrame, observed: float) -> dict:
    values = frame.delta_vs_A0.to_numpy()
    return {
        "realizations": len(values),
        "mean": float(values.mean()),
        "sd": float(values.std(ddof=1)),
        "median": float(np.median(values)),
        "p2p5": float(np.quantile(values, 0.025)),
        "p5": float(np.quantile(values, 0.05)),
        "p95": float(np.quantile(values, 0.95)),
        "p97p5": float(np.quantile(values, 0.975)),
        "minimum": float(values.min()),
        "maximum": float(values.max()),
        "fraction_ge_observed": float(np.mean(values >= observed)),
        "empirical_p_one_sided": float((1 + np.sum(values >= observed)) / (len(values) + 1)),
        "observed_percentile": float(100 * np.mean(values < observed)),
        "correct_minus_null_mean": float(np.mean(observed - values)),
        "correct_minus_null_median": float(np.median(observed - values)),
    }


def main() -> int:
    args = parse_args()
    if args.output_dir.exists():
        raise FileExistsError(f"Refusing to overwrite {args.output_dir}")
    args.output_dir.mkdir(parents=True)
    if args.nulls < 50:
        raise ValueError("Strict closure requires at least 50 independent nulls")
    if not 1 <= args.workers <= 4:
        raise ValueError("Worker count must be between 1 and 4")

    manifest = pd.read_csv(args.embedding_dir / "embedding_manifest.csv")
    loaded = np.load(args.embedding_dir / "colipri_strict_null_embeddings.npz")
    arrays = {name: loaded[name] for name in loaded.files}
    if len(manifest) != 381 or manifest.file.nunique() != 200:
        raise RuntimeError("Strict null requires the complete canonical 381-finding cohort")
    if not np.array_equal(manifest.finding_key.astype(str), arrays["finding_key"].astype(str)):
        raise RuntimeError("Embedding manifest/finding-key mismatch")

    base = pd.read_csv(P0_DIR / "feature_tables/finding_features.csv")
    folds = pd.read_csv(P0_DIR / "fold_assignments.csv")
    a0 = pd.read_csv(P0_DIR / "binary_router_oof_per_finding.csv")
    canonical_a2 = pd.read_csv(SOURCE / "oof/A2_p0_plus_correct_colipri.csv")
    old_features = pd.read_csv(SOURCE / "colipri_router_features.csv")
    old_shuffle = pd.read_csv(SOURCE / "shuffled_prompt_manifest.csv")
    if not np.isclose(a0.dice.mean(), 0.27891622651020864, atol=1e-12):
        raise RuntimeError("A0 canonical reproduction failed")
    expected_a2 = 0.2805948467792228
    if not np.isclose(canonical_a2.dice.mean(), expected_a2, atol=1e-12):
        raise RuntimeError("Canonical A2 source changed")

    canonical_replay_input = base.merge(
        old_features,
        on=["finding_key", "file", "finding_idx", "prompt"],
        validate="one_to_one",
    )
    canonical_replay = p0.nested_finding_router(canonical_replay_input, folds)
    canonical_replay_mean = float(canonical_replay.dice.mean())
    if abs(canonical_replay_mean - expected_a2) > 1e-12:
        raise RuntimeError(
            f"Canonical feature/router replay failed: {canonical_replay_mean} != {expected_a2}"
        )

    key_to_index = dict(zip(manifest.finding_key, range(len(manifest))))
    correct = np.arange(len(manifest), dtype=np.int32)
    contrast = old_shuffle.set_index("finding_key").loc[
        manifest.finding_key, "shuffled_prompt_source_key"
    ].map(key_to_index).to_numpy(dtype=np.int32)
    calibration = calibrate_score_matrices(arrays, old_features, contrast)
    fresh_correct = build_features(manifest, arrays, correct, contrast)
    score_columns = [
        column for column in old_features.columns
        if column.startswith("colipri_") or column == "zoom_roi_count"
    ]
    joined = fresh_correct.merge(
        old_features[["finding_key", *score_columns]], on="finding_key", suffixes=("_fresh", "_old")
    )
    score_errors = {
        column: float(
            np.nanmax(np.abs(joined[f"{column}_fresh"] - joined[f"{column}_old"]))
        )
        for column in score_columns
    }
    fresh_input = base.merge(
        fresh_correct, on=["finding_key", "file", "finding_idx", "prompt"], validate="one_to_one"
    )
    fresh_a2 = p0.nested_finding_router(fresh_input, folds)
    fresh_mean = float(fresh_a2.dice.mean())
    max_feature_error = max(score_errors.values())
    if max_feature_error > 0.01:
        raise RuntimeError(
            f"Calibrated all-prompt feature error is too large: {max_feature_error}"
        )

    prompts = manifest.prompt.astype(str).tolist()
    cases = manifest.file.astype(str).to_numpy()
    cross_allowed = permitted(prompts, cases)
    same_allowed, same_eligible = same_case_eligible_allowed(cross_allowed, prompts, cases)
    state = {
        "manifest": manifest,
        "arrays": arrays,
        "base": base,
        "folds": folds,
        "prompts": prompts,
        "cases": cases,
        "cross_allowed": cross_allowed,
        "same_allowed": same_allowed,
        "canonical_contrast": contrast,
        "a0_mean": float(a0.dice.mean()),
    }
    tasks = [
        (kind, realization, args.seed + realization + (0 if kind == "cross_case" else 1_000_000))
        for kind in ("cross_case", "same_case_hybrid")
        for realization in range(args.nulls)
    ]
    results = []
    assignments = []
    context = mp.get_context("fork")
    with ProcessPoolExecutor(
        max_workers=args.workers,
        mp_context=context,
        initializer=init_worker,
        initargs=(state,),
    ) as executor:
        futures = {executor.submit(run_one, task): task for task in tasks}
        for complete, future in enumerate(as_completed(futures), start=1):
            value = future.result()
            assignment, alternate = value.pop("assignment"), value.pop("contrast")
            results.append(value)
            for row, source in enumerate(assignment):
                assignments.append({
                    "null_type": value["null_type"],
                    "realization": value["realization"],
                    "target_finding_key": manifest.loc[row, "finding_key"],
                    "source_finding_key": manifest.loc[source, "finding_key"],
                    "contrast_finding_key": manifest.loc[alternate[row], "finding_key"],
                    "same_case": int(cases[row] == cases[source]),
                    "same_case_eligible": int(same_eligible[row]),
                })
            print(f"[A strict null] {complete}/{len(tasks)}", flush=True)

    nulls = pd.DataFrame(results).sort_values(["null_type", "realization"])
    nulls.to_csv(args.output_dir / "null_realization_summary.csv", index=False)
    pd.DataFrame(assignments).to_csv(args.output_dir / "null_prompt_assignments.csv", index=False)
    observed = expected_a2 - float(a0.dice.mean())
    summaries = {
        kind: summarize_null(nulls[nulls.null_type.eq(kind)], observed)
        for kind in nulls.null_type.unique()
    }

    effects = canonical_a2[["finding_key", "file", "category", "dice", "hit"]].merge(
        a0[["finding_key", "dice", "hit", "outer_fold"]],
        on="finding_key", suffixes=("_a2", "_a0"), validate="one_to_one"
    )
    effects["delta"] = effects.dice_a2 - effects.dice_a0
    effects["change"] = np.select(
        [effects.delta > 1e-12, effects.delta < -1e-12], ["improved", "worsened"], default="tied"
    )
    effects.to_csv(args.output_dir / "correct_A2_paired_effects.csv", index=False)
    overall = effects.delta.mean()
    loco = []
    for case, block in effects.groupby("file"):
        remaining = effects[effects.file.ne(case)]
        loco.append({"case": case, "n": len(block), "leave_out_delta": remaining.delta.mean(), "change_vs_all": remaining.delta.mean() - overall})
    pd.DataFrame(loco).sort_values("change_vs_all").to_csv(
        args.output_dir / "leave_one_case_out_influence.csv", index=False
    )
    stability_rows = []
    for grouping in ("outer_fold", "category"):
        for value, block in effects.groupby(grouping):
            remaining = effects[effects[grouping].ne(value)]
            stability_rows.append({"leave_one": grouping, "value": value, "excluded_n": len(block), "remaining_delta": remaining.delta.mean()})
    case_sizes = effects.groupby("file").size()
    effects["case_multiplicity"] = effects.file.map(case_sizes).map(lambda n: "single_finding" if n == 1 else "multi_finding")
    for value, block in effects.groupby("case_multiplicity"):
        stability_rows.append({"leave_one": "subgroup_result", "value": value, "excluded_n": len(block), "remaining_delta": block.delta.mean()})
    pd.DataFrame(stability_rows).to_csv(args.output_dir / "stability_summary.csv", index=False)
    effects.nlargest(10, "delta").to_csv(args.output_dir / "top10_positive_contributors.csv", index=False)
    effects.nsmallest(10, "delta").to_csv(args.output_dir / "top10_negative_contributors.csv", index=False)

    bootstrap = json.loads((PREVIOUS / "result.json").read_text())["A2_minus_A0"]
    primary = summaries["cross_case"]
    stable = max(abs(pd.DataFrame(loco).change_vs_all)) < abs(observed)
    if primary["empirical_p_one_sided"] <= 0.05 and stable and canonical_a2.hit.sum() >= a0.hit.sum():
        verdict = "GO"
    elif observed <= primary["median"] or primary["empirical_p_one_sided"] > 0.2:
        verdict = "NO-GO"
    else:
        verdict = "INCONCLUSIVE"
    result = {
        "verdict": verdict,
        "canonical": {"A0": float(a0.dice.mean()), "A2": expected_a2, "A2_minus_A0": observed, "hits_A0": int(a0.hit.sum()), "hits_A2": int(canonical_a2.hit.sum())},
        "fresh_reproduction": {
            "canonical_router_replay_A2": canonical_replay_mean,
            "L40S_all_prompt_sensitivity_A2": fresh_mean,
            "feature_max_abs_errors": score_errors,
            **calibration,
        },
        "case_bootstrap": bootstrap,
        "nulls": summaries,
        "same_case_eligible_findings": int(same_eligible.sum()),
        "same_case_eligible_cases": int(len(set(cases[same_eligible]))),
        "hashes": {str(path): sha256(path) for path in [P0_DIR / "feature_tables/finding_features.csv", P0_DIR / "fold_assignments.csv", P0_DIR / "binary_router_oof_per_finding.csv", SOURCE / "oof/A2_p0_plus_correct_colipri.csv"]},
    }
    (args.output_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    report = f"""# CoLiPri Experiment A Strict Null Closure

**Verdict: {verdict}.**

## Canonical reproduction

- A0: {result['canonical']['A0']:.9f}
- A2: {result['canonical']['A2']:.9f}
- A2-A0: {observed:+.9f}
- Canonical feature/router replay A2: {canonical_replay_mean:.9f}
- Calibrated L40S all-prompt sensitivity A2: {fresh_mean:.9f} (reported separately; the observed effect remains the canonical H200 A2)
- Findings/cases: 381/200; fold IDs and canonical input hashes were held fixed.

## Strict cross-case semantic null

The primary null contains {primary['realizations']} independent constrained prompt permutations. Every assignment uses another case, preserves the complete prompt pool, excludes normalized duplicates and detectable semantic equivalents, recomputes all image-text similarities from frozen image/text embeddings, and refits the complete nested router.

```json
{json.dumps(primary, indent=2)}
```

The paired case-cluster bootstrap for correct A2-A0 remains [{bootstrap['ci95_low']:+.6f}, {bootstrap['ci95_high']:+.6f}]. This interval and the permutation p-value answer different questions and are intentionally reported separately.

## Harder same-case null

Only cases admitting a complete semantically distinct within-case derangement were forced to same-case assignment; all other rows used constrained cross-case assignments while retaining a global one-to-one prompt permutation. Eligible findings/cases: {int(same_eligible.sum())}/{int(len(set(cases[same_eligible])))}.

```json
{json.dumps(summaries['same_case_hybrid'], indent=2)}
```

## Stability

- Improved/worsened/tied findings: {(effects.change == 'improved').sum()}/{(effects.change == 'worsened').sum()}/{(effects.change == 'tied').sum()}.
- Single- and multi-finding subgroup results, leave-one-fold/category summaries, leave-one-case influence, and top contributors are saved beside this report.
- Maximum absolute leave-one-case change relative to the full A2-A0 effect: {max(abs(pd.DataFrame(loco).change_vs_all)):.6f}.

The conclusion is based on the strict cross-case null, while the same-case hybrid is a separately labeled harder control.
"""
    report_path = ROOT / "reports/colipri_experiment_A_strict_null_closure.md"
    report_path.write_text(report)
    print(json.dumps(result, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
