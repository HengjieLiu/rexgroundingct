#!/usr/bin/env python3
"""Analyze whether a separately preprocessed CoLiPri branch adds to native VoxTell."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parents[1]
NATIVE = (
    ROOT
    / "outputs/prompt_standardization_rule_only_v1"
    / "stratified30_six_variant_ablation_v1/per_finding_threshold_metrics.csv"
)
SEED = 20260727


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--colipri-csv", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--variant", required=True)
    return parser.parse_args()


def prompt_features(text: str) -> dict[str, float]:
    words = re.findall(r"[a-z0-9]+", str(text).lower())
    return {
        "prompt_chars": float(len(str(text))),
        "prompt_words": float(len(words)),
        "prompt_plural": float(any(word.endswith("s") for word in words)),
        "prompt_bilateral": float(
            any(piece in str(text).lower() for piece in ("bilateral", "both lungs", "both sides"))
        ),
    }


def bootstrap(frame: pd.DataFrame, samples: int = 5000) -> tuple[float, float]:
    case_delta = frame.groupby("case").delta.mean().to_numpy()
    rng = np.random.default_rng(SEED)
    draws = rng.choice(case_delta, (samples, len(case_delta)), replace=True).mean(axis=1)
    return float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=False)
    native = pd.read_csv(NATIVE)
    native = native.loc[
        native.variant.eq("original") & np.isclose(native.threshold, 0.5)
    ].copy()
    native = native.rename(
        columns={
            "global_hit": "native_hit",
            "dice": "native_dice",
            "pred_voxels": "native_pred_voxels",
            "empty_prediction": "native_empty",
            "mean_probability": "native_mean_probability",
            "mean_logit": "native_mean_logit",
            "connected_components": "native_components",
        }
    )
    native = native[
        [
            "case",
            "finding_idx",
            "native_hit",
            "native_dice",
            "native_pred_voxels",
            "native_empty",
            "native_mean_probability",
            "native_mean_logit",
            "native_components",
        ]
    ]

    colipri = pd.read_csv(args.colipri_csv).rename(columns={"case_id": "case"})
    colipri = colipri.loc[colipri.variant.eq(args.variant)].copy()
    if colipri.empty:
        raise ValueError(f"Variant {args.variant!r} is absent from {args.colipri_csv}")
    prompts = (
        colipri[["case", "finding_idx", "prompt"]]
        .drop_duplicates(["case", "finding_idx"])
        .copy()
    )
    prompt_frame = pd.DataFrame(
        [prompt_features(text) for text in prompts.prompt],
        index=prompts.index,
    )
    prompts = pd.concat([prompts, prompt_frame], axis=1)

    keys = ["case", "finding_idx"]
    expected = native[keys].drop_duplicates()
    summaries = []
    aligned_by_threshold: dict[float, pd.DataFrame] = {}
    for threshold, block in colipri.groupby("threshold", sort=True):
        block = block.rename(
            columns={
                "dice": "colipri_dice",
                "hit": "colipri_hit",
                "pred_voxels": "colipri_pred_voxels",
                "empty_prediction": "colipri_empty",
            }
        )
        aligned = native.merge(
            block[
                keys
                + [
                    "colipri_dice",
                    "colipri_hit",
                    "colipri_pred_voxels",
                    "colipri_empty",
                ]
            ],
            on=keys,
            validate="one_to_one",
        ).merge(prompts.drop(columns="prompt"), on=keys, validate="one_to_one")
        if len(aligned) != len(expected):
            raise AssertionError(f"Expected {len(expected)} matched findings, got {len(aligned)}")
        aligned["threshold"] = float(threshold)
        aligned["colipri_native_volume_ratio"] = (
            aligned.colipri_pred_voxels / aligned.native_pred_voxels.clip(lower=1)
        )
        aligned_by_threshold[float(threshold)] = aligned
        summaries.append(
            {
                "threshold": float(threshold),
                "native_dice": aligned.native_dice.mean(),
                "colipri_dice": aligned.colipri_dice.mean(),
                "delta": (aligned.colipri_dice - aligned.native_dice).mean(),
                "native_hits": int(aligned.native_hit.sum()),
                "colipri_hits": int(aligned.colipri_hit.sum()),
                "native_mean_pred_voxels": aligned.native_pred_voxels.mean(),
                "colipri_mean_pred_voxels": aligned.colipri_pred_voxels.mean(),
            }
        )
    summary = pd.DataFrame(summaries)
    summary.to_csv(args.output_dir / "threshold_comparison.csv", index=False)

    # Upper bound across native and every calibrated CoLiPri threshold.
    native_ordered = native.sort_values(keys).reset_index(drop=True)
    candidates = {"native": native_ordered.native_dice.to_numpy()}
    candidate_hits = {"native": native_ordered.native_hit.to_numpy()}
    for threshold, aligned in aligned_by_threshold.items():
        aligned = aligned.sort_values(keys).reset_index(drop=True)
        candidates[f"colipri_{threshold:.2f}"] = aligned.colipri_dice.to_numpy()
        candidate_hits[f"colipri_{threshold:.2f}"] = aligned.colipri_hit.to_numpy()
    matrix = np.column_stack(list(candidates.values()))
    best_index = matrix.argmax(axis=1)
    names = list(candidates)
    oracle_dice = matrix[np.arange(len(matrix)), best_index]
    oracle_hits = np.array(
        [candidate_hits[names[index]][row] for row, index in enumerate(best_index)]
    )
    oracle = {
        "mean_dice": float(oracle_dice.mean()),
        "delta_vs_native": float(oracle_dice.mean() - native_ordered.native_dice.mean()),
        "hits": int(oracle_hits.sum()),
        "selection_counts": {
            name: int(np.sum(best_index == index)) for index, name in enumerate(names)
        },
    }

    # Nested case-OOF hard selector.  Each outer fold first chooses its CoLiPri
    # threshold using training cases only, then learns expected Dice utility
    # from inference-available features.  Inner predictions tune a conservative
    # switch margin with no hit loss and <=20% prediction-volume inflation.
    case_names = np.asarray(sorted(native.case.unique()))
    fold_map = {}
    for fold, (_, test) in enumerate(GroupKFold(5).split(case_names, groups=case_names)):
        fold_map.update({case_names[index]: fold for index in test})
    outputs = []
    features = [
        "native_pred_voxels",
        "native_empty",
        "native_mean_probability",
        "native_mean_logit",
        "native_components",
        "colipri_pred_voxels",
        "colipri_empty",
        "colipri_native_volume_ratio",
        "prompt_chars",
        "prompt_words",
        "prompt_plural",
        "prompt_bilateral",
    ]
    for outer in range(5):
        train_cases = {case for case, fold in fold_map.items() if fold != outer}
        test_cases = {case for case, fold in fold_map.items() if fold == outer}
        threshold_scores = []
        for threshold, aligned in aligned_by_threshold.items():
            train = aligned.loc[aligned.case.isin(train_cases)]
            threshold_scores.append(
                (
                    float(train.colipri_dice.mean()),
                    -float(train.colipri_pred_voxels.mean()),
                    threshold,
                )
            )
        selected_threshold = max(threshold_scores)[2]
        data = aligned_by_threshold[selected_threshold].copy()
        train = data.loc[data.case.isin(train_cases)].reset_index(drop=True)
        test = data.loc[data.case.isin(test_cases)].reset_index(drop=True)
        target = (train.colipri_dice - train.native_dice).to_numpy()
        groups = train.case.to_numpy()
        inner_prediction = np.zeros(len(train), dtype=float)
        inner_splits = min(4, len(np.unique(groups)))
        for inner_train, inner_val in GroupKFold(inner_splits).split(
            train[features], groups=groups
        ):
            model = make_pipeline(SimpleImputer(), StandardScaler(), Ridge(alpha=10.0))
            model.fit(train.loc[inner_train, features], target[inner_train])
            inner_prediction[inner_val] = model.predict(train.loc[inner_val, features])
        margins = np.unique(
            np.r_[np.inf, np.quantile(inner_prediction, np.linspace(0, 1, 31))]
        )
        valid = []
        for margin in margins:
            choose = inner_prediction > margin
            dice = np.where(choose, train.colipri_dice, train.native_dice)
            hits = np.where(choose, train.colipri_hit, train.native_hit)
            volume = np.where(
                choose, train.colipri_pred_voxels, train.native_pred_voxels
            )
            hit_loss = int(train.native_hit.sum() - hits.sum())
            volume_ratio = float(volume.mean() / max(train.native_pred_voxels.mean(), 1))
            if hit_loss <= 0 and volume_ratio <= 1.20:
                valid.append((float(dice.mean()), -float(choose.mean()), float(margin)))
        margin = max(valid)[2] if valid else float("inf")
        model = make_pipeline(SimpleImputer(), StandardScaler(), Ridge(alpha=10.0))
        model.fit(train[features], target)
        score = model.predict(test[features])
        choose = score > margin
        test["selected"] = np.where(choose, "colipri", "native")
        test["dice"] = np.where(choose, test.colipri_dice, test.native_dice)
        test["hit"] = np.where(choose, test.colipri_hit, test.native_hit)
        test["pred_voxels"] = np.where(
            choose, test.colipri_pred_voxels, test.native_pred_voxels
        )
        test["outer_fold"] = outer
        test["selected_threshold"] = selected_threshold
        test["margin"] = margin
        outputs.append(test)
    oof = pd.concat(outputs).sort_values(keys).reset_index(drop=True)
    oof["delta"] = oof.dice - oof.native_dice
    oof.to_csv(args.output_dir / "oof_router_per_finding.csv", index=False)
    ci_low, ci_high = bootstrap(oof)
    router = {
        "mean_dice": float(oof.dice.mean()),
        "native_mean_dice": float(oof.native_dice.mean()),
        "delta": float(oof.delta.mean()),
        "ci95": [ci_low, ci_high],
        "hits": int(oof.hit.sum()),
        "native_hits": int(oof.native_hit.sum()),
        "mean_pred_voxels": float(oof.pred_voxels.mean()),
        "native_mean_pred_voxels": float(oof.native_pred_voxels.mean()),
        "selection_counts": oof.selected.value_counts().to_dict(),
    }
    decision = {
        "status": "complete",
        "variant": args.variant,
        "native_preprocessing": "VoxTell native",
        "colipri_preprocessing": "CoLiPri official 2mm/center192",
        "oracle": oracle,
        "oof_router": router,
        "go_to_dense_feature_fusion": bool(
            router["delta"] >= 0.003
            and router["hits"] >= router["native_hits"] - 1
            and router["mean_pred_voxels"]
            <= 1.20 * router["native_mean_pred_voxels"]
        ),
    }
    (args.output_dir / "decision.json").write_text(json.dumps(decision, indent=2) + "\n")
    report_table = "```csv\n" + summary.to_csv(index=False, float_format="%.6f").strip() + "\n```"
    report = [
        f"# CoLiPri dual-preprocessing follow-up: {args.variant}",
        "",
        report_table,
        "",
        f"- Oracle delta versus native: `{oracle['delta_vs_native']:+.6f}`.",
        f"- Nested case-OOF router delta: `{router['delta']:+.6f}`.",
        f"- OOF case-bootstrap 95% CI: `{router['ci95']}`.",
        f"- Hit change: `{router['hits'] - router['native_hits']:+d}`.",
        f"- Proceed to dense feature fusion: `{decision['go_to_dense_feature_fusion']}`.",
    ]
    (args.output_dir / "REPORT.md").write_text("\n".join(report) + "\n")
    print(json.dumps(decision, indent=2))


if __name__ == "__main__":
    main()
