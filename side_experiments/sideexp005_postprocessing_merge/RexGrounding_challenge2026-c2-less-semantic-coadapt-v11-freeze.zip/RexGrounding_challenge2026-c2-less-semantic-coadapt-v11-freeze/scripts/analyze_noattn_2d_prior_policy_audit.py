#!/usr/bin/env python3
"""Audit lost 2d hits and recall-safe conversion policies without model inference."""

from __future__ import annotations

import json
import math
import re
import sys
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd
from scipy import ndimage
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import analyze_2d_s3prior_component_verifier as verifier  # noqa: E402

SOURCE = ROOT / "outputs/2d_noattn_prior_verifier_feasibility"
OUT = ROOT / "outputs/2d_noattn_prior_verifier_policy_audit"
BASE_SEG = ROOT / "outputs/nonattention_baseline_selection/full381_update10000"
BASE_METRICS = BASE_SEG / "summary_tables/per_finding_metrics.csv"
GT_DIR = ROOT / "data/segmentations"
CT_DIR = ROOT / "data/ct_rate_volumes_fixed"
PRIOR_DIR = SOURCE / "maps_component/prior_maps"
KEYS = ["file", "finding_idx"]
STRUCTURE = ndimage.generate_binary_structure(3, 3)
SEED = 260812


def write_json(name: str, value: object) -> None:
    (OUT / name).write_text(json.dumps(value, indent=2, default=str) + "\n")


def top_mean(values: np.ndarray, fraction: float) -> float:
    count = max(1, int(math.ceil(len(values) * fraction)))
    return float(np.partition(values, len(values) - count)[-count:].mean())


def original_findings(per: pd.DataFrame) -> pd.DataFrame:
    return per[(per.arm == "component") & (per.strategy == "original")].copy()


def metrics_from_keep(group: pd.DataFrame, reference: pd.Series, keep: np.ndarray) -> dict:
    kept = group.iloc[np.flatnonzero(keep)]
    pred = int(kept.component_voxels.sum()) if len(kept) else 0
    tp = int(kept.overlap_voxels.sum()) if len(kept) else 0
    gt = int(reference.gt_voxels)
    fp, fn = pred - tp, gt - tp
    dice = 2 * tp / max(pred + gt, 1)
    return {
        "dice": dice, "hit": dice >= .1, "tp": tp, "fp": fp, "fn": fn,
        "pred_voxels": pred, "gt_voxels": gt, "precision": tp / max(pred, 1),
        "recall": tp / max(gt, 1), "FP_GT": fp / max(gt, 1),
        "FN_GT": fn / max(gt, 1), "predicted_GT_volume_ratio": pred / max(gt, 1),
        "kept_components": int(keep.sum()),
    }


def base_keep(group: pd.DataFrame, strategy: str, global_frame: pd.DataFrame) -> np.ndarray:
    n = len(group)
    if strategy == "original":
        return np.ones(n, dtype=bool)
    match = re.fullmatch(r"top(1|2|3|5)_(.+)", strategy)
    if match:
        count, score = int(match.group(1)), match.group(2)
        order = np.argsort(-group[score].to_numpy(float), kind="stable")
        keep = np.zeros(n, dtype=bool); keep[order[:count]] = True
        return keep
    match = re.fullmatch(r"prune_q(05|10|20)_(.+)", strategy)
    if match:
        q, score = int(match.group(1)) / 100, match.group(2)
        values = group[score].to_numpy(float); volumes = group.component_voxels.to_numpy(float)
        keep = np.ones(n, dtype=bool)
        if n > 1:
            keep[(values <= np.quantile(values, q)) & (volumes <= np.median(volumes))] = False
            if not keep.any(): keep[int(np.argmax(values))] = True
        return keep
    match = re.fullmatch(r"fusion_(.+)_lambda(0.25|0.5|1|2)_top(1|2|3|5)", strategy)
    if match:
        score, lam, count = match.group(1), float(match.group(2)), int(match.group(3))
        def z(column: str) -> np.ndarray:
            mean, std = global_frame[column].mean(), global_frame[column].std()
            return (group[column].to_numpy(float) - mean) / (std if std > 0 else 1)
        values = z("seg_log_volume") + lam * z(score)
        order = np.argsort(-values, kind="stable")
        keep = np.zeros(n, dtype=bool); keep[order[:count]] = True
        return keep
    raise ValueError(f"Unknown strategy: {strategy}")


def protect_keep(group: pd.DataFrame, keep: np.ndarray, rule: str) -> tuple[np.ndarray, str]:
    protected = keep.copy()
    if rule == "A_sole_component":
        if len(group) == 1: protected[:] = True
        return protected, "evaluable"
    if rule == "B_never_leave_zero":
        if not protected.any() and len(group): protected[int(np.argmax(group.s_top5))] = True
        return protected, "partial_no_seg_probability"
    if rule in {"C_top_seg_confidence", "D_seg_confidence_q75"}:
        return protected, "not_evaluable_missing_seg_probability"
    match = re.fullmatch(r"E_small_(50|100|250|500|1000)", rule)
    if match:
        threshold = int(match.group(1)); scores = group.s_top5.to_numpy(float)
        kept_max = float(scores[protected].max()) if protected.any() else -np.inf
        risky = (group.component_voxels.to_numpy(int) < threshold) & (~protected)
        # A component is pruned only when retained prior support is >=25% stronger.
        protected[risky & (kept_max < 1.25 * scores)] = True
        return protected, "evaluable_prior_gap_1.25x"
    match = re.fullmatch(r"F_prior_top([123])", rule)
    if match:
        count = int(match.group(1)); order = np.argsort(-group.s_top5.to_numpy(float), kind="stable")
        protected[order[:count]] = True
        return protected, "evaluable_s_top5"
    if rule == "G_combined":
        order = np.argsort(-group.s_top5.to_numpy(float), kind="stable")
        protected[order[:2]] = True
        if len(group) == 1: protected[:] = True
        return protected, "partial_top2_prior_and_sole_only_missing_seg_probability"
    if rule == "none": return protected, "evaluable"
    raise ValueError(rule)


def summarize(candidate: pd.DataFrame, reference: pd.DataFrame) -> dict:
    merged = reference.merge(candidate, on=KEYS, suffixes=("_ref", "_new"), validate="one_to_one")
    d = merged.dice_new - merged.dice_ref
    small = merged.small_2d_new.astype(bool)
    return {
        "n": len(merged), "mean_dice": float(merged.dice_new.mean()), "dice_delta": float(d.mean()),
        "small_dice_delta": float(d[small].mean()), "hits": int(merged.hit_new.sum()),
        "hit_delta": int(merged.hit_new.sum() - merged.hit_ref.sum()),
        "small_hits_delta": int(merged.loc[small, "hit_new"].sum() - merged.loc[small, "hit_ref"].sum()),
        "FP_GT_delta": float((merged.FP_GT_new - merged.FP_GT_ref).mean()),
        "precision_delta": float((merged.precision_new - merged.precision_ref).mean()),
        "recall_delta": float((merged.recall_new - merged.recall_ref).mean()),
        "improved": int((d > 1e-12).sum()), "degraded": int((d < -1e-12).sum()),
        "tied": int((d.abs() <= 1e-12).sum()),
        "new_hits": int((merged.hit_new & ~merged.hit_ref).sum()),
        "lost_hits": int((~merged.hit_new & merged.hit_ref).sum()),
    }


def cluster_bootstrap(candidate: pd.DataFrame, reference: pd.DataFrame, small: bool, seed: int) -> dict:
    merged = reference.merge(candidate, on=KEYS, suffixes=("_ref", "_new"), validate="one_to_one")
    if small: merged = merged[merged.small_2d_new]
    cases = sorted(merged.file.unique())
    sums = merged.assign(delta=merged.dice_new - merged.dice_ref).groupby("file").delta.sum().reindex(cases).to_numpy()
    counts = merged.groupby("file").size().reindex(cases).to_numpy()
    rng = np.random.default_rng(seed); draws = np.empty(10000)
    for start in range(0, 10000, 500):
        idx = rng.integers(0, len(cases), size=(min(500, 10000-start), len(cases)))
        draws[start:start+len(idx)] = sums[idx].sum(1) / counts[idx].sum(1)
    return {"paired_dice_delta": float((merged.dice_new-merged.dice_ref).mean()),
            "ci_low": float(np.quantile(draws, .025)), "ci_high": float(np.quantile(draws, .975)),
            "p_delta_gt_0": float((draws > 0).mean()), "replicates": 10000}


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    expected = ["baseline_component_table.csv", "component_scores_component_prior.csv",
                "component_scores_oldloss_prior.csv", "component_scores_s3prior_comparison.csv",
                "component_ranking_summary.csv", "component_ranking_by_subgroup.csv",
                "mask_strategy_summary_same_cohort.csv", "mask_strategy_per_finding_same_cohort.csv",
                "crossfit_strategy_summary.json", "crossfit_per_finding.csv",
                "crossfit_selected_strategies.csv", "oracle_upper_bound_summary.json",
                "bootstrap_results.csv", "leave_one_case_out.csv", "decision.json", "report.md"]
    found = {name: (SOURCE/name).exists() for name in expected}
    map_count = len(list(PRIOR_DIR.glob("*.npz")))
    probability_files = [str(p) for p in BASE_SEG.rglob("*") if p.is_file() and re.search(r"prob|logit", p.name, re.I)]
    write_json("input_files_found.json", {"expected": found, "all_expected_found": all(found.values()),
               "component_prior_maps": map_count, "baseline_probability_or_logit_maps": probability_files,
               "p3_low_threshold_rescue_available": bool(probability_files)})
    if not all(found.values()) or map_count != 132: raise RuntimeError("Required table or prior map missing")

    components = pd.read_csv(SOURCE / "component_scores_component_prior.csv")
    per = pd.read_csv(SOURCE / "mask_strategy_per_finding_same_cohort.csv")
    cross = pd.read_csv(SOURCE / "crossfit_per_finding.csv")
    reference = original_findings(per)
    reference = reference[[*KEYS, "pixels", "small_2d", "dice", "hit", "tp", "fp", "fn", "pred_voxels",
                           "gt_voxels", "precision", "recall", "FP_GT", "FN_GT", "predicted_GT_volume_ratio", "kept_components"]]
    folds = cross[["file", "fold"]].drop_duplicates().sort_values("file")
    if folds.file.duplicated().any(): raise RuntimeError("Case appears in multiple folds")
    write_json("fold_assignments.json", {"seed": 260811, "case_level": True,
               "assignments": dict(zip(folds.file, folds.fold.astype(int)))})
    provenance = json.loads((SOURCE / "provenance.json").read_text())
    write_json("provenance.json", {"source": str(SOURCE), "source_provenance": provenance,
               "baseline_segmentation": str(BASE_SEG), "baseline_metrics": str(BASE_METRICS),
               "prior_checkpoint": str(SOURCE / "component/checkpoints/checkpoint_update_300.pth"),
               "coordinate_sanity": json.loads((SOURCE / "coordinate_sanity_check.json").read_text()),
               "analysis_only": True, "model_weights_modified": False})

    # P1: identify and reconstruct exact lost-hit component decisions.
    merged = reference.merge(cross, on=KEYS, suffixes=("_base", "_cross"), validate="one_to_one")
    lost = merged[merged.hit_base & ~merged.hit_cross].copy()
    if len(lost) != 3 or not lost.small_2d_cross.all(): raise RuntimeError(f"Expected 3 lost small hits, got {len(lost)}")
    detailed, compact = [], []
    for _, finding in lost.iterrows():
        keymask = (components.file == finding.file) & (components.finding_idx == finding.finding_idx)
        group = components[keymask].sort_values("component_id").copy()
        keep = base_keep(group, finding.selected_strategy, components)
        gt_img = nib.load(str(GT_DIR / finding.file)); ct_img = nib.load(str(CT_DIR / finding.file))
        gt = np.asarray(np.asanyarray(gt_img.dataobj[int(finding.finding_idx)]) > 0)
        spacing = np.asarray(nib.affines.voxel_sizes(ct_img.affine)); labels, _ = ndimage.label(gt, STRUCTURE)
        pred_img = nib.load(str(BASE_SEG / finding.file)); pred = np.asarray(np.asanyarray(pred_img.dataobj[int(finding.finding_idx)]) > 0)
        plabels, _ = ndimage.label(pred, STRUCTURE); objects = ndimage.find_objects(plabels)
        for score in ["s_max","s_top1","s_top5","s_mean","s_mass","s_mass_density","seg_log_volume"]:
            group[f"rank_{score}"] = group[score].rank(method="first", ascending=False).astype(int)
        pruned_positive = group[group.gt_overlap_positive & ~keep]
        for pos, (_, row) in enumerate(group.iterrows()):
            obj = objects[int(row.component_id)-1]; local = plabels[obj] == int(row.component_id)
            starts = np.asarray([a.start for a in obj]); coords = np.argwhere(local) + starts
            detailed.append({"case_id": finding.file, "finding_id": int(finding.finding_idx), "category": "2d",
                "size_stratum": "small_2d", "gt_voxels": int(gt.sum()), "gt_physical_volume_mm3": float(gt.sum()*np.prod(spacing)),
                "gt_component_count": int(labels.max()), "predicted_component_count": len(group),
                "baseline_dice": finding.dice_base, "verifier_dice": finding.dice_cross, "fold": int(finding.fold),
                "strategy": finding.selected_strategy, "component_id": int(row.component_id),
                "component_voxels": int(row.component_voxels), "physical_volume_mm3": row.physical_volume_mm3,
                "bbox_xyz": json.dumps([[int(a.start),int(a.stop)] for a in obj]),
                "centroid_xyz": json.dumps(coords.mean(0).tolist()), "overlap_voxels": int(row.overlap_voxels),
                "overlap_dice_with_gt": row.overlap_dice_with_gt, "gt_overlap_positive": bool(row.gt_overlap_positive),
                "distance_to_nearest_gt_mm": row.distance_to_nearest_gt_mm,
                "seg_probability_available": False, "seg_max": np.nan, "seg_top1": np.nan, "seg_top5": np.nan, "seg_mean": np.nan,
                **{s: row[s] for s in ["s_max","s_top1","s_top5","s_mean","s_mass","s_mass_density","prior_peak_distance_mm"]},
                **{f"rank_{s}": int(row[f"rank_{s}"]) for s in ["s_max","s_top1","s_top5","s_mean","s_mass","s_mass_density","seg_log_volume"]},
                "kept": bool(keep[pos])})
        compact.append({"case_id": finding.file, "finding_id": int(finding.finding_idx), "size_stratum": "small_2d",
            "gt_voxels": int(gt.sum()), "gt_physical_volume_mm3": float(gt.sum()*np.prod(spacing)),
            "gt_component_count": int(labels.max()), "predicted_component_count": len(group),
            "baseline_dice": finding.dice_base, "verifier_dice": finding.dice_cross, "fold": int(finding.fold),
            "strategy": finding.selected_strategy, "pruned_gt_components": int(len(pruned_positive)),
            "only_predicted_component": len(group)==1, "only_gt_overlap_component": int(group.gt_overlap_positive.sum())==1,
            "pruned_positive_ids": json.dumps(pruned_positive.component_id.astype(int).tolist()),
            "pruned_positive_prior_ranks_s_top5": json.dumps(pruned_positive.rank_s_top5.astype(int).tolist()),
            "higher_prior_FP_remained": bool(any((~group.gt_overlap_positive) & keep & (group.s_top5 >= pruned_positive.s_top5.min()))) if len(pruned_positive) else False,
            "segmentation_confidence_audit": "unavailable_no_saved_probability_map"})
    pd.DataFrame(compact).to_csv(OUT / "lost_hit_audit_summary.csv", index=False)
    pd.DataFrame(detailed).to_csv(OUT / "lost_hit_audit_components.csv", index=False)

    # P1B and candidate protected strategy table.
    rules = ["none","A_sole_component","B_never_leave_zero","C_top_seg_confidence","D_seg_confidence_q75",
             *[f"E_small_{v}" for v in [50,100,250,500,1000]], *[f"F_prior_top{k}" for k in [1,2,3]], "G_combined"]
    protected_rows, rule_status = [], {}
    for _, ref in reference.iterrows():
        group = components[(components.file==ref.file)&(components.finding_idx==ref.finding_idx)].sort_values("component_id")
        chosen = str(cross.loc[(cross.file==ref.file)&(cross.finding_idx==ref.finding_idx), "selected_strategy"].iloc[0])
        base = base_keep(group, chosen, components)
        for rule in rules:
            keep, status = protect_keep(group, base, rule); rule_status[rule] = status
            protected_rows.append({"file":ref.file,"finding_idx":int(ref.finding_idx),"pixels":int(ref.pixels),
                "small_2d":bool(ref.small_2d),"rule":rule,"base_strategy":chosen,
                "rescued_components":int((keep & ~base).sum()),
                "unpruned_fp_components":int((keep & ~base & ~group.gt_overlap_positive.to_numpy(bool)).sum()),
                **metrics_from_keep(group, ref, keep)})
    protected = pd.DataFrame(protected_rows)
    protected.to_csv(OUT / "lost_hit_protection_rule_per_finding.csv", index=False)
    result_rows=[]
    lost_keys=set(map(tuple,lost[KEYS].itertuples(index=False,name=None)))
    for rule, frame in protected.groupby("rule"):
        stats=summarize(frame,reference); merge_lost=reference.merge(frame,on=KEYS,suffixes=("_ref","_new"))
        merge_lost=merge_lost[[tuple(x) in lost_keys for x in merge_lost[KEYS].itertuples(index=False,name=None)]]
        result_rows.append({"rule":rule,"evaluation_status":rule_status[rule],**stats,
            "components_rescued_from_pruning":int(frame.rescued_components.sum()),
            "FP_components_unpruned":int(frame.unpruned_fp_components.sum()),
            "lost_small_hits_recovered":int((merge_lost.hit_new & ~merge_lost.hit_ref.eq(False)).sum())})
    protection_summary=pd.DataFrame(result_rows)
    protection_summary.to_csv(OUT / "lost_hit_protection_rule_results.csv",index=False)

    # Build all base candidates plus protected versions of the two selected top-5 policies.
    base_component = per[per.arm=="component"].copy()
    candidates={name:frame.copy() for name,frame in base_component.groupby("strategy")}
    evaluable_rules=[r for r in rules if not rule_status[r].startswith("not_evaluable") and r!="none"]
    for base_name in ["top5_s_max","top5_seg_log_volume"]:
        for rule in evaluable_rules:
            rows=[]
            for _,ref in reference.iterrows():
                group=components[(components.file==ref.file)&(components.finding_idx==ref.finding_idx)].sort_values("component_id")
                keep,_=protect_keep(group,base_keep(group,base_name,components),rule)
                rows.append({"file":ref.file,"finding_idx":int(ref.finding_idx),"pixels":int(ref.pixels),"small_2d":bool(ref.small_2d),
                             "strategy":f"{base_name}__protect_{rule}",**metrics_from_keep(group,ref,keep)})
            candidates[f"{base_name}__protect_{rule}"]=pd.DataFrame(rows)

    # P2: same fixed folds, train-only selection with explicit no-op fallback.
    fold_lookup=dict(zip(folds.file,folds.fold.astype(int)))
    modes={"strict_hit_safe":lambda s:s["hit_delta"]>=0 and s["small_hits_delta"]>=0,
           "all_hit_safe":lambda s:s["hit_delta"]>=0,
           "recall_safe":lambda s:s["hit_delta"]>=0 and s["recall_delta"]>=-.005}
    all_held=[]; selected=[]
    for mode,valid in modes.items():
        for fold in range(5):
            train_cases={f for f,v in fold_lookup.items() if v!=fold}; test_cases={f for f,v in fold_lookup.items() if v==fold}
            train_ref=reference[reference.file.isin(train_cases)]
            scored=[]
            for name,frame in candidates.items():
                block=frame[frame.file.isin(train_cases)]; stats=summarize(block,train_ref)
                if valid(stats): scored.append({"strategy":name,**stats})
            nontrivial=[s for s in scored if s["strategy"]!="original" and s["dice_delta"]>1e-4]
            if nontrivial:
                chosen=sorted(nontrivial,key=lambda s:(s["dice_delta"],-s["FP_GT_delta"],s["recall_delta"]),reverse=True)[0]
            else:
                chosen=next((s for s in scored if s["strategy"]=="original"),{"strategy":"original",**summarize(candidates["original"][candidates["original"].file.isin(train_cases)],train_ref)})
            selected.append({"mode":mode,"fold":fold,"selected_strategy":chosen["strategy"],"no_op":chosen["strategy"]=="original",
                             **{f"training_{k}":v for k,v in chosen.items() if k!="strategy"}})
            held=candidates[chosen["strategy"]]; held=held[held.file.isin(test_cases)].copy(); held["mode"]=mode; held["fold"]=fold; held["selected_strategy"]=chosen["strategy"]
            all_held.append(held)
    held=pd.concat(all_held,ignore_index=True); selected_df=pd.DataFrame(selected)
    held.to_csv(OUT/"recall_constrained_crossfit_per_finding.csv",index=False)
    selected_df.to_csv(OUT/"recall_constrained_selected_strategies.csv",index=False)
    mode_rows=[]
    for mode,frame in held.groupby("mode"):
        mode_rows.append({"mode":mode,"no_op_folds":int(selected_df[selected_df["mode"].eq(mode)].no_op.sum()),**summarize(frame,reference)})
    mode_summary=pd.DataFrame(mode_rows).sort_values("dice_delta",ascending=False)
    mode_summary.to_csv(OUT/"recall_constrained_crossfit_summary.csv",index=False)
    safe_modes=mode_summary[(mode_summary.hit_delta>=0)&(mode_summary.small_hits_delta>=0)]
    best_mode=str((safe_modes if len(safe_modes) else mode_summary[mode_summary["mode"].eq("recall_safe")]).iloc[0]["mode"])
    best_held=held[held["mode"].eq(best_mode)]
    boots=[]
    for small,label in [(False,"all_2d"),(True,"small_2d")]:
        boots.append({"mode":best_mode,"stratum":label,**cluster_bootstrap(best_held,reference,small,SEED+len(boots)),
                      "hit_delta":summarize(best_held,reference)["hit_delta"],"FP_GT_delta":summarize(best_held,reference)["FP_GT_delta"]})
    pd.DataFrame(boots).to_csv(OUT/"recall_constrained_bootstrap.csv",index=False)
    influence=[]
    for case in sorted(reference.file.unique()):
        influence.append({"mode":best_mode,"left_out_case":case,
                          "dice_delta":summarize(best_held[best_held.file!=case],reference[reference.file!=case])["dice_delta"]})
    pd.DataFrame(influence).to_csv(OUT/"recall_constrained_leave_one_case_out.csv",index=False)

    # P2B: prediction-side component-count gates around the best evaluable protected rule.
    eligible=protection_summary[(~protection_summary.evaluation_status.str.startswith("not_evaluable")) &
                                (protection_summary.hit_delta>=0)&(protection_summary.small_hits_delta>=0)]
    best_rule=str((eligible if len(eligible) else protection_summary[protection_summary.rule.eq("G_combined")]).sort_values("dice_delta",ascending=False).iloc[0].rule)
    base_protected=protected[protected.rule.eq(best_rule)]
    burden=[]
    count_map=components.groupby(KEYS).size()
    for name,threshold in [("H1_component_count_ge3",3),("H2_component_count_ge5",5)]:
        rows=[]
        for _,ref in reference.iterrows():
            n=int(count_map.get((ref.file,ref.finding_idx),0)); src=base_protected[(base_protected.file==ref.file)&(base_protected.finding_idx==ref.finding_idx)] if n>=threshold else reference[(reference.file==ref.file)&(reference.finding_idx==ref.finding_idx)]
            rows.append(src.iloc[0].to_dict())
        burden.append({"policy":name,"base_protection_rule":best_rule,"evaluation_status":"evaluable",**summarize(pd.DataFrame(rows),reference)})
    burden.append({"policy":"H3_small_low_confidence_count","base_protection_rule":best_rule,"evaluation_status":"not_evaluable_missing_seg_probability"})
    pd.DataFrame(burden).to_csv(OUT/"high_fp_burden_policy_summary.csv",index=False)

    # P3: prior localization among baseline predictions with no GT-overlap component.
    positive_by_key=components.groupby(KEYS).gt_overlap_positive.any()
    misses=[]
    for _,ref in reference.iterrows():
        if bool(positive_by_key.get((ref.file,ref.finding_idx),False)): continue
        gt_img=nib.load(str(GT_DIR/ref.file)); ct_img=nib.load(str(CT_DIR/ref.file)); pred_img=nib.load(str(BASE_SEG/ref.file))
        gt=np.asarray(np.asanyarray(gt_img.dataobj[int(ref.finding_idx)])>0); pred=np.asarray(np.asanyarray(pred_img.dataobj[int(ref.finding_idx)])>0)
        spacing=np.asarray(nib.affines.voxel_sizes(ct_img.affine)); path=PRIOR_DIR/f"{ref.file.removesuffix('.nii.gz')}_finding_{int(ref.finding_idx)}.npz"
        with np.load(path) as archive: prior=archive["prior"].astype(np.float32)
        peak=np.asarray(np.unravel_index(int(prior.argmax()),prior.shape)); tree=cKDTree(np.argwhere(gt)*spacing)
        labels,ncomp=ndimage.label(gt,STRUCTURE); row={"case_id":ref.file,"finding_id":int(ref.finding_idx),"size_stratum":"small_2d" if ref.small_2d else "other_2d",
            "gt_voxels":int(gt.sum()),"gt_component_count":int(ncomp),"baseline_dice":ref.dice,"baseline_hit":bool(ref.hit),
            "predicted_component_count":int(ndimage.label(pred,STRUCTURE)[1]),"peak_in_GT":bool(gt[tuple(peak)]),
            "peak_to_GT_distance_mm":float(tree.query(peak*spacing)[0]),"prior_peak_xyz":json.dumps(peak.tolist())}
        flat=prior.ravel(); gtflat=gt.ravel(); covered=[]
        for factor in [1,2,5,10]:
            k=min(flat.size,max(1,int(gt.sum()*factor))); idx=np.argpartition(flat,-k)[-k:]; chosen=np.zeros(flat.size,bool);chosen[idx]=True;chosen=chosen.reshape(gt.shape)
            cov=0
            for cid in range(1,ncomp+1): cov+=int((chosen&(labels==cid)).any())
            row[f"top{factor}x_precision"]=float(gtflat[idx].mean());row[f"top{factor}x_component_recall"]=cov/max(ncomp,1)
        if pred.any():
            row["prior_peak_to_nearest_baseline_component_mm"]=float(cKDTree(np.argwhere(pred)*spacing).query(peak*spacing)[0])
        else: row["prior_peak_to_nearest_baseline_component_mm"]=np.nan
        row["low_threshold_rescue_status"]="not_evaluated_missing_baseline_probability_logits"
        misses.append(row)
    miss=pd.DataFrame(misses); miss.to_csv(OUT/"baseline_miss_rescue_audit.csv",index=False)
    miss_summary={"n":len(miss),"small_2d":int((miss.size_stratum=="small_2d").sum()),"peak_in_GT_fraction":float(miss.peak_in_GT.mean()),
                  "mean_peak_to_GT_distance_mm":float(miss.peak_to_GT_distance_mm.mean()),
                  **{f"mean_top{f}x_component_recall":float(miss[f"top{f}x_component_recall"].mean()) for f in [1,2,5,10]},
                  "low_threshold_local_rescue":"unavailable_missing_baseline_probability_logits","gpu_inference_launched":False}
    write_json("baseline_miss_rescue_summary.json",miss_summary)
    write_json("rescue_plus_pruning_upper_bound.json",{"status":"not_computable_without_low_threshold_probability_candidates",
               "protected_pruning_rule":best_rule,"reason":"baseline probability/logit maps were not saved; no GPU inference was authorized or launched"})

    best_stats=mode_summary[mode_summary["mode"].eq(best_mode)].iloc[0].to_dict()
    if best_stats["dice_delta"]>0 and best_stats["hit_delta"]>=0 and best_stats["small_hits_delta"]>=0 and best_stats["FP_GT_delta"]<0:
        classification="A. PROTECTED PRUNING IS CROSS-FIT POSITIVE"
    elif best_stats["hit_delta"]>=0 and best_stats["small_hits_delta"]>=0:
        classification="B. PRIOR VERIFIER IS USEFUL ONLY WITH PROTECTION BUT STILL WEAK"
    elif miss_summary["peak_in_GT_fraction"]>0 or miss_summary["mean_top5x_component_recall"]>=.25:
        classification="C. HARD PRUNING IS UNSAFE; USE PRIOR ONLY FOR RESCUE OR SOFT SCORING"
    else: classification="E. CURRENT PRIOR CONVERSION REMAINS NO-GO"
    decision={"classification":classification,"lost_hits":len(lost),"best_protection_rule":best_rule,
              "best_recall_safe_mode":best_mode,"best_recall_safe_metrics":best_stats,"baseline_miss_prior_localization":miss_summary,
              "low_threshold_rescue_not_evaluated":True,"recommendation":"do not launch GPU or train automatically"}
    write_json("decision.json",decision)
    report=f"""# Recall-safe no-attention 2d prior policy audit

## 1. Why the previous cross-fit lost 3 small hits

The exact findings and component decisions are in `lost_hit_audit_summary.csv` and `lost_hit_audit_components.csv`. Saved baseline outputs are binary masks, so true segmentation probability confidence was unavailable.

## 2. Guard-rule simulation

Best hit-safe evaluable protection rule: `{best_rule}`. Full results are in `lost_hit_protection_rule_results.csv`.

## 3. Recall-constrained cross-fit

Selected mode: `{best_mode}`; Dice delta={best_stats['dice_delta']:+.6f}, hits={int(best_stats['hit_delta']):+d}, small hits={int(best_stats['small_hits_delta']):+d}, FP/GT={best_stats['FP_GT_delta']:+.6f}, recall={best_stats['recall_delta']:+.6f}.

## 4. Baseline-miss localization

Audited {len(miss)} findings with no GT-overlap baseline component. Prior peak-in-GT={miss_summary['peak_in_GT_fraction']:.3f}; mean peak distance={miss_summary['mean_peak_to_GT_distance_mm']:.2f} mm. Low-threshold rescue was not run because baseline probability/logit maps do not exist.

## 5. Decision

**{classification}**

No model was trained, no model weight was modified, and no GPU inference was launched.
"""
    (OUT/"report.md").write_text(report)
    print(json.dumps({"status":"complete","classification":classification,"lost_hits":len(lost),"best_mode":best_mode},indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
