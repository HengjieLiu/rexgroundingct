#!/usr/bin/env python
"""Collect the matched control/adaptive 30-case threshold sweep."""

from __future__ import annotations

import csv
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = Path(
    os.environ.get(
        "CATEGORY_TVERSKY_SWEEP_BASE",
        ROOT / "outputs/category_adaptive_tversky_threshold_sweep_subset30",
    )
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def threshold_from_dir(path: Path) -> float:
    return float(path.name.removeprefix("threshold_").replace("p", "."))


def collect_branch(branch: str) -> tuple[list[dict], dict[float, dict[tuple[str, int], dict]]]:
    rows: list[dict] = []
    findings_by_threshold: dict[float, dict[tuple[str, int], dict]] = {}
    for directory in sorted((BASE / branch).glob("threshold_*"), key=threshold_from_dir):
        metrics_path = directory / "eval_rexrank_metrics_global.json"
        finding_path = directory / "per_finding_metrics.csv"
        if not metrics_path.exists() or not finding_path.exists():
            continue
        threshold = threshold_from_dir(directory)
        summary = json.loads(metrics_path.read_text())["summary"]
        findings = read_csv(finding_path)
        tp = sum(int(float(item["tp_voxels"])) for item in findings)
        fp = sum(int(float(item["fp_voxels"])) for item in findings)
        fn = sum(int(float(item["fn_voxels"])) for item in findings)
        rows.append(
            {
                "branch": branch,
                "threshold": threshold,
                "findings": summary["total_findings"],
                "cases": summary["total_cases"],
                "dice_per_finding": summary["mean_global_dice_per_finding"],
                "dice_per_case": summary["mean_global_dice_per_case"],
                "hit_rate": summary["hit_rate"],
                "hits": summary["total_hits"],
                "misses": summary["total_misses"],
                "micro_precision": tp / (tp + fp) if tp + fp else 0.0,
                "micro_recall": tp / (tp + fn) if tp + fn else 0.0,
                "total_tp_voxels": tp,
                "total_fp_voxels": fp,
                "total_fn_voxels": fn,
                "metrics": str(metrics_path),
            }
        )
        findings_by_threshold[threshold] = {
            (item["file"], int(item["finding_idx"])): item for item in findings
        }
    return rows, findings_by_threshold


def main() -> int:
    BASE.mkdir(parents=True, exist_ok=True)
    control_rows, control_findings = collect_branch("control")
    adaptive_rows, adaptive_findings = collect_branch("adaptive")
    rows = sorted(control_rows + adaptive_rows, key=lambda item: (item["threshold"], item["branch"]))
    write_csv(BASE / "threshold_summary.csv", rows)

    control_by_threshold = {row["threshold"]: row for row in control_rows}
    adaptive_by_threshold = {row["threshold"]: row for row in adaptive_rows}
    paired_rows = []
    for threshold in sorted(set(control_by_threshold) & set(adaptive_by_threshold)):
        control = control_by_threshold[threshold]
        adaptive = adaptive_by_threshold[threshold]
        control_items = control_findings[threshold]
        adaptive_items = adaptive_findings[threshold]
        keys = sorted(set(control_items) & set(adaptive_items))
        deltas = [
            float(adaptive_items[key]["global_dice"]) - float(control_items[key]["global_dice"])
            for key in keys
        ]
        paired_rows.append(
            {
                "threshold": threshold,
                "control_dice": control["dice_per_finding"],
                "adaptive_dice": adaptive["dice_per_finding"],
                "adaptive_minus_control_dice": adaptive["dice_per_finding"] - control["dice_per_finding"],
                "control_hit_rate": control["hit_rate"],
                "adaptive_hit_rate": adaptive["hit_rate"],
                "adaptive_minus_control_hit_rate": adaptive["hit_rate"] - control["hit_rate"],
                "control_precision": control["micro_precision"],
                "adaptive_precision": adaptive["micro_precision"],
                "control_recall": control["micro_recall"],
                "adaptive_recall": adaptive["micro_recall"],
                "adaptive_fp_change_fraction": (
                    adaptive["total_fp_voxels"] / control["total_fp_voxels"] - 1.0
                    if control["total_fp_voxels"] else 0.0
                ),
                "fraction_findings_adaptive_improved": (
                    sum(delta > 0 for delta in deltas) / len(deltas) if deltas else 0.0
                ),
            }
        )
    write_csv(BASE / "paired_threshold_comparison.csv", paired_rows)

    best_control = max(control_rows, key=lambda item: item["dice_per_finding"])
    best_adaptive = max(adaptive_rows, key=lambda item: item["dice_per_finding"])
    report = [
        f"# Category-adaptive Tversky threshold sweep ({BASE.name})",
        "",
        f"Best control: threshold={best_control['threshold']:.2f}, Dice/finding={best_control['dice_per_finding']:.6f}, hit={best_control['hit_rate']:.6f}",
        f"Best adaptive: threshold={best_adaptive['threshold']:.2f}, Dice/finding={best_adaptive['dice_per_finding']:.6f}, hit={best_adaptive['hit_rate']:.6f}",
        "",
        f"Summary CSV: {BASE / 'threshold_summary.csv'}",
        f"Paired CSV: {BASE / 'paired_threshold_comparison.csv'}",
    ]
    (BASE / "report.md").write_text("\n".join(report) + "\n")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
