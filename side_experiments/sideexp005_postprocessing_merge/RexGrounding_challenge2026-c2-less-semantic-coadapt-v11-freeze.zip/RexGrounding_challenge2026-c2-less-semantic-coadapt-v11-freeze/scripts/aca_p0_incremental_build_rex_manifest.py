#!/usr/bin/env python3
"""Build the fixed30 inference manifest solely from P0/cohort source artifacts."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    cohort = list(csv.DictReader((args.output_root / "cohort_manifest.csv").open(newline="", encoding="utf-8")))
    preprocessed = {
        row["case"]: row
        for row in (
            json.loads(line)
            for line in (ROOT / "data/rex_voxtell_preprocessed_v1/manifest.jsonl").read_text().splitlines()
        )
    }
    by_case: dict[str, list[dict[str, str]]] = {}
    for row in cohort:
        by_case.setdefault(row["case_id"], []).append(row)
    entries = []
    for case_id, rows in sorted(by_case.items()):
        source = preprocessed[case_id]
        rows.sort(key=lambda row: int(row["finding_idx"]))
        entries.append(
            {
                "name": case_id,
                "findings": {row["finding_idx"]: row["prompt"] for row in rows},
                "shape": source["original_shape"],
                "pixels": {row["finding_idx"]: int(source["json_pixels"][row["finding_idx"]]) for row in rows},
                "categories": {row["finding_idx"]: row["category"] for row in rows},
                "protocol": "val",
            }
        )
    payload = {
        "provenance": {
            "schema": "aca_p0_incremental_fixed30_manifest_v1",
            "source": "canonical cohort + rex_voxtell_preprocessed_v1 manifest",
            "p1_artifacts_used": False,
            "cases": len(entries),
            "findings": sum(len(entry["findings"]) for entry in entries),
        },
        "val": entries,
    }
    path = args.output_root / "fixed30_rex_manifest.json"
    path.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload["provenance"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
