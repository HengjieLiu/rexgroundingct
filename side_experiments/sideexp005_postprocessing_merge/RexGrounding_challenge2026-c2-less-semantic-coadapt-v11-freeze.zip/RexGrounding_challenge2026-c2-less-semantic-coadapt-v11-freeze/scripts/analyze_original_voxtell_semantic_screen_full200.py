#!/usr/bin/env python3
"""Paired case-cluster bootstrap summary for the semantic-loss screen."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


ARMS = {
    "B0": "b0_original",
    "Lobe-Direct": "lobe_direct",
    "A5-Dense E4": "a5_dense_e4",
    "A5-Contrast E4": "a5_contrast_e4",
    "P-D3": "p_d3",
    "P-D4": "p_d4",
}


def load(root: Path, directory: str, update: int) -> tuple[pd.DataFrame, dict]:
    base = root / directory / f"full200_{update}"
    table = pd.read_csv(base / "summary_tables/per_finding_metrics.csv")
    summary = json.loads((base / "summary.json").read_text())
    if len(table) != 381 or table.file.nunique() != 200:
        raise RuntimeError(f"Invalid Full200 output: {base}")
    if table.duplicated(["file", "finding_idx"]).any():
        raise RuntimeError(f"Duplicate finding keys: {base}")
    return table, summary


def case_bootstrap(delta: pd.DataFrame, seed: int, draws: int) -> tuple[float, float]:
    groups = [part.delta.to_numpy(float) for _, part in delta.groupby("file", sort=True)]
    rng = np.random.default_rng(seed)
    sampled = np.empty(draws, dtype=float)
    for draw in range(draws):
        indices = rng.integers(0, len(groups), size=len(groups))
        sampled[draw] = np.concatenate([groups[index] for index in indices]).mean()
    low, high = np.quantile(sampled, [0.025, 0.975])
    return float(low), float(high)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--root", type=Path,
        default=Path("outputs/original_voxtell_semantic_screen_1k"),
    )
    parser.add_argument("--bootstrap-draws", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260902)
    args = parser.parse_args()
    root = args.root.resolve()
    out = root / "paired_full200"
    out.mkdir(parents=True, exist_ok=True)

    rows: list[dict] = []
    paired_rows: list[pd.DataFrame] = []
    for update in (500, 1000):
        control, control_summary = load(root, ARMS["B0"], update)
        for label, directory in ARMS.items():
            table, summary = load(root, directory, update)
            record = {
                "arm": label,
                "directory": directory,
                "update": update,
                "dice": float(summary["mean_global_dice_per_finding"]),
                "hit": int(summary["total_hits"]),
                "findings": int(summary["total_findings"]),
                "empty_predictions": int((table.pred_voxels == 0).sum()),
                "mean_prediction_volume_mm3": float((table.pred_voxels * table.voxel_volume_mm3).mean()),
                "median_prediction_volume_mm3": float((table.pred_voxels * table.voxel_volume_mm3).median()),
                "delta_vs_b0": 0.0,
                "ci95_low": 0.0,
                "ci95_high": 0.0,
            }
            if label != "B0":
                merged = control[["file", "finding_idx", "global_dice"]].merge(
                    table[["file", "finding_idx", "global_dice"]],
                    on=["file", "finding_idx"], suffixes=("_b0", "_arm"),
                    validate="one_to_one",
                )
                if len(merged) != 381:
                    raise RuntimeError(f"Pairing failure for {label} @{update}")
                merged["delta"] = merged.global_dice_arm - merged.global_dice_b0
                low, high = case_bootstrap(
                    merged, args.seed + update + list(ARMS).index(label), args.bootstrap_draws
                )
                record.update(
                    delta_vs_b0=float(merged.delta.mean()), ci95_low=low, ci95_high=high
                )
                merged.insert(0, "arm", label)
                merged.insert(1, "update", update)
                paired_rows.append(merged)
            rows.append(record)

    result = pd.DataFrame(rows)
    result.to_csv(out / "full200_summary.csv", index=False)
    pd.concat(paired_rows, ignore_index=True).to_csv(
        out / "paired_per_finding_dice.csv", index=False
    )
    payload = {
        "protocol": "canonical raw Full200; 200 cases / 381 findings; threshold 0.5",
        "bootstrap": {
            "unit": "case", "draws": args.bootstrap_draws, "seed": args.seed,
            "estimand": "paired mean finding-Dice difference with cases resampled as intact clusters",
        },
        "rows": result.to_dict(orient="records"),
    }
    (out / "full200_summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(result.to_string(index=False))


if __name__ == "__main__":
    main()
