#!/usr/bin/env python3
"""Extract the repaired S3-v2 validation trajectory and apply its checkpoint rule."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--tie-tolerance", type=float, default=0.002)
    args = parser.parse_args()
    history = [json.loads(line) for line in (args.run_dir / "history.jsonl").read_text().splitlines() if line.strip()]
    rows = []
    for record in history:
        step = int(record.get("step", -1))
        if step not in {100, 200, 300, 400, 500, 600}:
            continue
        rows.append({
            "step": step,
            "checkpoint": f"checkpoints/checkpoint_step_{step}.pth",
            "train_segmentation_loss": record.get("segmentation_loss"),
            "train_s3_pooled_loss": record.get("total_attention_loss"),
            "train_s3_fullres_loss": record.get("s3_fullres_fg_bg_loss"),
            "train_total_loss": record.get("train_loss"),
            "patch_global_dice": record.get("val_dice"),
            "patch_positive_dice": record.get("val_positive_dice"),
            "learning_rate_decoder": record.get("lr", {}).get("decoder"),
            "fullres_fg_similarity": record.get("val_s3_fullres_fg_mean"),
            "fullres_hard_bg_similarity": record.get("val_s3_fullres_hard_bg_mean"),
            "fullres_similarity_margin": record.get("val_s3_fullres_margin"),
            "fullres_feature_projection_grad_norm": record.get("grad_norm_s3_fullres_feature_projection"),
            "fullres_query_projection_grad_norm": record.get("grad_norm_s3_fullres_query_projection"),
        })
    if len(rows) != 6:
        raise RuntimeError(f"Expected six validation records, found {len(rows)}")
    rows.sort(key=lambda row: row["step"])
    with (args.run_dir / "s3v2_fullres_validation_trajectory.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    best_value = max(float(row["patch_positive_dice"]) for row in rows)
    candidates = [row for row in rows if best_value - float(row["patch_positive_dice"]) < args.tie_tolerance]
    selected = max(candidates, key=lambda row: row["step"])
    selection = {
        "criterion": "max patch positive Dice among steps 100..600; choose later step within 0.002",
        "tie_tolerance": args.tie_tolerance,
        "best_patch_positive_dice": best_value,
        "candidate_steps": [row["step"] for row in candidates],
        "selected": selected,
    }
    (args.run_dir / "s3v2_fullres_checkpoint_selection.json").write_text(json.dumps(selection, indent=2) + "\n")
    (args.run_dir / "s3v2_fullres_training_summary.md").write_text(
        "# Repaired S3-v2 Training Summary\n\n"
        f"- Selected checkpoint: `{selected['checkpoint']}` at step {selected['step']}.\n"
        f"- Selection metric: patch positive Dice `{best_value:.6f}`.\n"
        f"- Candidate steps within `{args.tie_tolerance}`: {selection['candidate_steps']}.\n"
        "- The initial step-0 checkpoint is reported separately by the trainer but excluded from the scheduled 100..600 training checkpoint selection.\n"
    )
    print(json.dumps(selection, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
