#!/usr/bin/env python3
"""Aggregate fixed30 trajectories and paired update-500 common-init statistics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import binomtest, wilcoxon


ROOT = Path(__file__).resolve().parents[1]
ARMS = ("B0_original", "A1_replace", "A2_FAN")
UPDATES = (0, 100, 250, 500)


def case_cluster_bootstrap(
    frame: pd.DataFrame,
    *,
    value: str,
    iterations: int = 20_000,
    seed: int = 260811,
) -> tuple[float, float]:
    cases = frame["file"].drop_duplicates().to_numpy()
    grouped = {case: frame.loc[frame.file == case, value].to_numpy() for case in cases}
    rng = np.random.default_rng(seed)
    estimates = np.empty(iterations, dtype=np.float64)
    for index in range(iterations):
        sampled = rng.choice(cases, size=len(cases), replace=True)
        estimates[index] = np.concatenate([grouped[case] for case in sampled]).mean()
    return tuple(np.quantile(estimates, [0.025, 0.975]).tolist())


def comparison(
    left: pd.DataFrame,
    right: pd.DataFrame,
    left_name: str,
    right_name: str,
) -> tuple[dict[str, Any], pd.DataFrame]:
    keys = ["file", "finding_idx"]
    columns = keys + ["prompt", "category", "global_dice", "pred_voxels", "global_hit"]
    lhs = left[columns].rename(columns={
        "global_dice": "left_dice", "pred_voxels": "left_volume", "global_hit": "left_hit"
    })
    rhs = right[keys + ["global_dice", "pred_voxels", "global_hit"]].rename(columns={
        "global_dice": "right_dice", "pred_voxels": "right_volume", "global_hit": "right_hit"
    })
    paired = lhs.merge(rhs, on=keys, validate="one_to_one")
    paired["delta_dice"] = paired.left_dice - paired.right_dice
    paired["delta_hit"] = paired.left_hit.astype(int) - paired.right_hit.astype(int)
    paired["volume_ratio"] = (
        (paired.left_volume + 1.0) / (paired.right_volume + 1.0)
    )
    tolerance = 1e-12
    improved = int((paired.delta_dice > tolerance).sum())
    worsened = int((paired.delta_dice < -tolerance).sum())
    tied = int(len(paired) - improved - worsened)
    ci_low, ci_high = case_cluster_bootstrap(paired, value="delta_dice")
    nonzero = paired.loc[paired.delta_dice.abs() > tolerance, "delta_dice"]
    p_value = (
        1.0
        if nonzero.empty
        else float(wilcoxon(nonzero, alternative="two-sided").pvalue)
    )
    hit_up = int(((paired.left_hit == 1) & (paired.right_hit == 0)).sum())
    hit_down = int(((paired.left_hit == 0) & (paired.right_hit == 1)).sum())
    mcnemar_p = (
        1.0
        if hit_up + hit_down == 0
        else float(
            binomtest(min(hit_up, hit_down), hit_up + hit_down, 0.5).pvalue
        )
    )
    result = {
        "comparison": f"{left_name} vs {right_name}",
        "n_findings": len(paired),
        "n_cases": int(paired.file.nunique()),
        "mean_paired_dice_delta": float(paired.delta_dice.mean()),
        "median_paired_dice_delta": float(paired.delta_dice.median()),
        "case_cluster_bootstrap_95ci": [ci_low, ci_high],
        "wilcoxon_p": p_value,
        "improved": improved,
        "worsened": worsened,
        "tied": tied,
        "hit_delta": int(paired.left_hit.sum() - paired.right_hit.sum()),
        "hit_discordant_up": hit_up,
        "hit_discordant_down": hit_down,
        "mcnemar_exact_p": mcnemar_p,
        "aggregate_predicted_volume_ratio": float(
            (paired.left_volume.sum() + 1.0) / (paired.right_volume.sum() + 1.0)
        ),
        "median_per_finding_volume_ratio": float(paired.volume_ratio.median()),
        "largest_improvements": paired.nlargest(5, "delta_dice")[
            keys + ["prompt", "category", "delta_dice"]
        ].to_dict("records"),
        "largest_degradations": paired.nsmallest(5, "delta_dice")[
            keys + ["prompt", "category", "delta_dice"]
        ].to_dict("records"),
    }
    paired.insert(0, "comparison", result["comparison"])
    return result, paired


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--experiment-root",
        type=Path,
        default=ROOT / "outputs/token_attention_common_init_pilot",
    )
    args = parser.parse_args()
    root = args.experiment_root.resolve()
    analysis_dir = root / "analysis"
    analysis_dir.mkdir(parents=True, exist_ok=True)
    summaries: list[dict[str, Any]] = []
    tables: dict[tuple[str, int], pd.DataFrame] = {}
    for arm in ARMS:
        for update in UPDATES:
            directory = root / arm / "full_volume" / f"update_{update:05d}"
            summary = json.loads((directory / "controlled_summary.json").read_text())
            summaries.append({"arm": arm, **summary})
            tables[(arm, update)] = pd.read_csv(
                directory / "summary_tables/per_finding_metrics.csv"
            )
    trajectory = pd.DataFrame(summaries).sort_values(["update", "arm"])
    trajectory.to_csv(analysis_dir / "validation_trajectory.csv", index=False)

    results = []
    paired_frames = []
    for left, right in (
        ("A1_replace", "B0_original"),
        ("A2_FAN", "B0_original"),
        ("A2_FAN", "A1_replace"),
    ):
        result, paired = comparison(
            tables[(left, 500)], tables[(right, 500)], left, right
        )
        results.append(result)
        paired_frames.append(paired)
    pd.concat(paired_frames, ignore_index=True).to_csv(
        analysis_dir / "paired_update500_per_finding.csv", index=False
    )
    payload = {
        "bootstrap_unit": "case (30 clusters); finding metrics retained within sampled case",
        "bootstrap_iterations": 20_000,
        "bootstrap_seed": 260811,
        "comparisons": results,
    }
    (analysis_dir / "paired_update500_statistics.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
