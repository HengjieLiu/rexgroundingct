#!/usr/bin/env python3
"""Aggregate fixed30 C2/P causal outputs, matched CIs, and A-ID repair."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/c2_semantic_p_token_causal_audit'
MODELS={'C2':OUT/'full_fixed30/c2','P':OUT/'full_fixed30/p'}; CONDITIONS=('correct','shuffle','neutral','samecase_wrong')
def table(model,condition):
 p=next((MODELS[model]/condition/'full_volume').glob('update_*/summary_tables/per_finding_metrics.csv'))
 return pd.read_csv(p)
def brief(d):
 return {'dice':float(d.global_dice.mean()),'hit':int(d.global_hit.astype(bool).sum()),'mean_pred_volume':float(d.pred_voxels.mean()),'median_pred_volume':float(d.pred_voxels.median()),'empty':int((d.pred_voxels==0).sum()),'n':len(d)}
def paired(a,b,seed):
 keys=['file','finding_idx']; x=a[keys+['global_dice','global_hit']].merge(b[keys+['global_dice','global_hit']],on=keys,suffixes=('_correct','_other'),validate='one_to_one'); x['delta']=x.global_dice_correct-x.global_dice_other; cm=x.groupby('file').delta.mean().to_numpy(); rng=np.random.default_rng(seed); draws=np.array([rng.choice(cm,len(cm),replace=True).mean() for _ in range(5000)])
 return {'mean':float(x.delta.mean()),'median':float(x.delta.median()),'improved':int((x.delta>1e-12).sum()),'worsened':int((x.delta<-1e-12).sum()),'tied':int((x.delta.abs()<=1e-12).sum()),'hit_delta':int(x.global_hit_correct.astype(bool).sum()-x.global_hit_other.astype(bool).sum()),'ci95':[float(np.quantile(draws,.025)),float(np.quantile(draws,.975))]}
def subset(d, ids): return d.merge(ids,left_on=['file','finding_idx'],right_on=['case','finding_idx'],how='inner',validate='one_to_one')
def repair():
 a=pd.read_csv(ROOT/'outputs/c2_semantic_ap_minimal_audit/A_backbone_swap/own_per_finding.tsv',sep='\t'); c=pd.read_csv(ROOT/'outputs/c2_semantic_ap_minimal_audit/A_backbone_swap/c2_backbone_same_head_per_finding.tsv',sep='\t'); keys=['case_id','finding_id']; m=a.merge(c,on=keys,suffixes=('_a','_c'),validate='one_to_one'); result={}
 for label,field in [('side','less_semantic_side_eligible_count'),('lobe','less_semantic_lobe_eligible_count')]:
  q=m[(m[field+'_a']>0)&(m[field+'_c']>0)]; metrics=['less_semantic_side_margin_mean','less_semantic_side_accuracy'] if label=='side' else ['less_semantic_lobe_accuracy','less_semantic_lobe_target_rank_mean']; result[label]={'n':len(q),'underpowered':bool(label=='lobe' and len(q)<=4),'A_own':{z:float(q[z+'_a'].mean()) for z in metrics},'C2_swap_same_A_head':{z:float(q[z+'_c'].mean()) for z in metrics}}
 return result
def main():
 frames={m:{c:table(m,c) for c in CONDITIONS} for m in MODELS}; summary={m:{c:brief(x) for c,x in fs.items()} for m,fs in frames.items()}; paired_stats={m:{c:paired(fs['correct'],fs[c],100+i) for i,c in enumerate(('shuffle','neutral'))} for m,fs in frames.items()}
 eligible=pd.read_csv(ROOT/'outputs/c2_semantic_ap_minimal_audit/P_backbone_swap/own_per_finding.tsv',sep='\t'); eligible=eligible[eligible.less_semantic_path_eligible_count>0][['case_id','finding_id']].rename(columns={'case_id':'case','finding_id':'finding_idx'}); secondary={}
 for m,fs in frames.items():
  secondary[m]={c:brief(subset(fs[c],eligible)) for c in ('correct','shuffle','neutral')}; secondary[m]['correct_shuffle_gap']=float(secondary[m]['correct']['dice']-secondary[m]['shuffle']['dice']); secondary[m]['correct_neutral_gap']=float(secondary[m]['correct']['dice']-secondary[m]['neutral']['dice'])
 pairs=pd.read_csv(OUT/'samecase/eligible_pairs.csv'); pairs=pairs[pairs.eligible][['case','finding_idx','pair_type']]; same={}
 for m,fs in frames.items():
  x=subset(fs['correct'],pairs);y=subset(fs['samecase_wrong'],pairs);same[m]={'eligible_n':len(x),'pair_types':pairs.pair_type.value_counts().to_dict(),'correct':brief(x),'wrong':brief(y),'paired':paired(x,y,812)}
 did={'shuffle':paired_stats['P']['shuffle']['mean']-paired_stats['C2']['shuffle']['mean'],'neutral':paired_stats['P']['neutral']['mean']-paired_stats['C2']['neutral']['mean']}
 feat={}
 for m in MODELS:
  p=OUT/'feature_sensitivity'/m.lower()/'summary.csv'; feat[m]=pd.read_csv(p).to_dict(orient='records') if p.exists() else 'not completed'
 result={'checkpoints':{'C2':str(ROOT/'outputs/less_fan_conditioning_10k/c2_less_encoder_conditioning/checkpoints/checkpoint_update_5000.pth'),'P':str(ROOT/'outputs/c2_less_semantic_coadapt_v11/p_pathology/checkpoints/checkpoint_update_5000.pth')},'whole_fixed30':summary,'paired':paired_stats,'difference_in_gaps':did,'pathology_eligible':secondary,'samecase':same,'feature_sensitivity':feat,'anatomy_matched_repair':repair()}
 (OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
 lines=['# C2 Pathology Semantic Co-Adaptation Word-Token Causal Audit','', '> Did Pathology semantic co-adaptation make C2 LESS segmentation functionally depend on correct word-token semantics?','', '## Matched checkpoints',f"- Historical C2@5000: `{result['checkpoints']['C2']}`",f"- P@5000: `{result['checkpoints']['P']}`",'', '## Whole fixed30','', '| Model | Correct | Shuffle | Neutral | Correct-Shuffle | Correct-Neutral |','|---|---:|---:|---:|---:|---:|']
 for m in MODELS:
  s=summary[m];lines.append(f"| {m}@5000 | {s['correct']['dice']:.6f} | {s['shuffle']['dice']:.6f} | {s['neutral']['dice']:.6f} | {paired_stats[m]['shuffle']['mean']:.6f} ({paired_stats[m]['shuffle']['ci95'][0]:.6f},{paired_stats[m]['shuffle']['ci95'][1]:.6f}) | {paired_stats[m]['neutral']['mean']:.6f} ({paired_stats[m]['neutral']['ci95'][0]:.6f},{paired_stats[m]['neutral']['ci95'][1]:.6f}) |")
 lines += ['', '## Difference in causal dependence',f"- Delta Gap shuffle (P minus C2): {did['shuffle']:.6f}",f"- Delta Gap neutral (P minus C2): {did['neutral']:.6f}",'', '## Pathology-eligible subset', '```json',json.dumps(secondary,indent=2),'```','', '## Same-case wrong tokens','```json',json.dumps(same,indent=2),'```','', '## Feature sensitivity','```json',json.dumps(feat,indent=2),'```','', '## Anatomy matched-ID repair','```json',json.dumps(result['anatomy_matched_repair'],indent=2),'```']
 (OUT/'report.md').write_text('\n'.join(lines)+'\n'); print(json.dumps(result,indent=2))
if __name__=='__main__':main()
