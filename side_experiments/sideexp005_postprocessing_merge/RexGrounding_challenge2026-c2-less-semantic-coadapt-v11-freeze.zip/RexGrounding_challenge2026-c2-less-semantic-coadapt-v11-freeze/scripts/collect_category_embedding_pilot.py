#!/usr/bin/env python3
"""Collect paired fixed-subset metrics for the category-embedding pilot."""

from __future__ import annotations

import argparse
import json
import os
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--dataset-json", type=Path, required=True)
    return parser.parse_args()


def flatten(path: Path, metadata: dict[str, dict[str, Any]]) -> tuple[dict, dict[tuple[str, int], dict]]:
    payload = json.loads(path.read_text())
    rows = {}
    for case in payload["cases"]:
        case_id = case["file"]
        entry = metadata[case_id]
        finding_keys = sorted(entry["findings"], key=int)
        for position, finding_key in enumerate(finding_keys):
            metric = case["findings"][f"finding_{position}"]
            rows[(case_id, position)] = {
                "dice": float(metric["global_dice"]),
                "hit": bool(metric["global_hit"]),
                "category": str((entry.get("categories") or {}).get(finding_key, "unknown")),
                "gt_pixels": int((entry.get("pixels") or {}).get(finding_key, 0)),
            }
    return payload["summary"], rows


def mean(values: list[float]) -> float:
    return float(sum(values) / len(values)) if values else float("nan")


def grouped_deltas(
    baseline: dict[tuple[str, int], dict],
    candidate: dict[tuple[str, int], dict],
    group_key,
) -> dict[str, dict[str, float | int]]:
    groups: dict[str, list[float]] = defaultdict(list)
    for key, base in baseline.items():
        groups[str(group_key(base))].append(candidate[key]["dice"] - base["dice"])
    return {
        group: {"findings": len(values), "mean_dice_delta": mean(values)}
        for group, values in sorted(groups.items())
    }


def main() -> int:
    args = parse_args()
    dataset = json.loads(args.dataset_json.read_text())
    metadata = {entry["name"]: entry for split in dataset.values() for entry in split}
    labels = {
        "baseline": "Baseline step-3800",
        "update_50": "Category emb. update 50",
        "update_100": "Category emb. update 100",
        "update_200": "Category emb. update 200",
    }
    summaries = {}
    rows = {}
    for key in labels:
        summaries[key], rows[key] = flatten(
            args.root / "fast_eval" / key / "eval_rexrank_metrics_global.json",
            metadata,
        )
    baseline = rows["baseline"]
    if len(baseline) != 49 or summaries["baseline"]["total_cases"] != 30:
        raise ValueError("Evaluation did not use the fixed 30-case / 49-finding cohort")

    table = []
    details = {}
    for key, label in labels.items():
        summary = summaries[key]
        if key == "baseline":
            table.append({
                "model": label,
                "dice_per_finding": summary["mean_global_dice_per_finding"],
                "delta": None,
                "dice_per_case": summary["mean_global_dice_per_case"],
                "hit_rate": summary["hit_rate"],
                "hits": summary["total_hits"],
                "improved": None,
                "degraded": None,
            })
            continue
        deltas = [rows[key][finding]["dice"] - baseline[finding]["dice"] for finding in baseline]
        table.append({
            "model": label,
            "dice_per_finding": summary["mean_global_dice_per_finding"],
            "delta": summary["mean_global_dice_per_finding"] - summaries["baseline"]["mean_global_dice_per_finding"],
            "dice_per_case": summary["mean_global_dice_per_case"],
            "hit_rate": summary["hit_rate"],
            "hits": summary["total_hits"],
            "improved": sum(delta > 0 for delta in deltas),
            "degraded": sum(delta < 0 for delta in deltas),
        })
        details[key] = {
            "mean_per_finding_dice_delta": mean(deltas),
            "median_per_finding_dice_delta": float(statistics.median(deltas)),
            "delta_greater_than_0p01": sum(delta > 0.01 for delta in deltas),
            "delta_below_minus_0p01": sum(delta < -0.01 for delta in deltas),
            "per_category": grouped_deltas(baseline, rows[key], lambda item: item["category"]),
            "focal_vs_diffuse": grouped_deltas(
                baseline,
                rows[key],
                lambda item: "focal" if item["category"].startswith("2") else "diffuse",
            ),
            "tiny_vs_non_tiny": grouped_deltas(
                baseline,
                rows[key],
                lambda item: "tiny_lt_100" if item["gt_pixels"] < 100 else "non_tiny_ge_100",
            ),
        }

    candidate_rows = table[1:]
    best = max(candidate_rows, key=lambda row: row["delta"])
    baseline_hit = float(table[0]["hit_rate"])
    no_meaningful_hit_degradation = float(best["hit_rate"]) >= baseline_hit - 0.02
    convincing_category = any(
        category["findings"] >= 2 and category["mean_dice_delta"] >= 0.003
        for update in details.values()
        for category in update["per_category"].values()
    )
    if best["delta"] >= 0.003 and no_meaningful_hit_degradation:
        verdict = "PROMISING"
    elif best["delta"] < 0 and not convincing_category:
        verdict = "NEGATIVE"
    else:
        verdict = "WEAK/MIXED"

    result = {
        "fixed_manifest": str(
            args.root.parents[0]
            / "prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/stratified_subset_manifest.json"
        ),
        "threshold": 0.5,
        "evaluation_slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "evaluation_launch_command": "sbatch scripts/evaluate_category_embedding_pilot_4l40s.sbatch",
        "table": table,
        "details": details,
        "best_model": best["model"],
        "verdict": verdict,
    }
    (args.root / "fast_eval" / "comparison.json").write_text(json.dumps(result, indent=2) + "\n")

    lines = [
        "# Category-embedding normal VoxTell pilot",
        "",
        f"Evaluation Slurm job: `{os.environ.get('SLURM_JOB_ID', 'unknown')}`",
        "",
        "Launch command: `sbatch scripts/evaluate_category_embedding_pilot_4l40s.sbatch`",
        "",
        "| Model | Dice/finding | Delta | Dice/case | Hit rate | Hits | Improved | Degraded |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in table:
        delta = "—" if row["delta"] is None else f"{row['delta']:+.6f}"
        improved = "—" if row["improved"] is None else str(row["improved"])
        degraded = "—" if row["degraded"] is None else str(row["degraded"])
        lines.append(
            f"| {row['model']} | {row['dice_per_finding']:.6f} | {delta} | "
            f"{row['dice_per_case']:.6f} | {row['hit_rate']:.6f} | {row['hits']} | "
            f"{improved} | {degraded} |"
        )
    lines.extend(["", "## Paired deltas", ""])
    for key in ("update_50", "update_100", "update_200"):
        item = details[key]
        lines.extend([
            f"### {labels[key]}",
            "",
            f"- Mean delta: `{item['mean_per_finding_dice_delta']:+.6f}`",
            f"- Median delta: `{item['median_per_finding_dice_delta']:+.6f}`",
            f"- Findings > +0.01: `{item['delta_greater_than_0p01']}`",
            f"- Findings < -0.01: `{item['delta_below_minus_0p01']}`",
            "",
            "| Category | N | Dice delta |",
            "|---|---:|---:|",
        ])
        for category, values in item["per_category"].items():
            lines.append(
                f"| {category} | {values['findings']} | {values['mean_dice_delta']:+.6f} |"
            )
        lines.extend(["", "Subgroups:", ""])
        for grouping in ("focal_vs_diffuse", "tiny_vs_non_tiny"):
            for group, values in item[grouping].items():
                lines.append(
                    f"- {group}: n={values['findings']}, delta={values['mean_dice_delta']:+.6f}"
                )
        lines.append("")
    lines.extend(["## Verdict", "", f"`{verdict}`", ""])
    (args.root / "summary.md").write_text("\n".join(lines))
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
