#!/usr/bin/env python
"""Build the frozen-Qwen text bank for C2 LESS MedPlex alignment.

The bank deliberately contains only raw pooled contextual content-token
features.  The trainable C2 alignment head owns the projection and therefore
receives gradients; the cached Qwen representation remains frozen.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import torch


def normalize_prompt(value: str) -> str:
    return " ".join(str(value).strip().casefold().split())


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--token-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--split", default="train")
    args = parser.parse_args()
    payload = torch.load(args.token_cache, map_location="cpu", weights_only=False)
    records = payload.get("records") or []
    features = payload.get("token_features") or []
    if len(records) != len(features):
        raise ValueError("Token cache records/features length mismatch")
    vectors: list[torch.Tensor] = []
    ids: list[str] = []
    prompts: list[str] = []
    duplicate_prompts = 0
    seen: set[tuple[str, str, int]] = set()
    for record, feature in zip(records, features):
        if str(record.get("split")) != str(args.split):
            continue
        key = (str(record["split"]), str(record["case"]), int(record["finding_idx"]))
        if key in seen:
            raise ValueError(f"Duplicate finding key in token cache: {key}")
        seen.add(key)
        if not isinstance(feature, torch.Tensor) or feature.ndim != 2 or feature.shape[0] == 0:
            raise ValueError(f"Malformed token feature for {key}")
        vectors.append(feature.float().mean(dim=0).contiguous())
        ids.append(f"{key[1]}::{key[2]}")
        prompts.append(normalize_prompt(str(record.get("prompt", ""))))
    if len(vectors) < 16:
        raise RuntimeError("MedPlex text bank needs at least 16 train findings")
    stacked = torch.stack(vectors).contiguous()
    duplicate_prompts = len(prompts) - len(set(prompts))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "vectors": stacked,
        "ids": ids,
        "prompts": prompts,
        "metadata": {
            "schema": "c2_less_medplex_frozen_qwen_text_bank_v1",
            "source_token_cache": str(args.token_cache.resolve()),
            "source_token_cache_sha256": sha256_file(args.token_cache),
            "split": str(args.split),
            "entries": int(stacked.shape[0]),
            "feature_dim": int(stacked.shape[1]),
            "duplicate_normalized_prompts": int(duplicate_prompts),
        },
    }, args.output)
    digest = sha256_file(args.output)
    print(json.dumps({"output": str(args.output), "sha256": digest, "entries": len(ids), "dim": int(stacked.shape[1])}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
