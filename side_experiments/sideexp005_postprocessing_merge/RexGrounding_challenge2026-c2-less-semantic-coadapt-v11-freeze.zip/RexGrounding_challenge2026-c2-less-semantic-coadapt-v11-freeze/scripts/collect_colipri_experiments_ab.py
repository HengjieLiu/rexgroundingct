#!/usr/bin/env python3
"""Collect the independent CoLiPri A/B execution into one conservative report."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a-dir", type=Path, required=True)
    parser.add_argument("--b0-dir", type=Path, required=True)
    parser.add_argument("--b1-dir", type=Path, required=True)
    parser.add_argument("--a-job", required=True)
    parser.add_argument("--b0-job", required=True)
    parser.add_argument("--b1-job", required=True)
    parser.add_argument("--b1-dependency", required=True)
    parser.add_argument("--gpu", default="H200")
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "reports/colipri_experiments_A_B_execution_summary.md",
    )
    return parser.parse_args()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text()) if path.exists() else {"verdict": "INCONCLUSIVE", "error": f"missing {path}"}


def read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def markdown(frame: pd.DataFrame) -> str:
    if frame.empty:
        return "_No completed output._"
    clean = frame.copy()
    for column in clean.columns:
        clean[column] = clean[column].map(lambda value: f"{value:.6g}" if isinstance(value, float) else str(value))
    headers = list(map(str, clean.columns))
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    lines.extend("| " + " | ".join(row) + " |" for row in clean.astype(str).to_numpy())
    return "\n".join(lines)


def job_table(args: argparse.Namespace) -> pd.DataFrame:
    jobs = [("A", args.a_job, "none", args.a_dir), ("B0", args.b0_job, "none", args.b0_dir), ("B1", args.b1_job, args.b1_dependency, args.b1_dir)]
    rows = []
    for experiment, job_id, dependency, output in jobs:
        command = ["sacct", "-j", job_id, "-X", "-n", "-P", "--format=State,Elapsed,AllocTRES"]
        completed = subprocess.run(command, capture_output=True, text=True, check=False).stdout.strip().splitlines()
        values = completed[0].split("|") if completed else ["UNKNOWN", "", ""]
        rows.append({"Experiment": experiment, "Job ID": job_id, "Dependency": dependency, "GPU": args.gpu, "State": values[0], "Runtime": values[1], "Output": str(output)})
    return pd.DataFrame(rows)


def main() -> int:
    args = parse_args()
    a_result, b0_result, b1_result = (read_json(path) for path in (args.a_dir / "result.json", args.b0_dir / "result.json", args.b1_dir / "result.json"))
    a_summary = read_csv(args.a_dir / "router_summary.csv")
    b0_summary = read_csv(args.b0_dir / "full_volume_summary.csv")
    b1_summary = read_csv(args.b1_dir / "full_volume_summary.csv")
    a_bootstrap = read_json(args.a_dir / "bootstrap.json")
    a_delta = a_bootstrap.get("A2_minus_A0", {}).get("estimate")
    a_semantic = a_bootstrap.get("A2_minus_A3", {}).get("estimate")
    lines = [
        "# CoLiPri Experiments A and B", "", "## 1. Job and GPU summary", "", markdown(job_table(args)), "",
        "## 2. Experiment A question and result", "",
        "A tests whether frozen CoLiPri scalar alignment adds incremental value to the existing P0 finding-level zoom router. It does not test spatial segmentation utility.", "",
        f"**Experiment A verdict: {a_result.get('verdict', 'INCONCLUSIVE')}.**", "",
        "## 3. Experiment A OOF comparison", "", markdown(a_summary), "",
        f"A2 minus A0: {a_delta if a_delta is not None else 'unavailable'}. Correct minus shuffled control: {a_semantic if a_semantic is not None else 'unavailable'}.", "",
        "## 4. B0 frozen representation result", "", markdown(b0_summary), "",
        f"**B0 verdict: {b0_result.get('verdict', 'INCONCLUSIVE')}.**", "",
        "## 5. B1 partial-adaptation result", "", markdown(b1_summary), "",
        f"**B1 verdict: {b1_result.get('verdict', 'INCONCLUSIVE')}.**", "",
        "## 6. Does CoLiPri alignment translate into segmentation?", "",
        "Frozen off-the-shelf evidence is determined by B0 Correct versus Shuffled/ImageOnly/VoxTellControl. Partial-adaptation evidence is determined by B1 Correct versus Shuffled/VoxTellControl and B1 versus B0. Subgroup CSVs provide the separate single-finding, multi-finding, same-entity, focality, and size analyses.", "",
        "A Dice change is not attributed to image-text alignment unless correct text clearly beats shuffled text.", "",
        "## 7. Relationship between A and B", "",
        "A measures finding-level routing utility. B measures prompt-conditioned spatial segmentation utility. Success or failure in one is not proof about the other.", "",
        "## 8. Final recommendations", "",
        f"- Experiment A: **{a_result.get('verdict', 'INCONCLUSIVE')}**", f"- Experiment B: **{b1_result.get('verdict', b0_result.get('verdict', 'INCONCLUSIVE'))}**", "",
        "## 9. Reproduction commands", "", "```bash",
        f"# Frozen CoLiPri score extraction and exact P0 OOF routing\npython scripts/colipri_experiment_a_router.py --output-dir {args.a_dir}",
        f"# B0 shared crop/cache generation, equivalence smoke, four branches, evaluation, and bootstrap\npython scripts/colipri_experiment_b_probe.py b0 --output-dir {args.b0_dir}",
        f"# B1 three online partial-adaptation branches and fixed30 evaluation\npython scripts/colipri_experiment_b_probe.py b1 --b0-dir {args.b0_dir} --output-dir {args.b1_dir}",
        "```", "", "## 10. Modified and created files", "",
        "- `scripts/colipri_experiment_a_router.py`: Experiment A feature extraction and exact grouped OOF router.",
        "- `VoxTell/voxtell/model/colipri_matched_spatial_probe.py`: matched lightweight prompt-conditioned probe.",
        "- `scripts/colipri_experiment_b_probe.py`: B0 cache/equivalence/training/evaluation and B1 adaptation.",
        "- `tests/test_colipri_matched_spatial_probe.py`: probe shape, conditioning, and gradient tests.",
        "- `tests/test_colipri_experiments_ab.py`: shuffled-prompt and save/reload tests.",
        "- `reports/colipri_experiments_A_B_starting_state.md`: immutable starting-state audit.", "",
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n")
    print(f"Experiment A final verdict: {a_result.get('verdict', 'INCONCLUSIVE')}")
    print(f"Experiment A Dice delta versus original router: {a_delta}")
    print(f"Experiment A correct-versus-shuffled result: {a_semantic}")
    print(f"Experiment B0 final verdict: {b0_result.get('verdict', 'INCONCLUSIVE')}")
    print(f"B0 correct-text Dice: {b0_result.get('correct_text_dice')}")
    print(f"B0 shuffled-text Dice: {b0_result.get('shuffled_text_dice')}")
    print(f"B0 image-only Dice: {b0_result.get('image_only_dice')}")
    print(f"B0 VoxTell-control Dice: {b0_result.get('voxtell_control_dice')}")
    print(f"Experiment B1 final verdict: {b1_result.get('verdict', 'INCONCLUSIVE')}")
    print(f"B1 correct-text Dice: {b1_result.get('correct_text_dice')}")
    print(f"B1 shuffled-text Dice: {b1_result.get('shuffled_text_dice')}")
    print(f"B1 VoxTell-control Dice: {b1_result.get('voxtell_control_dice')}")
    print(f"B1 versus B0 delta: {b1_result.get('delta_vs_b0')}")
    print(f"Does CoLiPri alignment translate into segmentation?: see {args.output}")
    print(f"Combined report path: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
