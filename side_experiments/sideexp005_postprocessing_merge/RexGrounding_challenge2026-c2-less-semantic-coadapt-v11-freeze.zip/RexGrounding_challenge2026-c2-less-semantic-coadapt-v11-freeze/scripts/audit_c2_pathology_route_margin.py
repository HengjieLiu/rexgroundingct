#!/usr/bin/env python3
"""Frozen-checkpoint pathology-margin route attribution on canonical fixed30."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from collections import defaultdict
from contextlib import contextmanager
from pathlib import Path

import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from scripts import run_c2_anatomy_formulation_ranking as base
import scripts.train_voxtell_rex_full_nnunet_aug as tr

OUT = ROOT / "outputs/c2_pathology_route_attribution_audit"
P_CKPT = ROOT / "outputs/c2_less_semantic_coadapt_v11/p_pathology/checkpoints/checkpoint_update_5000.pth"
C2_CKPT = ROOT / "outputs/less_fan_conditioning_10k/c2_less_encoder_conditioning/checkpoints/checkpoint_update_5000.pth"
P_ARGS = ROOT / "outputs/c2_less_semantic_coadapt_v11/p_pathology/args.json"
FIXED = ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv"
PROMPTS = OUT / "prompt_caches"
TOKENS = ROOT / "outputs/c2_semantic_p_token_causal_audit/token_caches"
PAIRS = ROOT / "outputs/c2_semantic_p_token_causal_audit/samecase/eligible_pairs.csv"

P_CONDITIONS = {
    "normal": ("correct", "correct", False),
    "l_shuffle": ("correct", "within_shuffle", False),
    "l_neutral": ("correct", "neutral", False),
    "l_wrong": ("correct", "samecase_wrong", False),
    "g_neutral": ("global_neutral", "correct", False),
    "g_wrong": ("global_samecase_wrong", "correct", False),
    "both_neutral": ("global_neutral", "neutral", False),
    "both_wrong": ("global_samecase_wrong", "samecase_wrong", False),
    "less_bypass": ("correct", "correct", True),
}
C2_CONDITIONS = {k: P_CONDITIONS[k] for k in ("normal", "l_neutral", "g_neutral", "both_neutral", "less_bypass")}


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha_state(state: dict[str, torch.Tensor]) -> str:
    h = hashlib.sha256()
    for name in sorted(state):
        raw = state[name].detach().cpu().contiguous().view(torch.uint8).numpy().tobytes()
        h.update(name.encode()); h.update(raw)
    return h.hexdigest()


def cache_map(path: Path, field: str) -> dict[tuple[str, int], torch.Tensor]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    values = payload[field]
    if isinstance(values, torch.Tensor): values = list(values)
    return {(str(r["case"]), int(r["finding_idx"])): v.detach().clone() for r, v in zip(payload["records"], values)}


def write_rows(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=sorted({k for row in rows for k in row}), delimiter="\t")
        writer.writeheader(); writer.writerows(rows)


@contextmanager
def less_bypass(model: torch.nn.Module, enabled: bool):
    handles = []
    if enabled:
        blocks = getattr(model, "less_encoder_blocks")
        handles = [block.register_forward_hook(lambda _m, inputs, _out: inputs[0]) for block in blocks.values()]
    try:
        yield
    finally:
        for handle in handles: handle.remove()


def stats(rows: list[dict]) -> dict:
    values = np.asarray([float(r["margin"]) for r in rows])
    return {
        "n": int(len(values)), "mean_margin": float(values.mean()), "median_margin": float(np.median(values)),
        "iqr_margin": float(np.quantile(values, .75) - np.quantile(values, .25)),
        "pos_gt_neg": float((values > 0).mean()),
    }


def paired_drop(normal: list[dict], other: list[dict], samecase_only: bool, seed: int) -> dict:
    keys = ["case", "finding_idx"]
    a = pd.DataFrame(normal); b = pd.DataFrame(other)
    if samecase_only:
        eligible = pd.read_csv(PAIRS); eligible = eligible[eligible.eligible][keys]
        a = a.merge(eligible, on=keys); b = b.merge(eligible, on=keys)
    merged = a[keys + ["margin"]].merge(b[keys + ["margin"]], on=keys, suffixes=("_normal", "_other"), validate="one_to_one")
    merged["drop"] = merged.margin_normal - merged.margin_other
    case_values = {case: group["drop"].to_numpy() for case, group in merged.groupby("case")}
    cases = sorted(case_values); rng = np.random.default_rng(seed); draws = []
    for _ in range(3000):
        picked = rng.choice(cases, len(cases), replace=True)
        draws.append(float(np.concatenate([case_values[c] for c in picked]).mean()))
    return {
        "n": int(len(merged)), "mean_drop": float(merged["drop"].mean()), "median_drop": float(merged["drop"].median()),
        "ci95_low": float(np.quantile(draws, .025)), "ci95_high": float(np.quantile(draws, .975)),
    }


def make_sampler(cfg: dict):
    records = tr.load_manifest(Path(cfg["preprocessed_dir"])); val = tr.build_case_records(records, "val", None)
    embeddings = tr.load_embedding_map(Path(cfg["embedding_cache"]), "qwen")
    # Sampler initialization validates coverage of the complete validation
    # manifest.  Intervention tensors are injected only at forward time below.
    full_tokens, _ = tr.load_token_feature_map(Path(cfg["token_feature_cache"]))
    return val, base.construct_sampler(cfg, val, embeddings, full_tokens, 3701)


def evaluate(model, cfg: dict, conditions: dict, device: torch.device) -> tuple[dict[str, list[dict]], dict]:
    prompt_maps = {name: cache_map(PROMPTS / f"{name}.pt", "embeddings") for name in {v[0] for v in conditions.values()}}
    token_maps = {name: cache_map(TOKENS / f"{name}.pt", "token_features") for name in {v[1] for v in conditions.values()}}
    correct_tokens = cache_map(TOKENS / "correct.pt", "token_features")
    valid, sampler = make_sampler(cfg); wanted = base.read_fixed30(FIXED)
    head = model.less_semantic_alignment_heads["pathology"]
    output: dict[str, list[dict]] = defaultdict(list)
    identity = []
    for case in valid:
        for position, finding in enumerate(case["findings"]):
            item = (str(case["case"]), int(finding["finding_idx"]))
            if item not in wanted: continue
            image, _embedding, target, weight, meta = base.anchor_sample(sampler, case, position)
            correct = correct_tokens[item].to(device)
            prompt = str(meta["prompt_texts_after_shuffle"][0]); pieces = list(map(str, meta["token_strings_after_shuffle"][0]))
            phrase = tr.fan_semantic_pathology_phrase(prompt)
            if phrase is None: continue
            query, indices = tr._less_alignment_phrase_vector(head, prompt, phrase, pieces, correct)
            if query is None: continue
            positive = target[0].to(device).bool(); lobes = list(meta["prompt_location_lobes"][0])
            lobe5 = meta["_prompt_location_lobe5_rois"].to(device); side = meta["_prompt_location_side_rois"][0].to(device); lung = meta["_prompt_location_lung_rois"][0].to(device)
            if len(lobes) == 1 and str(lobes[0]) in tr.FAN_SEMANTIC_LOBE_TO_INDEX:
                anatomy = lobe5[tr.FAN_SEMANTIC_LOBE_TO_INDEX[str(lobes[0])]].bool()
            elif bool(side.any().item()): anatomy = side.bool()
            else: anatomy = lung.bool()
            negative = anatomy & ~positive
            for condition, (global_name, token_name, bypass) in conditions.items():
                global_value = prompt_maps[global_name][item].view(1, 1, -1).to(device)
                token_value = token_maps[token_name][item].to(device)
                tf = token_value.view(1, 1, token_value.shape[0], token_value.shape[1]); tm = torch.ones(tf.shape[:3], dtype=torch.bool, device=device)
                with less_bypass(model, bypass), torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
                    _ = model(image.unsqueeze(0).to(device), global_value.unsqueeze(0), token_features=tf, token_valid_mask=tm)
                    visual = model.last_less_decoder_stage3[0, 0]
                    pos_vec = tr._less_alignment_region_vector(head, visual, positive)
                    neg_vec = tr._less_alignment_region_vector(head, visual, negative)
                    if pos_vec is None or neg_vec is None: continue
                    pos_score = torch.dot(query, pos_vec); neg_score = torch.dot(query, neg_vec)
                output[condition].append({
                    "case": item[0], "finding_idx": item[1], "prompt": prompt, "phrase": phrase,
                    "query_token_indices": ",".join(map(str, indices)), "positive_score": float(pos_score),
                    "negative_score": float(neg_score), "margin": float(pos_score - neg_score),
                    "global_condition": global_name, "less_condition": token_name, "less_bypass": bypass,
                })
                identity.append({
                    "case": item[0], "finding_idx": item[1], "condition": condition,
                    "global_sha256": hashlib.sha256(prompt_maps[global_name][item].contiguous().numpy().tobytes()).hexdigest(),
                    "less_sha256": hashlib.sha256(token_maps[token_name][item].contiguous().numpy().tobytes()).hexdigest(),
                })
    return dict(output), {"rows": identity}


def swap_to_c2(model) -> int:
    state = model.state_dict(); source = torch.load(C2_CKPT, map_location="cpu", weights_only=False)["network_weights"]; copied = 0
    for name, value in source.items():
        if not name.startswith("less_semantic_alignment_heads.") and name in state and state[name].shape == value.shape:
            state[name] = value; copied += 1
    model.load_state_dict(state, strict=True); return copied


def validate_identities(rows: list[dict]) -> dict:
    frame = pd.DataFrame(rows); index = ["case", "finding_idx"]
    g = frame.pivot(index=index, columns="condition", values="global_sha256")
    t = frame.pivot(index=index, columns="condition", values="less_sha256")
    global_fixed = ["l_shuffle", "l_neutral", "l_wrong", "less_bypass"]
    less_fixed = ["g_neutral", "g_wrong"]
    checks = {
        "whole_sentence_identical_normal_vs_L_conditions": all(bool((g[name] == g["normal"]).all()) for name in global_fixed if name in g),
        "LESS_tokens_identical_normal_vs_G_conditions": all(bool((t[name] == t["normal"]).all()) for name in less_fixed if name in t),
    }
    if not all(checks.values()): raise RuntimeError(f"route tensor identity failure: {checks}")
    return checks


def gradient_audit(model, cfg: dict, device: torch.device) -> dict:
    correct = cache_map(TOKENS / "correct.pt", "token_features"); valid, sampler = make_sampler(cfg); wanted = base.read_fixed30(FIXED)
    for parameter in model.parameters(): parameter.requires_grad_(True)
    model.eval(); model.zero_grad(set_to_none=True)
    chosen = None
    for case in valid:
        for pos, finding in enumerate(case["findings"]):
            if (case["case"], int(finding["finding_idx"])) in wanted:
                sample = base.anchor_sample(sampler, case, pos)
                image, embedding, target, weight, meta = sample; tf = meta["_token_features"].unsqueeze(0).to(device); tm = meta["_token_valid_mask"].unsqueeze(0).to(device)
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    _ = model(image.unsqueeze(0).to(device), embedding.unsqueeze(0).to(device), token_features=tf, token_valid_mask=tm)
                    loss, st = tr.less_semantic_alignment_loss(
                        model, target.unsqueeze(0).to(device), weight.unsqueeze(0).to(device), tf,
                        meta["_prompt_location_lung_rois"].unsqueeze(0).to(device), meta["_prompt_location_side_rois"].unsqueeze(0).to(device),
                        meta["_prompt_location_exact_rois"].unsqueeze(0).to(device), meta["_prompt_location_lobe5_rois"].unsqueeze(0).to(device), meta, "pathology", 1.0)
                if int(st["less_semantic_path_eligible_count"]) > 0:
                    loss.backward(); chosen = {"case": case["case"], "finding_idx": int(finding["finding_idx"]), "loss": float(loss.detach())}; break
                model.zero_grad(set_to_none=True)
        if chosen: break
    if chosen is None: raise RuntimeError("no eligible gradient-audit finding")
    groups = defaultdict(list)
    for name, parameter in model.named_parameters():
        if parameter.grad is None: continue
        if name.startswith("less_semantic_alignment_heads."): group = "semantic_head"
        elif "decoder.stages.3" in name: group = "decoder_stage3"
        elif "decoder.stages." in name: group = "earlier_decoder_blocks"
        elif "less_encoder_blocks" in name: group = "less_modules"
        elif name.startswith("encoder.") or ".encoder." in name: group = "image_encoder"
        elif "transformer_decoder" in name or "prompt" in name.lower(): group = "prompt_decoder_global_path"
        else: group = "other_segmentation_path"
        groups[group].append(float(parameter.grad.detach().float().norm().item()) ** 2)
    norms = {group: float(np.sqrt(sum(values))) for group, values in groups.items()}; total = sum(norms.values())
    return {"sample": chosen, "groups": {group: {"grad_norm": value, "normalized_fraction": value / total if total else 0.0} for group, value in sorted(norms.items())}}


def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--device", default="cuda"); args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True); device = torch.device(args.device); began = time.time()
    cfg = json.loads(P_ARGS.read_text()); cfg["prompt_location_label_dir"] = str(ROOT / "data/rex_lobe_labels_preprocessed_v1")
    model = base.make_model(cfg, device, P_CKPT)
    head_before = sha_state({k: v for k, v in model.state_dict().items() if k.startswith("less_semantic_alignment_heads.pathology.")})
    gradient = gradient_audit(model, cfg, device); model.zero_grad(set_to_none=True)
    for parameter in model.parameters(): parameter.requires_grad_(False)
    p_rows, p_identity = evaluate(model, cfg, P_CONDITIONS, device)
    p_checks = validate_identities(p_identity["rows"])
    copied = swap_to_c2(model)
    head_after_swap = sha_state({k: v for k, v in model.state_dict().items() if k.startswith("less_semantic_alignment_heads.pathology.")})
    c2_rows, c2_identity = evaluate(model, cfg, C2_CONDITIONS, device)
    c2_checks = validate_identities(c2_identity["rows"])
    if head_before != head_after_swap: raise RuntimeError("P semantic head changed during C2 backbone swap")
    for label, rows_by_condition in (("p_route_interventions", p_rows), ("c2_control", c2_rows)):
        for condition, rows in rows_by_condition.items(): write_rows(OUT / label / f"{condition}_per_finding.tsv", rows)
    pair_summary = {}
    for label, rows_by_condition in (("P", p_rows), ("C2", c2_rows)):
        pair_summary[label] = {condition: stats(rows) for condition, rows in rows_by_condition.items()}
        pair_summary[label]["paired_drops"] = {
            condition: paired_drop(rows_by_condition["normal"], rows, condition.endswith("wrong"), 1100 + index)
            for index, (condition, rows) in enumerate(rows_by_condition.items()) if condition != "normal"
        }
    checks = OUT / "tensor_identity_checks"; checks.mkdir(exist_ok=True)
    pd.DataFrame(p_identity["rows"]).to_csv(checks / "p_route_tensor_hashes.tsv", sep="\t", index=False)
    pd.DataFrame(c2_identity["rows"]).to_csv(checks / "c2_route_tensor_hashes.tsv", sep="\t", index=False)
    (checks / "route_identity_summary.json").write_text(json.dumps({"P": p_checks, "C2": c2_checks}, indent=2) + "\n")
    grad_dir = OUT / "gradient_route"; grad_dir.mkdir(exist_ok=True); (grad_dir / "gradient_norms.json").write_text(json.dumps(gradient, indent=2) + "\n")
    identity = {
        "P_checkpoint": str(P_CKPT.resolve()), "P_checkpoint_sha256": sha_file(P_CKPT),
        "C2_checkpoint": str(C2_CKPT.resolve()), "C2_checkpoint_sha256": sha_file(C2_CKPT),
        "P_semantic_head_sha256_before": head_before, "P_semantic_head_sha256_after": head_after_swap,
        "head_unchanged": head_before == head_after_swap, "c2_backbone_tensors_copied": copied,
        "primary_query_policy": "fixed correct pathology phrase vector from the trained P head; intervention affects conditioning route only",
    }
    (OUT / "checkpoint_identity.md").write_text("# Checkpoint identity\n\n```json\n" + json.dumps(identity, indent=2) + "\n```\n")
    result = {"identity": identity, "summary": pair_summary, "gradient": gradient, "runtime_seconds": time.time() - began}
    (OUT / "margin_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__": main()
