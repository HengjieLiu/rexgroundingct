#!/usr/bin/env python3
"""Collect SLURM and source provenance for the token Image-to-Text pilot."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ROOT = ROOT / "outputs/token_image_text_attention_phase0"
SOURCE_FILES = (
    "VoxTell/voxtell/model/token_image_text.py",
    "VoxTell/voxtell/model/voxtell_experimental.py",
    "VoxTell/voxtell/inference/predictor.py",
    "scripts/build_qwen_token_feature_cache.py",
    "scripts/audit_token_image_text_phase0_initialization.py",
    "scripts/train_voxtell_rex_full_nnunet_aug.py",
    "scripts/run_voxtell_rex_inference.py",
    "scripts/run_controlled_fixed30_validation.py",
    "scripts/diagnose_token_image_text_phase0.py",
    "scripts/finalize_token_image_text_phase0.py",
    "scripts/collect_token_image_text_phase0_provenance.py",
    "scripts/build_token_image_text_cache_phase0.sbatch",
    "scripts/train_token_image_text_phase0.sbatch",
    "scripts/evaluate_token_image_text_phase0.sbatch",
    "scripts/diagnose_token_image_text_phase0.sbatch",
    "scripts/finalize_token_image_text_phase0.sbatch",
    "tests/test_token_image_text.py",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument(
        "--job", action="append", default=[], metavar="LABEL=JOBID",
        help="Record one labeled SLURM job; may be repeated.",
    )
    return parser.parse_args()


def command(*args: str, cwd: Path = ROOT, check: bool = True) -> str:
    return subprocess.run(
        list(args), cwd=cwd, check=check, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    ).stdout


def main() -> int:
    args = parse_args()
    root = args.experiment_root.resolve()
    provenance = root / "reproducibility"
    snapshot = provenance / "source_snapshot"
    snapshot.mkdir(parents=True, exist_ok=True)
    job_specs = list(args.job)
    existing_manifest = root / "job_manifest.json"
    if not job_specs and existing_manifest.is_file():
        existing_jobs = json.loads(existing_manifest.read_text())
        job_specs = [
            f"{label}={int(item['job_id'])}" for label, item in existing_jobs.items()
        ]
    jobs = {}
    for item in job_specs:
        label, separator, job_id = item.partition("=")
        if not separator or not label or not job_id.isdigit():
            raise ValueError(f"Expected LABEL=JOBID, got {item!r}")
        output = command(
            "sacct", "-j", job_id, "-X", "-n", "-P",
            "--format=JobID,JobName,State,Elapsed,ElapsedRaw,ExitCode,ReqMem,AllocTRES,NodeList",
        ).strip()
        fields = output.split("|") if output else []
        jobs[label] = {
            "job_id": int(job_id),
            "sacct_raw": output,
            "state": fields[2] if len(fields) > 2 else "UNKNOWN",
            "elapsed": fields[3] if len(fields) > 3 else None,
            "elapsed_seconds": int(fields[4]) if len(fields) > 4 and fields[4].isdigit() else None,
            "exit_code": fields[5] if len(fields) > 5 else None,
            "requested_memory": fields[6] if len(fields) > 6 else None,
            "allocated_tres": fields[7] if len(fields) > 7 else None,
            "node_list": fields[8] if len(fields) > 8 else None,
        }
    (root / "job_manifest.json").write_text(json.dumps(jobs, indent=2) + "\n")

    git = shutil.which("git")
    metadata = {
        "root_git_commit": (
            command(git, "rev-parse", "HEAD").strip() if git else "unavailable_on_compute_node"
        ),
        "voxtell_git_commit": (
            command(git, "-C", "VoxTell", "rev-parse", "HEAD").strip()
            if git else "unavailable_on_compute_node"
        ),
        "canonical_checkpoint": str(
            (ROOT / "outputs/s3d_matched_continue_from_weakdiffuse_control_step1000/allcat_1over1_only_to_step6000/checkpoints/checkpoint_step_6000.pth").resolve()
        ),
        "source_files": list(SOURCE_FILES),
    }
    (provenance / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    if git:
        (provenance / "root_git_status.txt").write_text(command(git, "status", "--short"))
        (provenance / "voxtell_git_status.txt").write_text(
            command(git, "-C", "VoxTell", "status", "--short")
        )
        (provenance / "root_tracked_changes.patch").write_text(
            command(git, "diff", "--binary", check=False)
        )
        (provenance / "voxtell_tracked_changes.patch").write_text(
            command(git, "-C", "VoxTell", "diff", "--binary", check=False)
        )
    else:
        for name in (
            "root_git_status.txt", "voxtell_git_status.txt",
            "root_tracked_changes.patch", "voxtell_tracked_changes.patch",
        ):
            (provenance / name).write_text("git unavailable on compute node; refresh from login environment\n")
    for relative in SOURCE_FILES:
        source = ROOT / relative
        if not source.is_file():
            raise FileNotFoundError(source)
        destination = snapshot / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
    print(json.dumps({"jobs": jobs, "provenance": str(provenance)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
