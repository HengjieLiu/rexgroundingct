#!/usr/bin/env python
"""Compare control, current adaptive, L1, and L2 loss/gradient scales."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import torch

from scripts.train_voxtell_rex_full_nnunet_aug import segmentation_loss


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--current-map", type=Path, required=True)
    parser.add_argument("--l1-map", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    return parser.parse_args()


def fixed_batch() -> tuple[torch.Tensor, torch.Tensor, list[str]]:
    target = torch.zeros(1, 4, 16, 16, 16)
    logits = torch.full_like(target, -4.0)

    target[0, 0, 5:11, 5:11, 5:11] = 1
    logits[0, 0, 5:11, 5:11, 5:11] = 3.0
    logits[0, 0, 2:5, 5:11, 5:11] = 2.0

    target[0, 1, 3:9, 3:9, 3:9] = 1
    logits[0, 1, 3:6, 3:9, 3:9] = 2.0

    target[0, 2, 7:13, 7:13, 7:13] = 1
    logits[0, 2, 7:11, 7:13, 7:13] = 2.0
    logits[0, 2, 4:7, 7:13, 7:13] = 1.5

    logits[0, 3, 1:4, 1:4, 1:4] = 1.0
    return logits, target, ["1b", "1a", "2d", "unknown"]


def evaluate(
    label: str,
    mode: str,
    mapping: dict,
    base_logits: torch.Tensor,
    target: torch.Tensor,
    categories: list[str],
    *,
    dice_weight: float = 0.5,
    tversky_weight: float = 1.0,
) -> dict:
    logits = base_logits.clone().requires_grad_(True)
    loss, stats = segmentation_loss(
        logits,
        target,
        prompt_weights=torch.ones(1, 4),
        prompt_categories=[categories],
        rex_loss_mode=mode,
        category_tversky_mapping=mapping,
        category_dice_weight=dice_weight,
        category_tversky_weight=tversky_weight,
        voxel_bce_weighting=True,
        bce_foreground_weight=1.0,
        bce_boundary_weight=1.5,
        bce_background_weight=0.5,
        bce_boundary_radius=4,
        empty_target_loss_mode="bce_only",
        empty_target_loss_weight=0.5,
    )
    loss.backward()
    gradient = logits.grad.detach()
    return {
        "experiment": label,
        "loss_mode": mode,
        "total_loss": float(loss.detach()),
        "bce": stats["scale0_bce"],
        "dice": stats["scale0_dice_loss"],
        "tversky": stats.get("scale0_tversky_loss", 0.0),
        "weighted_dice_component": stats.get("scale0_category_dice_component", 0.0),
        "weighted_tversky_component": stats.get("scale0_category_tversky_component", 0.0),
        "logits_gradient_norm": float(gradient.norm()),
        "positive_gradient_norm": float(gradient[:, :3].norm()),
        "empty_gradient_norm": float(gradient[:, 3:].norm()),
    }


def main() -> int:
    args = parse_args()
    current_mapping = json.loads(args.current_map.read_text())
    l1_mapping = json.loads(args.l1_map.read_text())
    logits, target, categories = fixed_batch()
    rows = [
        evaluate("control", "dice_bce", current_mapping, logits, target, categories),
        evaluate(
            "adaptive_a0p7_b0p3",
            "category_adaptive_tversky",
            current_mapping,
            logits,
            target,
            categories,
        ),
        evaluate(
            "l1_a0p6_b0p4",
            "category_adaptive_tversky",
            l1_mapping,
            logits,
            target,
            categories,
        ),
        evaluate(
            "l2_dice0p5_tversky0p5",
            "category_adaptive_dice_tversky",
            current_mapping,
            logits,
            target,
            categories,
            dice_weight=0.5,
            tversky_weight=0.5,
        ),
    ]
    control_norm = rows[0]["logits_gradient_norm"]
    for row in rows:
        ratio = row["logits_gradient_norm"] / max(control_norm, 1e-12)
        row["gradient_norm_vs_control"] = ratio
        if not 0.5 <= ratio <= 2.0:
            raise RuntimeError(
                f"{row['experiment']} gradient ratio {ratio:.6f} is outside [0.5, 2.0]"
            )

    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "gradient_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (args.out_dir / "gradient_summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    lines = [
        "# L1/L2 loss and gradient audit",
        "",
        "All runs use the same fixed logits, targets, prompt weights, weighted BCE, and empty-target BCE.",
        "",
        "```text",
    ]
    headers = ["experiment", "total_loss", "bce", "dice", "tversky", "logits_gradient_norm", "gradient_norm_vs_control"]
    lines.append(" ".join(f"{name:>24}" for name in headers))
    for row in rows:
        lines.append(
            " ".join(
                f"{row[name]:>24.7f}" if isinstance(row[name], float) else f"{row[name]:>24}"
                for name in headers
            )
        )
    lines.extend(["```", ""])
    (args.out_dir / "report.md").write_text("\n".join(lines))
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
