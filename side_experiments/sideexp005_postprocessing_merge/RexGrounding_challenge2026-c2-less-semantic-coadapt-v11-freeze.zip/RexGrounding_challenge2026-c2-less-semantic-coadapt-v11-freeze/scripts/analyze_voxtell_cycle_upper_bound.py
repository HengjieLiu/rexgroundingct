#!/usr/bin/env python3
"""Analyze frozen VoxTell cycle features with the existing head and OOF ridge probe."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.linear_model import Ridge
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from torch import nn

ROOT = Path(__file__).resolve().parents[1]
TREATMENT = ROOT / "outputs/voxtell_embedding_cycle_treatment_retry2_20260806/checkpoints/checkpoint_step_300.pth"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--feature-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--cycle-checkpoint", type=Path, default=TREATMENT)
    parser.add_argument("--bootstrap-reps", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20260806)
    return parser.parse_args()


def normalized(value: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(value, axis=-1, keepdims=True)
    return value / np.maximum(norm, 1e-8)


def markdown_table(frame: pd.DataFrame) -> str:
    """Small dependency-free Markdown table writer."""
    columns = [str(column) for column in frame.columns]
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in frame.itertuples(index=False, name=None):
        values = []
        for value in row:
            if isinstance(value, float):
                values.append(f"{value:.6f}")
            else:
                values.append(str(value))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def build_existing_head(checkpoint: Path) -> nn.Module:
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if "mask_prompt_cycle_weights" not in payload:
        raise KeyError(f"No mask_prompt_cycle_weights in {checkpoint}")
    head = nn.Sequential(
        nn.LayerNorm(320), nn.Linear(320, 1024), nn.GELU(), nn.Linear(1024, 2560)
    )
    head.load_state_dict(payload["mask_prompt_cycle_weights"], strict=True)
    return head.eval().requires_grad_(False)


def apply_head(head: nn.Module, feature: np.ndarray) -> np.ndarray:
    shape = feature.shape
    flat = torch.from_numpy(feature.reshape(-1, shape[-1])).float()
    with torch.inference_mode():
        value = F.normalize(head(flat), dim=-1).numpy()
    return value.reshape(*shape[:-1], value.shape[-1])


def fit_oof_probe(
    gt: np.ndarray,
    target: np.ndarray,
    conditions: dict[str, np.ndarray],
    groups: np.ndarray,
) -> tuple[dict[str, np.ndarray], pd.DataFrame]:
    outputs = {
        name: np.zeros((*value.shape[:-1], target.shape[1]), dtype=np.float32)
        for name, value in conditions.items()
    }
    fold_rows = []
    splitter = GroupKFold(5)
    for fold, (train, test) in enumerate(splitter.split(gt, groups=groups)):
        probe = make_pipeline(StandardScaler(), Ridge(alpha=10.0))
        probe.fit(gt[train], target[train])
        for name, value in conditions.items():
            if value.ndim == 2:
                outputs[name][test] = normalized(probe.predict(value[test])).astype(np.float32)
            else:
                # Random controls are [R,N,C]. Apply this fold's exact same GT-trained probe.
                for rep in range(value.shape[0]):
                    outputs[name][rep, test] = normalized(
                        probe.predict(value[rep, test])
                    ).astype(np.float32)
        train_fit = normalized(probe.predict(gt[train]))
        fold_rows.append({
            "fold": fold,
            "train_cases": len(np.unique(groups[train])),
            "test_cases": len(np.unique(groups[test])),
            "train_findings": len(train),
            "test_findings": len(test),
            "train_mean_correct_cosine": float(np.mean(np.sum(train_fit * target[train], axis=1))),
        })
    return outputs, pd.DataFrame(fold_rows)


def candidate_indices(manifest: pd.DataFrame, index: int, level: str) -> np.ndarray:
    row = manifest.iloc[index]
    if level == "global":
        return np.arange(len(manifest))
    if level == "same_case":
        return np.flatnonzero(manifest.case_id.to_numpy() == row.case_id)
    if level == "same_case_same_entity":
        return np.flatnonzero(
            (manifest.case_id.to_numpy() == row.case_id)
            & (manifest.entity.fillna("").to_numpy() == (row.entity if pd.notna(row.entity) else ""))
        )
    if level == "same_entity_cross_case":
        return np.flatnonzero(
            (manifest.entity.fillna("").to_numpy() == (row.entity if pd.notna(row.entity) else ""))
            & ((manifest.case_id.to_numpy() != row.case_id) | (np.arange(len(manifest)) == index))
        )
    if level == "anatomy_swapped":
        entity = manifest.entity.fillna("").to_numpy() == (row.entity if pd.notna(row.entity) else "")
        anatomy = manifest.anatomy_signature.fillna("").astype(str).to_numpy()
        changed = anatomy != (str(row.anatomy_signature) if pd.notna(row.anatomy_signature) else "")
        return np.flatnonzero((entity & changed) | (np.arange(len(manifest)) == index))
    raise ValueError(level)


def retrieval_details(
    reconstructed: np.ndarray,
    target: np.ndarray,
    manifest: pd.DataFrame,
    level: str,
) -> tuple[dict, pd.DataFrame]:
    rows, pair_labels, pair_scores = [], [], []
    for index in range(len(manifest)):
        candidates = candidate_indices(manifest, index, level)
        if index not in candidates or len(candidates) < 2:
            continue
        similarities = reconstructed[index] @ target[candidates].T
        order = np.argsort(similarities)[::-1]
        correct_position = int(np.flatnonzero(candidates == index)[0])
        rank = int(np.flatnonzero(order == correct_position)[0]) + 1
        negative = np.delete(similarities, correct_position)
        rows.append({
            "finding_key": manifest.iloc[index].finding_key,
            "case_id": manifest.iloc[index].case_id,
            "category": manifest.iloc[index].category,
            "retrieval_level": level,
            "candidate_count": len(candidates),
            "rank": rank,
            "top1": int(rank == 1),
            "reciprocal_rank": 1.0 / rank,
            "pairwise_win_rate": float(np.mean(similarities[correct_position] > negative)),
            "hard_negative_margin": float(similarities[correct_position] - negative.max()),
            "correct_similarity": float(similarities[correct_position]),
        })
        pair_labels.extend([1, *([0] * len(negative))])
        pair_scores.extend([float(similarities[correct_position]), *negative.tolist()])
    details = pd.DataFrame(rows)
    if details.empty:
        return {"n": 0}, details
    return {
        "n": len(details),
        "eligible_cases": int(details.case_id.nunique()),
        "mean_candidates": float(details.candidate_count.mean()),
        "chance_top1": float(np.mean(1.0 / details.candidate_count)),
        "top1": float(details.top1.mean()),
        "mrr": float(details.reciprocal_rank.mean()),
        "median_rank": float(details["rank"].median()),
        "pairwise_win_rate": float(details.pairwise_win_rate.mean()),
        "hard_negative_margin": float(details.hard_negative_margin.mean()),
        "auroc": float(roc_auc_score(pair_labels, pair_scores)),
        "auprc": float(average_precision_score(pair_labels, pair_scores)),
    }, details


def bootstrap_difference(
    left: pd.DataFrame, right: pd.DataFrame, reps: int, seed: int
) -> dict:
    joined = left[["finding_key", "case_id", "top1", "reciprocal_rank"]].merge(
        right[["finding_key", "top1", "reciprocal_rank"]], on="finding_key",
        suffixes=("_left", "_right"), validate="one_to_one",
    )
    cases = joined.case_id.unique()
    rng = np.random.default_rng(seed)
    top1, mrr = [], []
    groups = {case: joined[joined.case_id.eq(case)] for case in cases}
    for _ in range(reps):
        sampled = rng.choice(cases, size=len(cases), replace=True)
        block = pd.concat([groups[case] for case in sampled], ignore_index=True)
        top1.append(float((block.top1_left - block.top1_right).mean()))
        mrr.append(float((block.reciprocal_rank_left - block.reciprocal_rank_right).mean()))
    return {
        "top1_estimate": float((joined.top1_left - joined.top1_right).mean()),
        "top1_ci95": [float(np.quantile(top1, 0.025)), float(np.quantile(top1, 0.975))],
        "mrr_estimate": float((joined.reciprocal_rank_left - joined.reciprocal_rank_right).mean()),
        "mrr_ci95": [float(np.quantile(mrr, 0.025)), float(np.quantile(mrr, 0.975))],
        "eligible_findings": len(joined),
        "eligible_cases": len(cases),
    }


def main() -> int:
    args = parse_args()
    if args.output_dir.exists():
        raise FileExistsError(f"Refusing to overwrite {args.output_dir}")
    args.output_dir.mkdir(parents=True)
    manifest = pd.read_csv(args.feature_dir / "feature_manifest.csv")
    loaded = np.load(args.feature_dir / "cycle_upper_bound_features.npz")
    target = normalized(loaded["target"].astype(np.float32))
    conditions = {
        name: loaded[name].astype(np.float32)
        for name in ("gt", "pred_soft", "pred_threshold", "shuffled", "full", "empty", "random")
    }
    if len(manifest) != 49 or manifest.case_id.nunique() != 30:
        raise RuntimeError("Cycle diagnostic requires the exact fixed30 49-finding cohort")
    if conditions["gt"].shape != (49, 320) or target.shape != (49, 2560):
        raise RuntimeError(f"Unexpected cache shapes: {conditions['gt'].shape}/{target.shape}")

    head = build_existing_head(args.cycle_checkpoint)
    existing = {name: apply_head(head, value) for name, value in conditions.items()}
    probe, fold_audit = fit_oof_probe(
        conditions["gt"], target, conditions, manifest.case_id.to_numpy()
    )
    fold_audit.to_csv(args.output_dir / "ridge_probe_fold_audit.csv", index=False)

    levels = ("global", "same_case", "same_case_same_entity", "same_entity_cross_case", "anatomy_swapped")
    summary_rows, detail_frames = [], []
    detail_lookup: dict[tuple[str, str, str], pd.DataFrame] = {}
    for analysis_name, outputs in (("C1_existing_cycle_head", existing), ("C2_oof_ridge_probe", probe)):
        for condition, values in outputs.items():
            reps = range(values.shape[0]) if values.ndim == 3 else [None]
            rep_metrics = []
            for rep in reps:
                current = values[rep] if rep is not None else values
                for level in levels:
                    metrics, details = retrieval_details(current, target, manifest, level)
                    if metrics.get("n", 0) == 0:
                        continue
                    row = {
                        "analysis": analysis_name,
                        "condition": condition,
                        "random_rep": rep,
                        "retrieval_level": level,
                        **metrics,
                    }
                    rep_metrics.append(row)
                    details = details.assign(
                        analysis=analysis_name, condition=condition,
                        random_rep=rep if rep is not None else -1,
                    )
                    detail_frames.append(details)
                    if rep is None:
                        detail_lookup[(analysis_name, condition, level)] = details
            block = pd.DataFrame(rep_metrics)
            if values.ndim == 3:
                numeric = [column for column in block.columns if column not in {"analysis", "condition", "random_rep", "retrieval_level"}]
                averaged = block.groupby(["analysis", "condition", "retrieval_level"], as_index=False)[numeric].mean()
                summary_rows.extend(averaged.to_dict("records"))
            else:
                summary_rows.extend(block.drop(columns="random_rep").to_dict("records"))
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(args.output_dir / "retrieval_summary.csv", index=False)
    details = pd.concat(detail_frames, ignore_index=True)
    details.to_csv(args.output_dir / "retrieval_per_finding.csv", index=False)

    bootstraps = {}
    for analysis_name in ("C1_existing_cycle_head", "C2_oof_ridge_probe"):
        for level in ("global", "same_case", "same_case_same_entity"):
            gt_key = (analysis_name, "gt", level)
            if gt_key not in detail_lookup:
                continue
            for control in ("pred_soft", "full"):
                key = (analysis_name, control, level)
                if key in detail_lookup:
                    bootstraps[f"{analysis_name}:{level}:gt_minus_{control}"] = bootstrap_difference(
                        detail_lookup[gt_key], detail_lookup[key], args.bootstrap_reps, args.seed
                    )
    (args.output_dir / "paired_case_bootstrap.json").write_text(json.dumps(bootstraps, indent=2) + "\n")

    def metric(analysis: str, condition: str, level: str, column: str = "top1") -> float:
        row = summary[
            summary.analysis.eq(analysis) & summary.condition.eq(condition)
            & summary.retrieval_level.eq(level)
        ]
        return float(row.iloc[0][column]) if len(row) else float("nan")

    analysis = "C2_oof_ridge_probe"
    gt_global = metric(analysis, "gt", "global")
    random_global = metric(analysis, "random", "global")
    full_global = metric(analysis, "full", "global")
    gt_same = metric(analysis, "gt", "same_case")
    chance_same = metric(analysis, "gt", "same_case", "chance_top1")
    gt_entity = metric(analysis, "gt", "same_case_same_entity")
    chance_entity = metric(analysis, "gt", "same_case_same_entity", "chance_top1")
    if not np.isfinite(gt_global) or not np.isfinite(gt_same):
        classification = "U4. INCONCLUSIVE"
        recommendation = "D. Inconclusive; repair the missing fixed30 retrieval subgroup only."
    elif gt_global <= max(random_global, full_global) + 0.05:
        classification = "U3. WEAK / NO UPPER BOUND"
        recommendation = "C. Stop cycle/report-generation with this image feature and prompt target."
    elif gt_same <= chance_same + 0.10 or (np.isfinite(gt_entity) and gt_entity <= chance_entity + 0.10):
        classification = "U2. CATEGORY-LEVEL ONLY"
        recommendation = "B. Restrict any continuation to entity/category-level semantic consistency."
    else:
        classification = "U1. STRONG UPPER BOUND"
        recommendation = "A. Continue embedding cycle with a better head/optimization design."

    result = {
        "classification": classification,
        "recommendation": recommendation,
        "existing_head": {
            "gt_global_top1": metric("C1_existing_cycle_head", "gt", "global"),
            "pred_global_top1": metric("C1_existing_cycle_head", "pred_soft", "global"),
            "gt_same_case_top1": metric("C1_existing_cycle_head", "gt", "same_case"),
        },
        "tiny_probe": {
            "gt_global_top1": gt_global,
            "pred_global_top1": metric(analysis, "pred_soft", "global"),
            "random_global_top1": random_global,
            "full_global_top1": full_global,
            "gt_same_case_top1": gt_same,
            "pred_same_case_top1": metric(analysis, "pred_soft", "same_case"),
            "same_case_chance": chance_same,
            "gt_same_case_same_entity_top1": gt_entity,
            "same_case_same_entity_chance": chance_entity,
        },
        "eligible_same_case": int(summary[(summary.analysis.eq(analysis)) & summary.condition.eq("gt") & summary.retrieval_level.eq("same_case")].iloc[0].n),
        "eligible_same_case_same_entity": int(summary[(summary.analysis.eq(analysis)) & summary.condition.eq("gt") & summary.retrieval_level.eq("same_case_same_entity")].iloc[0].n),
    }
    (args.output_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    display = summary[
        summary.retrieval_level.isin(["global", "same_case", "same_case_same_entity"])
        & summary.condition.isin(["gt", "pred_soft", "pred_threshold", "random", "shuffled", "full", "empty"])
    ][["analysis", "condition", "retrieval_level", "n", "chance_top1", "top1", "mrr", "median_rank", "pairwise_win_rate", "hard_negative_margin", "auroc", "auprc"]]
    report = f"""# VoxTell Cycle Upper-Bound Diagnostic

**Classification: {classification}.**

**Recommendation: {recommendation}**

## Feature and target

- Primary image-only feature: VoxTell encoder skip index 4, before text fusion, `[B,320,12,12,12]` for each 192-cubed patch.
- Pooling: trilinearly resampled soft ROI weights with sliding-window Gaussian overlap weights.
- Target: frozen, L2-normalized 2560-D Qwen prompt embedding.
- Existing head: `LayerNorm(320) -> Linear(320,1024) -> GELU -> Linear(1024,2560)`, final Treatment step300.
- Tiny upper-bound probe: `StandardScaler -> Ridge(alpha=10)`, five-fold GroupKFold by case, fit only on GT-pooled training features. The same fold model was applied unchanged to every control mask.
- Cohort: 30 cases / 49 findings. Random control: 20 approximately volume-matched realizations per finding.

## Retrieval results

{markdown_table(display)}

## Direct answers

1. GT versus predicted: tiny-probe global top-1 {gt_global:.3f} versus {metric(analysis, 'pred_soft', 'global'):.3f}; same-case {gt_same:.3f} versus {metric(analysis, 'pred_soft', 'same_case'):.3f}.
2. GT versus controls: random global {random_global:.3f}; full-ROI global {full_global:.3f}.
3. Same-case retrieval chance/top-1: {chance_same:.3f}/{gt_same:.3f} over {result['eligible_same_case']} eligible findings.
4. Same-case same-entity chance/top-1: {chance_entity:.3f}/{gt_entity:.3f} over {result['eligible_same_case_same_entity']} eligible findings.
5. Existing trained cycle head with GT global/same-case top-1: {result['existing_head']['gt_global_top1']:.3f}/{result['existing_head']['gt_same_case_top1']:.3f}.
6. The tiny probe result is the leakage-safe representation upper bound; its comparison with C1 separates head optimization from feature identifiability.

Case-level paired bootstrap results are in `paired_case_bootstrap.json`. The anatomy-swapped row is diagnostic only because the fixed30 metadata provide few reliable swapped candidates.
"""
    report_path = ROOT / "reports/voxtell_cycle_upper_bound_diagnostic.md"
    report_path.write_text(report)
    print(json.dumps(result, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
