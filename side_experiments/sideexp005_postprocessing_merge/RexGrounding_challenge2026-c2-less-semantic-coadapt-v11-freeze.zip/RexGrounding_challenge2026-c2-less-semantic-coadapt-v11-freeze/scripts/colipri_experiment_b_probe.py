#!/usr/bin/env python3
"""B0 frozen-feature and B1 partial-adaptation CoLiPri segmentation probes."""

from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
import os
import random
import socket
import sys
import time
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import torchio as tio
from nibabel.processing import resample_from_to


ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "scripts", ROOT / "VoxTell"):
    sys.path.insert(0, str(path))

import train_voxtell_rex_full_nnunet_aug as rex_train  # noqa: E402
from voxtell.model.colipri_matched_spatial_probe import (  # noqa: E402
    MatchedPromptSpatialProbe,
    binary_dice,
    dice_bce_loss,
)


SEED = 20260804
UPDATES = (0, 100, 200, 400)
COLIPRI_CHECKPOINT = Path(
    "/home/shenc2/.cache/huggingface/hub/models--microsoft--colipri/"
    "snapshots/be872ebec5c62894cf183b09835ec6fd7be537f5/model.safetensors"
)
ANCHOR_CHECKPOINT = ROOT / (
    "outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000/"
    "checkpoints/checkpoint_best_val_dice_step_3800.pth"
)
PREPROCESSED = ROOT / "data/rex_voxtell_preprocessed_v1"
EMBEDDINGS = ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt"
FIXED30 = ROOT / "outputs/s3_1over1_allcat_v11_e1e-5_d1e-4_s3e1e-4_1gpu_bs1_acc4_10kupd/fixed30_manifest.json"
BASELINE_FIXED30 = ROOT / (
    "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/"
    "per_finding_threshold_metrics.csv"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--output-dir", type=Path, required=True)
    common.add_argument("--device", default="cuda:0")
    common.add_argument("--train-cache-samples", type=int, default=96)
    common.add_argument("--val-cache-samples", type=int, default=20)
    common.add_argument("--grad-accum", type=int, default=4)
    common.add_argument("--seed", type=int, default=SEED)
    common.add_argument("--smoke-only", action="store_true")
    common.add_argument("--bootstrap-reps", type=int, default=10_000)
    common.add_argument(
        "--reuse-training-cache-from",
        type=Path,
        help="Reuse a validated shared-crop and feature cache from an earlier interrupted B0 run.",
    )
    common.add_argument(
        "--reuse-fixed30-cache-from",
        type=Path,
        help="Reuse a validated complete fixed30 sliding-window cache from an earlier interrupted B0 run.",
    )
    b0 = sub.add_parser("b0", parents=[common])
    b0.add_argument("--updates", type=int, default=400)
    sub.add_parser(
        "b0-finalize",
        parents=[common],
        help="Finalize an otherwise complete B0 run from its saved CSV artifacts.",
    )
    b1 = sub.add_parser("b1", parents=[common])
    b1.add_argument("--b0-dir", type=Path, required=True)
    b1.add_argument("--updates", type=int, default=400)
    b1.add_argument("--encoder-lr", type=float, default=5e-6)
    b1.add_argument("--probe-lr", type=float, default=1e-4)
    return parser.parse_args()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def state_sha256(module: torch.nn.Module, include=None) -> str:
    digest = hashlib.sha256()
    for name, value in module.state_dict().items():
        if include is not None and not include(name):
            continue
        digest.update(name.encode())
        digest.update(value.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def atomic_json(value: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def markdown_table(frame: pd.DataFrame) -> str:
    """Render a compact table without requiring the optional tabulate package."""
    if frame.empty:
        return "_No rows._"
    clean = frame.copy()
    for column in clean.columns:
        clean[column] = clean[column].map(
            lambda value: f"{value:.6g}" if isinstance(value, (float, np.floating)) else str(value)
        )
    headers = [str(column) for column in clean.columns]
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    lines.extend("| " + " | ".join(row) + " |" for row in clean.astype(str).to_numpy())
    return "\n".join(lines)


def seed_all(seed: int) -> None:
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)


def prepare_records(split: str) -> list[dict[str, Any]]:
    rows = rex_train.load_manifest(PREPROCESSED)
    return rex_train.build_case_records(rows, split, None)


def build_sampler(cases, embeddings, cache_size=4, sampler_seed=SEED):
    return rex_train.RexPreprocessedSampler(
        preprocessed_dir=PREPROCESSED,
        cases=cases,
        embedding_map=embeddings,
        patch_size=(192, 192, 192),
        positive_prompts=2,
        negative_prompts=1,
        positive_loss_weight=1.0,
        negative_loss_weight=1.0,
        foreground_prob=0.85,
        require_positive_crop=True,
        min_positive_voxels=1,
        max_crop_attempts=50,
        max_sample_attempts=50,
        cache_size=cache_size,
        augmenter=None,
        hard_negative_sampler=False,
        hard_negative_match="category_then_keyword",
        hard_negative_exclude_identical_prompt=True,
        sampler_mode="anchor85_hardneg70",
        anchor_positive_prob=0.85,
        same_case_negative_prob=0.15,
        shuffle_prompt_order=True,
        cross_case_negative_requires_foreground=True,
        anchor_hard_negative_prob=0.70,
        sampler_seed=sampler_seed,
    )


def parse_bbox(value: str) -> tuple[np.ndarray, np.ndarray]:
    intervals = [[int(part) for part in axis.split(":")] for axis in value.split(";")]
    return np.asarray([item[0] for item in intervals]), np.asarray([item[1] for item in intervals])


class RawCaseCache:
    def __init__(self, max_cases: int = 4) -> None:
        self.max_cases = max_cases
        self.values: dict[str, tuple[np.ndarray, np.ndarray, float, float, np.ndarray]] = {}

    def load(self, case_id: str) -> tuple[np.ndarray, np.ndarray, float, float, np.ndarray]:
        if case_id in self.values:
            return self.values[case_id]
        case_stem = case_id.removesuffix(".nii.gz")
        val_metadata = PREPROCESSED / "metadata/val" / f"{case_stem}.json"
        train_metadata = PREPROCESSED / "metadata/train" / f"{case_stem}.json"
        metadata_path = val_metadata if val_metadata.exists() else train_metadata
        if not metadata_path.exists():
            raise FileNotFoundError(
                f"Missing preprocessed metadata for {case_id}: checked {val_metadata} and {train_metadata}"
            )
        meta = json.loads(metadata_path.read_text())
        image = nib.as_closest_canonical(nib.load(str(ROOT / "data/ct_rate_volumes_fixed" / case_id)))
        xyz = np.asanyarray(image.dataobj).astype(np.float32, copy=False)
        dhw = xyz.transpose(2, 1, 0)
        bbox = meta["crop_bbox"]
        dhw = dhw[tuple(slice(int(lo), int(hi)) for lo, hi in bbox)]
        mean, std = float(dhw.mean()), float(dhw.std())
        spacing = np.asarray(image.header.get_zooms()[:3], dtype=np.float64)
        value = (dhw, spacing, mean, max(std, 1e-8), np.asarray(image.affine))
        if len(self.values) >= self.max_cases:
            self.values.pop(next(iter(self.values)))
        self.values[case_id] = value
        return value


def padded_crop(array: np.ndarray, start: np.ndarray, size=(192, 192, 192), fill=0.0) -> np.ndarray:
    size = np.asarray(size)
    output = np.full(tuple(size), fill, dtype=np.float32)
    src, dst = [], []
    for axis in range(3):
        lo, hi = max(int(start[axis]), 0), min(int(start[axis] + size[axis]), array.shape[axis])
        src.append(slice(lo, hi)); dst.append(slice(lo - int(start[axis]), hi - int(start[axis])))
    output[tuple(dst)] = array[tuple(src)]
    return output


def joint_official_transform(raw_dhw: np.ndarray, target_ndhw: np.ndarray, spacing_xyz: np.ndarray, processor):
    affine = np.diag([*spacing_xyz.tolist(), 1.0])
    image_xyz = np.ascontiguousarray(raw_dhw.transpose(2, 1, 0))
    target_nxyz = np.ascontiguousarray(target_ndhw.transpose(0, 3, 2, 1))
    subject = tio.Subject(
        image=tio.ScalarImage(tensor=torch.from_numpy(image_xyz)[None], affine=affine),
        label=tio.LabelMap(tensor=torch.from_numpy(target_nxyz.astype(np.uint8)), affine=affine),
    )
    transformed = processor._image_transform(subject)
    image = transformed.image.data.float()
    target = transformed.label.data > 0
    if tuple(image.shape[1:]) != tuple(target.shape[1:]):
        raise AssertionError(f"Joint CT/mask shape mismatch: {image.shape} versus {target.shape}")
    if not np.allclose(transformed.image.affine, transformed.label.affine, atol=1e-6):
        raise AssertionError("Joint CT/mask affine mismatch after CoLiPri preprocessing")
    before = target_ndhw.reshape(target_ndhw.shape[0], -1).any(axis=1)
    after = target.reshape(target.shape[0], -1).any(dim=1).cpu().numpy()
    if np.any(before & ~after):
        raise ValueError("positive target vanished under shared 2mm transform")
    hu = image * 1000.0
    voxtell = (hu - hu.mean()) / hu.std().clamp_min(1e-8)
    return image, voxtell, target.float(), transformed.image.affine


def make_sample(sampler, raw_cache: RawCaseCache, processor, attempts=100):
    last_error = None
    for _ in range(attempts):
        sampled_image, qwen, target, weights, meta = sampler.sample()
        try:
            case_id = meta["case"]
            raw, spacing, mean, std, source_affine = raw_cache.load(case_id)
            start, end = parse_bbox(meta["crop_bbox"])
            padding_before = np.maximum(np.asarray((192, 192, 192)) - np.asarray(raw.shape), 0) // 2
            raw_patch = padded_crop(raw, start - padding_before, fill=mean)
            reconstructed = (raw_patch - mean) / std
            max_error = float(np.max(np.abs(reconstructed - sampled_image[0].numpy())))
            if max_error > 0.03:
                raise RuntimeError(f"sampler/raw crop mismatch {max_error:.6f}")
            col_image, vox_image, transformed_target, affine = joint_official_transform(
                raw_patch, target.numpy(), spacing, processor
            )
            return {
                "colipri_image": col_image.numpy().astype(np.float16),
                "voxtell_image": vox_image.numpy().astype(np.float16),
                # Preserve the original VoxTell sampler geometry for later
                # baseline-preserving residual experiments. The older B0 probe
                # intentionally used the CoLiPri-resampled control above.
                "voxtell_native_image": sampled_image.numpy().astype(np.float16),
                "target": transformed_target.numpy().astype(np.uint8),
                "native_target": target.numpy().astype(np.uint8),
                "prompt_weights": weights.numpy().astype(np.float32),
                "qwen_text": qwen[:, 0].numpy().astype(np.float32),
                "prompt_texts": np.asarray(meta["prompt_texts_after_shuffle"], dtype=str),
                "case_id": case_id,
                "crop_bbox": meta["crop_bbox"],
                "processed_affine": affine,
                "source_affine": source_affine,
                "source_spacing_xyz": spacing,
                "raw_crop_start_dhw": start - padding_before,
                "raw_crop_stop_dhw": start - padding_before + np.asarray((192, 192, 192)),
                "sampler_reconstruction_max_abs_error": max_error,
                "meta_json": json.dumps(meta),
            }
        except (ValueError, RuntimeError) as error:
            last_error = error
    raise RuntimeError(f"Unable to construct shared sample: {last_error}")


def save_npz(path: Path, **values) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp.npz")
    np.savez_compressed(temporary, **values)
    temporary.replace(path)


def build_shared_samples(args, processor) -> pd.DataFrame:
    manifest_path = args.output_dir / "shared_crop_manifest.csv"
    if manifest_path.exists():
        return pd.read_csv(manifest_path)
    embeddings = rex_train.load_embedding_map(EMBEDDINGS)
    rows = []
    raw_cache = RawCaseCache()
    for split, count, offset in (("train", args.train_cache_samples, 0), ("val", args.val_cache_samples, 10_000)):
        seed_all(args.seed + offset)
        sampler = build_sampler(
            prepare_records(split), embeddings, sampler_seed=args.seed + offset
        )
        for index in range(count):
            sample = make_sample(sampler, raw_cache, processor)
            sample_id = f"{split}_{index:04d}"
            path = args.output_dir / "shared_samples" / split / f"{sample_id}.npz"
            save_npz(path, **sample)
            meta = json.loads(sample["meta_json"])
            rows.append(
                {
                    "sample_id": sample_id,
                    "split": split,
                    "path": str(path.resolve()),
                    "case_id": sample["case_id"],
                    "crop_bbox": sample["crop_bbox"],
                    "prompt_hash": hashlib.sha256("\n".join(sample["prompt_texts"]).encode()).hexdigest(),
                    "target_voxels": int(sample["target"].sum()),
                    "positive_prompts": int((sample["target"].reshape(3, -1).sum(1) > 0).sum()),
                    "sampler_mode": meta["sampler_mode"],
                    "sampler_reconstruction_max_abs_error": sample["sampler_reconstruction_max_abs_error"],
                    "source_affine_sha256": hashlib.sha256(sample["source_affine"].tobytes()).hexdigest(),
                    "preprocessing_hash": hashlib.sha256(
                        ("RAS|2mm|192^3|clamp[-1000,1000]|range[-1,1]|" + sample["crop_bbox"]).encode()
                    ).hexdigest(),
                }
            )
            print(f"[shared cache] {split} {index + 1}/{count}", flush=True)
    manifest = pd.DataFrame(rows)
    atomic_csv(manifest, manifest_path)
    return manifest


def load_anchor_model(device):
    model = rex_train.instantiate_voxtell(ROOT / "VoxTell/voxtell_v1.1", device, False)
    state = torch.load(ANCHOR_CHECKPOINT, map_location="cpu", weights_only=False)
    model.load_state_dict(state["network_weights"], strict=True)
    return model


def colipri_text(model, tokenizer, prompts: list[str], device) -> torch.Tensor:
    tokens = tokenizer(prompts, max_length=512, padding=True, truncation=True, return_tensors="pt")
    return model.text_encoder(
        tokens["input_ids"].to(device), tokens["attention_mask"].to(device), pool=True, normalize=True
    )


def extract_online(source: str, image: torch.Tensor, image_encoder, device) -> torch.Tensor:
    with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
        if source == "colipri":
            return image_encoder(image.to(device), project=False, pool=False, normalize=False).float()
        skips = image_encoder(image.to(device))
        return skips[3].float()


def build_feature_cache(args, manifest, processor, device):
    from colipri import get_model

    feature_manifest_path = args.output_dir / "feature_cache_manifest.csv"
    if feature_manifest_path.exists():
        return pd.read_csv(feature_manifest_path)
    colipri = get_model(checkpoint_path=COLIPRI_CHECKPOINT).to(device).eval()
    colipri.requires_grad_(False)
    voxtell = load_anchor_model(device).eval()
    voxtell.requires_grad_(False)
    rows = []
    colipri_hash = file_sha256(COLIPRI_CHECKPOINT)
    voxtell_hash = file_sha256(ANCHOR_CHECKPOINT)
    for index, row in enumerate(manifest.itertuples(index=False), start=1):
        with np.load(row.path, allow_pickle=False) as z:
            c_image = torch.from_numpy(z["colipri_image"]).float()[None]
            v_image = torch.from_numpy(z["voxtell_image"]).float()[None]
            prompts = z["prompt_texts"].astype(str).tolist()
            qwen = z["qwen_text"].astype(np.float32)
        with torch.inference_mode():
            c_dense = extract_online("colipri", c_image, colipri.image_encoder, device)[0].cpu().numpy()
            c_text = colipri_text(colipri, processor._text_tokenizer, prompts, device).float().cpu().numpy()
            v_dense = extract_online("voxtell", v_image, voxtell.encoder, device)[0].cpu().numpy()
        path = args.output_dir / "feature_cache" / row.split / f"{row.sample_id}.npz"
        save_npz(
            path,
            colipri_dense=c_dense.astype(np.float32),
            colipri_text=c_text.astype(np.float32),
            voxtell_dense=v_dense.astype(np.float32),
            voxtell_text=qwen,
        )
        rows.append({
            **row._asdict(),
            "feature_path": str(path.resolve()),
            "colipri_shape": str(c_dense.shape),
            "voxtell_shape": str(v_dense.shape),
            "dtype": "float32",
            "colipri_checkpoint_sha256": colipri_hash,
            "voxtell_checkpoint_sha256": voxtell_hash,
            "colipri_feature_layer": "image_encoder(project=False,pool=False)",
            "voxtell_feature_layer": "encoder_skip_3",
        })
        print(f"[feature cache] {index}/{len(manifest)} {row.sample_id}", flush=True)
    del voxtell, colipri
    torch.cuda.empty_cache()
    result = pd.DataFrame(rows)
    atomic_csv(result, feature_manifest_path)
    return result


def reuse_training_feature_cache(args) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Reuse only the immutable patch/feature caches from a validated interrupted run."""
    source = args.reuse_training_cache_from.resolve()
    if source == args.output_dir:
        raise ValueError("Cache source and new output directory must differ")
    shared_path = source / "shared_crop_manifest.csv"
    feature_path = source / "feature_cache_manifest.csv"
    if not shared_path.is_file() or not feature_path.is_file():
        raise FileNotFoundError(
            f"Reusable training manifests are incomplete under {source}"
        )
    shared = pd.read_csv(shared_path)
    features = pd.read_csv(feature_path)
    expected_rows = args.train_cache_samples + args.val_cache_samples
    if len(shared) != expected_rows or len(features) != expected_rows:
        raise RuntimeError(
            f"Reusable cache row count mismatch: shared={len(shared)}, "
            f"features={len(features)}, expected={expected_rows}"
        )
    if not shared.sample_id.equals(features.sample_id):
        raise RuntimeError("Reusable shared/feature manifests have different sample order")
    missing_shared = [path for path in shared.path if not Path(path).is_file()]
    missing_features = [path for path in features.feature_path if not Path(path).is_file()]
    if missing_shared or missing_features:
        raise FileNotFoundError(
            f"Reusable cache files missing: shared={len(missing_shared)}, "
            f"features={len(missing_features)}"
        )
    expected_colipri = file_sha256(COLIPRI_CHECKPOINT)
    expected_voxtell = file_sha256(ANCHOR_CHECKPOINT)
    if set(features.colipri_checkpoint_sha256) != {expected_colipri}:
        raise RuntimeError("Reusable CoLiPri feature checkpoint hash mismatch")
    if set(features.voxtell_checkpoint_sha256) != {expected_voxtell}:
        raise RuntimeError("Reusable VoxTell feature checkpoint hash mismatch")
    atomic_csv(shared, args.output_dir / "shared_crop_manifest.csv")
    atomic_csv(features, args.output_dir / "feature_cache_manifest.csv")
    atomic_json(
        {
            "source": str(source),
            "shared_rows": len(shared),
            "feature_rows": len(features),
            "colipri_checkpoint_sha256": expected_colipri,
            "voxtell_checkpoint_sha256": expected_voxtell,
            "validated_all_files_exist": True,
            "reused_fixed30_cache": False,
        },
        args.output_dir / "training_cache_reuse_audit.json",
    )
    print(f"[cache reuse] validated {len(features)} training/validation feature rows from {source}", flush=True)
    return shared, features


def sliding_window_starts(shape: tuple[int, int, int], patch_size: int = 192) -> np.ndarray:
    """Cover a full resampled volume with deterministic 50%-overlap windows."""
    axes = []
    stride = patch_size // 2
    for dimension in shape:
        if dimension < patch_size:
            raise ValueError(f"Volume dimension {dimension} is smaller than patch {patch_size}")
        maximum = dimension - patch_size
        starts = list(range(0, maximum + 1, stride))
        if starts[-1] != maximum:
            starts.append(maximum)
        axes.append(starts)
    return np.asarray(list(itertools.product(*axes)), dtype=np.int16)


def full_volume_colipri_preprocess(subject: tio.Subject, processor):
    """Apply official CoLiPri transforms except the destructive center CropOrPad."""
    transforms = list(processor._image_transform.transforms)
    if not transforms or not isinstance(transforms[-1], tio.CropOrPad):
        raise RuntimeError("Expected official CoLiPri CropOrPad as the final image transform")
    transformed = tio.Compose(transforms[:-1])(subject)
    target_shape = tuple(max(192, int(value)) for value in transformed.image.spatial_shape)
    if target_shape != tuple(transformed.image.spatial_shape):
        transformed = tio.CropOrPad(target_shape, padding_mode="minimum")(transformed)
    if tuple(transformed.image.shape[1:]) != tuple(transformed.label.shape[1:]):
        raise AssertionError("Full-volume CT/mask shape mismatch after joint preprocessing")
    if not np.allclose(transformed.image.affine, transformed.label.affine, atol=1e-6):
        raise AssertionError("Full-volume CT/mask affine mismatch after joint preprocessing")
    return transformed


def build_fixed30_cache(args, processor, device):
    from colipri import get_model

    manifest_path = args.output_dir / "fixed30_cache_manifest.csv"
    if manifest_path.exists():
        return pd.read_csv(manifest_path)
    data = json.loads(FIXED30.read_text())["val"]
    embedding_map = rex_train.load_embedding_map(EMBEDDINGS)
    all_prompts = [(entry["name"], int(key), text) for entry in data for key, text in sorted(entry["findings"].items(), key=lambda item: int(item[0]))]
    shuffled = {}
    for index, (case, finding, prompt) in enumerate(all_prompts):
        alternatives = [item for item in all_prompts if item[0] != case and item[2].lower() != prompt.lower()]
        shuffled[(case, finding)] = alternatives[index % len(alternatives)][2]
    colipri = get_model(checkpoint_path=COLIPRI_CHECKPOINT).to(device).eval(); colipri.requires_grad_(False)
    voxtell = load_anchor_model(device).eval(); voxtell.requires_grad_(False)
    rows = []
    for case_index, entry in enumerate(data, start=1):
        case = entry["name"]
        keys = [int(key) for key in sorted(entry["findings"], key=int)]
        prompts = [entry["findings"][str(key)] for key in keys]
        shuffled_prompts = [shuffled[(case, key)] for key in keys]
        original_image = tio.ScalarImage(ROOT / "data/ct_rate_volumes_fixed" / case)
        mask4 = np.asanyarray(nib.load(str(ROOT / "data/segmentations" / case)).dataobj)
        selected_gt = np.stack([mask4[key] > 0 for key in keys]).astype(np.uint8)
        subject = tio.Subject(
            image=original_image,
            label=tio.LabelMap(tensor=torch.from_numpy(selected_gt), affine=original_image.affine),
        )
        transformed = full_volume_colipri_preprocess(subject, processor)
        c_full = transformed.image.data.float()
        target = transformed.label.data > 0
        before = selected_gt.reshape(len(keys), -1).any(1)
        after = target.reshape(len(keys), -1).any(1).cpu().numpy()
        lost_after_resampling = np.flatnonzero(before & ~after)
        if len(lost_after_resampling):
            # Full-volume metrics are computed after mapping predictions back to the
            # original ReX geometry. Keep this as QC rather than replacing the mask
            # with an artificial voxel in 2-mm space.
            print(
                f"[fixed30 QC] {case}: {len(lost_after_resampling)} tiny finding(s) "
                "vanished under nearest-neighbor 2-mm mask resampling; original GT retained for evaluation",
                flush=True,
            )
        starts = sliding_window_starts(tuple(map(int, c_full.shape[1:])))
        c_images, v_images, c_dense_windows, v_dense_windows = [], [], [], []
        for start in starts:
            slices = tuple(slice(int(value), int(value) + 192) for value in start)
            c_image = c_full[(slice(None), *slices)].contiguous()
            hu = c_image * 1000.0
            v_image = (hu - hu.mean()) / hu.std().clamp_min(1e-8)
            with torch.inference_mode():
                c_dense_windows.append(
                    extract_online("colipri", c_image[None], colipri.image_encoder, device)[0].cpu().numpy()
                )
                v_dense_windows.append(
                    extract_online("voxtell", v_image[None], voxtell.encoder, device)[0].cpu().numpy()
                )
            c_images.append(c_image.numpy().astype(np.float16))
            v_images.append(v_image.numpy().astype(np.float16))
        with torch.inference_mode():
            c_correct = colipri_text(colipri, processor._text_tokenizer, prompts, device).float().cpu().numpy()
            c_shuffled = colipri_text(colipri, processor._text_tokenizer, shuffled_prompts, device).float().cpu().numpy()
        q_correct = torch.stack([embedding_map[("val", case, key)] for key in keys]).numpy().astype(np.float32)
        # Qwen shuffled controls use the cached source prompt embeddings.
        prompt_to_qwen = {text: embedding_map[("val", source_case, source_key)] for source_case, source_key, text in all_prompts}
        q_shuffled = torch.stack([prompt_to_qwen[text] for text in shuffled_prompts]).numpy().astype(np.float32)
        path = args.output_dir / "fixed30_cache" / f"case_{case_index:03d}.npz"
        save_npz(
            path,
            colipri_image=np.stack(c_images),
            voxtell_image=np.stack(v_images),
            target=target.numpy().astype(np.uint8),
            window_starts=starts,
            processed_shape=np.asarray(c_full.shape[1:]),
            colipri_dense=np.stack(c_dense_windows).astype(np.float32),
            colipri_text_correct=c_correct,
            colipri_text_shuffled=c_shuffled,
            voxtell_dense=np.stack(v_dense_windows).astype(np.float32),
            voxtell_text_correct=q_correct,
            voxtell_text_shuffled=q_shuffled,
            original_gt=selected_gt,
            original_shape=np.asarray(original_image.shape[1:]),
            original_affine=original_image.affine,
            processed_affine=transformed.image.affine,
            finding_indices=np.asarray(keys),
            prompts=np.asarray(prompts),
            categories=np.asarray([entry.get("categories", {}).get(str(key), "unknown") for key in keys]),
            entity_counts=np.asarray([entry.get("entity_counts", {}).get(str(key), 1) for key in keys]),
            target_retained_after_resampling=after.astype(np.uint8),
        )
        rows.append(
            {
                "case_id": case,
                "path": str(path.resolve()),
                "findings": len(keys),
                "windows": len(starts),
                "findings_lost_after_2mm_resampling": int(len(lost_after_resampling)),
            }
        )
        print(f"[fixed30 cache] {case_index}/30 {case} windows={len(starts)}", flush=True)
    del colipri, voxtell
    torch.cuda.empty_cache()
    result = pd.DataFrame(rows)
    atomic_csv(result, manifest_path)
    return result


def reuse_fixed30_cache(args) -> pd.DataFrame:
    """Validate and reuse a complete full-volume cache without copying its large arrays."""
    source = args.reuse_fixed30_cache_from.resolve()
    manifest_path = source / "fixed30_cache_manifest.csv"
    if not manifest_path.is_file():
        raise FileNotFoundError(manifest_path)
    manifest = pd.read_csv(manifest_path)
    if len(manifest) != 30 or int(manifest.findings.sum()) != 49:
        raise RuntimeError(
            f"fixed30 cache cohort mismatch: cases={len(manifest)}, findings={manifest.findings.sum()}"
        )
    required = {
        "colipri_image", "voxtell_image", "target", "window_starts", "processed_shape",
        "colipri_dense", "colipri_text_correct", "colipri_text_shuffled",
        "voxtell_dense", "voxtell_text_correct", "voxtell_text_shuffled",
        "original_gt", "original_shape", "original_affine", "processed_affine",
        "finding_indices", "prompts", "categories", "entity_counts",
        "target_retained_after_resampling",
    }
    validated_windows = 0
    for row in manifest.itertuples(index=False):
        path = Path(row.path)
        if not path.is_file():
            raise FileNotFoundError(path)
        with np.load(path, allow_pickle=False) as archive:
            missing = required.difference(archive.files)
            if missing:
                raise RuntimeError(f"fixed30 cache {path} is missing {sorted(missing)}")
            starts = archive["window_starts"].astype(int)
            shape = tuple(archive["processed_shape"].astype(int))
            if len(starts) != int(row.windows):
                raise RuntimeError(f"fixed30 window count mismatch for {row.case_id}")
            coverage = np.zeros(shape, dtype=bool)
            for start in starts:
                slices = tuple(slice(int(value), int(value) + 192) for value in start)
                coverage[slices] = True
            if not coverage.all():
                raise RuntimeError(f"fixed30 sliding windows do not cover {row.case_id}")
            if archive["original_gt"].shape[0] != int(row.findings):
                raise RuntimeError(f"fixed30 finding count mismatch for {row.case_id}")
            if not archive["original_gt"].reshape(int(row.findings), -1).any(1).all():
                raise RuntimeError(f"fixed30 original GT unexpectedly empty for {row.case_id}")
            validated_windows += len(starts)
    atomic_csv(manifest, args.output_dir / "fixed30_cache_manifest.csv")
    atomic_json(
        {
            "source": str(source),
            "cases": len(manifest),
            "findings": int(manifest.findings.sum()),
            "windows": validated_windows,
            "all_windows_cover_processed_volume": True,
            "all_original_gt_nonempty": True,
        },
        args.output_dir / "fixed30_cache_reuse_audit.json",
    )
    print(
        f"[fixed30 cache reuse] validated 30 cases, 49 findings, {validated_windows} windows from {source}",
        flush=True,
    )
    return manifest


BRANCHES_B0 = {
    "B0-Correct": ("colipri", "correct", False),
    "B0-Shuffled": ("colipri", "shuffled", False),
    "B0-ImageOnly": ("colipri", "correct", True),
    "B0-VoxTellControl": ("voxtell", "correct", False),
}


def load_cached_row(row, source, text_mode, device):
    with np.load(row.feature_path, allow_pickle=False) as feature, np.load(row.path, allow_pickle=False) as shared:
        dense = torch.from_numpy(feature[f"{source}_dense"]).float()[None].to(device)
        text = torch.from_numpy(feature[f"{source}_text"]).float()[None].to(device)
        target = torch.from_numpy(shared["target"]).float()[None].to(device)
    return dense, text, target


def shuffled_text_for_index(frame, index, source, device):
    current = frame.iloc[index]
    for offset in range(1, len(frame)):
        candidate = frame.iloc[(index + offset) % len(frame)]
        if candidate.case_id != current.case_id:
            with np.load(candidate.feature_path, allow_pickle=False) as z:
                return torch.from_numpy(z[f"{source}_text"]).float()[None].to(device)
    raise RuntimeError("No cross-case shuffled text")


def patch_metrics(logits, target):
    values = binary_dice(logits.detach(), target)
    positive = target.flatten(start_dim=2).any(2)
    prediction = logits.detach().sigmoid() >= 0.5
    return {
        "patch_dice": float(values.mean()),
        "patch_positive_dice": float(values[positive].mean()) if positive.any() else float("nan"),
        "predicted_voxels": int(prediction.sum()),
        "empty_predictions": int((~prediction.flatten(start_dim=2).any(2)).sum()),
    }


@torch.no_grad()
def patch_validate(probe, frame, source, text_mode, device):
    probe.eval(); rows = []
    for index, row in frame.reset_index(drop=True).iterrows():
        dense, text, target = load_cached_row(row, source, text_mode, device)
        if text_mode == "shuffled":
            text = shuffled_text_for_index(frame.reset_index(drop=True), index, source, device)
        logits = probe(dense, text)
        loss, terms = dice_bce_loss(logits, target)
        rows.append({"loss": float(loss), **terms, **patch_metrics(logits, target)})
    probe.train()
    return {key: float(np.mean([row[key] for row in rows])) for key in rows[0]}


def save_probe(path, probe, branch, update, source, text_mode, image_only, extra):
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "format": "colipri_matched_spatial_probe.v1",
            "branch": branch,
            "update": update,
            "source": source,
            "text_mode": text_mode,
            "image_only": image_only,
            "probe_state": {key: value.detach().cpu() for key, value in probe.state_dict().items()},
            "probe_config": {
                "image_channels": 864 if source == "colipri" else 256,
                "text_dim": 768 if source == "colipri" else 2560,
                "common_dim": 128,
                "image_only": image_only,
                "spatial_size": 24,
            },
            "extra": extra,
        },
        path,
    )


def instantiate_probe(source, image_only, seed):
    torch.manual_seed(seed)
    return MatchedPromptSpatialProbe(
        864 if source == "colipri" else 256,
        768 if source == "colipri" else 2560,
        common_dim=128,
        image_only=image_only,
    )


def equivalence_audit(args, feature_manifest, processor, device):
    from colipri import get_model

    sample = feature_manifest[feature_manifest.split.eq("train")].head(20).reset_index(drop=True)
    colipri = get_model(checkpoint_path=COLIPRI_CHECKPOINT).to(device).eval(); colipri.requires_grad_(False)
    feature_errors, cosines = [], []
    online_features = []
    for row in sample.itertuples(index=False):
        with np.load(row.path, allow_pickle=False) as shared, np.load(row.feature_path, allow_pickle=False) as cached:
            image = torch.from_numpy(shared["colipri_image"]).float()[None]
            cached_feature = torch.from_numpy(cached["colipri_dense"]).float()[None].to(device)
        with torch.inference_mode():
            online_inference = extract_online("colipri", image, colipri.image_encoder, device)
        # A tensor created under inference_mode cannot be saved by autograd even
        # when it is a frozen input. Clone outside the context to make it a normal
        # leaf tensor for the probe-gradient equivalence check.
        online = online_inference.clone().contiguous()
        feature_errors.append(float((online - cached_feature).abs().max()))
        cosines.append(float(F.cosine_similarity(online.flatten(), cached_feature.flatten(), dim=0)))
        online_features.append(online.detach())
    row = sample.iloc[0]
    dense, text, target = load_cached_row(row, "colipri", "correct", device)
    first = instantiate_probe("colipri", False, args.seed).to(device)
    second = copy.deepcopy(first)
    online_logits = first(online_features[0], text)
    cached_logits = second(dense, text)
    online_loss, _ = dice_bce_loss(online_logits, target)
    cached_loss, _ = dice_bce_loss(cached_logits, target)
    online_loss.backward(); cached_loss.backward()
    grad_a = torch.cat([p.grad.flatten() for p in first.parameters() if p.grad is not None])
    grad_b = torch.cat([p.grad.flatten() for p in second.parameters() if p.grad is not None])
    gradient_cosine = float(F.cosine_similarity(grad_a, grad_b, dim=0))
    # Same seed, batches, features, and optimizer for 20 updates.
    online_probe = instantiate_probe("colipri", False, args.seed + 1).to(device)
    cached_probe = copy.deepcopy(online_probe)
    optim_a = torch.optim.AdamW(online_probe.parameters(), lr=1e-4)
    optim_b = torch.optim.AdamW(cached_probe.parameters(), lr=1e-4)
    for step in range(20):
        item = sample.iloc[step % len(sample)]
        dense, text, target = load_cached_row(item, "colipri", "correct", device)
        for probe, optimizer, feature in (
            (online_probe, optim_a, online_features[step % len(online_features)]),
            (cached_probe, optim_b, dense),
        ):
            optimizer.zero_grad(set_to_none=True)
            loss, _ = dice_bce_loss(probe(feature, text), target)
            loss.backward(); optimizer.step()
    parameter_error = max(
        float((a.detach() - b.detach()).abs().max())
        for a, b in zip(online_probe.parameters(), cached_probe.parameters())
    )
    dense, text, target = load_cached_row(sample.iloc[0], "colipri", "correct", device)
    with torch.no_grad():
        post_online_logits = online_probe(online_features[0], text)
        post_cached_logits = cached_probe(dense, text)
        post_online_loss, _ = dice_bce_loss(post_online_logits, target)
        post_cached_loss, _ = dice_bce_loss(post_cached_logits, target)
    post_logit_error = float((post_online_logits - post_cached_logits).abs().max())
    post_loss_relative_difference = float(
        (post_online_loss - post_cached_loss).abs() / post_cached_loss.abs().clamp_min(1e-12)
    )
    report = {
        "batches": len(sample),
        "feature_max_abs_error": max(feature_errors),
        "feature_cosine_min": min(cosines),
        "logit_max_abs_error": float((online_logits - cached_logits).abs().max()),
        "loss_relative_difference": float(abs(online_loss - cached_loss) / cached_loss.abs().clamp_min(1e-12)),
        "decoder_gradient_cosine": gradient_cosine,
        "twenty_update_parameter_max_abs_error": parameter_error,
        "twenty_update_logit_max_abs_error": post_logit_error,
        "twenty_update_loss_relative_difference": post_loss_relative_difference,
    }
    report["passed"] = bool(
        report["feature_cosine_min"] > 0.99999
        and report["logit_max_abs_error"] < 1e-3
        and report["loss_relative_difference"] < 1e-4
        and report["decoder_gradient_cosine"] > 0.999
        and post_logit_error < 1e-3
        and post_loss_relative_difference < 1e-4
    )
    atomic_json(report, args.output_dir / "online_cache_equivalence.json")
    del colipri
    torch.cuda.empty_cache()
    if not report["passed"]:
        raise RuntimeError(f"Online/cache equivalence failed: {report}")
    return report


def train_b0_branch(args, branch, source, text_mode, image_only, feature_manifest, device):
    train = feature_manifest[feature_manifest.split.eq("train")].reset_index(drop=True)
    val = feature_manifest[feature_manifest.split.eq("val")].reset_index(drop=True)
    probe = instantiate_probe(source, image_only, args.seed).to(device)
    optimizer = torch.optim.AdamW(probe.parameters(), lr=1e-4, weight_decay=1e-4)
    output = args.output_dir / "branches" / branch
    history, validation = [], []
    initial = patch_validate(probe, val, source, text_mode, device)
    validation.append({"update": 0, **initial})
    save_probe(output / "checkpoints/checkpoint_update_0.pth", probe, branch, 0, source, text_mode, image_only, initial)
    if args.smoke_only:
        updates = 20
    else:
        updates = args.updates
    started = time.perf_counter(); step_times = []
    for update in range(1, updates + 1):
        tick = time.perf_counter(); optimizer.zero_grad(set_to_none=True); micro_rows = []
        for micro in range(args.grad_accum):
            index = ((update - 1) * args.grad_accum + micro) % len(train)
            row = train.iloc[index]
            dense, text, target = load_cached_row(row, source, text_mode, device)
            if text_mode == "shuffled":
                text = shuffled_text_for_index(train, index, source, device)
            logits = probe(dense, text)
            loss, terms = dice_bce_loss(logits, target)
            (loss / args.grad_accum).backward()
            micro_rows.append({"loss": float(loss.detach()), **terms, **patch_metrics(logits, target)})
        grad_norm = float(torch.nn.utils.clip_grad_norm_(probe.parameters(), 12.0))
        optimizer.step(); torch.cuda.synchronize(device); step_times.append(time.perf_counter() - tick)
        record = {"update": update, "grad_norm": grad_norm, **{key: float(np.mean([row[key] for row in micro_rows])) for key in micro_rows[0]}}
        history.append(record)
        if update in set(UPDATES[1:]) or update == updates:
            result = patch_validate(probe, val, source, text_mode, device)
            validation.append({"update": update, **result})
            save_probe(output / f"checkpoints/checkpoint_update_{update}.pth", probe, branch, update, source, text_mode, image_only, result)
            print(json.dumps({"branch": branch, **record, **{f"val_{key}": value for key, value in result.items()}}), flush=True)
    atomic_csv(pd.DataFrame(history), output / "training_trajectory.csv")
    atomic_csv(pd.DataFrame(validation), output / "patch_validation.csv")
    report = {
        "branch": branch,
        "source": source,
        "text_mode": text_mode,
        "image_only": image_only,
        "updates": updates,
        "probe_parameters": probe.parameter_counts(),
        "mean_seconds_per_update": float(np.mean(step_times)),
        "runtime_seconds": time.perf_counter() - started,
        "peak_gpu_memory_gib": torch.cuda.max_memory_allocated(device) / 2**30,
    }
    atomic_json(report, output / "run_report.json")
    return report


def load_probe_checkpoint(path: Path, device):
    payload = torch.load(path, map_location="cpu", weights_only=False)
    probe = MatchedPromptSpatialProbe(**payload["probe_config"]).to(device)
    probe.load_state_dict(payload["probe_state"], strict=True)
    return probe, payload


def restore_prediction(prediction_xyz: np.ndarray, processed_affine, original_shape, original_affine):
    source = nib.Nifti1Image(prediction_xyz.astype(np.uint8), processed_affine)
    return np.asanyarray(resample_from_to(source, (tuple(original_shape), original_affine), order=0).dataobj) > 0


@torch.no_grad()
def aggregate_cached_probabilities(probe, archive, source, text_mode, device) -> np.ndarray:
    text = torch.from_numpy(archive[f"{source}_text_{text_mode}"]).float()[None].to(device)
    shape = tuple(archive["processed_shape"].astype(int))
    prompts = int(text.shape[1])
    probability_sum = np.zeros((prompts, *shape), dtype=np.float32)
    count = np.zeros(shape, dtype=np.uint16)
    dense_windows = archive[f"{source}_dense"]
    for window, start in zip(dense_windows, archive["window_starts"].astype(int)):
        dense = torch.from_numpy(window).float()[None].to(device)
        probability = probe(dense, text).sigmoid()[0].float().cpu().numpy()
        slices = tuple(slice(int(value), int(value) + 192) for value in start)
        probability_sum[(slice(None), *slices)] += probability
        count[slices] += 1
    if np.any(count == 0):
        raise AssertionError("Sliding-window aggregation left uncovered voxels")
    return probability_sum / count[None]


@torch.no_grad()
def fixed30_evaluate_cached(probe, cache_manifest, source, text_mode, branch, update, device, output_csv):
    probe.eval(); rows = []
    for case_row in cache_manifest.itertuples(index=False):
        with np.load(case_row.path, allow_pickle=False) as z:
            probability = aggregate_cached_probabilities(probe, z, source, text_mode, device)
            for channel, finding_idx in enumerate(z["finding_indices"].astype(int)):
                pred = restore_prediction(
                    probability[channel] >= 0.5,
                    z["processed_affine"], z["original_shape"], z["original_affine"],
                )
                gt = z["original_gt"][channel].astype(bool)
                tp = int((pred & gt).sum()); fp = int((pred & ~gt).sum()); fn = int((~pred & gt).sum())
                rows.append(
                    {
                        "case": case_row.case_id,
                        "finding_idx": finding_idx,
                        "category": str(z["categories"][channel]),
                        "focality": "focal" if str(z["categories"][channel]).startswith("2") else "diffuse",
                        "case_finding_count": int(case_row.findings),
                        "same_case_same_entity": int(z["entity_counts"][channel]) > 1,
                        "prompt": str(z["prompts"][channel]),
                        "branch": branch,
                        "update": update,
                        "text_mode_at_inference": text_mode,
                        "dice": 2 * tp / max(2 * tp + fp + fn, 1),
                        "hit": int(tp > 0),
                        "tp_voxels": tp,
                        "fp_voxels": fp,
                        "fn_voxels": fn,
                        "pred_voxels": int(pred.sum()),
                        "gt_voxels": int(gt.sum()),
                        "empty_prediction": int(not pred.any()),
                    }
                )
    frame = pd.DataFrame(rows)
    atomic_csv(frame, output_csv)
    return frame


def bootstrap_vs_baseline(frame, baseline, reps):
    joined = frame.merge(baseline[["case", "finding_idx", "dice"]], on=["case", "finding_idx"], suffixes=("", "_baseline"), validate="one_to_one")
    per_case = joined.assign(delta=joined.dice - joined.dice_baseline).groupby("case").delta.mean().to_numpy()
    rng = np.random.default_rng(SEED)
    draws = rng.choice(per_case, (reps, len(per_case)), replace=True).mean(1)
    return {"estimate": float(per_case.mean()), "ci95_low": float(np.quantile(draws, .025)), "ci95_high": float(np.quantile(draws, .975))}


def baseline_fixed30():
    frame = pd.read_csv(BASELINE_FIXED30)
    return frame[(frame.variant.eq("original")) & np.isclose(frame.threshold, .5)].copy()


def summarize_full(frame, baseline):
    joined = frame.merge(baseline[["case", "finding_idx", "global_hit"]], on=["case", "finding_idx"], validate="one_to_one")
    return {
        "mean_dice": float(frame.dice.mean()),
        "median_dice": float(frame.dice.median()),
        "hits": int(frame.hit.sum()),
        "hit_rate": float(frame.hit.mean()),
        "mean_fp_voxels": float(frame.fp_voxels.mean()),
        "mean_predicted_voxels": float(frame.pred_voxels.mean()),
        "median_predicted_voxels": float(frame.pred_voxels.median()),
        "empty_predictions": int(frame.empty_prediction.sum()),
        "new_hits": int(((joined.hit == 1) & (~joined.global_hit.astype(bool))).sum()),
        "lost_hits": int(((joined.hit == 0) & joined.global_hit.astype(bool)).sum()),
    }


def fixed30_subgroups(frame: pd.DataFrame, branch: str, update: int) -> pd.DataFrame:
    size = pd.cut(
        frame.gt_voxels,
        bins=[-1, 100, 1_000, 10_000, np.inf],
        labels=["tiny", "small", "medium", "large"],
    )
    groups = {
        "single_finding": frame.case_finding_count.eq(1),
        "multi_finding": frame.case_finding_count.gt(1),
        "same_case_same_entity": frame.same_case_same_entity.astype(bool),
        "focal": frame.focality.eq("focal"),
        "diffuse": frame.focality.eq("diffuse"),
        "size_tiny": size.eq("tiny"),
        "size_small": size.eq("small"),
        "size_medium": size.eq("medium"),
        "size_large": size.eq("large"),
    }
    rows = []
    for name, mask in groups.items():
        block = frame.loc[mask]
        if len(block):
            rows.append(
                {
                    "branch": branch,
                    "update": update,
                    "subgroup": name,
                    "findings": len(block),
                    "mean_dice": float(block.dice.mean()),
                    "hit_rate": float(block.hit.mean()),
                    "mean_fp_voxels": float(block.fp_voxels.mean()),
                }
            )
    return pd.DataFrame(rows)


@torch.no_grad()
def fixed30_text_sensitivity_cached(probe, cache_manifest, source, branch, update, device):
    """Compare correct and shuffled text on exactly the same cached image features."""
    probe.eval(); rows = []
    for case_row in cache_manifest.itertuples(index=False):
        with np.load(case_row.path, allow_pickle=False) as z:
            probability_correct = aggregate_cached_probabilities(
                probe, z, source, "correct", device
            )
            probability_shuffled = aggregate_cached_probabilities(
                probe, z, source, "shuffled", device
            )
            for channel, finding_idx in enumerate(z["finding_indices"].astype(int)):
                binary_correct = restore_prediction(
                    probability_correct[channel] >= 0.5,
                    z["processed_affine"], z["original_shape"], z["original_affine"],
                )
                binary_shuffled = restore_prediction(
                    probability_shuffled[channel] >= 0.5,
                    z["processed_affine"], z["original_shape"], z["original_affine"],
                )
                truth = z["original_gt"][channel].astype(bool)
                overlap = int((binary_correct & binary_shuffled).sum())
                denominator = int(binary_correct.sum() + binary_shuffled.sum())
                mask_dice = 2 * overlap / denominator if denominator else 1.0
                correct_denominator = int(binary_correct.sum() + truth.sum())
                shuffled_denominator = int(binary_shuffled.sum() + truth.sum())
                target_dice_correct = 2 * int((binary_correct & truth).sum()) / max(correct_denominator, 1)
                target_dice_shuffled = 2 * int((binary_shuffled & truth).sum()) / max(shuffled_denominator, 1)
                rows.append(
                    {
                        "case": case_row.case_id,
                        "finding_idx": finding_idx,
                        "category": str(z["categories"][channel]),
                        "branch": branch,
                        "update": update,
                        "correct_vs_shuffled_mask_dice": mask_dice,
                        "mean_absolute_probability_difference": float(np.abs(probability_correct[channel] - probability_shuffled[channel]).mean()),
                        "foreground_volume_difference_voxels": int(binary_correct.sum() - binary_shuffled.sum()),
                        "correct_minus_shuffled_target_dice": target_dice_correct - target_dice_shuffled,
                    }
                )
    return pd.DataFrame(rows)


def evaluate_all_b0(args, fixed_manifest, device):
    baseline = baseline_fixed30(); rows = []; diagnostics = []; subgroup_frames = []; sensitivity_frames = []
    updates = (0, 20) if args.smoke_only else UPDATES
    for branch, (source, trained_text_mode, image_only) in BRANCHES_B0.items():
        for update in updates:
            checkpoint = args.output_dir / "branches" / branch / f"checkpoints/checkpoint_update_{update}.pth"
            if not checkpoint.exists():
                continue
            probe, _ = load_probe_checkpoint(checkpoint, device)
            inference_modes = [trained_text_mode]
            if update == updates[-1] and not image_only:
                inference_modes = ["correct", "shuffled"]
            for mode in inference_modes:
                path = args.output_dir / "full_volume" / branch / f"update_{update}_{mode}.csv"
                frame = fixed30_evaluate_cached(probe, fixed_manifest, source, mode, branch, update, device, path)
                summary = {"branch": branch, "update": update, "inference_text_mode": mode, **summarize_full(frame, baseline), **bootstrap_vs_baseline(frame, baseline, args.bootstrap_reps)}
                rows.append(summary)
                subgroup_frames.append(fixed30_subgroups(frame, branch, update).assign(inference_text_mode=mode))
                if update == updates[-1] and mode in {"correct", "shuffled"}:
                    diagnostics.append(frame[["case", "finding_idx", "dice", "pred_voxels"]].rename(columns={"dice": f"dice_{mode}", "pred_voxels": f"pred_voxels_{mode}"}).assign(branch=branch))
            if update == updates[-1] and not image_only:
                sensitivity = fixed30_text_sensitivity_cached(
                    probe, fixed_manifest, source, branch, update, device
                )
                sensitivity_frames.append(sensitivity)
                atomic_csv(
                    sensitivity,
                    args.output_dir / "text_sensitivity" / f"{branch}_update_{update}.csv",
                )
    summary = pd.DataFrame(rows)
    atomic_csv(summary, args.output_dir / "full_volume_summary.csv")
    diagnostic_rows = []
    for branch in summary.branch.unique():
        pieces = [frame for frame in diagnostics if frame.branch.iloc[0] == branch]
        if len(pieces) == 2:
            merged = pieces[0].merge(pieces[1], on=["case", "finding_idx", "branch"])
            correct_col = "dice_correct"; shuffled_col = "dice_shuffled"
            diagnostic_rows.append({"branch": branch, "correct_minus_shuffled_dice": float((merged[correct_col] - merged[shuffled_col]).mean()), "mean_absolute_volume_difference": float((merged.pred_voxels_correct - merged.pred_voxels_shuffled).abs().mean())})
    atomic_csv(pd.DataFrame(diagnostic_rows), args.output_dir / "text_sensitivity.csv")
    subgroup_summary = pd.concat(subgroup_frames, ignore_index=True)
    atomic_csv(subgroup_summary, args.output_dir / "subgroup_summary.csv")
    if sensitivity_frames:
        atomic_csv(
            pd.concat(sensitivity_frames, ignore_index=True),
            args.output_dir / "text_sensitivity_per_finding.csv",
        )
    return finalize_b0_outputs(
        args,
        summary=summary,
        diagnostic_summary=pd.DataFrame(diagnostic_rows),
        subgroup_summary=subgroup_summary,
    )


def finalize_b0_outputs(
    args,
    summary: pd.DataFrame | None = None,
    diagnostic_summary: pd.DataFrame | None = None,
    subgroup_summary: pd.DataFrame | None = None,
):
    """Create the B0 verdict/report from completed full-volume CSV artifacts."""
    if summary is None:
        summary = pd.read_csv(args.output_dir / "full_volume_summary.csv")
    if diagnostic_summary is None:
        diagnostic_summary = pd.read_csv(args.output_dir / "text_sensitivity.csv")
    if subgroup_summary is None:
        subgroup_summary = pd.read_csv(args.output_dir / "subgroup_summary.csv")
    final_update = int(summary["update"].max())
    expected_text_mode = summary["branch"].map(lambda name: BRANCHES_B0[name][1])
    final = summary[
        summary["update"].eq(final_update)
        & summary["inference_text_mode"].eq(expected_text_mode)
    ]
    values = final.set_index("branch")
    correct = values.loc["B0-Correct", "mean_dice"]
    shuffled = values.loc["B0-Shuffled", "mean_dice"]
    image_only = values.loc["B0-ImageOnly", "mean_dice"]
    if correct > max(shuffled, image_only) and correct - shuffled > .002:
        verdict = "GO"
    elif correct <= shuffled and correct <= image_only:
        verdict = "NO-GO"
    else:
        verdict = "INCONCLUSIVE"
    report_path = ROOT / "reports/colipri_experiment_B0_frozen_probe.md"
    report_path.write_text(
        "\n".join([
            "# CoLiPri Experiment B0: Frozen Representation Probe", "", f"**Verdict: {verdict}.**", "",
            "All branches use the same anchor85-selected physical crops, shared masks, fixed order, update budget, and matched lightweight decoder.", "",
            "## Full-volume fixed30", "", markdown_table(summary), "", "## Text sensitivity", "", markdown_table(diagnostic_summary), "",
            "## Subgroups", "", markdown_table(subgroup_summary), "",
            "Patch validation and the 20-batch online/cache audit are retained in the output directory. The decision is based on fixed30 segmentation, not patch Dice.",
        ]) + "\n"
    )
    result = {"verdict": verdict, "correct_text_dice": float(correct), "shuffled_text_dice": float(shuffled), "image_only_dice": float(image_only), "voxtell_control_dice": float(values.loc["B0-VoxTellControl", "mean_dice"]), "report": str(report_path)}
    atomic_json(result, args.output_dir / "result.json")
    return result


def run_b0(args):
    from colipri import get_processor

    if args.updates != 400 and not args.smoke_only:
        raise ValueError("Formal B0 is predeclared for exactly 400 updates")
    if not torch.cuda.is_available():
        raise RuntimeError("B0 requires one GPU")
    device = torch.device(args.device); torch.cuda.set_device(device); seed_all(args.seed)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    processor = get_processor()
    if args.reuse_training_cache_from is not None:
        manifest, features = reuse_training_feature_cache(args)
    else:
        manifest = build_shared_samples(args, processor)
        features = build_feature_cache(args, manifest, processor, device)
    if args.reuse_fixed30_cache_from is not None:
        fixed = reuse_fixed30_cache(args)
    else:
        fixed = build_fixed30_cache(args, processor, device)
    audit = equivalence_audit(args, features, processor, device)
    for branch, config in BRANCHES_B0.items():
        train_b0_branch(args, branch, *config, features, device)
    result = evaluate_all_b0(args, fixed, device)
    provenance = {
        "experiment": "B0 frozen matched spatial representation probe",
        "seed": args.seed,
        "sampler": "canonical anchor85_hardneg70, 2 positive + 1 negative, no dynamic spatial augmentation after cache",
        "shared_geometry": (
            "training uses the same source crop and target transformed jointly to RAS, 2mm, 192^3; "
            "fixed30 uses full RAS/2mm volumes tiled by deterministic 192^3 windows with 50% overlap"
        ),
        "colipri_checkpoint_sha256": file_sha256(COLIPRI_CHECKPOINT),
        "voxtell_checkpoint_sha256": file_sha256(ANCHOR_CHECKPOINT),
        "gpu": torch.cuda.get_device_name(device),
        "host": socket.gethostname(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID", ""),
        "equivalence": audit,
    }
    atomic_json(provenance, args.output_dir / "provenance.json")
    print(json.dumps(result, indent=2), flush=True)


BRANCHES_B1 = {
    "B1-Correct": ("colipri", "correct", "B0-Correct"),
    "B1-Shuffled": ("colipri", "shuffled", "B0-Shuffled"),
    "B1-VoxTellControl": ("voxtell", "correct", "B0-VoxTellControl"),
}


def augment_image(image, generator):
    contrast = float(torch.empty(1).uniform_(0.9, 1.1, generator=generator))
    brightness = float(torch.empty(1).uniform_(-0.05, 0.05, generator=generator))
    noise = torch.randn(image.shape, generator=generator, dtype=image.dtype) * 0.01
    return image * contrast + brightness + noise


def b1_encoder(source, device):
    if source == "colipri":
        from colipri import get_model
        model = get_model(checkpoint_path=COLIPRI_CHECKPOINT).to(device).eval()
        model.requires_grad_(False)
        blocks = model.image_encoder.backbone.eva.blocks
        for block in blocks[-2:]:
            block.requires_grad_(True)
        return model.image_encoder, list(blocks[-2:].parameters()), "backbone.eva.blocks.14-15"
    model = load_anchor_model(device).eval(); model.requires_grad_(False)
    source_stage = model.encoder.stages[3]
    source_stage.requires_grad_(True)
    return model.encoder, list(source_stage.parameters()), "encoder.stages.3"


def load_online_row(row, source, text_mode, device, shuffled_frame=None, index=None):
    with np.load(row.path, allow_pickle=False) as shared, np.load(row.feature_path, allow_pickle=False) as feature:
        image = torch.from_numpy(shared[f"{source}_image"]).float()[None].to(device)
        text = torch.from_numpy(feature[f"{source}_text"]).float()[None].to(device)
        target = torch.from_numpy(shared["target"]).float()[None].to(device)
    if text_mode == "shuffled":
        text = shuffled_text_for_index(shuffled_frame, index, source, device)
    return image, text, target


@torch.no_grad()
def patch_validate_online(probe, encoder, frame, source, text_mode, device):
    probe.eval(); encoder.eval(); rows=[]; frame=frame.reset_index(drop=True)
    for index,row in frame.iterrows():
        image,text,target=load_online_row(row,source,text_mode,device,frame,index)
        dense=extract_online(source,image,encoder,device)
        logits=probe(dense,text); loss,terms=dice_bce_loss(logits,target)
        rows.append({"loss":float(loss),**terms,**patch_metrics(logits,target)})
    probe.train(); encoder.eval()
    return {key:float(np.mean([row[key] for row in rows])) for key in rows[0]}


def train_b1_branch(
    args, branch, source, text_mode, b0_branch, feature_manifest, fixed_manifest, baseline, device
):
    train = feature_manifest[feature_manifest.split.eq("train")].reset_index(drop=True)
    val = feature_manifest[feature_manifest.split.eq("val")].reset_index(drop=True)
    b0_checkpoint = args.b0_dir / "branches" / b0_branch / "checkpoints/checkpoint_update_400.pth"
    if not b0_checkpoint.exists():
        raise FileNotFoundError(b0_checkpoint)
    probe, _ = load_probe_checkpoint(b0_checkpoint, device)
    encoder, encoder_parameters, trainable_stage = b1_encoder(source, device)
    trainable_names = {name for name, parameter in encoder.named_parameters() if parameter.requires_grad}
    expected_parameters = sum(parameter.numel() for parameter in encoder_parameters)
    if not trainable_names or sum(parameter.numel() for name, parameter in encoder.named_parameters() if name in trainable_names) != expected_parameters:
        raise RuntimeError("B1 trainable encoder parameter audit failed")
    frozen_before = state_sha256(encoder, lambda name: name not in trainable_names)
    trainable_before = state_sha256(encoder, lambda name: name in trainable_names)
    groups = [
        {"params": probe.parameters(), "lr": args.probe_lr},
        {"params": encoder_parameters, "lr": args.encoder_lr},
    ]
    optimizer = torch.optim.AdamW(groups, weight_decay=1e-4)
    output = args.output_dir / "branches" / branch
    history, validation, full_volume_rows = [], [], []
    generator = torch.Generator().manual_seed(args.seed)

    def save_encoder_stage(update: int) -> None:
        path = output / f"checkpoints/encoder_update_{update}.pth"
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "source": source,
                "trainable_stage": trainable_stage,
                "trainable_parameter_names": sorted(trainable_names),
                "encoder_trainable_state": {
                    name: value.detach().cpu()
                    for name, value in encoder.state_dict().items()
                    if name in trainable_names
                },
            },
            path,
        )

    def evaluate_checkpoint(update: int) -> dict[str, float]:
        frame = fixed30_evaluate_online(
            probe,
            encoder,
            fixed_manifest,
            source,
            text_mode,
            branch,
            update,
            device,
            args.output_dir / "full_volume" / branch / f"update_{update}_{text_mode}.csv",
        )
        metrics = {
            "branch": branch,
            "update": update,
            "inference_text_mode": text_mode,
            **summarize_full(frame, baseline),
            **bootstrap_vs_baseline(frame, baseline, args.bootstrap_reps),
        }
        full_volume_rows.append(metrics)
        atomic_csv(fixed30_subgroups(frame, branch, update), output / f"subgroups_update_{update}.csv")
        return metrics

    initial = patch_validate_online(probe, encoder, val, source, text_mode, device)
    validation.append({"update": 0, **initial})
    save_probe(output / "checkpoints/checkpoint_update_0.pth", probe, branch, 0, source, text_mode, False, initial)
    save_encoder_stage(0)
    evaluate_checkpoint(0)
    updates = 20 if args.smoke_only else args.updates
    started = time.perf_counter(); times = []; first_grad = None
    for update in range(1, updates + 1):
        tick = time.perf_counter(); optimizer.zero_grad(set_to_none=True); micros = []
        for micro in range(args.grad_accum):
            index = ((update - 1) * args.grad_accum + micro) % len(train)
            row = train.iloc[index]
            image, text, target = load_online_row(row, source, text_mode, device, train, index)
            image = augment_image(image.cpu(), generator).to(device)
            dense = extract_online(source, image, encoder, device)
            logits = probe(dense, text); loss, terms = dice_bce_loss(logits, target)
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Non-finite B1 loss at update {update}")
            (loss / args.grad_accum).backward()
            micros.append({"loss": float(loss.detach()), **terms, **patch_metrics(logits, target)})
        encoder_grad = float(torch.sqrt(sum(
            (parameter.grad.detach().float().square().sum() for parameter in encoder_parameters if parameter.grad is not None),
            torch.zeros((), device=device),
        )))
        probe_grad = float(torch.sqrt(sum(
            (parameter.grad.detach().float().square().sum() for parameter in probe.parameters() if parameter.grad is not None),
            torch.zeros((), device=device),
        )))
        if update == 1:
            first_grad = {"encoder": encoder_grad, "probe": probe_grad}
            if min(first_grad.values()) <= 0:
                raise RuntimeError(f"B1 gradient audit failed: {first_grad}")
        total_grad = float(torch.nn.utils.clip_grad_norm_([*probe.parameters(), *encoder_parameters], 12.0))
        optimizer.step(); torch.cuda.synchronize(device); times.append(time.perf_counter() - tick)
        record = {
            "update": update,
            "encoder_grad_norm": encoder_grad,
            "probe_grad_norm": probe_grad,
            "total_grad_norm": total_grad,
            **{key: float(np.mean([item[key] for item in micros])) for key in micros[0]},
        }
        history.append(record)
        if update in {100, 200, 400} or update == updates:
            result = patch_validate_online(probe, encoder, val, source, text_mode, device)
            validation.append({"update": update, **result})
            save_probe(output / f"checkpoints/checkpoint_update_{update}.pth", probe, branch, update, source, text_mode, False, result)
            save_encoder_stage(update)
            full_metrics = evaluate_checkpoint(update)
            print(json.dumps({"branch": branch, **record, **{f"val_{key}": value for key, value in result.items()}, **{f"fixed30_{key}": value for key, value in full_metrics.items() if isinstance(value, (int, float))}}), flush=True)
    frozen_after = state_sha256(encoder, lambda name: name not in trainable_names)
    trainable_after = state_sha256(encoder, lambda name: name in trainable_names)
    integrity = {
        "trainable_stage": trainable_stage,
        "trainable_parameter_names": sorted(trainable_names),
        "trainable_encoder_parameters": expected_parameters,
        "probe_trainable_parameters": sum(parameter.numel() for parameter in probe.parameters()),
        "first_update_gradient_norms": first_grad,
        "frozen_hash_before": frozen_before,
        "frozen_hash_after": frozen_after,
        "frozen_unchanged": frozen_before == frozen_after,
        "trainable_hash_before": trainable_before,
        "trainable_hash_after": trainable_after,
        "trainable_changed": trainable_before != trainable_after,
    }
    if not integrity["frozen_unchanged"] or not integrity["trainable_changed"]:
        raise RuntimeError(f"B1 integrity failed: {integrity}")
    atomic_csv(pd.DataFrame(history), output / "training_trajectory.csv")
    atomic_csv(pd.DataFrame(validation), output / "patch_validation.csv")
    atomic_csv(pd.DataFrame(full_volume_rows), output / "full_volume_summary.csv")
    atomic_json(
        {
            "branch": branch,
            "runtime_seconds": time.perf_counter() - started,
            "mean_seconds_per_update": float(np.mean(times)),
            "peak_gpu_memory_gib": torch.cuda.max_memory_allocated(device) / 2**30,
            "integrity": integrity,
        },
        output / "run_report.json",
    )
    return encoder, probe, full_volume_rows


@torch.no_grad()
def aggregate_online_probabilities(probe, encoder, archive, source, text_mode, device) -> np.ndarray:
    text = torch.from_numpy(archive[f"{source}_text_{text_mode}"]).float()[None].to(device)
    shape = tuple(archive["processed_shape"].astype(int))
    prompts = int(text.shape[1])
    probability_sum = np.zeros((prompts, *shape), dtype=np.float32)
    count = np.zeros(shape, dtype=np.uint16)
    for window, start in zip(archive[f"{source}_image"], archive["window_starts"].astype(int)):
        image = torch.from_numpy(window).float()[None].to(device)
        dense = extract_online(source, image, encoder, device)
        probability = probe(dense, text).sigmoid()[0].float().cpu().numpy()
        slices = tuple(slice(int(value), int(value) + 192) for value in start)
        probability_sum[(slice(None), *slices)] += probability
        count[slices] += 1
    if np.any(count == 0):
        raise AssertionError("Online sliding-window aggregation left uncovered voxels")
    return probability_sum / count[None]


@torch.no_grad()
def fixed30_evaluate_online(probe,encoder,cache_manifest,source,text_mode,branch,update,device,output_csv):
    probe.eval();encoder.eval();rows=[]
    for case_row in cache_manifest.itertuples(index=False):
        with np.load(case_row.path,allow_pickle=False) as z:
            prob=aggregate_online_probabilities(probe,encoder,z,source,text_mode,device)
            for channel,finding_idx in enumerate(z["finding_indices"].astype(int)):
                pred = restore_prediction(
                    prob[channel] >= .5,
                    z["processed_affine"],
                    z["original_shape"],
                    z["original_affine"],
                )
                gt = z["original_gt"][channel].astype(bool)
                tp = int((pred & gt).sum()); fp = int((pred & ~gt).sum()); fn = int((~pred & gt).sum())
                category = str(z["categories"][channel])
                rows.append({"case":case_row.case_id,"finding_idx":finding_idx,"category":category,"focality":"focal" if category.startswith("2") else "diffuse","case_finding_count":int(case_row.findings),"same_case_same_entity":int(z["entity_counts"][channel])>1,"branch":branch,"update":update,"dice":2*tp/max(2*tp+fp+fn,1),"hit":int(tp>0),"tp_voxels":tp,"fp_voxels":fp,"fn_voxels":fn,"pred_voxels":int(pred.sum()),"gt_voxels":int(gt.sum()),"empty_prediction":int(not pred.any())})
    frame=pd.DataFrame(rows);atomic_csv(frame,output_csv);return frame


def run_b1(args):
    if args.updates!=400 and not args.smoke_only: raise ValueError("Formal B1 is predeclared for exactly 400 updates")
    if not args.b0_dir.exists(): raise FileNotFoundError(args.b0_dir)
    b0_result=json.loads((args.b0_dir/"result.json").read_text())
    equivalence=json.loads((args.b0_dir/"online_cache_equivalence.json").read_text())
    if not equivalence.get("passed"): raise RuntimeError("B0 cache audit did not pass")
    if not torch.cuda.is_available(): raise RuntimeError("B1 requires one GPU")
    device=torch.device(args.device);torch.cuda.set_device(device);seed_all(args.seed);args.output_dir.mkdir(parents=True,exist_ok=False)
    features=pd.read_csv(args.b0_dir/"feature_cache_manifest.csv");fixed=pd.read_csv(args.b0_dir/"fixed30_cache_manifest.csv");baseline=baseline_fixed30();summary_rows=[]
    for branch,(source,text_mode,b0_branch) in BRANCHES_B1.items():
        seed_all(args.seed)
        encoder,probe,branch_rows=train_b1_branch(args,branch,source,text_mode,b0_branch,features,fixed,baseline,device)
        summary_rows.extend(branch_rows)
        del encoder,probe;torch.cuda.empty_cache()
    summary=pd.DataFrame(summary_rows);atomic_csv(summary,args.output_dir/"full_volume_summary.csv")
    final_update=20 if args.smoke_only else 400
    final=summary[summary.update.eq(final_update)].set_index("branch")
    correct=float(final.loc["B1-Correct","mean_dice"]);shuffled=float(final.loc["B1-Shuffled","mean_dice"]);control=float(final.loc["B1-VoxTellControl","mean_dice"]);delta_b0=correct-float(b0_result["correct_text_dice"])
    if correct>shuffled+.002 and correct>control and delta_b0>0:
        verdict="GO"
    elif correct<=shuffled and correct<=control and delta_b0<=0:
        verdict="NO-GO"
    else:
        verdict="INCONCLUSIVE"
    report_path=ROOT/"reports/colipri_experiment_B1_partial_adaptation.md";report_path.write_text("\n".join(["# CoLiPri Experiment B1: Partial Adaptation","",f"**Verdict: {verdict}.**","","B1 starts from the corresponding B0 update-400 probe, keeps the text encoder frozen, and updates only the matched probe plus CoLiPri EVA blocks 14-15 (or VoxTell source stage 3 for the control).","","## Fixed30", "",markdown_table(summary),"",f"B1 Correct minus B0 Correct: {delta_b0:+.6f}.",""])+"\n")
    result={"verdict":verdict,"correct_text_dice":correct,"shuffled_text_dice":shuffled,"voxtell_control_dice":control,"delta_vs_b0":delta_b0,"b0_verdict":b0_result["verdict"],"report":str(report_path)};atomic_json(result,args.output_dir/"result.json");atomic_json({"experiment":"B1 online partial adaptation","seed":args.seed,"encoder_lr":args.encoder_lr,"probe_lr":args.probe_lr,"augmentation":"on-the-fly intensity noise/brightness/contrast; no spatial flips","gpu":torch.cuda.get_device_name(device),"host":socket.gethostname(),"slurm_job_id":os.environ.get("SLURM_JOB_ID","")},args.output_dir/"provenance.json");print(json.dumps(result,indent=2),flush=True)


def main() -> int:
    args=parse_args();args.output_dir=args.output_dir.resolve()
    if args.command=="b0": run_b0(args)
    elif args.command == "b0-finalize": finalize_b0_outputs(args)
    else: args.b0_dir=args.b0_dir.resolve();run_b1(args)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
