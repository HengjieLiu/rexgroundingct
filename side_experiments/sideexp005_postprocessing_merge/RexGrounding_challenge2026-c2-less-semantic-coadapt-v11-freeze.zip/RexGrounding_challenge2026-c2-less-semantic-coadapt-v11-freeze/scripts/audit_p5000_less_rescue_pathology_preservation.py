#!/usr/bin/env python3
"""Frozen P-head pathology margin under normal correct LESS input."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from scripts import audit_c2_pathology_route_margin as route
from scripts import run_c2_anatomy_formulation_ranking as base


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--arm", required=True)
    parser.add_argument("--update", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    import torch
    device = torch.device("cuda:0")
    cfg = json.loads(route.P_ARGS.read_text())
    cfg["prompt_location_label_dir"] = str(ROOT / "data/rex_lobe_labels_preprocessed_v1")
    model = base.make_model(cfg, device, args.checkpoint)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    rows_by_condition, identity = route.evaluate(
        model, cfg, {"normal": ("correct", "correct", False)}, device
    )
    rows = rows_by_condition["normal"]
    route.write_rows(args.output / "per_finding.tsv", rows)
    summary = route.stats(rows)
    payload = {
        "arm": args.arm, "update": args.update,
        "checkpoint": str(args.checkpoint.resolve()),
        **summary,
        "condition": "normal correct global sentence + correct LESS tokens",
        "pathology_head": "loaded from P@5000 lineage and frozen during rescue",
        "identity_rows": len(identity["rows"]),
    }
    (args.output / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
