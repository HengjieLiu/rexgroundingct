#!/usr/bin/env python3
"""Inference-only trace of minimal location swaps through Qwen and VoxTell."""

from __future__ import annotations

import argparse
import csv
import difflib
import gc
import hashlib
import json
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import torch
from scipy import ndimage

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "VoxTell", ROOT / "scripts"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from diagnose_spatial_attention_localization import load_rex_masks_in_preprocessed_ras  # noqa: E402
from run_voxtell_rex_inference import load_entries, load_image, sorted_prompts  # noqa: E402
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402
from voxtell.utils.text_embedding import last_token_pool, wrap_with_instruction  # noqa: E402


DEFAULT_CHECKPOINT = (
    ROOT
    / "outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000"
    / "checkpoints/checkpoint_best_val_dice_step_3800.pth"
)
DEFAULT_SELECTED = (
    ROOT
    / "outputs/prompt_standardization_rule_only_v1"
    / "stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv"
)
DEFAULT_MANIFEST = (
    ROOT
    / "outputs/prompt_standardization_rule_only_v1"
    / "stratified30_six_variant_ablation_v1/prepared_inputs/stratified_subset_manifest.json"
)
DEFAULT_OUTPUT = ROOT / "outputs/p0_minimal_location_swap_trace_anchor85_fixed30"
EXPECTED_SELECTED_SHA256 = "68af4d8ff9efa7101e779c39b3efcf62407d0f7b3702f1459042a065b9270880"
EPS = 1e-12


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument("--selected-findings", type=Path, default=DEFAULT_SELECTED)
    parser.add_argument("--fixed30-manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--rex-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--mask-dir", type=Path, default=ROOT / "data/segmentations")
    parser.add_argument("--model-dir", type=Path, default=ROOT / "VoxTell/voxtell_v1.1")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--text-model", default="Qwen/Qwen3-Embedding-4B")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--qwen-batch-size", type=int, default=16)
    parser.add_argument("--bootstrap-samples", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260729)
    parser.add_argument("--max-visualizations", type=int, default=6)
    parser.add_argument("--prepare-only", action="store_true")
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_ready(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {str(key): json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(item) for item in value]
    return value


def write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(json_ready(payload), indent=2, sort_keys=False) + "\n")


def read_selected(args: argparse.Namespace) -> tuple[pd.DataFrame, dict[str, dict[str, Any]]]:
    selected_hash = sha256_file(args.selected_findings)
    if selected_hash != EXPECTED_SELECTED_SHA256:
        raise RuntimeError(
            "Refusing to use a different fixed30 selection: "
            f"{args.selected_findings} has SHA-256 {selected_hash}, expected "
            f"{EXPECTED_SELECTED_SHA256}"
        )
    selected = pd.read_csv(args.selected_findings)
    if len(selected) != 49 or selected["case"].nunique() != 30:
        raise RuntimeError(
            f"Expected exact fixed30 30-case/49-finding selection, got "
            f"{selected['case'].nunique()} cases/{len(selected)} findings"
        )
    entries = {item["name"]: item for item in load_entries(args.rex_json, ["val"])}
    missing = sorted(set(selected["case"]) - entries.keys())
    if missing:
        raise RuntimeError(f"Selected cases missing from ReX JSON: {missing}")
    return selected, entries


def exclusion_flags(text: str) -> set[str]:
    lower = text.lower()
    flags: set[str] = set()
    if re.search(r"\bbilateral\b|\bboth lungs?\b|\bboth upper lobes?\b|\bboth lower lobes?\b", lower):
        flags.add("bilateral_description")
    if (
        "diffuse" in lower
        or "multilobar" in lower
        or "upper and lower lobes" in lower
        or "largely filling" in lower
    ):
        flags.add("diffuse_or_multilobar_description")
    if re.search(r"\blingul(?:a|ar)\b", lower):
        flags.add("lingula")
    if "middle lobe" in lower:
        flags.add("middle_lobe")
    if re.search(r"\bmidline\b", lower):
        flags.add("midline")
    return flags


def replace_one(text: str, pattern: str, replacement: str) -> tuple[str, list[tuple[int, int]]]:
    matches = list(re.finditer(pattern, text, flags=re.IGNORECASE))
    if len(matches) != 1:
        raise ValueError(f"Expected one match for {pattern!r}, found {len(matches)} in {text!r}")
    match = matches[0]
    old = match.group(0)
    if old[:1].isupper():
        replacement = replacement[:1].upper() + replacement[1:]
    return text[: match.start()] + replacement + text[match.end() :], [(match.start(), match.end())]


def make_pair(
    case_id: str,
    finding_id: int,
    category: str,
    original: str,
    swap_type: str,
    old_value: str,
    new_value: str,
    pattern: str,
) -> dict[str, Any]:
    swapped, original_spans = replace_one(original, pattern, new_value)
    start = original_spans[0][0]
    swapped_spans = [(start, start + len(new_value))]
    before_same = original[:start] == swapped[:start]
    after_same = original[original_spans[0][1] :] == swapped[swapped_spans[0][1] :]
    changed_attribute_count = 1 if before_same and after_same and old_value.lower() != new_value.lower() else 0
    return {
        "pair_id": f"{case_id.removesuffix('.nii.gz')}__f{finding_id}__{swap_type}",
        "case_id": case_id,
        "finding_id": int(finding_id),
        "category": str(category),
        "swap_type": swap_type,
        "original_prompt": original,
        "swapped_prompt": swapped,
        "old_location_value": old_value.lower(),
        "new_location_value": new_value.lower(),
        "original_changed_char_spans": original_spans,
        "swapped_changed_char_spans": swapped_spans,
        "exactly_one_location_attribute_changed": changed_attribute_count == 1,
        "all_non_location_text_identical": bool(before_same and after_same),
    }


def generate_pairs(
    selected: pd.DataFrame,
    entries: dict[str, dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    pairs: list[dict[str, Any]] = []
    exclusions: list[dict[str, Any]] = []
    finding_status: dict[tuple[str, int], dict[str, Any]] = {}
    for source in selected.itertuples(index=False):
        case_id = str(source.case)
        finding_id = int(source.finding_idx)
        entry = entries[case_id]
        original = str(entry["findings"][str(finding_id)])
        category = str((entry.get("categories") or {}).get(str(finding_id), source.category))
        lower = original.lower()
        flags = exclusion_flags(original)
        eligible_types: list[str] = []

        sides = set(re.findall(r"\b(left|right)\b", lower))
        side_mentions = re.findall(r"\b(left|right)\b", lower)
        laterality_reason = None
        if not sides:
            laterality_reason = "no_supported_laterality"
        elif "bilateral_description" in flags:
            laterality_reason = "bilateral_description"
        elif len(sides) != 1:
            laterality_reason = "mixed_or_ambiguous_laterality"
        elif len(side_mentions) != 1:
            laterality_reason = "multiple_laterality_mentions"
        elif "middle_lobe" in flags:
            laterality_reason = "invalid_right_middle_to_left_middle"
        elif "lingula" in flags:
            laterality_reason = "invalid_lingula_laterality"
        elif "midline" in flags:
            laterality_reason = "midline"
        elif "diffuse_or_multilobar_description" in flags:
            laterality_reason = "diffuse_or_multilobar_description"
        if laterality_reason is None:
            old = next(iter(sides))
            new = "left" if old == "right" else "right"
            pairs.append(
                make_pair(
                    case_id, finding_id, category, original, "laterality",
                    old, new, rf"\b{old}\b",
                )
            )
            eligible_types.append("laterality")
        else:
            exclusions.append(
                {
                    "case_id": case_id,
                    "finding_id": finding_id,
                    "category": category,
                    "swap_type": "laterality",
                    "original_prompt": original,
                    "exclusion_reason": laterality_reason,
                }
            )

        vertical_values = set(
            value.lower()
            for value in re.findall(r"\b(upper lobe|lower lobe)\b", original, flags=re.IGNORECASE)
        )
        vertical_reason = None
        if not vertical_values:
            vertical_reason = "no_supported_upper_lower_phrase"
        elif len(vertical_values) != 1:
            vertical_reason = "multiple_or_multilobar_upper_lower_phrases"
        elif "bilateral_description" in flags:
            vertical_reason = "bilateral_description"
        elif "diffuse_or_multilobar_description" in flags:
            vertical_reason = "diffuse_or_multilobar_description"
        elif "middle_lobe" in flags:
            vertical_reason = "middle_lobe_present"
        elif "lingula" in flags:
            vertical_reason = "lingula_present"
        elif re.search(
            r"\b(?:laterobasal|posterobasal|anterobasal|mediobasal)\b"
            r"|\b(?:posterior|anterior) segment\b"
            r"|\bdiaphragmatic surface\b",
            lower,
        ):
            vertical_reason = "segment_or_surface_not_valid_after_lobe_swap"
        elif len(re.findall(r"\b(?:upper lobe|lower lobe)\b", lower)) != 1:
            vertical_reason = "multiple_upper_lower_mentions"
        if vertical_reason is None:
            old = next(iter(vertical_values))
            new = "lower lobe" if old == "upper lobe" else "upper lobe"
            pairs.append(
                make_pair(
                    case_id, finding_id, category, original, "upper_lower",
                    old, new, rf"\b{re.escape(old)}\b",
                )
            )
            eligible_types.append("upper_lower")
        else:
            exclusions.append(
                {
                    "case_id": case_id,
                    "finding_id": finding_id,
                    "category": category,
                    "swap_type": "upper_lower",
                    "original_prompt": original,
                    "exclusion_reason": vertical_reason,
                }
            )

        finding_status[(case_id, finding_id)] = {
            "case_id": case_id,
            "finding_id": finding_id,
            "category": category,
            "original_prompt": original,
            "eligible_swap_types": ",".join(eligible_types),
            "pair_count": len(eligible_types),
        }
    if not pairs:
        raise RuntimeError("No eligible location swaps were generated")
    for pair in pairs:
        if not pair["exactly_one_location_attribute_changed"] or not pair["all_non_location_text_identical"]:
            raise RuntimeError(f"Prompt sanity check failed: {pair}")
    eligible = [row for row in finding_status.values() if row["pair_count"] > 0]
    for row in exclusions:
        status = finding_status[(row["case_id"], int(row["finding_id"]))]
        row["finding_has_other_eligible_swap"] = bool(status["pair_count"] > 0)
        row["finding_fully_excluded"] = bool(status["pair_count"] == 0)
    return pairs, eligible, exclusions


def write_prompt_audit(
    args: argparse.Namespace,
    pairs: list[dict[str, Any]],
    eligible: list[dict[str, Any]],
    exclusions: list[dict[str, Any]],
) -> None:
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "validation_failure.json").unlink(missing_ok=True)
    pd.DataFrame(eligible).to_csv(args.output_dir / "eligible_findings.csv", index=False)
    pd.DataFrame(exclusions).to_csv(args.output_dir / "excluded_findings.csv", index=False)
    write_json(args.output_dir / "prompt_pairs.json", pairs)
    print("\nGenerated minimal prompt pairs:", flush=True)
    for pair in pairs:
        print(
            f"[{pair['pair_id']}] {pair['original_prompt']}  ==>  {pair['swapped_prompt']}",
            flush=True,
        )
    print(
        f"Eligible findings={len(eligible)}; pairs={len(pairs)}; "
        f"laterality={sum(p['swap_type'] == 'laterality' for p in pairs)}; "
        f"upper/lower={sum(p['swap_type'] == 'upper_lower' for p in pairs)}",
        flush=True,
    )
    print(f"Exclusion records={len(exclusions)}; reasons={Counter(x['exclusion_reason'] for x in exclusions)}")


def tensor_digest(module: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    with torch.no_grad():
        for name, tensor in module.state_dict().items():
            digest.update(name.encode("utf-8"))
            value = tensor.detach().contiguous()
            if value.device.type != "cpu":
                value = value.cpu()
            digest.update(value.reshape(-1).view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=np.float64).reshape(-1)
    y = np.asarray(b, dtype=np.float64).reshape(-1)
    denom = float(np.linalg.norm(x) * np.linalg.norm(y))
    if denom <= EPS:
        return 1.0 if np.allclose(x, y) else 0.0
    return float(np.dot(x, y) / denom)


def relative_l2(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=np.float64).reshape(-1)
    y = np.asarray(b, dtype=np.float64).reshape(-1)
    return float(np.linalg.norm(x - y) / (np.linalg.norm(x) + EPS))


def l2(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64)))


def token_indices_for_spans(offsets: list[list[int]], spans: list[list[int]]) -> list[int]:
    indices = []
    for index, (start, end) in enumerate(offsets):
        if end <= start:
            continue
        if any(start < span_end and end > span_start for span_start, span_end in spans):
            indices.append(index)
    return indices


def aligned_unchanged_indices(
    first_ids: list[int],
    second_ids: list[int],
    first_changed: set[int],
    second_changed: set[int],
) -> list[tuple[int, int]]:
    matcher = difflib.SequenceMatcher(a=first_ids, b=second_ids, autojunk=False)
    aligned = []
    for block in matcher.get_matching_blocks():
        for offset in range(block.size):
            left = block.a + offset
            right = block.b + offset
            if left not in first_changed and right not in second_changed:
                aligned.append((left, right))
    return aligned


@torch.inference_mode()
def extract_qwen(
    predictor: VoxTellPredictor,
    pairs: list[dict[str, Any]],
    batch_size: int,
) -> tuple[dict[str, torch.Tensor], dict[str, dict[str, Any]], dict[str, str]]:
    tokenizer = predictor.tokenizer
    model = predictor.text_backbone
    if tokenizer is None or model is None:
        raise RuntimeError("Qwen tokenizer/backbone were not loaded")
    model.requires_grad_(False)
    model.eval()
    qwen_before = tensor_digest(model)
    device = predictor.device
    model.to(device)
    unique_texts = list(
        dict.fromkeys(
            text
            for pair in pairs
            for text in (pair["original_prompt"], pair["swapped_prompt"])
        )
    )
    records: dict[str, dict[str, Any]] = {}
    pooled_map: dict[str, torch.Tensor] = {}
    for start in range(0, len(unique_texts), batch_size):
        texts = unique_texts[start : start + batch_size]
        wrapped = wrap_with_instruction(texts)
        tokens = tokenizer(
            wrapped,
            padding=True,
            truncation=True,
            max_length=predictor.max_text_length,
            return_tensors="pt",
            return_offsets_mapping=True,
        )
        offsets = tokens.pop("offset_mapping")
        model_tokens = {key: value.to(device) for key, value in tokens.items()}
        output = model(**model_tokens)
        pooled = last_token_pool(output.last_hidden_state, model_tokens["attention_mask"])
        for index, text in enumerate(texts):
            keep = model_tokens["attention_mask"][index].bool()
            ids = model_tokens["input_ids"][index][keep].detach().cpu().tolist()
            hidden = output.last_hidden_state[index][keep].float().cpu().numpy()
            kept_offsets = offsets[index][keep.cpu()].tolist()
            pooled_map[text] = pooled[index].float().cpu()
            records[text] = {
                "wrapped_text": wrapped[index],
                "input_ids": ids,
                "attention_mask": [1] * len(ids),
                "offset_mapping": kept_offsets,
                "token_pieces": tokenizer.convert_ids_to_tokens(ids),
                "decoded_tokens": [
                    tokenizer.decode([token_id], skip_special_tokens=False) for token_id in ids
                ],
                "_hidden": hidden,
            }
        del output, pooled, model_tokens
        torch.cuda.empty_cache()
    model.to("cpu")
    qwen_after = tensor_digest(model)
    if qwen_before != qwen_after:
        raise RuntimeError("Frozen Qwen parameter digest changed during inference")

    instruction_prefix = wrap_with_instruction([""])[0]
    for pair in pairs:
        first = records[pair["original_prompt"]]
        second = records[pair["swapped_prompt"]]
        first_spans = [
            [len(instruction_prefix) + int(a), len(instruction_prefix) + int(b)]
            for a, b in pair["original_changed_char_spans"]
        ]
        second_spans = [
            [len(instruction_prefix) + int(a), len(instruction_prefix) + int(b)]
            for a, b in pair["swapped_changed_char_spans"]
        ]
        first_changed = token_indices_for_spans(first["offset_mapping"], first_spans)
        second_changed = token_indices_for_spans(second["offset_mapping"], second_spans)
        if not first_changed or not second_changed:
            raise RuntimeError(f"Could not map changed token span for {pair['pair_id']}")
        aligned = aligned_unchanged_indices(
            first["input_ids"], second["input_ids"], set(first_changed), set(second_changed)
        )
        first_hidden = first["_hidden"]
        second_hidden = second["_hidden"]
        first_pool = pooled_map[pair["original_prompt"]].numpy()
        second_pool = pooled_map[pair["swapped_prompt"]].numpy()
        if len(first_hidden) == len(second_hidden):
            full_first = first_hidden
            full_second = second_hidden
            full_alignment = "position_aligned_equal_length"
        else:
            full_first = np.stack([first_hidden[a] for a, _ in aligned])
            full_second = np.stack([second_hidden[b] for _, b in aligned])
            full_alignment = "unchanged_token_id_alignment_length_mismatch"
        token_cosines = [
            cosine(first_hidden[a], second_hidden[b])
            for a, b in (
                list(zip(range(len(first_hidden)), range(len(second_hidden))))
                if len(first_hidden) == len(second_hidden)
                else aligned
            )
        ]
        unchanged_first = np.stack([first_hidden[a] for a, _ in aligned])
        unchanged_second = np.stack([second_hidden[b] for _, b in aligned])
        changed_first = first_hidden[first_changed].mean(axis=0)
        changed_second = second_hidden[second_changed].mean(axis=0)
        pair["qwen_tokenization"] = {
            "correct": {key: value for key, value in first.items() if not key.startswith("_")},
            "swap": {key: value for key, value in second.items() if not key.startswith("_")},
            "correct_changed_token_indices": first_changed,
            "swap_changed_token_indices": second_changed,
            "correct_changed_tokens": [first["decoded_tokens"][i] for i in first_changed],
            "swap_changed_tokens": [second["decoded_tokens"][i] for i in second_changed],
            "unchanged_aligned_token_pairs": aligned,
            "full_sequence_alignment_method": full_alignment,
        }
        pair["qwen_metrics"] = {
            "pooled_cosine": cosine(first_pool, second_pool),
            "pooled_l2": l2(first_pool, second_pool),
            "pooled_relative_l2": relative_l2(first_pool, second_pool),
            "masked_mean_token_feature_cosine": float(np.mean(token_cosines)),
            "full_token_sequence_cosine": cosine(full_first, full_second),
            "full_token_sequence_relative_l2": relative_l2(full_first, full_second),
            "changed_token_span_cosine": cosine(changed_first, changed_second),
            "changed_token_span_l2": l2(changed_first, changed_second),
            "changed_token_span_relative_l2": relative_l2(changed_first, changed_second),
            "unchanged_contextual_cosine": cosine(unchanged_first, unchanged_second),
            "unchanged_contextual_relative_l2": relative_l2(unchanged_first, unchanged_second),
            "unchanged_aligned_token_count": len(aligned),
        }
    return pooled_map, records, {"before": qwen_before, "after": qwen_after}


class FeatureAccumulator:
    """Accumulate pairwise vector metrics without retaining patch tensors."""

    def __init__(self, pairs: list[dict[str, Any]]) -> None:
        self.pairs = pairs
        self.values: dict[tuple[str, str], dict[str, float]] = defaultdict(
            lambda: {"dot": 0.0, "correct_sq": 0.0, "swap_sq": 0.0, "diff_sq": 0.0, "elements": 0.0, "calls": 0.0}
        )
        self.handles: list[Any] = []

    def observe(self, stage: str, tensor: torch.Tensor, prompt_dim: int) -> None:
        value = tensor.detach().float()
        value = value.movedim(prompt_dim, 0)
        if value.shape[0] != 2 * len(self.pairs):
            raise RuntimeError(
                f"Stage {stage}: expected {2 * len(self.pairs)} prompt vectors, got {tuple(value.shape)}"
            )
        flat = value.reshape(value.shape[0], -1)
        for index, pair in enumerate(self.pairs):
            correct = flat[2 * index]
            swap = flat[2 * index + 1]
            stat = self.values[(pair["pair_id"], stage)]
            stat["dot"] += float(torch.dot(correct, swap).cpu())
            stat["correct_sq"] += float(torch.dot(correct, correct).cpu())
            stat["swap_sq"] += float(torch.dot(swap, swap).cpu())
            difference = correct - swap
            stat["diff_sq"] += float(torch.dot(difference, difference).cpu())
            stat["elements"] += float(correct.numel())
            stat["calls"] += 1.0

    def add_hook(self, module: torch.nn.Module, stage: str, prompt_dim: int, tuple_first: bool = False) -> None:
        def hook(_module, _inputs, output):
            value = output[0] if tuple_first else output
            self.observe(stage, value, prompt_dim)

        self.handles.append(module.register_forward_hook(hook))

    def install(self, network: torch.nn.Module) -> None:
        self.add_hook(network.project_text_embed, "text_projection", 0)
        for index, layer in enumerate(network.transformer_decoder.layers):
            self.add_hook(layer, f"prompt_decoder_layer_{index + 1}", 0, tuple_first=True)
        if network.transformer_decoder.norm is not None:
            self.add_hook(network.transformer_decoder.norm, "prompt_decoder_final_norm", 0)
        for index, projection in enumerate(network.project_to_decoder_channels):
            self.add_hook(projection, f"multiscale_mask_projection_{index}", 1)

    def close(self) -> None:
        for handle in self.handles:
            handle.remove()
        self.handles.clear()

    def rows(self) -> list[dict[str, Any]]:
        result = []
        metadata = {pair["pair_id"]: pair for pair in self.pairs}
        for (pair_id, stage), value in self.values.items():
            correct_norm = math.sqrt(max(value["correct_sq"], 0.0))
            swap_norm = math.sqrt(max(value["swap_sq"], 0.0))
            diff_norm = math.sqrt(max(value["diff_sq"], 0.0))
            result.append(
                {
                    "case_id": metadata[pair_id]["case_id"],
                    "finding_id": metadata[pair_id]["finding_id"],
                    "pair_id": pair_id,
                    "swap_type": metadata[pair_id]["swap_type"],
                    "original_prompt": metadata[pair_id]["original_prompt"],
                    "swapped_prompt": metadata[pair_id]["swapped_prompt"],
                    "stage": stage,
                    "cosine_similarity": value["dot"] / (correct_norm * swap_norm + EPS),
                    "relative_l2_difference": diff_norm / (correct_norm + EPS),
                    "correct_representation_norm": correct_norm,
                    "difference_norm": diff_norm,
                    "normalized_sensitivity": diff_norm / (correct_norm + EPS),
                    "hook_calls": int(value["calls"]),
                    "elements_per_condition": int(value["elements"]),
                }
            )
        return result


class SinglePromptTrace:
    """Capture compact prompt-conditioned vectors from a normal one-prompt run."""

    def __init__(self) -> None:
        self.values: dict[str, list[torch.Tensor]] = defaultdict(list)
        self.handles: list[Any] = []

    def add_hook(
        self,
        module: torch.nn.Module,
        stage: str,
        prompt_dim: int,
        tuple_first: bool = False,
    ) -> None:
        def hook(_module, _inputs, output):
            value = output[0] if tuple_first else output
            value = value.detach().float().movedim(prompt_dim, 0)
            if value.shape[0] != 1:
                raise RuntimeError(
                    f"Single-prompt trace expected one prompt at {stage}, got {tuple(value.shape)}"
                )
            self.values[stage].append(value[0].reshape(-1).cpu())

        self.handles.append(module.register_forward_hook(hook))

    def install(self, network: torch.nn.Module) -> None:
        self.add_hook(network.project_text_embed, "text_projection", 0)
        for index, layer in enumerate(network.transformer_decoder.layers):
            self.add_hook(layer, f"prompt_decoder_layer_{index + 1}", 0, tuple_first=True)
        if network.transformer_decoder.norm is not None:
            self.add_hook(network.transformer_decoder.norm, "prompt_decoder_final_norm", 0)
        for index, projection in enumerate(network.project_to_decoder_channels):
            self.add_hook(projection, f"multiscale_mask_projection_{index}", 1)

    def close(self) -> None:
        for handle in self.handles:
            handle.remove()
        self.handles.clear()


def compare_single_prompt_traces(
    pair: dict[str, Any],
    correct: SinglePromptTrace,
    swap: SinglePromptTrace,
) -> list[dict[str, Any]]:
    if correct.values.keys() != swap.values.keys():
        raise RuntimeError("Correct/swap hook stages differ")
    rows = []
    for stage in correct.values:
        first_values = correct.values[stage]
        second_values = swap.values[stage]
        if len(first_values) != len(second_values):
            raise RuntimeError(
                f"Correct/swap hook-call count differs at {stage}: "
                f"{len(first_values)} != {len(second_values)}"
            )
        dot = correct_sq = swap_sq = diff_sq = 0.0
        elements = 0
        for first, second in zip(first_values, second_values):
            if first.shape != second.shape:
                raise RuntimeError(
                    f"Correct/swap representation shape differs at {stage}: "
                    f"{tuple(first.shape)} != {tuple(second.shape)}"
                )
            dot += float(torch.dot(first, second))
            correct_sq += float(torch.dot(first, first))
            swap_sq += float(torch.dot(second, second))
            difference = first - second
            diff_sq += float(torch.dot(difference, difference))
            elements += first.numel()
        correct_norm = math.sqrt(max(correct_sq, 0.0))
        swap_norm = math.sqrt(max(swap_sq, 0.0))
        diff_norm = math.sqrt(max(diff_sq, 0.0))
        rows.append(
            {
                "case_id": pair["case_id"],
                "finding_id": pair["finding_id"],
                "pair_id": pair["pair_id"],
                "swap_type": pair["swap_type"],
                "original_prompt": pair["original_prompt"],
                "swapped_prompt": pair["swapped_prompt"],
                "stage": stage,
                "cosine_similarity": dot / (correct_norm * swap_norm + EPS),
                "relative_l2_difference": diff_norm / (correct_norm + EPS),
                "correct_representation_norm": correct_norm,
                "difference_norm": diff_norm,
                "normalized_sensitivity": diff_norm / (correct_norm + EPS),
                "hook_calls": len(first_values),
                "elements_per_condition": elements,
            }
        )
    return rows


def pearson(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=np.float64).reshape(-1)
    y = np.asarray(b, dtype=np.float64).reshape(-1)
    x -= x.mean()
    y -= y.mean()
    denom = float(np.linalg.norm(x) * np.linalg.norm(y))
    if denom <= EPS:
        return 1.0 if np.allclose(a, b) else 0.0
    return float(np.dot(x, y) / denom)


def dice(pred: np.ndarray, target: np.ndarray) -> float:
    denom = int(pred.sum()) + int(target.sum())
    return 1.0 if denom == 0 else float(2 * np.logical_and(pred, target).sum() / denom)


def component_metrics(mask: np.ndarray) -> tuple[int, np.ndarray | None]:
    labels, count = ndimage.label(mask, structure=np.ones((3, 3, 3), dtype=np.uint8))
    if count == 0:
        return 0, None
    sizes = np.bincount(labels.reshape(-1))
    sizes[0] = 0
    largest = int(np.argmax(sizes))
    centroid = np.asarray(ndimage.center_of_mass(mask, labels, largest), dtype=np.float64)
    return int(count), centroid


def segmentation_row(
    pair: dict[str, Any],
    correct_logits: np.ndarray,
    swapped_logits: np.ndarray,
    target: np.ndarray,
    threshold: float,
) -> dict[str, Any]:
    correct_logits = correct_logits.astype(np.float32, copy=False)
    swapped_logits = swapped_logits.astype(np.float32, copy=False)
    correct_prob = 1.0 / (1.0 + np.exp(-correct_logits))
    swapped_prob = 1.0 / (1.0 + np.exp(-swapped_logits))
    correct_mask = correct_prob >= threshold
    swapped_mask = swapped_prob >= threshold
    target = target.astype(bool, copy=False)
    absolute = np.abs(correct_logits - swapped_logits)
    correct_inside = float(correct_logits[target].mean())
    correct_outside = float(correct_logits[~target].mean())
    swapped_inside = float(swapped_logits[target].mean())
    swapped_outside = float(swapped_logits[~target].mean())
    correct_margin = correct_inside - correct_outside
    swapped_margin = swapped_inside - swapped_outside
    correct_components, correct_centroid = component_metrics(correct_mask)
    swapped_components, swapped_centroid = component_metrics(swapped_mask)
    centroid_shift = (
        float(np.linalg.norm(correct_centroid - swapped_centroid))
        if correct_centroid is not None and swapped_centroid is not None
        else float("nan")
    )
    correct_dice = dice(correct_mask, target)
    swapped_dice = dice(swapped_mask, target)
    correct_volume = int(correct_mask.sum())
    swapped_volume = int(swapped_mask.sum())
    return {
        "case_id": pair["case_id"],
        "finding_id": pair["finding_id"],
        "pair_id": pair["pair_id"],
        "category": pair["category"],
        "swap_type": pair["swap_type"],
        "original_prompt": pair["original_prompt"],
        "swapped_prompt": pair["swapped_prompt"],
        **{f"qwen_{key}": value for key, value in pair["qwen_metrics"].items()},
        "logit_pearson": pearson(correct_logits, swapped_logits),
        "probability_pearson": pearson(correct_prob, swapped_prob),
        "mean_absolute_logit_difference": float(absolute.mean()),
        "p95_absolute_logit_difference": float(np.percentile(absolute, 95)),
        "p99_absolute_logit_difference": float(np.percentile(absolute, 99)),
        "correct_mean_logit_inside_gt": correct_inside,
        "correct_mean_logit_outside_gt": correct_outside,
        "correct_gt_logit_margin": correct_margin,
        "swapped_mean_logit_inside_gt": swapped_inside,
        "swapped_mean_logit_outside_gt": swapped_outside,
        "swapped_gt_logit_margin": swapped_margin,
        "correct_minus_swap_gt_logit_margin": correct_margin - swapped_margin,
        "correct_dice": correct_dice,
        "swapped_dice": swapped_dice,
        "correct_minus_swap_dice": correct_dice - swapped_dice,
        "correct_predicted_foreground_voxels": correct_volume,
        "swapped_predicted_foreground_voxels": swapped_volume,
        "correct_minus_swap_predicted_volume_voxels": correct_volume - swapped_volume,
        "correct_false_positive_voxels": int(np.logical_and(correct_mask, ~target).sum()),
        "swapped_false_positive_voxels": int(np.logical_and(swapped_mask, ~target).sum()),
        "binary_mask_dice_correct_vs_swap": dice(correct_mask, swapped_mask),
        "correct_connected_components": correct_components,
        "swapped_connected_components": swapped_components,
        "largest_component_centroid_shift_voxels": centroid_shift,
        "gt_voxels": int(target.sum()),
    }


def save_slice_payload(
    path: Path,
    ct: np.ndarray,
    target: np.ndarray,
    correct_logits: np.ndarray,
    swapped_logits: np.ndarray,
) -> None:
    z = int(np.argmax(target.reshape(target.shape[0], -1).sum(axis=1)))
    np.savez_compressed(
        path,
        ct=ct[z].astype(np.float32),
        gt=target[z].astype(np.uint8),
        correct_probability=(1.0 / (1.0 + np.exp(-correct_logits[z].astype(np.float32)))).astype(np.float32),
        swapped_probability=(1.0 / (1.0 + np.exp(-swapped_logits[z].astype(np.float32)))).astype(np.float32),
        absolute_logit_difference=np.abs(
            correct_logits[z].astype(np.float32) - swapped_logits[z].astype(np.float32)
        ),
        z=np.asarray(z),
    )


def stage_metadata(stage: str) -> tuple[int, str]:
    if stage == "text_projection":
        return 0, "text projection"
    match = re.match(r"prompt_decoder_layer_(\d+)", stage)
    if match:
        return int(match.group(1)), f"decoder L{match.group(1)}"
    if stage == "prompt_decoder_final_norm":
        return 7, "decoder norm"
    match = re.match(r"multiscale_mask_projection_(\d+)", stage)
    if match:
        index = int(match.group(1))
        return 8 + index, f"scale proj {index}"
    return 99, stage


def choose_visualizations(frame: pd.DataFrame, maximum: int) -> list[str]:
    selected: list[str] = []

    def add(row: pd.Series | None) -> None:
        if row is not None and row["pair_id"] not in selected:
            selected.append(str(row["pair_id"]))

    add(frame.loc[frame["mean_absolute_logit_difference"].idxmax()])
    add(frame.loc[frame["mean_absolute_logit_difference"].idxmin()])
    lateral = frame[frame["swap_type"] == "laterality"]
    vertical = frame[frame["swap_type"] == "upper_lower"]
    add(lateral.loc[lateral["mean_absolute_logit_difference"].idxmax()] if not lateral.empty else None)
    add(vertical.loc[vertical["mean_absolute_logit_difference"].idxmax()] if not vertical.empty else None)
    ratio = frame["qwen_changed_token_span_relative_l2"] / (
        frame["mean_absolute_logit_difference"] + 1e-8
    )
    add(frame.loc[ratio.idxmax()])
    shifts = frame.dropna(subset=["largest_component_centroid_shift_voxels"])
    add(shifts.loc[shifts["largest_component_centroid_shift_voxels"].idxmax()] if not shifts.empty else None)
    return selected[:maximum]


def make_visualizations(
    frame: pd.DataFrame,
    stage_frame: pd.DataFrame,
    pairs: list[dict[str, Any]],
    payload_dir: Path,
    output_dir: Path,
    maximum: int,
) -> list[str]:
    vis_dir = output_dir / "visualizations"
    vis_dir.mkdir(exist_ok=True)
    pair_map = {pair["pair_id"]: pair for pair in pairs}
    selected = choose_visualizations(frame, maximum)
    for pair_id in selected:
        row = frame.loc[frame["pair_id"] == pair_id].iloc[0]
        pair = pair_map[pair_id]
        with np.load(payload_dir / f"{pair_id}.npz") as payload_file:
            payload = {key: payload_file[key].copy() for key in payload_file.files}
        stage = stage_frame.loc[stage_frame["pair_id"] == pair_id].copy()
        ordered = sorted(
            ((stage_metadata(value), value) for value in stage["stage"]),
            key=lambda item: item[0][0],
        )
        stage_names = [item[1] for item in ordered]
        labels = [item[0][1] for item in ordered]
        sensitivities = [
            float(stage.loc[stage["stage"] == name, "normalized_sensitivity"].iloc[0])
            for name in stage_names
        ]
        fig = plt.figure(figsize=(16, 9), constrained_layout=True)
        grid = fig.add_gridspec(2, 3)
        axes = [fig.add_subplot(grid[0, index]) for index in range(3)]
        axes.extend([fig.add_subplot(grid[1, index]) for index in range(3)])
        ct = payload["ct"]
        gt = payload["gt"].astype(bool)
        low, high = np.percentile(ct, [1, 99])
        axes[0].imshow(ct, cmap="gray", vmin=low, vmax=high)
        if gt.any():
            axes[0].contour(gt, [0.5], colors="lime", linewidths=1.3)
        axes[0].set_title(f"CT + GT (green), slice {int(payload['z'])}")
        prob_low = min(
            float(np.percentile(payload["correct_probability"], 1)),
            float(np.percentile(payload["swapped_probability"], 1)),
        )
        prob_high = max(
            float(np.percentile(payload["correct_probability"], 99)),
            float(np.percentile(payload["swapped_probability"], 99)),
        )
        for ax, key, title in (
            (axes[1], "correct_probability", "Correct-prompt probability"),
            (axes[2], "swapped_probability", "Swapped-prompt probability"),
        ):
            image = ax.imshow(payload[key], cmap="magma", vmin=prob_low, vmax=prob_high)
            if gt.any():
                ax.contour(gt, [0.5], colors="lime", linewidths=1.0)
            ax.set_title(title)
        fig.colorbar(image, ax=axes[1:3], shrink=0.75)
        difference_image = axes[3].imshow(payload["absolute_logit_difference"], cmap="inferno")
        if gt.any():
            axes[3].contour(gt, [0.5], colors="cyan", linewidths=1.0)
        axes[3].set_title("Absolute logit difference")
        fig.colorbar(difference_image, ax=axes[3], shrink=0.75)
        axes[4].axis("off")
        axes[4].text(
            0.0,
            1.0,
            "Correct:\n"
            + pair["original_prompt"]
            + "\n\nSwap:\n"
            + pair["swapped_prompt"]
            + "\n\n"
            + f"logit r={row['logit_pearson']:.6f}\n"
            + f"logit MAD={row['mean_absolute_logit_difference']:.5g}\n"
            + f"correct−swap Dice={row['correct_minus_swap_dice']:+.5g}",
            ha="left",
            va="top",
            wrap=True,
            fontsize=9,
        )
        axes[4].set_title("Prompt pair and output metrics")
        axes[5].plot(range(len(sensitivities)), sensitivities, marker="o", linewidth=1.5)
        axes[5].set_xticks(range(len(labels)), labels, rotation=55, ha="right", fontsize=7)
        axes[5].set_ylabel("normalized sensitivity")
        axes[5].set_yscale("log")
        axes[5].grid(alpha=0.25)
        axes[5].set_title("Prompt-conditioned feature trace")
        for ax in (axes[0], axes[1], axes[2], axes[3]):
            ax.axis("off")
        fig.suptitle(f"{pair_id} ({pair['swap_type']})", fontsize=12)
        fig.savefig(vis_dir / f"{pair_id}.png", dpi=160)
        plt.close(fig)
    return selected


def bootstrap_ci(values: Iterable[float], samples: int, seed: int) -> list[float]:
    array = np.asarray(list(values), dtype=np.float64)
    array = array[np.isfinite(array)]
    if array.size == 0:
        return [float("nan"), float("nan")]
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, array.size, size=(samples, array.size))
    means = array[indices].mean(axis=1)
    return [float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))]


def descriptive(values: Iterable[float], samples: int, seed: int) -> dict[str, Any]:
    array = np.asarray(list(values), dtype=np.float64)
    array = array[np.isfinite(array)]
    if array.size == 0:
        return {"n": 0}
    q25, q75 = np.percentile(array, [25, 75])
    tolerance = 1e-12
    return {
        "n": int(array.size),
        "mean": float(array.mean()),
        "median": float(np.median(array)),
        "std": float(array.std(ddof=1)) if array.size > 1 else 0.0,
        "q25": float(q25),
        "q75": float(q75),
        "iqr": float(q75 - q25),
        "positive": int(np.sum(array > tolerance)),
        "negative": int(np.sum(array < -tolerance)),
        "unchanged": int(np.sum(np.abs(array) <= tolerance)),
        "paired_bootstrap_mean_95ci": bootstrap_ci(array, samples, seed),
    }


KEY_PAIR_METRICS = [
    "qwen_pooled_relative_l2",
    "qwen_changed_token_span_relative_l2",
    "qwen_full_token_sequence_relative_l2",
    "correct_minus_swap_gt_logit_margin",
    "correct_minus_swap_dice",
    "correct_minus_swap_predicted_volume_voxels",
    "mean_absolute_logit_difference",
    "logit_pearson",
    "probability_pearson",
    "binary_mask_dice_correct_vs_swap",
    "largest_component_centroid_shift_voxels",
]


def aggregate_results(
    frame: pd.DataFrame,
    stage_frame: pd.DataFrame,
    args: argparse.Namespace,
) -> dict[str, Any]:
    groups = {
        "laterality": frame[frame["swap_type"] == "laterality"],
        "upper_lower": frame[frame["swap_type"] == "upper_lower"],
        "all": frame,
    }
    by_group: dict[str, Any] = {}
    for group_index, (name, group) in enumerate(groups.items()):
        by_group[name] = {
            metric: descriptive(
                group[metric], args.bootstrap_samples, args.seed + group_index * 100 + index
            )
            for index, metric in enumerate(KEY_PAIR_METRICS)
        }
    stage_groups: dict[str, Any] = {}
    for group_name in ("laterality", "upper_lower", "all"):
        source = (
            stage_frame
            if group_name == "all"
            else stage_frame[stage_frame["swap_type"] == group_name]
        )
        stage_groups[group_name] = {}
        for stage_index, (stage, group) in enumerate(source.groupby("stage", sort=False)):
            stage_groups[group_name][stage] = {
                metric: descriptive(
                    group[metric],
                    args.bootstrap_samples,
                    args.seed + 1000 + stage_index,
                )
                for metric in (
                    "cosine_similarity",
                    "relative_l2_difference",
                    "correct_representation_norm",
                    "difference_norm",
                    "normalized_sensitivity",
                )
            }
    return {"pair_metrics": by_group, "stage_metrics": stage_groups}


def prior_artifacts() -> dict[str, str]:
    return {
        "correct_vs_shuffled_native_response_report": str(
            ROOT
            / "outputs/archived_experiment_records/20260728/result_folder_first_wave"
            / "historical_predictions/native_response_attention_minipilot_v1"
            / "native_response_audit_anchor85_step3800_v3/native_response_report.md"
        ),
        "correct_vs_shuffled_native_response_metrics": str(
            ROOT
            / "outputs/archived_experiment_records/20260728/result_folder_first_wave"
            / "historical_predictions/native_response_attention_minipilot_v1"
            / "native_response_audit_anchor85_step3800_v3/native_response_metrics.csv"
        ),
        "anatomy_residual_correct_vs_swapped_report": str(
            ROOT / "outputs/anatomy_residual_s3_pilot/paired_subset_eval_update200/report.md"
        ),
        "anatomy_residual_correct_vs_swapped_metrics": str(
            ROOT
            / "outputs/anatomy_residual_s3_pilot/paired_subset_eval_update200"
            / "per_finding_correct_vs_swap.csv"
        ),
    }


def decide(aggregate: dict[str, Any]) -> dict[str, str]:
    all_stats = aggregate["pair_metrics"]["all"]
    token = all_stats["qwen_changed_token_span_relative_l2"]["median"]
    pooled = all_stats["qwen_pooled_relative_l2"]["median"]
    logit_corr = all_stats["logit_pearson"]["median"]
    dice_delta = abs(all_stats["correct_minus_swap_dice"]["median"])
    token_sensitive = token >= 0.01
    pooling_suppresses = pooled < 0.5 * token
    final_weak = logit_corr >= 0.99 and dice_delta < 0.01
    if token_sensitive and pooling_suppresses:
        return {
            "sensitivity_loss_location": "pooled text embedding",
            "p1_prompt_composer": "GO",
            "recommended_next_experiment": "frozen-Qwen token-level Prompt Composer",
            "rationale": "Changed-token representations are responsive, while last-token pooling suppresses most of that response.",
        }
    if token_sensitive and not pooling_suppresses and final_weak:
        return {
            "sensitivity_loss_location": "prompt decoder/image-text fusion or segmentation decoder",
            "p1_prompt_composer": "NO-GO",
            "recommended_next_experiment": "modify the prompt decoder or image-text fusion",
            "rationale": "Pooled Qwen embeddings remain responsive, but final segmentation is comparatively insensitive.",
        }
    if not token_sensitive:
        return {
            "sensitivity_loss_location": "frozen Qwen token representations",
            "p1_prompt_composer": "NO-GO",
            "recommended_next_experiment": "consider Qwen LoRA as a later controlled experiment",
            "rationale": "Even the changed-token representations show weak sensitivity.",
        }
    return {
        "sensitivity_loss_location": "no complete collapse before final logits",
        "p1_prompt_composer": "NO-GO",
        "recommended_next_experiment": "inspect whether output movement targets correct anatomy versus diffuse false positives",
        "rationale": "Final logits are already location-sensitive; the remaining question is whether the movement is anatomically useful.",
    }


def fmt(stats: dict[str, Any]) -> str:
    return (
        f"{stats['mean']:.6g} (median {stats['median']:.6g}, "
        f"95% CI {stats['paired_bootstrap_mean_95ci'][0]:.6g} to "
        f"{stats['paired_bootstrap_mean_95ci'][1]:.6g})"
    )


def write_report(
    args: argparse.Namespace,
    config: dict[str, Any],
    pairs: list[dict[str, Any]],
    exclusions: list[dict[str, Any]],
    frame: pd.DataFrame,
    stage_frame: pd.DataFrame,
    aggregate: dict[str, Any],
    decision: dict[str, str],
) -> None:
    all_stats = aggregate["pair_metrics"]["all"]
    stage_all = aggregate["stage_metrics"]["all"]
    stage_lines = []
    ordered_stages = sorted(stage_all, key=lambda name: stage_metadata(name)[0])
    for stage in ordered_stages:
        stat = stage_all[stage]["normalized_sensitivity"]
        stage_lines.append(f"| {stage} | {stat['mean']:.6g} | {stat['median']:.6g} |")
    exclusion_counts = Counter(row["exclusion_reason"] for row in exclusions)
    prompt_examples = "\n".join(
        f"- `{pair['swap_type']}`: {pair['original_prompt']} → {pair['swapped_prompt']}"
        for pair in pairs[:6]
    )
    lines = [
        "# P0 Minimal Location-Swap Trace — Anchor85 fixed30",
        "",
        "## 1. Execution summary",
        "",
        f"- Checkpoint: `{args.checkpoint}`",
        f"- Fixed30 manifest: `{args.fixed30_manifest}`",
        f"- Exact selected-findings file: `{args.selected_findings}` (SHA-256 `{EXPECTED_SELECTED_SHA256}`)",
        f"- GPU: {config['gpu']}",
        f"- Runtime: {config['runtime_seconds'] / 60:.2f} minutes",
        f"- Scope: {frame.case_id.nunique()} cases, {frame.finding_id.groupby(frame.case_id).nunique().sum()} eligible case-findings, {len(frame)} prompt pairs",
        f"- Threshold: {args.threshold}; inference geometry and preprocessing are the unchanged VoxTell fixed30 path.",
        "- Inference-only: no optimizer, training loop, backward pass, or parameter update was created.",
        f"- Frozen-parameter verification: Qwen digest unchanged={config['validation']['qwen_parameters_unchanged']}; VoxTell digest unchanged={config['validation']['voxtell_parameters_unchanged']}.",
        f"- No gradients created: {config['validation']['no_gradients_created']}.",
        "",
        "## 2. Prompt-pair audit",
        "",
        f"- Eligible findings: {len({(p['case_id'], p['finding_id']) for p in pairs})}.",
        f"- Laterality pairs: {sum(p['swap_type'] == 'laterality' for p in pairs)}.",
        f"- Upper/lower pairs: {sum(p['swap_type'] == 'upper_lower' for p in pairs)}.",
        f"- Fully excluded findings: {len({(x['case_id'], x['finding_id']) for x in exclusions if x['finding_fully_excluded']})}.",
        f"- Ineligible swap attempts by reason: `{dict(exclusion_counts)}`. The exclusion CSV marks whether the finding still supports the other swap type.",
        "- Every saved pair passed the exactly-one-location-attribute and identical-non-location-text checks.",
        "",
        prompt_examples,
        "",
        "## 3. Qwen sensitivity",
        "",
        f"- Changed-token-span relative L2: {fmt(all_stats['qwen_changed_token_span_relative_l2'])}.",
        f"- Full token-sequence relative L2: {fmt(all_stats['qwen_full_token_sequence_relative_l2'])}.",
        f"- Current last-token pooled relative L2: {fmt(all_stats['qwen_pooled_relative_l2'])}.",
        f"- Median changed-span / pooled sensitivity ratio: "
        f"{all_stats['qwen_changed_token_span_relative_l2']['median'] / (all_stats['qwen_pooled_relative_l2']['median'] + EPS):.4g}.",
        "- Offset mappings, token IDs, attention masks, decoded token pieces, changed spans, and unchanged-token alignments are saved in `prompt_pairs.json`.",
        "",
        "## 4. Prompt decoder/fusion sensitivity",
        "",
        "| Stage | Mean normalized sensitivity | Median |",
        "|---|---:|---:|",
        *stage_lines,
        "",
        "- The strongest local attenuation is at `multiscale_mask_projection_0/1` "
        "(median normalized sensitivity about 0.14 versus 0.74 after final prompt-decoder "
        "normalization), while projections 3/4 retain about 0.74–0.76 and final logits "
        "remain strongly prompt-sensitive. This is attenuation, not an end-to-end collapse.",
        f"- Inferred loss point: **{decision['sensitivity_loss_location']}**.",
        "",
        "## 5. Final segmentation sensitivity",
        "",
        f"- Logit Pearson correlation: {fmt(all_stats['logit_pearson'])}.",
        f"- Probability Pearson correlation: {fmt(all_stats['probability_pearson'])}.",
        f"- Mean absolute logit difference: {fmt(all_stats['mean_absolute_logit_difference'])}.",
        f"- Correct-minus-swap GT logit margin: {fmt(all_stats['correct_minus_swap_gt_logit_margin'])}.",
        f"- Correct-minus-swap Dice: {fmt(all_stats['correct_minus_swap_dice'])}.",
        f"- Correct-minus-swap foreground volume (voxels): {fmt(all_stats['correct_minus_swap_predicted_volume_voxels'])}.",
        f"- Correct/swap binary-mask Dice: {fmt(all_stats['binary_mask_dice_correct_vs_swap'])}.",
        f"- Largest-component centroid shift (voxels): {fmt(all_stats['largest_component_centroid_shift_voxels'])}.",
        "",
        "## 6. Relationship to previous experiments",
        "",
        f"- Correct-vs-shuffled native response audit: `{prior_artifacts()['correct_vs_shuffled_native_response_report']}`.",
        f"- Anatomy residual correct-vs-swapped evaluation: `{prior_artifacts()['anatomy_residual_correct_vs_swapped_report']}`.",
        "- Those artifacts were read for context and were not rerun. This audit adds a controlled one-attribute language intervention and traces it from Qwen tokens through pooling, all prompt-decoder layers, all five mask projections, and final logits.",
        "",
        "## 7. Decision for P1",
        "",
        f"- **{decision['p1_prompt_composer']}** for a token-level Prompt Composer pilot.",
        f"- Recommended next experiment: **{decision['recommended_next_experiment']}**.",
        f"- Rationale: {decision['rationale']}",
        "",
        "## Statistical limitation",
        "",
        "The paired bootstrap treats prompt pairs as the descriptive sampling unit. Findings from the same CT case are not independent, and this small conservative subset is not a basis for strong significance claims.",
        "",
        "Full group-wise mean, median, standard deviation, IQR, signs, and paired bootstrap intervals are in `aggregate.json`.",
    ]
    (args.output_dir / "report.md").write_text("\n".join(lines) + "\n")


def get_gpu_name() -> str:
    if not torch.cuda.is_available():
        return "CUDA unavailable"
    return torch.cuda.get_device_name(torch.device("cuda:0"))


def get_git_state(path: Path) -> dict[str, Any]:
    try:
        commit = subprocess.check_output(
            ["git", "-C", str(path), "rev-parse", "HEAD"], text=True
        ).strip()
        status = subprocess.check_output(
            ["git", "-C", str(path), "status", "--short"], text=True
        ).splitlines()
        return {"commit": commit, "dirty_entries": status}
    except (subprocess.CalledProcessError, FileNotFoundError):
        return {"commit": None, "dirty_entries": []}


def initial_config(
    args: argparse.Namespace,
    pairs: list[dict[str, Any]],
    exclusions: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "audit": "p0_minimal_location_swap_trace_anchor85_fixed30",
        "created_at_unix": time.time(),
        "checkpoint": str(args.checkpoint.resolve()),
        "checkpoint_sha256": sha256_file(args.checkpoint),
        "fixed30_manifest": str(args.fixed30_manifest.resolve()),
        "fixed30_manifest_sha256": sha256_file(args.fixed30_manifest),
        "selected_findings": str(args.selected_findings.resolve()),
        "selected_findings_sha256": sha256_file(args.selected_findings),
        "rex_json": str(args.rex_json.resolve()),
        "image_dir": str(args.image_dir.resolve()),
        "mask_dir": str(args.mask_dir.resolve()),
        "model_dir": str(args.model_dir.resolve()),
        "text_model": args.text_model,
        "threshold": args.threshold,
        "device": args.device,
        "seed": args.seed,
        "bootstrap_samples": args.bootstrap_samples,
        "eligible_findings": len({(p["case_id"], p["finding_id"]) for p in pairs}),
        "pairs": len(pairs),
        "laterality_pairs": sum(p["swap_type"] == "laterality" for p in pairs),
        "upper_lower_pairs": sum(p["swap_type"] == "upper_lower" for p in pairs),
        "exclusion_records": len(exclusions),
        "strict_inference_only": True,
        "optimizer_created": False,
        "backward_called": False,
        "parameter_updates": False,
        "gt_used_as_model_input": False,
        "image_feature_reuse": (
            "Disabled after preflight: multi-prompt batching changed float16 logits "
            "relative to the fixed30 one-prompt path. Each condition therefore uses "
            "the unchanged normal one-prompt sliding-window forward path."
        ),
        "command": " ".join([sys.executable, *sys.argv]),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "slurm_node": os.environ.get("SLURMD_NODENAME"),
        "host": platform.node(),
        "python": sys.version,
        "torch": torch.__version__,
        "repository_git": get_git_state(ROOT),
        "voxtell_git": get_git_state(ROOT / "VoxTell"),
        "prior_artifacts_not_rerun": prior_artifacts(),
    }


def main() -> int:
    args = parse_args()
    started = time.time()
    if abs(args.threshold - 0.5) > 1e-12:
        raise ValueError("The existing fixed30 threshold is exactly 0.5")
    selected, entries = read_selected(args)
    pairs, eligible, exclusions = generate_pairs(selected, entries)
    write_prompt_audit(args, pairs, eligible, exclusions)
    config = initial_config(args, pairs, exclusions)
    write_json(args.output_dir / "audit_config.json", config)
    (args.output_dir / "run_command.txt").write_text(config["command"] + "\n")
    if args.prepare_only:
        print("Preparation-only prompt audit complete.", flush=True)
        return 0
    if not torch.cuda.is_available():
        raise RuntimeError("Full audit requires one CUDA GPU")

    device = torch.device(args.device)
    predictor = VoxTellPredictor(
        str(args.model_dir),
        device=device,
        text_encoding_model=args.text_model,
        checkpoint_path=str(args.checkpoint),
    )
    network = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    network.requires_grad_(False)
    network.eval()
    voxtell_before = tensor_digest(network)
    pooled_map, _qwen_records, qwen_digests = extract_qwen(
        predictor, pairs, args.qwen_batch_size
    )
    write_json(args.output_dir / "prompt_pairs.json", pairs)
    predictor.text_backbone = None
    gc.collect()
    torch.cuda.empty_cache()

    pair_map = {pair["pair_id"]: pair for pair in pairs}
    pairs_by_case: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for pair in pairs:
        pairs_by_case[pair["case_id"]].append(pair)

    # Required preflight: unchanged existing inference path versus hooked path.
    validation_pair = pairs[0]
    validation_case = validation_pair["case_id"]
    validation_entry = entries[validation_case]
    image, properties = load_image(args.image_dir / validation_case)
    data, bbox, _ = predictor.preprocess(image)
    targets = load_rex_masks_in_preprocessed_ras(
        args.mask_dir / validation_case,
        properties,
        len(sorted_prompts(validation_entry)),
        bbox,
    ).numpy().astype(bool)
    single_embedding = pooled_map[validation_pair["original_prompt"]][None, None]
    existing_logits = predictor.predict_sliding_window_return_logits(data, single_embedding)
    validation_trace = SinglePromptTrace()
    validation_trace.install(network)
    instrumented_logits = predictor.predict_sliding_window_return_logits(data, single_embedding)
    validation_trace.close()
    max_abs_validation = float(
        torch.max(torch.abs(existing_logits[0].float() - instrumented_logits[0].float())).cpu()
    )
    validation_target = targets[int(validation_pair["finding_id"])]
    existing_mask = torch.sigmoid(existing_logits[0].float()).cpu().numpy() >= args.threshold
    instrumented_mask = (
        torch.sigmoid(instrumented_logits[0].float()).cpu().numpy() >= args.threshold
    )
    validation = {
        "case_id": validation_case,
        "finding_id": validation_pair["finding_id"],
        "existing_vs_instrumented_max_abs_logit_difference": max_abs_validation,
        "binary_masks_identical": bool(np.array_equal(existing_mask, instrumented_mask)),
        "existing_dice": dice(existing_mask, validation_target),
        "instrumented_dice": dice(instrumented_mask, validation_target),
        "instrumentation_tolerance": 1e-5,
    }
    if (
        max_abs_validation > validation["instrumentation_tolerance"]
        or not validation["binary_masks_identical"]
        or abs(validation["existing_dice"] - validation["instrumented_dice"]) > EPS
    ):
        write_json(args.output_dir / "validation_failure.json", validation)
        raise RuntimeError(f"Instrumentation changed model output materially: {validation}")
    del existing_logits, instrumented_logits, image, data, targets
    gc.collect()
    torch.cuda.empty_cache()

    metric_rows: list[dict[str, Any]] = []
    stage_rows: list[dict[str, Any]] = []
    payload_dir = args.output_dir / ".visualization_payloads"
    if payload_dir.exists():
        shutil.rmtree(payload_dir)
    payload_dir.mkdir(exist_ok=True)
    for case_index, case_id in enumerate(sorted(pairs_by_case), start=1):
        case_pairs = pairs_by_case[case_id]
        print(
            f"Case {case_index}/{len(pairs_by_case)}: {case_id} "
            f"({len(case_pairs)} pairs)",
            flush=True,
        )
        entry = entries[case_id]
        image, properties = load_image(args.image_dir / case_id)
        data, bbox, _ = predictor.preprocess(image)
        targets = load_rex_masks_in_preprocessed_ras(
            args.mask_dir / case_id,
            properties,
            len(sorted_prompts(entry)),
            bbox,
        ).numpy().astype(bool)
        ct = data[0].numpy()
        for pair_index, pair in enumerate(case_pairs, start=1):
            print(
                f"  Pair {pair_index}/{len(case_pairs)}: {pair['pair_id']}",
                flush=True,
            )
            correct_trace = SinglePromptTrace()
            correct_trace.install(network)
            correct_logits_t = predictor.predict_sliding_window_return_logits(
                data, pooled_map[pair["original_prompt"]][None, None]
            )
            correct_trace.close()
            swap_trace = SinglePromptTrace()
            swap_trace.install(network)
            swapped_logits_t = predictor.predict_sliding_window_return_logits(
                data, pooled_map[pair["swapped_prompt"]][None, None]
            )
            swap_trace.close()
            stage_rows.extend(
                compare_single_prompt_traces(pair, correct_trace, swap_trace)
            )
            finding_id = int(pair["finding_id"])
            correct = correct_logits_t[0].float().cpu().numpy()
            swap = swapped_logits_t[0].float().cpu().numpy()
            row = segmentation_row(
                pair, correct, swap, targets[finding_id], args.threshold
            )
            metric_rows.append(row)
            save_slice_payload(
                payload_dir / f"{pair['pair_id']}.npz",
                ct,
                targets[finding_id],
                correct,
                swap,
            )
            del correct_logits_t, swapped_logits_t, correct, swap
            gc.collect()
            torch.cuda.empty_cache()
        del image, data, targets
        gc.collect()
        torch.cuda.empty_cache()

    metric_frame = pd.DataFrame(metric_rows)
    stage_frame = pd.DataFrame(stage_rows)
    metric_frame.to_csv(args.output_dir / "per_pair_metrics.csv", index=False)
    stage_frame.to_csv(args.output_dir / "per_stage_feature_metrics.csv", index=False)
    selected_visualizations = make_visualizations(
        metric_frame,
        stage_frame,
        pairs,
        payload_dir,
        args.output_dir,
        args.max_visualizations,
    )
    shutil.rmtree(payload_dir)

    aggregate = aggregate_results(metric_frame, stage_frame, args)
    decision = decide(aggregate)
    aggregate.update(
        {
            "counts": {
                "cases": int(metric_frame["case_id"].nunique()),
                "eligible_findings": len(
                    set(zip(metric_frame["case_id"], metric_frame["finding_id"]))
                ),
                "pairs": len(metric_frame),
                "laterality_pairs": int((metric_frame["swap_type"] == "laterality").sum()),
                "upper_lower_pairs": int((metric_frame["swap_type"] == "upper_lower").sum()),
            },
            "decision": decision,
            "selected_visualizations": selected_visualizations,
        }
    )
    write_json(args.output_dir / "aggregate.json", aggregate)

    network.to("cpu")
    voxtell_after = tensor_digest(network)
    no_gradients = all(parameter.grad is None for parameter in network.parameters())
    validation.update(
        {
            "qwen_parameter_digest_before": qwen_digests["before"],
            "qwen_parameter_digest_after": qwen_digests["after"],
            "qwen_parameters_unchanged": qwen_digests["before"] == qwen_digests["after"],
            "voxtell_parameter_digest_before": voxtell_before,
            "voxtell_parameter_digest_after": voxtell_after,
            "voxtell_parameters_unchanged": voxtell_before == voxtell_after,
            "no_gradients_created": no_gradients,
        }
    )
    if not validation["voxtell_parameters_unchanged"] or not no_gradients:
        raise RuntimeError("Frozen VoxTell parameter/no-gradient verification failed")
    runtime = time.time() - started
    config.update(
        {
            "completed": True,
            "runtime_seconds": runtime,
            "gpu": get_gpu_name(),
            "validation": validation,
            "visualizations": selected_visualizations,
        }
    )
    write_json(args.output_dir / "audit_config.json", config)
    write_report(
        args, config, pairs, exclusions, metric_frame, stage_frame, aggregate, decision
    )
    print(json.dumps(json_ready({"counts": aggregate["counts"], "decision": decision}), indent=2))
    print(f"Audit completed in {runtime / 60:.2f} minutes: {args.output_dir}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
