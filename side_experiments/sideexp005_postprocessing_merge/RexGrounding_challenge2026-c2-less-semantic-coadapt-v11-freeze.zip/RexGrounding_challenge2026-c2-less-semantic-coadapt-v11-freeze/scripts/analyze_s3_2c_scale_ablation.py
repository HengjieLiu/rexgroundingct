#!/usr/bin/env python3
"""Collect paired 2c scale-ablation results against the all-scale reference."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


POLICIES = ("drop_1over4", "drop_1over2", "drop_1over1", "all_off")
KEYS = ["file", "finding_idx"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--all-on-metrics", type=Path, required=True)
    parser.add_argument("--ablation-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def category_2c(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    return frame.loc[frame["category"].astype(str).eq("2c")].copy()


def rollup(label: str, frame: pd.DataFrame, delta: pd.Series) -> dict:
    tp = float(frame["tp_voxels"].sum())
    fp = float(frame["fp_voxels"].sum())
    fn = float(frame["fn_voxels"].sum())
    return {
        "policy": label,
        "n": int(len(frame)),
        "mean_dice": float(frame["global_dice"].mean()),
        "mean_precision": float(frame["voxel_precision"].mean()),
        "mean_recall": float(frame["voxel_recall"].mean()),
        "micro_precision": tp / max(tp + fp, 1.0),
        "micro_recall": tp / max(tp + fn, 1.0),
        "mean_pred_gt_volume_ratio": float(frame["pred_gt_volume_ratio"].mean()),
        "hits": int(frame["global_hit"].sum()),
        "mean_dice_delta_vs_all_on": float(delta.mean()),
        "median_dice_delta_vs_all_on": float(delta.median()),
        "improved_findings": int((delta > 1e-6).sum()),
        "worsened_findings": int((delta < -1e-6).sum()),
        "unchanged_findings": int((delta.abs() <= 1e-6).sum()),
    }


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    reference = category_2c(args.all_on_metrics).sort_values(KEYS).reset_index(drop=True)
    rows = [rollup("all_on", reference, pd.Series(np.zeros(len(reference))))]
    details = []
    for policy in POLICIES:
        path = args.ablation_root / policy / "hybrid" / "per_finding_metrics.csv"
        candidate = category_2c(path)
        paired = reference.merge(
            candidate,
            on=KEYS,
            suffixes=("_all_on", "_candidate"),
            validate="one_to_one",
        )
        if len(paired) != len(reference):
            raise RuntimeError(f"{policy}: expected {len(reference)} paired 2c findings, got {len(paired)}")
        delta = paired["global_dice_candidate"] - paired["global_dice_all_on"]
        rows.append(rollup(policy, candidate, delta))
        paired["policy"] = policy
        paired["dice_delta_vs_all_on"] = delta
        paired["precision_delta_vs_all_on"] = (
            paired["voxel_precision_candidate"] - paired["voxel_precision_all_on"]
        )
        paired["recall_delta_vs_all_on"] = (
            paired["voxel_recall_candidate"] - paired["voxel_recall_all_on"]
        )
        details.append(paired)
    summary = pd.DataFrame(rows).sort_values("mean_dice", ascending=False)
    summary.to_csv(args.output_dir / "scale_ablation_summary.csv", index=False)
    pd.concat(details, ignore_index=True).to_csv(
        args.output_dir / "scale_ablation_per_finding.csv", index=False
    )
    best = summary.iloc[0]
    report = {
        "best_policy": str(best["policy"]),
        "best_mean_dice": float(best["mean_dice"]),
        "all_on_mean_dice": float(
            summary.loc[summary["policy"].eq("all_on"), "mean_dice"].iloc[0]
        ),
        "rows": summary.to_dict(orient="records"),
    }
    (args.output_dir / "scale_ablation_summary.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
