#!/usr/bin/env python3
"""Finalize the matched B3/B3+LESS and within-checkpoint LESS-bypass audit."""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np


CATEGORY_NAMES = {
    "1a": "Bronchial wall thickening",
    "1b": "Bronchiectasis",
    "1c": "Emphysema",
    "1d": "Septal thickening / reticulation",
    "1e": "Micronodules / tree-in-bud",
    "1f": "Other diffuse lung / airway / pleural",
    "2a": "Linear opacity / scarring / fibrosis",
    "2b": "Atelectasis / consolidation",
    "2c": "Ground-glass opacity",
    "2d": "Pulmonary nodules / masses",
    "2e": "Pleural effusion / thickening",
    "2f": "Honeycombing",
    "2g": "Pneumothorax",
    "2h": "Other focal lung / airway / pleural",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit-dir", type=Path, required=True)
    parser.add_argument("--b3-dir", type=Path, required=True)
    parser.add_argument("--normal-dir", type=Path, required=True)
    parser.add_argument("--bypass-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-replicates", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=260904)
    return parser.parse_args()


def read_rows(directory: Path) -> tuple[dict, dict[tuple[str, int], dict]]:
    summary = json.loads((directory / "summary.json").read_text())
    path = directory / "summary_tables/per_finding_metrics.csv"
    rows = {}
    with path.open(newline="") as handle:
        for row in csv.DictReader(handle):
            key = (str(row["file"]), int(row["finding_idx"]))
            if key in rows:
                raise ValueError(f"Duplicate finding key: {key}")
            rows[key] = row
    return summary, rows


def cluster_bootstrap(
    deltas: dict[tuple[str, int], float], replicates: int, seed: int
) -> dict[str, object]:
    by_case: dict[str, list[float]] = defaultdict(list)
    for (case, _), value in deltas.items():
        by_case[case].append(float(value))
    cases = sorted(by_case)
    generator = np.random.default_rng(seed)
    values = np.empty(replicates, dtype=np.float64)
    for index in range(replicates):
        sampled = generator.choice(cases, size=len(cases), replace=True)
        values[index] = np.concatenate(
            [np.asarray(by_case[case], dtype=np.float64) for case in sampled]
        ).mean()
    raw = np.asarray(list(deltas.values()), dtype=np.float64)
    return {
        "case_clusters": len(cases),
        "findings": int(raw.size),
        "mean_delta": float(raw.mean()),
        "median_delta": float(np.median(raw)),
        "ci95": [float(value) for value in np.quantile(values, [0.025, 0.975])],
        "replicates": int(replicates),
        "seed": int(seed),
    }


def anatomy_group(prompt: str) -> str:
    value = prompt.lower().replace("-", " ")
    mappings = {
        "RUL": [r"right upper lobe", r"upper lobe of the right", r"upper lobe.*right lung"],
        "RML": [r"right middle lobe", r"middle lobe of the right"],
        "RLL": [r"right lower lobe", r"lower lobe of the right", r"lower lobe.*right lung"],
        "LUL": [r"left upper lobe", r"upper lobe of the left", r"upper lobe.*left lung"],
        "LLL": [r"left lower lobe", r"lower lobe of the left", r"lower lobe.*left lung"],
    }
    matches = [name for name, patterns in mappings.items() if any(re.search(p, value) for p in patterns)]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1 or "both lung" in value or "bilateral" in value:
        return "bilateral/multilobe"
    if "right lung" in value or "right sided" in value:
        return "right-unspecified"
    if "left lung" in value or "left sided" in value:
        return "left-unspecified"
    return "no-explicit-anatomy"


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def markdown_table(headers: list[str], rows: list[list[object]]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] + ["---:"] * (len(headers) - 1)) + " |",
    ]
    lines.extend("| " + " | ".join(map(str, row)) + " |" for row in rows)
    return "\n".join(lines)


def main() -> int:
    args = parse_args()
    args.audit_dir.mkdir(parents=True, exist_ok=True)
    b3_summary, b3 = read_rows(args.b3_dir)
    normal_summary, normal = read_rows(args.normal_dir)
    bypass_summary, bypass = read_rows(args.bypass_dir)
    if not (b3.keys() == normal.keys() == bypass.keys()):
        raise RuntimeError(
            f"Finding keys differ: B3={len(b3)}, normal={len(normal)}, bypass={len(bypass)}"
        )
    if len(normal) != 381 or len({key[0] for key in normal}) != 200:
        raise RuntimeError("Audit inputs are not canonical full200 / 381 findings")

    gt_values = np.asarray([float(row["gt_voxels"]) for row in normal.values()])
    q25, q50, q75 = np.quantile(gt_values, [0.25, 0.5, 0.75])

    def size_bin(value: float) -> str:
        if value <= q25:
            return "Q1-smallest"
        if value <= q50:
            return "Q2"
        if value <= q75:
            return "Q3"
        return "Q4-largest"

    def difficulty(value: float) -> str:
        if value < 0.1:
            return "B3-miss(<0.1)"
        if value < 0.3:
            return "B3-low(0.1-0.3)"
        if value < 0.5:
            return "B3-mid(0.3-0.5)"
        return "B3-high(>=0.5)"

    rows: list[dict[str, object]] = []
    transitions = Counter()
    train_delta = {}
    bypass_delta = {}
    for key in sorted(normal):
        b3_row, normal_row, bypass_row = b3[key], normal[key], bypass[key]
        if not (
            b3_row["category"] == normal_row["category"] == bypass_row["category"]
            and b3_row["prompt"] == normal_row["prompt"] == bypass_row["prompt"]
        ):
            raise RuntimeError(f"Finding metadata mismatch: {key}")
        b3_dice = float(b3_row["global_dice"])
        normal_dice = float(normal_row["global_dice"])
        bypass_dice = float(bypass_row["global_dice"])
        b3_hit = str(b3_row["global_hit"]).lower() == "true"
        normal_hit = str(normal_row["global_hit"]).lower() == "true"
        bypass_hit = str(bypass_row["global_hit"]).lower() == "true"
        transition = ("HIT" if normal_hit else "MISS") + " -> " + (
            "HIT" if bypass_hit else "MISS"
        )
        transitions[transition] += 1
        train_delta[key] = normal_dice - b3_dice
        bypass_delta[key] = normal_dice - bypass_dice
        gt_voxels = float(normal_row["gt_voxels"])
        rows.append(
            {
                "case": key[0],
                "finding_id": key[1],
                "category": normal_row["category"],
                "category_name": CATEGORY_NAMES.get(normal_row["category"], "unknown"),
                "prompt": normal_row["prompt"],
                "anatomy_group": anatomy_group(normal_row["prompt"]),
                "gt_voxels": int(gt_voxels),
                "size_bin": size_bin(gt_voxels),
                "baseline_difficulty": difficulty(b3_dice),
                "b3_dice": b3_dice,
                "b3_hit": int(b3_hit),
                "normal_dice": normal_dice,
                "normal_hit": int(normal_hit),
                "bypass_dice": bypass_dice,
                "bypass_hit": int(bypass_hit),
                "training_delta_normal_minus_b3": normal_dice - b3_dice,
                "functional_delta_normal_minus_bypass": normal_dice - bypass_dice,
                "hit_transition": transition,
            }
        )

    per_finding_fields = list(rows[0])
    write_csv(args.audit_dir / "per_finding.csv", rows, per_finding_fields)
    write_csv(
        args.audit_dir / "hit_transitions.csv",
        rows,
        per_finding_fields,
    )

    training_bootstrap = cluster_bootstrap(
        train_delta, args.bootstrap_replicates, args.seed
    )
    bypass_bootstrap = cluster_bootstrap(
        bypass_delta, args.bootstrap_replicates, args.seed + 1
    )
    bootstrap = {
        "training_level_normal_minus_b3": training_bootstrap,
        "functional_normal_minus_bypass": bypass_bootstrap,
        "approximately_unchanged_tolerance": 1e-4,
    }
    (args.audit_dir / "bootstrap_summary.json").write_text(
        json.dumps(bootstrap, indent=2) + "\n"
    )

    def summarize_group(field: str) -> list[dict[str, object]]:
        groups: dict[str, list[dict[str, object]]] = defaultdict(list)
        for row in rows:
            groups[str(row[field])].append(row)
        result = []
        for group, group_rows in sorted(groups.items()):
            deltas = np.asarray(
                [float(row["functional_delta_normal_minus_bypass"]) for row in group_rows]
            )
            result.append(
                {
                    field: group,
                    "n": len(group_rows),
                    "normal_dice": float(np.mean([float(row["normal_dice"]) for row in group_rows])),
                    "bypass_dice": float(np.mean([float(row["bypass_dice"]) for row in group_rows])),
                    "mean_delta": float(deltas.mean()),
                    "median_delta": float(np.median(deltas)),
                    "normal_hit": int(sum(int(row["normal_hit"]) for row in group_rows)),
                    "bypass_hit": int(sum(int(row["bypass_hit"]) for row in group_rows)),
                }
            )
        return result

    stratified = {
        "category": summarize_group("category"),
        "size_bin": summarize_group("size_bin"),
        "anatomy_group": summarize_group("anatomy_group"),
        "baseline_difficulty": summarize_group("baseline_difficulty"),
        "size_quartile_boundaries_gt_voxels": [float(q25), float(q50), float(q75)],
    }
    (args.audit_dir / "stratified_summary.json").write_text(
        json.dumps(stratified, indent=2) + "\n"
    )

    functional = bypass_bootstrap["ci95"][0] > 0 or bypass_bootstrap["ci95"][1] < 0
    functional_direction = (
        "beneficial" if bypass_bootstrap["mean_delta"] > 0 else "harmful"
    )
    if functional:
        used = "YES"
    elif np.mean(np.abs(list(bypass_delta.values()))) <= 1e-4:
        used = "NO"
    else:
        used = "INCONCLUSIVE"
    if training_bootstrap["ci95"][0] > 0:
        net = "YES"
    elif training_bootstrap["ci95"][1] < 0:
        net = "NO"
    else:
        net = "INCONCLUSIVE"

    tolerance = 1e-4
    values = np.asarray(list(bypass_delta.values()), dtype=np.float64)
    improved = int(np.sum(values > tolerance))
    worsened = int(np.sum(values < -tolerance))
    unchanged = int(np.sum(np.abs(values) <= tolerance))

    category_rows = [
        [
            item["category"],
            CATEGORY_NAMES.get(str(item["category"]), "unknown"),
            item["n"],
            f'{item["normal_dice"]:.6f}',
            f'{item["bypass_dice"]:.6f}',
            f'{item["mean_delta"]:+.6f}',
            f'{item["normal_hit"]}/{item["bypass_hit"]}',
        ]
        for item in stratified["category"]
    ]
    size_rows = [
        [
            item["size_bin"], item["n"], f'{item["normal_dice"]:.6f}',
            f'{item["bypass_dice"]:.6f}', f'{item["mean_delta"]:+.6f}',
        ]
        for item in stratified["size_bin"]
    ]
    changed_hits = [row for row in rows if row["normal_hit"] != row["bypass_hit"]]
    changed_hit_rows = [
        [
            row["case"], row["finding_id"], row["category"], row["anatomy_group"],
            row["gt_voxels"], f'{row["normal_dice"]:.6f}',
            f'{row["bypass_dice"]:.6f}',
            f'{row["functional_delta_normal_minus_bypass"]:+.6f}', row["hit_transition"],
        ]
        for row in changed_hits
    ]

    normal_finding = float(normal_summary["mean_global_dice_per_finding"])
    bypass_finding = float(bypass_summary["mean_global_dice_per_finding"])
    b3_finding = float(b3_summary["mean_global_dice_per_finding"])
    primary_ci = bypass_bootstrap["ci95"]
    training_ci = training_bootstrap["ci95"]
    conclusion = (
        f"The same frozen B3+LESS checkpoint shows a {functional_direction} "
        f"mean inference-time LESS effect of {normal_finding-bypass_finding:+.6f} Dice; "
        f"the case-cluster 95% CI is [{primary_ci[0]:+.6f}, {primary_ci[1]:+.6f}]. "
        "This measures functional dependence under an out-of-distribution module "
        "intervention, not the counterfactual gain from training a matched model without LESS."
    )
    report = f"""# LESS functional contribution audit

B3:
case Dice `{float(b3_summary['mean_global_dice_per_case']):.6f}`
finding Dice `{b3_finding:.6f}`
HIT `{int(b3_summary['total_hits'])}/381`

B3+LESS NORMAL:
case Dice `{float(normal_summary['mean_global_dice_per_case']):.6f}`
finding Dice `{normal_finding:.6f}`
HIT `{int(normal_summary['total_hits'])}/381`

B3+LESS BYPASS:
case Dice `{float(bypass_summary['mean_global_dice_per_case']):.6f}`
finding Dice `{bypass_finding:.6f}`
HIT `{int(bypass_summary['total_hits'])}/381`

TRAINING-LEVEL LESS EFFECT:
B3+LESS - B3 = `{normal_finding-b3_finding:+.6f}`
case-cluster 95% CI `[{training_ci[0]:+.6f}, {training_ci[1]:+.6f}]`

INFERENCE-TIME LESS DEPENDENCE:
normal - bypass = `{normal_finding-bypass_finding:+.6f}`
case-cluster 95% CI `[{primary_ci[0]:+.6f}, {primary_ci[1]:+.6f}]`

HIT TRANSITIONS:
normal HIT -> bypass MISS: `{transitions['HIT -> MISS']}`
normal MISS -> bypass HIT: `{transitions['MISS -> HIT']}`

LESS FUNCTIONALLY USED:
`{used}`

LESS NET BENEFICIAL:
`{net}`

FINAL INTERPRETATION:
{conclusion}

## Provenance and interpretation scope

The matched training comparison uses update5000 for both arms. Both descend from
the same VoxTell v1.1 initialization and use the same 5000-update budget, BF16,
effective batch 4, sampler seed/order, segmentation loss, optimizer family, and
10k polynomial schedule. B3 was executed as 0-2000 plus a true 2000-5000 resume;
B3+LESS was executed continuously 0-5000. The only intended architecture/training
difference is the trainable LESS encoder conditioning at levels 2-5.

The normal-versus-bypass comparison is causal for whether the frozen checkpoint's
predictions depend on LESS computation. Bypass is not a matched training
counterfactual: downstream layers were not trained with LESS removed.

## Paired functional result

- Mean finding delta (normal - bypass): `{bypass_bootstrap['mean_delta']:+.6f}`
- Median delta: `{bypass_bootstrap['median_delta']:+.6f}`
- Meaningfully helped by LESS (`delta > {tolerance}`): `{improved}/381`
- Meaningfully harmed by LESS (`delta < -{tolerance}`): `{worsened}/381`
- Approximately unchanged: `{unchanged}/381`
- HIT -> HIT: `{transitions['HIT -> HIT']}`
- HIT -> MISS: `{transitions['HIT -> MISS']}`
- MISS -> HIT: `{transitions['MISS -> HIT']}`
- MISS -> MISS: `{transitions['MISS -> MISS']}`

## Pathology category

{markdown_table(['Category','Finding type','N','Normal','Bypass','Normal-Bypass','HIT N/B'], category_rows)}

Small categories should not be overinterpreted.

## Lesion size

GT-voxel quartile boundaries: `{q25:.1f}`, `{q50:.1f}`, `{q75:.1f}`.

{markdown_table(['Size bin','N','Normal','Bypass','Normal-Bypass'], size_rows)}

## HIT transitions that change status

{markdown_table(['Case','Finding','Cat','Anatomy','GT vox','Normal','Bypass','Delta','Transition'], changed_hit_rows) if changed_hit_rows else 'No HIT status transitions.'}

## Direct answers

1. Did B3+LESS outperform matched B3? **{net}** — observed delta `{normal_finding-b3_finding:+.6f}`.
2. Does bypassing LESS change predictions? **{'YES' if improved+worsened > 0 else 'NO'}** — `{improved+worsened}/381` findings changed by more than `{tolerance}` Dice.
3. Does bypassing LESS significantly reduce Full200 Dice? **{'YES' if primary_ci[0] > 0 else 'NO'}** — paired CI `[{primary_ci[0]:+.6f}, {primary_ci[1]:+.6f}]`.
4. How many HITs specifically depend on LESS? **{transitions['HIT -> MISS']}**.
5. Are there findings that improve when LESS is removed? **{'YES' if worsened else 'NO'}** — `{worsened}` findings improve by more than `{tolerance}` Dice, including `{transitions['MISS -> HIT']}` HIT-status gains.
6. Which groups benefit or are harmed most? See the pathology and size tables; conclusions should prioritize groups with adequate N.
7. Is LESS genuinely contributing useful inference-time information? **{used}**.
8. Is its net effect positive, neutral, or negative? **{'positive' if net == 'YES' else 'negative' if net == 'NO' else 'not confirmed'}** in the matched training comparison.
"""
    (args.audit_dir / "report.md").write_text(report)
    print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
