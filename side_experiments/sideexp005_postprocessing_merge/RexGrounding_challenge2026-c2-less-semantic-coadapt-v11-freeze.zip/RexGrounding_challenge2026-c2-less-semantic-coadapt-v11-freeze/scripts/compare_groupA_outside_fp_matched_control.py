#!/usr/bin/env python3
"""Compare the Group-A alpha=1 run with its matched alpha=0 continuation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


POLICIES = ("raw", "whole10", "semantic_v1")
SUBGROUPS = (
    "all",
    "A_explicit_exact_lobe",
    "B_ambiguous_lobe",
    "explicit_lobe_parser_defined",
    "C_laterality_only",
    "DE_whole_lung_fallback",
)


def markdown_table(frame: pd.DataFrame) -> str:
    shown = frame.copy()
    for column in shown.select_dtypes(include=[np.number]).columns:
        shown[column] = shown[column].map(
            lambda value: "" if pd.isna(value) else f"{float(value):.6f}"
        )
    lines = [
        "| " + " | ".join(map(str, shown.columns)) + " |",
        "| " + " | ".join("---" for _ in shown.columns) + " |",
    ]
    lines.extend(
        "| " + " | ".join(map(str, row)) + " |"
        for row in shown.itertuples(index=False, name=None)
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--alpha1-dir", type=Path, required=True)
    parser.add_argument("--lambda0-dir", type=Path, required=True)
    parser.add_argument("--update", type=int, default=100)
    args = parser.parse_args()

    relative = Path(f"subset30_eval_update{args.update}") / "subset_metrics.csv"
    alpha1 = pd.read_csv(args.alpha1_dir / relative)
    lambda0 = pd.read_csv(args.lambda0_dir / relative)
    keys = ["subgroup", "variant"]
    wanted = lambda frame: frame[
        frame["subgroup"].isin(SUBGROUPS) & frame["variant"].isin(POLICIES)
    ].copy()
    alpha1 = wanted(alpha1)
    lambda0 = wanted(lambda0)
    merged = alpha1.merge(
        lambda0,
        on=keys,
        suffixes=("_alpha1", "_lambda0"),
        validate="one_to_one",
    )
    if len(merged) != len(POLICIES) * len(SUBGROUPS):
        raise RuntimeError(f"Expected 18 matched rows, found {len(merged)}")

    merged["penalty_specific_delta_dice"] = (
        merged["mean_dice_alpha1"] - merged["mean_dice_lambda0"]
    )
    merged["penalty_specific_delta_hit"] = (
        merged["hit_count_alpha1"] - merged["hit_count_lambda0"]
    )
    merged["alpha1_volume_over_lambda0"] = (
        merged["mean_predicted_volume_mm3_alpha1"]
        / merged["mean_predicted_volume_mm3_lambda0"].replace(0, np.nan)
    )
    merged["lambda0_volume_ratio_vs_starting"] = merged[
        "predicted_volume_ratio_vs_starting_lambda0"
    ]
    merged["alpha1_volume_ratio_vs_starting"] = merged[
        "predicted_volume_ratio_vs_starting_alpha1"
    ]

    output_columns = [
        "subgroup",
        "variant",
        "findings_alpha1",
        "mean_dice_alpha1",
        "mean_dice_lambda0",
        "delta_dice_vs_starting_alpha1",
        "delta_dice_vs_starting_lambda0",
        "penalty_specific_delta_dice",
        "hit_count_alpha1",
        "hit_count_lambda0",
        "penalty_specific_delta_hit",
        "alpha1_volume_ratio_vs_starting",
        "lambda0_volume_ratio_vs_starting",
        "alpha1_volume_over_lambda0",
    ]
    result = merged[output_columns].sort_values(keys)
    result.to_csv(args.lambda0_dir / "matched_control_comparison.csv", index=False)

    all_raw = result[
        (result["subgroup"] == "all") & (result["variant"] == "raw")
    ].iloc[0]
    a_raw = result[
        (result["subgroup"] == "A_explicit_exact_lobe")
        & (result["variant"] == "raw")
    ].iloc[0]
    b_raw = result[
        (result["subgroup"] == "B_ambiguous_lobe")
        & (result["variant"] == "raw")
    ].iloc[0]
    control_shrank = float(all_raw["lambda0_volume_ratio_vs_starting"]) < 0.90
    penalty_added_shrinkage = float(all_raw["alpha1_volume_over_lambda0"]) < 0.95
    interpretation = (
        "The matched lambda-zero continuation also shrank prediction volume; "
        "most global shrinkage cannot be attributed uniquely to the Group-A penalty."
        if control_shrank and not penalty_added_shrinkage
        else "The alpha=1 run shrank substantially more than the matched lambda-zero control, supporting a penalty-specific shrinkage effect."
        if penalty_added_shrinkage
        else "The matched control was volume-stable and alpha=1 did not add substantial global shrinkage; inspect subgroup-specific effects."
    )

    diagnostics = {
        "update": args.update,
        "alpha1_dir": str(args.alpha1_dir),
        "lambda0_dir": str(args.lambda0_dir),
        "all_raw_penalty_specific_delta_dice": float(
            all_raw["penalty_specific_delta_dice"]
        ),
        "groupA_raw_penalty_specific_delta_dice": float(
            a_raw["penalty_specific_delta_dice"]
        ),
        "groupB_raw_penalty_specific_delta_dice": float(
            b_raw["penalty_specific_delta_dice"]
        ),
        "all_raw_alpha1_volume_over_lambda0": float(
            all_raw["alpha1_volume_over_lambda0"]
        ),
        "lambda0_control_global_volume_shrinkage": bool(control_shrank),
        "alpha1_added_at_least_5pct_volume_shrinkage": bool(
            penalty_added_shrinkage
        ),
        "interpretation": interpretation,
    }
    (args.lambda0_dir / "matched_control_diagnostics.json").write_text(
        json.dumps(diagnostics, indent=2) + "\n"
    )
    report = f"""# Matched alpha-zero continued-training control

## Question

Did the Group-B degradation and global predicted-volume shrinkage arise from
the Group-A outside-ROI penalty, or from otherwise matched 100-update continued
training with a fresh optimizer?

## Match

Both runs start from the same all-category 1/1 full-attention step6000
checkpoint and use seed 2027, the same sampler stream, two GPUs, batch/GPU 1,
grad accumulation 2, effective batch 4, patch 192^3, optimizer, learning rates,
parser, lobe ROI construction, and full-volume GT-retention gate. The only
intended difference is `alpha=1.0` versus `alpha=0.0`.

## Fixed-30 / 49-finding comparison

`penalty_specific_delta_dice = Dice(alpha1) - Dice(lambda0)`.

{markdown_table(result)}

## Interpretation

{interpretation}

```json
{json.dumps(diagnostics, indent=2)}
```
"""
    (args.lambda0_dir / "MATCHED_CONTROL_REPORT.md").write_text(report)
    print(json.dumps(diagnostics, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
