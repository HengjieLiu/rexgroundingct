#!/usr/bin/env python3
"""Fresh-process precision A/B/C diagnosis for token Image->Text startup."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "VoxTell") not in sys.path:
    sys.path.insert(0, str(ROOT / "VoxTell"))

from scripts.train_voxtell_rex_full_nnunet_aug import (  # noqa: E402
    instantiate_voxtell,
    loss_kwargs_from_args,
    segmentation_loss,
    token_startup_block_forward_stats,
    token_startup_tensor_stats,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--fixed-batch", type=Path, required=True)
    parser.add_argument("--fixed-token-inputs", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def replace_symlink(link: Path, target: Path) -> None:
    link.parent.mkdir(parents=True, exist_ok=True)
    temporary = link.with_name(link.name + f".tmp.{os.getpid()}")
    temporary.unlink(missing_ok=True)
    temporary.symlink_to(os.path.relpath(target.resolve(), link.parent))
    temporary.replace(link)


def namespace_from_checkpoint_args(payload: dict[str, Any]) -> argparse.Namespace:
    args = SimpleNamespace(**payload)
    for key in (
        "model_dir",
        "preprocessed_dir",
        "embedding_cache",
        "canonical_embedding_cache",
        "prompt_sidecar",
        "category_tversky_map",
        "token_feature_cache",
        "output_dir",
    ):
        value = getattr(args, key, None)
        if value is not None and not isinstance(value, Path):
            setattr(args, key, Path(value))
    return args  # type: ignore[return-value]


def tensor_to_device(value: Any, device: torch.device) -> Any:
    return value.to(device, non_blocking=True) if torch.is_tensor(value) else value


def grad_norm_for_prefix(model: torch.nn.Module, prefix: str) -> float:
    square = None
    for name, parameter in model.named_parameters():
        if name.startswith(prefix) and parameter.grad is not None:
            value = parameter.grad.detach().float().square().sum()
            square = value if square is None else square + value
    return 0.0 if square is None else float(square.sqrt().item())


def load_training_model(
    checkpoint_payload: dict[str, Any],
    checkpoint_args: argparse.Namespace,
    device: torch.device,
) -> torch.nn.Module:
    args = checkpoint_args
    network = instantiate_voxtell(
        args.model_dir,
        device,
        deep_supervision=True,
        enable_patch_presence_head=args.patch_presence_head,
        presence_head_type=args.presence_head_type,
        presence_detach_features=args.presence_detach_features,
        presence_spatial_hidden_channels=args.presence_spatial_hidden_channels,
        presence_spatial_topk_frac=args.presence_spatial_topk_frac,
        enable_prompt_spatial_attention=args.enable_prompt_spatial_attention,
        spatial_attention_hidden_channels=args.spatial_attention_hidden_channels,
        spatial_attention_beta_init=args.spatial_attention_beta_init,
        spatial_attention_level=args.spatial_attention_level,
        enable_s2_attention=args.enable_s2_attention,
        s2_attention_scales=args.s2_attention_scales,
        s2_attention_hidden_channels=args.s2_attention_hidden_channels,
        s2_beta_init=args.s2_beta_init,
        enable_s3_voxel_text_matching_attention=args.enable_s3_voxel_text_matching_attention,
        s3_attention_hidden_channels=args.s3_attention_hidden_channels,
        s3_rho_mode=args.s3_rho_mode,
        s3_rho_fixed=args.s3_rho_fixed,
        s3_logit_scale_init=args.s3_logit_scale_init,
        s3_attention_scales=args.s3_attention_scales,
        enable_s3_decoder_feature_gate=args.enable_s3_decoder_feature_gate,
        s3_decoder_feature_gate_scales=args.s3_decoder_feature_gate_scales,
        s3_decoder_feature_gate_strength_init=args.s3_decoder_feature_gate_strength_init,
        enable_s3_fullres_attention_refinement=args.enable_s3_fullres_attention_refinement,
        s3_fullres_refinement_hidden_channels=args.s3_fullres_refinement_hidden_channels,
        enable_s3_joint_residual_fusion=args.enable_s3_joint_residual_fusion,
        s3_joint_fusion_hidden_channels=args.s3_joint_fusion_hidden_channels,
        s3_joint_fusion_detach_attention=args.s3_joint_fusion_detach_attention,
        enable_s3_fullres_sampled_alignment=args.enable_s3_fullres_sampled_alignment,
        s3_fullres_alignment_dim=args.s3_fullres_alignment_dim,
        dvsm_tie_probe=args.dvsm_tie_probe,
        dvsm_probe_dim=args.dvsm_probe_dim,
        dvsm_probe_depth=args.dvsm_probe_depth,
        dvsm_probe_heads=args.dvsm_probe_heads,
        dvsm_probe_pool_size=args.dvsm_probe_pool_size,
        dvsm_probe_zero_init=args.dvsm_probe_zero_init,
        lobe_input_mode=args.lobe_input_mode,
        lobe_embedding_dim=args.lobe_embedding_dim,
        multiwindow_input=args.multiwindow_input,
        mome_core_mode=args.mome_core_mode,
        mome_controller_width=args.mome_controller_width,
        mome_router_hidden_channels=args.mome_router_hidden_channels,
        mome_router_normalization=args.mome_router_normalization,
        mome_router_temperature=args.mome_router_temperature,
        mome_router_epsilon=args.mome_router_epsilon,
        mome_router_condition_text=args.mome_router_condition_text,
        mome_integration=args.mome_integration,
        mome_capture_router_maps=args.mome_capture_router_maps,
        mome_residual_mode=args.mome_residual_mode,
        mome_residual_controller_width=args.mome_residual_controller_width,
        mome_residual_router_hidden_channels=args.mome_residual_router_hidden_channels,
        mome_residual_router_epsilon=args.mome_residual_router_epsilon,
        mome_residual_capture_router_maps=args.mome_residual_capture_router_maps,
        token_image_text_mode=args.token_image_text_mode,
        token_image_text_hidden_dim=args.token_image_text_hidden_dim,
        token_image_text_heads=args.token_image_text_heads,
        token_image_text_dropout=args.token_image_text_dropout,
        token_image_text_init_seed=args.token_image_text_init_seed,
        token_image_text_identity_init=args.token_image_text_identity_init,
        encoder_propagation_mode=args.encoder_propagation_mode,
        encoder_propagation_hidden_dim=args.encoder_propagation_hidden_dim,
        encoder_propagation_heads=args.encoder_propagation_heads,
        encoder_propagation_dropout=args.encoder_propagation_dropout,
        encoder_propagation_init_seed=args.encoder_propagation_init_seed,
    )
    incompatible = network.load_state_dict(
        checkpoint_payload["network_weights"],
        strict=False,
    )
    invalid_missing = [
        key
        for key in incompatible.missing_keys
        if not key.startswith(
            (
                "patch_presence_head.",
                "prompt_spatial_attention_gate.",
                "s2_attention_gates.",
                "s3_attention_gate.",
                "s3_extra_attention_gates.",
                "s3_decoder_feature_gates.",
                "s3_fullres_attention_refinement.",
                "s3_joint_fusion_head.",
                "s3_fullres_alignment_head.",
                "dvsm_probe_adapter.",
                "lobe_embedding.",
                "lobe_embedding_projection.",
                "lobe_anatomy_adapter.",
                "mome_core.",
                "mome_residual.",
                "token_image_text_block.",
                "encoder_propagation_block.",
            )
        )
    ]
    if invalid_missing or incompatible.unexpected_keys:
        raise RuntimeError(
            f"Checkpoint mismatch: missing={invalid_missing}, "
            f"unexpected={list(incompatible.unexpected_keys)}"
        )
    if (
        args.enable_s3_voxel_text_matching_attention
        and checkpoint_payload.get("s3_extra_attention_weights") is not None
    ):
        network.s3_extra_attention_gates.load_state_dict(
            checkpoint_payload["s3_extra_attention_weights"], strict=False
        )
    return network


def run_mode(
    *,
    mode: str,
    checkpoint: Path,
    batch: dict[str, Any],
    token_inputs: dict[str, torch.Tensor],
    checkpoint_args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> dict[str, Any]:
    checkpoint_payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    model = load_training_model(checkpoint_payload, checkpoint_args, device)
    model.train()
    block = getattr(model, "token_image_text_block")
    original_forward = block.forward
    if mode == "fp32_token_block":

        def fp32_forward(
            image_tokens: torch.Tensor,
            text_tokens: torch.Tensor,
            valid_token_mask: torch.Tensor,
        ) -> torch.Tensor:
            with torch.autocast(device.type, enabled=False):
                return original_forward(
                    image_tokens.float(),
                    text_tokens.float(),
                    valid_token_mask,
                )

        block.forward = fp32_forward  # type: ignore[method-assign]
    dtype = {
        "fp16": torch.float16,
        "bf16": torch.bfloat16,
        "fp32_token_block": torch.float16,
    }[mode]
    image = batch["image"].float().to(device)
    embeddings = batch["embeddings"].float().to(device)
    target = batch["target"].float().to(device)
    prompt_weights = batch["prompt_weights"].float().to(device)
    forward_kwargs = {
        key: tensor_to_device(value, device)
        for key, value in batch["forward_tensor_kwargs"].items()
    }
    model.zero_grad(set_to_none=True)
    torch.manual_seed(260811)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(260811)
    with torch.autocast(
        device.type,
        enabled=device.type == "cuda",
        dtype=dtype,
    ):
        model_output = model(image, embeddings, **forward_kwargs)
        logits = model_output[0] if isinstance(model_output, list) else model_output
        loss, loss_stats = segmentation_loss(
            logits,
            target,
            prompt_weights,
            prompt_categories=[batch["meta"].get("categories_after_shuffle", [])],
            current_step=40,
            **loss_kwargs_from_args(checkpoint_args),
        )
    loss.backward()
    residual_autocast_enabled = device.type == "cuda" and mode != "fp32_token_block"
    residual_dtype = torch.bfloat16 if mode == "bf16" else torch.float16
    residual_inputs = {
        key: value.to(device)
        for key, value in token_inputs.items()
    }
    with torch.no_grad(), torch.autocast(
        device.type,
        enabled=residual_autocast_enabled,
        dtype=residual_dtype,
    ):
        if mode == "fp32_token_block":
            residual_stats = token_startup_block_forward_stats(
                block,
                residual_inputs["image_tokens"].float(),
                residual_inputs["text_tokens"].float(),
                residual_inputs["valid_token_mask"],
            )
        else:
            residual_stats = token_startup_block_forward_stats(
                block,
                residual_inputs["image_tokens"],
                residual_inputs["text_tokens"],
                residual_inputs["valid_token_mask"],
            )
    result = {
        "mode": mode,
        "loss": float(loss.detach().float().item()),
        "loss_stats": loss_stats,
        "out_proj_weight": token_startup_tensor_stats(block.out_proj.weight.detach()),
        "attention_pre_out_norm": residual_stats[
            "attention_weighted_value_before_out_proj"
        ]["l2_norm"],
        "attention_pre_out_max_abs": residual_stats[
            "attention_weighted_value_before_out_proj"
        ]["max_abs"],
        "attention_post_out_norm": residual_stats[
            "attention_output_after_out_proj"
        ]["l2_norm"],
        "attention_post_out_max_abs": residual_stats[
            "attention_output_after_out_proj"
        ]["max_abs"],
        "attention_post_out_zero_fraction": residual_stats[
            "attention_output_after_out_proj"
        ]["exact_zero_fraction"],
        "ffn_final_output_norm": residual_stats["FFN_final_output"]["l2_norm"],
        "ffn_final_output_max_abs": residual_stats["FFN_final_output"]["max_abs"],
        "delta_z_over_z": residual_stats["delta_z_over_z"],
        "delta_z_norm": residual_stats["DeltaZ_effective"]["l2_norm"],
        "delta_z_max_abs": residual_stats["DeltaZ_effective"]["max_abs"],
        "delta_z_zero_fraction": residual_stats["DeltaZ_effective"]["exact_zero_fraction"],
        "cos_z_z_after": residual_stats["cos_z_z_after"],
        "q_grad": grad_norm_for_prefix(model, "token_image_text_block.q_proj."),
        "k_grad": grad_norm_for_prefix(model, "token_image_text_block.k_proj."),
        "v_grad": grad_norm_for_prefix(model, "token_image_text_block.v_proj."),
        "out_proj_grad": grad_norm_for_prefix(model, "token_image_text_block.out_proj."),
        "ffn0_grad": grad_norm_for_prefix(model, "token_image_text_block.ffn.0."),
        "ffn3_grad": grad_norm_for_prefix(model, "token_image_text_block.ffn.3."),
    }
    block.forward = original_forward  # type: ignore[method-assign]
    del model, block, loss, model_output, logits, checkpoint_payload
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return result


def main() -> int:
    cli = parse_args()
    cli.output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(cli.device)
    checkpoint = torch.load(cli.checkpoint, map_location="cpu", weights_only=False)
    checkpoint_args = namespace_from_checkpoint_args(checkpoint["args"])
    batch = torch.load(cli.fixed_batch, map_location="cpu", weights_only=False)
    token_inputs = torch.load(cli.fixed_token_inputs, map_location="cpu", weights_only=False)
    results = [
        run_mode(
            mode=mode,
            checkpoint=cli.checkpoint,
            batch=batch,
            token_inputs=token_inputs,
            checkpoint_args=checkpoint_args,
            output_dir=cli.output_dir,
            device=device,
        )
        for mode in ("fp16", "bf16", "fp32_token_block")
    ]
    payload = {
        "checkpoint": str(cli.checkpoint.resolve()),
        "fixed_batch": str(cli.fixed_batch.resolve()),
        "fixed_token_inputs": str(cli.fixed_token_inputs.resolve()),
        "results": results,
    }
    (cli.output_dir / "precision_comparison.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
