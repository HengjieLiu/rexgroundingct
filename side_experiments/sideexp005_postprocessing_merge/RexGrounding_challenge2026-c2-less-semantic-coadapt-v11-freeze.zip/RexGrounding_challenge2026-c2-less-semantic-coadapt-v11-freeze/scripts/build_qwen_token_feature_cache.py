#!/usr/bin/env python3
"""Cache contextual Qwen content-token states for the Phase-0 token pilot."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import torch
from tqdm import tqdm
from transformers import AutoModel, AutoTokenizer

ROOT = Path(__file__).resolve().parents[1]
VOXTELL = ROOT / "VoxTell"
if str(VOXTELL) not in sys.path:
    sys.path.insert(0, str(VOXTELL))

from voxtell.utils.text_embedding import wrap_with_instruction  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--pooled-cache",
        type=Path,
        default=ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--audit-json", type=Path, required=True)
    parser.add_argument("--model", default="Qwen/Qwen3-Embedding-4B")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--audit-count", type=int, default=8)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


@torch.inference_mode()
def main() -> int:
    args = parse_args()
    pooled = torch.load(args.pooled_cache, map_location="cpu", weights_only=False)
    records = pooled["records"]
    if pooled.get("text_model") != args.model:
        raise ValueError(
            f"Pooled cache uses {pooled.get('text_model')!r}, requested {args.model!r}"
        )
    tokenizer = AutoTokenizer.from_pretrained(
        args.model, padding_side="left", local_files_only=True, use_fast=True
    )
    model = AutoModel.from_pretrained(
        args.model,
        local_files_only=True,
        torch_dtype=torch.bfloat16,
    ).eval().to(args.device)
    for parameter in model.parameters():
        parameter.requires_grad_(False)

    token_features: list[torch.Tensor] = []
    token_ids: list[list[int]] = []
    token_strings: list[list[str]] = []
    audit: list[dict] = []
    for start in tqdm(range(0, len(records), args.batch_size), desc="Qwen contextual tokens"):
        batch_records = records[start : start + args.batch_size]
        prompts = [str(record["prompt"]) for record in batch_records]
        wrapped = wrap_with_instruction(prompts)
        encoded = tokenizer(
            wrapped,
            padding=True,
            truncation=True,
            max_length=args.max_length,
            return_offsets_mapping=True,
            return_special_tokens_mask=True,
            return_tensors="pt",
        )
        offsets = encoded.pop("offset_mapping")
        special = encoded.pop("special_tokens_mask")
        device_inputs = {key: value.to(args.device) for key, value in encoded.items()}
        hidden = model(**device_inputs).last_hidden_state.detach().cpu()
        for row, (record, prompt, wrapped_text) in enumerate(
            zip(batch_records, prompts, wrapped)
        ):
            query_start = wrapped_text.rfind(prompt)
            query_stop = query_start + len(prompt)
            row_offsets = offsets[row]
            attention = encoded["attention_mask"][row].bool()
            content = torch.tensor(
                [
                    bool(attention[index])
                    and not bool(special[row, index])
                    and int(pair[1]) > int(pair[0])
                    and int(pair[1]) > query_start
                    and int(pair[0]) < query_stop
                    for index, pair in enumerate(row_offsets.tolist())
                ],
                dtype=torch.bool,
            )
            if not bool(content.any()):
                raise RuntimeError(f"No content tokens selected for {record}")
            ids = encoded["input_ids"][row, content].tolist()
            pieces = tokenizer.convert_ids_to_tokens(ids)
            feature = hidden[row, content].to(torch.float16).contiguous()
            token_features.append(feature)
            token_ids.append(list(map(int, ids)))
            token_strings.append(list(map(str, pieces)))
            if len(audit) < args.audit_count:
                audit.append(
                    {
                        "split": record["split"],
                        "case": record["case"],
                        "finding_idx": int(record["finding_idx"]),
                        "raw_finding": prompt,
                        "wrapped_text": wrapped_text,
                        "tokenizer_token_ids": encoded["input_ids"][row].tolist(),
                        "decoded_tokens": tokenizer.convert_ids_to_tokens(
                            encoded["input_ids"][row].tolist()
                        ),
                        "attention_mask": attention.tolist(),
                        "special_token_mask": special[row].bool().tolist(),
                        "valid_content_token_mask": content.tolist(),
                        "content_token_ids": list(map(int, ids)),
                        "content_token_strings": list(map(str, pieces)),
                        "token_feature_shape": list(feature.shape),
                    }
                )

    snapshot = getattr(model.config, "_name_or_path", args.model)
    metadata = {
        "format_version": "rex_qwen_contextual_content_tokens.v1",
        "text_model": args.model,
        "resolved_model": snapshot,
        "hidden_size": int(model.config.hidden_size),
        "storage_dtype": "float16",
        "inference_dtype": "bfloat16",
        "tokenizer_padding_side": tokenizer.padding_side,
        "instruction_wrapper": "voxtell.utils.text_embedding.wrap_with_instruction",
        "selection": "non-special, attended tokens whose character span overlaps raw Query text (retains the first token when it owns the preceding-space marker)",
        "qwen_frozen": True,
        "qwen_trainable_parameters": sum(
            parameter.numel() for parameter in model.parameters() if parameter.requires_grad
        ),
        "records": len(records),
        "pooled_cache": str(args.pooled_cache.resolve()),
        "pooled_cache_sha256": sha256(args.pooled_cache),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "metadata": metadata,
            "records": records,
            "token_features": token_features,
            "token_ids": token_ids,
            "token_strings": token_strings,
        },
        args.output,
    )
    args.audit_json.parent.mkdir(parents=True, exist_ok=True)
    args.audit_json.write_text(
        json.dumps({"metadata": metadata, "samples": audit}, indent=2) + "\n"
    )
    print(json.dumps({**metadata, "output": str(args.output.resolve())}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
