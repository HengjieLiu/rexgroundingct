#!/usr/bin/env python3
"""Collect paired full-validation results for the medcomposeCT experiment."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = (
    ROOT
    / "outputs/category_embedding_normal_voxtell_step3800_pilot"
    / "focused_fullval_followup"
)
MODELS = ("baseline", "update_50", "update_100", "update_200")
MODEL_LABELS = {
    "baseline": "Baseline step-3800",
    "update_50": "Category adapter update 50",
    "update_100": "Category adapter update 100",
    "update_200": "Category adapter update 200",
}
COHORTS = ("category_2a", "category_2c", "diffuse")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap-samples", type=int, default=10_000)
    parser.add_argument("--bootstrap-seed", type=int, default=2026)
    parser.add_argument("--slurm-job-id", default=os.environ.get("SLURM_JOB_ID", "unknown"))
    parser.add_argument(
        "--launch-command",
        default="sbatch scripts/evaluate_medcomposect_focused_followup_4gpu.sbatch",
    )
    parser.add_argument("--resources", default="unknown")
    parser.add_argument("--runtime-seconds", type=float, default=None)
    parser.add_argument("--base-checkpoint", type=Path, required=True)
    parser.add_argument("--prompt-cache", type=Path, required=True)
    parser.add_argument("--adapter", type=Path, action="append", required=True)
    return parser.parse_args()


def read_eval_rows(path: Path, metadata: dict[tuple[str, int], dict[str, Any]]) -> dict[tuple[str, int], dict[str, Any]]:
    payload = json.loads(path.read_text())
    rows: dict[tuple[str, int], dict[str, Any]] = {}
    for case in payload.get("cases", []):
        case_id = case["file"]
        for metric_key, metric in sorted(
            (case.get("findings") or {}).items(), key=lambda item: int(item[0].split("_")[-1])
        ):
            channel = int(metric_key.split("_")[-1])
            if (case_id, channel) not in metadata:
                continue
            meta = metadata[(case_id, channel)]
            key = (case_id, int(meta["finding_id"]))
            rows[key] = {
                **meta,
                "dice": float(metric["global_dice"]),
                "hit": bool(metric["global_hit"]),
            }
    return rows


def add_volume_metrics(
    rows: dict[tuple[str, int], dict[str, Any]], gt_dir: Path, pred_dir: Path
) -> None:
    cases: dict[str, list[dict[str, Any]]] = {}
    for row in rows.values():
        cases.setdefault(row["case_id"], []).append(row)
    for case_id, case_rows in cases.items():
        gt_image = nib.load(str(gt_dir / case_id))
        pred_image = nib.load(str(pred_dir / case_id))
        gt = np.asanyarray(gt_image.dataobj) > 0
        pred = np.asanyarray(pred_image.dataobj) > 0
        if gt.shape != pred.shape:
            raise ValueError(f"GT/prediction shape mismatch for {case_id}: {gt.shape} != {pred.shape}")
        voxel_volume = float(np.prod(gt_image.header.get_zooms()[:3]))
        for row in case_rows:
            channel = int(row["finding_id"])
            gt_mask, pred_mask = gt[channel], pred[channel]
            fp = int(np.logical_and(pred_mask, ~gt_mask).sum())
            fn = int(np.logical_and(~pred_mask, gt_mask).sum())
            pred_voxels, gt_voxels = int(pred_mask.sum()), int(gt_mask.sum())
            row.update(
                {
                    "pred_voxels": pred_voxels,
                    "gt_voxels": gt_voxels,
                    "fp_voxels": fp,
                    "fn_voxels": fn,
                    "voxel_volume_mm3": voxel_volume,
                    "pred_volume_mm3": pred_voxels * voxel_volume,
                    "gt_volume_mm3": gt_voxels * voxel_volume,
                    "fp_volume_mm3": fp * voxel_volume,
                    "fn_volume_mm3": fn * voxel_volume,
                    "pred_gt_volume_ratio": pred_voxels / gt_voxels if gt_voxels else math.nan,
                }
            )


def bootstrap_ci(deltas: np.ndarray, samples: int, seed: int) -> tuple[float, float]:
    if len(deltas) == 0:
        return math.nan, math.nan
    rng = np.random.default_rng(seed)
    means = np.empty(samples, dtype=np.float64)
    batch = 1000
    for start in range(0, samples, batch):
        stop = min(samples, start + batch)
        indices = rng.integers(0, len(deltas), size=(stop - start, len(deltas)))
        means[start:stop] = deltas[indices].mean(axis=1)
    low, high = np.percentile(means, [2.5, 97.5])
    return float(low), float(high)


def cohort_for(row: dict[str, Any]) -> str:
    category = row["category_code"]
    if category == "2a":
        return "category_2a"
    if category == "2c":
        return "category_2c"
    if category.startswith("1"):
        return "diffuse"
    raise ValueError(f"Unexpected union category: {category}")


def mean(values) -> float:
    values = list(values)
    return float(np.mean(values)) if values else math.nan


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty CSV: {path}")
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def fmt(value: float | None, signed: bool = False) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "—"
    return f"{value:+.6f}" if signed else f"{value:.6f}"


def main() -> int:
    args = parse_args()
    out = args.output_dir
    union = json.loads((out / "manifests/union.json").read_text())
    metadata = {
        (row["case_id"], int(row["finding_id"])): dict(row)
        for row in union["findings"]
    }
    expected = {(row["case_id"], int(row["finding_id"])) for row in union["findings"]}

    by_model = {}
    for model in MODELS:
        rows = read_eval_rows(
            out / "predictions" / model / "eval_rexrank_metrics_global.json", metadata
        )
        if set(rows) != expected:
            raise ValueError(
                f"{model} finding identifiers do not match union manifest: "
                f"missing={len(expected - set(rows))}, extra={len(set(rows) - expected)}"
            )
        add_volume_metrics(rows, ROOT / "data/segmentations", out / "predictions" / model)
        by_model[model] = rows

    baseline = by_model["baseline"]
    long_rows = []
    for key in sorted(expected):
        base = baseline[key]
        for model in MODELS:
            item = by_model[model][key]
            long_rows.append(
                {
                    "case_id": item["case_id"],
                    "finding_id": item["finding_id"],
                    "target_channel_idx": item["target_channel_idx"],
                    "cohort": cohort_for(item),
                    "category_code": item["category_code"],
                    "focality": item["focality"],
                    "model": model,
                    "model_label": MODEL_LABELS[model],
                    "dice": item["dice"],
                    "baseline_dice": base["dice"],
                    "dice_delta": item["dice"] - base["dice"],
                    "hit": int(item["hit"]),
                    "baseline_hit": int(base["hit"]),
                    "new_hit": int(item["hit"] and not base["hit"]),
                    "baseline_hit_lost": int(base["hit"] and not item["hit"]),
                    "pred_voxels": item["pred_voxels"],
                    "gt_voxels": item["gt_voxels"],
                    "fp_voxels": item["fp_voxels"],
                    "fn_voxels": item["fn_voxels"],
                    "voxel_volume_mm3": item["voxel_volume_mm3"],
                    "pred_volume_mm3": item["pred_volume_mm3"],
                    "gt_volume_mm3": item["gt_volume_mm3"],
                    "fp_volume_mm3": item["fp_volume_mm3"],
                    "fn_volume_mm3": item["fn_volume_mm3"],
                    "pred_gt_volume_ratio": item["pred_gt_volume_ratio"],
                    "gt_pixels_from_dataset_metadata": item["gt_pixels_from_dataset_metadata"],
                    "prompt": item["prompt"],
                }
            )
    write_csv(out / "per_finding_metrics.csv", long_rows)

    summary_rows = []
    bootstrap = {
        "method": "finding-level paired bootstrap of mean Dice delta",
        "samples": args.bootstrap_samples,
        "seed": args.bootstrap_seed,
        "confidence_level": 0.95,
        "results": {},
    }
    for cohort in COHORTS:
        keys = [key for key in sorted(expected) if cohort_for(baseline[key]) == cohort]
        bootstrap["results"][cohort] = {}
        base_hits = np.asarray([baseline[key]["hit"] for key in keys], dtype=bool)
        for model in MODELS:
            current = by_model[model]
            dice = np.asarray([current[key]["dice"] for key in keys], dtype=np.float64)
            base_dice = np.asarray([baseline[key]["dice"] for key in keys], dtype=np.float64)
            deltas = dice - base_dice
            hits = np.asarray([current[key]["hit"] for key in keys], dtype=bool)
            ratios = np.asarray([current[key]["pred_gt_volume_ratio"] for key in keys], dtype=np.float64)
            low, high = bootstrap_ci(deltas, args.bootstrap_samples, args.bootstrap_seed)
            bootstrap["results"][cohort][model] = {
                "n": len(keys),
                "mean_delta": float(deltas.mean()),
                "ci_95_low": low,
                "ci_95_high": high,
                "ci_excludes_zero": bool(low > 0 or high < 0),
            }
            summary_rows.append(
                {
                    "cohort": cohort,
                    "n": len(keys),
                    "model": model,
                    "model_label": MODEL_LABELS[model],
                    "dice_per_finding": float(dice.mean()),
                    "mean_delta": float(deltas.mean()),
                    "median_delta": float(np.median(deltas)),
                    "delta_q25": float(np.quantile(deltas, 0.25)),
                    "delta_q75": float(np.quantile(deltas, 0.75)),
                    "bootstrap_ci_95_low": low,
                    "bootstrap_ci_95_high": high,
                    "hit_rate": float(hits.mean()),
                    "hit_delta": float(hits.mean() - base_hits.mean()),
                    "improved": int((deltas > 0).sum()) if model != "baseline" else 0,
                    "degraded": int((deltas < 0).sum()) if model != "baseline" else 0,
                    "delta_gt_plus_0p01": int((deltas > 0.01).sum()) if model != "baseline" else 0,
                    "delta_lt_minus_0p01": int((deltas < -0.01).sum()) if model != "baseline" else 0,
                    "mean_pred_gt_volume_ratio": float(np.nanmean(ratios)),
                    "aggregate_pred_gt_volume_ratio": float(
                        sum(current[key]["pred_voxels"] for key in keys)
                        / sum(current[key]["gt_voxels"] for key in keys)
                    ),
                    "new_hits": int(np.logical_and(hits, ~base_hits).sum()) if model != "baseline" else 0,
                    "baseline_hits_lost": int(np.logical_and(~hits, base_hits).sum()) if model != "baseline" else 0,
                }
            )
    write_csv(out / "cohort_summary.csv", summary_rows)
    (out / "bootstrap_results.json").write_text(json.dumps(bootstrap, indent=2) + "\n")

    summary_lookup = {(row["cohort"], row["model"]): row for row in summary_rows}
    keys_2c = [key for key in sorted(expected) if cohort_for(baseline[key]) == "category_2c"]
    diagnostic_rows = []
    for model in MODELS:
        current = by_model[model]
        base = by_model["baseline"]
        row = {
            "model": model,
            "model_label": MODEL_LABELS[model],
            "n": len(keys_2c),
            "mean_pred_volume_mm3": mean(current[key]["pred_volume_mm3"] for key in keys_2c),
            "mean_gt_volume_mm3": mean(current[key]["gt_volume_mm3"] for key in keys_2c),
            "mean_pred_gt_volume_ratio": mean(current[key]["pred_gt_volume_ratio"] for key in keys_2c),
            "mean_fp_volume_mm3": mean(current[key]["fp_volume_mm3"] for key in keys_2c),
            "mean_fn_volume_mm3": mean(current[key]["fn_volume_mm3"] for key in keys_2c),
            "new_hits": sum(current[key]["hit"] and not base[key]["hit"] for key in keys_2c),
            "baseline_hits_lost": sum(base[key]["hit"] and not current[key]["hit"] for key in keys_2c),
        }
        if model == "baseline":
            row.update(
                {
                    "delta_pred_volume_mm3": 0.0,
                    "delta_pred_gt_volume_ratio": 0.0,
                    "delta_fp_volume_mm3": 0.0,
                    "delta_fn_volume_mm3": 0.0,
                    "primary_error_mode": "reference",
                }
            )
        else:
            base_row = diagnostic_rows[0]
            row.update(
                {
                    "delta_pred_volume_mm3": row["mean_pred_volume_mm3"] - base_row["mean_pred_volume_mm3"],
                    "delta_pred_gt_volume_ratio": row["mean_pred_gt_volume_ratio"] - base_row["mean_pred_gt_volume_ratio"],
                    "delta_fp_volume_mm3": row["mean_fp_volume_mm3"] - base_row["mean_fp_volume_mm3"],
                    "delta_fn_volume_mm3": row["mean_fn_volume_mm3"] - base_row["mean_fn_volume_mm3"],
                }
            )
            over = max(row["delta_fp_volume_mm3"], 0.0)
            under = max(row["delta_fn_volume_mm3"], 0.0)
            if row["baseline_hits_lost"] > row["new_hits"] and row["baseline_hits_lost"] >= 3:
                mode = "lost detections"
            elif over > 1.25 * under and over > 0:
                mode = "over-segmentation"
            elif under > 1.25 * over and under > 0:
                mode = "under-segmentation"
            else:
                mode = "mixed behavior"
            row["primary_error_mode"] = mode
        diagnostic_rows.append(row)
    write_csv(out / "category_2c_diagnostic.csv", diagnostic_rows)

    a = summary_lookup[("category_2a", "update_50")]
    a_deltas = sorted(
        [by_model["update_50"][key]["dice"] - baseline[key]["dice"] for key in expected if cohort_for(baseline[key]) == "category_2a"],
        key=abs,
        reverse=True,
    )
    a_trimmed = mean(a_deltas[2:]) if len(a_deltas) > 2 else math.nan
    verdict_a = (
        a["mean_delta"] > 0 and a["improved"] / a["n"] >= 0.55 and a_trimmed > 0
    )
    b_rows = [summary_lookup[("category_2c", model)] for model in MODELS[1:]]
    b_negative = all(row["mean_delta"] < 0 for row in b_rows)
    # The stated rule does not require strict checkpoint-by-checkpoint
    # monotonicity. Treat the harm as persistent when the middle checkpoint
    # retains at least half the update-50 magnitude and update-200 retains at
    # least three quarters of it (or grows), while all three means are negative.
    b_persistent = (
        abs(b_rows[1]["mean_delta"]) >= 0.50 * abs(b_rows[0]["mean_delta"])
        and abs(b_rows[2]["mean_delta"]) >= 0.75 * abs(b_rows[0]["mean_delta"])
    )
    verdict_b = b_negative and b_persistent
    c_rows = [summary_lookup[("diffuse", model)] for model in MODELS[1:]]
    c_positive = [row for row in c_rows if row["mean_delta"] > 0]
    c_best = max(c_rows, key=lambda row: row["mean_delta"])
    verdict_c = (
        len(c_positive) >= 2
        and c_best["improved"] / c_best["n"] >= 0.55
        and c_best["baseline_hits_lost"] <= c_best["new_hits"]
    )
    verdicts = {
        "hypothesis_A_2a_benefit": "SUPPORTED" if verdict_a else "NOT SUPPORTED",
        "hypothesis_B_2c_harm": "SUPPORTED" if verdict_b else "NOT SUPPORTED",
        "hypothesis_C_diffuse_benefit": "SUPPORTED" if verdict_c else "NOT SUPPORTED",
        "hypothesis_A_trimmed_mean_after_removing_two_largest_absolute_deltas": a_trimmed,
    }
    if verdict_a and not verdict_c:
        recommendation = "investigate only category 2a"
    elif verdict_c:
        recommendation = "proceed to a more structured factor such as focality/location/size"
    else:
        recommendation = "stop category-only conditioning"
    verdicts["overall_recommendation"] = recommendation
    (out / "verdicts.json").write_text(json.dumps(verdicts, indent=2) + "\n")

    config = {
        "experiment": "medcomposeCT experiment",
        "evaluation_only": True,
        "split": "val",
        "source_validation_cohort": union["source_validation_cohort"],
        "target_union": {"findings": union["total_findings"], "cases": union["unique_cases"]},
        "base_checkpoint": str(args.base_checkpoint.resolve()),
        "adapters": [str(path.resolve()) for path in args.adapter],
        "prompt_embedding_cache": str(args.prompt_cache.resolve()),
        "prompt_mode": "original",
        "category_text_prefix": False,
        "threshold": 0.5,
        "inference": "global/full-volume; same VoxTell predictor, preprocessing, postprocessing, and prompt ordering as pilot",
        "hit_definition": "project global_hit from data/rexrank_eval.py via scripts/evaluate_rex_predictions.py --global-only",
        "bootstrap": {"samples": args.bootstrap_samples, "seed": args.bootstrap_seed},
        "slurm": {
            "job_id": args.slurm_job_id,
            "launch_command": args.launch_command,
            "resources": args.resources,
            "runtime_seconds_at_collection": args.runtime_seconds,
        },
    }
    (out / "config.json").write_text(json.dumps(config, indent=2) + "\n")

    lines = [
        "# medcomposeCT experiment: focused full-validation follow-up",
        "",
        "This is the evaluation-only follow-up of the normal-VoxTell category-embedding pilot.",
        "",
        "## Cohorts and provenance",
        "",
        f"- Complete released validation cohort: {union['source_validation_cohort']['cases']} cases / {union['source_validation_cohort']['findings']} findings.",
        f"- Target union: {union['total_findings']} findings across {union['unique_cases']} cases.",
        f"- Category 2a: {union['cohort_sizes']['category_2a']} findings / {union['cohort_unique_cases']['category_2a']} cases.",
        f"- Category 2c: {union['cohort_sizes']['category_2c']} findings / {union['cohort_unique_cases']['category_2c']} cases.",
        f"- Diffuse/non-focal: {union['cohort_sizes']['diffuse']} findings / {union['cohort_unique_cases']['diffuse']} cases.",
        f"- Finding overlap: `{json.dumps(union['finding_overlap'], sort_keys=True)}`.",
        f"- Case overlap: `{json.dumps(union['case_overlap'], sort_keys=True)}`.",
        "- Category metadata: `data/MICCAI_challenge_dataset.json`, `val[].categories`.",
        "- Diffuse rule: the existing repository rule—category codes beginning with `1` are non-focal/diffuse; codes beginning with `2` are focal.",
        "",
        "## Execution",
        "",
        f"- Slurm job: `{args.slurm_job_id}`",
        f"- Command: `{args.launch_command}`",
        f"- Resources: `{args.resources}`",
        f"- Runtime at collection: `{args.runtime_seconds if args.runtime_seconds is not None else 'unknown'} seconds`",
        "",
        "## Paired cohort results",
        "",
        "| Cohort | N | Model | Dice/finding | Mean delta | Median delta | Hit rate | Hit delta | Improved | Degraded | >+0.01 | <-0.01 | Q25 | Q75 | 95% CI | Pred/GT | New hits | Lost hits |",
        "|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summary_rows:
        baseline_row = row["model"] == "baseline"
        ci_text = (
            "—"
            if baseline_row
            else f"[{row['bootstrap_ci_95_low']:+.6f}, {row['bootstrap_ci_95_high']:+.6f}]"
        )
        lines.append(
            f"| {row['cohort']} | {row['n']} | {row['model_label']} | {row['dice_per_finding']:.6f} | "
            f"{('—' if baseline_row else fmt(row['mean_delta'], True))} | {('—' if baseline_row else fmt(row['median_delta'], True))} | "
            f"{row['hit_rate']:.6f} | {('—' if baseline_row else fmt(row['hit_delta'], True))} | "
            f"{('—' if baseline_row else row['improved'])} | {('—' if baseline_row else row['degraded'])} | "
            f"{('—' if baseline_row else row['delta_gt_plus_0p01'])} | {('—' if baseline_row else row['delta_lt_minus_0p01'])} | "
            f"{('—' if baseline_row else fmt(row['delta_q25'], True))} | {('—' if baseline_row else fmt(row['delta_q75'], True))} | "
            f"{ci_text} | "
            f"{row['mean_pred_gt_volume_ratio']:.6f} | {('—' if baseline_row else row['new_hits'])} | "
            f"{('—' if baseline_row else row['baseline_hits_lost'])} |"
        )
    lines.extend(
        [
            "",
            "The 95% intervals are finding-level paired bootstrap intervals (10,000 samples, seed 2026).",
            "",
            "## Category 2c error-mode diagnostic",
            "",
            "| Model | Pred volume mm³ | GT volume mm³ | Pred/GT | FP mm³ | FN mm³ | ΔPred mm³ | ΔFP mm³ | ΔFN mm³ | New hits | Lost hits | Primary mode |",
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        ]
    )
    for row in diagnostic_rows:
        lines.append(
            f"| {row['model_label']} | {row['mean_pred_volume_mm3']:.3f} | {row['mean_gt_volume_mm3']:.3f} | "
            f"{row['mean_pred_gt_volume_ratio']:.6f} | {row['mean_fp_volume_mm3']:.3f} | {row['mean_fn_volume_mm3']:.3f} | "
            f"{row['delta_pred_volume_mm3']:+.3f} | {row['delta_fp_volume_mm3']:+.3f} | {row['delta_fn_volume_mm3']:+.3f} | "
            f"{row['new_hits']} | {row['baseline_hits_lost']} | {row['primary_error_mode']} |"
        )
    lines.extend(
        [
            "",
            "## Hypothesis verdicts",
            "",
            f"- Hypothesis A (2a benefit): **{verdicts['hypothesis_A_2a_benefit']}**. The two-extreme-case-trimmed update-50 mean is `{a_trimmed:+.6f}`.",
            f"- Hypothesis B (2c harm): **{verdicts['hypothesis_B_2c_harm']}**.",
            f"- Hypothesis C (diffuse benefit): **{verdicts['hypothesis_C_diffuse_benefit']}**.",
            "",
            f"Overall recommendation: **{recommendation}**.",
            "",
            "## Visualizations",
            "",
            "See `visualizations/manifest.json` for the three largest 2c update-200 degradations, 2a update-50 improvements, and diffuse update-100 improvements, with duplicates removed.",
        ]
    )
    (out / "summary.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"verdicts": verdicts, "summary_rows": len(summary_rows)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
