#!/usr/bin/env python3
"""Matched, inference-only CoLiPri versus VoxTell alignment benchmark.

The command has four isolated stages: ``prepare``, ``score-colipri``,
``score-voxtell``, and ``evaluate``.  Both scorers consume the same cached RAS
physical ROI and the same prompt-pair manifest.  GT is used only by ``prepare``
to define the ROI and reject ambiguous natural negatives.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import random
import re
import socket
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

import nibabel as nib
import numpy as np
import pandas as pd
from nibabel.processing import resample_from_to


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "outputs/colipri_voxtell_matched_alignment_20260804"
DEFAULT_S3_RUN = ROOT / "outputs/s3_1over1_allcat_v11_e1e-5_d1e-4_s3e1e-4_1gpu_bs1_acc4_10kupd"
DEFAULT_S3_CHECKPOINT = DEFAULT_S3_RUN / "checkpoints/checkpoint_update_9000.pth"
COLIPRI_REVISION = "be872ebec5c62894cf183b09835ec6fd7be537f5"
SEED = 20260804
ROI_SHAPE = (192, 192, 192)
ROI_MIN_SIDE_MM = 192.0
ROI_MARGIN_MM = 24.0
AMBIGUITY_THRESHOLD = 0.01

CATEGORY_NAMES = {
    "1a": "bronchial wall thickening",
    "1b": "bronchiectasis",
    "1c": "emphysema",
    "1d": "septal thickening",
    "1e": "micronodules",
    "1f": "other lung finding",
    "2a": "linear atelectasis scarring or fibrosis",
    "2b": "atelectasis or consolidation",
    "2c": "ground glass opacity",
    "2d": "pulmonary nodule or mass",
    "2e": "pleural effusion or thickening",
    "2f": "honeycombing",
    "2g": "pneumothorax",
    "2h": "other lung finding",
}

DIFFUSE_RE = re.compile(
    r"\b(ground[- ]?glass|ggo|consolidation|opacity|opacities|infiltrate|"
    r"atelectasis|fibrotic|fibrosis|reticulation|honeycombing|emphysema|"
    r"bronchiectasis|peribronchial|pleural effusion|pneumothorax)\b",
    re.I,
)
FOCAL_RE = re.compile(r"\b(nodule|nodules|mass|lesion|calcification|granuloma|cyst)\b", re.I)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path, chunk_size: int = 8 << 20) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def prompt_hash(text: str) -> str:
    return sha256_bytes(str(text).encode("utf-8"))


def normalize_prompt(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(text).lower()).strip()


def parse_laterality(text: str) -> str:
    value = str(text).lower()
    bilateral = bool(re.search(r"\b(bilateral|both lungs?|both (upper|lower) lobes)\b", value))
    right = bool(re.search(r"\b(right|rul|rml|rll)\b", value))
    left = bool(re.search(r"\b(left|lul|lll|lingula|lingular)\b", value))
    if bilateral or (right and left):
        return "bilateral"
    if right:
        return "right"
    if left:
        return "left"
    return "unspecified"


def parse_lobes(text: str) -> list[str]:
    value = str(text).lower()
    found: set[str] = set()
    patterns = {
        "RUL": (r"\bright upper(?: lobe)?\b", r"\brul\b"),
        "RML": (r"\bright middle(?: lobe)?\b", r"\brml\b"),
        "RLL": (r"\bright lower(?: lobe)?\b", r"\brll\b"),
        "LUL": (r"\bleft upper(?: lobe)?\b", r"\blul\b", r"\blingul(?:a|ar)\b"),
        "LLL": (r"\bleft lower(?: lobe)?\b", r"\blll\b"),
    }
    for lobe, candidates in patterns.items():
        if any(re.search(pattern, value) for pattern in candidates):
            found.add(lobe)
    if "both upper lobes" in value:
        found.update(("RUL", "LUL"))
    if "both lower lobes" in value:
        found.update(("RLL", "LLL"))
    return [item for item in ("RUL", "RML", "RLL", "LUL", "LLL") if item in found]


def classify_focality(text: str) -> str:
    focal = bool(FOCAL_RE.search(str(text)))
    diffuse = bool(DIFFUSE_RE.search(str(text)))
    if focal and diffuse:
        return "mixed"
    if focal:
        return "focal"
    if diffuse:
        return "diffuse"
    return "unknown"


def anatomy_signature(text: str) -> str:
    lobes = parse_lobes(text)
    return "+".join(lobes) if lobes else parse_laterality(text)


def anatomy_phrase(text: str) -> str:
    lobes = parse_lobes(text)
    if lobes:
        names = {
            "RUL": "right upper lobe",
            "RML": "right middle lobe",
            "RLL": "right lower lobe",
            "LUL": "left upper lobe",
            "LLL": "left lower lobe",
        }
        return " and ".join(names[item] for item in lobes)
    side = parse_laterality(text)
    return {"right": "right lung", "left": "left lung", "bilateral": "both lungs"}.get(side, "")


def swap_anatomy(text: str) -> str | None:
    """Return one conservative, grammatical side- or lobe-swapped prompt."""
    if parse_laterality(text) == "bilateral":
        return None
    substitutions = (
        (r"\bright upper lobe\b", "right lower lobe"),
        (r"\bright lower lobe\b", "right upper lobe"),
        (r"\bleft upper lobe\b", "left lower lobe"),
        (r"\bleft lower lobe\b", "left upper lobe"),
        (r"\bRUL\b", "RLL"),
        (r"\bRLL\b", "RUL"),
        (r"\bLUL\b", "LLL"),
        (r"\bLLL\b", "LUL"),
    )
    for pattern, replacement in substitutions:
        if re.search(pattern, text, re.I):
            return re.sub(pattern, replacement, text, count=1, flags=re.I)
    side = parse_laterality(text)
    if side == "right":
        return re.sub(r"\bright\b", "left", text, flags=re.I)
    if side == "left":
        return re.sub(r"\bleft\b", "right", text, flags=re.I)
    return None


def size_bin(volume_mm3: float) -> str:
    if volume_mm3 < 1_000:
        return "tiny"
    if volume_mm3 < 10_000:
        return "small"
    if volume_mm3 < 100_000:
        return "medium"
    return "large"


def json_compact(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)


def write_csv(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError(f"Refusing to write empty CSV: {path}")
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def dataframe_to_markdown(frame: pd.DataFrame) -> str:
    """Render a compact Markdown table without pandas' optional tabulate dep."""
    columns = [str(column) for column in frame.columns]

    def cell(value: Any) -> str:
        if pd.isna(value):
            return ""
        if isinstance(value, (float, np.floating)):
            return f"{float(value):.6g}"
        return str(value).replace("|", "\\|").replace("\n", " ")

    lines = [
        "| " + " | ".join(columns) + " |",
        "|" + "|".join("---" for _ in columns) + "|",
    ]
    lines.extend(
        "| " + " | ".join(cell(value) for value in row) + " |"
        for row in frame.itertuples(index=False, name=None)
    )
    return "\n".join(lines)


def target_grid_from_world_points(points: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    if points.ndim != 2 or points.shape[1] != 3 or not len(points):
        raise ValueError(f"Invalid nonempty world points: {points.shape}")
    lower = points.min(axis=0)
    upper = points.max(axis=0)
    center = (lower + upper) / 2.0
    extent = upper - lower
    side = max(ROI_MIN_SIDE_MM, float(extent.max()) + 2.0 * ROI_MARGIN_MM)
    side = math.ceil(side / 8.0) * 8.0
    spacing = side / ROI_SHAPE[0]
    affine = np.diag([spacing, spacing, spacing, 1.0])
    affine[:3, 3] = center - spacing * (np.asarray(ROI_SHAPE) - 1.0) / 2.0
    edge_lower = affine[:3, 3] - spacing / 2.0
    edge_upper = affine[:3, 3] + spacing * (np.asarray(ROI_SHAPE) - 0.5)
    return affine, edge_lower, edge_upper, side


def world_points(mask: np.ndarray, affine: np.ndarray) -> np.ndarray:
    indices = np.argwhere(mask)
    if not len(indices):
        return np.empty((0, 3), dtype=np.float64)
    return nib.affines.apply_affine(affine, indices)


def points_fraction_in_bounds(points: np.ndarray, lower: np.ndarray, upper: np.ndarray) -> tuple[float, int]:
    if not len(points):
        return 0.0, 0
    inside = np.all((points >= lower[None]) & (points <= upper[None]), axis=1)
    count = int(inside.sum())
    return count / len(points), count


def create_shared_roi(
    canonical_ct: nib.Nifti1Image,
    canonical_target: nib.Nifti1Image,
    target_affine: np.ndarray,
    cache_path: Path,
) -> tuple[str, int, bool]:
    resampled = resample_from_to(
        canonical_ct,
        (ROI_SHAPE, target_affine),
        order=1,
        mode="constant",
        cval=-1000.0,
    )
    image = np.asarray(resampled.dataobj, dtype=np.float32).astype(np.float16)
    if not np.isfinite(image).all():
        raise RuntimeError(f"Non-finite shared ROI: {cache_path}")
    target = resample_from_to(
        canonical_target,
        (ROI_SHAPE, target_affine),
        order=0,
        mode="constant",
        cval=0,
    )
    target_voxels = int((np.asarray(target.dataobj) > 0).sum())
    occupancy_rescued = False
    if target_voxels == 0:
        # A one-voxel lesion can fall between output voxel centers under
        # nearest-neighbor resampling. This soft occupancy map is diagnostic
        # only and is never passed to either model.
        soft_source = nib.Nifti1Image(
            np.asarray(canonical_target.dataobj, dtype=np.float32),
            canonical_target.affine,
        )
        soft_target = resample_from_to(
            soft_source,
            (ROI_SHAPE, target_affine),
            order=1,
            mode="constant",
            cval=0,
        )
        target_voxels = int((np.asarray(soft_target.dataobj) > 1e-6).sum())
        occupancy_rescued = True
        if target_voxels == 0:
            raise RuntimeError(f"Target vanished after occupancy rescue: {cache_path}")
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(cache_path, image, allow_pickle=False)
    return sha256_bytes(image.tobytes(order="C")), target_voxels, occupancy_rescued


def load_dataset(rex_json: Path, split: str) -> list[dict[str, Any]]:
    data = json.loads(rex_json.read_text())
    if split not in data:
        raise KeyError(f"Missing split {split!r} in {rex_json}")
    return list(data[split])


def reproduce_historical_metrics(output: Path) -> None:
    """Recover historical values from stored tables without neural inference."""
    comparison_path = ROOT / "outputs/colipri_voxtell_nextstep_v1/inference_only_functional_comparison.csv"
    comparison = pd.read_csv(comparison_path)
    historical = comparison[
        comparison.group.eq("all")
        & comparison.metric.eq("prompt_discrimination_auroc")
    ].set_index("model").value.to_dict()
    patch_path = ROOT / "outputs/colipri_text_and_voxtell_patch_alignment_v1/patch_alignment_patch_validation.csv"
    patch = pd.read_csv(patch_path).set_index("step")
    segmentation_path = ROOT / "outputs/colipri_text_and_voxtell_patch_alignment_v1/final_two_experiment_summary.csv"
    segmentation = pd.read_csv(segmentation_path).set_index("experiment")
    payload = {
        "historical_functional_comparison": {
            "source": str(comparison_path),
            "colipri_auroc": float(historical["COLIPRI"]),
            "voxtell_auroc": float(historical["VoxTell"]),
            "reproduced_expected_values": bool(
                math.isclose(float(historical["COLIPRI"]), 0.808641975308642)
                and math.isclose(float(historical["VoxTell"]), 0.5061728395061729)
            ),
            "comparable": False,
        },
        "separate_voxtell_qwen_patch_head": {
            "source": str(patch_path),
            "update0_auroc": float(patch.loc[0, "alignment_auroc"]),
            "update600_auroc": float(patch.loc[600, "alignment_auroc"]),
            "update0_margin": float(patch.loc[0, "positive_minus_negative_margin"]),
            "update600_margin": float(patch.loc[600, "positive_minus_negative_margin"]),
            "anchor85_fullvolume_dice": float(segmentation.loc["Anchor85 baseline", "dice"]),
            "patch_head_fullvolume_dice": float(segmentation.loc["Experiment B patch alignment", "dice"]),
            "native_colipri_encoders_used": False,
        },
    }
    (output / "historical_metric_reproduction.json").write_text(
        json.dumps(payload, indent=2) + "\n"
    )


def prepare(args: argparse.Namespace) -> int:
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    reproduce_historical_metrics(output)
    entries = load_dataset(args.rex_json, args.split)
    if args.case_id is not None:
        entries = [entry for entry in entries if str(entry["name"]) == args.case_id]
        if len(entries) != 1:
            raise ValueError(f"Expected exactly one --case-id match, found {len(entries)}")
    if args.limit_cases is not None:
        entries = entries[: args.limit_cases]
    records: list[dict[str, Any]] = []
    overlaps: dict[tuple[str, int], dict[int, dict[str, float | int]]] = {}
    failures: list[dict[str, Any]] = []

    for case_number, entry in enumerate(entries, start=1):
        case = str(entry["name"])
        image_path = args.image_dir / case
        mask_path = args.mask_dir / case
        try:
            ct_native = nib.load(str(image_path))
            ct_ras = nib.as_closest_canonical(ct_native)
            gt = np.asanyarray(nib.load(str(mask_path)).dataobj)
            finding_keys = sorted(entry["findings"], key=lambda item: int(item))
            if gt.ndim != 4 or gt.shape[0] < len(finding_keys) or tuple(gt.shape[1:]) != tuple(ct_native.shape):
                raise ValueError(f"Image/mask mismatch: image={ct_native.shape}, mask={gt.shape}")
            canonical_masks: dict[int, nib.Nifti1Image] = {}
            points_by_finding: dict[int, np.ndarray] = {}
            for key in finding_keys:
                index = int(key)
                source = nib.Nifti1Image((gt[index] > 0).astype(np.uint8), ct_native.affine)
                canonical = nib.as_closest_canonical(source)
                canonical_masks[index] = canonical
                points = world_points(np.asarray(canonical.dataobj) > 0, canonical.affine)
                if not len(points):
                    raise ValueError(f"Empty GT finding {index}")
                points_by_finding[index] = points

            voxel_volume = abs(float(np.linalg.det(ct_native.affine[:3, :3])))
            for key in finding_keys:
                index = int(key)
                prompt = str(entry["findings"][key]).strip()
                category = str((entry.get("categories") or {}).get(key, "unknown"))
                affine, lower, upper, side = target_grid_from_world_points(points_by_finding[index])
                overlap_info: dict[int, dict[str, float | int]] = {}
                for other in (int(item) for item in finding_keys if int(item) != index):
                    fraction, count = points_fraction_in_bounds(points_by_finding[other], lower, upper)
                    overlap_info[other] = {"fraction": fraction, "voxels": count}
                overlaps[(case, index)] = overlap_info
                target_fraction, target_inside = points_fraction_in_bounds(points_by_finding[index], lower, upper)
                roi_id = f"{case.removesuffix('.nii.gz')}__finding{index:02d}"
                cache_path = output / "shared_roi_cache" / f"{roi_id}.npy"
                if cache_path.exists() and not args.overwrite_cache:
                    cached = np.load(cache_path, mmap_mode="r")
                    if tuple(cached.shape) != ROI_SHAPE or cached.dtype != np.float16:
                        raise ValueError(f"Invalid existing ROI cache {cache_path}: {cached.shape}/{cached.dtype}")
                    roi_hash = sha256_bytes(np.asarray(cached).tobytes(order="C"))
                    shared_gt_voxels = -1
                    occupancy_rescued = False
                else:
                    roi_hash, shared_gt_voxels, occupancy_rescued = create_shared_roi(
                        ct_ras, canonical_masks[index], affine, cache_path
                    )
                gt_voxels = int(len(points_by_finding[index]))
                gt_volume = gt_voxels * voxel_volume
                records.append(
                    {
                        "roi_id": roi_id,
                        "case_id": case,
                        "finding_id": f"{case}:finding{index}",
                        "finding_idx": index,
                        "split": args.split,
                        "prompt_text": prompt,
                        "prompt_hash": prompt_hash(prompt),
                        "category": category,
                        "entity": CATEGORY_NAMES.get(category, category),
                        "laterality": parse_laterality(prompt),
                        "lobes": "+".join(parse_lobes(prompt)),
                        "anatomy_signature": anatomy_signature(prompt),
                        "focality": classify_focality(prompt),
                        "gt_voxels_original": gt_voxels,
                        "gt_volume_mm3": gt_volume,
                        "size_bin": size_bin(gt_volume),
                        "image_path": str(image_path.resolve()),
                        "mask_path": str(mask_path.resolve()),
                        "source_manifest": str(args.rex_json.resolve()),
                        "source_affine_json": json_compact(ct_native.affine.tolist()),
                        "source_shape_json": json_compact(list(ct_native.shape)),
                        "source_orientation": "".join(nib.aff2axcodes(ct_native.affine)),
                        "shared_orientation": "RAS",
                        "roi_center_mm_json": json_compact(((lower + upper) / 2.0).tolist()),
                        "roi_bounds_lower_mm_json": json_compact(lower.tolist()),
                        "roi_bounds_upper_mm_json": json_compact(upper.tolist()),
                        "roi_size_mm": side,
                        "roi_volume_mm3": side**3,
                        "shared_shape_json": json_compact(list(ROI_SHAPE)),
                        "shared_spacing_mm_json": json_compact([side / ROI_SHAPE[0]] * 3),
                        "shared_affine_json": json_compact(affine.tolist()),
                        "shared_roi_path": str(cache_path.resolve()),
                        "shared_roi_sha256": roi_hash,
                        "target_gt_fraction_in_roi": target_fraction,
                        "target_gt_voxels_in_roi": target_inside,
                        "target_gt_voxels_shared_grid": shared_gt_voxels,
                        "target_shared_grid_occupancy_rescued": int(occupancy_rescued),
                        "other_finding_overlap_json": json_compact(overlap_info),
                        "other_findings_with_any_gt_in_roi": sum(int(v["voxels"]) > 0 for v in overlap_info.values()),
                        "other_findings_above_ambiguity_threshold": sum(float(v["fraction"]) > AMBIGUITY_THRESHOLD for v in overlap_info.values()),
                        "roi_rule": "GT_world_bbox_centered_cube_min192mm_margin24mm_round8mm_RAS192cube",
                    }
                )
            print(f"[{case_number}/{len(entries)}] prepared {case}", flush=True)
        except Exception as exc:
            failures.append({"case_id": case, "stage": "prepare", "error": repr(exc)})

    if failures:
        write_csv(output / "failures_prepare.csv", failures)
        raise RuntimeError(f"Preparation failed for {len(failures)} cases; see failures_prepare.csv")
    roi_frame = pd.DataFrame(records).sort_values(["case_id", "finding_idx"]).reset_index(drop=True)
    roi_frame.to_csv(output / "matched_roi_manifest.csv", index=False)
    pair_rows = build_prompt_pairs(roi_frame, overlaps, args.seed)
    pd.DataFrame(pair_rows).to_csv(output / "matched_prompt_pairs.csv", index=False)
    metadata = {
        "created_at_unix": time.time(),
        "host": socket.gethostname(),
        "seed": args.seed,
        "split": args.split,
        "case_count": int(roi_frame.case_id.nunique()),
        "finding_count": int(len(roi_frame)),
        "pair_rows_total": len(pair_rows),
        "pair_rows_included": sum(bool(row["included"]) for row in pair_rows),
        "roi_rule": records[0]["roi_rule"],
        "roi_min_side_mm": ROI_MIN_SIDE_MM,
        "roi_margin_mm": ROI_MARGIN_MM,
        "ambiguity_threshold": AMBIGUITY_THRESHOLD,
        "gt_usage": "ROI definition, coverage audit, and natural-negative ambiguity exclusion only",
    }
    (output / "manifest_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata, indent=2), flush=True)
    return 0


def build_prompt_pairs(
    roi_frame: pd.DataFrame,
    overlaps: dict[tuple[str, int], dict[int, dict[str, float | int]]],
    seed: int,
) -> list[dict[str, Any]]:
    rng = random.Random(seed)
    all_rows = [row._asdict() for row in roi_frame.itertuples(index=False)]
    by_case: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in all_rows:
        by_case[str(row["case_id"])].append(row)
    output: list[dict[str, Any]] = []

    def append(
        target: dict[str, Any],
        text: str,
        is_correct: bool,
        negative_type: str,
        source: dict[str, Any] | None,
        prompt_form: str = "original",
        included: bool = True,
        exclusion_reason: str = "",
        overlap: float | None = None,
    ) -> None:
        normalized = normalize_prompt(text)
        source_case = "" if source is None else str(source["case_id"])
        source_finding = "" if source is None else str(source["finding_id"])
        pair_key = "|".join(
            (str(target["roi_id"]), prompt_form, negative_type, source_finding, normalized)
        )
        output.append(
            {
                "pair_id": sha256_bytes(pair_key.encode())[:24],
                "case_id": target["case_id"],
                "finding_id": target["finding_id"],
                "finding_idx": target["finding_idx"],
                "roi_id": target["roi_id"],
                "prompt_id": prompt_hash(text)[:24],
                "prompt_text": text,
                "prompt_hash": prompt_hash(text),
                "prompt_form": prompt_form,
                "is_correct": int(is_correct),
                "negative_type": negative_type,
                "negative_case_id": source_case,
                "negative_finding_id": source_finding,
                "entity_match": int(source is not None and source["category"] == target["category"]),
                "anatomy_match": int(source is not None and source["anatomy_signature"] == target["anatomy_signature"]),
                "same_case": int(source is not None and source_case == target["case_id"]),
                "GT_overlap_with_ROI": "" if overlap is None else overlap,
                "included": int(included),
                "exclusion_reason": exclusion_reason,
                "target_category": target["category"],
                "target_entity": target["entity"],
                "target_laterality": target["laterality"],
                "target_lobes": target["lobes"],
                "target_focality": target["focality"],
                "target_size_bin": target["size_bin"],
            }
        )

    for target in all_rows:
        append(target, target["prompt_text"], True, "correct", target)
        entity_text = str(target["entity"])
        append(target, entity_text, True, "correct", target, prompt_form="entity_only")
        anatomy = anatomy_phrase(str(target["prompt_text"]))
        if anatomy:
            entity_anatomy_text = (
                f"{entity_text} in both lungs"
                if anatomy == "both lungs"
                else f"{entity_text} in the {anatomy}"
            )
            append(
                target,
                entity_anatomy_text,
                True,
                "correct",
                target,
                prompt_form="entity_anatomy",
            )

        other_case = [
            row for row in all_rows
            if row["case_id"] != target["case_id"]
            and row["category"] != target["category"]
            and normalize_prompt(row["prompt_text"]) != normalize_prompt(target["prompt_text"])
        ]
        if other_case:
            append(target, (choice := rng.choice(other_case))["prompt_text"], False, "random_case", choice)

        case_overlap = overlaps[(str(target["case_id"]), int(target["finding_idx"]))]
        for candidate in by_case[str(target["case_id"])]:
            if candidate["finding_idx"] == target["finding_idx"]:
                continue
            overlap = float(case_overlap[int(candidate["finding_idx"])]["fraction"])
            negative_type = "same_case_same_entity" if candidate["category"] == target["category"] else "same_case"
            duplicate = normalize_prompt(candidate["prompt_text"]) == normalize_prompt(target["prompt_text"])
            included = overlap <= AMBIGUITY_THRESHOLD and not duplicate
            reason = ""
            if overlap > AMBIGUITY_THRESHOLD:
                reason = f"corresponding_gt_fraction_in_roi>{AMBIGUITY_THRESHOLD}"
            elif duplicate:
                reason = "duplicate_or_semantically_identical_prompt"
            append(
                target,
                candidate["prompt_text"],
                False,
                negative_type,
                candidate,
                included=included,
                exclusion_reason=reason,
                overlap=overlap,
            )

        same_entity = [
            row for row in all_rows
            if row["case_id"] != target["case_id"]
            and row["category"] == target["category"]
            and row["anatomy_signature"] != target["anatomy_signature"]
            and normalize_prompt(row["prompt_text"]) != normalize_prompt(target["prompt_text"])
        ]
        if same_entity:
            candidate = rng.choice(same_entity)
            append(target, candidate["prompt_text"], False, "same_entity", candidate)

        signature = str(target["anatomy_signature"])
        same_anatomy = [
            row for row in all_rows
            if row["case_id"] != target["case_id"]
            and row["category"] != target["category"]
            and signature not in {"", "unspecified"}
            and row["anatomy_signature"] == signature
            and normalize_prompt(row["prompt_text"]) != normalize_prompt(target["prompt_text"])
        ]
        if same_anatomy:
            candidate = rng.choice(same_anatomy)
            append(target, candidate["prompt_text"], False, "same_anatomy", candidate)

        swapped = swap_anatomy(str(target["prompt_text"]))
        if swapped and normalize_prompt(swapped) != normalize_prompt(target["prompt_text"]):
            append(target, swapped, False, "anatomy_swapped", None)

    # Symmetric duplicate removal within each ROI/prompt form. Keep the first
    # declared role and retain excluded rows for a complete audit trail.
    seen: set[tuple[str, str, str]] = set()
    for row in output:
        key = (str(row["roi_id"]), str(row["prompt_form"]), normalize_prompt(row["prompt_text"]))
        if key in seen and row["included"]:
            row["included"] = 0
            row["exclusion_reason"] = "duplicate_prompt_within_roi"
        elif row["included"]:
            seen.add(key)
    return output


def score_summaries(values, prefix: str = "") -> dict[str, float]:
    import torch

    flat = values.float().reshape(-1)
    n = flat.numel()
    top1 = torch.topk(flat, max(1, math.ceil(n * 0.01))).values.mean()
    top5 = torch.topk(flat, max(1, math.ceil(n * 0.05))).values.mean()
    return {
        f"{prefix}mean": float(flat.mean().item()),
        f"{prefix}max": float(flat.max().item()),
        f"{prefix}top1_mean": float(top1.item()),
        f"{prefix}top5_mean": float(top5.item()),
    }


def load_manifests(args: argparse.Namespace) -> tuple[pd.DataFrame, pd.DataFrame]:
    rois = pd.read_csv(args.output_dir / "matched_roi_manifest.csv")
    pairs = pd.read_csv(args.output_dir / "matched_prompt_pairs.csv")
    pairs = pairs.loc[pairs.included.astype(bool)].copy()
    if args.limit_cases is not None:
        cases = rois.case_id.drop_duplicates().head(args.limit_cases)
        rois = rois[rois.case_id.isin(cases)].copy()
        pairs = pairs[pairs.case_id.isin(cases)].copy()
    return rois, pairs


def score_colipri(args: argparse.Namespace) -> int:
    import torch
    import torchio as tio
    from huggingface_hub import hf_hub_download
    from colipri import get_model, get_processor

    if not torch.cuda.is_available():
        raise RuntimeError("CoLiPri scoring requires a GPU")
    rois, pairs = load_manifests(args)
    checkpoint = Path(
        hf_hub_download(
            repo_id=args.colipri_model,
            filename="model.safetensors",
            revision=args.colipri_revision,
        )
    )
    checkpoint_before = sha256_file(checkpoint)
    device = torch.device(args.device)
    torch.cuda.set_device(device)
    processor = get_processor()
    model = get_model(checkpoint_path=checkpoint).to(device).eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    torch.cuda.reset_peak_memory_stats(device)
    result: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    started = time.perf_counter()
    roi_lookup = rois.set_index("roi_id")
    for index, (roi_id, group) in enumerate(pairs.groupby("roi_id", sort=True), start=1):
        try:
            roi = roi_lookup.loc[roi_id]
            image = np.load(roi.shared_roi_path, mmap_mode="r")
            actual_hash = sha256_bytes(np.asarray(image).tobytes(order="C"))
            if actual_hash != roi.shared_roi_sha256:
                raise RuntimeError(f"Shared ROI hash mismatch: {roi_id}")
            affine = np.asarray(json.loads(roi.shared_affine_json), dtype=np.float64)
            subject = tio.Subject(
                image=tio.ScalarImage(
                    tensor=torch.from_numpy(np.asarray(image, dtype=np.float32))[None],
                    affine=affine,
                )
            )
            transformed = processor._image_transform(subject)
            image_batch = transformed.image.data.float()[None]
            prompts = group.prompt_text.astype(str).tolist()
            raw_tokens = processor._text_tokenizer(prompts, truncation=False, add_special_tokens=True)
            raw_lengths = [len(item) for item in raw_tokens["input_ids"]]
            token_ids, attention_mask = processor.process_text(prompts)
            with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                dense = model.encode_image(image_batch, pool=False, project=True, normalize=True)
                pooled = model.encode_image(image_batch, pool=True, project=True, normalize=True)
                text = model.encode_text(
                    token_ids.to(device), attention_mask.to(device), pool=True, normalize=True
                )
                canonical = torch.einsum("bc,pc->p", pooled, text)
                maps = torch.einsum("bcdhw,pc->bpdhw", dense, text)[0]
            if not (torch.isfinite(canonical).all() and torch.isfinite(maps).all()):
                raise RuntimeError(f"Non-finite CoLiPri score: {roi_id}")
            for prompt_index, row in enumerate(group.itertuples(index=False)):
                summaries = score_summaries(maps[prompt_index], "dense_")
                result.append(
                    {
                        "pair_id": row.pair_id,
                        "roi_id": roi_id,
                        "case_id": row.case_id,
                        "finding_id": row.finding_id,
                        "prompt_hash": row.prompt_hash,
                        "prompt_text": row.prompt_text,
                        "prompt_form": row.prompt_form,
                        "is_correct": row.is_correct,
                        "negative_type": row.negative_type,
                        "same_case": row.same_case,
                        "target_category": row.target_category,
                        "target_focality": row.target_focality,
                        "target_size_bin": row.target_size_bin,
                        "scorer": "colipri_native",
                        "score_primary": float(canonical[prompt_index].float().item()),
                        "score_canonical_global": float(canonical[prompt_index].float().item()),
                        **summaries,
                        "shared_roi_sha256": actual_hash,
                        "model_input_shape": "x".join(map(str, image_batch.shape)),
                        "dense_map_shape": "x".join(map(str, maps[prompt_index].shape)),
                        "token_count_untruncated": raw_lengths[prompt_index],
                        "prompt_truncated": int(raw_lengths[prompt_index] > 512),
                    }
                )
            print(f"[{index}/{rois.shape[0]}] CoLiPri {roi_id}", flush=True)
        except Exception as exc:
            failures.append({"scorer": "colipri_native", "roi_id": roi_id, "error": repr(exc)})
    path = args.output_dir / "scores/colipri_scores.csv"
    write_csv(path, result)
    if failures:
        write_csv(args.output_dir / "failures_colipri.csv", failures)
    checkpoint_after = sha256_file(checkpoint)
    provenance = {
        "scorer": "colipri_native",
        "model": args.colipri_model,
        "image_encoder": "native frozen Primus-M with official CoLiPri projector",
        "text_encoder": "native frozen CXR-BERT with official CoLiPri projector",
        "feature_layer": "normalized 768-D projected pooled image and pooled text features",
        "image_pooling": "official CoLiPri global pool=True",
        "tokenizer": getattr(processor._text_tokenizer, "name_or_path", type(processor._text_tokenizer).__name__),
        "prompt_max_tokens": 512,
        "revision": args.colipri_revision,
        "checkpoint": str(checkpoint),
        "checkpoint_sha256_before": checkpoint_before,
        "checkpoint_sha256_after": checkpoint_after,
        "checkpoint_unchanged": checkpoint_before == checkpoint_after,
        "all_parameters_frozen": all(not p.requires_grad for p in model.parameters()),
        "equation": "dot(L2_normalize(project(pool(image))), L2_normalize(text))",
        "primary_score": "canonical pooled normalized image-text dot product",
        "dense_sensitivity": ["mean", "max", "top1_mean", "top5_mean"],
        "processor": "official CoLiPri RAS, 2mm isotropic, 192^3, HU[-1000,1000], [-1,1]",
        "runtime_seconds": time.perf_counter() - started,
        "peak_gpu_memory_gib": torch.cuda.max_memory_allocated(device) / 2**30,
        "gpu": torch.cuda.get_device_name(device),
        "host": socket.gethostname(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID", ""),
        "rows": len(result),
        "failures": len(failures),
    }
    (args.output_dir / "scores/colipri_provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    if failures:
        raise RuntimeError(f"CoLiPri failed on {len(failures)} ROIs")
    return 0


def embed_qwen_prompts(predictor, prompts: list[str], device, batch_size: int = 32):
    import torch
    from voxtell.utils.text_embedding import last_token_pool, wrap_with_instruction

    unique = list(dict.fromkeys(prompts))
    backbone = predictor.text_backbone.to(device).eval()
    output: dict[str, torch.Tensor] = {}
    lengths: dict[str, int] = {}
    for start in range(0, len(unique), batch_size):
        batch = unique[start : start + batch_size]
        wrapped = wrap_with_instruction(batch)
        untruncated = predictor.tokenizer(wrapped, truncation=False, add_special_tokens=True)
        for prompt, ids in zip(batch, untruncated["input_ids"]):
            lengths[prompt] = len(ids)
        tokens = predictor.tokenizer(
            wrapped,
            padding=True,
            truncation=True,
            max_length=predictor.max_text_length,
            return_tensors="pt",
        )
        tokens = {key: value.to(device) for key, value in tokens.items()}
        with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            hidden = backbone(**tokens).last_hidden_state
            embedded = last_token_pool(hidden, tokens["attention_mask"])
        for prompt, vector in zip(batch, embedded):
            output[prompt] = vector.float().cpu()
        print(f"embedded Qwen prompts {min(start + batch_size, len(unique))}/{len(unique)}", flush=True)
    predictor.text_backbone = backbone.to("cpu")
    torch.cuda.empty_cache()
    return output, lengths


def score_voxtell(args: argparse.Namespace) -> int:
    import torch

    for path in (ROOT / "VoxTell", ROOT / "scripts"):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    from voxtell.inference.predictor import VoxTellPredictor

    if not torch.cuda.is_available():
        raise RuntimeError("VoxTell scoring requires a GPU")
    rois, pairs = load_manifests(args)
    device = torch.device(args.device)
    torch.cuda.set_device(device)
    checkpoint_before = sha256_file(args.voxtell_checkpoint)
    started = time.perf_counter()
    predictor = VoxTellPredictor(
        str(args.voxtell_model_dir),
        device=device,
        checkpoint_path=str(args.voxtell_checkpoint),
        load_text_backbone=True,
    )
    network = predictor.network
    if not getattr(network, "enable_s3_voxel_text_matching_attention", False):
        raise RuntimeError("Selected VoxTell checkpoint does not enable S3")
    if "1/1" not in getattr(network, "s3_attention_scales", ()): 
        raise RuntimeError(f"Selected S3 scales lack 1/1: {network.s3_attention_scales}")
    for parameter in network.parameters():
        parameter.requires_grad_(False)
    embeddings, token_lengths = embed_qwen_prompts(
        predictor, pairs.prompt_text.astype(str).tolist(), device, args.text_batch_size
    )
    network = network.to(device).eval()
    torch.cuda.reset_peak_memory_stats(device)
    roi_lookup = rois.set_index("roi_id")
    result: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    for index, (roi_id, group) in enumerate(pairs.groupby("roi_id", sort=True), start=1):
        try:
            roi = roi_lookup.loc[roi_id]
            image_xyz = np.load(roi.shared_roi_path, mmap_mode="r")
            actual_hash = sha256_bytes(np.asarray(image_xyz).tobytes(order="C"))
            if actual_hash != roi.shared_roi_sha256:
                raise RuntimeError(f"Shared ROI hash mismatch: {roi_id}")
            image_zyx = np.asarray(image_xyz, dtype=np.float32).transpose(2, 1, 0)[None]
            image_zyx = predictor.normalization.run(image_zyx, None)
            image_tensor = torch.from_numpy(image_zyx)[None].to(device)
            prompts = group.prompt_text.astype(str).tolist()
            text = torch.stack([embeddings[prompt] for prompt in prompts], dim=0)[None].to(device)
            with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                _ = network(image_tensor, text)
            maps = network.last_s3_attention_logits.get("1/1", [])
            if len(maps) != len(prompts):
                raise RuntimeError(f"Expected {len(prompts)} S3 maps, got {len(maps)}")
            for prompt_index, (row, value) in enumerate(zip(group.itertuples(index=False), maps)):
                summaries = score_summaries(value, "s3_")
                result.append(
                    {
                        "pair_id": row.pair_id,
                        "roi_id": roi_id,
                        "case_id": row.case_id,
                        "finding_id": row.finding_id,
                        "prompt_hash": row.prompt_hash,
                        "prompt_text": row.prompt_text,
                        "prompt_form": row.prompt_form,
                        "is_correct": row.is_correct,
                        "negative_type": row.negative_type,
                        "same_case": row.same_case,
                        "target_category": row.target_category,
                        "target_focality": row.target_focality,
                        "target_size_bin": row.target_size_bin,
                        "scorer": "voxtell_s3_1over1",
                        "score_primary": summaries["s3_top1_mean"],
                        **summaries,
                        "shared_roi_sha256": actual_hash,
                        "model_input_shape": "x".join(map(str, image_tensor.shape)),
                        "dense_map_shape": "x".join(map(str, value.shape[-3:])),
                        "token_count_untruncated": token_lengths[row.prompt_text],
                        "prompt_truncated": int(token_lengths[row.prompt_text] > predictor.max_text_length),
                    }
                )
            del image_tensor, text, maps
            torch.cuda.empty_cache()
            print(f"[{index}/{rois.shape[0]}] VoxTell S3 {roi_id}", flush=True)
        except Exception as exc:
            failures.append({"scorer": "voxtell_s3_1over1", "roi_id": roi_id, "error": repr(exc)})
    write_csv(args.output_dir / "scores/voxtell_scores.csv", result)
    if failures:
        write_csv(args.output_dir / "failures_voxtell.csv", failures)
    checkpoint_after = sha256_file(args.voxtell_checkpoint)
    gate = network.s3_extra_attention_gates[network._s2_scale_key("1/1")]
    provenance = {
        "scorer": "voxtell_s3_1over1",
        "image_encoder": "VoxTell ResEncL image pathway",
        "text_encoder": "frozen Qwen/Qwen3-Embedding-4B plus VoxTell prompt projection",
        "tokenizer": "Qwen/Qwen3-Embedding-4B tokenizer with standard VoxTell instruction wrapper",
        "prompt_max_tokens": predictor.max_text_length,
        "checkpoint": str(args.voxtell_checkpoint.resolve()),
        "checkpoint_sha256_before": checkpoint_before,
        "checkpoint_sha256_after": checkpoint_after,
        "checkpoint_unchanged": checkpoint_before == checkpoint_after,
        "all_parameters_frozen": all(not p.requires_grad for p in network.parameters()),
        "feature_layer": "S3 1/1 decoder skip/coarse-context visual projection and prompt query projection",
        "equation": "exp(logit_scale)*dot(L2_normalize(visual_projection), L2_normalize(text_projection))+bias",
        "primary_score": "mean of top 1% pre-sigmoid S3 spatial logits",
        "sensitivity": ["global mean", "maximum", "top 5% mean"],
        "s3_logit_scale": float(gate.logit_scale.detach().exp().cpu()),
        "s3_bias": float(gate.bias.detach().cpu()),
        "preprocessing": "shared RAS physical ROI, XYZ->ZYX, per-ROI Z-score; no GT passed to model",
        "runtime_seconds": time.perf_counter() - started,
        "peak_gpu_memory_gib": torch.cuda.max_memory_allocated(device) / 2**30,
        "gpu": torch.cuda.get_device_name(device),
        "host": socket.gethostname(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID", ""),
        "rows": len(result),
        "failures": len(failures),
    }
    (args.output_dir / "scores/voxtell_provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    if failures:
        raise RuntimeError(f"VoxTell failed on {len(failures)} ROIs")
    return 0


def auc_ap(labels: np.ndarray, scores: np.ndarray) -> tuple[float, float]:
    from sklearn.metrics import average_precision_score, roc_auc_score

    if len(np.unique(labels)) < 2:
        return float("nan"), float("nan")
    return float(roc_auc_score(labels, scores)), float(average_precision_score(labels, scores))


def evaluate_one(frame: pd.DataFrame, score_col: str) -> dict[str, float | int]:
    primary = frame[frame.prompt_form.eq("original")].copy()
    positives = primary[primary.is_correct.eq(1)].set_index("roi_id")[score_col]
    negatives = primary[primary.is_correct.eq(0)].copy()
    margins = positives.loc[negatives.roi_id].to_numpy() - negatives[score_col].to_numpy()
    ranks: list[int] = []
    top1: list[float] = []
    same_case_top1: list[float] = []
    hardest: list[float] = []
    for roi_id, group in primary.groupby("roi_id"):
        correct = group[group.is_correct.eq(1)][score_col]
        if len(correct) != 1:
            continue
        correct_score = float(correct.iloc[0])
        rank = 1 + int((group.loc[group.is_correct.eq(0), score_col] >= correct_score).sum())
        ranks.append(rank)
        top1.append(float(rank == 1))
        neg = group[group.is_correct.eq(0)][score_col]
        hardest.append(correct_score - float(neg.max()))
        same = group[(group.is_correct.eq(0)) & (group.same_case.eq(1))]
        if len(same):
            same_case_top1.append(float(correct_score > float(same[score_col].max())))
    labels = primary.is_correct.to_numpy(dtype=np.uint8)
    auc, ap = auc_ap(labels, primary[score_col].to_numpy())
    return {
        "top1": float(np.mean(top1)),
        "same_case_top1": float(np.mean(same_case_top1)) if same_case_top1 else float("nan"),
        "mrr": float(np.mean(1.0 / np.asarray(ranks))),
        "median_rank": float(np.median(ranks)),
        "pairwise_win_rate": float(np.mean(margins > 0)),
        "mean_pairwise_margin": float(np.mean(margins)),
        "hardest_negative_margin": float(np.mean(hardest)),
        "auroc": auc,
        "auprc": ap,
        "findings": len(ranks),
        "positive_pairs": int(labels.sum()),
        "negative_pairs": int((labels == 0).sum()),
        "same_case_findings": len(same_case_top1),
    }


def binary_by_type(frame: pd.DataFrame, score_col: str) -> list[dict[str, Any]]:
    primary = frame[frame.prompt_form.eq("original")]
    rows = []
    negatives = primary[primary.is_correct.eq(0)]
    groups = list(negatives.groupby("negative_type", sort=True))
    hard_types = {
        "same_case",
        "same_case_same_entity",
        "same_entity",
        "same_anatomy",
        "anatomy_swapped",
    }
    hard = negatives[negatives.negative_type.isin(hard_types)]
    if len(hard):
        groups.append(("all_hard_combined", hard))
    for negative_type, negative in groups:
        eligible = set(negative.roi_id)
        positive = primary[(primary.is_correct.eq(1)) & primary.roi_id.isin(eligible)]
        sample = pd.concat([positive, negative], ignore_index=True)
        auc, ap = auc_ap(sample.is_correct.to_numpy(), sample[score_col].to_numpy())
        pos = positive.set_index("roi_id")[score_col]
        margins = pos.loc[negative.roi_id].to_numpy() - negative[score_col].to_numpy()
        rows.append(
            {
                "negative_type": negative_type,
                "auroc": auc,
                "auprc": ap,
                "pairwise_win_rate": float(np.mean(margins > 0)),
                "mean_margin": float(np.mean(margins)),
                "cases": int(sample.case_id.nunique()),
                "findings": len(eligible),
                "negative_pairs": len(negative),
            }
        )
    return rows


def bootstrap_differences(
    colipri: pd.DataFrame,
    voxtell: pd.DataFrame,
    reps: int,
    seed: int,
) -> dict[str, Any]:
    from sklearn.metrics import average_precision_score, roc_auc_score

    c = colipri[colipri.prompt_form.eq("original")].copy()
    v = voxtell[voxtell.prompt_form.eq("original")].copy()
    cases = sorted(set(c.case_id) & set(v.case_id))
    case_to_index = {case: index for index, case in enumerate(cases)}
    rng = np.random.default_rng(seed)
    metrics = ("top1", "pairwise_win_rate", "auroc", "auprc", "mrr")
    values = {metric: np.empty(reps, dtype=np.float64) for metric in metrics}

    def retrieval_rows(frame: pd.DataFrame) -> pd.DataFrame:
        rows = []
        for roi_id, group in frame.groupby("roi_id"):
            positive = group[group.is_correct.eq(1)]
            if len(positive) != 1:
                continue
            score = float(positive.score_primary.iloc[0])
            rank = 1 + int((group.loc[group.is_correct.eq(0), "score_primary"] >= score).sum())
            rows.append(
                {
                    "roi_id": roi_id,
                    "case_id": positive.case_id.iloc[0],
                    "top1": float(rank == 1),
                    "mrr": 1.0 / rank,
                }
            )
        return pd.DataFrame(rows)

    def pair_rows(frame: pd.DataFrame) -> pd.DataFrame:
        positive = frame[frame.is_correct.eq(1)].set_index("roi_id").score_primary
        negative = frame[frame.is_correct.eq(0)].copy()
        negative["win"] = (
            positive.loc[negative.roi_id].to_numpy() > negative.score_primary.to_numpy()
        ).astype(float)
        return negative[["pair_id", "case_id", "win"]]

    retrieval = retrieval_rows(c).merge(
        retrieval_rows(v), on=["roi_id", "case_id"], suffixes=("_c", "_v"), validate="one_to_one"
    )
    pairwise = pair_rows(c).merge(
        pair_rows(v), on=["pair_id", "case_id"], suffixes=("_c", "_v"), validate="one_to_one"
    )
    binary = c[["pair_id", "case_id", "is_correct", "score_primary"]].merge(
        v[["pair_id", "case_id", "is_correct", "score_primary"]],
        on=["pair_id", "case_id", "is_correct"],
        suffixes=("_c", "_v"),
        validate="one_to_one",
    )
    retrieval_case = retrieval.case_id.map(case_to_index).to_numpy()
    pair_case = pairwise.case_id.map(case_to_index).to_numpy()
    binary_case = binary.case_id.map(case_to_index).to_numpy()
    labels = binary.is_correct.to_numpy(dtype=np.uint8)
    for rep in range(reps):
        counts = rng.multinomial(len(cases), np.full(len(cases), 1.0 / len(cases)))
        rw = counts[retrieval_case]
        pw = counts[pair_case]
        bw = counts[binary_case]
        values["top1"][rep] = np.average(retrieval.top1_c, weights=rw) - np.average(retrieval.top1_v, weights=rw)
        values["mrr"][rep] = np.average(retrieval.mrr_c, weights=rw) - np.average(retrieval.mrr_v, weights=rw)
        values["pairwise_win_rate"][rep] = np.average(pairwise.win_c, weights=pw) - np.average(pairwise.win_v, weights=pw)
        values["auroc"][rep] = roc_auc_score(labels, binary.score_primary_c, sample_weight=bw) - roc_auc_score(labels, binary.score_primary_v, sample_weight=bw)
        values["auprc"][rep] = average_precision_score(labels, binary.score_primary_c, sample_weight=bw) - average_precision_score(labels, binary.score_primary_v, sample_weight=bw)
    output = {}
    for metric, array in values.items():
        output[metric] = {
            "mean_bootstrap_difference": float(array.mean()),
            "ci95_low": float(np.percentile(array, 2.5)),
            "ci95_high": float(np.percentile(array, 97.5)),
            "replicates": reps,
            "cluster_unit": "case",
        }
    return output


def evaluate(args: argparse.Namespace) -> int:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rois = pd.read_csv(args.output_dir / "matched_roi_manifest.csv")
    pairs = pd.read_csv(args.output_dir / "matched_prompt_pairs.csv")
    pairs = pairs[pairs.included.astype(bool)].copy()
    c = pd.read_csv(args.output_dir / "scores/colipri_scores.csv")
    v = pd.read_csv(args.output_dir / "scores/voxtell_scores.csv")
    expected = set(pairs.pair_id)
    common = expected & set(c.pair_id) & set(v.pair_id)
    attrition = len(expected) - len(common)
    c = c[c.pair_id.isin(common)].copy()
    v = v[v.pair_id.isin(common)].copy()
    merged = c.merge(v, on="pair_id", suffixes=("_colipri", "_voxtell"), validate="one_to_one")
    for field in ("prompt_hash", "shared_roi_sha256", "roi_id", "case_id"):
        if not (merged[f"{field}_colipri"] == merged[f"{field}_voxtell"]).all():
            raise RuntimeError(f"Anti-confounding join failed for {field}")
    merged.to_csv(args.output_dir / "matched_scores.csv", index=False)

    cm = evaluate_one(c, "score_primary")
    vm = evaluate_one(v, "score_primary")
    ctype = pd.DataFrame(binary_by_type(c, "score_primary")); ctype["model"] = "CoLiPri"
    vtype = pd.DataFrame(binary_by_type(v, "score_primary")); vtype["model"] = "VoxTell"
    by_type = ctype.merge(vtype, on="negative_type", suffixes=("_colipri", "_voxtell"))
    by_type["auroc_difference"] = by_type.auroc_colipri - by_type.auroc_voxtell
    by_type["auprc_difference"] = by_type.auprc_colipri - by_type.auprc_voxtell

    bootstrap = bootstrap_differences(c, v, args.bootstrap_reps, args.seed)
    (args.output_dir / "bootstrap.json").write_text(json.dumps(bootstrap, indent=2) + "\n")

    primary_c = c[c.prompt_form.eq("original")]
    primary_v = v[v.prompt_form.eq("original")]
    hard_types = {
        "same_case",
        "same_case_same_entity",
        "same_entity",
        "same_anatomy",
        "anatomy_swapped",
    }
    type_bootstrap: dict[str, Any] = {}
    for type_index, negative_type in enumerate(by_type.negative_type):
        if negative_type == "all_hard_combined":
            cneg = primary_c[(primary_c.is_correct.eq(0)) & primary_c.negative_type.isin(hard_types)]
            vneg = primary_v[(primary_v.is_correct.eq(0)) & primary_v.negative_type.isin(hard_types)]
        else:
            cneg = primary_c[(primary_c.is_correct.eq(0)) & primary_c.negative_type.eq(negative_type)]
            vneg = primary_v[(primary_v.is_correct.eq(0)) & primary_v.negative_type.eq(negative_type)]
        eligible = set(cneg.roi_id) & set(vneg.roi_id)
        csub = pd.concat(
            [primary_c[(primary_c.is_correct.eq(1)) & primary_c.roi_id.isin(eligible)], cneg[cneg.roi_id.isin(eligible)]],
            ignore_index=True,
        )
        vsub = pd.concat(
            [primary_v[(primary_v.is_correct.eq(1)) & primary_v.roi_id.isin(eligible)], vneg[vneg.roi_id.isin(eligible)]],
            ignore_index=True,
        )
        type_bootstrap[str(negative_type)] = bootstrap_differences(
            csub,
            vsub,
            args.bootstrap_reps,
            args.seed + 100 + type_index,
        )
    (args.output_dir / "bootstrap_by_negative_type.json").write_text(
        json.dumps(type_bootstrap, indent=2) + "\n"
    )
    by_type["auroc_difference_ci95_low"] = by_type.negative_type.map(
        lambda name: type_bootstrap[str(name)]["auroc"]["ci95_low"]
    )
    by_type["auroc_difference_ci95_high"] = by_type.negative_type.map(
        lambda name: type_bootstrap[str(name)]["auroc"]["ci95_high"]
    )
    by_type["auprc_difference_ci95_low"] = by_type.negative_type.map(
        lambda name: type_bootstrap[str(name)]["auprc"]["ci95_low"]
    )
    by_type["auprc_difference_ci95_high"] = by_type.negative_type.map(
        lambda name: type_bootstrap[str(name)]["auprc"]["ci95_high"]
    )
    by_type.to_csv(args.output_dir / "binary_metrics_by_negative_type.csv", index=False)

    subgroup_rows = []
    case_counts = rois.groupby("case_id").size()
    repeated_entity = rois.groupby(["case_id", "category"]).size()
    same_entity_cases = set(repeated_entity[repeated_entity > 1].index.get_level_values(0))
    subgroup_masks = {
        "single_finding_case": rois.case_id.map(case_counts).eq(1),
        "multi_finding_case": rois.case_id.map(case_counts).gt(1),
        "same_entity_multiple_findings": rois.case_id.isin(same_entity_cases),
        "tiny_or_small": rois.size_bin.isin(["tiny", "small"]),
        "diffuse": rois.focality.eq("diffuse"),
        "focal": rois.focality.eq("focal"),
    }
    for name, mask in subgroup_masks.items():
        ids = set(rois.loc[mask, "roi_id"])
        for model_name, frame in (("CoLiPri", c), ("VoxTell", v)):
            sample = frame[frame.roi_id.isin(ids)]
            if sample.roi_id.nunique() < 2:
                continue
            metric = evaluate_one(sample, "score_primary")
            subgroup_rows.append({"subgroup": name, "model": model_name, **metric})
    pd.DataFrame(subgroup_rows).to_csv(args.output_dir / "subgroup_metrics.csv", index=False)

    ablation_rows = []
    for form in ("original", "entity_only", "entity_anatomy"):
        for model_name, frame in (("CoLiPri", c), ("VoxTell", v)):
            positives = frame[(frame.prompt_form.eq(form)) & frame.is_correct.eq(1)].copy()
            negatives = frame[(frame.prompt_form.eq("original")) & frame.is_correct.eq(0)].copy()
            eligible = set(positives.roi_id) & set(negatives.roi_id)
            sample = pd.concat(
                [positives[positives.roi_id.isin(eligible)], negatives[negatives.roi_id.isin(eligible)]],
                ignore_index=True,
            )
            sample["prompt_form"] = "original"
            if eligible:
                ablation_rows.append({"prompt_form": form, "model": model_name, **evaluate_one(sample, "score_primary")})
    pd.DataFrame(ablation_rows).to_csv(args.output_dir / "prompt_ablation_metrics.csv", index=False)

    sensitivity = []
    for model_name, frame, columns in (
        ("CoLiPri", c, ["score_canonical_global", "dense_top1_mean", "dense_mean", "dense_max", "dense_top5_mean"]),
        ("VoxTell", v, ["s3_top1_mean", "s3_mean", "s3_max", "s3_top5_mean"]),
    ):
        for column in columns:
            metric = evaluate_one(frame, column)
            sensitivity.append({"model": model_name, "aggregation": column, **metric})
    pd.DataFrame(sensitivity).to_csv(args.output_dir / "aggregation_sensitivity.csv", index=False)

    plots = args.output_dir / "plots"; plots.mkdir(exist_ok=True)
    primary = merged[merged.prompt_form_colipri.eq("original")].copy()
    order = ["correct"] + sorted(set(primary.negative_type_colipri) - {"correct"})
    fig, axes = plt.subplots(1, 2, figsize=(15, 5), constrained_layout=True)
    for axis, model, column in ((axes[0], "CoLiPri", "score_primary_colipri"), (axes[1], "VoxTell", "score_primary_voxtell")):
        arrays = [primary.loc[primary.negative_type_colipri.eq(item), column].to_numpy() for item in order]
        axis.boxplot(arrays, tick_labels=order, showfliers=False)
        axis.tick_params(axis="x", rotation=35); axis.set_title(f"{model} matched scores"); axis.set_ylabel("compatibility score")
    fig.savefig(plots / "matched_score_distributions.png", dpi=160); plt.close(fig)

    hard = by_type[by_type.negative_type.eq("all_hard_combined")]
    random_row = by_type[by_type.negative_type.eq("random_case")]
    hard_advantage = bool(
        len(hard)
        and float(hard.auroc_difference.iloc[0]) > 0
        and float(hard.auroc_difference_ci95_low.iloc[0]) > 0
    )
    random_advantage = bool(len(random_row) and float(random_row.auroc_difference.iloc[0]) > 0)
    if (
        attrition / max(len(expected), 1) > 0.1
        or hard.empty
        or float(hard.cases_colipri.max()) < 20
    ):
        verdict = "D. INCONCLUSIVE"
    elif hard_advantage:
        verdict = "A. MATCHED ADVANTAGE"
    elif random_advantage and float(hard.auroc_difference.iloc[0]) <= 0:
        verdict = "B. EASY-NEGATIVE ADVANTAGE ONLY"
    else:
        verdict = "C. NO MATCHED ADVANTAGE"

    successful_rois = set(c.roi_id) & set(v.roi_id)
    metrics = {
        "colipri": cm,
        "voxtell": vm,
        "differences_colipri_minus_voxtell": {key: float(cm[key]) - float(vm[key]) for key in ("top1", "same_case_top1", "mrr", "pairwise_win_rate", "auroc", "auprc")},
        "case_count": int(rois[rois.roi_id.isin(successful_rois)].case_id.nunique()),
        "finding_count": int(rois[rois.roi_id.isin(successful_rois)].roi_id.nunique()),
        "expected_pair_rows": len(expected),
        "matched_pair_rows": len(common),
        "attrition_rows": attrition,
        "verdict": verdict,
    }
    failure_columns = ["model", "case_id", "roi_id", "pair_id", "stage", "error"]
    active_failure_frames = []
    for failure_path in sorted(args.output_dir.glob("failures_*.csv")):
        if failure_path.name.startswith("resolved_"):
            continue
        frame = pd.read_csv(failure_path)
        if len(frame):
            active_failure_frames.append(frame)
    active_failures = (
        pd.concat(active_failure_frames, ignore_index=True)
        if active_failure_frames
        else pd.DataFrame(columns=failure_columns)
    )
    active_failures.reindex(columns=failure_columns).to_csv(args.output_dir / "failures.csv", index=False)
    (args.output_dir / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    write_final_report(args, rois, pairs, metrics, by_type, bootstrap, verdict)
    print_console_summary(args, metrics, bootstrap, verdict)
    return 0


def write_final_report(args, rois, pairs, metrics, by_type, bootstrap, verdict) -> None:
    report_path = ROOT / "reports/colipri_vs_voxtell_matched_alignment_benchmark.md"
    report_path.parent.mkdir(exist_ok=True)
    c = metrics["colipri"]; v = metrics["voxtell"]
    hard_count = int(pairs[(pairs.included.astype(bool)) & pairs.negative_type.isin(["same_case", "same_case_same_entity", "same_entity", "same_anatomy", "anatomy_swapped"])].shape[0])
    type_table = dataframe_to_markdown(
        by_type[[
            "negative_type",
            "auroc_colipri",
            "auroc_voxtell",
            "auroc_difference",
            "auroc_difference_ci95_low",
            "auroc_difference_ci95_high",
            "auprc_colipri",
            "auprc_voxtell",
            "findings_colipri",
        ]]
    )
    prompt_frame = pd.read_csv(args.output_dir / "prompt_ablation_metrics.csv")
    prompt_table = dataframe_to_markdown(
        prompt_frame[
            ["prompt_form", "model", "top1", "mrr", "auroc", "auprc"]
        ]
    )
    subgroup_table = dataframe_to_markdown(
        pd.read_csv(args.output_dir / "subgroup_metrics.csv")[
            ["subgroup", "model", "findings", "top1", "pairwise_win_rate", "auroc", "auprc"]
        ]
    )
    bootstrap_table = dataframe_to_markdown(
        pd.DataFrame(
            [
                {
                    "metric": metric,
                    "difference": float(metrics["colipri"][metric]) - float(metrics["voxtell"][metric]),
                    "ci95_low": values["ci95_low"],
                    "ci95_high": values["ci95_high"],
                    "replicates": values["replicates"],
                }
                for metric, values in bootstrap.items()
            ]
        )
    )
    roi_coverage = float(rois.target_gt_fraction_in_roi.mean())
    excluded_pairs = pairs[~pairs.included.astype(bool)]
    colipri_scores = pd.read_csv(args.output_dir / "scores/colipri_scores.csv")
    voxtell_scores = pd.read_csv(args.output_dir / "scores/voxtell_scores.csv")
    active_failures_path = args.output_dir / "failures.csv"
    active_failure_count = len(pd.read_csv(active_failures_path)) if active_failures_path.exists() else 0
    resolved_history_path = args.output_dir / "resolved_prepare_failure_history.csv"
    hard_row = by_type[by_type.negative_type.eq("all_hard_combined")].iloc[0]
    random_row = by_type[by_type.negative_type.eq("random_case")].iloc[0]
    same_case_row = by_type[by_type.negative_type.eq("same_case")].iloc[0]
    same_case_entity_row = by_type[by_type.negative_type.eq("same_case_same_entity")].iloc[0]
    colipri_prompt = prompt_frame[prompt_frame.model.eq("CoLiPri")].set_index("prompt_form")
    entity_delta = float(colipri_prompt.loc["entity_only", "auroc"] - colipri_prompt.loc["original", "auroc"])
    prompt_interpretation = (
        "CoLiPri performance is preserved or improved by entity-only text, which is more consistent with coarse entity recognition than detailed grounding."
        if entity_delta >= -0.01
        else "CoLiPri loses discrimination with entity-only text, indicating that detailed wording contributes beyond coarse entity recognition."
    )
    lines = [
        "# CoLiPri vs VoxTell Matched Alignment Benchmark",
        "",
        "## 1. Bottom-line verdict",
        "",
        f"**{verdict}**",
        "",
        "The verdict is based on identical cached physical ROIs, prompt strings, and pair rows. "
        "CoLiPri uses its canonical pooled normalized similarity; VoxTell uses the preregistered top-1% mean of direct S3 pre-sigmoid similarity logits.",
        "This is a qualified matched advantage: CoLiPri is stronger overall and on cross-case same-entity/same-anatomy negatives, but it is weaker than VoxTell for within-case discrimination. It should not be interpreted as uniformly stronger instance localization.",
        "",
        "## 2. Historical comparison reproduction",
        "",
        "The historical AUROCs (CoLiPri 0.808642, VoxTell 0.506173) were reproduced from the stored summary, but used a 5-case/9-finding post-hoc intersection, different image regions, independent shuffled negatives, and unlike scalar definitions. They are not evidence for the present verdict. See `reports/colipri_voxtell_matched_alignment_starting_state.md`.",
        "",
        "| Model | Score definition | Cohort | Negatives | AUROC | Comparable? |",
        "|---|---|---|---|---:|---|",
        "| Native CoLiPri | whole-case pooled native cosine | 5 cases / 9 focal findings | independent random shuffle | 0.808642 | No |",
        "| VoxTell | GT inside-minus-outside decoder response | 5 cases / 9 focal findings | different independent shuffle | 0.506173 | No |",
        "",
        "## 3. Models and score definitions",
        "",
        f"- CoLiPri: `microsoft/colipri` revision `{COLIPRI_REVISION}`; frozen Primus-M and CXR-BERT native 768-D projected space; `dot(L2(image), L2(text))`; official 2 mm/192^3 processor after shared ROI extraction.",
        f"- VoxTell: `{DEFAULT_S3_CHECKPOINT}`; frozen full-category 1/1 S3 model and Qwen3-Embedding-4B; pre-sigmoid S3 cosine logit map; primary top 1% mean.",
        "- Higher is better for both. No segmentation probability, Dice, or final mask is used.",
        "",
        "## 4. Matched cohort and ROI construction",
        "",
        f"- Cases: {metrics['case_count']}; findings: {metrics['finding_count']}; matched rows: {metrics['matched_pair_rows']}.",
        f"- Each target uses a RAS cube centered on its GT world-coordinate bbox, at least 192 mm wide, with 24 mm context per side and side rounded to 8 mm, cached on one shared 192^3 grid.",
        f"- Mean target GT coverage: {roi_coverage:.6f}. The shared float16 ROI SHA256 is checked independently by both scorers.",
        "- GT is never passed to either encoder or score function.",
        "",
        "## 5. Prompt and negative construction",
        "",
        dataframe_to_markdown(
            pairs[pairs.included.astype(bool)].negative_type.value_counts().rename_axis("type").reset_index(name="rows")
        ),
        "",
        f"Hard-negative rows: {hard_count}. Same-case natural negatives whose corresponding GT has >{AMBIGUITY_THRESHOLD:.0%} of its voxels inside the target ROI are symmetrically excluded.",
        "",
        "## 6. Primary matched results",
        "",
        "| Model | Top-1 | Same-case Top-1 | MRR | Pairwise win rate | Hardest-negative margin | AUROC | AUPRC |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
        f"| CoLiPri | {c['top1']:.4f} | {c['same_case_top1']:.4f} | {c['mrr']:.4f} | {c['pairwise_win_rate']:.4f} | {c['hardest_negative_margin']:.4f} | {c['auroc']:.4f} | {c['auprc']:.4f} |",
        f"| VoxTell | {v['top1']:.4f} | {v['same_case_top1']:.4f} | {v['mrr']:.4f} | {v['pairwise_win_rate']:.4f} | {v['hardest_negative_margin']:.4f} | {v['auroc']:.4f} | {v['auprc']:.4f} |",
        "",
        type_table,
        "",
        f"Paired case-bootstrap AUROC difference (CoLiPri - VoxTell): {bootstrap['auroc']['mean_bootstrap_difference']:+.4f}, 95% CI [{bootstrap['auroc']['ci95_low']:+.4f}, {bootstrap['auroc']['ci95_high']:+.4f}], {bootstrap['auroc']['replicates']} replicates.",
        "",
        bootstrap_table,
        "",
        "## 7. Hard-negative analysis",
        "",
        f"CoLiPri minus VoxTell AUROC is {float(random_row.auroc_difference):+.4f} for random-case negatives and {float(hard_row.auroc_difference):+.4f} for all hard negatives combined (95% CI [{float(hard_row.auroc_difference_ci95_low):+.4f}, {float(hard_row.auroc_difference_ci95_high):+.4f}]). The verdict requires a credible hard-negative advantage and cannot be triggered by random negatives alone.",
        f"The advantage is not uniform. For same-case negatives, the AUROC difference is {float(same_case_row.auroc_difference):+.4f} (95% CI [{float(same_case_row.auroc_difference_ci95_low):+.4f}, {float(same_case_row.auroc_difference_ci95_high):+.4f}]); for same-case same-entity negatives it is {float(same_case_entity_row.auroc_difference):+.4f} (95% CI [{float(same_case_entity_row.auroc_difference_ci95_low):+.4f}, {float(same_case_entity_row.auroc_difference_ci95_high):+.4f}]). Same-case top-1 is {c['same_case_top1']:.4f} for CoLiPri versus {v['same_case_top1']:.4f} for VoxTell. VoxTell is therefore better at the hardest within-CT multi-finding distinction.",
        "",
        "## 8. Prompt-form ablations",
        "",
        "Original, entity-only, and entity+anatomy positives are scored against the same original negative pool:",
        "",
        prompt_table,
        "",
        prompt_interpretation,
        "",
        "## 8.1 Difficult subgroups",
        "",
        subgroup_table,
        "",
        "## 9. Optional component diagnostic",
        "",
        "Not run in the primary benchmark. Existing P0 component manifests are indexed in preprocessed/candidate voxel coordinates rather than validated original physical bounds, so adapting them here would violate the exact-physical-ROI requirement.",
        "",
        "| Model | Component AUROC | AUPRC | Top-1 correct component | Same-anatomy FP result |",
        "|---|---:|---:|---:|---|",
        "| CoLiPri | not run | not run | not run | physical component bounds unavailable |",
        "| VoxTell | not run | not run | not run | physical component bounds unavailable |",
        "",
        "## 10. Failure and attrition audit",
        "",
        f"Expected included rows: {metrics['expected_pair_rows']}; common successful rows: {metrics['matched_pair_rows']}; symmetric attrition: {metrics['attrition_rows']}.",
        "",
        f"- Active failures: {active_failure_count}; consolidated in `failures.csv`.",
        f"- Resolved preparation history: {'one tiny-lesion occupancy-resampling failure, fixed by the preregistered diagnostic occupancy rescue and retained in `resolved_prepare_failure_history.csv`' if resolved_history_path.exists() else 'none'}.",
        f"- Same physical ROI: verified by one shared cache path and SHA256; all {metrics['matched_pair_rows']} joined rows matched.",
        f"- Same prompt strings and pair rows: exact prompt hashes and one-to-one `pair_id` join verified for all common rows.",
        f"- No GT leakage: GT is used only in `prepare`; scorer functions receive CT arrays and prompt strings, not masks.",
        f"- Frozen weights: both provenance files report all parameters frozen and identical checkpoint SHA256 before/after.",
        f"- Prompt truncation: CoLiPri {int(colipri_scores.prompt_truncated.sum())} rows; VoxTell {int(voxtell_scores.prompt_truncated.sum())} rows.",
        f"- Crop coverage: mean {roi_coverage:.6f}; minimum {float(rois.target_gt_fraction_in_roi.min()):.6f}.",
        f"- Multi-finding ambiguity: {int((rois.other_findings_with_any_gt_in_roi > 0).sum())} ROIs contain at least one voxel from another finding; ambiguous natural negatives were excluded.",
        f"- Duplicate/ambiguity exclusions: {len(excluded_pairs)} rows; reasons remain in `matched_prompt_pairs.csv`.",
        f"- Score direction: higher means greater compatibility for both scorers.",
        f"- Cached-embedding consistency: no old image/text embedding cache was reused; only the shared image ROI cache was reused after SHA256 validation.",
        "- Per-row input shapes and token counts are retained in `scores/*.csv`; runtime, GPU memory, job ID, scorer equation, and checkpoint provenance are in `scores/*_provenance.json`.",
        "",
        "## 11. Scientific interpretation",
        "",
        f"The conservative interpretation is **{verdict}**. Ranking and hard-negative results, rather than cross-model raw score scale, determine this conclusion. "
        + ("CoLiPri provides stronger matched alignment overall and on cross-case same-entity/same-anatomy negatives, but not stronger within-case instance grounding. The evidence extends beyond random category recognition while remaining insufficient to treat CoLiPri as a sole instance selector." if verdict.startswith("A.") else "The result does not establish stronger CoLiPri instance-level grounding."),
        "",
        "## 12. Next-step recommendation",
        "",
        {"A. MATCHED ADVANTAGE": "Test frozen CoLiPri similarity as one added feature in an existing router.", "B. EASY-NEGATIVE ADVANTAGE ONLY": "At most test a coarse presence prior; do not use CoLiPri for instance selection.", "C. NO MATCHED ADVANTAGE": "Stop the CoLiPri integration direction.", "D. INCONCLUSIVE": "Run one bounded missing hard-negative cohort test after resolving the listed coverage/attrition issue."}[verdict],
        "",
        "## 13. Reproduction commands",
        "",
        "```bash",
        f"python scripts/colipri_voxtell_matched_alignment.py prepare --output-dir {args.output_dir}",
        f"python scripts/colipri_voxtell_matched_alignment.py score-colipri --output-dir {args.output_dir}",
        f"python scripts/colipri_voxtell_matched_alignment.py score-voxtell --output-dir {args.output_dir}",
        f"python scripts/colipri_voxtell_matched_alignment.py evaluate --output-dir {args.output_dir} --bootstrap-reps {args.bootstrap_reps}",
        "```",
        "",
        "Smoke uses the same commands with a separate output root and `--limit-cases 5` on prepare/scorers.",
        "",
        "## 14. Modified and created files",
        "",
        "- `scripts/colipri_voxtell_matched_alignment.py`: prepare, score, and evaluate pipeline.",
        "- `scripts/run_colipri_voxtell_matched_alignment_{smoke,full}.sbatch`: isolated SLURM entry points.",
        "- `tests/test_colipri_voxtell_matched_alignment.py`: ROI and prompt-pair correctness tests.",
        f"- `{args.output_dir}`: manifests, scores, statistics, plots, failures, and provenance.",
    ]
    report_path.write_text("\n".join(lines) + "\n")


def print_console_summary(args, metrics, bootstrap, verdict) -> None:
    c = metrics["colipri"]; v = metrics["voxtell"]
    hard_rows = pd.read_csv(args.output_dir / "matched_prompt_pairs.csv")
    hard_rows = hard_rows[(hard_rows.included.astype(bool)) & ~hard_rows.negative_type.isin(["correct", "random_case"])]
    job_ids = []
    for path in (args.output_dir / "scores").glob("*_provenance.json"):
        value = json.loads(path.read_text()).get("slurm_job_id")
        if value:
            job_ids.append(value)
    job_ids = sorted(set(job_ids))
    print(f"Historical comparison reproduced: yes (0.808642 vs 0.506173; not comparable)")
    print(f"Matched cohort: {metrics['finding_count']} target ROIs")
    print(f"Cases: {metrics['case_count']}")
    print(f"Findings: {metrics['finding_count']}")
    print(f"Matched pair rows: {metrics['matched_pair_rows']}")
    print(f"Hard-negative rows: {len(hard_rows)}")
    print(f"CoLiPri primary AUROC: {c['auroc']:.6f}")
    print(f"VoxTell primary AUROC: {v['auroc']:.6f}")
    print(f"AUROC difference and 95% CI: {c['auroc']-v['auroc']:+.6f} [{bootstrap['auroc']['ci95_low']:+.6f}, {bootstrap['auroc']['ci95_high']:+.6f}]")
    print(f"CoLiPri same-case top-1: {c['same_case_top1']:.6f}")
    print(f"VoxTell same-case top-1: {v['same_case_top1']:.6f}")
    print(f"Overall verdict: {verdict}")
    if verdict.startswith("A.") and c["same_case_top1"] <= v["same_case_top1"]:
        grounding_answer = "qualified cross-case hard-negative evidence; not stronger same-case multi-instance grounding"
    else:
        grounding_answer = "yes" if verdict.startswith("A.") else "no"
    print(f"Does evidence support CoLiPri instance-level grounding?: {grounding_answer}")
    recommendation = {"A": "test frozen similarity in an existing router", "B": "coarse presence prior only", "C": "stop CoLiPri integration", "D": "one bounded missing hard-negative test"}[verdict[0]]
    print(f"Recommended next action: {recommendation}")
    print(f"Report path: {ROOT / 'reports/colipri_vs_voxtell_matched_alignment_benchmark.md'}")
    print(f"Output path: {args.output_dir}")
    print(f"Job IDs: {','.join(job_ids) if job_ids else 'none/local'}")


def parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    common.add_argument("--limit-cases", type=int)
    common.add_argument("--seed", type=int, default=SEED)
    command = argparse.ArgumentParser(description=__doc__)
    sub = command.add_subparsers(dest="command", required=True)
    prepare_parser = sub.add_parser("prepare", parents=[common])
    prepare_parser.add_argument("--rex-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    prepare_parser.add_argument("--split", default="val")
    prepare_parser.add_argument("--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed")
    prepare_parser.add_argument("--mask-dir", type=Path, default=ROOT / "data/segmentations")
    prepare_parser.add_argument("--overwrite-cache", action="store_true")
    prepare_parser.add_argument("--case-id")
    colipri_parser = sub.add_parser("score-colipri", parents=[common])
    colipri_parser.add_argument("--device", default="cuda:0")
    colipri_parser.add_argument("--colipri-model", default="microsoft/colipri")
    colipri_parser.add_argument("--colipri-revision", default=COLIPRI_REVISION)
    voxtell_parser = sub.add_parser("score-voxtell", parents=[common])
    voxtell_parser.add_argument("--device", default="cuda:0")
    voxtell_parser.add_argument("--voxtell-model-dir", type=Path, default=DEFAULT_S3_RUN)
    voxtell_parser.add_argument("--voxtell-checkpoint", type=Path, default=DEFAULT_S3_CHECKPOINT)
    voxtell_parser.add_argument("--text-batch-size", type=int, default=32)
    evaluate_parser = sub.add_parser("evaluate", parents=[common])
    evaluate_parser.add_argument("--bootstrap-reps", type=int, default=10_000)
    return command


def main() -> int:
    args = parser().parse_args()
    args.output_dir = args.output_dir.resolve()
    if args.command == "prepare":
        return prepare(args)
    if args.command == "score-colipri":
        return score_colipri(args)
    if args.command == "score-voxtell":
        return score_voxtell(args)
    if args.command == "evaluate":
        return evaluate(args)
    raise AssertionError(args.command)


if __name__ == "__main__":
    raise SystemExit(main())
