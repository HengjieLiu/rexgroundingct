#!/usr/bin/env python3
"""Minimal A/P semantic-learning audit: logs plus frozen-head backbone swaps."""
from __future__ import annotations
import argparse, csv, hashlib, json, sys, time
from collections import defaultdict
from pathlib import Path
from typing import Any
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[1]; sys.path[:0]=[str(ROOT),str(ROOT/'VoxTell')]
from scripts import run_c2_anatomy_formulation_ranking as base
import scripts.train_voxtell_rex_full_nnunet_aug as tr

OUT=ROOT/'outputs/c2_semantic_ap_minimal_audit'
C2=ROOT/'outputs/less_fan_conditioning_10k/c2_less_encoder_conditioning/checkpoints/checkpoint_update_5000.pth'
A=ROOT/'outputs/c2_less_semantic_coadapt_v11/a_anatomy/checkpoints/checkpoint_update_5000.pth'
P=ROOT/'outputs/c2_less_semantic_coadapt_v11/p_pathology/checkpoints/checkpoint_update_5000.pth'
FIXED=ROOT/'outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv'

def hstate(state):
 h=hashlib.sha256()
 for k in sorted(state): h.update(k.encode()); h.update(state[k].detach().cpu().contiguous().numpy().tobytes())
 return h.hexdigest()
def read_jsonl(path):
 with path.open() as f:
  for line in f:
   if line.strip(): yield json.loads(line)
def weighted(rows,key,count):
 d=[r for r in rows if int(r.get(count,0))>0]
 n=sum(int(r[count]) for r in d)
 return (sum(float(r.get(key,0))*int(r[count]) for r in d)/n if n else float('nan'),n)
def trajectory(arm,kind):
 rows=list(read_jsonl(ROOT/'outputs/c2_less_semantic_coadapt_v11'/arm/'history.jsonl'))
 updates=(1000,2000,3000,3600,4000,5000); out=[]
 for u in updates:
  # one deterministic 200-microstep lookback window, existing training logs only
  part=[r for r in rows if u-50 < int(r.get('optimizer_update',0)) <= u]
  if kind=='A':
   sm,sn=weighted(part,'less_semantic_side_margin_mean','less_semantic_side_eligible_count'); sa,_=weighted(part,'less_semantic_side_accuracy','less_semantic_side_eligible_count'); la,ln=weighted(part,'less_semantic_lobe_accuracy','less_semantic_lobe_eligible_count'); lr,_=weighted(part,'less_semantic_lobe_target_rank_mean','less_semantic_lobe_eligible_count')
   out.append(dict(update=u,window_rows=len(part),side_margin=sm,side_accuracy=sa,side_n=sn,lobe_accuracy=la,lobe_mean_rank=lr,lobe_n=ln))
  else:
   pm,pn=weighted(part,'less_semantic_path_margin_mean','less_semantic_path_eligible_count'); pr,_=weighted(part,'less_semantic_path_pos_gt_neg_rate','less_semantic_path_eligible_count'); pl,_=weighted(part,'less_semantic_path_loss_raw','less_semantic_path_eligible_count'); pw,_=weighted(part,'less_semantic_loss_weighted','less_semantic_path_eligible_count')
   out.append(dict(update=u,window_rows=len(part),path_margin=pm,path_pos_gt_neg=pr,path_n=pn,path_loss_raw=pl,path_loss_weighted=pw))
 path=OUT/f'{kind}_semantic_trajectory.tsv'; path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('w',newline='') as f: w=csv.DictWriter(f,fieldnames=list(out[0]),delimiter='\t');w.writeheader();w.writerows(out)
 return out
def args():
 p=argparse.ArgumentParser();p.add_argument('--device',default='cuda');return p.parse_args()
def load_model(args_json, ckpt, device):
 cfg=json.loads(Path(args_json).read_text()); cfg['prompt_location_label_dir']=str(ROOT/'data/rex_lobe_labels_preprocessed_v1')
 m=base.make_model(cfg,device,ckpt); return m,cfg
def fixed_keys(): return base.read_fixed30(FIXED)
def collect(m,cfg,kind,device):
 rows=tr.load_manifest(Path(cfg['preprocessed_dir'])); val=tr.build_case_records(rows,'val',None); wanted=fixed_keys(); emb=tr.load_embedding_map(Path(cfg['embedding_cache']),'qwen'); tok,_=tr.load_token_feature_map(Path(cfg['token_feature_cache'])); sampler=base.construct_sampler(cfg,val,emb,tok,3701)
 result=[]
 for case in val:
  for pos,finding in enumerate(case['findings']):
   if (case['case'],int(finding['finding_idx'])) not in wanted: continue
   image,e,target,weight,meta=base.anchor_sample(sampler,case,pos)
   tf=meta['_token_features'].unsqueeze(0).to(device); tm=meta['_token_valid_mask'].unsqueeze(0).to(device)
   with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
    _=m(image.unsqueeze(0).to(device),e.unsqueeze(0).to(device),token_features=tf,token_valid_mask=tm)
    loss,st=tr.less_semantic_alignment_loss(m,target.unsqueeze(0).to(device),weight.unsqueeze(0).to(device),tf,meta['_prompt_location_lung_rois'].unsqueeze(0).to(device),meta['_prompt_location_side_rois'].unsqueeze(0).to(device),meta['_prompt_location_exact_rois'].unsqueeze(0).to(device),meta['_prompt_location_lobe5_rois'].unsqueeze(0).to(device),meta, 'anatomy' if kind=='A' else 'pathology',1.0)
   r={'case_id':case['case'],'finding_id':int(finding['finding_idx']),'prompt':str(finding['prompt']),**{k:float(v) for k,v in st.items() if k.startswith('less_semantic_')}}
   result.append(r)
 return result
def summary(rows,kind):
 if kind=='A':
  side=[r for r in rows if r['less_semantic_side_eligible_count']>0]; lobe=[r for r in rows if r['less_semantic_lobe_eligible_count']>0]
  return {'side_margin':float(np.mean([r['less_semantic_side_margin_mean'] for r in side])) if side else np.nan,'side_accuracy':float(np.mean([r['less_semantic_side_accuracy'] for r in side])) if side else np.nan,'lobe_accuracy':float(np.mean([r['less_semantic_lobe_accuracy'] for r in lobe])) if lobe else np.nan,'lobe_rank':float(np.mean([r['less_semantic_lobe_target_rank_mean'] for r in lobe])) if lobe else np.nan,'n_side':len(side),'n_lobe':len(lobe)}
 x=[r for r in rows if r['less_semantic_path_eligible_count']>0]; a=np.array([r['less_semantic_path_margin_mean'] for r in x])
 return {'mean_margin':float(a.mean()) if len(a) else np.nan,'median_margin':float(np.median(a)) if len(a) else np.nan,'iqr_margin':float(np.subtract(*np.percentile(a,[75,25]))) if len(a) else np.nan,'pos_gt_neg':float(np.mean([r['less_semantic_path_pos_gt_neg_rate'] for r in x])) if x else np.nan,'n':len(x)}
def boot(own,swap,kind,seed=99):
 rng=np.random.default_rng(seed); common=sorted(set((r['case_id'],r['finding_id']) for r in own)&set((r['case_id'],r['finding_id']) for r in swap)); d1={(r['case_id'],r['finding_id']):r for r in own};d2={(r['case_id'],r['finding_id']):r for r in swap}; cases=sorted({k[0] for k in common}); keys=['lobe_accuracy','lobe_rank'] if kind=='A' else ['mean_margin','pos_gt_neg']; vals={k:[] for k in keys}
 for _ in range(1000):
  picked=rng.choice(cases,len(cases),replace=True); ids=[k for c in picked for k in common if k[0]==c]; a=summary([d1[k] for k in ids],kind); b=summary([d2[k] for k in ids],kind)
  for k in keys: vals[k].append(a[k]-b[k])
 return [{'metric':k,'delta':float(np.mean(v)),'ci95_low':float(np.percentile(v,2.5)),'ci95_high':float(np.percentile(v,97.5))} for k,v in vals.items()]
def swap_backbone(model,c2):
 before={k:v.detach().clone() for k,v in model.state_dict().items() if k.startswith('less_semantic_alignment_heads.')}; bh=hstate(before); own=model.state_dict(); c=torch.load(c2,map_location='cpu',weights_only=False)['network_weights']; copied=[]
 for k,v in c.items():
  if not k.startswith('less_semantic_alignment_heads.') and k in own and own[k].shape==v.shape: own[k]=v;copied.append(k)
 model.load_state_dict(own,strict=True); after={k:v.detach().clone() for k,v in model.state_dict().items() if k.startswith('less_semantic_alignment_heads.')}
 if bh!=hstate(after): raise RuntimeError('semantic-head hash changed during backbone swap')
 return bh,len(copied)
def write_inventory():
 p=OUT/'checkpoint_inventory.md'; p.write_text('\n'.join(['# Checkpoint inventory','',f'- C2@5000: `{C2}`',f'- A Anatomy@5000: `{A}`',f'- P Pathology@5000: `{P}`','', 'All use common v1.1 initialization, C2 LESS word conditioning, frozen Qwen and the original whole-sentence/Prompt-Decoder path; A/P differ by their auxiliary semantic objective.'])+'\n')
def main():
 a=args(); OUT.mkdir(exist_ok=True); write_inventory(); atraj=trajectory('a_anatomy','A'); ptraj=trajectory('p_pathology','P'); dev=torch.device(a.device); began=time.time(); final={}
 for kind,ckpt,arm in [('A',A,'a_anatomy'),('P',P,'p_pathology')]:
  model,cfg=load_model(ROOT/'outputs/c2_less_semantic_coadapt_v11'/arm/'args.json',ckpt,dev); head={k:v for k,v in model.state_dict().items() if k.startswith('less_semantic_alignment_heads.')}; own=collect(model,cfg,kind,dev); hh,n=swap_backbone(model,C2); swapped=collect(model,cfg,kind,dev); sm1,sm2=summary(own,kind),summary(swapped,kind); bs=boot(own,swapped,kind)
  d=OUT/(f'{kind}_backbone_swap');d.mkdir(exist_ok=True)
  for name,rows in [('own',own),('c2_backbone_same_head',swapped)]:
   with (d/f'{name}_per_finding.tsv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=sorted({k for r in rows for k in r}),delimiter='\t');w.writeheader();w.writerows(rows)
  with (d/'metrics.tsv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=['condition',*sm1]);w.writeheader();w.writerow({'condition':f'{kind}_backbone_same_head',**sm1});w.writerow({'condition':'C2_backbone_same_head',**sm2})
  with (d/'bootstrap.tsv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(bs[0]),delimiter='\t');w.writeheader();w.writerows(bs)
  final[kind]={'own':sm1,'c2_swap':sm2,'bootstrap':bs,'head_sha256_before_after':hh,'shared_keys_overwritten':n}
  del model;torch.cuda.empty_cache()
 report=['# Minimal A/P semantic-learning audit','',f'GPU runtime seconds: {time.time()-began:.1f}','', '## Results','', '```json',json.dumps(final,indent=2),'```','', 'No full-volume segmentation validation, causal test, fresh probe, or retraining was run.']
 (OUT/'report.md').write_text('\n'.join(report)+'\n');print(json.dumps(final,indent=2))
if __name__=='__main__':main()
