#!/usr/bin/env python3
"""Gradient and loss-tradeoff diagnostics for frozen prompt adapters.

This script never constructs an optimizer and never writes a checkpoint.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F


ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "VoxTell", ROOT / "scripts"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import train_prompt_residual_adapter_s3 as adapter_lib  # noqa: E402
import train_voxtell_rex_full_nnunet_aug as train_lib  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--family", required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--base-checkpoint", type=Path, required=True)
    parser.add_argument("--base-args", type=Path, required=True)
    parser.add_argument("--category-gamma-json", type=Path, required=True)
    parser.add_argument("--adapter-updates", nargs="+", type=int, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batches", type=int, default=32)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--case-cache-size", type=int, default=8)
    parser.add_argument(
        "--preprocessed-dir",
        type=Path,
        default=ROOT / "data/rex_voxtell_preprocessed_v1",
    )
    parser.add_argument(
        "--embedding-cache",
        type=Path,
        default=ROOT
        / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/"
        "qwen_prompt_embeddings_train_val.pt",
    )
    parser.add_argument(
        "--model-dir", type=Path, default=ROOT / "VoxTell/voxtell_v1.1"
    )
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def flatten_gradients(
    gradients: tuple[torch.Tensor | None, ...], parameters: list[torch.Tensor]
) -> torch.Tensor:
    values = []
    for gradient, parameter in zip(gradients, parameters):
        values.append(
            torch.zeros_like(parameter, dtype=torch.float32).flatten()
            if gradient is None
            else gradient.detach().float().flatten()
        )
    return torch.cat(values).cpu()


def cosine(left: torch.Tensor, right: torch.Tensor) -> float | None:
    denominator = float(left.norm() * right.norm())
    return float(torch.dot(left, right) / denominator) if denominator > 0 else None


def state_vector(state: dict[str, torch.Tensor]) -> torch.Tensor:
    return torch.cat([state[key].detach().float().cpu().flatten() for key in sorted(state)])


def selected_segmentation_loss(
    logits: torch.Tensor | list[torch.Tensor],
    target: torch.Tensor,
    prompt_weights: torch.Tensor,
    meta: dict[str, Any],
    base: argparse.Namespace,
    loss_kwargs: dict[str, Any],
    mask: torch.Tensor,
    update: int,
) -> tuple[torch.Tensor, dict[str, float]]:
    weights = prompt_weights * mask.to(prompt_weights.dtype)
    if not bool((weights > 0).any()):
        zero = (logits[0] if isinstance(logits, list) else logits).sum() * 0.0
        return zero, {}
    return train_lib.segmentation_loss(
        logits,
        target,
        weights,
        prompt_categories=[meta["categories_after_shuffle"]],
        prompt_instance_types=None,
        current_step=update,
        **loss_kwargs,
    )


def weighted_stat(stats: dict[str, float], field: str) -> float:
    total = 0.0
    scale = 0
    while f"scale{scale}_weight" in stats:
        total += stats[f"scale{scale}_weight"] * stats.get(
            f"scale{scale}_{field}", 0.0
        )
        scale += 1
    return total


def prompt_masks(
    target: torch.Tensor, meta: dict[str, Any]
) -> dict[str, torch.Tensor]:
    nonempty = target.flatten(start_dim=2).sum(dim=2) > 0
    instance_types = list(map(str, meta["prompt_instance_types_after_shuffle"]))
    same_empty = torch.tensor(
        [
            value in {"same_prompt_crop_empty", "spatial_empty_negative"}
            for value in instance_types
        ],
        device=target.device,
        dtype=torch.bool,
    )[None]
    semantic = torch.tensor(
        [
            value in {"hard_semantic_negative", "cross_case_real_finding_negative"}
            for value in instance_types
        ],
        device=target.device,
        dtype=torch.bool,
    )[None]
    empty = ~nonempty
    # Any unrecognized empty prompt is classified by whether its source case
    # matches the image case, preserving the sampler's intended distinction.
    source_cases = list(map(str, meta["source_cases_after_shuffle"]))
    unclassified = empty & ~(same_empty | semantic)
    same_source = torch.tensor(
        [value == str(meta["case"]) for value in source_cases],
        device=target.device,
        dtype=torch.bool,
    )[None]
    same_empty = same_empty | (unclassified & same_source)
    semantic = semantic | (unclassified & ~same_source)
    return {
        "positive": nonempty,
        "same_case_empty_negative": empty & same_empty,
        "cross_case_semantic_negative": empty & semantic,
        "all_negative": empty,
    }


def probability_stats(
    logits: torch.Tensor | list[torch.Tensor],
    target: torch.Tensor,
    masks: dict[str, torch.Tensor],
) -> dict[str, float]:
    final = logits[0] if isinstance(logits, list) else logits
    probability = torch.sigmoid(final.float())
    positive = masks["positive"][..., None, None, None].expand_as(probability)
    negative = masks["all_negative"][..., None, None, None].expand_as(probability)
    binary = probability > 0.5
    return {
        "mean_positive_predicted_probability": float(
            probability[positive].mean().detach() if positive.any() else 0.0
        ),
        "mean_negative_predicted_probability": float(
            probability[negative].mean().detach() if negative.any() else 0.0
        ),
        "positive_prediction_voxels": float((binary & positive).sum().detach()),
        "empty_target_prediction_voxels": float((binary & negative).sum().detach()),
        "positive_target_voxels": float(
            (target.bool() & positive).sum().detach()
        ),
    }


def main() -> int:
    cli = parse_args()
    cli.output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda:0")
    random.seed(cli.seed)
    np.random.seed(cli.seed)
    torch.manual_seed(cli.seed)
    torch.cuda.manual_seed_all(cli.seed)
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(False)

    base_dict = json.loads(cli.base_args.read_text())
    base_dict["category_tversky_map"] = Path(base_dict["category_tversky_map"])
    base_dict["s3_category_gamma_json"] = cli.category_gamma_json.resolve()
    base_dict["amp_dtype"] = base_dict.get("amp_dtype", "float16")
    base = argparse.Namespace(**base_dict)
    loss_kwargs = train_lib.loss_kwargs_from_args(base)
    loss_kwargs["total_steps"] = int(
        json.loads((cli.source_root / "config.json").read_text())[
            "successful_optimizer_updates"
        ]
    )
    gamma = train_lib.load_s3_category_gamma(base)
    sampler_cli = argparse.Namespace(
        preprocessed_dir=cli.preprocessed_dir,
        embedding_cache=cli.embedding_cache,
        case_cache_size=cli.case_cache_size,
    )
    sampler = adapter_lib.make_sampler(sampler_cli, base_dict)
    model_cli = argparse.Namespace(
        model_dir=cli.model_dir,
        base_checkpoint=cli.base_checkpoint,
    )
    model = adapter_lib.instantiate_base(model_cli, base_dict, device)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for parameter in model.prompt_residual_adapter.parameters():
        parameter.requires_grad_(True)
    model.eval()
    parameters = list(model.prompt_residual_adapter.parameters())
    parameter_names = [
        name
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    ]
    if sum(parameter.numel() for parameter in parameters) != 69632:
        raise AssertionError("Adapter parameter count is not 69,632")
    zero_state = {
        key: value.detach().cpu().clone()
        for key, value in model.prompt_residual_adapter.state_dict().items()
    }
    states: dict[str, dict[str, torch.Tensor]] = {"zero": zero_state}
    state_payloads = {}
    for update in cli.adapter_updates:
        path = cli.source_root / f"checkpoints/prompt_adapter_update_{update}.pth"
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if int(payload["optimizer_update"]) != update:
            raise ValueError(f"{path}: update metadata mismatch")
        states[f"update_{update}"] = payload["adapter_state"]
        state_payloads[f"update_{update}"] = payload

    deltas = {
        state_name: state_vector(state) - state_vector(zero_state)
        for state_name, state in states.items()
        if state_name != "zero"
    }
    amp_dtype = torch.float16 if base_dict["amp_dtype"] == "float16" else torch.bfloat16
    captured_residual: list[torch.Tensor] = []
    captured_bottleneck: list[torch.Tensor] = []
    residual_hook = model.prompt_residual_adapter.register_forward_hook(
        lambda _module, _inputs, output: captured_residual.append(output)
    )
    bottleneck_hook = model.prompt_residual_adapter.activation.register_forward_hook(
        lambda _module, _inputs, output: captured_bottleneck.append(output)
    )

    gradient_rows = []
    loss_rows = []
    manifest_rows = []
    gradient_sums: dict[tuple[str, str], torch.Tensor] = {}
    gradient_counts: defaultdict[tuple[str, str], int] = defaultdict(int)
    started = time.time()

    for batch_index in range(cli.batches):
        image, embeddings, target, prompt_weights, meta = sampler.sample()
        manifest_rows.append(
            {
                "batch_index": batch_index,
                "case": meta["case"],
                "crop_bbox": meta["crop_bbox"],
                "branch_type": meta["branch_type"],
                "roles": meta["roles_after_shuffle"],
                "instance_types": meta["prompt_instance_types_after_shuffle"],
                "prompts": meta["prompt_texts_after_shuffle"],
                "source_cases": meta["source_cases_after_shuffle"],
                "categories": meta["categories_after_shuffle"],
                "target_voxels": meta["target_voxels"],
                "prompt_weights": meta["prompt_weights"],
            }
        )
        image = image.unsqueeze(0).to(device)
        embeddings = embeddings.unsqueeze(0).to(device)
        target = target.unsqueeze(0).to(device)
        prompt_weights = prompt_weights.unsqueeze(0).to(device)
        masks = prompt_masks(target, meta)
        active_count = float((prompt_weights > 0).sum())
        gate_scales = train_lib.s3_gate_scales_from_category_gamma_metadata(
            meta, gamma, device, image.dtype
        )

        for state_name, state in states.items():
            model.prompt_residual_adapter.load_state_dict(state, strict=True)
            captured_residual.clear()
            captured_bottleneck.clear()
            with torch.autocast("cuda", dtype=amp_dtype):
                logits = model(
                    image,
                    embeddings,
                    s3_attention_gate_scale=gate_scales,
                )
                raw = model
                direct, hard_background, _ = train_lib.s3_attention_localization_loss(
                    raw.last_s3_attention_maps,
                    target,
                    meta["categories_after_shuffle"],
                    meta["roles_after_shuffle"],
                    set(map(str, base.s3_attention_train_categories)),
                    base.s3_attention_margin,
                    base.s3_hard_background_fraction,
                )
                coverage, tv, _ = train_lib.s3_diffuse_coverage_tv_loss(
                    raw.last_s3_attention_maps,
                    target,
                    meta["categories_after_shuffle"],
                    meta["roles_after_shuffle"],
                    set(map(str, base.s3_diffuse_coverage_train_categories)),
                    base.s3_diffuse_attention_scale,
                    base.s3_diffuse_coverage_bottomk_frac,
                )

                components: dict[str, torch.Tensor] = {}
                component_stats: dict[str, dict[str, float]] = {}
                for component_name, mask_name in (
                    ("segmentation_positive", "positive"),
                    ("same_case_empty_negative", "same_case_empty_negative"),
                    ("cross_case_semantic_negative", "cross_case_semantic_negative"),
                ):
                    isolated, stats = selected_segmentation_loss(
                        logits,
                        target,
                        prompt_weights,
                        meta,
                        base,
                        loss_kwargs,
                        masks[mask_name],
                        int(state_name.split("_")[-1])
                        if state_name != "zero"
                        else 0,
                    )
                    fraction = float(
                        ((prompt_weights > 0) & masks[mask_name]).sum()
                    ) / active_count
                    components[component_name] = isolated * fraction
                    component_stats[component_name] = stats

                components["s3_direct"] = (
                    float(base.s3_attention_loss_weight) * direct
                )
                components["s3_hard_background"] = (
                    float(base.s3_hard_bg_loss_weight) * hard_background
                )
                components["s3_diffuse_coverage"] = (
                    float(base.s3_diffuse_coverage_loss_weight) * coverage
                )
                components["s3_diffuse_tv"] = (
                    float(base.s3_diffuse_tv_loss_weight) * tv
                )
                components["positive_total"] = (
                    components["segmentation_positive"]
                    + components["s3_direct"]
                    + components["s3_hard_background"]
                    + components["s3_diffuse_coverage"]
                    + components["s3_diffuse_tv"]
                )
                components["negative_total"] = (
                    components["same_case_empty_negative"]
                    + components["cross_case_semantic_negative"]
                )
                components["training_total"] = (
                    components["positive_total"] + components["negative_total"]
                )

                categories = list(map(str, meta["categories_after_shuffle"]))
                for category in sorted(set(categories)):
                    category_mask = torch.tensor(
                        [value == category for value in categories],
                        device=device,
                        dtype=torch.bool,
                    )[None]
                    positive_category = category_mask & masks["positive"]
                    negative_category = category_mask & masks["all_negative"]
                    if bool(positive_category.any()):
                        isolated, _ = selected_segmentation_loss(
                            logits,
                            target,
                            prompt_weights,
                            meta,
                            base,
                            loss_kwargs,
                            positive_category,
                            int(state_name.split("_")[-1])
                            if state_name != "zero"
                            else 0,
                        )
                        fraction = float(
                            ((prompt_weights > 0) & positive_category).sum()
                        ) / active_count
                        category_roles = [
                            role if cat == category else "excluded"
                            for role, cat in zip(
                                meta["roles_after_shuffle"], categories
                            )
                        ]
                        cat_direct, cat_hard, _ = (
                            train_lib.s3_attention_localization_loss(
                                raw.last_s3_attention_maps,
                                target,
                                categories,
                                category_roles,
                                set(map(str, base.s3_attention_train_categories)),
                                base.s3_attention_margin,
                                base.s3_hard_background_fraction,
                            )
                        )
                        components[f"positive_category_{category}"] = (
                            isolated * fraction
                            + float(base.s3_attention_loss_weight) * cat_direct
                            + float(base.s3_hard_bg_loss_weight) * cat_hard
                        )
                    if bool(negative_category.any()):
                        isolated, _ = selected_segmentation_loss(
                            logits,
                            target,
                            prompt_weights,
                            meta,
                            base,
                            loss_kwargs,
                            negative_category,
                            int(state_name.split("_")[-1])
                            if state_name != "zero"
                            else 0,
                        )
                        fraction = float(
                            ((prompt_weights > 0) & negative_category).sum()
                        ) / active_count
                        components[f"negative_category_{category}"] = (
                            isolated * fraction
                        )

            if len(captured_residual) != 1 or len(captured_bottleneck) != 1:
                raise RuntimeError("Adapter hooks did not capture one residual/bottleneck")
            residual_output = captured_residual[0]
            bottleneck_output = captured_bottleneck[0]
            probability = probability_stats(logits, target, masks)
            positive_stats = component_stats["segmentation_positive"]
            negative_stats = {}
            for key in (
                "same_case_empty_negative",
                "cross_case_semantic_negative",
            ):
                if component_stats[key]:
                    negative_stats = component_stats[key]
                    break
            loss_rows.append(
                {
                    "family": cli.family,
                    "batch_index": batch_index,
                    "state": state_name,
                    **{f"loss_{key}": float(value.detach()) for key, value in components.items()},
                    "positive_bce": weighted_stat(positive_stats, "bce"),
                    "positive_dice": weighted_stat(positive_stats, "dice_loss"),
                    "positive_tversky": weighted_stat(positive_stats, "tversky_loss"),
                    "empty_target_bce": (
                        float(components["negative_total"].detach())
                    ),
                    "s3_direct_raw": float(direct.detach()),
                    "s3_hard_background_raw": float(hard_background.detach()),
                    **probability,
                }
            )

            for component_name, component_loss in components.items():
                if not component_loss.requires_grad:
                    continue
                gradients = torch.autograd.grad(
                    component_loss,
                    [*parameters, residual_output, bottleneck_output],
                    retain_graph=True,
                    allow_unused=True,
                )
                adapter_gradient = flatten_gradients(
                    gradients[: len(parameters)], parameters
                )
                residual_gradient = gradients[-2]
                bottleneck_gradient = gradients[-1]
                key = (state_name, component_name)
                if key not in gradient_sums:
                    gradient_sums[key] = torch.zeros_like(adapter_gradient)
                gradient_sums[key] += adapter_gradient
                gradient_counts[key] += 1
                gradient_rows.append(
                    {
                        "family": cli.family,
                        "batch_index": batch_index,
                        "state": state_name,
                        "component": component_name,
                        "loss": float(component_loss.detach()),
                        "adapter_gradient_norm": float(adapter_gradient.norm()),
                        "residual_gradient_norm": (
                            float(residual_gradient.detach().float().norm())
                            if residual_gradient is not None
                            else 0.0
                        ),
                        "bottleneck_gradient_norm": (
                            float(bottleneck_gradient.detach().float().norm())
                            if bottleneck_gradient is not None
                            else 0.0
                        ),
                    }
                )
            del logits, components, residual_output, bottleneck_output
            torch.cuda.empty_cache()
        del image, embeddings, target, prompt_weights

    residual_hook.remove()
    bottleneck_hook.remove()
    pd.DataFrame(gradient_rows).to_csv(
        cli.output_dir / "gradient_decomposition.csv", index=False
    )
    pd.DataFrame(loss_rows).to_csv(cli.output_dir / "loss_tradeoff.csv", index=False)
    (cli.output_dir / "batch_manifest.json").write_text(
        json.dumps(
            {
                "family": cli.family,
                "seed": cli.seed,
                "batches": manifest_rows,
            },
            indent=2,
        )
        + "\n"
    )

    average = {
        key: gradient_sums[key] / gradient_counts[key] for key in gradient_sums
    }
    alignment: dict[str, Any] = {
        "family": cli.family,
        "parameter_names": parameter_names,
        "zero_state_reconstruction_seed": cli.seed,
        "states": {},
    }
    for state_name in states:
        state_result: dict[str, Any] = {
            "mean_gradient_norms": {
                component: float(value.norm())
                for (state, component), value in average.items()
                if state == state_name
            }
        }
        positive = average.get((state_name, "positive_total"))
        negative = average.get((state_name, "negative_total"))
        same_empty = average.get((state_name, "same_case_empty_negative"))
        semantic = average.get((state_name, "cross_case_semantic_negative"))
        state_result["positive_negative_cosine"] = (
            cosine(positive, negative)
            if positive is not None and negative is not None
            else None
        )
        state_result["same_empty_semantic_negative_cosine"] = (
            cosine(same_empty, semantic)
            if same_empty is not None and semantic is not None
            else None
        )
        state_result["negative_positive_norm_ratio"] = (
            float(negative.norm() / positive.norm())
            if positive is not None and negative is not None and positive.norm() > 0
            else None
        )
        target_updates = (
            [state_name] if state_name != "zero" else sorted(deltas)
        )
        state_result["descent_alignment_with_learned_displacement"] = {}
        for target in target_updates:
            displacement = deltas[target]
            state_result["descent_alignment_with_learned_displacement"][target] = {
                component: cosine(-gradient, displacement)
                for (state, component), gradient in average.items()
                if state == state_name
            }
        alignment["states"][state_name] = state_result
    (cli.output_dir / "gradient_alignment.json").write_text(
        json.dumps(alignment, indent=2) + "\n"
    )
    (cli.output_dir / "job_status.json").write_text(
        json.dumps(
            {
                "status": "completed",
                "family": cli.family,
                "elapsed_seconds": int(time.time() - started),
                "batches": cli.batches,
                "seed": cli.seed,
                "trained": False,
                "optimizer_constructed": False,
                "optimizer_steps": 0,
                "base_checkpoint": str(cli.base_checkpoint.resolve()),
                "base_checkpoint_sha256": sha256(cli.base_checkpoint),
                "adapter_updates": cli.adapter_updates,
            },
            indent=2,
        )
        + "\n"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
