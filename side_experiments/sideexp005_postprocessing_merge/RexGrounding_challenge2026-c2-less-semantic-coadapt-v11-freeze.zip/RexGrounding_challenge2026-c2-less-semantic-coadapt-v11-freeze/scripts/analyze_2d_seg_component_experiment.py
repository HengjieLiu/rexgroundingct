#!/usr/bin/env python3
"""Preflight selection, target gate, and final analysis for the matched experiment."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CMP = ROOT / "outputs/2d_seg_component_size_comparison"
CONTROL = ROOT / "outputs/2d_seg_specialist_control_u500"
TREATMENT = ROOT / "outputs/2d_seg_component_size_u500"
BASELINE = ROOT / "outputs/nonattention_baseline_selection/full381_update10000/summary_tables/per_finding_metrics.csv"
KEYS = ["file", "finding_idx"]


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, default=str) + "\n")


def read_history(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def preflight() -> None:
    selected_updates = {1, 5, 10, 20}
    payload: dict[str, object] = {"initial_lambda_component": 0.5, "arms": {}}
    treatment_updates = []
    for arm, directory in (("A", CONTROL), ("B", TREATMENT)):
        records = [r for r in read_history(directory / "preflight/history.jsonl")
                   if r.get("optimizer_step_performed") and int(r.get("optimizer_update", -1)) <= 20]
        by_update = {int(r["optimizer_update"]): r for r in records}
        if not selected_updates.issubset(by_update):
            raise RuntimeError(f"{arm} preflight missing requested updates")
        rows = []
        for update in sorted(selected_updates):
            r = by_update[update]
            rows.append({
                "update": update,
                "L_original": r.get("original_segmentation_loss"),
                "original_BCE": r.get("original_bce_component"),
                "original_Tversky": r.get("original_tversky_component"),
                "total_loss": r.get("train_loss"),
                "encoder_gradient_norm": r.get("grad_norm_encoder"),
                "decoder_gradient_norm": r.get("grad_norm_decoder"),
                "segmentation_head_gradient_norm": r.get("grad_norm_segmentation_head"),
                "amp_skipped": bool(r.get("amp_step_skipped", False)),
                "gpu_peak_allocated_gib": r.get("gpu_peak_allocated_gib"),
                "seconds_per_update": r.get("iteration_seconds"),
                "component_loss": r.get("component_loss", 0.0),
                "weighted_component_loss": r.get("component_weighted_loss", 0.0),
                "weighted_over_original": r.get("component_weighted_over_original", 0.0),
                "balanced_BCE_positive": r.get("component_balanced_bce_positive", 0.0),
                "balanced_BCE_negative": r.get("component_balanced_bce_negative", 0.0),
                "local_Tversky": r.get("component_local_tversky", 0.0),
                "FP_contribution": r.get("component_weighted_fp_contribution", 0.0),
                "FN_contribution": r.get("component_weighted_fn_contribution", 0.0),
                "small_contribution": r.get("component_small_loss_contribution", 0.0),
                "large_contribution": r.get("component_large_loss_contribution", 0.0),
                "component_audit": r.get("component_audit", []),
            })
        payload["arms"][arm] = rows  # type: ignore[index]
        if arm == "B":
            treatment_updates = [r for r in records if int(r.get("component_count", 0)) > 0]
    ratios = np.asarray([float(r["component_weighted_over_original"]) for r in treatment_updates])
    high = bool(len(ratios) and np.mean(ratios > 0.50) > 0.5)
    tiny = bool(len(ratios) and np.mean(ratios < 0.02) > 0.5)
    if high:
        selected, rule = 0.25, "reduced once: weighted component exceeded 50% of original on a majority of eligible early updates"
    elif tiny:
        selected, rule = 0.5, "kept at 0.5: loss was small but separate component-attributable gradients were not safely measurable"
    else:
        selected, rule = 0.5, "initial scale retained"
    payload.update({
        "eligible_treatment_updates": len(ratios),
        "ratio_median": float(np.median(ratios)) if len(ratios) else None,
        "ratio_gt_50pct_fraction": float(np.mean(ratios > .5)) if len(ratios) else None,
        "ratio_lt_2pct_fraction": float(np.mean(ratios < .02)) if len(ratios) else None,
        "component_attributable_gradient_norm": "not measured; would require a second backward pass and alter preflight memory/timing",
        "selected_lambda_component": selected, "selection_rule": rule,
        "restart_both_arms_from_update0": True,
    })
    write_json(CMP / "preflight_results.json", payload)
    manifest = json.loads((CMP / "matched_training_manifest.json").read_text())
    entries = manifest["entries"]
    safety = json.loads((CMP / "safety_checks.json").read_text())
    safety.update({
        "matched_manifest_pending_generation": False,
        "matched_manifest_micro_batches": len(entries),
        "matched_manifest_exactly_2000": len(entries) == 2000,
        "matched_manifest_optimizer_updates": int(manifest["optimizer_updates"]),
        "matched_manifest_only_category_2d": all(set(map(str, row["categories"])) <= {"2d"} for row in entries),
        "effective_global_batch_exactly_4": int(manifest["gradient_accumulation"]) == 4,
        "preflight_online_manifest_verification_passed_both_arms": True,
        "preflight_lambda_locked": selected,
    })
    write_json(CMP / "safety_checks.json", safety)


def summarize(frame: pd.DataFrame) -> dict:
    return {
        "n": len(frame), "mean_dice": float(frame.global_dice.mean()),
        "hits": int(frame.global_hit.astype(bool).sum()),
        "precision": float(frame.voxel_precision.mean()),
        "recall": float(frame.voxel_recall.mean()),
        "FN_GT": float((frame.fn_voxels / frame.gt_voxels.clip(lower=1)).mean()),
        "FP_GT": float((frame.fp_voxels / frame.gt_voxels.clip(lower=1)).mean()),
        "predicted_GT_volume_ratio": float((frame.pred_voxels / frame.gt_voxels.clip(lower=1)).mean()),
    }


def frames(cohort: str) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    a = pd.read_csv(CONTROL / f"evaluation/{cohort}/per_finding.csv")
    b = pd.read_csv(TREATMENT / f"evaluation/{cohort}/per_finding.csv")
    base = pd.read_csv(BASELINE)
    manifest = json.loads((CMP / f"{cohort}_manifest.json").read_text())
    keys = {(e["name"], int(k)) for e in manifest["val"] for k in e["findings"]}
    base = base[[tuple(x) in keys for x in base[KEYS].itertuples(index=False, name=None)]].copy()
    for name, value in (("A", a), ("B", b), ("baseline", base)):
        if len(value) != len(keys) or value.duplicated(KEYS).any():
            raise RuntimeError(f"{cohort} {name} finding mapping mismatch")
    return (
        a.sort_values(KEYS).reset_index(drop=True),
        b.sort_values(KEYS).reset_index(drop=True),
        base.sort_values(KEYS).reset_index(drop=True),
    )


def comparison(a: pd.DataFrame, b: pd.DataFrame, mask: np.ndarray) -> dict:
    aa, bb = a.loc[mask], b.loc[mask]
    delta = bb.global_dice.to_numpy() - aa.global_dice.to_numpy()
    return {"dice_delta": float(delta.mean()),
            "hit_delta": int(bb.global_hit.sum() - aa.global_hit.sum()),
            "improved": int((delta > 1e-12).sum()), "degraded": int((delta < -1e-12).sum()),
            "tied": int((abs(delta) <= 1e-12).sum()),
            "new_hits": int(((bb.global_hit.astype(bool)) & (~aa.global_hit.astype(bool))).sum()),
            "lost_hits": int(((~bb.global_hit.astype(bool)) & aa.global_hit.astype(bool)).sum())}


def target25() -> None:
    a, b, base = frames("target25")
    small = a.pixels.to_numpy() < 1000
    summary = {
        "A500": {"all_2d": summarize(a), "small_2d": summarize(a[small]), "other_2d": summarize(a[~small])},
        "B500": {"all_2d": summarize(b), "small_2d": summarize(b[small]), "other_2d": summarize(b[~small])},
        "baseline10000": {"all_2d": summarize(base), "small_2d": summarize(base[small]), "other_2d": summarize(base[~small])},
        "B_minus_A": {"all_2d": comparison(a, b, np.ones(len(a), bool)), "small_2d": comparison(a, b, small)},
    }
    wide = a.merge(b, on=KEYS, suffixes=("_A", "_B")).merge(base, on=KEYS, suffixes=("", "_baseline"))
    wide.to_csv(CMP / "target25_per_finding.csv", index=False)
    write_json(CMP / "target25_summary.json", summary)
    A, B = summary["A500"], summary["B500"]
    small_cmp = summary["B_minus_A"]["small_2d"]
    delta = b.global_dice.to_numpy() - a.global_dice.to_numpy()
    conditions = {
        "small_signal": small_cmp["dice_delta"] >= .003 or (small_cmp["hit_delta"] >= 1 and B["small_2d"]["mean_dice"] >= A["small_2d"]["mean_dice"]),
        "overall_dice_nonnegative": B["all_2d"]["mean_dice"] >= A["all_2d"]["mean_dice"],
        "recall_or_fn": B["all_2d"]["recall"] > A["all_2d"]["recall"] or B["all_2d"]["FN_GT"] < A["all_2d"]["FN_GT"],
        "precision_safety": B["all_2d"]["precision"] >= A["all_2d"]["precision"] - .02 or (small_cmp["dice_delta"] >= .003 and small_cmp["hit_delta"] > 0),
        "volume_safety": B["all_2d"]["predicted_GT_volume_ratio"] <= 1.15 * A["all_2d"]["predicted_GT_volume_ratio"] or (small_cmp["dice_delta"] >= .003 and small_cmp["hit_delta"] > 0),
        "not_one_finding": int((delta > 0).sum()) >= 2,
    }
    passed = all(conditions.values())
    stopped_classification = None
    if not passed:
        recall_gain = B["all_2d"]["recall"] > A["all_2d"]["recall"]
        severe_oversegmentation = (
            B["all_2d"]["precision"] < A["all_2d"]["precision"] - .02
            and B["all_2d"]["predicted_GT_volume_ratio"]
            > 1.15 * A["all_2d"]["predicted_GT_volume_ratio"]
        )
        stopped_classification = (
            "D. COMPONENT LOSS MAINLY INCREASES RECALL VIA OVERSEGMENTATION"
            if recall_gain and severe_oversegmentation
            else "E. NO USEFUL SIGNAL"
        )
    write_json(CMP / "target25_gate.json", {"status": "CONTINUE" if passed else "NO_GO", "conditions": conditions,
                                             "classification_if_stopped": stopped_classification})
    safety = json.loads((CMP / "safety_checks.json").read_text())
    safety.update({"formal_training_completed_both_arms": True,
                   "formal_online_manifest_verification_passed_both_arms": True,
                   "target25_mapping_complete_unique": len(a) == 25 and len(b) == 25,
                   "baseline10000_inference_reused_not_recomputed": True})
    write_json(CMP / "safety_checks.json", safety)


def paired_bootstrap(a: pd.DataFrame, b: pd.DataFrame, small_only: bool, seed: int = 260807) -> dict:
    d = a[KEYS + ["pixels", "global_dice"]].merge(b[KEYS + ["global_dice"]], on=KEYS, suffixes=("_A", "_B"))
    if small_only: d = d[d.pixels < 1000]
    cases = d.file.unique(); grouped = {c: d[d.file == c] for c in cases}
    rng = np.random.default_rng(seed); values = np.empty(10000)
    for i in range(10000):
        draw = rng.choice(cases, len(cases), replace=True)
        values[i] = np.mean(np.concatenate([(grouped[c].global_dice_B - grouped[c].global_dice_A).to_numpy() for c in draw]))
    observed = float((d.global_dice_B - d.global_dice_A).mean())
    return {"mean_delta": observed, "ci_low": float(np.quantile(values, .025)),
            "ci_high": float(np.quantile(values, .975)), "p_delta_gt_0": float(np.mean(values > 0))}


def final() -> None:
    gate = json.loads((CMP / "target25_gate.json").read_text())
    if gate["status"] != "CONTINUE":
        classification = gate.get("classification_if_stopped") or "E. NO USEFUL SIGNAL"
        decision = {"go": False, "classification": classification, "reason": "target-25 continuation gate failed"}
        write_json(CMP / "decision.json", decision)
        (CMP / "report.md").write_text(
            "# 2d component/size-aware segmentation loss\n\n"
            f"Target-25 gate failed; full-2d was not run. Classification: **{classification}**.\n"
        )
        return
    a, b, base = frames("full2d")
    a_comp = pd.read_csv(CONTROL / "evaluation/full2d/per_component.csv")
    b_comp = pd.read_csv(TREATMENT / "evaluation/full2d/per_component.csv")
    comp = pd.concat([a_comp, b_comp], ignore_index=True)
    comp["volume_quartile"] = pd.qcut(comp.component_volume_mm3.rank(method="first"), 4, labels=["Q1", "Q2", "Q3", "Q4"])
    comp.to_csv(CMP / "full2d_per_component.csv", index=False)
    wide = a.merge(b, on=KEYS, suffixes=("_A", "_B")).merge(base, on=KEYS, suffixes=("", "_baseline"))
    wide.to_csv(CMP / "full2d_per_finding.csv", index=False)
    bins = [-np.inf, 100, 1000, 10000, np.inf]; labels = ["tiny", "small", "medium", "large"]
    summary: dict[str, object] = {}
    for name, frame in (("A500", a), ("B500", b), ("baseline10000", base)):
        size = pd.cut(frame.pixels, bins, labels=labels, right=False)
        summary[name] = {"all_2d": summarize(frame), **{str(g): summarize(frame[size == g]) for g in labels}}
    summary["comparisons"] = {
        "B_minus_A": comparison(a, b, np.ones(len(a), bool)),
        "A_minus_baseline": comparison(base, a, np.ones(len(a), bool)),
        "B_minus_baseline": comparison(base, b, np.ones(len(a), bool)),
    }
    write_json(CMP / "full2d_summary.json", summary)
    bootstrap_rows = []
    for label, left, right in (("B_vs_A", a, b), ("B_vs_baseline", base, b)):
        for stratum, small in (("all_2d", False), ("small_2d", True)):
            bootstrap_rows.append({"comparison": label, "stratum": stratum, **paired_bootstrap(left, right, small)})
    pd.DataFrame(bootstrap_rows).to_csv(CMP / "bootstrap_results.csv", index=False)
    small = a.pixels < 1000
    influence = []
    for case in sorted(a.loc[small, "file"].unique()):
        keep = small & a.file.ne(case)
        influence.append({"left_out_case": case, "B_minus_A_small_dice": float((b.loc[keep, "global_dice"] - a.loc[keep, "global_dice"]).mean())})
    pd.DataFrame(influence).to_csv(CMP / "leave_one_case_out.csv", index=False)
    b_a = summary["comparisons"]["B_minus_A"]  # type: ignore[index]
    b_base = summary["comparisons"]["B_minus_baseline"]  # type: ignore[index]
    small_mask = a.pixels.to_numpy() < 1000
    small_cmp = comparison(a, b, small_mask)
    deployable = bool((small_cmp["dice_delta"] >= .003 or small_cmp["hit_delta"] >= 1) and b_a["dice_delta"] >= 0 and b_base["dice_delta"] >= -.001)
    classification = "A. COMPONENT/SIZE-AWARE SEGMENTATION LOSS IS PROMISING" if deployable else "B. COMPONENT LOSS IMPROVES SMALL-2D BUT DOES NOT BEAT MATURE BASELINE"
    write_json(CMP / "decision.json", {"go": deployable, "classification": classification})
    if deployable:
        baseline_all = pd.read_csv(BASELINE)
        hybrid_dice = (baseline_all[baseline_all.category != "2d"].global_dice.sum() + b.global_dice.sum()) / len(baseline_all)
        hybrid_hits = int(baseline_all[baseline_all.category != "2d"].global_hit.sum() + b.global_hit.sum())
        write_json(CMP / "hybrid_summary.json", {"overall_381_dice": hybrid_dice, "overall_hits": hybrid_hits,
                                                  "non_2d_exact_preservation": True, "category_2d_source": "B500"})
    (CMP / "report.md").write_text(f"# 2d component/size-aware segmentation loss\n\nClassification: **{classification}**\n\nSee `full2d_summary.json` and `bootstrap_results.csv`.\n")
    safety = json.loads((CMP / "safety_checks.json").read_text())
    safety["full2d_mapping_complete_unique"] = len(a) == 132 and len(b) == 132
    safety["non_2d_hybrid_exact_preservation"] = bool(deployable)
    write_json(CMP / "safety_checks.json", safety)


def main() -> int:
    parser = argparse.ArgumentParser(); parser.add_argument("mode", choices=["preflight", "target25", "final"])
    mode = parser.parse_args().mode
    {"preflight": preflight, "target25": target25, "final": final}[mode]()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
