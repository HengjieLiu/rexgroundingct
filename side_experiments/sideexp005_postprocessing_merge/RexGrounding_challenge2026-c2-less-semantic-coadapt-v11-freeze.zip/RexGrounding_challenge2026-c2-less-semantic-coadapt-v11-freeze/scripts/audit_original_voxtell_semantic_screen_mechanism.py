#!/usr/bin/env python3
"""Deterministic auxiliary-head readout and frozen-head backbone swap."""
from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from scripts import run_c2_anatomy_formulation_ranking as historical  # noqa: E402
from scripts import train_voxtell_rex_full_nnunet_aug as tr  # noqa: E402
from scripts.original_voxtell_semantic_screen_losses import (  # noqa: E402
    ANATOMY_PHRASES,
    A5ImagePositionHead,
    NativeFeatureCapture,
    PathologyRegionAlignmentHead,
    a5_contrast_objective,
    a5_dense_objective,
    anatomy_occupancy,
    global_preprocessed_coordinates,
)

EXP = ROOT / "outputs/original_voxtell_semantic_screen_1k"
TOKEN = ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt"
PHRASE = ROOT / "outputs/c2_anatomy_formulation_ranking/cache/qwen_anatomy_phrase_embeddings.pt"
LOBE = ROOT / "data/rex_lobe_labels_preprocessed_v1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", required=True, choices=["a5_dense_e4", "a5_contrast_e4", "p_d3", "p_d4"])
    parser.add_argument("--max-findings", type=int, default=24)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def state_hash(state: dict[str, torch.Tensor], prefix: str) -> str:
    digest = hashlib.sha256()
    for key in sorted(k for k in state if k.startswith(prefix)):
        digest.update(key.encode())
        digest.update(state[key].detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def build_model(config: dict[str, Any], checkpoint: Path, device: torch.device,
                backbone_checkpoint: Path | None = None) -> tuple[torch.nn.Module, NativeFeatureCapture, str]:
    params = inspect.signature(tr.instantiate_voxtell).parameters
    call = {key: config[key] for key in params if key in config}
    call.update(model_dir=Path(config["model_dir"]), device=device, deep_supervision=False)
    model = tr.instantiate_voxtell(**call)
    arm = str(config["semantic_screen_mode"])
    if arm.startswith("a5_"):
        head = A5ImagePositionHead(int(model.encoder.output_channels[4]), 128)
    else:
        stage_index = 1 if arm == "p_d3" else 0
        head = PathologyRegionAlignmentHead(int(model.encoder.output_channels[stage_index]), 2560, 128)
    model.add_module("semantic_screen_head", head.to(device))
    capture = NativeFeatureCapture(arm)
    capture.attach(model)
    arm_state = torch.load(checkpoint, map_location="cpu", weights_only=False)["network_weights"]
    head_hash = state_hash(arm_state, "semantic_screen_head.")
    if backbone_checkpoint is None:
        state = arm_state
    else:
        state = dict(arm_state)
        control = torch.load(backbone_checkpoint, map_location="cpu", weights_only=False)["network_weights"]
        copied = 0
        for key, value in control.items():
            if key.startswith("semantic_screen_head."):
                continue
            if key not in state or state[key].shape != value.shape:
                raise RuntimeError(f"B0 backbone mismatch at {key}")
            state[key] = value
            copied += 1
        if copied < 300:
            raise RuntimeError(f"Too few B0 backbone tensors copied: {copied}")
    model.load_state_dict(state, strict=True)
    if state_hash(model.state_dict(), "semantic_screen_head.") != head_hash:
        raise RuntimeError("Semantic head changed during model/backbone construction")
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model, capture, head_hash


def sampler(config: dict[str, Any], cases: list[dict], embeddings: dict, tokens: dict):
    cfg = dict(config)
    cfg["prompt_location_label_dir"] = str(LOBE)
    return historical.construct_sampler(cfg, cases, embeddings, tokens, 20260902)


def select_keys(config: dict[str, Any], cases: list[dict], embeddings: dict,
                tokens: dict, arm: str, limit: int) -> list[tuple[str, int]]:
    sample = sampler(config, cases, embeddings, tokens)
    chosen: list[tuple[str, int]] = []
    for case in sorted(cases, key=lambda item: str(item["case"])):
        for position, finding in enumerate(case["findings"]):
            prompt = str(finding["prompt"])
            parsed = tr.semantic_parse(prompt)
            if arm.startswith("a5_"):
                if len(list(parsed.get("lobes", []))) != 1:
                    continue
            elif tr.fan_semantic_pathology_phrase(prompt) is None:
                continue
            try:
                _image, _embed, _target, _weight, meta = historical.anchor_sample(sample, case, position)
            except Exception:
                continue
            if arm.startswith("a5_"):
                lobe5 = meta["_prompt_location_lobe5_rois"]
                if not bool((lobe5.flatten(1).sum(1) > 0).all()):
                    continue
            chosen.append((str(case["case"]), int(finding["finding_idx"])))
            if len(chosen) >= limit:
                return chosen
    if len(chosen) < max(8, limit // 2):
        raise RuntimeError(f"Mechanistic cohort too small: {len(chosen)}")
    return chosen


def a5_rows(model: torch.nn.Module, capture: NativeFeatureCapture, arm: str,
            sample: Any, cases: list[dict], keys: list[tuple[str, int]],
            phrases: torch.Tensor, device: torch.device, condition: str, update: int) -> list[dict]:
    lookup = {(str(c["case"]), int(f["finding_idx"])): (c, i)
              for c in cases for i, f in enumerate(c["findings"])}
    rows: list[dict] = []
    for case_id, finding_id in keys:
        case, position = lookup[(case_id, finding_id)]
        image, embed, _target, _weight, meta = historical.anchor_sample(sample, case, position)
        capture.reset()
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            _ = model(image.unsqueeze(0).to(device), embed.unsqueeze(0).to(device))
        feature = capture.encoder_feature
        if feature is None:
            raise RuntimeError("E4 capture missing")
        shape = tuple(map(int, feature.shape[-3:]))
        coords = global_preprocessed_coordinates(meta, shape, device)
        occupancy = anatomy_occupancy(meta["_prompt_location_lobe5_rois"].unsqueeze(0).to(device), shape)
        head = model.semantic_screen_head
        scores, semantic, text = head.maps(feature, coords, phrases)
        if arm == "a5_dense_e4":
            loss, _ = a5_dense_objective(head, feature, coords, phrases, occupancy, 0.15)
        else:
            loss, _ = a5_contrast_objective(head, feature, coords, phrases, occupancy, 0.07)
        weights = occupancy / occupancy.sum((-3, -2, -1), keepdim=True).clamp_min(1e-6)
        visual = F.normalize(torch.einsum("bcdhw,bqdhw->bqc", semantic.float(), weights.float()), dim=-1)
        similarity = visual[0] @ text.float().T
        probability = torch.sigmoid(scores.float() / 0.15)
        for region in range(7):
            candidates = range(2) if region < 2 else range(2, 7)
            values = similarity[region, list(candidates)]
            target = region if region < 2 else region - 2
            rank = 1 + int((values > values[target]).sum())
            wrong = torch.cat((values[:target], values[target + 1:])).max()
            truth = occupancy[0, region] > 0.5
            pred = probability[0, region] > 0.5
            dice = float((2 * (truth & pred).sum() + 1) / (truth.sum() + pred.sum() + 1))
            rows.append({
                "condition": condition, "update": update, "case_id": case_id,
                "finding_idx": finding_id, "region": ANATOMY_PHRASES[region],
                "task": "side" if region < 2 else "lobe", "correct": int(rank == 1),
                "rank": rank, "correct_vs_best_wrong_margin": float(values[target] - wrong),
                "map_dice": dice, "semantic_loss": float(loss),
            })
    return rows


def p_rows(model: torch.nn.Module, capture: NativeFeatureCapture, arm: str,
           sample: Any, cases: list[dict], keys: list[tuple[str, int]],
           device: torch.device, condition: str, update: int) -> list[dict]:
    lookup = {(str(c["case"]), int(f["finding_idx"])): (c, i)
              for c in cases for i, f in enumerate(c["findings"])}
    rows: list[dict] = []
    for case_id, finding_id in keys:
        case, position = lookup[(case_id, finding_id)]
        image, embed, target, weight, meta = historical.anchor_sample(sample, case, position)
        capture.reset()
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            _ = model(image.unsqueeze(0).to(device), embed.unsqueeze(0).to(device))
            feature = torch.stack(capture.decoder_features, dim=1)
            _weighted, stats = tr.semantic_screen_pathology_loss(
                model.semantic_screen_head, feature, target.unsqueeze(0).to(device),
                weight.unsqueeze(0).to(device), meta["_token_features"].unsqueeze(0).to(device),
                meta["_prompt_location_lung_rois"].unsqueeze(0).to(device),
                meta["_prompt_location_side_rois"].unsqueeze(0).to(device),
                meta["_prompt_location_lobe5_rois"].unsqueeze(0).to(device), meta, 1.0, arm,
            )
        if stats["semantic_screen_pathology_eligible_count"]:
            rows.append({
                "condition": condition, "update": update, "case_id": case_id,
                "finding_idx": finding_id,
                "margin": stats["semantic_screen_pathology_margin_mean"],
                "pos_gt_neg": stats["semantic_screen_pathology_pos_gt_neg"],
                "semantic_loss": stats["semantic_screen_loss_raw"],
            })
    return rows


def summarize(frame: pd.DataFrame, arm: str) -> list[dict]:
    result = []
    for (condition, update), part in frame.groupby(["condition", "update"], sort=False):
        row: dict[str, Any] = {"condition": condition, "update": int(update), "n_rows": len(part)}
        if arm.startswith("a5_"):
            for task in ("side", "lobe"):
                subset = part[part.task == task]
                row.update({
                    f"{task}_n": len(subset), f"{task}_accuracy": float(subset.correct.mean()),
                    f"{task}_mean_rank": float(subset["rank"].mean()),
                    f"{task}_margin": float(subset.correct_vs_best_wrong_margin.mean()),
                    f"{task}_map_dice": float(subset.map_dice.mean()),
                })
        else:
            row.update(mean_margin=float(part.margin.mean()), median_margin=float(part.margin.median()),
                       pos_gt_neg=float(part.pos_gt_neg.mean()), semantic_loss=float(part.semantic_loss.mean()))
        result.append(row)
    return result


def main() -> int:
    args = parse_args()
    device = torch.device(args.device)
    run = EXP / args.arm
    config = json.loads((run / "args.json").read_text())
    manifest = tr.load_manifest(Path(config["preprocessed_dir"]))
    cases = tr.build_case_records(manifest, "train", None)
    embeddings = tr.load_embedding_map(Path(config["embedding_cache"]), "qwen")
    tokens, token_meta = tr.load_token_feature_map(TOKEN)
    keys = select_keys(config, cases, embeddings, tokens, args.arm, args.max_findings)
    phrases_payload = torch.load(PHRASE, map_location="cpu", weights_only=False)
    if tuple(phrases_payload["phrases"]) != ANATOMY_PHRASES:
        raise RuntimeError("Anatomy phrase cache order mismatch")
    phrases = phrases_payload["vectors"].float().to(device)
    records: list[dict] = []
    head_hashes: dict[str, str] = {}
    conditions = [("own_backbone", 500, None), ("own_backbone", 1000, None),
                  ("b0_backbone_same_head", 1000, EXP / "b0_original/checkpoints/checkpoint_update_1000.pth")]
    for condition, update, backbone in conditions:
        checkpoint = run / f"checkpoints/checkpoint_update_{update}.pth"
        model, capture, head_hash = build_model(config, checkpoint, device, backbone)
        head_hashes[f"{condition}_{update}"] = head_hash
        sample = sampler(config, cases, embeddings, tokens)
        if args.arm.startswith("a5_"):
            records.extend(a5_rows(model, capture, args.arm, sample, cases, keys, phrases, device, condition, update))
        else:
            records.extend(p_rows(model, capture, args.arm, sample, cases, keys, device, condition, update))
        capture.remove()
        del model
        torch.cuda.empty_cache()
    frame = pd.DataFrame(records)
    out = run / ("anatomy_metrics" if args.arm.startswith("a5_") else "pathology_metrics")
    out.mkdir(parents=True, exist_ok=True)
    frame.to_csv(out / "mechanism_per_region_or_finding.csv", index=False)
    summary = summarize(frame, args.arm)
    pd.DataFrame(summary).to_csv(out / "mechanism_summary.csv", index=False)
    payload = {
        "arm": args.arm, "cohort": "deterministic anatomy/pathology-eligible training crops",
        "selected_findings": len(keys), "keys": keys, "summary": summary,
        "head_hashes": head_hashes, "token_cache_metadata": token_meta,
        "head_frozen_during_audit": True, "segmentation_inference": False,
    }
    (out / "mechanism_summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
