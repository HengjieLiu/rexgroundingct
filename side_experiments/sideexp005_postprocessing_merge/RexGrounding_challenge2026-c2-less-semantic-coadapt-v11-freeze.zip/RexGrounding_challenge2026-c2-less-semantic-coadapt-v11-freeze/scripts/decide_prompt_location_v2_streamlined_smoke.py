#!/usr/bin/env python3
"""Write the streamlined v2 smoke safety decision and resolved configuration."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from statistics import mean
from typing import Any


def optional_float(value: Any) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed == parsed and abs(parsed) != float("inf") else None


def truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def window_mean(rows: list[dict[str, str]], key: str) -> float | None:
    values = [
        value
        for value in (optional_float(row.get(key)) for row in rows)
        if value is not None
    ]
    return mean(values) if values else None


def ratio(last: float | None, first: float | None) -> float | None:
    if last is None or first is None or first <= 0:
        return None
    return last / first


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    with (args.output_dir / "smoke_metrics.csv").open(newline="", encoding="utf-8") as handle:
        smoke = next(csv.DictReader(handle))
    with (args.output_dir / "train_log.csv").open(newline="", encoding="utf-8") as handle:
        train_rows = list(csv.DictReader(handle))
    with (args.output_dir / "alignment_loss_debug.csv").open(
        newline="", encoding="utf-8"
    ) as handle:
        debug_rows = list(csv.DictReader(handle))
    config = json.loads((args.output_dir / "args.json").read_text())

    weighted_ratio = optional_float(
        smoke.get("weighted_alignment_over_segmentation_mean")
    ) or 0.0
    window = max(1, min(20, len(train_rows) // 3))
    first_train = train_rows[:window]
    last_train = train_rows[-window:]
    pred_first = window_mean(first_train, "train_pred_voxels")
    pred_last = window_mean(last_train, "train_pred_voxels")
    dice_first = window_mean(first_train, "train_positive_dice")
    dice_last = window_mean(last_train, "train_positive_dice")
    pred_ratio = ratio(pred_last, pred_first)
    dice_ratio = ratio(dice_last, dice_first)
    volume_unsafe = pred_ratio is not None and not 0.25 <= pred_ratio <= 4.0
    dice_collapse = dice_ratio is not None and dice_ratio < 0.50

    kind_stats: dict[str, dict[str, Any]] = {}
    for kind in ("lung", "side", "lobe"):
        eligible = [
            row for row in debug_rows if truthy(row.get(f"{kind}_parser_eligible"))
        ]
        gated = [row for row in eligible if truthy(row.get(f"{kind}_gated_active"))]
        hinge = [row for row in gated if truthy(row.get(f"{kind}_hinge_active"))]
        hard = [
            row
            for row in gated
            if row.get("sampling_source") == "hard_negative"
            and optional_float(row.get(f"{kind}_outside_ratio")) is not None
        ]
        hard.sort(key=lambda row: int(row.get("micro_step") or 0))
        split = max(1, len(hard) // 2)
        first_outside = window_mean(hard[:split], f"{kind}_outside_ratio")
        last_outside = window_mean(hard[split:], f"{kind}_outside_ratio")
        kind_stats[kind] = {
            "parser_eligible": len(eligible),
            "gated_active": len(gated),
            "hinge_active": len(hinge),
            "gated_fraction": len(gated) / len(eligible) if eligible else 0.0,
            "hinge_fraction": len(hinge) / len(gated) if gated else 0.0,
            "hard_negative_outside_first_half": first_outside,
            "hard_negative_outside_last_half": last_outside,
        }

    nonzero_all = all(kind_stats[kind]["hinge_active"] > 0 for kind in kind_stats)
    hard_measured = any(
        kind_stats[kind]["hard_negative_outside_first_half"] is not None
        for kind in kind_stats
    )
    reasons: list[str] = []
    if weighted_ratio < 0.002 or not nonzero_all:
        decision = "STRONGER_SMOKE_REQUIRED"
        reasons.append(
            "weighted alignment is below 0.2% of segmentation or at least one hierarchy has zero hinge activation"
        )
    elif weighted_ratio > 0.05 or volume_unsafe or dice_collapse:
        decision = "WEAKER_OR_STOP"
        reasons.append(
            "alignment exceeds 5%, predicted volume is unstable, or patch positive Dice collapsed"
        )
    else:
        decision = "SMOKE_GO"
        reasons.append(
            "alignment is materially above the inactive v1 level with nonzero hierarchical activation and no safety collapse"
        )
    if not hard_measured:
        reasons.append("hard-negative outside ratios were not measured; investigate before formal training")
        if decision == "SMOKE_GO":
            decision = "NO_GO_DIAGNOSTIC_MISSING"

    resolved = {
        "starting_checkpoint": config.get("resume"),
        "seed": config.get("seed"),
        "patch_size": config.get("patch_size"),
        "gpus": config.get("world_size"),
        "batch_size_per_gpu": 1,
        "grad_accum": config.get("grad_accum"),
        "optimizer": "SGD_Nesterov",
        "momentum": config.get("momentum"),
        "weight_decay": config.get("weight_decay"),
        "encoder_lr": config.get("encoder_lr"),
        "decoder_lr": config.get("decoder_lr"),
        "s3_attention_lr": config.get("s3_attention_lr"),
        "hard_negative_fraction": config.get(
            "prompt_location_hard_negative_fraction"
        ),
        "hard_negative_type_weights": {
            "whole_lung_outside_fp": config.get(
                "prompt_location_hard_negative_weight_lung"
            ),
            "side_outside_fp": config.get(
                "prompt_location_hard_negative_weight_side"
            ),
            "exact_lobe_outside_fp": config.get(
                "prompt_location_hard_negative_weight_lobe"
            ),
        },
        "mass_gamma": config.get("prompt_location_mass_gamma"),
        "tau": {
            "lung": config.get("prompt_location_tau_lung"),
            "side": config.get("prompt_location_tau_side"),
            "lobe": config.get("prompt_location_tau_lobe"),
        },
        "lambda": {
            "lung": config.get("prompt_location_lambda_lung"),
            "side": config.get("prompt_location_lambda_side"),
            "lobe": config.get("prompt_location_lambda_lobe"),
        },
        "gt_retention": {
            "lung": config.get("prompt_location_gt_retention_lung"),
            "side": config.get("prompt_location_gt_retention"),
            "lobe": config.get("prompt_location_gt_retention"),
        },
    }
    yaml_lines: list[str] = []
    for key, value in resolved.items():
        if isinstance(value, dict):
            yaml_lines.append(f"{key}:")
            yaml_lines.extend(f"  {subkey}: {subvalue}" for subkey, subvalue in value.items())
        else:
            yaml_lines.append(f"{key}: {value}")
    stage_name = args.output_dir.name
    resolved_text = "\n".join(yaml_lines) + "\n"
    stage_config = args.output_dir.parent / f"resolved_config_{stage_name}.yaml"
    stage_config.write_text(resolved_text)

    report = {
        "decision": decision,
        "reasons": reasons,
        "weighted_alignment_over_segmentation": weighted_ratio,
        "target_range": [0.005, 0.02],
        "inactive_threshold": 0.002,
        "too_strong_threshold": 0.05,
        "train_pred_voxels_first": pred_first,
        "train_pred_voxels_last": pred_last,
        "train_pred_volume_ratio": pred_ratio,
        "train_positive_dice_first": dice_first,
        "train_positive_dice_last": dice_last,
        "train_positive_dice_ratio": dice_ratio,
        "hierarchy": kind_stats,
    }
    markdown = [
        "# Streamlined v2 smoke decision",
        "",
        f"Decision: **{decision}**",
        "",
        f"- Weighted alignment / segmentation: {weighted_ratio:.6f} ({100 * weighted_ratio:.3f}%)",
        f"- Predicted-volume last/first ratio: {pred_ratio}",
        f"- Positive-Dice last/first ratio: {dice_ratio}",
        f"- Nonzero lung/side/lobe hinge activation: {nonzero_all}",
        f"- Hard-negative outside ratios measured: {hard_measured}",
        "",
        "Reasons:",
        "",
        *[f"- {reason}" for reason in reasons],
        "",
        "Per-hierarchy diagnostics:",
        "",
        "```json",
        json.dumps(kind_stats, indent=2),
        "```",
    ]
    markdown_text = "\n".join(markdown) + "\n"
    report_text = json.dumps(report, indent=2) + "\n"
    (args.output_dir.parent / f"smoke_decision_{stage_name}.md").write_text(
        markdown_text
    )
    (args.output_dir.parent / f"smoke_decision_{stage_name}.json").write_text(
        report_text
    )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
