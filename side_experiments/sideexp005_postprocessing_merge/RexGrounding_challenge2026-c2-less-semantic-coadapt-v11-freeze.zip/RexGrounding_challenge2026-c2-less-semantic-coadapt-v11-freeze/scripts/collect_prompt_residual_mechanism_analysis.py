#!/usr/bin/env python3
"""Collect the diagnostic-only prompt residual mechanism analysis.

This script does not instantiate a model and cannot update parameters.  It
validates and combines already-written geometry, gradient, path-ablation, and
attention artifacts.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


FAMILIES = ("weak", "allcategory", "multiscale")
MODES = ("baseline", "shared", "s3_only", "decoder_only")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text())


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def finite_or_none(value: float) -> float | None:
    return float(value) if np.isfinite(value) else None


def validate_batch_manifests(root: Path) -> dict[str, Any]:
    manifests = {
        family: read_json(root / "gradient_runs" / family / "batch_manifest.json")
        for family in FAMILIES
    }
    payloads = [manifests[family]["batches"] for family in FAMILIES]
    identical = payloads[0] == payloads[1] == payloads[2]
    if not identical:
        raise AssertionError("The three gradient batch manifests are not identical")
    batches = payloads[0]
    if len(batches) != 32:
        raise AssertionError(f"Expected 32 gradient batches, found {len(batches)}")
    categories = [category for batch in batches for category in batch["categories"]]
    instance_types = [
        instance_type
        for batch in batches
        for instance_type in batch["instance_types"]
    ]
    coverage = {
        "positive_prompts": sum(x == "positive_foreground" for x in instance_types),
        "same_case_spatial_empty_negatives": sum(
            x == "same_prompt_crop_empty" for x in instance_types
        ),
        "cross_case_semantic_negatives": sum(
            x in {"hard_semantic_negative", "cross_case_real_finding_negative"}
            for x in instance_types
        ),
        "contains_2b": "2b" in categories,
        "contains_2c": "2c" in categories,
        "contains_non_2b2c": any(x not in {"2b", "2c"} for x in categories),
        "categories": sorted(set(categories)),
    }
    if (
        coverage["positive_prompts"] == 0
        or coverage["same_case_spatial_empty_negatives"] == 0
        or coverage["cross_case_semantic_negatives"] == 0
        or not coverage["contains_2b"]
        or not coverage["contains_2c"]
        or not coverage["contains_non_2b2c"]
    ):
        raise AssertionError(f"Gradient cohort coverage is incomplete: {coverage}")
    canonical = root / "gradient_batch_manifest.json"
    write_json(
        canonical,
        {
            "seed": 2026,
            "families": list(FAMILIES),
            "identical_across_families": identical,
            "coverage": coverage,
            "batches": batches,
        },
    )
    return {
        "path": str(canonical.resolve()),
        "sha256": sha256(canonical),
        "batches": len(batches),
        "identical_across_families": identical,
        "coverage": coverage,
    }


def collect_gradients(root: Path) -> dict[str, Any]:
    gradient_frames = []
    loss_frames = []
    alignment = {}
    jobs = {}
    for family in FAMILIES:
        family_root = root / "gradient_runs" / family
        gradient_frames.append(pd.read_csv(family_root / "gradient_decomposition.csv"))
        loss_frames.append(pd.read_csv(family_root / "loss_tradeoff.csv"))
        alignment[family] = read_json(family_root / "gradient_alignment.json")
        jobs[family] = read_json(family_root / "job_status.json")
        if jobs[family]["optimizer_steps"] != 0 or jobs[family]["trained"]:
            raise AssertionError(f"Forbidden optimization was recorded for {family}")
    gradient = pd.concat(gradient_frames, ignore_index=True)
    loss = pd.concat(loss_frames, ignore_index=True)
    gradient.to_csv(root / "gradient_decomposition.csv", index=False)
    loss.to_csv(root / "loss_tradeoff.csv", index=False)
    write_json(root / "gradient_alignment.json", alignment)
    gradient_summary = (
        gradient.groupby(["family", "state", "component"], as_index=False)
        .agg(
            batches=("batch_index", "size"),
            mean_loss=("loss", "mean"),
            mean_adapter_gradient_norm=("adapter_gradient_norm", "mean"),
            q25_adapter_gradient_norm=(
                "adapter_gradient_norm",
                lambda values: values.quantile(0.25),
            ),
            median_adapter_gradient_norm=("adapter_gradient_norm", "median"),
            q75_adapter_gradient_norm=(
                "adapter_gradient_norm",
                lambda values: values.quantile(0.75),
            ),
            mean_residual_gradient_norm=("residual_gradient_norm", "mean"),
            mean_bottleneck_gradient_norm=("bottleneck_gradient_norm", "mean"),
        )
    )
    gradient_summary.to_csv(root / "gradient_summary.csv", index=False)

    delta_columns = [
        "loss_training_total",
        "loss_positive_total",
        "loss_negative_total",
        "positive_bce",
        "positive_dice",
        "positive_tversky",
        "empty_target_bce",
        "s3_direct_raw",
        "s3_hard_background_raw",
        "mean_positive_predicted_probability",
        "mean_negative_predicted_probability",
        "positive_prediction_voxels",
        "empty_target_prediction_voxels",
    ]
    tradeoff_rows = []
    for family in FAMILIES:
        family_loss = loss[loss.family == family]
        zero = family_loss[family_loss.state == "zero"].sort_values("batch_index")
        for state in sorted(set(family_loss.state) - {"zero"}):
            saved = family_loss[family_loss.state == state].sort_values("batch_index")
            if not np.array_equal(
                zero.batch_index.to_numpy(), saved.batch_index.to_numpy()
            ):
                raise AssertionError(f"Loss batch mismatch for {family}/{state}")
            record: dict[str, Any] = {"family": family, "state": state}
            for column in delta_columns:
                delta = (
                    saved[column].to_numpy(dtype=float)
                    - zero[column].to_numpy(dtype=float)
                )
                record[f"mean_delta_{column}"] = finite_or_none(np.nanmean(delta))
                record[f"median_delta_{column}"] = finite_or_none(np.nanmedian(delta))
            tradeoff_rows.append(record)
    tradeoff_summary = pd.DataFrame(tradeoff_rows)
    tradeoff_summary.to_csv(root / "loss_tradeoff_summary.csv", index=False)
    return {"jobs": jobs, "rows": len(gradient), "loss_rows": len(loss)}


def finding_key(frame: pd.DataFrame) -> pd.Series:
    return frame["file"].astype(str) + "::" + frame["finding_idx"].astype(str)


def group_mask(frame: pd.DataFrame, group: str) -> pd.Series:
    if group == "all":
        return pd.Series(True, index=frame.index)
    if group == "focal":
        return frame.category.astype(str).str.startswith("2")
    if group == "diffuse":
        return frame.category.astype(str).str.startswith("1")
    if group in {"2b", "2c", "2d"}:
        return frame.category.astype(str) == group
    if group == "tiny":
        return frame.pixels.astype(float) < 100
    if group == "non_tiny":
        return frame.pixels.astype(float) >= 100
    raise KeyError(group)


def summarize_path_pair(
    family: str, mode: str, baseline: pd.DataFrame, adapted: pd.DataFrame
) -> list[dict[str, Any]]:
    base = baseline.copy()
    other = adapted.copy()
    base["_key"] = finding_key(base)
    other["_key"] = finding_key(other)
    merged = base.merge(
        other,
        on="_key",
        suffixes=("_baseline", "_mode"),
        how="inner",
        validate="one_to_one",
    )
    if len(merged) != 49:
        raise AssertionError(f"{family}/{mode}: expected 49 paired findings, got {len(merged)}")
    records = []
    proxy = pd.DataFrame(
        {
            "category": merged["category_baseline"],
            "pixels": merged["pixels_baseline"],
        }
    )
    for group in ("all", "focal", "diffuse", "2b", "2c", "2d", "tiny", "non_tiny"):
        mask = group_mask(proxy, group).to_numpy()
        subset = merged.loc[mask]
        if subset.empty:
            continue
        baseline_dice = subset.global_dice_baseline.astype(float)
        mode_dice = subset.global_dice_mode.astype(float)
        baseline_hit = subset.global_hit_baseline.astype(str).str.lower() == "true"
        mode_hit = subset.global_hit_mode.astype(str).str.lower() == "true"
        records.append(
            {
                "family": family,
                "mode": mode,
                "group": group,
                "findings": len(subset),
                "baseline_dice_per_finding": baseline_dice.mean(),
                "dice_per_finding": mode_dice.mean(),
                "paired_dice_delta": (mode_dice - baseline_dice).mean(),
                "hit_rate": mode_hit.mean(),
                "hits": int(mode_hit.sum()),
                "new_hits": int((~baseline_hit & mode_hit).sum()),
                "lost_hits": int((baseline_hit & ~mode_hit).sum()),
                "prediction_gt_volume_ratio": subset.pred_gt_volume_ratio_mode.astype(
                    float
                ).mean(),
                "fp_voxels": subset.fp_voxels_mode.astype(float).mean(),
                "fn_voxels": subset.fn_voxels_mode.astype(float).mean(),
                "prediction_volume_change_voxels": (
                    subset.pred_voxels_mode.astype(float)
                    - subset.pred_voxels_baseline.astype(float)
                ).mean(),
            }
        )
    return records


def compare_prior_predictions(
    family: str, mode: str, current: pd.DataFrame, project_root: Path
) -> dict[str, Any]:
    prior_paths = {
        ("weak", "baseline"): project_root
        / "outputs/prompt_residual_adapter_best_s3_frozen/fast_eval/baseline/per_finding_metrics.csv",
        ("weak", "shared"): project_root
        / "outputs/prompt_residual_adapter_best_s3_frozen/fast_eval/update_100/per_finding_metrics.csv",
        ("allcategory", "baseline"): project_root
        / "outputs/prompt_residual_adapter_s3_early_checkpoint_diagnostic/full_eval/allcategory_1over1/baseline/per_finding_metrics.csv",
        ("allcategory", "shared"): project_root
        / "outputs/prompt_residual_adapter_s3_early_checkpoint_diagnostic/full_eval/allcategory_1over1/update_25/per_finding_metrics.csv",
        ("multiscale", "baseline"): project_root
        / "outputs/prompt_residual_adapter_s3_early_checkpoint_diagnostic/full_eval/multiscale_2b2c/baseline/per_finding_metrics.csv",
        ("multiscale", "shared"): project_root
        / "outputs/prompt_residual_adapter_s3_early_checkpoint_diagnostic/full_eval/multiscale_2b2c/update_25/per_finding_metrics.csv",
    }
    path = prior_paths[(family, mode)]
    prior = pd.read_csv(path)
    current = current.copy()
    prior = prior.copy()
    current["_key"] = finding_key(current)
    prior["_key"] = finding_key(prior)
    merged = current.merge(
        prior,
        on="_key",
        suffixes=("_current", "_prior"),
        validate="one_to_one",
    )
    if len(merged) != 49:
        raise AssertionError(
            f"{family}/{mode}: only {len(merged)} findings overlap prior evaluation"
        )
    maximum = {}
    for column in ("global_dice", "pred_voxels", "fp_voxels", "fn_voxels"):
        maximum[column] = float(
            np.max(
                np.abs(
                    merged[f"{column}_current"].astype(float)
                    - merged[f"{column}_prior"].astype(float)
                )
            )
        )
    return {
        "prior_path": str(path.resolve()),
        "paired_findings": len(merged),
        "maximum_absolute_difference": maximum,
        "voxel_exact_and_dice_tolerance_1e_minus_7": maximum["global_dice"] <= 1e-7
        and maximum["pred_voxels"] == 0
        and maximum["fp_voxels"] == 0
        and maximum["fn_voxels"] == 0,
        "dice_within_0p02": maximum["global_dice"] <= 0.02,
    }


def collect_path_ablation(root: Path, project_root: Path) -> dict[str, Any]:
    records = []
    jobs = {}
    equivalence = {}
    for family in FAMILIES:
        family_root = root / "path_ablation" / family
        jobs[family] = read_json(family_root / "job_status.json")
        if jobs[family]["optimizer_steps"] != 0 or jobs[family]["trained"]:
            raise AssertionError(f"Forbidden optimization was recorded for {family}")
        frames = {
            mode: pd.read_csv(family_root / mode / "per_finding_metrics.csv")
            for mode in MODES
        }
        baseline = frames["baseline"]
        for mode in MODES:
            records.extend(summarize_path_pair(family, mode, baseline, frames[mode]))
        equivalence[family] = {
            mode: compare_prior_predictions(
                family, mode, frames[mode], project_root
            )
            for mode in ("baseline", "shared")
        }
    output = pd.DataFrame(records)
    output.to_csv(root / "path_ablation" / "summary.csv", index=False)
    write_json(root / "path_ablation" / "equivalence_validation.json", equivalence)
    return {"jobs": jobs, "equivalence": equivalence, "rows": len(output)}


def collect_attention(root: Path) -> dict[str, Any]:
    frames = []
    summaries = []
    jobs = {}
    visualizations = []
    output_visual_root = root / "attention_visualizations"
    output_visual_root.mkdir(exist_ok=True)
    for family in FAMILIES:
        family_root = root / "attention_runs" / family
        status = read_json(family_root / "status.json")
        if status["optimizer_steps"] != 0 or status["trained"]:
            raise AssertionError(f"Forbidden optimization was recorded for {family}")
        jobs[family] = status
        frames.append(pd.read_csv(family_root / "attention_analysis.csv"))
        summaries.append(pd.read_csv(family_root / "attention_summary.csv"))
        for source in sorted((family_root / "visualizations").glob("*.png")):
            target = output_visual_root / f"{family}_{source.name}"
            if target.exists():
                target.unlink()
            target.symlink_to(source.resolve())
            visualizations.append(str(target.resolve()))
    combined = pd.concat(frames, ignore_index=True)
    combined["delta_top_1pct_fraction_inside_gt"] = (
        combined["adapter_top_1pct_fraction_inside_gt"]
        - combined["baseline_top_1pct_fraction_inside_gt"]
    )
    combined["delta_attention_on_baseline_fn"] = (
        combined["adapter_attention_on_baseline_fn"]
        - combined["baseline_attention_on_baseline_fn"]
    )
    combined["delta_attention_on_adapter_added_fn"] = (
        combined["adapter_attention_on_adapter_added_fn"]
        - combined["baseline_attention_on_adapter_added_fn"]
    )
    combined.to_csv(root / "attention_analysis.csv", index=False)
    summary = pd.concat(summaries, ignore_index=True)
    summary.to_csv(root / "attention_summary.csv", index=False)
    subgroup_records = []
    for (family, scale), frame in combined.groupby(["family", "scale"]):
        for group in (
            "all",
            "focal",
            "diffuse",
            "2b",
            "2c",
            "2d",
            "tiny",
            "non_tiny",
        ):
            subset = frame.loc[group_mask(frame, group)]
            if subset.empty:
                continue
            subgroup_records.append(
                {
                    "family": family,
                    "scale": scale,
                    "group": group,
                    "findings": len(subset),
                    "mean_map_correlation": subset[
                        "baseline_adapter_attention_correlation"
                    ].mean(),
                    "mean_delta_inside": subset["delta_inside_mean"].mean(),
                    "mean_delta_outside": subset["delta_outside_mean"].mean(),
                    "mean_delta_margin": subset["delta_margin"].mean(),
                    "mean_delta_entropy": subset["delta_entropy"].mean(),
                    "mean_delta_effective_volume": subset[
                        "delta_effective_volume"
                    ].mean(),
                    "mean_delta_boundary_attention": subset[
                        "delta_boundary_attention"
                    ].mean(),
                    "mean_delta_top_1pct_fraction_inside_gt": subset[
                        "delta_top_1pct_fraction_inside_gt"
                    ].mean(),
                    "mean_delta_attention_on_baseline_fn": subset[
                        "delta_attention_on_baseline_fn"
                    ].mean(),
                    "mean_delta_attention_on_adapter_added_fn": subset[
                        "delta_attention_on_adapter_added_fn"
                    ].mean(),
                }
            )
    pd.DataFrame(subgroup_records).to_csv(
        root / "attention_subgroup_summary.csv", index=False
    )
    return {
        "jobs": jobs,
        "rows": len(combined),
        "visualizations": visualizations,
    }


def summarize_bottleneck(root: Path) -> dict[str, Any]:
    raw = read_json(root / "bottleneck_unit_analysis.json")
    output = {}
    for state, units in raw.items():
        unit_rows = []
        for unit, values in units.items():
            categories = values["top_category_distribution"]
            dominant_category, dominant_count = max(
                categories.items(), key=lambda item: item[1]
            )
            focal_count = values["top_focal_diffuse_distribution"].get("focal", 0)
            tiny_count = values["top_tiny_distribution"].get("tiny", 0)
            unit_rows.append(
                {
                    "unit": int(unit),
                    "activation_mean": values["mean"],
                    "activation_variance": values["variance"],
                    "sparsity_abs_lt_1e_minus_3": values[
                        "sparsity_abs_lt_1e_minus_3"
                    ],
                    "fraction_nonpositive": values["fraction_nonpositive"],
                    "prompt_length_spearman": values["prompt_length_spearman"],
                    "dominant_top20_category": dominant_category,
                    "dominant_top20_category_count": dominant_count,
                    "top20_focal_count": focal_count,
                    "top20_tiny_count": tiny_count,
                    "top_enriched_terms": [
                        item["term"]
                        for item in values["enriched_unigrams_bigrams"][:5]
                    ],
                }
            )
        output[state] = {
            "units": unit_rows,
            "units_with_top20_category_majority": sum(
                row["dominant_top20_category_count"] >= 10 for row in unit_rows
            ),
            "units_with_abs_length_spearman_ge_0p3": sum(
                abs(row["prompt_length_spearman"]) >= 0.3 for row in unit_rows
            ),
            "maximum_abs_prompt_length_spearman": max(
                abs(row["prompt_length_spearman"]) for row in unit_rows
            ),
            "median_fraction_nonpositive": float(
                np.median([row["fraction_nonpositive"] for row in unit_rows])
            ),
            "interpretation_guardrail": (
                "Top-20 enrichment is descriptive. A bottleneck unit is not "
                "called a semantic output direction unless residual SVD also "
                "shows that its variation survives the up projection."
            ),
        }
    write_json(root / "bottleneck_unit_summary.json", output)
    return output


def build_config(root: Path, project_root: Path) -> dict[str, Any]:
    source_configs = {
        "weak": project_root / "outputs/prompt_residual_adapter_best_s3_frozen/config.json",
        "allcategory": project_root
        / "outputs/prompt_residual_adapter_s3_allcategory_1over1_frozen/config.json",
        "multiscale": project_root
        / "outputs/prompt_residual_adapter_s3_multiscale_2b2c_frozen/config.json",
    }
    selected_updates = {
        "weak": [100],
        "allcategory": [25, 100],
        "multiscale": [25, 100],
    }
    families = {}
    for family, path in source_configs.items():
        source = read_json(path)
        families[family] = {
            "source_config": str(path.resolve()),
            "base_checkpoint": source["base_checkpoint"],
            "base_checkpoint_sha256": source["base_checkpoint_sha256"],
            "model_type": source["model_type"],
            "s3_scales": source["s3_scales"],
            "attention_enabled_categories": source.get(
                "attention_enabled_categories",
                ["1a", "1b", "1c", "1d", "2a", "2b", "2c"],
            ),
            "direct_loss_categories": source.get(
                "direct_loss_categories", ["2a", "2b", "2c"]
            ),
            "selected_adapter_updates": selected_updates[family],
            "adapter_rank": source["adapter"]["rank"],
            "adapter_parameters": source["adapter"]["parameters"],
            "injection": "shared S3 and decoder query in the trained experiment",
            "all_original_parameters_frozen": True,
            "only_text_input": source["prompt_input_compliance"][
                "only_textual_model_input"
            ],
            "loss": {
                "segmentation": source["segmentation_loss"],
                "s3_direct_weight": source["s3_attention_loss_weight"],
                "s3_hard_background_weight": source["s3_hard_bg_loss_weight"],
                "s3_diffuse_coverage_weight": source[
                    "s3_diffuse_coverage_loss_weight"
                ],
                "s3_diffuse_tv_weight": source["s3_diffuse_tv_loss_weight"],
            },
            "sampler": {
                "seed": source["seed"],
                "patch_size": source["patch_size"],
                "mode": source["sampler_mode"],
                "positive_prompts": source["positive_prompts"],
                "negative_prompts": source["negative_prompts"],
            },
            "inference_mode": source["inference_mode"],
        }
    config = {
        "analysis": "Frozen Prompt Residual Adapter mechanism analysis",
        "diagnostic_only": True,
        "training_performed": False,
        "optimizer_constructed_by_diagnostic_scripts": False,
        "optimizer_steps": 0,
        "seed": 2026,
        "geometry_cohort": {"validation_findings": 381},
        "gradient_cohort": {"training_batches": 32},
        "path_and_attention_cohort": {"cases": 30, "findings": 49},
        "families": families,
    }
    write_json(root / "config.json", config)
    return config


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--root",
        type=Path,
        default=Path("outputs/prompt_residual_adapter_mechanism_analysis"),
    )
    parser.add_argument("--project-root", type=Path, default=Path("."))
    args = parser.parse_args()
    root = args.root.resolve()
    project_root = args.project_root.resolve()

    required = (
        root / "residual_geometry.csv",
        root / "residual_pca.json",
        root / "subspace_comparison.json",
        root / "bottleneck_unit_analysis.json",
        root / "artifact_hashes.json",
    )
    for path in required:
        if not path.is_file():
            raise FileNotFoundError(path)

    config = build_config(root, project_root)
    batch_manifest = validate_batch_manifests(root)
    gradient = collect_gradients(root)
    summarize_bottleneck(root)
    path = collect_path_ablation(root, project_root)
    attention = collect_attention(root)
    manifest = {
        "status": "completed",
        "diagnostic_only": True,
        "trained": False,
        "optimizer_steps": 0,
        "seed": 2026,
        "config": str((root / "config.json").resolve()),
        "artifact_hashes": read_json(root / "artifact_hashes.json"),
        "cohorts": {
            "geometry": {
                "validation_findings": 381,
                "source": "existing full-validation per-finding metrics",
            },
            "gradient": batch_manifest,
            "path_ablation": {"cases": 30, "findings": 49},
            "attention": {"cases": 30, "findings": 49},
        },
        "jobs": {
            "gradient": gradient["jobs"],
            "path_ablation": path["jobs"],
            "attention": attention["jobs"],
        },
        "equivalence_validation": path["equivalence"],
        "tests": {
            "command": "pytest -q tests/test_prompt_residual_adapter.py tests/test_prompt_residual_mechanism_diagnostics.py",
            "passed": 5,
            "failed": 0,
            "runtime_seconds": 166.91,
        },
        "outputs": sorted(
            str(path.resolve())
            for path in root.iterdir()
            if path.name not in {"gradient_runs", "attention_runs"}
        ),
        "config_summary": config,
    }
    write_json(root / "analysis_manifest.json", manifest)
    print(json.dumps({"status": "completed", "root": str(root)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
