#!/usr/bin/env python3
"""Audit/reproduce ACA P0 and create canonical matched cohort manifests."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

from scripts.evaluate_semantic_aware_lobe_constraint_part1 import semantic_parse
from voxtell.model.aca_anatomy import ANATOMY_NAMES


ROOT = Path(__file__).resolve().parents[1]
P0_TRAIN = ROOT / "outputs/aca_anatomy_p0_probe_20260730T225800Z_retry5_l40s"
P0_EVAL = ROOT / "outputs/aca_anatomy_p0_probe_eval_20260730T225800Z_retry6_l40s"
P0_FINAL = ROOT / "outputs/aca_anatomy_final_20260730T225800Z"
P0_AUDIT = ROOT / "outputs/aca_anatomy_audit_20260730T223558Z"
LOBE_VALUES = {"RUL": 3, "RML": 4, "RLL": 5, "LUL": 1, "LLL": 2}
LOBE_NAMES = tuple(LOBE_VALUES)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    return parser.parse_args()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text())


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def symmetric_ce(similarity: torch.Tensor) -> float:
    labels = torch.arange(similarity.shape[0])
    return float(
        0.5
        * (
            F.cross_entropy(similarity / 0.07, labels)
            + F.cross_entropy(similarity.T / 0.07, labels)
        )
    )


def reproduce_saved_p0() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    expected = load_json(P0_EVAL / "aggregate.json")["fixed30_probe"]
    csv_rows = load_csv(P0_EVAL / "anatomy_retrieval.csv")
    details = load_json(P0_EVAL / "fixed30_representation_details.json")
    if len(csv_rows) != 49 or len(details) != 49:
        raise AssertionError("Saved P0 evaluation is not the expected 49 findings")

    top1 = np.asarray([row["top1_correct"] == "True" for row in csv_rows])
    top2 = np.asarray([row["top2_correct"] == "True" for row in csv_rows])
    explicit = np.asarray(
        [row["explicit_lobe_correct"] == "True" for row in csv_rows if row["explicit_lobe_correct"]]
    )
    laterality = np.asarray(
        [row["laterality_correct"] == "True" for row in csv_rows if row["laterality_correct"]]
    )
    targets = np.asarray([row["target"] for row in details], dtype=np.float64)
    probabilities = np.asarray([row["probability"] for row in details], dtype=np.float64)
    correct_route = np.asarray([row["correct_route_loss"] for row in details])
    swapped_route = np.asarray([row["left_right_swapped_route_loss"] for row in details])
    gt_mass = (probabilities * (targets > 0)).sum(1)

    retrieval: dict[str, float | None] = {}
    correct_contrastive: list[float] = []
    permuted_contrastive: list[float] = []
    permutation = (1, 4, 0, 2, 3, 5)
    for anatomy_index, anatomy in enumerate(ANATOMY_NAMES):
        eligible = [
            index
            for index, row in enumerate(details)
            if float(row["target"][anatomy_index]) >= 0.05 or anatomy_index == 5
        ]
        if len(eligible) < 2:
            retrieval[anatomy] = None
            continue
        image = torch.tensor(
            [details[index]["image_embedding"][anatomy_index] for index in eligible],
            dtype=torch.float32,
        )
        permuted = torch.tensor(
            [details[index]["image_embedding"][permutation[anatomy_index]] for index in eligible],
            dtype=torch.float32,
        )
        text = torch.tensor(
            [details[index]["text_embedding"] for index in eligible], dtype=torch.float32
        )
        similarity = image @ text.T
        permuted_similarity = permuted @ text.T
        labels = torch.arange(len(eligible))
        retrieval[anatomy] = float((similarity.argmax(-1) == labels).float().mean())
        correct_contrastive.append(symmetric_ce(similarity))
        permuted_contrastive.append(symmetric_ce(permuted_similarity))

    dominant = [row["dominant_anatomy"] for row in csv_rows]
    explicit_rows = [row for row in csv_rows if row["explicit_lobe_correct"]]
    side_truth = [
        "left" if sum(row["target"][3:5]) >= sum(row["target"][0:3]) else "right"
        for row in details
    ]
    actual = {
        "fixed30_cases": len({row["case_id"] for row in csv_rows}),
        "fixed30_findings": len(csv_rows),
        "dominant_anatomy_top1_accuracy": float(top1.mean()),
        "top2_accuracy": float(top2.mean()),
        "gt_overlap_probability_mass": float(gt_mass.mean()),
        "explicit_lobe_accuracy": float(explicit.mean()),
        "explicit_lobe_count": int(explicit.size),
        "laterality_accuracy": float(laterality.mean()),
        "laterality_count": int(laterality.size),
        "correct_route_loss": float(correct_route.mean()),
        "left_right_swapped_route_loss": float(swapped_route.mean()),
        "correct_vs_swapped_margin": float((swapped_route - correct_route).mean()),
        "retrieval_accuracy_by_anatomy": retrieval,
        "mean_correct_visual_text_contrastive_loss": float(np.mean(correct_contrastive)),
        "mean_anatomy_permuted_visual_text_contrastive_loss": float(np.mean(permuted_contrastive)),
        "explicit_lobe_frequency_baseline": max(
            Counter(row["dominant_anatomy"] for row in explicit_rows).values()
        )
        / len(explicit_rows),
        "laterality_frequency_baseline": max(Counter(side_truth).values()) / len(side_truth),
        "dominant_anatomy_frequency_baseline": max(Counter(dominant).values()) / len(dominant),
        "random_anatomy_baseline": 1 / 6,
        "random_laterality_baseline": 0.5,
    }
    comparisons: dict[str, Any] = {}
    passed = True
    for key, expected_value in expected.items():
        actual_value = actual[key]
        if isinstance(expected_value, dict):
            deltas = {
                name: abs(float(actual_value[name]) - float(value))
                for name, value in expected_value.items()
                if value is not None
            }
            ok = all(delta <= 1e-6 for delta in deltas.values())
            comparisons[key] = {"max_abs_delta": max(deltas.values(), default=0), "passed": ok}
        elif isinstance(expected_value, int):
            ok = actual_value == expected_value
            comparisons[key] = {"expected": expected_value, "actual": actual_value, "passed": ok}
        else:
            delta = abs(float(actual_value) - float(expected_value))
            ok = delta <= 1e-6
            comparisons[key] = {"abs_delta": delta, "passed": ok}
        passed &= ok

    tie_count_6way = int(sum(np.count_nonzero(row == row.max()) > 1 for row in targets))
    global_dominant = int(sum(row.argmax() == 5 for row in targets))
    reproduction = {
        "schema": "aca_p0_saved_output_reproduction_v1",
        "passed": passed,
        "tolerance": 1e-6,
        "expected": expected,
        "reproduced": actual,
        "comparisons": comparisons,
        "exact_counts": {
            "top1": f"{int(top1.sum())}/49",
            "top2": f"{int(top2.sum())}/49",
            "explicit_lobe": f"{int(explicit.sum())}/{len(explicit)}",
            "laterality": f"{int(laterality.sum())}/{len(laterality)}",
        },
        "original_target_semantics": {
            "classes": list(ANATOMY_NAMES),
            "global_participated": True,
            "six_way_target_ties": tie_count_6way,
            "tie_handling": "torch.argmax deterministic first-index; ties were not excluded",
            "global_dominant_findings": global_dominant,
            "explicit_lobe_metric_source": "semantic parser returned one or more lobes; 27 findings, including multi-lobe parser outputs",
            "laterality_metric_source": "GT-overlap route target; all 49 findings; left wins exact left/right mass ties",
        },
    }
    return reproduction, details


def prompt_partial_location(prompt: str) -> bool:
    text = prompt.lower()
    terms = (
        "upper", "lower", "apical", "apex", "basal", "base", "lingula",
        "anterior", "posterior", "medial", "lateral", "subpleural", "peripheral",
    )
    return any(term in text for term in terms)


def full_volume_cohort_manifest() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    fixed = load_csv(P0_TRAIN / "fixed30_findings_source.csv")
    preprocessed_manifest = {
        row["case"]: row
        for row in (
            json.loads(line)
            for line in (ROOT / "data/rex_voxtell_preprocessed_v1/manifest.jsonl").read_text().splitlines()
        )
    }
    by_case: dict[str, list[dict[str, str]]] = {}
    for row in fixed:
        by_case.setdefault(row["case_id"], []).append(row)
    output: list[dict[str, Any]] = []
    exclusions: list[dict[str, Any]] = []
    for case_id, case_rows in sorted(by_case.items()):
        print(f"cohort target {case_id}", flush=True)
        manifest_row = preprocessed_manifest[case_id]
        with np.load(manifest_row["cache_path"]) as payload:
            case_masks = np.asarray(payload["masks"], dtype=np.uint8)
            finding_indices = [int(value) for value in payload["finding_indices"]]
        channel_by_finding = {
            finding_id: index for index, finding_id in enumerate(finding_indices)
        }
        stem = case_id.removesuffix(".nii.gz").removesuffix(".nii")
        lobe_path = (
            ROOT
            / "data/rex_lobe_labels_preprocessed_v1"
            / manifest_row["split"]
            / f"{stem}.npz"
        )
        if not lobe_path.exists():
            for row in case_rows:
                exclusions.append({**row, "reason": "missing_lobe_mask"})
            continue
        lobe = np.load(lobe_path)["lobe_label"]
        for source in case_rows:
            finding = int(source["finding_idx"])
            if finding not in channel_by_finding:
                exclusions.append({**source, "reason": "finding_missing_from_preprocessed_cache"})
                continue
            # This is the exact full preprocessed finding mask consumed by the
            # original sampler before its deterministic 192^3 crop.
            mask = case_masks[channel_by_finding[finding]] > 0
            if tuple(mask.shape) != tuple(lobe.shape):
                raise AssertionError(
                    f"Preprocessed GT/lobe shape mismatch for {case_id}: "
                    f"{mask.shape} != {lobe.shape}"
                )
            overlaps = np.asarray(
                [int(np.count_nonzero(mask & (lobe == LOBE_VALUES[name]))) for name in LOBE_NAMES],
                dtype=np.int64,
            )
            covered = int(overlaps.sum())
            if not mask.any() or covered == 0:
                exclusions.append({**source, "reason": "empty_or_no_lobe_covered_gt"})
                continue
            normalized = overlaps / covered
            maximum = overlaps.max()
            dominant_indices = np.flatnonzero(overlaps == maximum)
            lobe_tie = len(dominant_indices) > 1
            dominant = "" if lobe_tie else LOBE_NAMES[int(dominant_indices[0])]
            right = int(overlaps[:3].sum())
            left = int(overlaps[3:].sum())
            side_tie = right == left
            side = "" if side_tie else ("right" if right > left else "left")
            parsed = semantic_parse(source["prompt"])
            parser_lobes = list(parsed.get("lobes") or [])
            parser_side = str(parsed.get("side") or "")
            exact_parser_lobe = (
                parser_lobes[0]
                if parsed.get("group") == "high_conf_exact_lobe" and len(parser_lobes) == 1
                else ""
            )
            side_only = parsed.get("group") == "laterality_only" and bool(parser_side)
            partial = (
                not exact_parser_lobe
                and not side_only
                and prompt_partial_location(source["prompt"])
            )
            no_reliable = not exact_parser_lobe and not side_only and not partial
            parser_disagreement = bool(
                dominant and exact_parser_lobe and dominant != exact_parser_lobe
            )
            parser_not_identical = not dominant or exact_parser_lobe != dominant
            category = source["category"]
            focal = category in {"1e", "2d", "2h"}
            diffuse = category in {"1b", "1c", "2b", "2c", "2e", "2g"}
            output.append(
                {
                    "case_id": case_id,
                    "finding_idx": finding,
                    "category": category,
                    "prompt": source["prompt"],
                    "parser_group": parsed.get("group") or "",
                    "parser_lobes": "+".join(parser_lobes),
                    "parser_side": parser_side,
                    "parser_exact_lobe": exact_parser_lobe,
                    **{f"gt_overlap_{name}": int(overlaps[index]) for index, name in enumerate(LOBE_NAMES)},
                    **{f"gt_soft_{name}": float(normalized[index]) for index, name in enumerate(LOBE_NAMES)},
                    "gt_covered_voxels": covered,
                    "gt_dominant_lobe": dominant,
                    "gt_dominant_side": side,
                    "gt_lobe_tie": bool(lobe_tie),
                    "gt_side_tie": bool(side_tie),
                    "gt_max_dominance": float(normalized.max()),
                    "cohort_explicit_lobe": bool(exact_parser_lobe),
                    "cohort_laterality": bool(side),
                    "cohort_nontrivial_location": not bool(exact_parser_lobe),
                    "cohort_explicit_lobe_text": bool(exact_parser_lobe),
                    "cohort_side_only": bool(side_only),
                    "cohort_partial_location": bool(partial),
                    "cohort_no_reliable_text_location": bool(no_reliable),
                    "cohort_ambiguous_bilateral_diffuse": parsed.get("group")
                    in {"ambiguous_lobe", "bilateral_multifocal", "nonlocalizable"},
                    "cohort_parser_gt_agreement": bool(dominant and exact_parser_lobe == dominant),
                    "cohort_parser_gt_disagreement": parser_disagreement,
                    "cohort_image_text_disagreement_or_nonidentical": parser_not_identical,
                    "cohort_low_dominance": float(normalized.max()) < 0.70,
                    "cohort_high_dominance": float(normalized.max()) >= 0.70,
                    "cohort_focal": focal,
                    "cohort_diffuse": diffuse,
                    "inclusion_reason": "fixed30; nonempty GT; lobe cache present; lobe-covered GT > 0",
                }
            )
    return output, exclusions


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("")
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    reproduction, _ = reproduce_saved_p0()
    (args.output_root / "reproduced_p0_metrics.json").write_text(
        json.dumps(reproduction, indent=2) + "\n"
    )
    if not reproduction["passed"]:
        raise RuntimeError("Original P0 reproduction failed; confirmation study must stop")

    train_manifest = [json.loads(line) for line in (P0_TRAIN / "train_sample_manifest.jsonl").read_text().splitlines()]
    train_pairs = {
        (str(case), int(finding))
        for row in train_manifest
        for case, finding in zip(row["source_cases"], row["finding_ids"])
    }
    checkpoint_path = P0_TRAIN / "checkpoints/checkpoint_update_100.pth"
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    resolved = load_json(P0_TRAIN / "resolved_config.json")
    feature_map = load_json(P0_TRAIN / "feature_map.json")
    experiment_manifest = load_json(P0_AUDIT / "experiment_manifest.json")
    audit = {
        "schema": "aca_p0_incremental_value_phase1_audit_v1",
        "reproduction_passed": True,
        "original_training": {
            "optimizer_updates": len(train_manifest),
            "sampled_prompt_occurrences": sum(len(row["finding_ids"]) for row in train_manifest),
            "unique_source_case_finding_pairs": len(train_pairs),
            "training_split": "ReX train cases excluding every fixed30 case",
            "validation_split": "none; original P0 had no validation/model selection",
            "heldout_evaluation": "fixed30: 30 cases / 49 findings",
        },
        "checkpoint": {
            "path": str(checkpoint_path.resolve()),
            "sha256": sha256(checkpoint_path),
            "schema": checkpoint.get("schema"),
            "stage": checkpoint.get("stage"),
            "update": checkpoint.get("update"),
            "base_checkpoint": checkpoint.get("base_checkpoint"),
        },
        "resolved_config": resolved,
        "feature_map": feature_map,
        "text_representation": {
            "source": resolved["embedding_cache"],
            "description": "frozen cached Qwen finding embeddings, 2560 dimensions",
        },
        "anatomy_token_construction": (
            "adaptive-max pooled TotalSegmentator-derived five-lobe masks select frozen skips[4] voxels; "
            "masked mean normalized visual vectors + learned type embedding + centroid spatial MLP; GLOBAL token added"
        ),
        "routing_score": "dot(unit image projection, unit text projection) / learned route temperature",
        "seeds": {"model": resolved["seed"], "sampler": resolved["sampler_seed"]},
        "original_experiment_manifest": str((P0_AUDIT / "experiment_manifest.json").resolve()),
        "base_checkpoint_from_manifest": experiment_manifest["baseline"],
    }
    (args.output_root / "phase1_audit.json").write_text(json.dumps(audit, indent=2) + "\n")

    cohort, exclusions = full_volume_cohort_manifest()
    write_csv(args.output_root / "cohort_manifest.csv", cohort)
    write_csv(args.output_root / "exclusions.csv", exclusions)
    summary = {
        "eligible_cases": len({row["case_id"] for row in cohort}),
        "eligible_findings": len(cohort),
        "excluded_findings": len(exclusions),
        "cohort_counts": {
            key.removeprefix("cohort_"): sum(bool(row[key]) for row in cohort)
            for key in cohort[0]
            if key.startswith("cohort_")
        },
        "target_ties": {
            "lobe": sum(row["gt_lobe_tie"] for row in cohort),
            "side": sum(row["gt_side_tie"] for row in cohort),
        },
    }
    (args.output_root / "cohort_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"reproduction": reproduction["passed"], **summary}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
