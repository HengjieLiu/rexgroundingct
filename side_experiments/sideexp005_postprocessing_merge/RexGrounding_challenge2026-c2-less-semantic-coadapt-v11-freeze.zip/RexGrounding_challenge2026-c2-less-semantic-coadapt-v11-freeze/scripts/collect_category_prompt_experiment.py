#!/usr/bin/env python
"""Collect original-vs-category-prefix validation summaries."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd


REX_ROOT = Path(__file__).resolve().parents[1]
VOXTELL_ROOT = REX_ROOT / "VoxTell"
if str(VOXTELL_ROOT) not in sys.path:
    sys.path.insert(0, str(VOXTELL_ROOT))

from voxtell.utils.rex_category_prompts import CATEGORY_NAME_BY_CODE  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--baseline-dir",
        type=Path,
        default=REX_ROOT / "outputs/category_prompt_experiment/category_prompt_original_seed2026_fullvol_val_predictions",
    )
    parser.add_argument(
        "--category-prefix-dir",
        type=Path,
        default=REX_ROOT / "outputs/category_prompt_experiment/category_prompt_prefix_seed2026_fullvol_val_predictions",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REX_ROOT / "outputs/category_prompt_experiment/analysis",
    )
    return parser.parse_args()


def load_summary(run_dir: Path) -> dict:
    with (run_dir / "eval_rexrank_metrics_global.json").open() as handle:
        return json.load(handle)["summary"]


def load_category(run_dir: Path, prefix: str) -> pd.DataFrame:
    path = run_dir / "per_category_metrics.csv"
    frame = pd.read_csv(path)
    frame["category"] = frame["category"].astype(str)
    keep = [
        "category",
        "n",
        "mean_dice",
        "median_dice",
        "hit_rate",
        "hits",
        "misses",
        "mean_pred_gt_volume_ratio",
    ]
    for col in keep:
        if col not in frame:
            frame[col] = pd.NA
    frame["empty_prediction_rate"] = pd.NA
    frame["severe_oversegmentation_rate"] = pd.NA
    per_finding_path = run_dir / "per_finding_metrics.csv"
    if per_finding_path.exists():
        per = pd.read_csv(per_finding_path)
        per["category"] = per["category"].astype(str)
        if "pred_voxels" in per:
            empty = per.groupby("category")["pred_voxels"].apply(lambda s: float((s == 0).mean())).rename("empty_prediction_rate")
            frame = frame.drop(columns=["empty_prediction_rate"]).merge(empty, on="category", how="left")
        if "pred_gt_volume_ratio" in per:
            severe = (
                per.groupby("category")["pred_gt_volume_ratio"]
                .apply(lambda s: float((pd.to_numeric(s, errors="coerce") >= 5.0).mean()))
                .rename("severe_oversegmentation_rate")
            )
            frame = frame.drop(columns=["severe_oversegmentation_rate"]).merge(severe, on="category", how="left")
    rename = {
        col: f"{prefix}_{col}"
        for col in frame.columns
        if col not in {"category", "n"}
    }
    return frame.rename(columns=rename)


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    baseline_summary = load_summary(args.baseline_dir)
    prefix_summary = load_summary(args.category_prefix_dir)
    baseline = load_category(args.baseline_dir, "baseline")
    category = load_category(args.category_prefix_dir, "category_prefix")
    merged = baseline.merge(category, on=["category", "n"], how="outer")
    merged.insert(1, "category_name", merged["category"].map(CATEGORY_NAME_BY_CODE).fillna("unknown"))
    merged["dice_delta"] = merged["category_prefix_mean_dice"] - merged["baseline_mean_dice"]
    merged["hit_rate_delta"] = merged["category_prefix_hit_rate"] - merged["baseline_hit_rate"]
    if "category_prefix_mean_pred_gt_volume_ratio" in merged and "baseline_mean_pred_gt_volume_ratio" in merged:
        merged["pred_gt_volume_ratio_delta"] = (
            merged["category_prefix_mean_pred_gt_volume_ratio"] - merged["baseline_mean_pred_gt_volume_ratio"]
        )
    merged = merged.sort_values("category")
    csv_path = args.output_dir / "per_category_comparison.csv"
    merged.to_csv(csv_path, index=False)

    lines = [
        "# Category Prompt Experiment Summary",
        "",
        "## Overall",
        "",
        "| run | Dice/finding | Dice/case | hit rate | hits | misses |",
        "|---|---:|---:|---:|---:|---:|",
        (
            f"| original | {baseline_summary.get('mean_global_dice_per_finding', float('nan')):.6f} | "
            f"{baseline_summary.get('mean_global_dice_per_case', float('nan')):.6f} | "
            f"{baseline_summary.get('hit_rate', float('nan')):.6f} | "
            f"{baseline_summary.get('total_hits')} | {baseline_summary.get('total_misses')} |"
        ),
        (
            f"| category_prefix | {prefix_summary.get('mean_global_dice_per_finding', float('nan')):.6f} | "
            f"{prefix_summary.get('mean_global_dice_per_case', float('nan')):.6f} | "
            f"{prefix_summary.get('hit_rate', float('nan')):.6f} | "
            f"{prefix_summary.get('total_hits')} | {prefix_summary.get('total_misses')} |"
        ),
        "",
        "## Per-Category Delta",
        "",
        "| category | name | n | original mean Dice | category-prefix mean Dice | delta |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for _, row in merged.iterrows():
        lines.append(
            f"| {row['category']} | {row['category_name']} | {int(row['n'])} | "
            f"{row['baseline_mean_dice']:.6f} | {row['category_prefix_mean_dice']:.6f} | {row['dice_delta']:.6f} |"
        )
    lines.extend(
        [
            "",
            f"CSV: `{csv_path}`",
            f"Original eval: `{args.baseline_dir / 'eval_rexrank_metrics_global.json'}`",
            f"Category-prefix eval: `{args.category_prefix_dir / 'eval_rexrank_metrics_global.json'}`",
        ]
    )
    (args.output_dir / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {csv_path}")
    print(f"Wrote {args.output_dir / 'summary.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
