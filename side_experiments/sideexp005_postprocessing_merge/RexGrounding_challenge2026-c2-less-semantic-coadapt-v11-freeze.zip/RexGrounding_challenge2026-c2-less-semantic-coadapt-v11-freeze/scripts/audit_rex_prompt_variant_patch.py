#!/usr/bin/env python
"""Paired patch-validation audit for ReX prompt embedding variants."""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch


REX_ROOT = Path(__file__).resolve().parents[1]
for path in (REX_ROOT / "VoxTell", REX_ROOT / "nnUNet", REX_ROOT / "scripts"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import train_voxtell_rex_full_nnunet_aug as train  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-args", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--model-dir", type=Path, default=REX_ROOT / "VoxTell/voxtell_v1.1")
    parser.add_argument("--preprocessed-dir", type=Path, default=REX_ROOT / "data/rex_voxtell_preprocessed_v1")
    parser.add_argument(
        "--embedding-cache",
        action="append",
        nargs=2,
        metavar=("VARIANT", "PATH"),
        required=True,
        help="Repeat for original, canonical_visual, disease_only, and disease_anatomy.",
    )
    parser.add_argument("--num-val-batches", type=int, default=25)
    parser.add_argument("--max-val-cases", type=int, default=200)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def reset_rng(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def merged_training_args(path: Path) -> argparse.Namespace:
    args = train.parse_args([])
    saved = json.loads(path.read_text())
    for key, value in saved.items():
        if hasattr(args, key) and key not in {"resume", "output_dir", "world_size"}:
            setattr(args, key, value)
    # Older baseline args predate the optional experimental flags. Defaults are
    # retained for all fields absent from the saved clean baseline config.
    return args


def build_sampler(
    preprocessed_dir: Path,
    cases: list[dict],
    embedding_map: dict,
    cfg: argparse.Namespace,
) -> train.RexPreprocessedSampler:
    return train.RexPreprocessedSampler(
        preprocessed_dir=preprocessed_dir,
        cases=cases,
        embedding_map=embedding_map,
        patch_size=tuple(cfg.patch_size),
        positive_prompts=cfg.positive_prompts,
        negative_prompts=cfg.negative_prompts,
        positive_loss_weight=cfg.positive_loss_weight,
        negative_loss_weight=cfg.negative_loss_weight,
        foreground_prob=cfg.foreground_prob,
        require_positive_crop=cfg.require_positive_crop,
        min_positive_voxels=cfg.min_positive_voxels,
        max_crop_attempts=cfg.max_crop_attempts,
        max_sample_attempts=cfg.max_sample_attempts,
        cache_size=cfg.case_cache_size,
        augmenter=None,
        hard_negative_sampler=cfg.hard_negative_sampler,
        hard_negative_match=cfg.hard_negative_match,
        hard_negative_exclude_identical_prompt=cfg.hard_negative_exclude_identical_prompt,
        sampler_mode=cfg.sampler_mode,
        anchor_positive_prob=cfg.anchor_positive_prob,
        same_case_negative_prob=cfg.same_case_negative_prob,
        shuffle_prompt_order=cfg.shuffle_prompt_order,
        cross_case_negative_requires_foreground=cfg.cross_case_negative_requires_foreground,
        spatial_empty_foreground_prob=cfg.spatial_empty_foreground_prob,
        spatial_empty_around_other_prob=cfg.spatial_empty_around_other_prob,
        spatial_empty_near_anchor_prob=cfg.spatial_empty_near_anchor_prob,
        spatial_empty_far_anchor_prob=cfg.spatial_empty_far_anchor_prob,
        spatial_empty_hard_negative_prob=cfg.spatial_empty_hard_negative_prob,
        anchor_hard_negative_prob=cfg.anchor_hard_negative_prob,
        category_balance_lambda=cfg.category_balance_lambda,
        category_balance_alpha=cfg.category_balance_alpha,
        category_balance_tau=cfg.category_balance_tau,
    )


def sample_fingerprint(sampler: train.RexPreprocessedSampler, seed: int) -> dict:
    reset_rng(seed)
    image, embedding, target, weights, meta = sampler.sample()
    return {
        "case": meta["case"],
        "crop_bbox": meta["crop_bbox"],
        "roles": meta["roles_after_shuffle"],
        "source_cases": meta["source_cases_after_shuffle"],
        "finding_indices": meta["prompt_indices_after_shuffle"],
        "target_voxels": meta["target_voxels"],
        "image_sum": float(image.sum()),
        "target_sum": float(target.sum()),
        "prompt_weights": weights.tolist(),
        "embedding_sum": float(embedding.sum()),
    }


def main() -> int:
    args = parse_args()
    if not torch.cuda.is_available() and args.device.startswith("cuda"):
        raise RuntimeError("CUDA requested but unavailable")
    device = torch.device(args.device)
    cfg = merged_training_args(args.baseline_args)
    cfg.max_val_cases = args.max_val_cases
    rows = train.load_manifest(args.preprocessed_dir)
    cases = train.build_case_records(rows, cfg.val_split, args.max_val_cases)
    embedding_paths = {name: Path(path) for name, path in args.embedding_cache}
    required = {"original", "canonical_visual", "disease_only", "disease_anatomy"}
    missing = required - embedding_paths.keys()
    if missing:
        raise ValueError(f"Missing embedding cache variants: {sorted(missing)}")

    maps = {name: train.load_embedding_map(path) for name, path in embedding_paths.items()}
    samplers = {name: build_sampler(args.preprocessed_dir, cases, mapping, cfg) for name, mapping in maps.items()}
    fingerprints = {name: sample_fingerprint(sampler, args.seed) for name, sampler in samplers.items()}
    spatial_keys = ("case", "crop_bbox", "roles", "source_cases", "finding_indices", "target_voxels", "image_sum", "target_sum")
    original_fingerprint = fingerprints["original"]
    paired_samples_identical = all(
        all(fingerprint[key] == original_fingerprint[key] for key in spatial_keys)
        for fingerprint in fingerprints.values()
    )
    if not paired_samples_identical:
        raise RuntimeError("Prompt variants did not reproduce identical sampled patches")

    network = train.instantiate_voxtell(args.model_dir, device, deep_supervision=True)
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    incompatible = network.load_state_dict(checkpoint["network_weights"], strict=True)
    if incompatible.missing_keys or incompatible.unexpected_keys:
        raise RuntimeError(
            f"Checkpoint mismatch: missing={incompatible.missing_keys}, unexpected={incompatible.unexpected_keys}"
        )
    loss_kwargs = train.loss_kwargs_from_args(cfg)
    results = {}
    for name, sampler in samplers.items():
        reset_rng(args.seed)
        results[name] = train.run_validation(
            network,
            sampler,
            device,
            args.num_val_batches,
            cfg.amp,
            loss_kwargs,
            current_step=int(checkpoint.get("step", 0)),
        )
        print(name, json.dumps(results[name], sort_keys=True))

    output = {
        "checkpoint": str(args.checkpoint.resolve()),
        "baseline_args": str(args.baseline_args.resolve()),
        "seed": args.seed,
        "num_val_batches": args.num_val_batches,
        "max_val_cases": args.max_val_cases,
        "paired_samples_identical": paired_samples_identical,
        "sample_fingerprints": fingerprints,
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(f"Saved: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
