#!/usr/bin/env python3
"""Create the final full-validation comparison for selected L1/L2 checkpoints."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SUBSET_DIR = ROOT / "outputs/l1_l2_loss_subset30"
FULL_DIR = ROOT / "outputs/l1_l2_loss_full200"
REFERENCE_DIR = ROOT / "outputs/category_adaptive_tversky_full200"


def load(branch: str, step: int, root: Path) -> pd.DataFrame:
    path = root / branch / f"step{step}" / "per_finding_metrics.csv"
    frame = pd.read_csv(path)
    frame["model"] = branch
    frame["step"] = step
    return frame


def summary(frame: pd.DataFrame, model: str, loss: str, alpha_beta: str) -> dict:
    return {
        "model": model,
        "loss": loss,
        "fp_heavy_alpha_beta": alpha_beta,
        "step": int(frame.step.iloc[0]),
        "dice_per_finding": frame.global_dice.mean(),
        "dice_per_case": frame.groupby("file").global_dice.mean().mean(),
        "hit_rate": frame.global_hit.mean(),
        "hits": int(frame.global_hit.sum()),
        "findings": len(frame),
        "precision": frame.voxel_precision.mean(),
        "recall": frame.voxel_recall.mean(),
        "total_fp_mm3": frame.fp_mm3.sum(),
        "total_fn_mm3": frame.fn_mm3.sum(),
    }


def main() -> int:
    decision = json.loads((SUBSET_DIR / "decision.json").read_text())
    frames = {
        "control": load("control", 600, REFERENCE_DIR),
        "adaptive": load("adaptive", 600, REFERENCE_DIR),
    }
    rows = [
        summary(frames["control"], "Control", "WBCE + Dice", "-"),
        summary(frames["adaptive"], "Adaptive current", "WBCE + Tversky", "0.7/0.3"),
    ]
    specs = {
        "l1": ("L1", "WBCE + Tversky", "0.6/0.4"),
        "l2": ("L2", "WBCE + 0.5 Dice + 0.5 Tversky", "0.7/0.3"),
    }
    for item in decision.get("selected", []):
        branch, step = item["branch"], int(item["step"])
        frame = load(branch, step, FULL_DIR)
        frames[branch] = frame
        rows.append(summary(frame, *specs[branch]))

    table = pd.DataFrame(rows)
    control_fp = float(table.loc[table.model == "Control", "total_fp_mm3"].iloc[0])
    table["fp_change_vs_control"] = table.total_fp_mm3 / control_fp - 1.0
    FULL_DIR.mkdir(parents=True, exist_ok=True)
    table.to_csv(FULL_DIR / "final_comparison.csv", index=False)

    adaptive = table[table.model == "Adaptive current"].iloc[0]
    conclusions = []
    for model in ("L1", "L2"):
        match = table[table.model == model]
        if match.empty:
            conclusions.append(f"- {model}: not selected by the fixed 30-case gate.")
            continue
        row = match.iloc[0]
        conclusions.append(
            f"- {model}: Dice/finding {row.dice_per_finding:.6f}; recall {row.recall:.4f}; "
            f"FP change vs control {row.fp_change_vs_control:+.2%}; "
            f"Dice vs current adaptive {row.dice_per_finding - adaptive.dice_per_finding:+.6f}."
        )
    report = [
        "# L1/L2 full-volume validation",
        "",
        "```text",
        table.round(6).to_string(index=False),
        "```",
        "",
        "## Interpretation",
        "",
        *conclusions,
        "",
        "The best branch for later architecture combination is the row with the highest full-volume Dice; recall and FP change break near-ties.",
        "",
    ]
    (FULL_DIR / "report.md").write_text("\n".join(report))
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
