#!/usr/bin/env python3
"""Summarize C2 LESS @9000 fixed30 token-causal predictions and paired CIs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


CONDITIONS = {
    "correct": "Correct",
    "shuffle": "TokenShuffle",
    "neutral": "TokenNeutral",
    "cross_category_shuffle": "CrossCategoryShuffle",
}


def locate_metrics(root: Path, label: str) -> Path:
    matches = sorted((root / label / "full_volume").glob("update_*/summary_tables/per_finding_metrics.csv"))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected one per-finding CSV for {label}, found {matches}")
    return matches[0]


def dice_summary(frame: pd.DataFrame) -> dict[str, float | int]:
    pred = frame["pred_voxels"].astype(float)
    return {
        "dice": float(frame["global_dice"].mean()),
        "hit": int(frame["global_hit"].astype(bool).sum()),
        "n": int(len(frame)),
        "mean_pred_volume": float(pred.mean()),
        "median_pred_volume": float(pred.median()),
        "empty": int((pred == 0).sum()),
    }


def paired(correct: pd.DataFrame, other: pd.DataFrame, rng: np.random.Generator) -> dict[str, object]:
    keys = ["run", "file", "finding_idx"]
    left = correct[keys + ["global_dice", "global_hit"]].rename(
        columns={"global_dice": "dice_correct", "global_hit": "hit_correct"}
    )
    right = other[keys + ["global_dice", "global_hit"]].rename(
        columns={"global_dice": "dice_other", "global_hit": "hit_other"}
    )
    merged = left.merge(right, on=keys, validate="one_to_one")
    delta = merged.dice_correct - merged.dice_other
    case_means = merged.assign(delta=delta).groupby("file", sort=True).delta.mean().to_numpy()
    draws = np.empty(5000, dtype=np.float64)
    for index in range(len(draws)):
        draws[index] = rng.choice(case_means, size=len(case_means), replace=True).mean()
    tolerance = 1e-12
    return {
        "mean_dice_delta_correct_minus_condition": float(delta.mean()),
        "median_dice_delta_correct_minus_condition": float(delta.median()),
        "improved": int((delta > tolerance).sum()),
        "worsened": int((delta < -tolerance).sum()),
        "tied": int((delta.abs() <= tolerance).sum()),
        "hit_delta_correct_minus_condition": int(
            merged.hit_correct.astype(bool).sum() - merged.hit_other.astype(bool).sum()
        ),
        "case_cluster_bootstrap_95_ci": [float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    tables = root / "paired_stats"
    tables.mkdir(parents=True, exist_ok=True)
    frames = {label: pd.read_csv(locate_metrics(root, label)) for label in CONDITIONS}
    summary = {label: dice_summary(frame) for label, frame in frames.items()}
    rng = np.random.default_rng(20260822)
    pair_stats = {
        label: paired(frames["correct"], frames[label], rng)
        for label in CONDITIONS if label != "correct"
    }
    rows = []
    for label, display in CONDITIONS.items():
        row = {"condition": display, **summary[label]}
        if label != "correct":
            row.update(pair_stats[label])
        rows.append(row)
    pd.DataFrame(rows).to_csv(tables / "causal_summary.csv", index=False)
    for label, frame in frames.items():
        frame.to_csv(tables / f"per_finding_{label}.csv", index=False)
    (tables / "paired_stats.json").write_text(json.dumps(pair_stats, indent=2) + "\n")
    (tables / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"summary": summary, "paired": pair_stats}, indent=2))


if __name__ == "__main__":
    main()
