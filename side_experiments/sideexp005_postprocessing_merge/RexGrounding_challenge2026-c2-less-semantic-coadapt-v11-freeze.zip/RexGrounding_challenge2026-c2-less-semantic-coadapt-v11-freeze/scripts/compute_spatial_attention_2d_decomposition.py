#!/usr/bin/env python3
"""Compute category-2d voxel decomposition for spatial-attention ablations."""

from __future__ import annotations

import argparse
import json
from multiprocessing import Pool
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd


REX_ROOT = Path(__file__).resolve().parents[1]


def load_2d_cases(dataset_json: Path) -> dict[str, list[int]]:
    with dataset_json.open() as f:
        data = json.load(f)
    cases: dict[str, list[int]] = {}
    for entry in data["val"]:
        indices = [
            int(k) for k, category in (entry.get("categories") or {}).items()
            if str(category) == "2d"
        ]
        if indices:
            cases[entry["name"]] = indices
    return cases


def process_case(args):
    name, indices, gt_dir, runs = args
    gt_img = nib.load(str(gt_dir / name))
    gt = np.asanyarray(gt_img.dataobj) > 0
    voxel_volume_mm3 = float(np.prod(gt_img.header.get_zooms()[:3]))
    rows = []
    for label, pred_dir in runs:
        pred = np.asanyarray(nib.load(str(pred_dir / name)).dataobj) > 0
        for idx in indices:
            gt_mask = gt[idx]
            pred_mask = pred[idx]
            tp = int(np.logical_and(pred_mask, gt_mask).sum())
            fp = int(np.logical_and(pred_mask, ~gt_mask).sum())
            fn = int(np.logical_and(~pred_mask, gt_mask).sum())
            pred_voxels = int(pred_mask.sum())
            gt_voxels = int(gt_mask.sum())
            denom = 2 * tp + fp + fn
            dice = (2 * tp / denom) if denom else 1.0
            rows.append(
                {
                    "run": label,
                    "file": name,
                    "finding_idx": idx,
                    "dice": dice,
                    "hit": dice >= 0.1,
                    "tp_voxels": tp,
                    "fp_voxels": fp,
                    "fn_voxels": fn,
                    "pred_voxels": pred_voxels,
                    "gt_voxels": gt_voxels,
                    "fp_mm3": fp * voxel_volume_mm3,
                    "fn_mm3": fn * voxel_volume_mm3,
                    "voxel_precision": tp / (tp + fp) if (tp + fp) else 1.0,
                    "voxel_recall": tp / (tp + fn) if (tp + fn) else 1.0,
                    "pred_gt_volume_ratio": pred_voxels / gt_voxels if gt_voxels else np.nan,
                }
            )
    return rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-json", type=Path, default=REX_ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--gt-dir", type=Path, default=REX_ROOT / "data/segmentations")
    parser.add_argument("--out-csv", type=Path, required=True)
    parser.add_argument("--num-workers", type=int, default=12)
    parser.add_argument("--run", action="append", required=True, help="label:path/to/pred_dir")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    runs = []
    for spec in args.run:
        label, path = spec.split(":", 1)
        runs.append((label, Path(path)))
    cases = load_2d_cases(args.dataset_json)
    tasks = [(name, indices, args.gt_dir, runs) for name, indices in cases.items()]
    rows = []
    with Pool(processes=args.num_workers) as pool:
        for result in pool.imap_unordered(process_case, tasks):
            rows.extend(result)
    df = pd.DataFrame(rows)
    summary = df.groupby("run").agg(
        n=("dice", "size"),
        mean_dice=("dice", "mean"),
        hit_rate=("hit", "mean"),
        hits=("hit", "sum"),
        mean_voxel_precision=("voxel_precision", "mean"),
        mean_voxel_recall=("voxel_recall", "mean"),
        mean_fp_voxels=("fp_voxels", "mean"),
        mean_fn_voxels=("fn_voxels", "mean"),
        mean_fp_mm3=("fp_mm3", "mean"),
        mean_fn_mm3=("fn_mm3", "mean"),
        mean_pred_gt_volume_ratio=("pred_gt_volume_ratio", "mean"),
        dice_on_hit_cases_only=("dice", lambda x: x[df.loc[x.index, "hit"]].mean()),
    ).reset_index()
    summary["misses"] = summary["n"] - summary["hits"]
    args.out_csv.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(args.out_csv, index=False)
    df.to_csv(args.out_csv.with_name(args.out_csv.stem + "_per_finding.csv"), index=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
