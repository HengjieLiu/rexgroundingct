#!/usr/bin/env python
"""Paired full-volume original/canonical prompt audit with threshold controls."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import average_precision_score, roc_auc_score
from tqdm import tqdm


REX_ROOT = Path(__file__).resolve().parents[1]
for path in (REX_ROOT / "VoxTell", REX_ROOT / "nnUNet", REX_ROOT / "scripts"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from audit_rex_prompt_variant_inference import (  # noqa: E402
    binary_dice,
    probability_correlation,
    prompt_metrics,
)
from run_voxtell_rex_inference import (  # noqa: E402
    load_entries,
    load_image,
    load_reference_mask_for_window_diagnostic,
    select_entries,
    sorted_finding_keys,
)
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402
from voxtell.utils.prompt_embedding_cache import load_embedding_cache  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rex-json", type=Path, default=REX_ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--split", default="val")
    parser.add_argument("--image-dir", type=Path, default=REX_ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--mask-dir", type=Path, default=REX_ROOT / "data/segmentations")
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--original-cache", type=Path)
    parser.add_argument("--canonical-cache", type=Path)
    parser.add_argument(
        "--variant-cache",
        action="append",
        default=[],
        metavar="NAME=PATH",
        help="Additional/general cache specification. Requires an 'original=PATH' entry when used.",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--thresholds", nargs="+", type=float, default=[0.4, 0.45, 0.5])
    parser.add_argument("--num-shards", type=int, default=None)
    parser.add_argument("--shard-id", type=int, default=None)
    parser.add_argument(
        "--max-cases",
        type=int,
        default=None,
        help="Deterministically sample this many cases before distributing them across shards.",
    )
    parser.add_argument(
        "--case-list-json",
        type=Path,
        help="JSON manifest containing a 'cases' list. Takes precedence over --max-cases.",
    )
    parser.add_argument("--max-ranking-voxels-per-class", type=int, default=50_000)
    parser.add_argument("--ranking-repeat-seeds", type=int, default=1)
    parser.add_argument("--save-sampled-logits", action="store_true")
    parser.add_argument("--sampled-logit-dtype", choices=["float16", "float32"], default="float16")
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--text-encoding-model", default="Qwen/Qwen3-Embedding-4B")
    parser.add_argument(
        "--s3-enabled-categories",
        nargs="*",
        default=None,
        help=(
            "Optional S3 inference gate policy. When set, only prompts in these "
            "categories receive the S3 residual gate, matching category-gated training."
        ),
    )
    return parser.parse_args()


def stable_seed(case: str, finding_idx: int, seed: int) -> int:
    digest = hashlib.sha256(f"{case}:{finding_idx}:{seed}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "little")


def stratified_indices(target: np.ndarray, limit: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    """Return reproducible positive/background indices for ranking diagnostics."""
    flat = target.reshape(-1)
    positive = np.flatnonzero(flat)
    rng = np.random.default_rng(seed)
    if positive.size > limit:
        positive = rng.choice(positive, size=limit, replace=False)

    negative_parts = []
    remaining = limit
    while remaining > 0:
        candidates = rng.integers(0, flat.size, size=max(remaining * 2, 1024))
        candidates = candidates[~flat[candidates]]
        if candidates.size == 0:
            break
        take = candidates[:remaining]
        negative_parts.append(take)
        remaining -= take.size
    negative = np.concatenate(negative_parts) if negative_parts else np.empty(0, dtype=np.int64)
    return positive.astype(np.int64, copy=False), negative.astype(np.int64, copy=False)


def ranking_metrics(probability: np.ndarray, positive: np.ndarray, negative: np.ndarray) -> dict[str, float]:
    flat = probability.reshape(-1)
    indices = np.concatenate((positive, negative))
    labels = np.concatenate((np.ones(positive.size, dtype=np.uint8), np.zeros(negative.size, dtype=np.uint8)))
    if positive.size == 0 or negative.size == 0:
        return {"voxel_average_precision": float("nan"), "voxel_auroc": float("nan")}
    scores = flat[indices].astype(np.float64, copy=False)
    return {
        "voxel_average_precision": float(average_precision_score(labels, scores)),
        "voxel_auroc": float(roc_auc_score(labels, scores)),
    }


def summarize_logits(logits: np.ndarray, probability: np.ndarray, target: np.ndarray) -> dict[str, float]:
    gt = target.astype(bool, copy=False)
    outside = ~gt
    return {
        "mean_probability": float(np.mean(probability)),
        "mean_gt_interior_probability": float(np.mean(probability[gt])) if gt.any() else float("nan"),
        "mean_gt_exterior_probability": float(np.mean(probability[outside])) if outside.any() else float("nan"),
        "mean_logit": float(np.mean(logits)),
        "mean_gt_interior_logit": float(np.mean(logits[gt])) if gt.any() else float("nan"),
        "mean_gt_exterior_logit": float(np.mean(logits[outside])) if outside.any() else float("nan"),
    }


def append_sampled_values(
    *,
    case_code: int,
    case: str,
    finding_idx: int,
    positive: np.ndarray,
    negative: np.ndarray,
    target: np.ndarray,
    original_logits: np.ndarray,
    canonical_logits: np.ndarray,
    original_probability: np.ndarray,
    canonical_probability: np.ndarray,
    buffers: dict[str, list],
    manifest_rows: list[dict],
) -> None:
    indices = np.concatenate((positive, negative)).astype(np.int64, copy=False)
    if indices.size == 0:
        return
    start = sum(len(values) for values in buffers["flat_index"])
    labels = target.reshape(-1)[indices].astype(np.uint8, copy=False)
    stratum = np.concatenate((
        np.ones(positive.size, dtype=np.uint8),
        np.zeros(negative.size, dtype=np.uint8),
    ))
    buffers["case_code"].append(np.full(indices.size, case_code, dtype=np.int32))
    buffers["finding_idx"].append(np.full(indices.size, finding_idx, dtype=np.int16))
    buffers["flat_index"].append(indices)
    buffers["stratum"].append(stratum)
    buffers["gt_label"].append(labels)
    buffers["original_logit"].append(original_logits.reshape(-1)[indices])
    buffers["canonical_logit"].append(canonical_logits.reshape(-1)[indices])
    buffers["original_probability"].append(original_probability.reshape(-1)[indices])
    buffers["canonical_probability"].append(canonical_probability.reshape(-1)[indices])
    manifest_rows.append({
        "case_code": case_code,
        "case": case,
        "finding_idx": finding_idx,
        "sample_start": start,
        "sample_count": int(indices.size),
        "positive_samples": int(positive.size),
        "negative_samples": int(negative.size),
    })


def main() -> int:
    args = parse_args()
    thresholds = sorted(set(args.thresholds))
    if not thresholds or any(not 0 < value < 1 for value in thresholds):
        raise ValueError(f"Invalid thresholds: {thresholds}")

    world_size = args.num_shards or int(os.environ.get("WORLD_SIZE", "1"))
    rank = args.shard_id if args.shard_id is not None else int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", str(args.gpu)))
    if rank < 0 or rank >= world_size:
        raise ValueError(f"shard-id {rank} is outside [0, {world_size})")

    all_entries = select_entries(
        load_entries(args.rex_json, [args.split]), args.image_dir, None, None
    )
    if args.case_list_json is not None:
        selected = json.loads(args.case_list_json.read_text()).get("cases")
        if not isinstance(selected, list) or not selected:
            raise ValueError(f"{args.case_list_json} must contain a non-empty 'cases' list")
        wanted = set(map(str, selected))
        all_entries = [entry for entry in all_entries if entry["name"] in wanted]
        found = {entry["name"] for entry in all_entries}
        missing = sorted(wanted - found)
        if missing:
            raise ValueError(f"Case list has {len(missing)} missing validation cases; first={missing[0]}")
        order = {name: index for index, name in enumerate(selected)}
        all_entries.sort(key=lambda entry: order[entry["name"]])
    elif args.max_cases is not None:
        if args.max_cases <= 0:
            raise ValueError("--max-cases must be positive")
        if args.max_cases < len(all_entries):
            rng = np.random.default_rng(args.seed)
            selected_indices = np.sort(rng.choice(
                len(all_entries), size=args.max_cases, replace=False
            ))
            all_entries = [all_entries[index] for index in selected_indices]
    entries = [entry for index, entry in enumerate(all_entries) if index % world_size == rank]
    shard_dir = args.output_dir / f"shard_{rank:02d}" if world_size > 1 else args.output_dir
    shard_dir.mkdir(parents=True, exist_ok=True)
    if rank == 0:
        (args.output_dir / "selected_cases.json").write_text(json.dumps({
            "split": args.split,
            "seed": args.seed,
            "max_cases": args.max_cases,
            "case_list_json": str(args.case_list_json) if args.case_list_json else None,
            "selected_case_count": len(all_entries),
            "cases": [entry["name"] for entry in all_entries],
        }, indent=2) + "\n")

    if args.variant_cache:
        caches = {}
        for spec in args.variant_cache:
            if "=" not in spec:
                raise ValueError(f"Invalid --variant-cache '{spec}'; expected NAME=PATH")
            name, raw_path = spec.split("=", 1)
            name = name.strip()
            if not name:
                raise ValueError(f"Invalid --variant-cache '{spec}'; empty name")
            if name in caches:
                raise ValueError(f"Duplicate --variant-cache name: {name}")
            caches[name] = load_embedding_cache(Path(raw_path))["mapping"]
    else:
        if args.original_cache is None or args.canonical_cache is None:
            raise ValueError("Supply --original-cache/--canonical-cache or one or more --variant-cache specs")
        caches = {
            "original": load_embedding_cache(args.original_cache)["mapping"],
            "canonical_visual": load_embedding_cache(args.canonical_cache)["mapping"],
        }
    if "original" not in caches:
        raise ValueError("An 'original' embedding cache is required as the paired reference")
    if args.save_sampled_logits and "canonical_visual" not in caches:
        raise ValueError("--save-sampled-logits currently requires a 'canonical_visual' cache")
    device = torch.device(f"cuda:{local_rank}" if args.device == "cuda" else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(device)
    # Let VoxTellPredictor load the requested checkpoint itself. Experimental
    # checkpoints keep S2/S3 modules in dedicated payload keys rather than in
    # network_weights, so reloading network_weights with strict=True here would
    # incorrectly discard/fail those modules. All prompt variants are cached,
    # therefore the multi-billion-parameter text backbone is unnecessary.
    predictor = VoxTellPredictor(
        str(args.model_dir),
        device,
        args.text_encoding_model,
        checkpoint_path=str(args.checkpoint),
        load_text_backbone=False,
    )
    predictor.network.eval()

    rows: list[dict] = []
    logit_summary_rows: list[dict] = []
    ap_repeat_rows: list[dict] = []
    sample_manifest_rows: list[dict] = []
    sampled_buffers: dict[str, list] = {
        "case_code": [],
        "finding_idx": [],
        "flat_index": [],
        "stratum": [],
        "gt_label": [],
        "original_logit": [],
        "canonical_logit": [],
        "original_probability": [],
        "canonical_probability": [],
    }
    case_code_lookup: dict[str, int] = {}
    for entry in tqdm(entries, desc=f"Full-val prompt audit shard {rank}", unit="case"):
        case = entry["name"]
        if case not in case_code_lookup:
            case_code_lookup[case] = len(case_code_lookup)
        image, properties = load_image(args.image_dir / case)
        data, bbox, original_shape = predictor.preprocess(image)
        finding_keys = sorted_finding_keys(entry)
        categories = [str((entry.get("categories") or {}).get(key, "unknown")) for key in finding_keys]
        gt = load_reference_mask_for_window_diagnostic(
            args.mask_dir / case,
            len(finding_keys),
            tuple(original_shape),
            bbox,
            image_properties=properties,
        )
        if gt is None:
            raise ValueError(f"Could not align GT for {case}")
        target = gt.numpy().astype(bool, copy=False)
        voxel_mm3 = float(np.prod(properties.get("spacing", (1.0, 1.0, 1.0))))

        logits_by_variant = {}
        probabilities = {}
        for variant, mapping in caches.items():
            embeddings = torch.stack([
                mapping[(entry["_split"], case, int(finding_idx))]
                for finding_idx in finding_keys
            ])[None].to(device)
            inference_kwargs = {}
            if args.s3_enabled_categories is not None:
                enabled = set(map(str, args.s3_enabled_categories))
                inference_kwargs["spatial_attention_rho_scale"] = torch.tensor(
                    [[float(category in enabled) for category in categories]],
                    device=device,
                    dtype=torch.float32,
                )
            logits = predictor.predict_sliding_window_return_logits(data, embeddings, **inference_kwargs)
            logits_np = logits.cpu().float().numpy()
            logits_by_variant[variant] = logits_np
            probabilities[variant] = 1.0 / (1.0 + np.exp(-logits_np))
            del logits, embeddings

        for channel, finding_idx in enumerate(finding_keys):
            gt_channel = target[channel]
            positive, negative = stratified_indices(
                gt_channel,
                args.max_ranking_voxels_per_class,
                stable_seed(case, int(finding_idx), args.seed),
            )
            ranking = {
                variant: ranking_metrics(probabilities[variant][channel], positive, negative)
                for variant in probabilities
            }
            for repeat in range(max(1, args.ranking_repeat_seeds)):
                repeat_positive, repeat_negative = stratified_indices(
                    gt_channel,
                    args.max_ranking_voxels_per_class,
                    stable_seed(case, int(finding_idx), args.seed + repeat * 10_003),
                )
                for variant in probabilities:
                    repeat_metrics = ranking_metrics(
                        probabilities[variant][channel],
                        repeat_positive,
                        repeat_negative,
                    )
                    ap_repeat_rows.append({
                        "case": case,
                        "finding_idx": int(finding_idx),
                        "variant": variant,
                        "repeat_seed_index": repeat,
                        "seed": int(args.seed + repeat * 10_003),
                        "ranking_positive_samples": int(repeat_positive.size),
                        "ranking_negative_samples": int(repeat_negative.size),
                        **repeat_metrics,
                    })
            if args.save_sampled_logits:
                append_sampled_values(
                    case_code=case_code_lookup[case],
                    case=case,
                    finding_idx=int(finding_idx),
                    positive=positive,
                    negative=negative,
                    target=gt_channel,
                    original_logits=logits_by_variant["original"][channel],
                    canonical_logits=logits_by_variant["canonical_visual"][channel],
                    original_probability=probabilities["original"][channel],
                    canonical_probability=probabilities["canonical_visual"][channel],
                    buffers=sampled_buffers,
                    manifest_rows=sample_manifest_rows,
                )
            category = categories[channel]
            summary_by_variant = {
                variant: summarize_logits(
                    logits_by_variant[variant][channel],
                    probabilities[variant][channel],
                    gt_channel,
                )
                for variant in probabilities
            }
            for variant, summary in summary_by_variant.items():
                logit_summary_rows.append({
                    "case": case,
                    "finding_idx": int(finding_idx),
                    "category": category,
                    "focality": "non-focal" if category.startswith("1") else "focal",
                    "variant": variant,
                    "gt_voxels": int(gt_channel.sum()),
                    **summary,
                })
            for threshold in thresholds:
                original_prediction = probabilities["original"][channel] > threshold
                for variant in probabilities:
                    probability = probabilities[variant][channel]
                    prediction = probability > threshold
                    metrics = prompt_metrics(probability, gt_channel, threshold, voxel_mm3)
                    probability_mad = float(np.mean(np.abs(
                        probability - probabilities["original"][channel]
                    )))
                    probability_corr = probability_correlation(
                        probability, probabilities["original"][channel]
                    )
                    rows.append({
                        "case": case,
                        "finding_idx": int(finding_idx),
                        "category": category,
                        "focality": "non-focal" if category.startswith("1") else "focal",
                        "variant": variant,
                        "threshold": threshold,
                        "global_hit": metrics["dice"] >= 0.1,
                        "prediction_dice_vs_original_same_threshold": binary_dice(
                            prediction, original_prediction
                        ),
                        "probability_correlation_to_original": (
                            1.0 if variant == "original" else probability_corr
                        ),
                        "mean_absolute_probability_difference": (
                            0.0 if variant == "original" else probability_mad
                        ),
                        "ranking_positive_samples": int(positive.size),
                        "ranking_negative_samples": int(negative.size),
                        **ranking[variant],
                        **summary_by_variant[variant],
                        **metrics,
                    })

        del probabilities, logits_by_variant, data, gt
        if device.type == "cuda":
            torch.cuda.empty_cache()

    output_csv = shard_dir / "per_finding_threshold_metrics.csv"
    with output_csv.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    logit_summary_csv = shard_dir / "per_finding_logit_summary.csv"
    with logit_summary_csv.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(logit_summary_rows[0]))
        writer.writeheader()
        writer.writerows(logit_summary_rows)
    ap_repeat_csv = shard_dir / "per_finding_ap_repeats.csv"
    with ap_repeat_csv.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(ap_repeat_rows[0]))
        writer.writeheader()
        writer.writerows(ap_repeat_rows)
    sampled_npz = None
    sample_manifest_csv = None
    if args.save_sampled_logits:
        dtype = np.float16 if args.sampled_logit_dtype == "float16" else np.float32
        sampled_npz = shard_dir / "sampled_voxel_logits.npz"
        arrays = {}
        for name, chunks in sampled_buffers.items():
            if chunks:
                values = np.concatenate(chunks)
            else:
                values = np.empty(0, dtype=np.float32)
            if name.endswith("logit") or name.endswith("probability"):
                values = values.astype(dtype, copy=False)
            arrays[name] = values
        np.savez_compressed(
            sampled_npz,
            **arrays,
            case_names=np.asarray(
                [case for case, _ in sorted(case_code_lookup.items(), key=lambda item: item[1])],
                dtype=object,
            ),
            seed=np.asarray([args.seed], dtype=np.int64),
        )
        sample_manifest_csv = shard_dir / "sampled_voxel_manifest.csv"
        with sample_manifest_csv.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(sample_manifest_rows[0]))
            writer.writeheader()
            writer.writerows(sample_manifest_rows)
    manifest = {
        "rank": rank,
        "world_size": world_size,
        "cases": len(entries),
        "case_names": [entry["name"] for entry in entries],
        "finding_threshold_variant_rows": len(rows),
        "thresholds": thresholds,
        "variants": list(caches),
        "ranking_repeat_seeds": args.ranking_repeat_seeds,
        "save_sampled_logits": args.save_sampled_logits,
        "checkpoint": str(args.checkpoint.resolve()),
        "output_csv": str(output_csv.resolve()),
        "logit_summary_csv": str(logit_summary_csv.resolve()),
        "ap_repeat_csv": str(ap_repeat_csv.resolve()),
        "sampled_voxel_logits": str(sampled_npz.resolve()) if sampled_npz else None,
        "sampled_voxel_manifest": str(sample_manifest_csv.resolve()) if sample_manifest_csv else None,
    }
    (shard_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
