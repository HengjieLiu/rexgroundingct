#!/usr/bin/env python3
"""Selected-update text/image drift and four-stage interaction diagnostics."""

from __future__ import annotations

import gc
import json
import sys
from pathlib import Path

import pandas as pd
import torch
import torch.nn.functional as F
from transformers import AutoConfig, AutoModel, AutoTokenizer


ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT, ROOT / "VoxTell"):
    if str(search_path) not in sys.path:
        sys.path.insert(0, str(search_path))

from scripts.diagnose_token_image_text_phase0 import pad_and_crop  # noqa: E402
from scripts.diagnose_token_image_text_phase0b_gate import replace_symlink  # noqa: E402
from scripts.run_voxtell_rex_inference import load_image  # noqa: E402
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402


OUT = ROOT / "outputs/medplex_trainable_text_study"
UPDATES = [0, 1000, 2000, 3000, 4000, 5000]
PBT_ROOT = ROOT / "model_assets/pubmedbert/e1354b7a3a09615f6aba48dfad4b7a613eef7062"
BCLIP_ROOT = ROOT / "model_assets/biomedclip/9f341de24bfb00180f1b847274256e9b65a3a32e"
BCLIP_ARCH = ROOT / "model_assets/biomedclip/biomedbert_arch_config"
ARMS = {
    "P0": {
        "run": ROOT / "outputs/pbt_trainable_control_from4800",
        "cache": ROOT / "model_assets/text_embedding_analysis/pubmedbert_train_val.pt",
        "mode": "pubmedbert",
        "bifusion": False,
    },
    "M1": {
        "run": ROOT / "outputs/pbt_medplex_from4800",
        "cache": ROOT / "model_assets/text_embedding_analysis/pubmedbert_train_val.pt",
        "mode": "pubmedbert",
        "bifusion": True,
    },
    "B0": {
        "run": ROOT / "outputs/bclip_trainable_control_from4000",
        "cache": ROOT / "model_assets/text_embedding_analysis/biomedclip_cls_train_val.pt",
        "mode": "biomedclip",
        "bifusion": False,
    },
    "M2": {
        "run": ROOT / "outputs/bclip_medplex_from4000",
        "cache": ROOT / "model_assets/text_embedding_analysis/biomedclip_cls_train_val.pt",
        "mode": "biomedclip",
        "bifusion": True,
    },
}


def checkpoint_path(run: Path, update: int) -> Path:
    return run / "checkpoints" / (
        "checkpoint_initial.pth" if update == 0 else f"checkpoint_update_{update}.pth"
    )


def metrics(reference: torch.Tensor, value: torch.Tensor) -> dict[str, float]:
    reference = reference.detach().float().reshape(-1)
    value = value.detach().float().reshape(-1)
    return {
        "relative_l2": float((value - reference).norm() / reference.norm().clamp_min(1e-12)),
        "cosine_to_update0": float(F.cosine_similarity(reference, value, dim=0)),
    }


def load_text_model(mode: str, device: torch.device):
    if mode == "pubmedbert":
        model = AutoModel.from_pretrained(PBT_ROOT, local_files_only=True)
        tokenizer = AutoTokenizer.from_pretrained(PBT_ROOT, local_files_only=True)
    else:
        model = AutoModel.from_config(AutoConfig.from_pretrained(BCLIP_ARCH, local_files_only=True))
        tokenizer = AutoTokenizer.from_pretrained(BCLIP_ROOT, local_files_only=True)
    return model.eval().to(device), tokenizer


def medplex_text_state(payload: dict) -> dict[str, torch.Tensor]:
    prefix = "medplex_staged_text.backbone."
    return {
        name.removeprefix(prefix): value
        for name, value in payload["network_weights"].items()
        if name.startswith(prefix)
    }


@torch.inference_mode()
def intrinsic_text_drift(device: torch.device) -> list[dict]:
    rows = []
    for arm, config in ARMS.items():
        cache = torch.load(config["cache"], map_location="cpu", weights_only=False, mmap=True)
        prompts = [str(item["prompt"]) for item in cache["records"][:10]]
        model, tokenizer = load_text_model(config["mode"], device)
        encoded = tokenizer(prompts, padding=True, truncation=True, max_length=128, return_tensors="pt")
        encoded = {key: value.to(device) for key, value in encoded.items()}
        baseline = None
        for update in UPDATES:
            payload = torch.load(checkpoint_path(config["run"], update), map_location="cpu", weights_only=False, mmap=True)
            incompatible = model.load_state_dict(medplex_text_state(payload), strict=False)
            invalid_missing = [name for name in incompatible.missing_keys if not name.startswith("pooler.")]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    f"{arm}@{update} BERT state mismatch: missing={invalid_missing}, unexpected={incompatible.unexpected_keys}"
                )
            del payload
            pooled = model(**encoded).last_hidden_state[:, 0].float()
            if baseline is None:
                baseline = pooled.clone()
            for index, prompt in enumerate(prompts):
                rows.append({
                    "arm": arm,
                    "update": update,
                    "prompt_index": index,
                    "prompt": prompt,
                    "scope": "bert_final_cls_intrinsic",
                    **metrics(baseline[index], pooled[index]),
                })
            gc.collect()
        del model, encoded, cache
        gc.collect()
        torch.cuda.empty_cache()
    return rows


def representative_record(cache_path: Path) -> tuple[dict, torch.Tensor]:
    cache = torch.load(cache_path, map_location="cpu", weights_only=False, mmap=True)
    manifest = json.loads(
        (ROOT / "outputs/pubmedbert_voxtell/PBT-CLS/fixed30/update_04800/fixed30_manifest.json").read_text()
    )
    entry = manifest["val"][0]
    finding_key, prompt = next(iter(entry["findings"].items()))
    index = next(
        idx for idx, item in enumerate(cache["records"])
        if str(item["case"]) == str(entry["name"])
        and int(item["finding_idx"]) == int(finding_key)
        and str(item["prompt"]) == str(prompt)
    )
    return {
        "case": str(entry["name"]),
        "finding_idx": int(finding_key),
        "prompt": str(prompt),
    }, cache["cls_embeddings"][index].float().clone()


@torch.inference_mode()
def image_and_interaction_drift(device: torch.device) -> tuple[list[dict], list[dict]]:
    representation_rows = []
    interaction_rows = []
    model_assets = OUT / "diagnostic_model"
    replace_symlink(model_assets / "plans.json", ROOT / "VoxTell/voxtell_v1.1/plans.json")
    patch_by_case: dict[str, torch.Tensor] = {}
    for arm, config in ARMS.items():
        record, cached_cls = representative_record(config["cache"])
        baselines: dict[str, torch.Tensor] = {}
        for update in UPDATES:
            predictor = VoxTellPredictor(
                str(model_assets),
                checkpoint_path=str(checkpoint_path(config["run"], update)),
                device=device,
                load_text_backbone=False,
                text_representation=("pubmedbert_cls" if config["mode"] == "pubmedbert" else "biomedclip_cls"),
                amp_dtype="bfloat16",
            )
            if record["case"] not in patch_by_case:
                image, _ = load_image(ROOT / "data/ct_rate_volumes_fixed" / record["case"])
                preprocessed, _bbox, _shape = predictor.preprocess(image)
                empty = torch.zeros(preprocessed.shape[-3:], dtype=torch.float32)
                patch_by_case[record["case"]], _target, _starts, _padding = pad_and_crop(preprocessed, empty)
            patch = patch_by_case[record["case"]]
            network = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
            network.eval()
            encoded = predictor.medplex_tokenizer(
                [record["prompt"]], padding=True, truncation=True,
                max_length=predictor.medplex_max_length, return_tensors="pt",
            )
            captured: dict[str, torch.Tensor] = {}

            def capture(name: str):
                def hook(_module, _inputs, output):
                    captured[name] = output.detach().float().cpu()
                return hook

            handles = [
                network.encoder.stages[3].register_forward_hook(capture("image_stage3")),
                network.encoder.stages[4].register_forward_hook(capture("image_stage4")),
            ]
            try:
                # Use the same public sliding-window path as fixed30.  Besides
                # preserving inference semantics, this avoids bypassing the
                # predictor's mixed-precision/device setup.
                predictor.predict_sliding_window_return_logits(
                    patch.to(dtype=torch.float32),
                    cached_cls.reshape(1, 1, 768).to(dtype=torch.float32),
                    text_prompts=[record["prompt"]],
                )
            finally:
                for handle in handles:
                    handle.remove()
            for scope, value in captured.items():
                if scope not in baselines:
                    baselines[scope] = value.clone()
                representation_rows.append({
                    "arm": arm, "update": update, **record, "scope": scope,
                    **metrics(baselines[scope], value),
                })
            audit = dict(network.last_medplex_audit)
            if config["bifusion"] and update > 0:
                for stage, item in enumerate(audit.get("stages", []), start=1):
                    interaction_rows.append({
                        "arm": arm, "update": update, "stage": stage, **record,
                        "gamma_image": audit["gamma_image"][stage - 1],
                        "gamma_text": audit["gamma_text"][stage - 1],
                        "delta_v_rel_l2": item["image_relative_l2"],
                        "delta_t_rel_l2": item["text_relative_l2"],
                    })
            del network, predictor, captured
            gc.collect()
            torch.cuda.empty_cache()
    return representation_rows, interaction_rows


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda")
    rows = intrinsic_text_drift(device)
    image_rows, interaction_rows = image_and_interaction_drift(device)
    rows.extend(image_rows)
    pd.DataFrame(rows).to_csv(OUT / "representation_drift.csv", index=False)
    pd.DataFrame(interaction_rows).to_csv(OUT / "bifusion_interaction_magnitude.csv", index=False)
    summary = {
        "status": "complete",
        "updates": UPDATES,
        "representation_rows": len(rows),
        "interaction_rows": len(interaction_rows),
    }
    (OUT / "representation_drift_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
