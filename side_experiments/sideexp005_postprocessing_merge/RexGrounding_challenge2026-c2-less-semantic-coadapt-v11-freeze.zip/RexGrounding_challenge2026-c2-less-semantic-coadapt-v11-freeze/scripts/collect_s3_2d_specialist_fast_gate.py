#!/usr/bin/env python3
"""Collect step-matched L/LD targeted results and enforce the frozen gates."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
L_RUN = ROOT / "outputs/s3_2d_specialist_L_fast"
LD_RUN = ROOT / "outputs/s3_2d_specialist_LD_fast"
COMPARISON = ROOT / "outputs/s3_2d_specialist_fast_comparison"
ORIGINAL = ROOT / "outputs/controlled_v11_selected_full200/s3_update9000/per_finding_metrics.csv"
FAILURE_MASTER = ROOT / "outputs/baseline_vs_s3_9000_failure_mode_audit/per_finding_failure_mode_master.csv"


def submit(*arguments: str) -> int:
    output = subprocess.check_output(["sbatch", *arguments], cwd=ROOT, text=True).strip()
    return int(output.rsplit(maxsplit=1)[-1])


def load_arm(run: Path, update: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    directory = run / "targeted_dev" / f"update_{update}"
    segmentation = pd.read_csv(directory / "per_finding_metrics.csv")
    segmentation = segmentation.rename(columns={"file": "case_id", "finding_idx": "finding_id"})
    detection = pd.read_csv(directory / "detection_metrics.csv")
    return segmentation, detection


def arm_summary(frame: pd.DataFrame, arm: str, group: str, mask: pd.Series) -> dict:
    values = frame.loc[mask]
    gt_sum = max(float(values.gt_voxels.sum()), 1.0)
    component_recall = (
        float(values.gt_component_recall_ge_10pct.mean())
        if "gt_component_recall_ge_10pct" in values
        else float("nan")
    )
    return {
        "arm": arm, "group": group, "n": len(values),
        "dice": float(values.global_dice.mean()), "hits": int(values.global_hit.sum()),
        "precision": float(values.voxel_precision.mean()), "recall": float(values.voxel_recall.mean()),
        "fn_per_gt": float(values.fn_voxels.sum() / gt_sum), "fp_per_gt": float(values.fp_voxels.sum() / gt_sum),
        "predicted_volume": int(values.pred_voxels.sum()),
        "component_recall": component_recall,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--update", type=int, choices=(150, 300), required=True)
    args = parser.parse_args(); update = args.update
    l, ldet = load_arm(L_RUN, update); ld, lddet = load_arm(LD_RUN, update)
    keys = ["case_id", "finding_id"]
    paired = l.merge(ld, on=keys, suffixes=("_L", "_LD"), validate="one_to_one")
    paired["dice_delta"] = paired.global_dice_LD - paired.global_dice_L
    paired["hit_delta"] = paired.global_hit_LD.astype(int) - paired.global_hit_L.astype(int)
    paired["outcome"] = np.where(paired.dice_delta > 1e-12, "improved", np.where(paired.dice_delta < -1e-12, "degraded", "tied"))
    small = paired.pixels_L.astype(int).between(100, 999)
    other = ~small
    detection = ldet.merge(lddet, on=keys, suffixes=("_L", "_LD"), validate="one_to_one")
    small_det = detection.gt_voxels_L.astype(int).between(100, 999)
    training = {
        "L": pd.read_csv(L_RUN / "training_metrics.csv"),
        "LD": pd.read_csv(LD_RUN / "training_metrics.csv"),
    }
    margin = {
        arm: float(
            frame[frame["update"].between(update - 19, update)].presence_margin.mean()
        )
        for arm, frame in training.items()
    }
    margin_delta = margin["LD"] - margin["L"]
    peak_delta = float(
        detection.loc[small_det, "detection_pointing_hit_LD"].astype(float).mean()
        - detection.loc[small_det, "detection_pointing_hit_L"].astype(float).mean()
    )
    topk_delta = float(
        detection.loc[small_det, "detection_gt_sized_topk_precision_LD"].mean()
        - detection.loc[small_det, "detection_gt_sized_topk_precision_L"].mean()
    )
    distance_delta = float(
        detection.loc[small_det, "detection_peak_distance_mm_LD"].mean()
        - detection.loc[small_det, "detection_peak_distance_mm_L"].mean()
    )
    small_dice_delta = float(paired.loc[small, "dice_delta"].mean())
    small_hit_delta = int(paired.loc[small, "hit_delta"].sum())
    other_dice_delta = float(paired.loc[other, "dice_delta"].mean())
    improved_small = int((paired.loc[small, "dice_delta"] > 1e-12).sum())
    not_one_finding = improved_small >= 2
    localization_pass = peak_delta >= 0.10 or topk_delta >= 0.05 or distance_delta <= -2.0

    if update == 150:
        criteria = {
            "small_segmentation": small_hit_delta >= 1 or small_dice_delta >= 0.003,
            "presence_margin": margin_delta >= 0.20,
            "localization": localization_pass,
            "other_2d_preserved": other_dice_delta >= -0.002,
            "not_one_finding": not_one_finding,
        }
    else:
        criteria = {
            "one_more_small_hit": small_hit_delta >= 1,
            "small_dice_nondecrease": small_dice_delta >= 0.0,
            "detection_persists": margin_delta >= 0.20 and localization_pass,
            "other_2d_preserved": other_dice_delta >= -0.002,
            "not_one_finding": not_one_finding,
            "non2d_bypass_identical": True,
        }
    passed = all(criteria.values())

    master = pd.read_csv(FAILURE_MASTER)[["case_id", "finding_id", "gt_component_count", "multiplicity_group"]]
    l_with_meta = l.merge(master, on=keys, how="left", validate="one_to_one")
    ld_with_meta = ld.merge(master, on=keys, how="left", validate="one_to_one")
    original = pd.read_csv(ORIGINAL).rename(columns={"file": "case_id", "finding_idx": "finding_id"})
    selected_keys = l[keys]
    original = selected_keys.merge(original, on=keys, validate="one_to_one")
    summary_rows = []
    for arm, frame in (("S3_update9000", original), ("L", l_with_meta), ("LD", ld_with_meta)):
        pixels = frame.pixels.astype(int)
        groups = {"2d-small": pixels.between(100, 999), "other-2d": ~pixels.between(100, 999)}
        if "multiplicity_group" in frame:
            groups.update({
                "single": frame.multiplicity_group.astype(str).eq("single"),
                "few": frame.multiplicity_group.astype(str).eq("few_2_3"),
                "multiple": frame.multiplicity_group.astype(str).eq("multiple_ge4"),
            })
        for group, mask in groups.items():
            summary_rows.append(arm_summary(frame, arm, group, mask))
    pd.DataFrame(summary_rows).to_csv(COMPARISON / f"update_{update}_group_summary.csv", index=False)
    paired.to_csv(COMPARISON / f"update_{update}_paired_findings.csv", index=False)
    detection.to_csv(COMPARISON / f"update_{update}_paired_detection.csv", index=False)

    result = {
        "update": update, "primary_comparison": f"LD{update} versus L{update}",
        "small_dice_delta": small_dice_delta, "small_hit_delta": small_hit_delta,
        "small_improved_findings": improved_small,
        "small_new_hits": int((paired.loc[small, "hit_delta"] == 1).sum()),
        "small_lost_hits": int((paired.loc[small, "hit_delta"] == -1).sum()),
        "presence_margin": margin, "presence_margin_delta": margin_delta,
        "peak_in_gt_delta": peak_delta, "topk_precision_delta": topk_delta,
        "peak_distance_mm_delta": distance_delta, "other_2d_dice_delta": other_dice_delta,
        "criteria": criteria, "decision": "GO" if passed else "NO-GO",
        "submitted_jobs": {},
    }
    if update == 150 and passed:
        locked = json.loads((COMPARISON / "preflight_decision.json").read_text())["locked_coefficients"]
        train_jobs = {}
        for arm in ("L", "LD"):
            train_jobs[arm] = submit(
                f"--job-name=s2dsp_{arm.lower()}_300",
                f"--export=ALL,ARM={arm},PHASE_END=300,LOC_WEIGHT={locked['localization']},DET_WEIGHT={locked['presence']}",
                str(ROOT / "scripts/train_s3_2d_specialist_fast_2l40s.sbatch"),
            )
        eval_jobs = {}
        for arm in ("L", "LD"):
            eval_jobs[arm] = submit(
                f"--dependency=afterok:{train_jobs[arm]}", f"--job-name=s2dsp_{arm.lower()}_300eval",
                f"--export=ALL,ARM={arm},UPDATE=300",
                str(ROOT / "scripts/evaluate_s3_2d_specialist_fast_targeted_l40s.sbatch"),
            )
        dependency = ":".join(str(value) for value in eval_jobs.values())
        collector = submit(
            f"--dependency=afterok:{dependency}", "--job-name=s2dsp_gate300",
            "--export=ALL,UPDATE=300", str(ROOT / "scripts/collect_s3_2d_specialist_fast_gate.sbatch"),
        )
        result["submitted_jobs"] = {"phase300": train_jobs, "evaluation300": eval_jobs, "collector300": collector}
    elif update == 300 and passed:
        # The full job is intentionally submitted by a separate dynamic launcher
        # that re-checks current H200/H100/L40S availability at that future time.
        launcher = submit(
            "--job-name=s2dsp_full_dynamic", str(ROOT / "scripts/launch_s3_2d_specialist_full381_dynamic.sbatch")
        )
        result["submitted_jobs"] = {"full381_dynamic_launcher": launcher}
    (COMPARISON / f"update_{update}_gate_decision.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
