#!/usr/bin/env python3
"""Aggregate attention checkpoint-search trajectory and conditional hybrid."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "outputs/dual_expert_historical_lr_from_u500"
OUT = BASE / "attention_continue_3000_to_5000"
SOURCE = BASE / "attention_to_u3000/full_volume_update3000/summary_tables/specialist_metrics.csv"
BASELINE = ROOT / "outputs/nonattention_baseline_selection/full381_update10000/summary_tables/per_finding_metrics.csv"
CATEGORIES = ["1c", "1d", "1f", "2b", "2c"]
KEYS = ["file", "finding_idx"]


def write_json(name: str, payload: object) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_text(json.dumps(payload, indent=2, default=str) + "\n")


def path_for(update: int) -> Path:
    if update == 3000:
        return SOURCE
    return OUT / f"evaluations/update{update}/summary_tables/specialist_metrics.csv"


def load(update: int) -> pd.DataFrame:
    frame = pd.read_csv(path_for(update))
    frame = frame[frame.category.astype(str).isin(CATEGORIES)].copy()
    frame["category"] = frame.category.astype(str)
    if len(frame) != 136 or frame.duplicated(KEYS).any():
        raise RuntimeError(f"update{update}: expected 136 unique expert findings")
    return frame.sort_values(KEYS).reset_index(drop=True)


def summary(frame: pd.DataFrame) -> dict:
    gt = frame.gt_voxels.clip(lower=1)
    return {
        "findings": len(frame), "mean_dice": float(frame.global_dice.mean()),
        "hits": int(frame.global_hit.astype(bool).sum()),
        "precision": float(frame.voxel_precision.mean()),
        "recall": float(frame.voxel_recall.mean()),
        "FP_GT": float((frame.fp_voxels / gt).mean()),
        "FN_GT": float((frame.fn_voxels / gt).mean()),
        "predicted_GT_volume_ratio": float((frame.pred_voxels / gt).mean()),
    }


def paired(candidate: pd.DataFrame, reference: pd.DataFrame) -> dict:
    merged = reference[KEYS + ["global_dice", "global_hit"]].merge(
        candidate[KEYS + ["global_dice", "global_hit"]], on=KEYS,
        suffixes=("_reference", "_candidate"), validate="one_to_one")
    delta = merged.global_dice_candidate - merged.global_dice_reference
    abs_sum = float(delta.abs().sum())
    per_case = merged.assign(delta=delta).groupby("file").delta.mean()
    leave_one = [float(delta[merged.file.ne(case)].mean()) for case in per_case.index]
    return {
        "mean_dice_delta": float(delta.mean()),
        "hit_delta": int(merged.global_hit_candidate.sum() - merged.global_hit_reference.sum()),
        "improved_degraded_tied": [int((delta > 1e-12).sum()), int((delta < -1e-12).sum()), int((delta.abs() <= 1e-12).sum())],
        "largest_finding_absolute_share": float(delta.abs().max() / abs_sum) if abs_sum else 0.0,
        "leave_one_case_out_delta_min": min(leave_one),
        "leave_one_case_out_delta_max": max(leave_one),
        "single_case_dominated": bool(abs_sum and delta.abs().max() / abs_sum > 0.5),
    }


def build_trajectory(updates: list[int]) -> tuple[pd.DataFrame, pd.DataFrame, dict[int, pd.DataFrame]]:
    frames = {update: load(update) for update in updates}
    reference = frames[3000]
    baseline_all = pd.read_csv(BASELINE)
    baseline_all["category"] = baseline_all.category.astype(str)
    reference_keys = set(map(tuple, reference[KEYS].itertuples(index=False, name=None)))
    baseline = baseline_all[
        [tuple(row) in reference_keys for row in baseline_all[KEYS].itertuples(index=False, name=None)]
    ].sort_values(KEYS).reset_index(drop=True)
    if len(baseline) != 136:
        raise RuntimeError("baseline10000 expert-pool mapping mismatch")
    rows, category_rows = [], []
    for update, frame in frames.items():
        overall = summary(frame)
        rows.append({
            "update": update, **overall,
            "dice_delta_vs_attention3000": float(frame.global_dice.mean() - reference.global_dice.mean()),
            "dice_delta_vs_baseline10000": float(frame.global_dice.mean() - baseline.global_dice.mean()),
        })
        for category in CATEGORIES:
            block = frame[frame.category.eq(category)]
            ref_block = reference[reference.category.eq(category)]
            base_block = baseline[baseline.category.eq(category)]
            category_rows.append({
                "update": update, "category": category, **summary(block),
                "dice_delta_vs_attention3000": float(block.global_dice.mean() - ref_block.global_dice.mean()),
                "dice_delta_vs_baseline10000": float(block.global_dice.mean() - base_block.global_dice.mean()),
            })
    trajectory = pd.DataFrame(rows).sort_values("update")
    per_category = pd.DataFrame(category_rows).sort_values(["update", "category"])
    trajectory.to_csv(OUT / "attention_trajectory.csv", index=False)
    per_category.to_csv(OUT / "per_category_trajectory.csv", index=False)
    control_context = []
    for prior_update in (1500, 2000, 2500, 3000):
        prior_path = BASE / f"comparison/update_{prior_update:05d}/summary.json"
        if prior_path.is_file():
            value = json.loads(prior_path.read_text())
            control_context.append({
                "update": prior_update,
                "control_mean_dice": value["control_mean_dice"],
                "attention_mean_dice": value["attention_mean_dice"],
                "sampler_traces_identical": value["sampler_traces_identical"],
            })
    write_json("attention_trajectory_summary.json", {
        "updates": trajectory.to_dict("records"),
        "primary_categories": ["2b", "2c"], "secondary_category": "1c",
        "exploratory_categories": ["1d", "1f"],
        "prior_control_trajectory_context_only": control_context,
        "causal_ablation_caveat": "not a strict attention-control estimate after prior sampler-trace divergence",
    })
    return trajectory, per_category, frames


def early() -> None:
    trajectory, _, _ = build_trajectory([3000, 3500, 4000])
    scores = trajectory.set_index("update").mean_dice
    stop = bool(scores[3500] < scores[3000] - .003 and scores[4000] < scores[3000] - .003)
    write_json("early_stop_gate.json", {
        "status": "STOP" if stop else "CONTINUE", "reference_update": 3000,
        "reference_dice": scores[3000], "update3500_dice": scores[3500],
        "update4000_dice": scores[4000], "margin": 0.003,
        "rule": "STOP only if both 3500 and 4000 are below attention3000 by more than 0.003",
    })


def baseline_expert() -> pd.DataFrame:
    baseline = pd.read_csv(BASELINE)
    baseline["category"] = baseline.category.astype(str)
    baseline = baseline[baseline.category.isin(CATEGORIES)].copy()
    keys = set(map(tuple, load(3000)[KEYS].itertuples(index=False, name=None)))
    baseline = baseline[[tuple(row) in keys for row in baseline[KEYS].itertuples(index=False, name=None)]]
    if len(baseline) != 136 or baseline.duplicated(KEYS).any():
        raise RuntimeError("baseline10000 expert-pool mapping mismatch")
    return baseline.sort_values(KEYS).reset_index(drop=True)


def final() -> None:
    gate = json.loads((OUT / "early_stop_gate.json").read_text())
    updates = [3000, 3500, 4000] if gate["status"] == "STOP" else [3000, 3500, 4000, 4500, 5000]
    trajectory, per_category, frames = build_trajectory(updates)
    best_update = int(trajectory.loc[trajectory.mean_dice.idxmax(), "update"])
    best = frames[best_update]; reference = frames[3000]; baseline = baseline_expert()
    best_summary = summary(best); reference_summary = summary(reference); baseline_summary = summary(baseline)
    comparison_3000 = paired(best, reference)
    comparison_3000.update({
        "selected_update": best_update, "selected": best_summary, "attention3000": reference_summary,
        "per_category_dice_delta": {
            category: float(best[best.category.eq(category)].global_dice.mean() - reference[reference.category.eq(category)].global_dice.mean())
            for category in CATEGORIES},
    })
    comparison_baseline = paired(best, baseline)
    comparison_baseline.update({"selected_update": best_update, "selected": best_summary,
                                "baseline10000": baseline_summary})
    write_json("comparison_to_attention3000.json", comparison_3000)
    write_json("comparison_to_baseline10000.json", comparison_baseline)
    core_delta = np.mean([comparison_3000["per_category_dice_delta"][c] for c in ("2b", "2c")])
    precision_safe = best_summary["precision"] >= reference_summary["precision"] - .02
    volume_safe = best_summary["predicted_GT_volume_ratio"] <= 1.15 * reference_summary["predicted_GT_volume_ratio"]
    improved = best_update != 3000 and comparison_3000["mean_dice_delta"] > 0
    healthy = bool(improved and core_delta >= 0 and precision_safe and volume_safe
                   and best_summary["hits"] >= reference_summary["hits"]
                   and not comparison_3000["single_case_dominated"])
    best_payload = {
        "selected_update": best_update,
        "checkpoint": str((OUT / f"checkpoints/checkpoint_update_{best_update}.pth").resolve()) if best_update != 3000 else str((BASE / "attention_to_u3000/checkpoints/checkpoint_update_3000.pth").resolve()),
        "selection_metric": "expert-pool mean Dice", "metrics": best_summary,
        "improved_beyond_attention3000": improved, "healthy": healthy,
        "health_checks": {"2b_2c_mean_delta_nonnegative": core_delta >= 0,
                          "precision_stable": precision_safe, "volume_controlled": volume_safe,
                          "hits_stable_or_improved": best_summary["hits"] >= reference_summary["hits"],
                          "not_single_case_dominated": not comparison_3000["single_case_dominated"]},
    }
    write_json("best_checkpoint.json", best_payload)
    hybrid_written = False
    if improved:
        full_baseline = pd.read_csv(BASELINE); full_baseline["category"] = full_baseline.category.astype(str)
        expert_keys = set(map(tuple, best[KEYS].itertuples(index=False, name=None)))
        nonexpert = full_baseline[[tuple(row) not in expert_keys for row in full_baseline[KEYS].itertuples(index=False, name=None)]]
        if len(nonexpert) + len(best) != 381:
            raise RuntimeError("Hybrid mapping is not exactly 381 findings")
        category_contributions = {}
        for category in CATEGORIES:
            b = baseline[baseline.category.eq(category)]; s = best[best.category.eq(category)]
            category_contributions[category] = {
                "n": len(s), "selected_mean_dice": float(s.global_dice.mean()),
                "baseline_mean_dice": float(b.global_dice.mean()),
                "full381_mean_dice_contribution": float((s.global_dice.sum() - b.global_dice.sum()) / 381),
                "hit_delta": int(s.global_hit.sum() - b.global_hit.sum()),
            }
        hybrid = {
            "selected_attention_update": best_update,
            "overall_381_dice": float((nonexpert.global_dice.sum() + best.global_dice.sum()) / 381),
            "overall_381_hits": int(nonexpert.global_hit.sum() + best.global_hit.sum()),
            "baseline10000_overall_381_dice": float(full_baseline.global_dice.mean()),
            "baseline10000_overall_381_hits": int(full_baseline.global_hit.sum()),
            "non_expert_findings": len(nonexpert), "non_expert_exact_preservation": True,
            "category_contributions": category_contributions,
            "construction": "offline per-finding substitution; no GPU full381 rerun",
        }
        write_json("hybrid_summary.json", hybrid); hybrid_written = True
    decision = {
        "checkpoint_search_improved_beyond_3000": improved,
        "selected_update": best_update, "selected_checkpoint_healthy": healthy,
        "early_stop_status": gate["status"],
        "hybrid_generated": hybrid_written,
        "causal_ablation_claim_allowed": False,
        "conclusion": ("Improved and healthy checkpoint found" if healthy else
                       "Higher aggregate checkpoint found but health criteria failed" if improved else
                       "No checkpoint improved beyond attention3000"),
    }
    write_json("decision.json", decision)
    report = [
        "# Attention specialist continuation: update3000 to update5000", "",
        "## A. Checkpoint-search conclusion", "",
        f"Selected update: **{best_update}**; expert-pool Dice: **{best_summary['mean_dice']:.6f}**.",
        f"Improved beyond attention@3000: **{improved}**; healthy: **{healthy}**.", "",
        "## B. Causal-ablation caveat", "",
        "This continuation is an absolute checkpoint search. Because sampler traces diverged after the prior restart, it must not be interpreted as a strict Attention-Control causal estimate.", "",
        "See `attention_trajectory.csv`, `per_category_trajectory.csv`, and `best_checkpoint.json`.",
    ]
    (OUT / "report.md").write_text("\n".join(report) + "\n")


def register(args: argparse.Namespace) -> None:
    write_json("continuation_jobs.json", {
        "training_3000_to_4000": args.train_early,
        "early_gate": args.gate,
        "training_4000_to_5000_conditional": args.train_late,
        "resource_note": "recovery training uses one H200, 6 CPUs, 120G after observed 80G CPU-cgroup OOM",
        "recovery": ({
            "failed_job": args.failed_job,
            "failure": "CPU cgroup OOM at update3909 with MaxRSS 82245820K under 80G",
            "resume_checkpoint": str((OUT / "checkpoints/checkpoint_update_3500.pth").resolve()),
            "resume_checkpoint_sha256": "7b291b1f292cf570e6d9a1d327a7084ffbaba1a662a443206fcdf8f6a6ed8c68",
            "recovery_memory": "120G",
        } if args.failed_job else None),
    })
    write_json("eval_jobs.json", {
        "updates_3500_4000": args.eval_early,
        "updates_4500_5000_conditional": args.eval_late,
        "final_aggregation": args.final_job,
        "array_mapping": {"task_0": "first update in stage", "task_1": "second update in stage"},
    })


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["early", "final", "register"])
    parser.add_argument("--train-early"); parser.add_argument("--eval-early")
    parser.add_argument("--gate"); parser.add_argument("--train-late")
    parser.add_argument("--eval-late"); parser.add_argument("--final-job")
    parser.add_argument("--failed-job")
    args = parser.parse_args()
    if args.mode == "early": early()
    elif args.mode == "final": final()
    else:
        if not all((args.train_early, args.eval_early, args.gate, args.train_late, args.eval_late, args.final_job)):
            parser.error("register requires all job IDs")
        register(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
