#!/usr/bin/env python3
"""Targeted semantic propagation trace for trained Q-C2@5000.

This is inference-only. It recomputes frozen-Qwen layer-30 prefix states for
clean semantic substitutions, then traces paired original/modified prompts
through BiCA, the actual six Qwen suffix blocks, encoder stages, decoder
features, and a target-centred diagnostic-patch probability map.
"""

from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path
from typing import Any

import pandas as pd
import torch
import torch.nn.functional as F
from transformers import AutoModel, AutoTokenizer
from transformers.masking_utils import create_causal_mask


ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT, ROOT / "VoxTell", ROOT / "scripts"):
    if str(search_path) not in sys.path:
        sys.path.insert(0, str(search_path))

from audit_p0_minimal_location_swap_trace import generate_pairs, read_selected  # noqa: E402
from scripts.diagnose_token_image_text_phase0 import pad_and_crop  # noqa: E402
from scripts.diagnose_token_image_text_phase0b_gate import replace_symlink  # noqa: E402
from scripts.run_voxtell_rex_inference import (  # noqa: E402
    load_image,
    load_reference_mask_for_window_diagnostic,
)
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402
from voxtell.utils.text_embedding import wrap_with_instruction  # noqa: E402


OUT = ROOT / "outputs/image_text_interaction_mechanism_audit/qc2_semantic_trace"
CHECKPOINT = ROOT / "outputs/qwen_lora_top6_bica_stage3_from_v11/checkpoints/checkpoint_update_5000.pth"
NORMAL_METRICS = ROOT / "outputs/qwen_lora_top6_bica_stage3_from_v11/fixed30/update_05000/full_volume/update_05000/summary_tables/per_finding_metrics.csv"
PRIOR_SELECTION = ROOT / "outputs/image_text_interaction_mechanism_audit/multi_finding_magnitude/selected_findings.csv"
SELECTED_FIXED30 = ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv"
DATASET = ROOT / "data/MICCAI_challenge_dataset.json"
QWEN_MODEL = "Qwen/Qwen3-Embedding-4B"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, default=CHECKPOINT)
    parser.add_argument("--output-dir", type=Path, default=OUT)
    parser.add_argument("--normal-metrics", type=Path, default=NORMAL_METRICS)
    parser.add_argument("--count", type=int, default=10)
    return parser.parse_args()


def select_pairs(count: int = 10) -> pd.DataFrame:
    selected, entries = read_selected(
        argparse.Namespace(selected_findings=SELECTED_FIXED30, rex_json=DATASET)
    )
    pairs, _eligible, _excluded = generate_pairs(selected, entries)
    prior = pd.read_csv(PRIOR_SELECTION)
    prior_keys = set(zip(prior.case_id.astype(str), prior.finding_id.astype(int)))
    metrics = pd.read_csv(NORMAL_METRICS).rename(
        columns={"file": "case_id", "finding_idx": "finding_id", "global_dice": "original_fixed30_dice"}
    )
    metric_map = {
        (str(row.case_id), int(row.finding_id)): row
        for row in metrics.itertuples(index=False)
    }
    for pair in pairs:
        pair["from_multi_finding_magnitude"] = (
            str(pair["case_id"]), int(pair["finding_id"])
        ) in prior_keys

    chosen: list[dict[str, Any]] = []
    used: set[tuple[str, int]] = set()

    def add(candidates: list[dict[str, Any]], limit: int | None = None) -> None:
        added = 0
        for pair in candidates:
            key = (str(pair["case_id"]), int(pair["finding_id"]))
            if key in used:
                continue
            chosen.append(pair)
            used.add(key)
            added += 1
            if len(chosen) >= count or (limit is not None and added >= limit):
                return

    stable = lambda p: (str(p["case_id"]), int(p["finding_id"]), str(p["swap_type"]))
    # Reuse prior-cohort findings where a clean swap exists. Prefer upper/lower
    # for one of them so both perturbation families are represented.
    prior_upper = sorted(
        [p for p in pairs if p["from_multi_finding_magnitude"] and p["swap_type"] == "upper_lower"],
        key=stable,
    )
    prior_lateral = sorted(
        [p for p in pairs if p["from_multi_finding_magnitude"] and p["swap_type"] == "laterality"],
        key=stable,
    )
    add(prior_upper, limit=1)
    add(prior_lateral, limit=2)
    add(sorted([p for p in pairs if p["swap_type"] == "upper_lower"], key=stable), limit=3)
    add(sorted([p for p in pairs if p["swap_type"] == "laterality"], key=stable))
    if len(chosen) < 8:
        raise RuntimeError(f"Only {len(chosen)} clean unique semantic swaps available")
    chosen = chosen[:count]
    rows = []
    for order, pair in enumerate(chosen, start=1):
        key = (str(pair["case_id"]), int(pair["finding_id"]))
        metric = metric_map[key]
        rows.append({
            "selection_order": order,
            "pair_id": pair["pair_id"],
            "case_id": key[0],
            "finding_id": key[1],
            "swap_type": pair["swap_type"],
            "original_prompt": pair["original_prompt"],
            "modified_prompt": pair["swapped_prompt"],
            "original_fixed30_dice": float(metric.original_fixed30_dice),
            "original_fixed30_hit": bool(metric.global_hit),
            "gt_voxels": int(metric.gt_voxels),
            "category": str(metric.category),
            "from_multi_finding_magnitude": bool(pair["from_multi_finding_magnitude"]),
        })
    return pd.DataFrame(rows)


@torch.inference_mode()
def encode_prefixes(prompts: list[str], device: torch.device) -> dict[str, dict[str, torch.Tensor]]:
    """Re-encode each prompt through the exact frozen Qwen layers 0--29."""
    tokenizer = AutoTokenizer.from_pretrained(
        QWEN_MODEL, padding_side="left", local_files_only=True, use_fast=True
    )
    model = AutoModel.from_pretrained(
        QWEN_MODEL, local_files_only=True, torch_dtype=torch.bfloat16
    ).eval().to(device)
    model.requires_grad_(False)
    base = getattr(model, "model", model)
    n_layers = int(model.config.num_hidden_layers)
    prefix_layers = n_layers - 6
    if prefix_layers != 30 or int(model.config.hidden_size) != 2560:
        raise RuntimeError("Unexpected Qwen architecture for trained Q-C2")
    outputs: dict[str, dict[str, torch.Tensor]] = {}
    # Encode individually. This avoids any left-padding-dependent ambiguity in
    # token alignment and makes original/modified sequence lengths explicit.
    for index, prompt in enumerate(prompts, start=1):
        tokens = tokenizer(
            wrap_with_instruction([prompt]), truncation=True, max_length=512,
            return_tensors="pt",
        )
        inputs = {name: value.to(device) for name, value in tokens.items()}
        hidden = base.embed_tokens(inputs["input_ids"])
        cache_position = torch.arange(hidden.shape[1], device=device)
        position_ids = cache_position.unsqueeze(0)
        causal_mask = create_causal_mask(
            config=model.config,
            input_embeds=hidden,
            attention_mask=inputs["attention_mask"],
            cache_position=cache_position,
            past_key_values=None,
            position_ids=position_ids,
        )
        position_embeddings = base.rotary_emb(hidden, position_ids)
        for layer in base.layers[:prefix_layers]:
            hidden = layer(
                hidden,
                attention_mask=causal_mask,
                position_ids=position_ids,
                past_key_values=None,
                use_cache=False,
                cache_position=cache_position,
                position_embeddings=position_embeddings,
            )
        outputs[prompt] = {
            "hidden": hidden[0].detach().cpu().to(torch.float16).contiguous(),
            "attention_mask": torch.ones(hidden.shape[1], dtype=torch.long),
            "position_ids": torch.arange(hidden.shape[1], dtype=torch.long),
            "input_ids": inputs["input_ids"][0].detach().cpu(),
        }
        print(f"prefix {index}/{len(prompts)}", flush=True)
    del position_embeddings, causal_mask, hidden, inputs, tokens, base, model
    gc.collect()
    torch.cuda.empty_cache()
    return outputs


def diagnostic_patch(predictor: VoxTellPredictor, record: Any) -> torch.Tensor:
    image, properties = load_image(ROOT / "data/ct_rate_volumes_fixed" / record.case_id)
    data, bbox, original_shape = predictor.preprocess(image)
    target = load_reference_mask_for_window_diagnostic(
        ROOT / "data/segmentations" / record.case_id,
        1,
        tuple(original_shape),
        bbox,
        image_properties=properties,
        finding_ids=[int(record.finding_id)],
    )[0]
    patch, _target, _starts, _padding = pad_and_crop(data, target)
    return patch.to(dtype=torch.float32)


def detached(value: Any) -> torch.Tensor:
    if isinstance(value, (tuple, list)):
        value = value[0]
    if not torch.is_tensor(value):
        raise TypeError(f"Expected tensor hook output, got {type(value)}")
    return value.detach().float().cpu()


def metric(original: torch.Tensor, modified: torch.Tensor, *, token_state: bool = False) -> dict[str, Any]:
    compatible = tuple(original.shape) == tuple(modified.shape)
    if token_state and not compatible:
        # Both sequences are unpadded and fully valid. Pooling across the token
        # axis is an explicit fallback; no misaligned token positions are used.
        original_value = original.mean(dim=-2)
        modified_value = modified.mean(dim=-2)
        mode = "valid_token_mean_length_mismatch"
    else:
        original_value = original
        modified_value = modified
        mode = "aligned_full_tensor" if token_state else "full_tensor"
    left = original_value.float().reshape(-1)
    right = modified_value.float().reshape(-1)
    return {
        "relative_l2": float((right - left).norm() / left.norm().clamp_min(1e-12)),
        "cosine_similarity": float(F.cosine_similarity(left, right, dim=0)),
        "comparison_mode": mode,
        "shape_compatible": compatible,
        "original_shape": "x".join(map(str, original.shape)),
        "modified_shape": "x".join(map(str, modified.shape)),
    }


def make_predictor(device: torch.device) -> tuple[VoxTellPredictor, torch.nn.Module]:
    model_dir = OUT / "diagnostic_model"
    replace_symlink(model_dir / "plans.json", ROOT / "VoxTell/voxtell_v1.1/plans.json")
    predictor = VoxTellPredictor(
        str(model_dir), checkpoint_path=str(CHECKPOINT), device=device,
        load_text_backbone=False, text_representation="qwen", amp_dtype="bfloat16",
    )
    network = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    if tuple(network.qwen_adapter.top_layer_indices) != tuple(range(30, 36)):
        raise RuntimeError(f"Unexpected trained top-layer indices: {network.qwen_adapter.top_layer_indices}")
    return predictor, network.eval()


@torch.inference_mode()
def run_once(
    predictor: VoxTellPredictor,
    network: torch.nn.Module,
    patch: torch.Tensor,
    prefix: dict[str, torch.Tensor],
) -> dict[str, Any]:
    captured: dict[str, torch.Tensor] = {}

    def bica_pre(_module, args, _kwargs):
        captured["V0_stage3_pre_bica"] = detached(args[0])
        captured["T0_pre_bica"] = detached(args[1])

    def bica_post(_module, _args, _kwargs, output):
        captured["V1_stage3_post_bica"] = detached(output[0])
        captured["T1_post_bica"] = detached(output[1])

    def capture(name: str):
        def hook(_module, _args, output):
            captured[name] = detached(output)
        return hook

    handles = [
        network.qwen_bica_block.register_forward_pre_hook(bica_pre, with_kwargs=True),
        network.qwen_bica_block.register_forward_hook(bica_post, with_kwargs=True),
        network.encoder.stages[4].register_forward_hook(capture("V2_stage4")),
        network.encoder.stages[5].register_forward_hook(capture("V3_bottleneck")),
        network.decoder.stages[0].register_forward_hook(capture("V4_decoder_stage0")),
        network.decoder.stages[min(2, len(network.decoder.stages) - 1)].register_forward_hook(capture("V5_decoder_stage2")),
    ]
    qwen_layers = getattr(network.qwen_adapter.backbone, "model", network.qwen_adapter.backbone).layers
    for suffix_index, actual_index in enumerate(network.qwen_adapter.top_layer_indices, start=1):
        handles.append(qwen_layers[actual_index].register_forward_hook(capture(f"T{suffix_index + 1}_qwen_block{suffix_index}")))
    try:
        hidden = prefix["hidden"].unsqueeze(0).unsqueeze(0)
        mask = prefix["attention_mask"].unsqueeze(0).unsqueeze(0)
        positions = prefix["position_ids"].unsqueeze(0).unsqueeze(0)
        logits = predictor.predict_sliding_window_return_logits(
            patch,
            torch.zeros((1, 1, 2560), dtype=torch.float32),
            qwen_prefix_hidden=hidden,
            qwen_attention_mask=mask,
            qwen_position_ids=positions,
        )
        captured["T8_final_pooled"] = network.last_qwen_pooled_embedding.detach().float().cpu()
        captured["V6_probability"] = torch.sigmoid(logits.detach().float().cpu())
        audit = dict(network.last_qwen_bica_audit)
    finally:
        for handle in handles:
            handle.remove()
    required = {
        "T0_pre_bica", "T1_post_bica", "T2_qwen_block1", "T3_qwen_block2",
        "T4_qwen_block3", "T5_qwen_block4", "T6_qwen_block5", "T7_qwen_block6",
        "T8_final_pooled", "V0_stage3_pre_bica", "V1_stage3_post_bica", "V2_stage4",
        "V3_bottleneck", "V4_decoder_stage0", "V5_decoder_stage2", "V6_probability",
    }
    missing = sorted(required - set(captured))
    if missing:
        raise RuntimeError(f"Trace hooks did not fire: {missing}")
    return {"states": captured, "audit": audit}


def output_metrics(original_probability: torch.Tensor, modified_probability: torch.Tensor) -> dict[str, Any]:
    probability = metric(original_probability, modified_probability)
    original_mask = original_probability >= 0.5
    modified_mask = modified_probability >= 0.5
    intersection = int((original_mask & modified_mask).sum())
    original_volume = int(original_mask.sum())
    modified_volume = int(modified_mask.sum())
    disagreement = int((original_mask ^ modified_mask).sum())
    denominator = original_volume + modified_volume
    return {
        "probability_relative_l2": probability["relative_l2"],
        "probability_cosine_similarity": probability["cosine_similarity"],
        "voxel_disagreement": disagreement,
        "voxel_disagreement_fraction": disagreement / original_mask.numel(),
        "original_prediction_voxels": original_volume,
        "modified_prediction_voxels": modified_volume,
        "prediction_volume_change_voxels": modified_volume - original_volume,
        "prediction_volume_change_fraction": (modified_volume - original_volume) / max(original_volume, 1),
        "prediction_dice_original_vs_modified": (2 * intersection / denominator) if denominator else 1.0,
    }


def distribution(values: pd.Series, prefix: str) -> dict[str, float]:
    q1, q3 = values.quantile([0.25, 0.75])
    return {
        f"{prefix}_median": float(values.median()),
        f"{prefix}_min": float(values.min()),
        f"{prefix}_max": float(values.max()),
        f"{prefix}_q1": float(q1),
        f"{prefix}_q3": float(q3),
        f"{prefix}_iqr": float(q3 - q1),
    }


def main() -> int:
    args = parse_args()
    global OUT, CHECKPOINT, NORMAL_METRICS
    OUT = args.output_dir
    CHECKPOINT = args.checkpoint
    NORMAL_METRICS = args.normal_metrics
    OUT.mkdir(parents=True, exist_ok=True)
    selected = select_pairs(args.count)
    selected.to_csv(OUT / "selected_findings.csv", index=False)
    prompts = list(dict.fromkeys(selected.original_prompt.tolist() + selected.modified_prompt.tolist()))
    device = torch.device("cuda")
    prefixes = encode_prefixes(prompts, device)
    predictor, network = make_predictor(device)
    actual_layers = list(map(int, network.qwen_adapter.top_layer_indices))

    text_rows: list[dict[str, Any]] = []
    image_rows: list[dict[str, Any]] = []
    retention_rows: list[dict[str, Any]] = []
    output_rows: list[dict[str, Any]] = []
    text_stages = [
        "T0_pre_bica", "T1_post_bica", "T2_qwen_block1", "T3_qwen_block2",
        "T4_qwen_block3", "T5_qwen_block4", "T6_qwen_block5", "T7_qwen_block6",
        "T8_final_pooled",
    ]
    image_stages = [
        "V0_stage3_pre_bica", "V1_stage3_post_bica", "V2_stage4", "V3_bottleneck",
        "V4_decoder_stage0", "V5_decoder_stage2", "V6_probability",
    ]
    for pair_index, record in enumerate(selected.itertuples(index=False), start=1):
        patch = diagnostic_patch(predictor, record)
        original = run_once(predictor, network, patch, prefixes[record.original_prompt])
        modified = run_once(predictor, network, patch, prefixes[record.modified_prompt])
        token_lengths_compatible = (
            len(prefixes[record.original_prompt]["input_ids"])
            == len(prefixes[record.modified_prompt]["input_ids"])
        )
        changed_token_positions = (
            int((prefixes[record.original_prompt]["input_ids"] != prefixes[record.modified_prompt]["input_ids"]).sum())
            if token_lengths_compatible else None
        )
        common = {
            "pair_id": record.pair_id, "case_id": record.case_id,
            "finding_id": int(record.finding_id), "swap_type": record.swap_type,
            "original_prompt": record.original_prompt, "modified_prompt": record.modified_prompt,
            "original_fixed30_dice": float(record.original_fixed30_dice),
            "token_lengths_compatible": token_lengths_compatible,
            "changed_token_positions": changed_token_positions,
        }
        text_metrics: dict[str, dict[str, Any]] = {}
        for stage_index, stage in enumerate(text_stages):
            value = metric(
                original["states"][stage], modified["states"][stage],
                token_state=(stage != "T8_final_pooled"),
            )
            text_metrics[stage] = value
            text_rows.append({
                **common, "trace_stage": stage, "trace_order": stage_index,
                "actual_qwen_layer_index": (
                    actual_layers[stage_index - 2] if 2 <= stage_index <= 7 else None
                ),
                **value,
            })
        image_metrics: dict[str, dict[str, Any]] = {}
        for stage_index, stage in enumerate(image_stages):
            value = metric(original["states"][stage], modified["states"][stage])
            image_metrics[stage] = value
            image_rows.append({
                **common, "trace_stage": stage, "trace_order": stage_index,
                "normal_bica_r_image": float(original["audit"]["delta_v_rel_l2"]),
                "normal_bica_r_text": float(original["audit"]["delta_t_rel_l2"]),
                **value,
            })
        text_denominator = max(text_metrics["T1_post_bica"]["relative_l2"], 1e-12)
        for stage in text_stages[2:]:
            retention_rows.append({
                **common, "path": "text", "from_stage": "T1_post_bica", "to_stage": stage,
                "initial_relative_change": text_metrics["T1_post_bica"]["relative_l2"],
                "final_relative_change": text_metrics[stage]["relative_l2"],
                "retention_ratio": text_metrics[stage]["relative_l2"] / text_denominator,
            })
        image_denominator = max(image_metrics["V1_stage3_post_bica"]["relative_l2"], 1e-12)
        for stage in image_stages[2:]:
            retention_rows.append({
                **common, "path": "image", "from_stage": "V1_stage3_post_bica", "to_stage": stage,
                "initial_relative_change": image_metrics["V1_stage3_post_bica"]["relative_l2"],
                "final_relative_change": image_metrics[stage]["relative_l2"],
                "retention_ratio": image_metrics[stage]["relative_l2"] / image_denominator,
            })
        output_rows.append({
            **common,
            "text_pre_bica_relative_l2": text_metrics["T0_pre_bica"]["relative_l2"],
            "text_post_bica_relative_l2": text_metrics["T1_post_bica"]["relative_l2"],
            "final_pooled_text_relative_l2": text_metrics["T8_final_pooled"]["relative_l2"],
            "image_stage3_post_bica_relative_l2": image_metrics["V1_stage3_post_bica"]["relative_l2"],
            "image_stage4_relative_l2": image_metrics["V2_stage4"]["relative_l2"],
            **output_metrics(original["states"]["V6_probability"], modified["states"]["V6_probability"]),
        })
        print(f"trace {pair_index}/{len(selected)} {record.pair_id}", flush=True)
        del patch, original, modified
        gc.collect()
        torch.cuda.empty_cache()

    text_frame = pd.DataFrame(text_rows)
    image_frame = pd.DataFrame(image_rows)
    retention = pd.DataFrame(retention_rows)
    outputs = pd.DataFrame(output_rows)
    text_frame.to_csv(OUT / "text_layer_trace.csv", index=False)
    image_frame.to_csv(OUT / "image_stage_trace.csv", index=False)
    retention.to_csv(OUT / "retention_ratios.csv", index=False)
    outputs.to_csv(OUT / "output_sensitivity.csv", index=False)

    paths = [
        ("Text: post-BiCA -> pooled Qwen", "text", "T8_final_pooled"),
        ("Image: Stage3 post-BiCA -> Stage4", "image", "V2_stage4"),
        ("Image: Stage3 post-BiCA -> bottleneck", "image", "V3_bottleneck"),
        ("Image: Stage3 post-BiCA -> decoder stage0", "image", "V4_decoder_stage0"),
        ("Image: Stage3 post-BiCA -> decoder stage2", "image", "V5_decoder_stage2"),
        ("Image: Stage3 post-BiCA -> probability", "image", "V6_probability"),
    ]
    summary_rows = []
    for label, path, to_stage in paths:
        subset = retention[(retention.path == path) & (retention.to_stage == to_stage)]
        summary_rows.append({
            "path": label, "findings": len(subset),
            **distribution(subset.initial_relative_change, "initial_change"),
            **distribution(subset.final_relative_change, "final_change"),
            **distribution(subset.retention_ratio, "retention"),
        })
    trace_summary = pd.DataFrame(summary_rows)
    trace_summary.to_csv(OUT / "trace_summary.csv", index=False)

    text_retention = float(trace_summary.loc[trace_summary.path == "Text: post-BiCA -> pooled Qwen", "retention_median"].iloc[0])
    stage4_retention = float(trace_summary.loc[trace_summary.path == "Image: Stage3 post-BiCA -> Stage4", "retention_median"].iloc[0])
    bottleneck_retention = float(trace_summary.loc[trace_summary.path == "Image: Stage3 post-BiCA -> bottleneck", "retention_median"].iloc[0])
    output_retention = float(trace_summary.loc[trace_summary.path == "Image: Stage3 post-BiCA -> probability", "retention_median"].iloc[0])
    stage3_semantic = float(outputs.image_stage3_post_bica_relative_l2.median())
    probability_change = float(outputs.probability_relative_l2.median())
    stage3_rows = image_frame[image_frame.trace_stage == "V1_stage3_post_bica"]
    semantic_fraction_of_bica = float(
        (stage3_rows.relative_l2 / stage3_rows.normal_bica_r_image).median()
    )
    t0 = text_frame[text_frame.trace_stage == "T0_pre_bica"].set_index("pair_id").relative_l2
    t1 = text_frame[text_frame.trace_stage == "T1_post_bica"].set_index("pair_id").relative_l2
    image_to_text_semantic_ratio = float((t1 / t0).median())
    if stage3_semantic < 1e-4 or (
        semantic_fraction_of_bica < 0.1
        and abs(image_to_text_semantic_ratio - 1.0) < 0.02
    ):
        dominant = "semantic selectivity is weak already at BiCA"
        recommendation = "Test a different interaction objective/selectivity constraint before increasing Qwen depth, moving BiCA, or strengthening the decoder route."
    elif text_retention < 0.25 and text_retention < stage4_retention:
        dominant = "text-side attenuation"
        recommendation = "Test Top-12 Qwen LoRA with the same Stage3 BiCA before moving the image interaction."
    elif stage4_retention < 0.25:
        dominant = "image-side attenuation at the next encoder stage"
        recommendation = "Run a small Stage2/Stage3/Stage4 BiCA placement screen with the same Qwen top-6 LoRA."
    elif output_retention < 0.1 and text_retention >= 0.25:
        dominant = "decoder-side attenuation"
        recommendation = "Test a stronger route into the VoxTell decoder rather than increasing Qwen depth or merely moving BiCA."
    else:
        dominant = "mixed or weak attenuation"
        recommendation = "Prioritize stronger downstream conditioning; neither extra Qwen depth nor stage movement is singly supported."

    table_lines = [
        "| Path | Median initial | Median final | Median retention | IQR retention |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for row in trace_summary.itertuples(index=False):
        table_lines.append(
            f"| {row.path} | {row.initial_change_median:.6g} | {row.final_change_median:.6g} | "
            f"{row.retention_median:.6g} | {row.retention_iqr:.6g} |"
        )
    report = f"""# Q-C2 targeted semantic propagation trace

Inference-only paired trace of {len(selected)} clean semantic swaps through `{CHECKPOINT}`. Actual trained Qwen suffix layer indices: {actual_layers}. Probability metrics use a target-centred 192^3 diagnostic patch; GT chooses the crop but is never supplied to the model.

## Aggregate retention

{chr(10).join(table_lines)}

Median semantic-swap changes: Stage3 post-BiCA image={stage3_semantic:.6g}; final pooled Qwen={outputs.final_pooled_text_relative_l2.median():.6g}; probability map={probability_change:.6g}. Median original-vs-modified prediction Dice={outputs.prediction_dice_original_vs_modified.median():.6f}; median thresholded voxel disagreement={100*outputs.voxel_disagreement_fraction.median():.6g}%.

The baseline BiCA residual and semantic sensitivity are separate quantities: the branch writes about 0.7% into Stage3 under a normal prompt, but the semantic-swap-induced Stage3 difference is only {100*semantic_fraction_of_bica:.3f}% of that residual. T1/T0 semantic-change ratio is {image_to_text_semantic_ratio:.8f}, so the Image->Text BiCA update adds almost no measurable semantic modulation. The later amplification therefore does not establish that BiCA itself drives the final prompt sensitivity.

## Answers

1. Text-side post-BiCA-to-pooled retention: {text_retention:.4g}.
2. Image Stage3-to-Stage4 retention: {stage4_retention:.4g}; bottleneck retention: {bottleneck_retention:.4g}.
3. There is no text- or image-side attenuation; both paths amplify the paired difference. Dominant diagnosis: **{dominant}**.
4. The final 2560-D pooled embedding has median semantic sensitivity {outputs.final_pooled_text_relative_l2.median():.6g}.
5. The probability map has median relative change {probability_change:.6g}.

## Recommendation

{recommendation}

No training or architecture modification was launched.
"""
    (OUT / "report.md").write_text(report)
    status = {
        "status": "complete", "checkpoint": str(CHECKPOINT), "selected_findings": len(selected),
        "actual_qwen_suffix_layers": actual_layers, "dominant_attenuation": dominant,
        "semantic_fraction_of_bica_residual": semantic_fraction_of_bica,
        "image_to_text_semantic_change_ratio_t1_over_t0": image_to_text_semantic_ratio,
        "recommendation": recommendation,
    }
    (OUT / "audit_summary.json").write_text(json.dumps(status, indent=2) + "\n")
    print(json.dumps(status, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
