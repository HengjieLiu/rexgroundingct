#!/usr/bin/env python3
"""Compare lower-LR group-balanced treatment with its strict alpha-zero control."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


POLICIES = ("raw", "whole10", "semantic_v1")
SUBGROUPS = (
    "all",
    "A_explicit_exact_lobe",
    "B_ambiguous_lobe",
    "C_laterality_only",
    "DE_whole_lung_fallback",
    "explicit_lobe_parser_defined",
)


def markdown_table(frame: pd.DataFrame) -> str:
    shown = frame.copy()
    for column in shown.select_dtypes(include=[np.number]).columns:
        shown[column] = shown[column].map(
            lambda value: "" if pd.isna(value) else f"{float(value):.6f}"
        )
    lines = [
        "| " + " | ".join(map(str, shown.columns)) + " |",
        "| " + " | ".join("---" for _ in shown.columns) + " |",
    ]
    lines.extend(
        "| " + " | ".join(map(str, row)) + " |"
        for row in shown.itertuples(index=False, name=None)
    )
    return "\n".join(lines)


def load_json(path: Path) -> dict:
    return json.loads(path.read_text())


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control-dir", type=Path, required=True)
    parser.add_argument("--treatment-dir", type=Path, required=True)
    parser.add_argument("--update", type=int, default=100)
    parser.add_argument("--combined-summary", type=Path, required=True)
    parser.add_argument(
        "--previous-original-lr-control",
        type=Path,
        default=Path(
            "outputs/groupA_exact_lobe_outside_fp_weight_v1_allcat1over1_step6000_lambda0_control"
        ),
    )
    args = parser.parse_args()

    relative = Path(f"subset30_eval_update{args.update}/subset_metrics.csv")
    control = pd.read_csv(args.control_dir / relative)
    treatment = pd.read_csv(args.treatment_dir / relative)
    wanted = lambda frame: frame[
        frame["variant"].isin(POLICIES) & frame["subgroup"].isin(SUBGROUPS)
    ].copy()
    control = wanted(control)
    treatment = wanted(treatment)
    merged = treatment.merge(
        control,
        on=["subgroup", "variant"],
        suffixes=("_treatment", "_control"),
        validate="one_to_one",
    )
    merged["delta_dice_treatment_vs_control"] = (
        merged["mean_dice_treatment"] - merged["mean_dice_control"]
    )
    merged["delta_hit_treatment_vs_control"] = (
        merged["hit_count_treatment"] - merged["hit_count_control"]
    )
    merged["volume_ratio_treatment_vs_control"] = (
        merged["mean_predicted_volume_mm3_treatment"]
        / merged["mean_predicted_volume_mm3_control"].replace(0, np.nan)
    )
    table_columns = [
        "subgroup",
        "variant",
        "findings_treatment",
        "mean_dice_control",
        "mean_dice_treatment",
        "delta_dice_treatment_vs_control",
        "hit_count_control",
        "hit_count_treatment",
        "delta_hit_treatment_vs_control",
        "predicted_volume_ratio_vs_starting_control",
        "predicted_volume_ratio_vs_starting_treatment",
        "volume_ratio_treatment_vs_control",
    ]
    comparison = merged[table_columns].sort_values(["subgroup", "variant"])
    comparison.to_csv(
        args.treatment_dir / f"matched_pair_comparison_update{args.update}.csv",
        index=False,
    )
    comparison.to_csv(
        args.control_dir / f"matched_pair_comparison_update{args.update}.csv",
        index=False,
    )

    indexed = merged.set_index(["subgroup", "variant"])
    all_semantic = indexed.loc[("all", "semantic_v1")]
    group_a_semantic = indexed.loc[("A_explicit_exact_lobe", "semantic_v1")]
    group_b_semantic = indexed.loc[("B_ambiguous_lobe", "semantic_v1")]
    de_semantic = indexed.loc[("DE_whole_lung_fallback", "semantic_v1")]
    semantic_gain = float(all_semantic["delta_dice_treatment_vs_control"])
    semantic_hit_delta = int(all_semantic["delta_hit_treatment_vs_control"])
    semantic_volume_ratio = float(all_semantic["volume_ratio_treatment_vs_control"])
    group_a_gain = float(group_a_semantic["delta_dice_treatment_vs_control"])
    group_b_gain = float(group_b_semantic["delta_dice_treatment_vs_control"])
    de_gain = float(de_semantic["delta_dice_treatment_vs_control"])
    de_volume_ratio = float(de_semantic["volume_ratio_treatment_vs_control"])

    control_diag = load_json(args.control_dir / "training_diagnostics.json")
    treatment_diag = load_json(args.treatment_dir / "training_diagnostics.json")
    control_frozen = load_json(args.control_dir / "frozen_weight_check.json")
    treatment_frozen = load_json(args.treatment_dir / "frozen_weight_check.json")
    control_patch = control_diag.get("patch_validation", {})
    treatment_patch = treatment_diag.get("patch_validation", {})
    control_patch_pred = control_patch.get("val_pred_voxels_update100")
    treatment_patch_pred = treatment_patch.get("val_pred_voxels_update100")
    patch_pred_ratio = (
        treatment_patch_pred / control_patch_pred
        if control_patch_pred and treatment_patch_pred is not None
        else None
    )

    safety = {
        "semantic_dice_not_meaningfully_lower_than_control": semantic_gain >= -0.0005,
        "semantic_hit_not_lower_than_control": semantic_hit_delta >= 0,
        "semantic_volume_ratio_0p95_to_1p05": 0.95 <= semantic_volume_ratio <= 1.05,
        "group_B_delta_at_least_minus_0p005": group_b_gain >= -0.005,
        "DE_delta_at_least_minus_0p005": de_gain >= -0.005,
        "DE_volume_ratio_at_least_0p95": de_volume_ratio >= 0.95,
        "control_no_nonfinite": control_diag.get("nonfinite_total_loss_rows", 1) == 0,
        "treatment_no_nonfinite": treatment_diag.get("nonfinite_total_loss_rows", 1) == 0,
        "control_encoder_exactly_frozen": bool(
            control_frozen.get("encoder_weight_delta_exact_zero")
        ),
        "treatment_encoder_exactly_frozen": bool(
            treatment_frozen.get("encoder_weight_delta_exact_zero")
        ),
        "treatment_patch_dice_not_collapsed": (
            treatment_patch.get("val_dice_delta") is None
            or treatment_patch["val_dice_delta"] >= -0.05
        ),
        "treatment_patch_volume_vs_control_0p80_to_1p20": (
            patch_pred_ratio is None or 0.80 <= patch_pred_ratio <= 1.20
        ),
    }
    safe = all(safety.values())
    if not safe:
        classification = "EARLY_NO_GO_UNSAFE"
        recommend_update250 = False
    elif semantic_gain >= 0.0015 and group_a_gain > 0:
        classification = "EARLY_POSITIVE_CONSIDER_UPDATE250"
        recommend_update250 = True
    else:
        classification = "SAFE_UNDERPOWERED_CONSIDER_UPDATE250"
        recommend_update250 = True

    old_control_comparison = None
    old_metrics_path = (
        args.previous_original_lr_control
        / f"subset30_eval_update{args.update}"
        / "subset_metrics.csv"
    )
    if old_metrics_path.is_file():
        old = wanted(pd.read_csv(old_metrics_path)).set_index(["subgroup", "variant"])
        lower = control.set_index(["subgroup", "variant"])
        rows = []
        for policy in POLICIES:
            old_row = old.loc[("all", policy)]
            lower_row = lower.loc[("all", policy)]
            rows.append(
                {
                    "policy": policy,
                    "original_lr_alpha0_volume_ratio_vs_starting": float(
                        old_row["predicted_volume_ratio_vs_starting"]
                    ),
                    "lower_lr_frozen_alpha0_volume_ratio_vs_starting": float(
                        lower_row["predicted_volume_ratio_vs_starting"]
                    ),
                    "lower_minus_original_volume_ratio": float(
                        lower_row["predicted_volume_ratio_vs_starting"]
                        - old_row["predicted_volume_ratio_vs_starting"]
                    ),
                    "original_lr_alpha0_dice": float(old_row["mean_dice"]),
                    "lower_lr_frozen_alpha0_dice": float(lower_row["mean_dice"]),
                }
            )
        old_control_comparison = rows

    counts = (
        treatment[treatment["variant"] == "raw"]
        .set_index("subgroup")["findings"]
        .reindex(SUBGROUPS)
        .dropna()
        .astype(int)
        .to_dict()
    )
    result = {
        "status": "stage1_update100_reviewed" if args.update == 100 else "update250_reviewed",
        "update": args.update,
        "classification": classification,
        "primary_semantic_v1_delta_treatment_vs_control": semantic_gain,
        "primary_semantic_v1_hit_delta_treatment_vs_control": semantic_hit_delta,
        "primary_semantic_v1_volume_ratio_treatment_vs_control": semantic_volume_ratio,
        "group_A_semantic_v1_delta_treatment_vs_control": group_a_gain,
        "group_B_semantic_v1_delta_treatment_vs_control": group_b_gain,
        "DE_semantic_v1_delta_treatment_vs_control": de_gain,
        "patch_predicted_volume_ratio_treatment_vs_control": patch_pred_ratio,
        "safety": safety,
        "parser_counts_fixed30": counts,
        "control_training_diagnostics": control_diag,
        "treatment_training_diagnostics": treatment_diag,
        "lower_lr_control_vs_previous_original_lr_control": old_control_comparison,
        "recommend_update250": recommend_update250 if args.update == 100 else False,
        "update250_auto_submitted": False,
        "full381_auto_submitted": False,
        "next_action": (
            "Stop; do not continue or run full381."
            if classification == "EARLY_NO_GO_UNSAFE"
            else "Prepare/recommend matched continuation to update250; await explicit user approval."
            if args.update == 100
            else "Apply update250 GO_TO_FULL381 criteria; full381 still requires explicit approval."
        ),
    }
    for root, role in ((args.control_dir, "control"), (args.treatment_dir, "treatment")):
        payload = {"pair_role": role, **result}
        (root / "go_no_go.json").write_text(json.dumps(payload, indent=2) + "\n")

    old_table = (
        markdown_table(pd.DataFrame(old_control_comparison))
        if old_control_comparison
        else "Previous original-LR control metrics were unavailable."
    )
    report = f"""# Lower-LR frozen-encoder semantic-v1 group-balanced matched pilot

## Decision: {classification}

The primary endpoint is treatment minus its strict alpha-zero control at the
same update. Both runs use the same semantic-v1 group-balanced code path,
checkpoint, seed, sampler, optimizer, lower LR, frozen encoder, and evaluation.
Only alpha differs (0.1 versus 0.0).

## Fixed-30 parser counts

```json
{json.dumps(counts, indent=2)}
```

## Matched results at update {args.update}

{markdown_table(comparison)}

## Safety criteria

```json
{json.dumps(safety, indent=2)}
```

## Training diagnostics

Control:

```json
{json.dumps(control_diag, indent=2)}
```

Treatment:

```json
{json.dumps(treatment_diag, indent=2)}
```

## Lower-LR control versus previous original-LR alpha-zero control

{old_table}

## Interpretation

Primary Semantic-v1 treatment-minus-control Dice is {semantic_gain:+.6f}; HIT
delta is {semantic_hit_delta:+d}; volume ratio is {semantic_volume_ratio:.6f}.
The update100 endpoint is a safety/activation check. A safe small effect is not
declared ineffective and supports considering the already-prepared matched
continuation to update250. No update250 or full-381 job was auto-submitted.
"""
    for root in (args.control_dir, args.treatment_dir):
        (root / "REPORT.md").write_text(report)

    combined = {}
    if args.combined_summary.is_file():
        combined = load_json(args.combined_summary)
    combined.update(result)
    combined["control_dir"] = str(args.control_dir)
    combined["treatment_dir"] = str(args.treatment_dir)
    args.combined_summary.write_text(json.dumps(combined, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
