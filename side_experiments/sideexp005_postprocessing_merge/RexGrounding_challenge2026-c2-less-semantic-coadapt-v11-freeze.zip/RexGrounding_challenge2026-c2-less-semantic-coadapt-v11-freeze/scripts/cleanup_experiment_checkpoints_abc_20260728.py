#!/usr/bin/env python3
"""Audit and execute the approved A-C checkpoint cleanup from 2026-07-28.

Only checkpoint-like files inside the explicitly listed experiment directories
are eligible. Non-checkpoint experiment records are inventoried and preserved.
Run without --execute to write/refresh the dry-run manifest. Execution requires
an exactly matching dry-run manifest.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import tempfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


EXPECTED_ROOT = Path(".")
OUTPUTS = EXPECTED_ROOT / "outputs"
MANIFEST = OUTPUTS / "checkpoint_cleanup_abc_20260728_manifest.json"
EXECUTION = OUTPUTS / "checkpoint_cleanup_abc_20260728_execution.json"

A_DIRS = [
    "outputs/zoom_out_256_matched",
    "outputs/s3d_matched_continue_from_weakdiffuse_control_step1000",
    "outputs/s3_diffuse_coverage_tv_matched_from_s3d_step400",
    "outputs/s3d_multiscale_2b2c_train_nowrong_from_adaptive_step600",
    "outputs/s3_selective_categories_matched_from_control_step6000_2h100",
    "outputs/anchor85_hardneg70_no_topk",
    "outputs/loss_adaptive_cat_tversky_short",
    "outputs/voxtell_rex_full_preprocessed_from_lr1e6_step2000_nnunet_aug_lr1e6_3000steps",
    "outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500",
    "outputs/voxtell_rex_hard_negative_triplet_preprocessed_4l40s_to4000",
    "outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000",
    "outputs/voxtell_rex_patch_presence_hardneg_from_baseline_4l40s_2000steps",
    "outputs/dual_s3_multifov",
    "outputs/prompt_residual_adapter_best_s3_frozen",
]

B_DIRS = [
    "outputs/native_response_attention_minipilot_v1",
    "outputs/anchor85_hardneg70_hybrid75_dp_192",
    "outputs/category_prompt_experiment",
    "outputs/voxtell_rex_anchor85_loss_focal_tversky",
    "outputs/voxtell_rex_anchor85_loss_unified_focal",
    "outputs/prompt_residual_adapter_s3_allcategory_1over1_frozen",
    "outputs/prompt_residual_adapter_s3_multiscale_2b2c_frozen",
    "outputs/colipri_dual_preprocess_residual",
]

C_DIRS = [
    "outputs/hnt_spatial_empty_safe_weaktopk",
    "outputs/hardneg70_catbalanced_aggressive_twopos_noattention",
    "outputs/s3_v2_pooled_align_2b2c_from_adaptive_step600",
    "outputs/s3_v2_pooled_align_2c_only_from_adaptive_step600",
    "outputs/s3_v2_pooled_align_fullres_sampled_2c_only_from_adaptive_step600",
    "outputs/s3d_multiscale_all_train_nowrong_from_adaptive_step600",
    "outputs/s3_anchor_to_negative_softplus_from_control_step6000_2h100",
    "outputs/s3_joint_residual_fusion_from_control_step6000",
]

APPROVED_ALIAS_DIRS = [
    "outputs/voxtell_rex_anchor85_loss_focal_tversky_step3000_model",
    "outputs/voxtell_rex_anchor85_loss_unified_focal_step3000_model",
]

KEEP = [
    "outputs/zoom_out_256_matched/s3_allcategory_1over1_from_update3250_10000microsteps_patchval500/checkpoints/checkpoint_best_val_dice_step_6000.pth",
    "outputs/zoom_out_256_matched/control_highlr_continue_10000microsteps_patchval500/from_update3250_add10000microsteps/checkpoints/checkpoint_update_3750.pth",
    "outputs/s3d_matched_continue_from_weakdiffuse_control_step1000/control_2b2c_multiscale_to_step6000/checkpoints/checkpoint_step_6000.pth",
    "outputs/s3d_matched_continue_from_weakdiffuse_control_step1000/allcat_1over1_only_to_step6000/checkpoints/checkpoint_step_6000.pth",
    "outputs/s3_diffuse_coverage_tv_matched_from_s3d_step400/weakdiffuse_gate_control/checkpoints/checkpoint_step_1000.pth",
    "outputs/s3d_multiscale_2b2c_train_nowrong_from_adaptive_step600/checkpoints/checkpoint_step_400.pth",
    "outputs/s3_selective_categories_matched_from_control_step6000_2h100/selective_2a_weak1c1d_3000/checkpoints/checkpoint_step_2500.pth",
    "outputs/anchor85_hardneg70_no_topk/checkpoints/checkpoint_step_500.pth",
    "outputs/loss_adaptive_cat_tversky_short/checkpoints/checkpoint_step_600.pth",
    "outputs/voxtell_rex_full_preprocessed_from_lr1e6_step2000_nnunet_aug_lr1e6_3000steps/checkpoints/checkpoint_step_500.pth",
    "outputs/voxtell_rex_from_best_step500_noaug_weightedbce_r10_2pos1neg_lr1e6_to2500/checkpoints/checkpoint_step_2000.pth",
    "outputs/voxtell_rex_hard_negative_triplet_preprocessed_4l40s_to4000/checkpoints/checkpoint_step_4000.pth",
    "outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000/checkpoints/checkpoint_best_val_dice_step_3800.pth",
    "outputs/voxtell_rex_patch_presence_hardneg_from_baseline_4l40s_2000steps/checkpoints/checkpoint_step_1000.pth",
    "outputs/voxtell_rex_patch_presence_hardneg_from_baseline_4l40s_2000steps/checkpoints/checkpoint_best_val_positive_dice_step_1900.pth",
    "outputs/dual_s3_multifov/from_s3_step6000_update1500_focal96_bf16_2h100_to_update6500/checkpoints/checkpoint_update_2000.pth",
    "outputs/prompt_residual_adapter_best_s3_frozen/checkpoints/prompt_adapter_update_100.pth",
]

RECORD_SUFFIXES = {".json", ".jsonl", ".csv", ".md", ".yaml", ".yml", ".txt"}
CHECKPOINT_SUFFIXES = {".pth", ".pt", ".ckpt"}


def relative(path: Path) -> str:
    return str(path.relative_to(EXPECTED_ROOT))


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        dir=path.parent, prefix=f".{path.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(fd, "w") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(tmp_name, path)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def is_checkpoint(path: Path) -> bool:
    if path.suffix.lower() not in CHECKPOINT_SUFFIXES:
        return False
    lowered = path.name.lower()
    return (
        "checkpoint" in lowered
        or "adapter" in lowered
        or "checkpoints" in path.parts
        or "fold_0" in path.parts
    )


def regular_checkpoints(directory: Path) -> list[Path]:
    found = []
    for path in directory.rglob("*"):
        if path.is_symlink():
            continue
        if path.is_file() and is_checkpoint(path):
            found.append(path)
    return sorted(found)


def record_inventory(directory: Path) -> dict:
    count = 0
    size = 0
    names = Counter()
    for path in directory.rglob("*"):
        if path.is_symlink() or not path.is_file():
            continue
        if path.suffix.lower() in RECORD_SUFFIXES:
            stat = path.stat()
            count += 1
            size += stat.st_size
            names[path.suffix.lower()] += 1
    return {
        "file_count": count,
        "bytes": size,
        "suffix_counts": dict(sorted(names.items())),
    }


def current_jobs() -> list[dict]:
    result = subprocess.run(
        ["squeue", "-u", os.environ.get("USER", ""), "-h", "-o", "%i|%T|%j"],
        check=True,
        text=True,
        capture_output=True,
    )
    jobs = []
    for line in result.stdout.splitlines():
        if not line:
            continue
        job_id, state, name = line.split("|", 2)
        jobs.append({"job_id": job_id, "state": state, "name": name})
    return jobs


def candidate_state() -> dict:
    if Path.cwd().resolve() != EXPECTED_ROOT:
        raise RuntimeError(f"must run from {EXPECTED_ROOT}, got {Path.cwd().resolve()}")

    groups = {"A": A_DIRS, "B": B_DIRS, "C": C_DIRS}
    keep_abs = {(EXPECTED_ROOT / path).resolve() for path in KEEP}
    keep_records = []
    for path in sorted(keep_abs):
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"protected checkpoint missing or not regular: {path}")
        stat = path.stat()
        keep_records.append(
            {
                "path": relative(path),
                "bytes": stat.st_size,
                "mtime_ns": stat.st_mtime_ns,
            }
        )

    candidates = []
    records = {}
    seen: set[Path] = set()
    declared_dirs: set[Path] = set()
    for group, rel_dirs in groups.items():
        for rel_dir in rel_dirs:
            directory = (EXPECTED_ROOT / rel_dir).resolve()
            declared_dirs.add(directory)
            if not directory.is_dir():
                raise RuntimeError(f"declared directory missing: {directory}")
            records[rel_dir] = record_inventory(directory)
            for path in regular_checkpoints(directory):
                resolved = path.resolve()
                if group == "A" and resolved in keep_abs:
                    continue
                if resolved in keep_abs:
                    raise RuntimeError(
                        f"protected checkpoint unexpectedly selected in {group}: {path}"
                    )
                if resolved in seen:
                    raise RuntimeError(f"duplicate candidate: {path}")
                seen.add(resolved)
                stat = path.stat()
                candidates.append(
                    {
                        "group": group,
                        "path": relative(path),
                        "bytes": stat.st_size,
                        "mtime_ns": stat.st_mtime_ns,
                    }
                )

    approved_alias_dirs = {
        (EXPECTED_ROOT / rel_dir).resolve() for rel_dir in APPROVED_ALIAS_DIRS
    }
    for directory in approved_alias_dirs:
        if not directory.is_dir():
            raise RuntimeError(f"approved alias directory missing: {directory}")
        rel_dir = relative(directory)
        records[rel_dir] = record_inventory(directory)

    # Find aliases anywhere in outputs. Aliases inside declared A-C directories
    # are deleted with their target; aliases outside the approved scope block.
    candidate_abs = {(EXPECTED_ROOT / item["path"]).resolve() for item in candidates}
    aliases = []
    external_aliases = []
    for directory, dirnames, filenames in os.walk(OUTPUTS, followlinks=False):
        for name in [*dirnames, *filenames]:
            path = Path(directory) / name
            if not path.is_symlink():
                continue
            target = (path.parent / os.readlink(path)).resolve(strict=False)
            if target not in candidate_abs:
                continue
            inside = any(
                path == declared or path.is_relative_to(declared)
                for declared in declared_dirs | approved_alias_dirs
            )
            entry = {
                "path": relative(path),
                "target": relative(target),
            }
            if inside:
                aliases.append(entry)
            else:
                external_aliases.append(entry)
    if external_aliases:
        formatted = "\n".join(
            f"{item['path']} -> {item['target']}" for item in external_aliases
        )
        raise RuntimeError(f"external aliases block cleanup:\n{formatted}")

    candidates.sort(key=lambda item: item["path"])
    aliases.sort(key=lambda item: item["path"])
    totals = Counter()
    for item in candidates:
        totals[f"{item['group']}_files"] += 1
        totals[f"{item['group']}_bytes"] += item["bytes"]
        totals["files"] += 1
        totals["bytes"] += item["bytes"]

    return {
        "schema_version": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "root": str(EXPECTED_ROOT),
        "approved_scope": {
            "A": A_DIRS,
            "B": B_DIRS,
            "C": C_DIRS,
            "alias_dirs": APPROVED_ALIAS_DIRS,
        },
        "protected_checkpoints": keep_records,
        "record_inventory": records,
        "candidates": candidates,
        "aliases_to_remove": aliases,
        "totals": dict(totals),
        "current_jobs": current_jobs(),
    }


def stable_payload(payload: dict) -> dict:
    return {
        "root": payload["root"],
        "approved_scope": payload["approved_scope"],
        "protected_checkpoints": payload["protected_checkpoints"],
        "record_inventory": payload["record_inventory"],
        "candidates": payload["candidates"],
        "aliases_to_remove": payload["aliases_to_remove"],
        "totals": payload["totals"],
    }


def execute(state: dict) -> None:
    if not MANIFEST.is_file():
        raise RuntimeError(f"dry-run manifest is required: {MANIFEST}")
    saved = json.loads(MANIFEST.read_text())
    if stable_payload(saved) != stable_payload(state):
        raise RuntimeError("filesystem state differs from dry-run manifest; aborting")

    deleted = []
    deleted_aliases = []
    errors = []
    for item in state["candidates"]:
        path = EXPECTED_ROOT / item["path"]
        try:
            stat = path.stat()
            if stat.st_size != item["bytes"] or stat.st_mtime_ns != item["mtime_ns"]:
                raise RuntimeError("size or mtime changed after dry run")
            path.unlink()
            deleted.append(item)
        except Exception as exc:  # preserve partial execution evidence
            errors.append({"path": item["path"], "error": repr(exc)})
            break

    if not errors:
        for item in state["aliases_to_remove"]:
            path = EXPECTED_ROOT / item["path"]
            try:
                if not path.is_symlink():
                    raise RuntimeError("planned alias is no longer a symlink")
                path.unlink()
                deleted_aliases.append(item)
            except Exception as exc:
                errors.append({"path": item["path"], "error": repr(exc)})
                break

    record_after = {
        rel_dir: record_inventory(EXPECTED_ROOT / rel_dir)
        for rel_dir in sorted(state["record_inventory"])
    }
    record_mismatches = {
        rel_dir: {
            "before": state["record_inventory"][rel_dir],
            "after": after,
        }
        for rel_dir, after in record_after.items()
        if after != state["record_inventory"][rel_dir]
    }
    protected_after = []
    for item in state["protected_checkpoints"]:
        path = EXPECTED_ROOT / item["path"]
        ok = path.is_file() and not path.is_symlink()
        if ok:
            stat = path.stat()
            ok = stat.st_size == item["bytes"] and stat.st_mtime_ns == item["mtime_ns"]
        protected_after.append({"path": item["path"], "ok": ok})

    execution = {
        "schema_version": 1,
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "manifest": relative(MANIFEST),
        "deleted": deleted,
        "deleted_aliases": deleted_aliases,
        "deleted_files": len(deleted),
        "deleted_bytes": sum(item["bytes"] for item in deleted),
        "errors": errors,
        "record_inventory_after": record_after,
        "record_mismatches": record_mismatches,
        "protected_after": protected_after,
        "current_jobs_after": current_jobs(),
    }
    atomic_json(EXECUTION, execution)
    if errors:
        raise RuntimeError(f"cleanup stopped after {len(deleted)} files: {errors[0]}")
    if record_mismatches:
        raise RuntimeError(f"experiment records changed: {record_mismatches}")
    failed_protected = [item for item in protected_after if not item["ok"]]
    if failed_protected:
        raise RuntimeError(f"protected checkpoint verification failed: {failed_protected}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()

    state = candidate_state()
    if args.execute:
        execute(state)
        print(
            f"deleted {state['totals']['files']} checkpoint files "
            f"({state['totals']['bytes'] / 1073741824:.3f} GiB)"
        )
        print(f"execution record: {EXECUTION}")
    else:
        atomic_json(MANIFEST, state)
        print(
            f"dry run: {state['totals']['files']} checkpoint files "
            f"({state['totals']['bytes'] / 1073741824:.3f} GiB)"
        )
        for group in "ABC":
            print(
                f"{group}: {state['totals'][f'{group}_files']} files, "
                f"{state['totals'][f'{group}_bytes'] / 1073741824:.3f} GiB"
            )
        print(f"protected checkpoints: {len(state['protected_checkpoints'])}")
        print(f"aliases to remove: {len(state['aliases_to_remove'])}")
        print(f"manifest: {MANIFEST}")


if __name__ == "__main__":
    main()
