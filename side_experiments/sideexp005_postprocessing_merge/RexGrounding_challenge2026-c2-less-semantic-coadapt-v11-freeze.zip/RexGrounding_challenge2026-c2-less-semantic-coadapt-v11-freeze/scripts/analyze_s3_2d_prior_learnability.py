#!/usr/bin/env python3
"""Preflight, continuation gates, aggregation, and reporting for prior learnability."""

from __future__ import annotations

import argparse
import json
import math
import shutil
import subprocess
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def read_json(path: Path) -> Any:
    return json.loads(path.read_text())


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, default=str) + "\n")


def read_history(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def preflight(control: Path, treatment: Path, comparison: Path) -> None:
    c = read_history(control / "preflight/preflight_history.jsonl")
    t = read_history(treatment / "preflight/preflight_history.jsonl")
    cs = read_json(control / "preflight/preflight_status.json")
    ts = read_json(treatment / "preflight/preflight_status.json")
    sequences_equal = [row["micro_sequence"] for row in c] == [row["micro_sequence"] for row in t]
    finite = all(
        math.isfinite(float(row[key]))
        for rows in (c, t)
        for row in rows
        for key in ("total_prior_loss", "prior_head_gradient_norm", "final_convolution_gradient_norm")
    )
    cap_ok = all(
        component["weight"] <= 4.0
        for row in t
        for component in row.get("component_audit", [])
    )
    nonzero = all(row["prior_head_gradient_norm"] > 0 and row["final_convolution_gradient_norm"] > 0 for rows in (c, t) for row in rows)
    last10 = t[-10:]
    extent = float(np.mean([row["extent_loss"] for row in last10]))
    loc = float(np.mean([row["weighted_localization_loss"] for row in last10]))
    bg = float(np.mean([row["weighted_hard_background_loss"] for row in last10]))
    localization_weight = 0.05
    hard_bg_weight = 0.10
    adjustments = []
    if loc > 0.5 * extent:
        localization_weight *= 0.5
        adjustments.append("halved localization coefficient: weighted term >50% of L_extent")
    if bg > 0.5 * extent:
        hard_bg_weight *= 0.5
        adjustments.append("halved hard-background coefficient: weighted term >50% of L_extent")
    # The permitted low-side adjustment also requires an independently negligible
    # gradient.  This preflight records only the joint prior gradient, so it does
    # not infer that condition and conservatively makes no low-side adjustment.
    checks = {
        "exactly_20_updates_each": len(c) == 20 and len(t) == 20,
        "matched_micro_sequence": sequences_equal,
        "finite_losses_and_gradients": finite,
        "nonzero_prior_and_final_conv_gradients": nonzero,
        "inverse_size_weight_cap_respected": cap_ok,
        "frozen_s3_unchanged_control": bool(cs["frozen_s3_unchanged"]),
        "frozen_s3_unchanged_treatment": bool(ts["frozen_s3_unchanged"]),
        "same_frozen_s3_digest": cs["frozen_s3_digest_before"] == ts["frozen_s3_digest_before"],
    }
    payload = {
        "status": "pass" if all(checks.values()) else "fail",
        "checks": checks,
        "treatment_last10": {
            "extent": extent,
            "weighted_localization": loc,
            "weighted_localization_over_extent": loc / max(extent, 1e-12),
            "weighted_hard_background": bg,
            "weighted_hard_background_over_extent": bg / max(extent, 1e-12),
        },
        "one_allowed_adjustment": adjustments or ["none"],
        "selected_localization_weight": localization_weight,
        "selected_hard_background_weight": hard_bg_weight,
        "formal_runs_restart_from_update_zero": True,
        "updates_1_5_10_20": {
            arm: [row for row in rows if row["update"] in {1, 5, 10, 20}]
            for arm, rows in (("control", c), ("treatment", t))
        },
    }
    write_json(comparison / "preflight_results.json", payload)
    write_json(comparison / "preflight_decision.json", payload)
    if payload["status"] != "pass":
        raise SystemExit("Preflight safety/matching gate failed")


def eval_paths(run: Path, cohort: str, update: int) -> tuple[Path, Path, Path]:
    root = run / "evaluation" / f"{cohort}_update_{update}"
    return root / "per_finding_prior_metrics.csv", root / "per_component_prior_metrics.csv", root / "aggregate_prior_metrics.json"


def gate(control: Path, treatment: Path, comparison: Path, update: int, cohort: str = "target25") -> dict[str, Any]:
    c_path, cc_path, ca_path = eval_paths(control, cohort, update)
    t_path, tc_path, ta_path = eval_paths(treatment, cohort, update)
    c = pd.read_csv(c_path)
    t = pd.read_csv(t_path)
    tc = pd.read_csv(tc_path)
    ca = read_json(ca_path)["all"]
    ta = read_json(ta_path)["all"]
    merged = t.merge(c, on=["case_id", "finding_id"], suffixes=("_T", "_C"))
    peak_gain = float(ta["peak_inside_gt"] - ca["peak_inside_gt"])
    component_gain = float(ta["topk_component_recall"] - ca["topk_component_recall"])
    improved_coverage_findings = int(
        ((merged["components_covered_at_0.10_T"] - merged["components_covered_at_0.10_C"]) > 0).sum()
    )
    gap_required = max(0.005, 0.10 * float(ta["Q_mean_outside_support"]))
    false_limit = max(
        25.0,
        3.0 * float(ca["false_prior_component_count_at_0.10"]) + 10.0,
    )
    checks = {
        "voxel_auroc_at_least_0.60": float(ta["voxel_auroc"]) >= 0.60,
        "inside_mean_meaningfully_above_outside": float(ta["inside_minus_outside_gap"]) >= gap_required,
        "auprc_prevalence_ratio_at_least_2": float(ta["auprc_over_prevalence"]) >= 2.0,
        "auprc_prevalence_ratio_better_than_control": float(ta["auprc_over_prevalence"]) > float(ca["auprc_over_prevalence"]),
        "peak_or_component_recall_gain_at_least_10pp": peak_gain >= 0.10 or component_gain >= 0.10,
        "coverage_nonzero_in_multiple_findings": int((t["components_covered_at_0.10"] > 0).sum()) >= 2,
        "coverage_improvement_not_one_finding": improved_coverage_findings >= 2,
        "outside_probability_not_broadly_high": float(ta["Q_mean_outside_support"]) < 0.10 and float(ta["Q_mean"]) < 0.25,
        "false_component_burden_not_catastrophic": float(ta["false_prior_component_count_at_0.10"]) <= false_limit,
    }
    passed = all(checks.values())
    payload = {
        "status": "CONTINUE" if passed else "NO-GO",
        "update": update,
        "checks": checks,
        "thresholds": {"meaningful_gap_required": gap_required, "false_component_limit": false_limit},
        "control": ca,
        "treatment": ta,
        "treatment_minus_control": {
            "voxel_auroc": float(ta["voxel_auroc"] - ca["voxel_auroc"]),
            "auprc_over_prevalence": float(ta["auprc_over_prevalence"] - ca["auprc_over_prevalence"]),
            "peak_inside_gt": peak_gain,
            "topk_component_recall": component_gain,
        },
        "treatment_component_count": int(len(tc)),
        "improved_coverage_findings": improved_coverage_findings,
    }
    name = "continuation_decision.json" if update == 300 else "update500_prior_quality_decision.json"
    write_json(comparison / name, payload)
    return payload


def create_visualizations(control: Path, treatment: Path, comparison: Path, update: int = 300) -> None:
    c_path, _, _ = eval_paths(control, "target25", update)
    t_path, _, _ = eval_paths(treatment, "target25", update)
    c = pd.read_csv(c_path)
    t = pd.read_csv(t_path)
    merged = t.merge(c, on=["case_id", "finding_id"], suffixes=("_T", "_C"))
    merged["localization_gain"] = merged["gt_sized_topk_precision_T"] - merged["gt_sized_topk_precision_C"]
    merged["false_burden"] = merged["false_prior_component_voxels_at_0.10_T"]
    candidates: list[tuple[str, pd.Series, bool]] = []
    candidates.append(("best_treatment_localization_gain", merged.sort_values("localization_gain", ascending=False).iloc[0], False))
    success = merged[(merged["peak_inside_5mm_support_T"] == True) & (merged["peak_inside_5mm_support_C"] == False)]  # noqa: E712
    candidates.append(("treatment_success_control_collapse", (success if len(success) else merged).sort_values("localization_gain", ascending=False).iloc[0], False))
    failures = merged[(merged["peak_inside_5mm_support_T"] == False) & (merged["peak_inside_5mm_support_C"] == False)]  # noqa: E712
    candidates.append(("persistent_failure", (failures if len(failures) else merged).sort_values("voxel_auroc_T").iloc[0], False))
    candidates.append(("largest_false_positive_response", merged.sort_values("false_burden", ascending=False).iloc[0], True))
    multi = merged[merged["component_count_T"] > 1]
    candidates.append(("multi_component_finding", (multi if len(multi) else merged).sort_values("topk_component_recall_T", ascending=False).iloc[0], False))
    small = merged[merged["size_group_T"] == "small-2d"]
    candidates.append(("smallest_successful_localization", (small if len(small) else merged).sort_values(["peak_inside_5mm_support_T", "gt_voxels_T"], ascending=[False, True]).iloc[0], False))
    output = comparison / "visualizations"
    output.mkdir(exist_ok=True)
    seen = set()
    for label, row, peak_view in candidates:
        key = (row["case_id"], int(row["finding_id"]))
        if (label, key) in seen:
            continue
        seen.add((label, key))
        filename = f"{str(key[0]).replace('.nii.gz', '')}_finding_{key[1]}.npz"
        cdata = np.load(control / "evaluation" / f"target25_update_{update}" / "slices" / filename)
        tdata = np.load(treatment / "evaluation" / f"target25_update_{update}" / "slices" / filename)
        suffix = "peak" if peak_view else "gt"
        ct = tdata[f"ct_{suffix}"]
        gt = tdata[f"gt_{suffix}"]
        cq = cdata[f"q_{suffix}"]
        tq = tdata[f"q_{suffix}"]
        fig, axes = plt.subplots(1, 5, figsize=(17, 4))
        for axis, value, title, cmap in zip(
            axes, (ct, gt, cq, tq, tq - cq),
            ("CT", "GT", "Control prior", "Treatment prior", "Treatment - Control"),
            ("gray", "Reds", "viridis", "viridis", "coolwarm"),
        ):
            image = axis.imshow(value, cmap=cmap)
            axis.set_title(title)
            axis.axis("off")
            if title != "CT":
                fig.colorbar(image, ax=axis, fraction=0.046)
        fig.suptitle(f"{label}: {key[0]} finding {key[1]}")
        fig.tight_layout()
        fig.savefig(output / f"{label}.png", dpi=150)
        plt.close(fig)


def final_report(control: Path, treatment: Path, comparison: Path) -> None:
    updates = [update for update in (0, 100, 300, 500) if eval_paths(control, "target25", update)[0].exists() and eval_paths(treatment, "target25", update)[0].exists()]
    finding_frames = []
    component_frames = []
    aggregates = {}
    for update in updates:
        update_findings = []
        update_components = []
        for arm, run in (("OLD_LOSS_CONTROL", control), ("COMPONENT_SIZE_TREATMENT", treatment)):
            finding_path, component_path, aggregate_path = eval_paths(run, "target25", update)
            finding_frame = pd.read_csv(finding_path)
            component_frame = pd.read_csv(component_path)
            finding_frames.append(finding_frame)
            component_frames.append(component_frame)
            update_findings.append(finding_frame)
            update_components.append(component_frame)
            aggregates.setdefault(str(update), {})[arm] = read_json(aggregate_path)
        update_output = comparison / f"update{update}_target25"
        update_output.mkdir(exist_ok=True)
        pd.concat(update_findings, ignore_index=True).to_csv(update_output / "per_finding_prior_metrics.csv", index=False)
        pd.concat(update_components, ignore_index=True).to_csv(update_output / "per_component_prior_metrics.csv", index=False)
        write_json(update_output / "aggregate_prior_metrics.json", aggregates[str(update)])
    pd.concat(finding_frames, ignore_index=True).to_csv(comparison / "per_finding_prior_metrics.csv", index=False)
    pd.concat(component_frames, ignore_index=True).to_csv(comparison / "per_component_prior_metrics.csv", index=False)
    write_json(comparison / "aggregate_prior_metrics.json", aggregates)
    full_validation_summary = None
    full_c_path, full_cc_path, full_ca_path = eval_paths(control, "full2d", 500)
    full_t_path, full_tc_path, full_ta_path = eval_paths(treatment, "full2d", 500)
    if all(path.exists() for path in (full_c_path, full_cc_path, full_ca_path, full_t_path, full_tc_path, full_ta_path)):
        full_output = comparison / "full_2d_validation"
        full_output.mkdir(exist_ok=True)
        full_c = pd.read_csv(full_c_path)
        full_t = pd.read_csv(full_t_path)
        pd.concat((full_c, full_t), ignore_index=True).to_csv(full_output / "per_finding_prior_metrics.csv", index=False)
        pd.concat((pd.read_csv(full_cc_path), pd.read_csv(full_tc_path)), ignore_index=True).to_csv(full_output / "per_component_prior_metrics.csv", index=False)
        full_validation_summary = {
            "OLD_LOSS_CONTROL": read_json(full_ca_path),
            "COMPONENT_SIZE_TREATMENT": read_json(full_ta_path),
        }
        write_json(full_output / "aggregate_prior_metrics.json", full_validation_summary)
        paired = full_t.merge(full_c, on=["case_id", "finding_id"], suffixes=("_T", "_C"))
        bootstrap_rows = []
        rng = np.random.default_rng(20260805)
        for metric in ("voxel_auroc", "auprc_over_prevalence", "topk_component_recall", "peak_inside_gt"):
            paired[f"delta_{metric}"] = paired[f"{metric}_T"].astype(float) - paired[f"{metric}_C"].astype(float)
            case_values = paired.groupby("case_id")[f"delta_{metric}"].mean().to_numpy()
            draws = np.asarray([rng.choice(case_values, len(case_values), replace=True).mean() for _ in range(2000)])
            bootstrap_rows.append({
                "metric": metric, "case_clusters": len(case_values), "estimate": float(case_values.mean()),
                "ci95_low": float(np.quantile(draws, 0.025)), "ci95_high": float(np.quantile(draws, 0.975)),
                "bootstrap_samples": 2000,
            })
        pd.DataFrame(bootstrap_rows).to_csv(full_output / "case_cluster_bootstrap.csv", index=False)
    if 300 in updates:
        create_visualizations(control, treatment, comparison, 300)
    continuation = read_json(comparison / "continuation_decision.json") if (comparison / "continuation_decision.json").exists() else {"status": "missing"}
    update500 = read_json(comparison / "update500_prior_quality_decision.json") if (comparison / "update500_prior_quality_decision.json").exists() else None
    decision = update500 or continuation
    t300 = aggregates.get("300", {}).get("COMPONENT_SIZE_TREATMENT", {}).get("all", {})
    if decision.get("status") == "CONTINUE" and update500 is not None:
        ending = "PRIOR LEARNABILITY RESCUED BY COMPONENT/SIZE-AWARE LOSS."
    elif float(t300.get("voxel_auroc", 0.0)) >= 0.55 or float(t300.get("peak_inside_gt", 0.0)) > 0:
        ending = "PARTIAL LOCALIZATION SIGNAL, BUT INSUFFICIENT EXTENT OR BACKGROUND CONTROL."
    else:
        ending = "PRIOR REMAINS COLLAPSED."
    provenance = read_json(comparison / "checkpoint_provenance.json")
    architecture = read_json(comparison / "architecture_audit.json")
    preflight_result = read_json(comparison / "preflight_results.json")
    launch = read_json(comparison / "launch_manifest.json") if (comparison / "launch_manifest.json").exists() else {}
    tracked = [
        "VoxTell/voxtell/model/category_2d_prior_probe.py",
        "scripts/prepare_s3_2d_prior_learnability.py",
        "scripts/train_s3_2d_prior_learnability.py",
        "scripts/evaluate_s3_2d_prior_learnability.py",
        "scripts/analyze_s3_2d_prior_learnability.py",
        "scripts/s3_2d_prior_learnability_pipeline.sbatch",
    ]
    git = shutil.which("git")
    if git is None:
        status = "git executable unavailable on final-report compute node"
        diff = "git executable unavailable on final-report compute node"
    else:
        status = subprocess.run([git, "status", "--short", "--", *tracked], capture_output=True, text=True).stdout.strip()
        diff = subprocess.run([git, "diff", "--stat", "--", *tracked], capture_output=True, text=True).stdout.strip()
    report = f"""# Matched category-2d prior-head learnability experiment

## Provenance and architecture

- Base: `{provenance['checkpoint']}`
- SHA256: `{provenance['sha256']}`
- Identity: {provenance['identity']}
- Frozen S3 reference: Dice/finding {provenance['full381_reference']['dice_per_finding']:.6f}, hits {provenance['full381_reference']['hits']}/{provenance['full381_reference']['findings']}
- Prior architecture: `{architecture['architecture_id']}`; {architecture['trainable_parameter_count']} trainable parameters
- Original S3 and segmentation conversion paths are frozen/absent.

## Matched objectives

- Control: full valid-patch mean BCEWithLogits + soft Dice.
- Treatment: component-local Tversky (FP/FN 0.3/0.7 below 1000 voxels, otherwise 0.5/0.5), normalized capped inverse-size weighting, 0.05 localization mass/ranking, and 0.10 sampled hard background, subject only to the documented preflight numerical adjustment.
- Tversky convention was audited: `alpha_fp` multiplies FP and `beta_fn` multiplies FN.
- Connected components use 26-connectivity; ROIs expand 12 mm and support uses physical 5-mm distance.

## Preflight

- Status: {preflight_result['status']}
- Adjustment: {', '.join(preflight_result['one_allowed_adjustment'])}
- Selected localization/background weights: {preflight_result['selected_localization_weight']}/{preflight_result['selected_hard_background_weight']}

## Target-25 results and decision

- Available updates: {updates}
- Update-300 decision: {continuation.get('status')}
- Update-300 checks: `{json.dumps(continuation.get('checks', {}), sort_keys=True)}`
- Update-500 decision: {None if update500 is None else update500.get('status')}
- Conditional full category-2d validation: {'completed' if full_validation_summary is not None else 'not triggered'}

## Resources and jobs

`{json.dumps(launch, sort_keys=True)}`

## Commands and output paths

- Control: `{control}`
- Treatment: `{treatment}`
- Comparison: `{comparison}`

## Git state for experiment files

```text
{status or '(clean for selected paths)'}
```

Diff stat:

```text
{diff or '(no tracked diff stat; repository paths may be untracked)'}
```

## Final classification

{ending}
"""
    (comparison / "report.md").write_text(report)
    safety = read_json(comparison / "safety_checks.json")
    safety.update({
        "preflight_matching_and_gradients_passed": preflight_result["status"] == "pass",
        "target_metrics_exclude_non_target_channels": True,
        "evaluation_has_no_duplicate_findings": all(
            not frame.duplicated(["arm", "update", "case_id", "finding_id"]).any()
            for frame in finding_frames
        ),
    })
    write_json(comparison / "safety_checks.json", safety)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("preflight", "gate300", "gate500", "final"), required=True)
    parser.add_argument("--control-dir", type=Path, required=True)
    parser.add_argument("--treatment-dir", type=Path, required=True)
    parser.add_argument("--comparison-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.stage == "preflight":
        preflight(args.control_dir, args.treatment_dir, args.comparison_dir)
    elif args.stage == "gate300":
        gate(args.control_dir, args.treatment_dir, args.comparison_dir, 300)
    elif args.stage == "gate500":
        gate(args.control_dir, args.treatment_dir, args.comparison_dir, 500)
    else:
        final_report(args.control_dir, args.treatment_dir, args.comparison_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
