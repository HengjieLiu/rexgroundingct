#!/usr/bin/env python3
"""Candidate-availability, ranking, and crop-coverage ceiling for category 2d-small."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import ndimage
from scipy.spatial import cKDTree
from run_voxtell_rex_inference import (
    load_image,
    load_reference_mask_for_window_diagnostic,
)


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/s3_2d_small_candidate_ceiling_audit"
PROB_ROOT = OUT / "exact_probabilities"
PREP = ROOT / "data/rex_voxtell_preprocessed_v1"
PRIOR = ROOT / "outputs/baseline_vs_s3_9000_failure_mode_audit"
CT_DIR = ROOT / "data/ct_rate_volumes_fixed"
GT_DIR = ROOT / "data/segmentations"
THRESHOLDS = (0.50, 0.40, 0.30, 0.20, 0.10, 0.05)
STRUCTURE18 = ndimage.generate_binary_structure(3, 2)
GT_STRUCTURE = STRUCTURE18
RANK_RULES = {
    "maximum_probability": ("maximum_probability", False),
    "mean_probability": ("mean_probability", False),
    "integrated_probability": ("integrated_probability", False),
    "candidate_volume": ("candidate_voxel_count", False),
    "existing_peak_heuristic": ("maximum_probability", False),
}
LOST_KEYS = {
    ("train_13339_a_1.nii.gz", 0),
    ("train_18956_a_1.nii.gz", 0),
    ("train_19032_a_2.nii.gz", 1),
    ("train_19456_b_1.nii.gz", 0),
    ("train_19877_a_2.nii.gz", 0),
    ("train_2458_a_2.nii.gz", 0),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=OUT)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--bootstrap-samples", type=int, default=2_000)
    parser.add_argument("--seed", type=int, default=20260802)
    parser.add_argument("--force-cases", action="store_true")
    return parser.parse_args()


def atomic_json(value: object, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, default=str) + "\n")
    temporary.replace(path)


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def atomic_parquet(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    frame.to_parquet(temporary, index=False)
    temporary.replace(path)


def markdown_table(frame: pd.DataFrame) -> str:
    def render(value: object) -> str:
        if pd.isna(value):
            return ""
        return str(value).replace("|", "\\|").replace("\n", "<br>")

    columns = frame.columns.tolist()
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
    ]
    lines.extend(
        "| " + " | ".join(render(value) for value in row) + " |"
        for row in frame.itertuples(index=False, name=None)
    )
    return "\n".join(lines)


def probability_path(model: str, case_id: str) -> Path:
    return PROB_ROOT / model / f"{case_id.removesuffix('.nii.gz')}.npz"


def analysis_probability_path(model: str, case_id: str) -> Path:
    reused = PRIOR / "selected_diagnostics" / f"{model}_probability" / f"{case_id.removesuffix('.nii.gz')}.npz"
    return reused if reused.exists() else probability_path(model, case_id)


def load_preprocessed_manifest() -> dict[str, dict]:
    result = {}
    with (PREP / "manifest.jsonl").open() as handle:
        for line in handle:
            row = json.loads(line)
            if row.get("split") == "val" and row.get("status") == "processed":
                result[str(row["case"])] = row
    return result


def probability_regeneration_summary(cohort: pd.DataFrame) -> dict:
    expected = {
        case: sorted(group.finding_id.astype(int).tolist())
        for case, group in cohort.groupby("case_id")
    }
    result = {}
    for model in ("baseline", "s3"):
        records = []
        reused_cases = 0
        for case_id, finding_ids in sorted(expected.items()):
            path = analysis_probability_path(model, case_id)
            reused_cases += int(PRIOR / "selected_diagnostics" in path.parents)
            with np.load(path, allow_pickle=False) as archive:
                metadata = json.loads(str(archive["metadata_json"].item()))
                stored_ids = archive["finding_ids"].astype(int).tolist()
            if not set(finding_ids).issubset(stored_ids) or stored_ids != metadata["finding_ids"]:
                raise AssertionError(f"{model}/{case_id}: target finding IDs missing or archive metadata mismatch")
            records.append(metadata)
        result[model] = {
            "case_archives": len(records),
            "target_findings": int(sum(len(ids) for ids in expected.values())),
            "stored_channels_total": int(sum(len(record["finding_ids"]) for record in records)),
            "reused_prior_selected_case_archives": reused_cases,
            "regenerated_case_archives": len(records) - reused_cases,
            "legacy_preprocessed_mask_cache_rejected": True,
            "legacy_cache_rejection_reason": "Affine-aware smoke showed that the legacy preprocessed mask cache is not in current inference RAS coordinates for every case; GT is loaded with the same CT-affine transform used by inference anchoring.",
            "reference_binary_mismatches_anchored": int(sum(record["reference_binary_mismatches_before_anchor"] for record in records)),
            "maximum_reference_binary_probability_margin": float(max(record["reference_binary_max_probability_margin"] for record in records)),
            "threshold_boundary_repairs": int(sum(record["threshold_boundary_repairs"] for record in records)),
            "all_final_thresholds": sorted(set(float(record["final_threshold"]) for record in records)),
            "coordinate_orders": sorted(set(record["coordinate_order"] for record in records)),
            "non_target_channels_included": False,
        }
    return result


def component_overlap_ordinals(labels: np.ndarray, gt_coords: np.ndarray) -> dict[int, list[int]]:
    values = labels[tuple(gt_coords.T)]
    order = np.argsort(values, kind="stable")
    sorted_values = values[order]
    boundaries = np.flatnonzero(np.diff(sorted_values)) + 1
    result = {}
    for indices in np.split(order, boundaries):
        if len(indices) and int(values[indices[0]]) > 0:
            result[int(values[indices[0]])] = indices.astype(int).tolist()
    return result


def extract_components(
    probability: np.ndarray,
    gt: np.ndarray,
    gt_labels: np.ndarray,
    gt_coords: np.ndarray,
    tree: cKDTree,
    case_id: str,
    finding_id: int,
    source: str,
    threshold: float,
    previous_labels: np.ndarray | None,
    previous_persistent: dict[int, str],
    persistent_counter: int,
) -> tuple[pd.DataFrame, np.ndarray, dict[int, str], int]:
    mask = probability > np.float16(threshold)
    labels, count = ndimage.label(mask, structure=STRUCTURE18)
    ids = np.arange(1, count + 1, dtype=np.int32)
    objects = ndimage.find_objects(labels, max_label=count)
    sizes_list, sums_list, maxima_list, centers_list, maximum_positions_list = [], [], [], [], []
    for component_id, box in zip(ids, objects):
        member = labels[box] == component_id
        local_coordinates = np.argwhere(member)
        start = np.asarray([axis.start for axis in box], dtype=np.int64)
        values = probability[box][member]
        sizes_list.append(len(values))
        sums_list.append(values.sum(dtype=np.float64))
        maximum_offset = int(np.argmax(values))
        maxima_list.append(float(values[maximum_offset]))
        centers_list.append(local_coordinates.mean(axis=0) + start)
        maximum_positions_list.append(local_coordinates[maximum_offset] + start)
    sizes = np.asarray(sizes_list, dtype=np.int64)
    sums = np.asarray(sums_list, dtype=np.float64)
    maxima = np.asarray(maxima_list, dtype=np.float64)
    centers = np.asarray(centers_list, dtype=np.float64).reshape((-1, 3))
    maximum_positions = np.asarray(maximum_positions_list, dtype=np.int64).reshape((-1, 3))
    if int(sizes.sum()) != int(mask.sum()):
        raise AssertionError(f"{case_id}/f{finding_id}/{source}/t{threshold}: component voxels do not partition threshold mask")
    overlap_by_component = component_overlap_ordinals(labels, gt_coords)
    gt_component_values = gt_labels[tuple(gt_coords.T)]
    persistent: dict[int, str] = {}
    parents: dict[int, list[str]] = defaultdict(list)
    if previous_labels is not None and previous_persistent:
        active = previous_labels > 0
        pairs = np.unique(
            np.stack([labels[active], previous_labels[active]], axis=1), axis=0
        )
        for current_id, previous_id in pairs:
            if int(current_id) > 0 and int(previous_id) in previous_persistent:
                parents[int(current_id)].append(previous_persistent[int(previous_id)])
    for component_id in ids:
        inherited = sorted(set(parents.get(int(component_id), [])))
        if inherited:
            persistent[int(component_id)] = inherited[0]
        else:
            persistent[int(component_id)] = (
                f"{case_id.removesuffix('.nii.gz')}__f{finding_id:03d}__{source}__p{persistent_counter:06d}"
            )
            persistent_counter += 1
    rows = []
    if count:
        center_distance = tree.query(centers, workers=1)[0]
        maximum_distance = tree.query(maximum_positions, workers=1)[0]
    else:
        center_distance = maximum_distance = np.asarray([], dtype=float)
    gt_voxels = len(gt_coords)
    for offset, component_id in enumerate(ids):
        component_id_int = int(component_id)
        overlap_ordinals = overlap_by_component.get(component_id_int, [])
        overlap = len(overlap_ordinals)
        component_gt_ids = sorted(
            set(int(gt_component_values[index]) for index in overlap_ordinals)
        )
        volume = int(sizes[offset])
        union = volume + gt_voxels - overlap
        box = objects[offset]
        center = centers[offset]
        maximum_position = maximum_positions[offset]
        rows.append(
            {
                "case_id": case_id,
                "finding_id": finding_id,
                "source": source,
                "origin_source": source,
                "probability_threshold": threshold,
                "candidate_id": f"{source}_t{threshold:.2f}_c{component_id_int:06d}",
                "component_id": component_id_int,
                "candidate_voxel_count": volume,
                "maximum_probability": float(maxima[offset]),
                "mean_probability": float(sums[offset] / max(volume, 1)),
                "integrated_probability": float(sums[offset]),
                "centroid_d": float(center[0]),
                "centroid_h": float(center[1]),
                "centroid_w": float(center[2]),
                "maximum_d": int(maximum_position[0]),
                "maximum_h": int(maximum_position[1]),
                "maximum_w": int(maximum_position[2]),
                "bbox_d0": int(box[0].start),
                "bbox_d1": int(box[0].stop),
                "bbox_h0": int(box[1].start),
                "bbox_h1": int(box[1].stop),
                "bbox_w0": int(box[2].start),
                "bbox_w1": int(box[2].stop),
                "centroid_distance_to_gt_voxels": float(center_distance[offset]),
                "maximum_point_distance_to_gt_voxels": float(maximum_distance[offset]),
                "overlap_voxels": overlap,
                "gt_voxels": gt_voxels,
                "gt_coverage": overlap / gt_voxels,
                "candidate_precision": overlap / volume,
                "iou": overlap / union if union else 1.0,
                "overlaps_any_gt": bool(overlap),
                "gt_components_overlapped": len(component_gt_ids),
                "gt_component_ids_json": json.dumps(component_gt_ids),
                "gt_overlap_ordinal_indices_json": json.dumps(overlap_ordinals),
                "persistent_candidate_id": persistent[component_id_int],
                "persistent_parent_ids_json": json.dumps(sorted(set(parents.get(component_id_int, [])))),
                "eligible_min1": True,
                "eligible_min3": volume >= 3,
                "eligible_min10": volume >= 10,
            }
        )
    frame = pd.DataFrame(rows)
    if frame.empty:
        frame = pd.DataFrame(
            columns=[
                "case_id", "finding_id", "source", "origin_source",
                "probability_threshold", "candidate_id", "component_id",
                "candidate_voxel_count", "maximum_probability",
                "mean_probability", "integrated_probability", "centroid_d",
                "centroid_h", "centroid_w", "maximum_d", "maximum_h",
                "maximum_w", "bbox_d0", "bbox_d1", "bbox_h0", "bbox_h1",
                "bbox_w0", "bbox_w1", "centroid_distance_to_gt_voxels",
                "maximum_point_distance_to_gt_voxels", "overlap_voxels",
                "gt_voxels", "gt_coverage", "candidate_precision", "iou",
                "overlaps_any_gt", "gt_components_overlapped",
                "gt_component_ids_json", "gt_overlap_ordinal_indices_json",
                "persistent_candidate_id", "persistent_parent_ids_json",
                "eligible_min1", "eligible_min3", "eligible_min10",
            ]
        )
    return frame, labels, persistent, persistent_counter


def union_candidates(
    baseline: pd.DataFrame,
    s3: pd.DataFrame,
    baseline_labels: np.ndarray,
    s3_labels: np.ndarray,
    threshold: float,
) -> pd.DataFrame:
    """Deduplicate only strongly overlapping cross-model components."""
    b_sizes = baseline.set_index("component_id").candidate_voxel_count.to_dict()
    s_sizes = s3.set_index("component_id").candidate_voxel_count.to_dict()
    active = (baseline_labels > 0) & (s3_labels > 0)
    duplicate_pairs: set[tuple[int, int]] = set()
    if active.any():
        encoded = baseline_labels[active].astype(np.int64) * (len(s_sizes) + 1) + s3_labels[active]
        codes, counts = np.unique(encoded, return_counts=True)
        for code, overlap in zip(codes, counts):
            baseline_id = int(code // (len(s_sizes) + 1))
            s3_id = int(code % (len(s_sizes) + 1))
            if baseline_id not in b_sizes or s3_id not in s_sizes:
                continue
            iou = overlap / (b_sizes[baseline_id] + s_sizes[s3_id] - overlap)
            contained = overlap / min(b_sizes[baseline_id], s_sizes[s3_id])
            if iou >= 0.50 or contained >= 0.80:
                duplicate_pairs.add((baseline_id, s3_id))
    joined = pd.concat([baseline, s3], ignore_index=True)
    joined = joined.sort_values(
        ["maximum_probability", "integrated_probability", "candidate_id"],
        ascending=[False, False, True],
        kind="stable",
    )
    kept: list[pd.Series] = []
    kept_ids: set[tuple[str, int]] = set()
    suppressed_by: dict[tuple[str, int], str] = {}
    for _, row in joined.iterrows():
        key = (str(row.source), int(row.component_id))
        conflicts = []
        if key[0] == "baseline":
            conflicts = [("s3", s3_id) for baseline_id, s3_id in duplicate_pairs if baseline_id == key[1]]
        else:
            conflicts = [("baseline", baseline_id) for baseline_id, s3_id in duplicate_pairs if s3_id == key[1]]
        blocker = next((candidate for candidate in conflicts if candidate in kept_ids), None)
        if blocker is not None:
            suppressed_by[key] = f"{blocker[0]}_c{blocker[1]:06d}"
            continue
        kept.append(row)
        kept_ids.add(key)
    if not kept:
        return pd.DataFrame(columns=baseline.columns)
    result = pd.DataFrame(kept).reset_index(drop=True)
    result["origin_source"] = result.source.astype(str)
    result["source"] = "union"
    result["candidate_id"] = [
        f"union_t{threshold:.2f}_{origin}_c{int(component):06d}"
        for origin, component in zip(result.origin_source, result.component_id)
    ]
    result["union_dedup_rule"] = "cross-model IoU>=0.50 or overlap/min-volume>=0.80; retain higher peak"
    return result


def crop_rows(candidates: pd.DataFrame, gt_coords: np.ndarray, gt_component_ids: np.ndarray, volume_shape: tuple[int, int, int]) -> pd.DataFrame:
    rows = []
    gt_voxels = len(gt_coords)
    for candidate in candidates.itertuples(index=False):
        centers = {
            "centroid": np.rint([candidate.centroid_d, candidate.centroid_h, candidate.centroid_w]).astype(int),
            "maximum_point": np.asarray([candidate.maximum_d, candidate.maximum_h, candidate.maximum_w], dtype=int),
        }
        for center_type, center in centers.items():
            distance = float(
                candidate.centroid_distance_to_gt_voxels
                if center_type == "centroid"
                else candidate.maximum_point_distance_to_gt_voxels
            )
            for geometry, size in (("native192", 192), ("native96", 96)):
                start = center - size // 2
                stop = start + size
                inside = np.all((gt_coords >= start) & (gt_coords < stop), axis=1)
                included_ids = sorted(set(gt_component_ids[inside].astype(int).tolist()))
                safe_start = start + 8
                safe_stop = stop - 8
                safe_inside = np.all((gt_coords >= safe_start) & (gt_coords < safe_stop), axis=1)
                component_sizes = np.bincount(gt_component_ids.astype(int))[1:]
                full_component_counts = np.bincount(gt_component_ids[inside].astype(int), minlength=len(component_sizes) + 1)[1:]
                safe_component_counts = np.bincount(gt_component_ids[safe_inside].astype(int), minlength=len(component_sizes) + 1)[1:]
                raw_component_coverage = np.divide(full_component_counts, np.maximum(component_sizes, 1), dtype=np.float64)
                safe_component_coverage = np.divide(safe_component_counts, np.maximum(component_sizes, 1), dtype=np.float64)
                rows.append(
                    {
                        "case_id": candidate.case_id,
                        "finding_id": int(candidate.finding_id),
                        "source": candidate.source,
                        "origin_source": candidate.origin_source,
                        "probability_threshold": candidate.probability_threshold,
                        "candidate_id": candidate.candidate_id,
                        "center_type": center_type,
                        "crop_geometry": geometry,
                        "crop_size_d": size,
                        "crop_size_h": size,
                        "crop_size_w": size,
                        "center_d": int(center[0]),
                        "center_h": int(center[1]),
                        "center_w": int(center[2]),
                        "center_to_gt_distance_voxels": distance,
                        "gt_voxels_in_crop": int(inside.sum()),
                        "gt_voxel_coverage": float(inside.mean()),
                        "coverage_ge_0p10": bool(inside.mean() >= 0.10),
                        "coverage_ge_0p50": bool(inside.mean() >= 0.50),
                        "coverage_ge_0p90": bool(inside.mean() >= 0.90),
                        "any_gt_voxel_in_crop": bool(inside.any()),
                        "gt_components_included": len(included_ids),
                        "gt_component_ids_json": json.dumps(included_ids),
                        "safe_margin_voxels": 8,
                        "safe_inner_gt_coverage": float(safe_inside.mean()),
                        "raw_full_max_component_coverage": float(raw_component_coverage.max(initial=0.0)),
                        "safe_inner_max_component_coverage": float(safe_component_coverage.max(initial=0.0)),
                        "crop_was_boundary_clipped": bool(np.any(start < 0) or np.any(stop > np.asarray(volume_shape))),
                    }
                )
    return pd.DataFrame(rows)


def process_case(task: tuple[str, list[int], dict, str, bool]) -> tuple[str, int, int]:
    case_id, finding_ids, prep_row, case_dir_text, force = task
    case_dir = Path(case_dir_text)
    candidate_path = case_dir / f"{case_id.removesuffix('.nii.gz')}_candidates.parquet"
    crop_path = case_dir / f"{case_id.removesuffix('.nii.gz')}_crops.parquet"
    if candidate_path.exists() and crop_path.exists() and not force:
        return case_id, len(pd.read_parquet(candidate_path)), len(pd.read_parquet(crop_path))
    with np.load(analysis_probability_path("baseline", case_id), allow_pickle=False) as archive:
        stored = archive["probability"].astype(np.float16)
        baseline_ids = archive["finding_ids"].astype(int).tolist()
        baseline_probability = stored[[baseline_ids.index(finding_id) for finding_id in finding_ids]]
    with np.load(analysis_probability_path("s3", case_id), allow_pickle=False) as archive:
        stored = archive["probability"].astype(np.float16)
        s3_ids = archive["finding_ids"].astype(int).tolist()
        s3_probability = stored[[s3_ids.index(finding_id) for finding_id in finding_ids]]
    if not set(finding_ids).issubset(baseline_ids) or not set(finding_ids).issubset(s3_ids):
        raise AssertionError(f"{case_id}: target finding IDs absent from probabilities {baseline_ids}/{s3_ids}")
    image, image_properties = load_image(CT_DIR / case_id)
    probability_shape = tuple(baseline_probability.shape[1:])
    if tuple(s3_probability.shape[1:]) != probability_shape or tuple(image.shape[1:]) != probability_shape:
        raise AssertionError(f"{case_id}: image/probability shape mismatch")
    full_bbox = tuple(slice(0, value) for value in probability_shape)
    aligned = load_reference_mask_for_window_diagnostic(
        GT_DIR / case_id,
        len(finding_ids),
        probability_shape,
        full_bbox,
        image_properties=image_properties,
        finding_ids=finding_ids,
    )
    if aligned is None:
        raise AssertionError(f"{case_id}: affine-aware GT alignment failed")
    masks = aligned.numpy().astype(bool, copy=False)
    all_candidates = []
    all_crops = []
    for channel, finding_id in enumerate(finding_ids):
        gt = masks[channel]
        expected_gt_voxels = int(prep_row["json_pixels"][str(finding_id)])
        if int(gt.sum()) != expected_gt_voxels:
            raise AssertionError(
                f"{case_id}/f{finding_id}: aligned GT has {int(gt.sum())} voxels, expected {expected_gt_voxels}"
            )
        if gt.shape != baseline_probability[channel].shape or gt.shape != s3_probability[channel].shape:
            raise AssertionError(f"{case_id}/f{finding_id}: probability/GT shape mismatch")
        gt_labels, _ = ndimage.label(gt, structure=GT_STRUCTURE)
        gt_coords = np.argwhere(gt)
        gt_component_ids = gt_labels[tuple(gt_coords.T)]
        tree = cKDTree(gt_coords)
        state = {
            "baseline": (None, {}, 1),
            "s3": (None, {}, 1),
        }
        for threshold in THRESHOLDS:
            extracted = {}
            label_arrays = {}
            for source, probability in (("baseline", baseline_probability[channel]), ("s3", s3_probability[channel])):
                previous_labels, previous_persistent, counter = state[source]
                frame, labels, persistent, counter = extract_components(
                    probability, gt, gt_labels, gt_coords, tree, case_id, finding_id,
                    source, threshold, previous_labels, previous_persistent, counter,
                )
                frame["gt_component_count"] = int(gt_labels.max())
                extracted[source] = frame
                label_arrays[source] = labels
                state[source] = (labels, persistent, counter)
            union = union_candidates(
                extracted["baseline"], extracted["s3"], label_arrays["baseline"],
                label_arrays["s3"], threshold,
            )
            union["gt_component_count"] = int(gt_labels.max())
            combined = pd.concat([extracted["baseline"], extracted["s3"], union], ignore_index=True)
            all_candidates.append(combined)
            all_crops.append(crop_rows(combined, gt_coords, gt_component_ids, gt.shape))
    candidates = pd.concat(all_candidates, ignore_index=True)
    crops = pd.concat(all_crops, ignore_index=True)
    case_dir.mkdir(parents=True, exist_ok=True)
    atomic_parquet(candidates, candidate_path)
    atomic_parquet(crops, crop_path)
    return case_id, len(candidates), len(crops)


def wilson(successes: int, denominator: int) -> tuple[float, float]:
    if denominator == 0:
        return float("nan"), float("nan")
    z = 1.959963984540054
    p = successes / denominator
    center = (p + z * z / (2 * denominator)) / (1 + z * z / denominator)
    half = z * math.sqrt(p * (1 - p) / denominator + z * z / (4 * denominator**2)) / (1 + z * z / denominator)
    return center - half, center + half


def case_bootstrap(frame: pd.DataFrame, value: str, samples: int, seed: int) -> tuple[float, float]:
    if frame.empty:
        return float("nan"), float("nan")
    grouped = frame.groupby("case_id")[value].agg(["sum", "count"]).sort_index()
    sums = grouped["sum"].to_numpy(float)
    counts = grouped["count"].to_numpy(float)
    rng = np.random.default_rng(seed)
    selected = rng.integers(0, len(grouped), size=(samples, len(grouped)))
    values = sums[selected].sum(axis=1) / counts[selected].sum(axis=1)
    return tuple(float(x) for x in np.quantile(values, [0.025, 0.975]))


def persistent_summary(candidates: pd.DataFrame) -> pd.DataFrame:
    exact = candidates.loc[candidates.source.isin(["baseline", "s3"])].copy()
    rows = []
    for persistent_id, group in exact.groupby("persistent_candidate_id", sort=False):
        ordered = group.sort_values("probability_threshold", ascending=False)
        rows.append(
            {
                "persistent_candidate_id": persistent_id,
                "case_id": ordered.iloc[0].case_id,
                "finding_id": int(ordered.iloc[0].finding_id),
                "source": ordered.iloc[0].source,
                "threshold_max": float(ordered.probability_threshold.max()),
                "threshold_min": float(ordered.probability_threshold.min()),
                "threshold_count": int(ordered.probability_threshold.nunique()),
                "maximum_probability": float(ordered.maximum_probability.max()),
                "maximum_integrated_probability": float(ordered.integrated_probability.max()),
                "volumes_by_threshold_json": json.dumps(
                    {f"{r.probability_threshold:.2f}": int(r.candidate_voxel_count) for r in ordered.itertuples()}
                ),
                "centroid_trajectory_json": json.dumps(
                    {f"{r.probability_threshold:.2f}": [r.centroid_d, r.centroid_h, r.centroid_w] for r in ordered.itertuples()}
                ),
                "ever_overlaps_gt": bool(ordered.overlaps_any_gt.any()),
                "maximum_gt_coverage": float(ordered.gt_coverage.max()),
            }
        )
    return pd.DataFrame(rows)


def source_summary(
    candidates: pd.DataFrame,
    crops: pd.DataFrame,
    cohort: pd.DataFrame,
    samples: int,
    seed: int,
) -> pd.DataFrame:
    crop_max = crops.groupby(["case_id", "finding_id", "source", "probability_threshold", "candidate_id"]).gt_voxel_coverage.max()
    frame = candidates.merge(crop_max.rename("maximum_crop_coverage"), on=["case_id", "finding_id", "source", "probability_threshold", "candidate_id"], how="left")
    analysis_groups = {
        "all_2d_small": np.ones(len(cohort), dtype=bool),
        "six_lost_hits": np.asarray([(case, int(finding)) in LOST_KEYS for case, finding in zip(cohort.case_id, cohort.finding_id)]),
        "hit_hit": cohort.transition.eq("hit_hit").to_numpy(),
        "miss_miss": cohort.transition.eq("miss_miss").to_numpy(),
        "single_component": cohort.multiplicity_group.eq("single").to_numpy(),
        "few_components": cohort.multiplicity_group.eq("few_2_3").to_numpy(),
        "multiple_components": cohort.multiplicity_group.eq("multiple_ge4").to_numpy(),
    }
    rows = []
    for source in ("baseline", "s3", "union"):
        for threshold in THRESHOLDS:
            selected = frame.loc[frame.source.eq(source) & np.isclose(frame.probability_threshold, threshold)]
            for minimum in (1, 3, 10):
                eligible = selected.loc[selected.candidate_voxel_count.ge(minimum)]
                grouped = eligible.groupby(["case_id", "finding_id"])
                for analysis_group, selector in analysis_groups.items():
                    per = cohort.loc[selector, ["case_id", "finding_id"]].copy()
                    per["candidate_count"] = [len(grouped.get_group(key)) if key in grouped.groups else 0 for key in map(tuple, per.to_numpy())]
                    for metric, condition in {
                        "any_component_overlap": eligible.overlaps_any_gt,
                        "component_coverage_ge_0p10": eligible.gt_coverage.ge(0.10),
                        "component_coverage_ge_0p50": eligible.gt_coverage.ge(0.50),
                        "crop_coverage_ge_0p50": eligible.maximum_crop_coverage.ge(0.50),
                        "crop_coverage_ge_0p90": eligible.maximum_crop_coverage.ge(0.90),
                        "usable_candidate": eligible.overlaps_any_gt | eligible.maximum_crop_coverage.ge(0.50),
                    }.items():
                        positive_keys = set(zip(eligible.loc[condition, "case_id"], eligible.loc[condition, "finding_id"].astype(int)))
                        per[metric] = [tuple(key) in positive_keys for key in per[["case_id", "finding_id"]].to_numpy()]
                    for metric in ("any_component_overlap", "component_coverage_ge_0p10", "component_coverage_ge_0p50", "crop_coverage_ge_0p50", "crop_coverage_ge_0p90", "usable_candidate"):
                        successes = int(per[metric].sum())
                        low, high = wilson(successes, len(per))
                        boot_low, boot_high = case_bootstrap(per, metric, samples, seed + successes + minimum)
                        rows.append(
                            {
                                "analysis_group": analysis_group,
                                "source": source,
                                "probability_threshold": threshold,
                                "minimum_component_voxels": minimum,
                                "metric": metric,
                                "numerator": successes,
                                "denominator": len(per),
                                "proportion": successes / len(per),
                                "wilson_ci95_low": low,
                                "wilson_ci95_high": high,
                                "case_bootstrap_ci95_low": boot_low,
                                "case_bootstrap_ci95_high": boot_high,
                                "mean_candidate_count": float(per.candidate_count.mean()),
                                "p95_candidate_count": float(per.candidate_count.quantile(0.95)),
                            }
                        )
    return pd.DataFrame(rows)


def continuous_summary(
    candidates: pd.DataFrame,
    crops: pd.DataFrame,
    cohort: pd.DataFrame,
    samples: int,
    seed: int,
) -> pd.DataFrame:
    maximum_crop = crops.groupby(["case_id", "finding_id", "source", "probability_threshold", "candidate_id"]).gt_voxel_coverage.max()
    frame = candidates.merge(maximum_crop.rename("maximum_crop_coverage"), on=["case_id", "finding_id", "source", "probability_threshold", "candidate_id"], how="left")
    analysis_groups = {
        "all_2d_small": np.ones(len(cohort), dtype=bool),
        "six_lost_hits": np.asarray([(case, int(finding)) in LOST_KEYS for case, finding in zip(cohort.case_id, cohort.finding_id)]),
        "hit_hit": cohort.transition.eq("hit_hit").to_numpy(),
        "miss_miss": cohort.transition.eq("miss_miss").to_numpy(),
        "single_component": cohort.multiplicity_group.eq("single").to_numpy(),
        "few_components": cohort.multiplicity_group.eq("few_2_3").to_numpy(),
        "multiple_components": cohort.multiplicity_group.eq("multiple_ge4").to_numpy(),
    }
    rows = []
    for source in ("baseline", "s3", "union"):
        for threshold in THRESHOLDS:
            selected = frame.loc[frame.source.eq(source) & np.isclose(frame.probability_threshold, threshold)]
            for minimum in (1, 3, 10):
                eligible = selected.loc[selected.candidate_voxel_count.ge(minimum)]
                grouped = eligible.groupby(["case_id", "finding_id"])
                base = cohort[["case_id", "finding_id"]].copy()
                base["candidate_count"] = [len(grouped.get_group(key)) if key in grouped.groups else 0 for key in map(tuple, base.to_numpy())]
                base["maximum_component_gt_coverage"] = [float(grouped.get_group(key).gt_coverage.max()) if key in grouped.groups else 0.0 for key in map(tuple, base[["case_id", "finding_id"]].to_numpy())]
                base["maximum_crop_gt_coverage"] = [float(grouped.get_group(key).maximum_crop_coverage.max()) if key in grouped.groups else 0.0 for key in map(tuple, base[["case_id", "finding_id"]].to_numpy())]
                for analysis_group, selector in analysis_groups.items():
                    group = base.loc[selector]
                    for metric in ("candidate_count", "maximum_component_gt_coverage", "maximum_crop_gt_coverage"):
                        low, high = case_bootstrap(group, metric, samples, seed + minimum + len(rows))
                        rows.append(
                            {
                                "analysis_group": analysis_group,
                                "source": source,
                                "probability_threshold": threshold,
                                "minimum_component_voxels": minimum,
                                "metric": metric,
                                "findings": len(group),
                                "mean": float(group[metric].mean()),
                                "median": float(group[metric].median()),
                                "quartile_25": float(group[metric].quantile(0.25)),
                                "quartile_75": float(group[metric].quantile(0.75)),
                                "case_bootstrap_mean_ci95_low": low,
                                "case_bootstrap_mean_ci95_high": high,
                            }
                        )
    return pd.DataFrame(rows)


def rank_tables(candidates: pd.DataFrame, crops: pd.DataFrame, cohort: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    maximum_crop = crops.groupby(["case_id", "finding_id", "source", "probability_threshold", "candidate_id"]).gt_voxel_coverage.max()
    frame = candidates.merge(maximum_crop.rename("maximum_crop_coverage"), on=["case_id", "finding_id", "source", "probability_threshold", "candidate_id"], how="left")
    finding_rows = []
    for source in ("baseline", "s3", "union"):
        for threshold in THRESHOLDS:
            subset = frame.loc[frame.source.eq(source) & np.isclose(frame.probability_threshold, threshold)]
            groups = {key: group for key, group in subset.groupby(["case_id", "finding_id"])}
            for finding in cohort.itertuples(index=False):
                key = (finding.case_id, int(finding.finding_id))
                group = groups.get(key, pd.DataFrame(columns=frame.columns))
                for rule, (column, ascending) in RANK_RULES.items():
                    ranked = group.sort_values([column, "candidate_id"], ascending=[ascending, True], kind="stable")
                    targets = {
                        "component_any": ranked.overlap_voxels.gt(0),
                        "component_coverage_ge_0p10": ranked.gt_coverage.ge(0.10),
                        "component_coverage_ge_0p50": ranked.gt_coverage.ge(0.50),
                        "crop_coverage_ge_0p90": ranked.maximum_crop_coverage.ge(0.90),
                    }
                    row = {
                        "case_id": key[0], "finding_id": key[1], "source": source,
                        "probability_threshold": threshold, "ranking_rule": rule,
                        "candidate_count": len(ranked),
                    }
                    for target_name, target in targets.items():
                        positions = np.flatnonzero(target.to_numpy()) + 1
                        row[f"rank_{target_name}"] = int(positions[0]) if len(positions) else np.nan
                    overlap_sets = [set(json.loads(value)) for value in ranked.gt_overlap_ordinal_indices_json]
                    for k in (1, 3, 5, 10):
                        union: set[int] = set()
                        for values in overlap_sets[:k]:
                            union.update(values)
                        row[f"top{k}_union_gt_coverage"] = len(union) / int(finding.gt_voxels)
                    finding_rows.append(row)
    per_finding = pd.DataFrame(finding_rows)
    summaries = []
    targets = ("component_any", "component_coverage_ge_0p10", "component_coverage_ge_0p50", "crop_coverage_ge_0p90")
    for keys, group in per_finding.groupby(["source", "probability_threshold", "ranking_rule"], sort=True):
        source, threshold, rule = keys
        for target in targets:
            rank = group[f"rank_{target}"]
            row = {
                "source": source, "probability_threshold": threshold, "ranking_rule": rule,
                "target": target, "findings": len(group), "oracle_numerator": int(rank.notna().sum()),
                "oracle_recall": float(rank.notna().mean()),
                "scope": "all_88_2d_small",
                "mean_candidate_count": float(group.candidate_count.mean()),
                "p95_candidate_count": float(group.candidate_count.quantile(0.95)),
            }
            for k in (1, 3, 5, 10):
                row[f"top{k}_numerator"] = int(rank.le(k).sum())
                row[f"top{k}_recall"] = float(rank.le(k).mean())
                row[f"mean_top{k}_union_coverage"] = float(group[f"top{k}_union_gt_coverage"].mean())
            summaries.append(row)
    return per_finding, pd.DataFrame(summaries)


def first_appearance_table(candidates: pd.DataFrame, crops: pd.DataFrame, cohort: pd.DataFrame) -> pd.DataFrame:
    maximum_crop = crops.groupby(["case_id", "finding_id", "source", "probability_threshold", "candidate_id"]).gt_voxel_coverage.max()
    frame = candidates.merge(maximum_crop.rename("maximum_crop_coverage"), on=["case_id", "finding_id", "source", "probability_threshold", "candidate_id"], how="left")
    rows = []
    for finding in cohort.itertuples(index=False):
        for source in ("baseline", "s3", "union"):
            group = frame.loc[frame.case_id.eq(finding.case_id) & frame.finding_id.eq(finding.finding_id) & frame.source.eq(source)]
            first = np.nan
            valid_count = false_count = 0
            for threshold in THRESHOLDS:
                threshold_group = group.loc[np.isclose(group.probability_threshold, threshold)]
                valid = threshold_group.overlaps_any_gt | threshold_group.maximum_crop_coverage.ge(0.50)
                if valid.any():
                    first = threshold
                    valid_count = int(valid.sum())
                    false_count = int((~valid).sum())
                    break
            rows.append(
                {
                    "case_id": finding.case_id,
                    "finding_id": int(finding.finding_id),
                    "source": source,
                    "first_usable_threshold_descending": first,
                    "usable_candidates_at_first_threshold": valid_count,
                    "false_candidates_at_first_threshold": false_count,
                    "transition": finding.transition,
                    "multiplicity_group": finding.multiplicity_group,
                }
            )
    return pd.DataFrame(rows)


def failure_classification(
    candidates: pd.DataFrame,
    crops: pd.DataFrame,
    ranks: pd.DataFrame,
    cohort: pd.DataFrame,
) -> pd.DataFrame:
    maximum_crop = crops.groupby(["case_id", "finding_id", "source", "probability_threshold", "candidate_id"]).gt_voxel_coverage.max()
    frame = candidates.merge(maximum_crop.rename("maximum_crop_coverage"), on=["case_id", "finding_id", "source", "probability_threshold", "candidate_id"], how="left")
    rows = []
    for finding in cohort.itertuples(index=False):
        for source in ("baseline", "s3", "union"):
            group = frame.loc[
                frame.case_id.eq(finding.case_id) & frame.finding_id.eq(finding.finding_id) & frame.source.eq(source)
            ]
            valid = group.overlaps_any_gt | group.maximum_crop_coverage.ge(0.50)
            source_ranks = ranks.loc[
                ranks.case_id.eq(finding.case_id) & ranks.finding_id.eq(finding.finding_id) & ranks.source.eq(source)
            ]
            valid_rank_columns = ["rank_component_any", "rank_crop_coverage_ge_0p90"]
            best_rank = float(source_ranks[valid_rank_columns].min(axis=1).min()) if len(source_ranks) else np.nan
            top3 = group.loc[group.overlaps_any_gt & group.maximum_crop_coverage.ge(0.90)]
            top3_exists = False
            if len(top3):
                top3_ids = set(top3.candidate_id)
                for rank_row in source_ranks.itertuples(index=False):
                    threshold_group = group.loc[np.isclose(group.probability_threshold, rank_row.probability_threshold)]
                    column = RANK_RULES[rank_row.ranking_rule][0]
                    ordered = threshold_group.sort_values([column, "candidate_id"], ascending=[False, True])
                    if set(ordered.head(3).candidate_id) & top3_ids:
                        top3_exists = True
                        break
            if not valid.any():
                classification = "A_candidate_absent"
                reason = "No component overlaps GT and no candidate-centered crop reaches 50% GT coverage."
            elif top3_exists:
                classification = "D_candidate_sufficient"
                reason = "A top-3 localized candidate has at least 90% crop coverage."
            elif np.isfinite(best_rank) and best_rank > 5:
                classification = "B_exists_but_ranks_poorly"
                reason = "A valid candidate exists, but its best simple-heuristic rank is below top 5."
            elif np.isfinite(best_rank) and best_rank <= 3:
                classification = "C_ranks_well_coverage_incomplete"
                reason = "A valid candidate ranks in the top 3, but high crop/component coverage is not established."
            else:
                classification = "E_mixed_ambiguous"
                reason = "Availability and rank do not fit a single operational class."
            rows.append(
                {
                    "case_id": finding.case_id,
                    "finding_id": int(finding.finding_id),
                    "source": source,
                    "classification": classification,
                    "reason": reason,
                    "candidate_count_all_threshold_rows": len(group),
                    "any_component_overlap": bool(group.overlaps_any_gt.any()),
                    "maximum_component_gt_coverage": float(group.gt_coverage.max()) if len(group) else 0.0,
                    "maximum_crop_gt_coverage": float(group.maximum_crop_coverage.max()) if len(group) else 0.0,
                    "best_valid_simple_rank": best_rank,
                    "baseline_dice": float(finding.baseline_global_dice),
                    "s3_dice": float(finding.s3_global_dice),
                    "transition": finding.transition,
                    "multiplicity_group": finding.multiplicity_group,
                }
            )
    return pd.DataFrame(rows)


def add_historical_proposal_summary(cohort: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    manifest = pd.read_csv(ROOT / "outputs/p0b2_lite_crop_coverage_ranker_fold0/candidate_manifest_top8.csv")
    coverage = pd.read_csv(ROOT / "outputs/p0b2_lite_crop_coverage_ranker_fold0/candidate_coverage_labels.csv")
    merged = manifest.merge(coverage, on=["candidate_uid", "candidate_index", "finding_key"], validate="one_to_one")
    keys = set(zip(cohort.case_id, cohort.finding_id.astype(int)))
    merged = merged.loc[[((str(case)), int(finding)) in keys for case, finding in zip(merged.case, merged.finding_idx)]].copy()
    all_keys = cohort[["case_id", "finding_id"]].copy()
    group = merged.groupby(["case", "finding_idx"])
    per = []
    for row in all_keys.itertuples(index=False):
        candidates = group.get_group((row.case_id, row.finding_id)) if (row.case_id, row.finding_id) in group.groups else merged.iloc[:0]
        ordered = candidates.sort_values(["heuristic_rank", "candidate_uid"])
        per.append(
            {
                "case_id": row.case_id,
                "finding_id": int(row.finding_id),
                "candidate_count": len(ordered),
                "oracle_any_crop_ge_0p50": bool(ordered.safe_inner_coverage.ge(0.50).any()),
                "oracle_any_crop_ge_0p90": bool(ordered.safe_inner_coverage.ge(0.90).any()),
                "heuristic_top1_crop_ge_0p90": bool(ordered.head(1).safe_inner_coverage.ge(0.90).any()),
                "heuristic_top3_crop_ge_0p90": bool(ordered.head(3).safe_inner_coverage.ge(0.90).any()),
                "maximum_safe_crop_coverage": float(ordered.safe_inner_coverage.max()) if len(ordered) else 0.0,
            }
        )
    per_frame = pd.DataFrame(per)
    p0f = pd.read_csv(ROOT / "outputs/p0f_lite_same_anatomy_component_ranker/per_candidate_predictions.csv")
    p0f = p0f.loc[[((str(case)), int(finding)) in keys for case, finding in zip(p0f.case, p0f.finding_idx)]]
    summary = {
        "p0b2_source": "Dual-S3 update2000, not exact S3@9000",
        "cohort_candidates": len(merged),
        "findings_with_candidates": int((per_frame.candidate_count > 0).sum()),
        "oracle_native96_safe_crop_ge_0p50": int(per_frame.oracle_any_crop_ge_0p50.sum()),
        "oracle_native96_safe_crop_ge_0p90": int(per_frame.oracle_any_crop_ge_0p90.sum()),
        "heuristic_top1_ge_0p90": int(per_frame.heuristic_top1_crop_ge_0p90.sum()),
        "heuristic_top3_ge_0p90": int(per_frame.heuristic_top3_crop_ge_0p90.sum()),
        "lost_hits_with_candidates": int(sum(((row.case_id, row.finding_id) in LOST_KEYS) and row.candidate_count > 0 for row in per_frame.itertuples())),
        "p0f_cohort_findings_with_candidate_scores": int(p0f.groupby(["case", "finding_idx"]).ngroups),
        "p0f_lost_hits_with_candidate_scores": int(len(LOST_KEYS & set(zip(p0f.case, p0f.finding_idx.astype(int))))),
    }
    return per_frame, summary


def prior_ranker_summary(cohort: pd.DataFrame) -> pd.DataFrame:
    cohort_keys = set(zip(cohort.case_id, cohort.finding_id.astype(int)))
    rows = []
    p0f = pd.read_csv(ROOT / "outputs/p0f_lite_same_anatomy_component_ranker/per_candidate_predictions.csv")
    p0f = p0f.loc[[((str(case)), int(finding)) in cohort_keys for case, finding in zip(p0f.case, p0f.finding_idx)]]
    p0f_groups = list(p0f.groupby(["case", "finding_idx"]))
    for rule in ("probability_integrated_mass", "tabular_score", "frozen_score"):
        ranks = []
        for _, group in p0f_groups:
            ordered = group.sort_values([rule, "candidate_uid"], ascending=[False, True])
            positions = np.flatnonzero(ordered.useful.astype(bool).to_numpy()) + 1
            ranks.append(int(positions[0]) if len(positions) else np.nan)
        rank = pd.Series(ranks, dtype=float)
        row = {
            "stored_source": "p0f_duals3_update2000_same_anatomy_components",
            "ranking_rule": rule,
            "directly_scored_findings": len(rank),
            "full_cohort_findings": len(cohort),
            "oracle_numerator": int(rank.notna().sum()),
            "oracle_recall_among_scored": float(rank.notna().mean()) if len(rank) else np.nan,
            "oracle_recall_full_cohort": float(rank.notna().sum() / len(cohort)),
        }
        for k in (1, 3, 5, 10):
            row[f"top{k}_numerator"] = int(rank.le(k).sum())
            row[f"top{k}_recall_among_scored"] = float(rank.le(k).mean()) if len(rank) else np.nan
            row[f"top{k}_recall_full_cohort"] = float(rank.le(k).sum() / len(cohort))
        rows.append(row)

    p0b2 = pd.read_csv(ROOT / "outputs/p0b2_lite_crop_coverage_ranker_fold0/heldout_candidate_scores.csv")
    p0b2 = p0b2.loc[[((str(case)), int(finding)) in cohort_keys for case, finding in zip(p0b2.case, p0b2.finding_idx)]]
    p0b2_groups = list(p0b2.groupby(["case", "finding_idx"]))
    for rule, column, ascending in (("heuristic_rank", "heuristic_rank", True), ("learned_coverage_score", "coverage_score", False)):
        ranks = []
        for _, group in p0b2_groups:
            ordered = group.sort_values([column, "candidate_uid"], ascending=[ascending, True])
            positions = np.flatnonzero(ordered.safe_inner_coverage.ge(0.90).to_numpy()) + 1
            ranks.append(int(positions[0]) if len(positions) else np.nan)
        rank = pd.Series(ranks, dtype=float)
        row = {
            "stored_source": "p0b2_duals3_update2000_native96_heldout_only",
            "ranking_rule": rule,
            "directly_scored_findings": len(rank),
            "full_cohort_findings": len(cohort),
            "oracle_numerator": int(rank.notna().sum()),
            "oracle_recall_among_scored": float(rank.notna().mean()) if len(rank) else np.nan,
            "oracle_recall_full_cohort": float(rank.notna().sum() / len(cohort)),
        }
        for k in (1, 3, 5, 10):
            row[f"top{k}_numerator"] = int(rank.le(k).sum())
            row[f"top{k}_recall_among_scored"] = float(rank.le(k).mean()) if len(rank) else np.nan
            row[f"top{k}_recall_full_cohort"] = float(rank.le(k).sum() / len(cohort))
        rows.append(row)
    return pd.DataFrame(rows)


def historical_source_summary_rows(
    historical: pd.DataFrame,
    cohort: pd.DataFrame,
    samples: int,
    seed: int,
) -> pd.DataFrame:
    frame = cohort[["case_id", "finding_id", "transition", "multiplicity_group"]].merge(
        historical, on=["case_id", "finding_id"], validate="one_to_one"
    )
    groups = {
        "all_2d_small": np.ones(len(frame), dtype=bool),
        "six_lost_hits": np.asarray([(case, int(finding)) in LOST_KEYS for case, finding in zip(frame.case_id, frame.finding_id)]),
        "hit_hit": frame.transition.eq("hit_hit").to_numpy(),
        "miss_miss": frame.transition.eq("miss_miss").to_numpy(),
        "single_component": frame.multiplicity_group.eq("single").to_numpy(),
        "few_components": frame.multiplicity_group.eq("few_2_3").to_numpy(),
        "multiple_components": frame.multiplicity_group.eq("multiple_ge4").to_numpy(),
    }
    rows = []
    metrics = {
        "stored_candidate_available": frame.candidate_count.gt(0),
        "stored_safe_component_crop_ge_0p50": frame.oracle_any_crop_ge_0p50,
        "stored_safe_component_crop_ge_0p90": frame.oracle_any_crop_ge_0p90,
    }
    for group_name, selector in groups.items():
        for metric, values in metrics.items():
            selected = frame.loc[selector, ["case_id", "candidate_count"]].copy()
            selected[metric] = values.loc[selector].to_numpy(bool)
            successes = int(selected[metric].sum())
            low, high = wilson(successes, len(selected))
            boot_low, boot_high = case_bootstrap(selected, metric, samples, seed + successes)
            rows.append(
                {
                    "analysis_group": group_name,
                    "source": "stored_p0b2_duals3_update2000_native96",
                    "probability_threshold": 0.20,
                    "minimum_component_voxels": 1,
                    "metric": metric,
                    "numerator": successes,
                    "denominator": len(selected),
                    "proportion": successes / len(selected),
                    "wilson_ci95_low": low,
                    "wilson_ci95_high": high,
                    "case_bootstrap_ci95_low": boot_low,
                    "case_bootstrap_ci95_high": boot_high,
                    "mean_candidate_count": float(selected.candidate_count.mean()),
                    "p95_candidate_count": float(selected.candidate_count.quantile(0.95)),
                }
            )
    return pd.DataFrame(rows)


def make_casebook(
    candidates: pd.DataFrame,
    crops: pd.DataFrame,
    failures: pd.DataFrame,
    cohort: pd.DataFrame,
    historical: pd.DataFrame,
    prep_manifest: dict[str, dict],
    output_dir: Path,
) -> pd.DataFrame:
    crop_max = crops.groupby(["case_id", "finding_id", "source", "candidate_id", "crop_geometry"]).gt_voxel_coverage.max().unstack(fill_value=0)
    rows = []
    visual_dir = output_dir / "visualizations"
    visual_dir.mkdir(parents=True, exist_ok=True)
    for case_id, finding_id in sorted(LOST_KEYS):
        finding = cohort.loc[cohort.case_id.eq(case_id) & cohort.finding_id.eq(finding_id)].iloc[0]
        row = {
            "case_id": case_id, "finding_id": finding_id, "gt_voxels": int(finding.gt_voxels),
            "gt_component_count": int(finding.gt_component_count),
            "baseline_dice": float(finding.baseline_global_dice), "baseline_hit": bool(finding.baseline_global_hit),
            "s3_dice": float(finding.s3_global_dice), "s3_hit": bool(finding.s3_global_hit),
        }
        for source in ("baseline", "s3", "union"):
            group = candidates.loc[candidates.case_id.eq(case_id) & candidates.finding_id.eq(finding_id) & candidates.source.eq(source)]
            row[f"{source}_candidate_counts_by_threshold_json"] = json.dumps({f"{t:.2f}": int(np.isclose(group.probability_threshold, t).sum()) for t in THRESHOLDS})
            row[f"{source}_best_component_coverage"] = float(group.gt_coverage.max()) if len(group) else 0.0
            indices = crop_max.index
            selected_index = (indices.get_level_values(0) == case_id) & (indices.get_level_values(1) == finding_id) & (indices.get_level_values(2) == source)
            selected_crop = crop_max.loc[selected_index]
            row[f"{source}_best_native192_crop_coverage"] = float(selected_crop.get("native192", pd.Series(dtype=float)).max()) if len(selected_crop) else 0.0
            row[f"{source}_best_native96_crop_coverage"] = float(selected_crop.get("native96", pd.Series(dtype=float)).max()) if len(selected_crop) else 0.0
            failure = failures.loc[failures.case_id.eq(case_id) & failures.finding_id.eq(finding_id) & failures.source.eq(source)].iloc[0]
            row[f"{source}_best_valid_rank"] = failure.best_valid_simple_rank
            row[f"{source}_failure_classification"] = failure.classification
        row["baseline_candidate_absent_from_s3"] = bool(row["baseline_best_component_coverage"] > 0 and row["s3_best_component_coverage"] == 0)
        row["s3_candidate_absent_from_baseline"] = bool(row["s3_best_component_coverage"] > 0 and row["baseline_best_component_coverage"] == 0)
        row["union_recovers_gt"] = bool(row["union_best_component_coverage"] > 0 or row["union_best_native96_crop_coverage"] >= 0.5)
        history = historical.loc[historical.case_id.eq(case_id) & historical.finding_id.eq(finding_id)].iloc[0]
        row["prior_p0b2_candidate_count"] = int(history.candidate_count)
        row["prior_p0b2_best_safe_native96_coverage"] = float(history.maximum_safe_crop_coverage)
        rows.append(row)

        image_with_channel, image_properties = load_image(CT_DIR / case_id)
        image = image_with_channel[0].astype(np.float32, copy=False)
        full_bbox = tuple(slice(0, value) for value in image.shape)
        aligned = load_reference_mask_for_window_diagnostic(
            GT_DIR / case_id,
            1,
            tuple(image.shape),
            full_bbox,
            image_properties=image_properties,
            finding_ids=[finding_id],
        )
        if aligned is None:
            raise AssertionError(f"{case_id}/f{finding_id}: visualization GT alignment failed")
        gt = aligned.numpy()[0].astype(bool, copy=False)
        probabilities = {}
        for source in ("baseline", "s3"):
            with np.load(analysis_probability_path(source, case_id), allow_pickle=False) as archive:
                ids = archive["finding_ids"].astype(int).tolist()
                probabilities[source] = archive["probability"][ids.index(finding_id)].astype(np.float32)
        gt_center = np.rint(np.argwhere(gt).mean(axis=0)).astype(int)
        z = int(gt_center[0])
        fig, axes = plt.subplots(2, 3, figsize=(16, 10), constrained_layout=True)
        panels = [
            (image[z], "CT"), (gt[z].astype(float), "GT"),
            (probabilities["baseline"][z], "Baseline probability"),
            (probabilities["s3"][z], "S3 probability"),
        ]
        for axis, (panel, title) in zip(axes.flat[:4], panels):
            axis.imshow(panel, cmap="gray" if title == "CT" else "magma", vmin=None if title == "CT" else 0, vmax=None if title == "CT" else 1)
            axis.contour(gt[z], levels=[0.5], colors="cyan", linewidths=1)
            if title == "Baseline probability":
                axis.contour(probabilities["baseline"][z] > 0.5, levels=[0.5], colors="lime", linewidths=0.8)
            elif title == "S3 probability":
                axis.contour(probabilities["s3"][z] > 0.5, levels=[0.5], colors="lime", linewidths=0.8)
            axis.set_title(title)
            axis.axis("off")
        for axis, source in zip(axes.flat[4:], ("baseline", "s3")):
            axis.imshow(image[z], cmap="gray")
            source_group = candidates.loc[candidates.case_id.eq(case_id) & candidates.finding_id.eq(finding_id) & candidates.source.eq(source)]
            overlapping_thresholds = source_group.loc[source_group.overlaps_any_gt, "probability_threshold"]
            display_threshold = float(overlapping_thresholds.max()) if len(overlapping_thresholds) else 0.05
            group = source_group.loc[np.isclose(source_group.probability_threshold, display_threshold)]
            top = group.sort_values(["maximum_probability", "candidate_id"], ascending=[False, True]).head(3)
            colors = ("lime", "yellow", "red")
            for rank, (candidate, color) in enumerate(zip(top.itertuples(), colors), start=1):
                axis.scatter(candidate.maximum_w, candidate.maximum_h, s=50, facecolors="none", edgecolors=color, label=f"#{rank} {candidate.candidate_id} p={candidate.maximum_probability:.3f}")
                if abs(candidate.maximum_d - z) <= 48:
                    axis.add_patch(plt.Rectangle((candidate.maximum_w - 48, candidate.maximum_h - 48), 96, 96, fill=False, edgecolor=color, linewidth=1))
            axis.contour(gt[z], levels=[0.5], colors="cyan", linewidths=1.5)
            axis.set_title(f"{source} t={display_threshold:.2f} top-3 centers/native96")
            if len(top):
                axis.legend(fontsize=5, loc="lower right")
            axis.axis("off")
        fig.suptitle(f"{case_id} finding {finding_id}; GT={int(finding.gt_voxels)} voxels")
        fig.savefig(visual_dir / f"{case_id.removesuffix('.nii.gz')}__f{finding_id}.png", dpi=150)
        plt.close(fig)
    return pd.DataFrame(rows)


def write_reports(
    output_dir: Path,
    cohort: pd.DataFrame,
    source: pd.DataFrame,
    ranking: pd.DataFrame,
    failures: pd.DataFrame,
    casebook: pd.DataFrame,
    historical_summary: dict,
    first_appearance: pd.DataFrame,
    prior_rankers: pd.DataFrame,
) -> None:
    regeneration = json.loads((output_dir / "artifact_inventory.json").read_text())["exact_probability_maps_after_regeneration"]
    primary = source.loc[source.analysis_group.eq("all_2d_small") & source.minimum_component_voxels.eq(1) & source.metric.eq("usable_candidate")]
    broad = primary.loc[np.isclose(primary.probability_threshold, 0.05)].set_index("source")
    broad_best_value = float(broad.proportion.max())
    broad_best_sources = broad.index[np.isclose(broad.proportion, broad_best_value)].tolist()
    broad_best_source = "union" if "union" in broad_best_sources else broad_best_sources[0]
    lost_union = casebook.union_recovers_gt.sum()
    lost_union_top3_high_crop = int(
        (
            casebook.union_best_valid_rank.le(3)
            & casebook[["union_best_native192_crop_coverage", "union_best_native96_crop_coverage"]].max(axis=1).ge(0.90)
        ).sum()
    )
    first_union = first_appearance.loc[first_appearance.source.eq("union") & first_appearance.first_usable_threshold_descending.notna()]
    first_threshold_counts = first_union.first_usable_threshold_descending.value_counts().sort_index(ascending=False).to_dict()
    mean_false_at_first = float(first_union.false_candidates_at_first_threshold.mean()) if len(first_union) else float("nan")
    missing_prior_lost = [
        f"{row.case_id}::f{int(row.finding_id)}"
        for row in casebook.loc[casebook.prior_p0b2_candidate_count.eq(0)].itertuples()
    ]
    p0b2_heuristic = prior_rankers.loc[prior_rankers.ranking_rule.eq("heuristic_rank")].iloc[0]
    p0b2_learned = prior_rankers.loc[prior_rankers.ranking_rule.eq("learned_coverage_score")].iloc[0]
    p0f_mass = prior_rankers.loc[prior_rankers.ranking_rule.eq("probability_integrated_mass")].iloc[0]
    p0f_frozen = prior_rankers.loc[prior_rankers.ranking_rule.eq("frozen_score")].iloc[0]
    class_counts = failures.groupby(["source", "classification"]).size().unstack(fill_value=0)
    lost_selector = np.asarray([(case, int(finding)) in LOST_KEYS for case, finding in zip(failures.case_id, failures.finding_id)])
    union_classes = failures.loc[failures.source.eq("union") & lost_selector].classification.value_counts()
    main_bottleneck = str(union_classes.idxmax()).removeprefix("A_").removeprefix("B_").removeprefix("C_").removeprefix("D_").removeprefix("E_")
    lost_s3_poor_rank = int(
        failures.loc[
            failures.source.eq("s3")
            & lost_selector
            & failures.classification.eq("B_exists_but_ranks_poorly")
        ].shape[0]
    )
    recommendation = "D_STOP_TWO_STAGE"
    rationale = "Candidate recall, ranking headroom, and prior local refinement do not jointly support another general two-stage run."
    if broad.loc["union", "proportion"] >= 0.85:
        union_rank = ranking.loc[
            ranking.source.eq("union") & np.isclose(ranking.probability_threshold, 0.05)
            & ranking.ranking_rule.eq("maximum_probability") & ranking.target.eq("crop_coverage_ge_0p90")
        ].iloc[0]
        if union_rank.oracle_recall - union_rank.top5_recall >= 0.10 and lost_s3_poor_rank >= 2:
            recommendation = "A_SAME_CASE_HARD_NEGATIVE_RANKER"
            rationale = "The broad pool has high availability with a material oracle-to-top5 gap, and multiple S3 lost hits contain poorly ranked valid candidates."
        elif union_rank.top3_recall >= 0.75 and lost_union_top3_high_crop >= 4:
            recommendation = "C_LOCAL_SEGMENTATION_REFINEMENT"
            rationale = "Top-3 crop localization is already high; mask extent is the remaining bottleneck. This does not justify repeating the prior native-96 model, which degraded small findings; any refinement must be materially different and small-specific."
    if broad.loc["union", "proportion"] < 0.75 or lost_union <= 2:
        recommendation = "B_DEDICATED_SMALL_NODULE_PROPOSAL_MODEL"
        rationale = "Usable candidates remain absent for a substantial fraction, including the broad dual-model union."

    top_lines = []
    for source_name in ("baseline", "s3", "union"):
        row = broad.loc[source_name]
        top_lines.append(f"- {source_name}: {int(row.numerator)}/{int(row.denominator)} usable at threshold 0.05 (Wilson 95% CI {row.wilson_ci95_low:.3f}–{row.wilson_ci95_high:.3f}).")
    summary = f"""# S3 category-2d-small candidate ceiling audit

## Outcome

**Recommendation: {recommendation}.** {rationale}

The exact primary cohort contains **{len(cohort)} findings in {cohort.case_id.nunique()} cases**. It reproduces category-2d Dice/hits from the prior audit and all six baseline-hit → S3-miss identities.

## Exact-model candidate availability

{os.linesep.join(top_lines)}

- Six lost hits recovered by the broad union definition: **{int(lost_union)}/6**.
- Best exact-model source by broad usable-candidate count: **{broad_best_source}**.
- Union first-usable thresholds (high to low): **{first_threshold_counts}**; mean false candidates introduced at that first threshold: **{mean_false_at_first:.1f}**.
- Candidate counts include the requested size-1 ceiling; operational min-3 and evaluator min-10 variants are in `candidate_source_summary.csv`.

## Failure classes

```
{class_counts.to_string()}
```

## Prior two-stage relation

- P0-B2 stored native-96 source: {historical_summary['findings_with_candidates']}/88 findings had retained candidates; {historical_summary['oracle_native96_safe_crop_ge_0p90']}/88 had an oracle safe crop with ≥90% component coverage.
- These proposals came from Dual-S3 update-2000, not exact S3@9000, so they are historical controls rather than primary evidence.
- P0-F scores directly cover only {historical_summary['p0f_cohort_findings_with_candidate_scores']}/88 cohort findings and {historical_summary['p0f_lost_hits_with_candidate_scores']}/6 lost hits.
- Prior native-96 adaptation was a practical NO-GO for small findings; local refinement is not justified unless exact top-3 crop localization is already high.

## Required decision questions

1. Usable candidates exist for **{int(broad.loc['union', 'numerator'])}/{int(broad.loc['union', 'denominator'])}** 2d-small findings in the broad diagnostic union.
2. The union recovers **{int(lost_union)}/6** lost hits.
3. The best broad source is **{broad_best_source}**; the union is diagnostic and not a deployable single-model method.
4. First-usable union thresholds are distributed as **{first_threshold_counts}**.
5. The mean number of false candidates at first appearance is **{mean_false_at_first:.1f}**; per-finding values are in `candidate_first_appearance.csv`.
6. The most common union failure class is **{main_bottleneck}**; complete class counts are shown above.
7. Prior native-96 retained proposals exist for **{historical_summary['findings_with_candidates']}/88** findings and **{historical_summary['lost_hits_with_candidates']}/6** lost hits.
8. Top-1 is the lower-FP choice; top-3 should only be used with abstention because prior max-fusion inflated FP. Exact localization recall is in `candidate_ranking_summary.csv`.
9. A new hard-negative ranker is **{'justified' if recommendation.startswith('A_') else 'not justified by the prespecified gate'}**.
10. A dedicated proposal model is **{'justified' if recommendation.startswith('B_') else 'not the selected next step'}**.
11. Local refinement is **{'justified with the native-96 small-finding caveat' if recommendation.startswith('C_') else 'not justified'}**.
12. The two-stage route should **{'be stopped' if recommendation.startswith('D_') else 'not be repeated generally; only the selected narrow next step should proceed'}**.

## Definitions and caveats

- Connected components: probability `> threshold`, 18-neighbor connectivity; thresholds 0.50, 0.40, 0.30, 0.20, 0.10 plus prior canonical 0.05.
- Union is a diagnostic dual-model ceiling. Cross-model candidates are deduplicated only for strong component overlap (IoU ≥0.50 or containment ≥0.80).
- Native-96 is fixed center ±48; native-192 is fixed center ±96. Safe coverage uses the prior 8-voxel inner margin.
- Confidence intervals use Wilson intervals and complete-case clustered bootstrap. Small six-case results should not be overinterpreted.
- Target-only prompt batching introduced threshold-near numerical drift in a small number of voxels; exact historical 0.5 binaries were anchored. Maximum pre-anchor margins were {regeneration['baseline']['maximum_reference_binary_probability_margin']:.6f} (baseline) and {regeneration['s3']['maximum_reference_binary_probability_margin']:.6f} (S3); all lower-threshold analyses use the saved continuous fields.
- The 13 prior selected-diagnostic probability archives are reused. A mandatory smoke rejected the legacy preprocessed mask cache for metric alignment; all GT is transformed with the same CT-affine-aware loader used by inference anchoring.
"""
    atomic_text = output_dir / "s3_2d_small_candidate_ceiling_audit_summary.md"
    atomic_text.write_text(summary)

    prior = f"""# Prior two-stage comparison

1. Stored P0-B2 candidate presence is {historical_summary['findings_with_candidates']}/88 (97.7%) for 2d-small versus 376/381 (98.7%) all-category, slightly lower; exact baseline/S3@9000 recall is reported separately in `candidate_source_summary.csv`.
2. Stored P0-B2 candidates exist for {historical_summary['lost_hits_with_candidates']}/6 lost hits; missing: {missing_prior_lost}.
3. P0-E-lite native-96 adaptation was a practical NO-GO: safe-positive recall decreased 0.0834 and fold-1 top-3 Dice decreased 0.005849, despite lower empty-crop FP.
4. A top-1 policy is safer for FP than prior top-3 max-fusion, but can sacrifice recall; exact top-1/top-3 localization is quantified in `candidate_ranking_summary.csv`.
5. On directly scored stored candidates, P0-B2 learned top-1 safe-crop recall is {int(p0b2_learned.top1_numerator)}/{int(p0b2_learned.directly_scored_findings)} versus heuristic {int(p0b2_heuristic.top1_numerator)}/{int(p0b2_heuristic.directly_scored_findings)}; P0-F frozen top-1 useful-component recall is {int(p0f_frozen.top1_numerator)}/{int(p0f_frozen.directly_scored_findings)} versus integrated-mass {int(p0f_mass.top1_numerator)}/{int(p0f_mass.directly_scored_findings)}. Coverage is only {historical_summary['p0f_cohort_findings_with_candidate_scores']}/88, so neither score is extrapolated to exact S3@9000 candidates.
6. Operational failure classes for baseline, S3, and their union are in `candidate_failure_classification.csv`.
"""
    (output_dir / "prior_two_stage_comparison.md").write_text(prior)


def main() -> int:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    cohort = pd.read_csv(output_dir / "cohort_2d_small.csv")
    prep_manifest = load_preprocessed_manifest()
    missing = [str(analysis_probability_path(model, case)) for model in ("baseline", "s3") for case in cohort.case_id.unique() if not analysis_probability_path(model, case).exists()]
    if missing:
        raise FileNotFoundError(f"Missing {len(missing)} exact probability archives; first={missing[0]}")
    regeneration = probability_regeneration_summary(cohort)
    artifact_inventory_path = output_dir / "artifact_inventory.json"
    artifact_inventory = json.loads(artifact_inventory_path.read_text())
    artifact_inventory["exact_probability_maps_after_regeneration"] = regeneration
    atomic_json(artifact_inventory, artifact_inventory_path)
    case_dir = output_dir / "case_tables"
    tasks = []
    for case_id, group in cohort.groupby("case_id", sort=True):
        finding_ids = sorted(group.finding_id.astype(int).tolist())
        tasks.append((case_id, finding_ids, prep_manifest[case_id], str(case_dir), args.force_cases))
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = {executor.submit(process_case, task): task[0] for task in tasks}
        for index, future in enumerate(as_completed(futures), start=1):
            case_id, candidates, crops = future.result()
            print(f"[{index}/{len(tasks)}] {case_id}: {candidates} candidates, {crops} crops", flush=True)
    candidate_paths = sorted(case_dir.glob("*_candidates.parquet"))
    crop_paths = sorted(case_dir.glob("*_crops.parquet"))
    if len(candidate_paths) != len(tasks) or len(crop_paths) != len(tasks):
        raise AssertionError("Per-case candidate/crop output count mismatch")
    candidates = pd.concat((pd.read_parquet(path) for path in candidate_paths), ignore_index=True)
    crops = pd.concat((pd.read_parquet(path) for path in crop_paths), ignore_index=True)
    candidates = candidates.sort_values(["case_id", "finding_id", "source", "probability_threshold", "candidate_id"], ascending=[True, True, True, False, True]).reset_index(drop=True)
    crops = crops.sort_values(["case_id", "finding_id", "source", "probability_threshold", "candidate_id", "crop_geometry", "center_type"], ascending=[True, True, True, False, True, True, True]).reset_index(drop=True)
    atomic_csv(candidates, output_dir / "candidate_level_master.csv")
    atomic_parquet(candidates, output_dir / "candidate_level_master.parquet")
    atomic_csv(crops, output_dir / "candidate_crop_coverage.csv")
    atomic_csv(persistent_summary(candidates), output_dir / "persistent_candidate_summary.csv")
    source = source_summary(candidates, crops, cohort, args.bootstrap_samples, args.seed)
    atomic_csv(source, output_dir / "candidate_source_summary.csv")
    continuous = continuous_summary(candidates, crops, cohort, args.bootstrap_samples, args.seed)
    atomic_csv(continuous, output_dir / "candidate_continuous_summary.csv")
    rank_per_finding, ranking = rank_tables(candidates, crops, cohort)
    atomic_csv(rank_per_finding, output_dir / "candidate_ranking_per_finding.csv")
    atomic_csv(ranking, output_dir / "candidate_ranking_summary.csv")
    first_appearance = first_appearance_table(candidates, crops, cohort)
    atomic_csv(first_appearance, output_dir / "candidate_first_appearance.csv")
    failures = failure_classification(candidates, crops, rank_per_finding, cohort)
    atomic_csv(failures, output_dir / "candidate_failure_classification.csv")
    historical, historical_summary = add_historical_proposal_summary(cohort)
    source = pd.concat(
        [source, historical_source_summary_rows(historical, cohort, args.bootstrap_samples, args.seed)],
        ignore_index=True,
    )
    atomic_csv(source, output_dir / "candidate_source_summary.csv")
    atomic_csv(historical, output_dir / "prior_p0b2_2d_small_per_finding.csv")
    atomic_json(historical_summary, output_dir / "prior_two_stage_machine_summary.json")
    prior_rankers = prior_ranker_summary(cohort)
    atomic_csv(prior_rankers, output_dir / "prior_ranker_direct_applicability.csv")
    prior_ranking_rows = []
    for row in prior_rankers.itertuples(index=False):
        prior_ranking_rows.append(
            {
                "source": row.stored_source,
                "probability_threshold": 0.30 if str(row.stored_source).startswith("p0f") else 0.20,
                "ranking_rule": row.ranking_rule,
                "target": "useful_component" if str(row.stored_source).startswith("p0f") else "safe_component_crop_ge_0p90",
                "findings": int(row.directly_scored_findings),
                "oracle_numerator": int(row.oracle_numerator),
                "oracle_recall": float(row.oracle_recall_among_scored),
                "scope": "stored_candidates_directly_scored_only",
                "top1_numerator": int(row.top1_numerator),
                "top1_recall": float(row.top1_recall_among_scored),
                "top3_numerator": int(row.top3_numerator),
                "top3_recall": float(row.top3_recall_among_scored),
                "top5_numerator": int(row.top5_numerator),
                "top5_recall": float(row.top5_recall_among_scored),
                "top10_numerator": int(row.top10_numerator),
                "top10_recall": float(row.top10_recall_among_scored),
            }
        )
    ranking = pd.concat([ranking, pd.DataFrame(prior_ranking_rows)], ignore_index=True)
    atomic_csv(ranking, output_dir / "candidate_ranking_summary.csv")
    casebook = make_casebook(candidates, crops, failures, cohort, historical, prep_manifest, output_dir)
    atomic_csv(casebook, output_dir / "six_lost_hits_candidate_casebook.csv")
    casebook_md = "# Six lost-hit candidate casebook\n\n" + markdown_table(casebook) + "\n"
    (output_dir / "six_lost_hits_candidate_casebook.md").write_text(casebook_md)
    definitions = {
        "threshold_operator": ">",
        "thresholds": list(THRESHOLDS),
        "connectivity": "3D 18-neighbor; scipy.ndimage.generate_binary_structure(3,2)",
        "candidate_ceiling_minimum_voxels": 1,
        "prior_low_threshold_operational_minimum_voxels": 3,
        "failure_audit_descriptor_minimum_voxels": 10,
        "centroid": "unweighted component voxel centroid in preprocessed D,H,W coordinates",
        "maximum_point": "deterministic first np.argmax voxel within component, matching the prior proposal generator",
        "gt_coverage": "|candidate intersection GT| / |GT|",
        "candidate_precision": "|candidate intersection GT| / |candidate|",
        "iou": "intersection / union",
        "native96": "fixed 96^3 crop centered at rounded centroid or maximum point",
        "native192": "fixed 192^3 crop centered at rounded centroid or maximum point",
        "safe_coverage": "same crop with 8-voxel inner margin; both whole-finding coverage and prior P0-B2 max-component coverage are stored",
        "union_dedup": "Cross-model IoU>=0.50 or overlap/min(component volumes)>=0.80; retain higher max probability",
        "ranking_ties": "candidate_id ascending, deterministic",
        "global_hit": "finding Dice >= 0.10, matching the repository evaluator",
        "local_maxima_generator": "No separate validated repository generator applied; component maximum points are evaluated as centers.",
    }
    atomic_json(definitions, output_dir / "candidate_metric_definitions.json")
    write_reports(output_dir, cohort, source, ranking, failures, casebook, historical_summary, first_appearance, prior_rankers)

    checks = {
        "exact_cohort_88_findings_83_cases": len(cohort) == 88 and cohort.case_id.nunique() == 83,
        "exact_six_lost_hits": set(zip(cohort.loc[cohort.transition.eq('hit_miss'), 'case_id'], cohort.loc[cohort.transition.eq('hit_miss'), 'finding_id'].astype(int))) == LOST_KEYS,
        "id_alignment": not candidates.duplicated(["case_id", "finding_id", "source", "probability_threshold", "candidate_id"]).any(),
        "component_partition_exact_at_each_threshold": True,
        "component_metrics_in_unit_interval": bool(candidates[["gt_coverage", "candidate_precision", "iou"]].ge(0).all().all() and candidates[["gt_coverage", "candidate_precision", "iou"]].le(1).all().all()),
        "crop_metrics_in_unit_interval": bool(crops[["gt_voxel_coverage", "safe_inner_gt_coverage"]].ge(0).all().all() and crops[["gt_voxel_coverage", "safe_inner_gt_coverage"]].le(1).all().all()),
        "topk_recall_nondecreasing": bool(((ranking.top1_recall <= ranking.top3_recall) & (ranking.top3_recall <= ranking.top5_recall) & (ranking.top5_recall <= ranking.top10_recall)).all()),
        "oracle_at_least_topk": bool((ranking.oracle_recall >= ranking.top10_recall).all()),
        "union_recall_at_least_individual": True,
        "deterministic_unique_candidate_ids": not candidates.duplicated(["case_id", "finding_id", "source", "probability_threshold", "candidate_id"]).any(),
        "crop_geometry_matches_prior": set(crops.crop_size_d.unique()) == {96, 192} and int(crops.safe_margin_voxels.unique()[0]) == 8,
        "no_zero_filled_non_target_channels": all(
            regeneration[model]["target_findings"] == 88
            and not regeneration[model]["non_target_channels_included"]
            for model in ("baseline", "s3")
        ),
        "threshold_0p5_reproduces_exact_binary_metrics": True,
    }
    for model in ("baseline", "s3"):
        selected = candidates.loc[candidates.source.eq(model) & np.isclose(candidates.probability_threshold, 0.50)]
        aggregated = selected.groupby(["case_id", "finding_id"]).agg(predicted=("candidate_voxel_count", "sum"), overlap=("overlap_voxels", "sum"))
        for finding in cohort.itertuples(index=False):
            predicted = int(aggregated.loc[(finding.case_id, finding.finding_id), "predicted"]) if (finding.case_id, finding.finding_id) in aggregated.index else 0
            overlap = int(aggregated.loc[(finding.case_id, finding.finding_id), "overlap"]) if (finding.case_id, finding.finding_id) in aggregated.index else 0
            reproduced = (2 * overlap + 1e-6) / (predicted + int(finding.gt_voxels) + 1e-6)
            expected = float(getattr(finding, f"{model}_global_dice"))
            if abs(reproduced - expected) > 1e-7 or bool(reproduced >= 0.10) != bool(getattr(finding, f"{model}_global_hit")):
                checks["threshold_0p5_reproduces_exact_binary_metrics"] = False
                break
    for threshold in THRESHOLDS:
        subset = source.loc[source.analysis_group.eq("all_2d_small") & source.minimum_component_voxels.eq(1) & source.metric.eq("usable_candidate") & np.isclose(source.probability_threshold, threshold)].set_index("source")
        if len(subset) == 3:
            checks["union_recall_at_least_individual"] &= bool(subset.loc["union", "numerator"] >= max(subset.loc["baseline", "numerator"], subset.loc["s3", "numerator"]))
    if not all(checks.values()):
        atomic_json(checks, output_dir / "sanity_checks.json")
        raise AssertionError(f"Sanity check failure: {[key for key, value in checks.items() if not value]}")
    atomic_json(checks, output_dir / "sanity_checks.json")
    inventory = []
    for path in sorted(output_dir.rglob("*")):
        if path.is_file() and not any(part.startswith("smoke_") for part in path.relative_to(output_dir).parts):
            inventory.append({"path": str(path.relative_to(output_dir)), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest() if path.stat().st_size < 100_000_000 else None})
    inventory.append({"path": "output_file_inventory.json", "bytes": None, "sha256": None, "note": "self-reference; size and digest intentionally omitted"})
    atomic_json(inventory, output_dir / "output_file_inventory.json")
    print(json.dumps({"candidates": len(candidates), "crops": len(crops), "outputs": len(inventory)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
