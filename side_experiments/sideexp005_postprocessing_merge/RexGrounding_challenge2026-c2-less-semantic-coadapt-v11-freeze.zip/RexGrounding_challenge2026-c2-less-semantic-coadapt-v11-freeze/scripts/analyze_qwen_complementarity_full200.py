#!/usr/bin/env python3
"""Paired full200 complementarity audit for frozen Qwen, Qwen-LoRA, and BiomedCLIP."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/qwen_complementarity_full200"
N_FINDINGS = 381
N_CASES = 200
N_BOOT = 5000
EXPECTED = {
    "q0": {"dice": 0.3285152961288672, "hits": 288},
    "ql": {"dice": 0.3251869783409958, "hits": 292},
    "bc": {"dice": 0.26445185069905836, "hits": 265},
}
SOURCES = {
    "q0": {
        "root": ROOT / "outputs/a2_fan_v11_longrun_5000/B0/full200_b0_5000_global_only/predictions",
        "metrics": OUT / "source_metrics/q0/per_finding_metrics.csv",
    },
    "ql": {
        "root": ROOT / "outputs/qwen_early_coadaptation_from_v11/full_validation_selected_checkpoints/full_validation/C1_update_5000",
        "metrics": ROOT / "outputs/qwen_early_coadaptation_from_v11/full_validation_selected_checkpoints/full_validation/C1_update_5000/summary_tables/per_finding_metrics.csv",
    },
    "bc": {
        "root": ROOT / "outputs/medplex_trainable_text_study/full200_selected_checkpoints/full_validation/B0_update_3200",
        "metrics": OUT / "source_metrics/bc/per_finding_metrics.csv",
    },
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap-replicates", type=int, default=N_BOOT)
    return parser.parse_args()


def summary_for(name: str) -> dict:
    data = json.loads((SOURCES[name]["root"] / "summary.json").read_text())
    if int(data["total_cases"]) != N_CASES or int(data["total_findings"]) != N_FINDINGS:
        raise RuntimeError(f"{name}: unexpected cohort in summary: {data}")
    if not np.isclose(float(data["mean_global_dice_per_finding"]), EXPECTED[name]["dice"], atol=1e-12):
        raise RuntimeError(f"{name}: summary Dice identity mismatch")
    if int(data["total_hits"]) != EXPECTED[name]["hits"]:
        raise RuntimeError(f"{name}: summary HIT identity mismatch")
    return data


def load_table(name: str, summary: dict) -> pd.DataFrame:
    path = SOURCES[name]["metrics"]
    if not path.is_file():
        raise FileNotFoundError(f"Missing per-finding metrics for {name}: {path}")
    frame = pd.read_csv(path)
    required = {
        "file", "finding_idx", "global_dice", "global_hit", "tp_voxels",
        "fp_voxels", "fn_voxels", "pred_voxels", "gt_voxels",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise RuntimeError(f"{name}: missing metrics columns {missing}")
    frame["file"] = frame["file"].astype(str)
    frame["finding_idx"] = pd.to_numeric(frame["finding_idx"], errors="raise").astype(int)
    frame["global_dice"] = pd.to_numeric(frame["global_dice"], errors="raise")
    frame["global_hit"] = frame["global_hit"].astype(bool)
    key = ["file", "finding_idx"]
    if len(frame) != N_FINDINGS or frame.duplicated(key).any() or frame["file"].nunique() != N_CASES:
        raise RuntimeError(f"{name}: invalid finding key cardinality")
    if not np.isclose(frame["global_dice"].mean(), float(summary["mean_global_dice_per_finding"]), atol=1e-12):
        raise RuntimeError(f"{name}: per-finding Dice does not reproduce stored summary")
    if int(frame["global_hit"].sum()) != int(summary["total_hits"]):
        raise RuntimeError(f"{name}: per-finding HIT does not reproduce stored summary")
    return frame.sort_values(key).reset_index(drop=True)


def model_columns(frame: pd.DataFrame, name: str) -> pd.DataFrame:
    keep = ["file", "finding_idx", "global_dice", "global_hit", "tp_voxels", "fp_voxels", "fn_voxels", "pred_voxels", "gt_voxels"]
    out = frame[keep].copy()
    out = out.rename(columns={
        "global_dice": f"dice_{name}", "global_hit": f"hit_{name}",
        "tp_voxels": f"tp_{name}", "fp_voxels": f"fp_{name}",
        "fn_voxels": f"fn_{name}", "pred_voxels": f"pred_volume_{name}",
        "gt_voxels": "gt_volume",
    })
    if name != "q0":
        out = out.drop(columns="gt_volume")
    return out


def bootstrap_clustered(frame: pd.DataFrame, delta_column: str, reps: int, seed: int) -> tuple[float, float]:
    groups = [group[delta_column].to_numpy(dtype=float) for _, group in frame.groupby("file", sort=True)]
    if not groups:
        return (float("nan"), float("nan"))
    rng = np.random.default_rng(seed)
    estimates = np.empty(reps, dtype=float)
    for index in range(reps):
        selected = rng.integers(0, len(groups), size=len(groups))
        values = np.concatenate([groups[item] for item in selected])
        estimates[index] = values.mean()
    return (float(np.quantile(estimates, 0.025)), float(np.quantile(estimates, 0.975)))


def paired_stat(frame: pd.DataFrame, alternative: str, scope: str, reps: int, seed: int) -> dict:
    delta = frame[f"delta_dice_{alternative}_minus_q0"]
    low, high = bootstrap_clustered(frame, f"delta_dice_{alternative}_minus_q0", reps, seed)
    return {
        "comparison": f"{alternative.upper()} - Q0", "scope": scope, "n_findings": int(len(frame)),
        "n_cases": int(frame["file"].nunique()), "mean_delta": float(delta.mean()),
        "median_delta": float(delta.median()), "wins_delta_gt_0p005": int((delta > 0.005).sum()),
        "losses_delta_lt_m0p005": int((delta < -0.005).sum()),
        "descriptive_ties_abs_lt_0p005": int((delta.abs() < 0.005).sum()),
        "bootstrap_ci_low": low, "bootstrap_ci_high": high,
    }


def hit_groups(frame: pd.DataFrame, alternative: str) -> pd.DataFrame:
    left, right = frame["hit_q0"], frame[f"hit_{alternative}"]
    labels = np.select(
        [left & right, left & ~right, ~left & right],
        ["both_hit", "q0_only_hit", f"{alternative}_only_hit"], default="both_miss",
    )
    result = frame.copy()
    result["hit_group"] = labels
    result["comparison"] = f"q0_vs_{alternative}"
    return result


def paired_table(base: pd.DataFrame, alternative: str) -> pd.DataFrame:
    columns = [
        "file", "finding_idx", "prompt", "category", "pixels", "gt_volume",
        "dice_q0", f"dice_{alternative}", f"delta_dice_{alternative}_minus_q0",
        "hit_q0", f"hit_{alternative}", "tp_q0", f"tp_{alternative}",
        "fp_q0", f"fp_{alternative}", "fn_q0", f"fn_{alternative}",
        "pred_volume_q0", f"pred_volume_{alternative}",
    ]
    return base[columns].copy()


def group_model_metrics(frame: pd.DataFrame, alternative: str) -> list[dict]:
    rows = []
    for group, subset in hit_groups(frame, alternative).groupby("hit_group", sort=True):
        for model in ("q0", alternative):
            rows.append({
                "comparison": f"q0_vs_{alternative}", "hit_group": group, "model": model,
                "n": int(len(subset)), "mean_dice": float(subset[f"dice_{model}"].mean()),
                "median_dice": float(subset[f"dice_{model}"].median()),
                "mean_fp": float(subset[f"fp_{model}"].mean()),
                "mean_fn": float(subset[f"fn_{model}"].mean()),
                "mean_prediction_volume": float(subset[f"pred_volume_{model}"].mean()),
                "mean_gt_volume": float(subset["gt_volume"].mean()),
                "empty_prediction_count": int((subset[f"pred_volume_{model}"] == 0).sum()),
            })
    return rows


def oracle_row(frame: pd.DataFrame, models: list[str], baseline: str = "q0") -> dict:
    dices = frame[[f"dice_{model}" for model in models]]
    hits = frame[[f"hit_{model}" for model in models]]
    oracle_dice = dices.max(axis=1)
    oracle_hit = hits.any(axis=1)
    label = "+".join(model.upper() for model in models)
    return {
        "oracle": label, "n": int(len(frame)), "mean_oracle_dice": float(oracle_dice.mean()),
        "gain_over_q0_dice": float(oracle_dice.mean() - frame["dice_q0"].mean()),
        "gain_over_last_model_dice": float(oracle_dice.mean() - frame[f"dice_{models[-1]}"].mean()),
        "oracle_hits": int(oracle_hit.sum()), "oracle_hit_rate": float(oracle_hit.mean()),
        "gain_over_q0_hits": int(oracle_hit.sum() - frame["hit_q0"].sum()),
        "gain_over_last_model_hits": int(oracle_hit.sum() - frame[f"hit_{models[-1]}"].sum()),
    }


def lesion_size_analysis(base: pd.DataFrame) -> pd.DataFrame:
    # Rank-based qcut is deterministic even when multiple lesions share an equal volume.
    result = base.copy()
    result["gt_volume_quartile"] = pd.qcut(
        result["gt_volume"].rank(method="first"), q=4, labels=["Q1_smallest", "Q2", "Q3", "Q4_largest"]
    )
    rows = []
    for quartile, subset in result.groupby("gt_volume_quartile", observed=True, sort=True):
        for model in ("q0", "ql", "bc"):
            rows.append({
                "quartile": str(quartile), "model": model.upper(), "n": int(len(subset)),
                "gt_volume_min": float(subset["gt_volume"].min()), "gt_volume_max": float(subset["gt_volume"].max()),
                "mean_dice": float(subset[f"dice_{model}"].mean()), "hit_rate": float(subset[f"hit_{model}"].mean()),
                "hits": int(subset[f"hit_{model}"].sum()),
                "ql_minus_q0_dice": float((subset["dice_ql"] - subset["dice_q0"]).mean()),
                "bc_minus_q0_dice": float((subset["dice_bc"] - subset["dice_q0"]).mean()),
            })
    return pd.DataFrame(rows)


def subgroup_analysis(base: pd.DataFrame) -> pd.DataFrame:
    rows = []
    # Category comes from canonical metadata. No lobe/laterality field exists in that
    # metadata, so those potentially noisy text-derived subgroups are intentionally skipped.
    for category, subset in base.groupby("category", dropna=False, sort=True):
        if len(subset) < 10:
            continue
        for model in ("q0", "ql", "bc"):
            rows.append({
                "subgroup_type": "category", "subgroup": str(category), "model": model.upper(),
                "n": int(len(subset)), "mean_dice": float(subset[f"dice_{model}"].mean()),
                "hit_rate": float(subset[f"hit_{model}"].mean()), "hits": int(subset[f"hit_{model}"].sum()),
            })
    return pd.DataFrame(rows)


def correlations(base: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for left, right in (("q0", "ql"), ("q0", "bc"), ("ql", "bc")):
        rows.append({
            "model_a": left.upper(), "model_b": right.upper(),
            "pearson_dice": float(base[f"dice_{left}"].corr(base[f"dice_{right}"], method="pearson")),
            "spearman_dice": float(base[f"dice_{left}"].corr(base[f"dice_{right}"], method="spearman")),
            "hit_agreement": float((base[f"hit_{left}"] == base[f"hit_{right}"]).mean()),
            "both_hit": int((base[f"hit_{left}"] & base[f"hit_{right}"]).sum()),
            "a_only_hit": int((base[f"hit_{left}"] & ~base[f"hit_{right}"]).sum()),
            "b_only_hit": int((~base[f"hit_{left}"] & base[f"hit_{right}"]).sum()),
            "both_miss": int((~base[f"hit_{left}"] & ~base[f"hit_{right}"]).sum()),
        })
    return pd.DataFrame(rows)


def markdown_table(frame: pd.DataFrame, columns: list[str]) -> str:
    subset = frame[columns].copy()
    for column in columns:
        if pd.api.types.is_float_dtype(subset[column]):
            subset[column] = subset[column].map(lambda value: f"{value:.6f}")
    lines = ["| " + " | ".join(columns) + " |", "| " + " | ".join("---" for _ in columns) + " |"]
    lines.extend("| " + " | ".join(str(value) for value in row) + " |" for row in subset.itertuples(index=False, name=None))
    return "\n".join(lines)


def main() -> int:
    args = parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    summaries = {name: summary_for(name) for name in SOURCES}
    tables = {name: load_table(name, summaries[name]) for name in SOURCES}
    keys = {name: set(zip(table.file, table.finding_idx)) for name, table in tables.items()}
    if not (keys["q0"] == keys["ql"] == keys["bc"]):
        raise RuntimeError("Prediction findings cannot be aligned exactly")

    metadata = tables["q0"][["file", "finding_idx", "prompt", "category", "pixels"]].copy()
    base = metadata.merge(model_columns(tables["q0"], "q0"), on=["file", "finding_idx"], validate="one_to_one")
    for name in ("ql", "bc"):
        base = base.merge(model_columns(tables[name], name), on=["file", "finding_idx"], validate="one_to_one")
        base[f"delta_dice_{name}_minus_q0"] = base[f"dice_{name}"] - base["dice_q0"]
    base = base.sort_values(["file", "finding_idx"]).reset_index(drop=True)

    base[["file", "finding_idx", "prompt", "category", "pixels", "gt_volume"]].rename(columns={"file": "case_id", "finding_idx": "finding_id"}).to_csv(OUT / "matched_manifest.csv", index=False)
    ql_table, bc_table = paired_table(base, "ql"), paired_table(base, "bc")
    ql_table.to_csv(OUT / "q0_vs_ql_per_finding.csv", index=False)
    bc_table.to_csv(OUT / "q0_vs_bc_per_finding.csv", index=False)
    hit_ql, hit_bc = hit_groups(base, "ql"), hit_groups(base, "bc")
    hit_columns = ["comparison", "hit_group", "file", "finding_idx", "prompt", "category", "gt_volume", "dice_q0", "dice_ql", "hit_q0", "hit_ql", "fp_q0", "fp_ql", "fn_q0", "fn_ql", "pred_volume_q0", "pred_volume_ql"]
    hit_ql[hit_columns].rename(columns={"file": "case_id", "finding_idx": "finding_id"}).to_csv(OUT / "hit_disagreement_q0_ql.csv", index=False)
    hit_columns_bc = [column.replace("ql", "bc") for column in hit_columns]
    hit_bc[hit_columns_bc].rename(columns={"file": "case_id", "finding_idx": "finding_id"}).to_csv(OUT / "hit_disagreement_q0_bc.csv", index=False)

    both_hit_rows = group_model_metrics(base, "ql") + group_model_metrics(base, "bc")
    both_hit = pd.DataFrame(both_hit_rows)
    both_hit.to_csv(OUT / "both_hit_analysis.csv", index=False)
    lesion = lesion_size_analysis(base)
    lesion.to_csv(OUT / "lesion_size_analysis.csv", index=False)
    subgroup = subgroup_analysis(base)
    subgroup.to_csv(OUT / "subgroup_analysis.csv", index=False)
    error = correlations(base)
    error.to_csv(OUT / "error_correlation.csv", index=False)
    oracle = pd.DataFrame([oracle_row(base, ["q0", "ql"]), oracle_row(base, ["q0", "bc"]), oracle_row(base, ["q0", "ql", "bc"])])
    oracle.to_csv(OUT / "oracle_summary.csv", index=False)

    stats = pd.DataFrame([
        paired_stat(base, "ql", "all", args.bootstrap_replicates, 1731),
        paired_stat(base.loc[base.hit_q0 & base.hit_ql], "ql", "both_hit", args.bootstrap_replicates, 1732),
        paired_stat(base, "bc", "all", args.bootstrap_replicates, 1733),
        paired_stat(base.loc[base.hit_q0 & base.hit_bc], "bc", "both_hit", args.bootstrap_replicates, 1734),
    ])

    ql_counts = hit_ql["hit_group"].value_counts().to_dict()
    bc_counts = hit_bc["hit_group"].value_counts().to_dict()
    ql_oracle = oracle.loc[oracle.oracle == "Q0+QL"].iloc[0]
    bc_oracle = oracle.loc[oracle.oracle == "Q0+BC"].iloc[0]
    ql_class = "Useful primarily as localization/rescue branch" if ql_counts.get("ql_only_hit", 0) > 0 and ql_oracle.gain_over_q0_hits > 0 else "Redundant / no useful gain"
    bc_class = "Small niche complementarity" if bc_counts.get("bc_only_hit", 0) > 0 and bc_oracle.gain_over_q0_hits > 0 else "Redundant relative to Qwen"
    report = [
        "# Full200 paired complementarity analysis", "",
        "This is a CPU-only analysis of existing prediction masks and official global-only evaluation JSONs. It is diagnostic; oracle results are GT-based and not deployable.",
        "", "## Identity and alignment", "",
        "- Q0: frozen Qwen B0@5000, `outputs/a2_fan_v11_longrun_5000/B0/full200_b0_5000_global_only/predictions`.",
        "- QL: early Qwen top-6 LoRA Global C1@5000, `outputs/qwen_early_coadaptation_from_v11/full_validation_selected_checkpoints/full_validation/C1_update_5000`.",
        "- BC: trainable BiomedCLIP B0@3200, `outputs/medplex_trainable_text_study/full200_selected_checkpoints/full_validation/B0_update_3200`.",
        f"- Exact alignment passed: {len(base)} findings across {base.file.nunique()} cases; no duplicates or missing keys. All use threshold 0.5 and global HIT Dice >=0.1.",
        "", "## Aggregate paired statistics", "", markdown_table(stats, ["comparison", "scope", "n_findings", "mean_delta", "median_delta", "wins_delta_gt_0p005", "losses_delta_lt_m0p005", "descriptive_ties_abs_lt_0p005", "bootstrap_ci_low", "bootstrap_ci_high"]),
        "", "## HIT disagreements", "",
        f"- Q0 vs QL: both hit={ql_counts.get('both_hit', 0)}, Q0-only={ql_counts.get('q0_only_hit', 0)}, QL-only={ql_counts.get('ql_only_hit', 0)}, both miss={ql_counts.get('both_miss', 0)}.",
        f"- Q0 vs BC: both hit={bc_counts.get('both_hit', 0)}, Q0-only={bc_counts.get('q0_only_hit', 0)}, BC-only={bc_counts.get('bc_only_hit', 0)}, both miss={bc_counts.get('both_miss', 0)}.",
        "", "## GT-based diagnostic oracles (not deployable)", "", markdown_table(oracle, ["oracle", "mean_oracle_dice", "gain_over_q0_dice", "oracle_hits", "gain_over_q0_hits"]),
        "", "## Classification", "",
        f"- Qwen-LoRA: **{ql_class}**. Its higher HIT is represented by {ql_counts.get('ql_only_hit', 0)} QL-only localizations; delineation and error decomposition are in `both_hit_analysis.csv` and all discordant findings are listed in `hit_disagreement_q0_ql.csv`.",
        f"- BiomedCLIP: **{bc_class}**. It has {bc_counts.get('bc_only_hit', 0)} BC-only localizations; the oracle gain determines whether this small niche is practically useful.",
        "", "## Scope notes", "",
        "- Category is the only reliable metadata subgroup available here. Lobe/laterality were not inferred from free text and are intentionally omitted.",
        "- Probability averaging was skipped: QL has saved probability maps, but Q0 and BC only have thresholded prediction masks, so comparable probability ensembles are not available.",
    ]
    (OUT / "report.md").write_text("\n".join(report) + "\n")
    audit = {
        "schema": "qwen_complementarity_full200_v1", "sources": {name: {"prediction_dir": str(item["root"]), "per_finding_metrics": str(item["metrics"]), "summary": summaries[name]} for name, item in SOURCES.items()},
        "alignment": {"cases": int(base.file.nunique()), "findings": int(len(base)), "exact_keys": True, "hit_definition": "global Dice >= 0.1", "threshold": 0.5},
        "paired_statistics": stats.to_dict(orient="records"), "oracles": oracle.to_dict(orient="records"),
        "classifications": {"qwen_lora": ql_class, "biomedclip": bc_class},
        "ensemble": {"applicable": False, "reason": "Q0 and BC probability maps are unavailable"},
    }
    (OUT / "audit_summary.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"findings": len(base), "cases": base.file.nunique(), "ql_counts": ql_counts, "bc_counts": bc_counts}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
