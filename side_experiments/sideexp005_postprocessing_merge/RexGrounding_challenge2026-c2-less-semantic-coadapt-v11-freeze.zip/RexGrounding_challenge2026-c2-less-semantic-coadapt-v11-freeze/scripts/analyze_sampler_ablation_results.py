#!/usr/bin/env python3
"""Create subgroup, paired-bootstrap, trajectory, and final sampler reports."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ROOT = ROOT / "outputs/sampler_ablation_restricted_vs_inclusive_5k"
UPDATES = (1000, 2000, 3000, 4000, 5000)
ARMS = {"S0": "S0_restricted", "S1": "S1_inclusive"}
GROUPS = ("overall", "singleton", "multi")
BOOTSTRAPS = 10_000
SEED = 2026


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_ROOT)
    return parser.parse_args()


def metrics(frame: pd.DataFrame) -> dict[str, float | int]:
    return {
        "n": int(len(frame)),
        "mean_dice": float(frame["global_dice"].mean()),
        "median_dice": float(frame["global_dice"].median()),
        "hits": int(frame["global_hit"].astype(bool).sum()),
        "empty_predictions": int((frame["pred_voxels"] == 0).sum()),
        "mean_predicted_voxels": float(frame["pred_voxels"].mean()),
        "median_predicted_voxels": float(frame["pred_voxels"].median()),
    }


def subset(frame: pd.DataFrame, group: str) -> pd.DataFrame:
    if group == "overall":
        return frame
    return frame[frame["singleton_or_multi"] == group]


def paired_bootstrap(merged: pd.DataFrame, group: str, seed: int) -> dict[str, object]:
    current = subset(merged, group).copy()
    current["delta_dice"] = current["global_dice_S1"] - current["global_dice_S0"]
    clusters = [values.to_numpy(dtype=np.float64) for _, values in current.groupby("case_id")["delta_dice"]]
    rng = np.random.default_rng(seed)
    boot = np.empty(BOOTSTRAPS, dtype=np.float64)
    for index in range(BOOTSTRAPS):
        chosen = rng.integers(0, len(clusters), size=len(clusters))
        numerator = sum(float(clusters[value].sum()) for value in chosen)
        denominator = sum(int(clusters[value].size) for value in chosen)
        boot[index] = numerator / denominator
    delta = current["delta_dice"].to_numpy(dtype=np.float64)
    tolerance = 1e-12
    return {
        "subgroup": group,
        "findings": int(len(current)),
        "case_clusters": int(current["case_id"].nunique()),
        "mean_paired_delta": float(delta.mean()),
        "median_paired_delta": float(np.median(delta)),
        "case_cluster_bootstrap_ci95": [
            float(np.quantile(boot, 0.025)),
            float(np.quantile(boot, 0.975)),
        ],
        "bootstrap_replicates": BOOTSTRAPS,
        "bootstrap_seed": seed,
        "improved": int((delta > tolerance).sum()),
        "worsened": int((delta < -tolerance).sum()),
        "tied": int((np.abs(delta) <= tolerance).sum()),
    }


def load_full(root: Path, arm: str, update: int, manifest: pd.DataFrame) -> pd.DataFrame:
    path = root / ARMS[arm] / "full200" / f"update_{update:05d}" / "summary_tables/per_finding_metrics.csv"
    if not path.is_file():
        raise FileNotFoundError(path)
    frame = pd.read_csv(path).rename(columns={"file": "case_id", "finding_idx": "finding_id"})
    frame["finding_id"] = frame["finding_id"].astype(int)
    frame = frame.merge(manifest, on=["case_id", "finding_id"], how="left", validate="one_to_one")
    if len(frame) != 381 or frame["singleton_or_multi"].isna().any():
        raise RuntimeError(f"Full200 cardinality/subgroup mismatch: {path}")
    return frame


def fmt(value: float) -> str:
    return f"{value:.6f}"


def main() -> int:
    args = parse_args()
    root = args.output_root.resolve()
    manifest = pd.read_csv(root / "manifests/full200_subgroup_manifest.tsv", sep="\t")
    if (len(manifest), (manifest.singleton_or_multi == "singleton").sum()) != (381, 90):
        raise RuntimeError("Frozen subgroup manifest is invalid")

    trajectory_rows: list[dict[str, object]] = []
    all_subgroup_rows: list[dict[str, object]] = []
    paired_by_update: dict[int, dict[str, dict[str, object]]] = {}
    arm_metrics: dict[tuple[str, int, str], dict[str, object]] = {}
    for update in UPDATES:
        frames = {arm: load_full(root, arm, update, manifest) for arm in ARMS}
        merged = frames["S0"].merge(
            frames["S1"],
            on=["case_id", "finding_id", "singleton_or_multi", "usable_finding_count"],
            suffixes=("_S0", "_S1"),
            validate="one_to_one",
        )
        paired = {
            group: paired_bootstrap(merged, group, SEED + update + group_index)
            for group_index, group in enumerate(GROUPS)
        }
        paired_by_update[update] = paired
        result_dir = root / "paired_analysis" / f"update_{update:05d}"
        result_dir.mkdir(parents=True, exist_ok=True)
        merged[["case_id", "finding_id", "singleton_or_multi", "global_dice_S0", "global_dice_S1"]].assign(
            delta_dice=lambda value: value.global_dice_S1 - value.global_dice_S0
        ).to_csv(result_dir / "paired_finding_deltas.csv", index=False)
        (result_dir / "paired_bootstrap.json").write_text(json.dumps(paired, indent=2, sort_keys=True) + "\n")

        subgroup_rows = []
        for arm, frame in frames.items():
            for group in GROUPS:
                value = metrics(subset(frame, group))
                arm_metrics[(arm, update, group)] = value
                subgroup_rows.append({"arm": arm, "update": update, "subgroup": group, **value})
        pd.DataFrame(subgroup_rows).to_csv(result_dir / "subgroup_metrics.csv", index=False)
        all_subgroup_rows.extend(subgroup_rows)
        report_lines = [
            f"# Paired sampler comparison at update {update}",
            "",
            "| Subgroup | S0 Dice | S1 Dice | Mean paired delta | Median paired delta | 95% case-bootstrap CI | Improved / worsened / tied |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ]
        for group in GROUPS:
            comparison = paired[group]
            low, high = comparison["case_cluster_bootstrap_ci95"]
            report_lines.append(
                f"| {group} | {fmt(arm_metrics[('S0', update, group)]['mean_dice'])} | "
                f"{fmt(arm_metrics[('S1', update, group)]['mean_dice'])} | "
                f"{fmt(comparison['mean_paired_delta'])} | {fmt(comparison['median_paired_delta'])} | "
                f"[{fmt(low)}, {fmt(high)}] | "
                f"{comparison['improved']} / {comparison['worsened']} / {comparison['tied']} |"
            )
        (result_dir / "report.md").write_text("\n".join(report_lines) + "\n")

        row: dict[str, object] = {"update": update}
        for arm in ARMS:
            for group in GROUPS:
                row[f"{arm}_{group}_dice"] = arm_metrics[(arm, update, group)]["mean_dice"]
        for group in GROUPS:
            row[f"delta_{group}"] = paired[group]["mean_paired_delta"]
            row[f"delta_{group}_ci_low"] = paired[group]["case_cluster_bootstrap_ci95"][0]
            row[f"delta_{group}_ci_high"] = paired[group]["case_cluster_bootstrap_ci95"][1]
        trajectory_rows.append(row)

    trajectory = pd.DataFrame(trajectory_rows)
    trajectory.to_csv(root / "paired_analysis/full200_trajectory.csv", index=False)
    (root / "paired_analysis/full200_trajectory.json").write_text(
        json.dumps(trajectory_rows, indent=2) + "\n"
    )
    subgroup_table = pd.DataFrame(all_subgroup_rows)
    subgroup_table.to_csv(root / "paired_analysis/full200_all_subgroup_metrics.csv", index=False)
    hit_lines = [
        "# Full200 overall and case-type subgroup metrics",
        "",
        "| Arm | Update | Overall Dice | Singleton Dice | Multi Dice | Overall HIT | Singleton HIT | Multi HIT |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for update in UPDATES:
        for arm in ARMS:
            overall = arm_metrics[(arm, update, "overall")]
            singleton = arm_metrics[(arm, update, "singleton")]
            multi = arm_metrics[(arm, update, "multi")]
            hit_lines.append(
                f"| {arm} | {update} | {overall['mean_dice']:.6f} | "
                f"{singleton['mean_dice']:.6f} | {multi['mean_dice']:.6f} | "
                f"{overall['hits']}/{overall['n']} | {singleton['hits']}/{singleton['n']} | "
                f"{multi['hits']}/{multi['n']} |"
            )
    (root / "paired_analysis/full200_metrics_table.md").write_text("\n".join(hit_lines) + "\n")

    fixed_rows = []
    for arm, directory in ARMS.items():
        for update in range(1000, 5001, 200):
            eval_dir = root / directory / "fixed30/full_volume" / f"update_{update:05d}"
            summary_path = eval_dir / "controlled_summary.json"
            if not summary_path.is_file():
                raise FileNotFoundError(summary_path)
            summary = json.loads(summary_path.read_text())
            if summary["cases"] != 30 or summary["findings"] != 49:
                raise RuntimeError(f"Fixed30 cardinality mismatch: {summary_path}")
            fixed_rows.append({"arm": arm, **summary})
            finding_path = eval_dir / "summary_tables/per_finding_metrics.csv"
            finding = pd.read_csv(finding_path).rename(columns={"file": "case_id", "finding_idx": "finding_id"})
            finding["finding_id"] = finding["finding_id"].astype(int)
            annotated = finding.merge(manifest, on=["case_id", "finding_id"], how="left", validate="one_to_one")
            if len(annotated) != 49 or annotated["singleton_or_multi"].isna().any():
                raise RuntimeError(f"Fixed30 subgroup annotation mismatch: {finding_path}")
            annotated.to_csv(eval_dir / "summary_tables/per_finding_metrics_with_case_type.csv", index=False)
    fixed = pd.DataFrame(fixed_rows)
    fixed.to_csv(root / "paired_analysis/fixed30_trajectory.csv", index=False)

    best: dict[str, dict[str, tuple[int, float]]] = {}
    for arm in ARMS:
        best[arm] = {}
        for group in GROUPS:
            candidates = [(update, float(arm_metrics[(arm, update, group)]["mean_dice"])) for update in UPDATES]
            best[arm][group] = max(candidates, key=lambda item: item[1])
        arm_fixed = fixed[fixed.arm == arm]
        best_row = arm_fixed.loc[arm_fixed.mean_dice_per_finding.idxmax()]
        best[arm]["fixed30"] = (int(best_row["update"]), float(best_row["mean_dice_per_finding"]))

    singleton_significant = [
        update for update in UPDATES
        if paired_by_update[update]["singleton"]["case_cluster_bootstrap_ci95"][0] > 0
        or paired_by_update[update]["singleton"]["case_cluster_bootstrap_ci95"][1] < 0
    ]
    first_difference = (
        f"update {singleton_significant[0]} (singleton 95% CI excluded zero)"
        if singleton_significant else "no evaluated checkpoint (all singleton 95% CIs included zero)"
    )
    final = paired_by_update[5000]
    exposure = json.loads((root / "S1_inclusive/exposure/cumulative_update_05000.json").read_text())
    singleton_exposed = int(exposure["singleton_findings_sampled_at_least_once"])
    final_single = final["singleton"]
    final_multi = final["multi"]
    final_overall = final["overall"]
    better_default = (
        final_single["case_cluster_bootstrap_ci95"][0] > 0
        and final_overall["case_cluster_bootstrap_ci95"][0] > 0
        and final_multi["case_cluster_bootstrap_ci95"][0] > -0.01
    )
    tradeoff = final_single["mean_paired_delta"] * final_multi["mean_paired_delta"] < 0
    mixture_justified = tradeoff and abs(float(final_single["mean_paired_delta"])) > 0.005

    jobs_path = root / "slurm/submitted_jobs.json"
    jobs = json.loads(jobs_path.read_text()) if jobs_path.is_file() else {}
    lines = [
        "# Matched sampler ablation: restricted vs inclusive singleton training",
        "",
        "| Arm | Best overall Full200 | Best singleton Dice | Best multi Dice | Fixed30 best | Positive cases eligible |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for arm, label, eligible in (("S0", "S0 restricted", 1936), ("S1", "S1 inclusive", 2992)):
        lines.append(
            f"| {label} | {best[arm]['overall'][1]:.6f} (u{best[arm]['overall'][0]}) | "
            f"{best[arm]['singleton'][1]:.6f} (u{best[arm]['singleton'][0]}) | "
            f"{best[arm]['multi'][1]:.6f} (u{best[arm]['multi'][0]}) | "
            f"{best[arm]['fixed30'][1]:.6f} (u{best[arm]['fixed30'][0]}) | {eligible} |"
        )
    lines.extend([
        "",
        "## Full200 trajectory",
        "",
        "| Update | S0 Overall | S1 Overall | Δ | S0 Singleton | S1 Singleton | Δ | S0 Multi | S1 Multi | Δ |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ])
    for update in UPDATES:
        lines.append(
            f"| {update} | {arm_metrics[('S0', update, 'overall')]['mean_dice']:.6f} | "
            f"{arm_metrics[('S1', update, 'overall')]['mean_dice']:.6f} | {paired_by_update[update]['overall']['mean_paired_delta']:.6f} | "
            f"{arm_metrics[('S0', update, 'singleton')]['mean_dice']:.6f} | {arm_metrics[('S1', update, 'singleton')]['mean_dice']:.6f} | {paired_by_update[update]['singleton']['mean_paired_delta']:.6f} | "
            f"{arm_metrics[('S0', update, 'multi')]['mean_dice']:.6f} | {arm_metrics[('S1', update, 'multi')]['mean_dice']:.6f} | {paired_by_update[update]['multi']['mean_paired_delta']:.6f} |"
        )
    lines.extend([
        "",
        "Detailed case-cluster bootstrap CIs and improved/worsened/tied counts are in each `paired_analysis/update_*` directory.",
        "",
        "## Answers",
        "",
        f"1. **Singleton inclusion:** Yes. S1 recorded singleton cases as positive anchors; {singleton_exposed}/1056 singleton findings received at least one positive-target exposure by update 5000.",
        "2. **Multi-finding equivalence:** Yes at implementation level: S1 delegates all multi-finding samples to S0, and the deterministic exact-equivalence test passed before submission.",
        f"3. **Actual singleton coverage:** {singleton_exposed}/1056 singleton findings.",
        f"4. **Singleton performance:** final mean paired Δ Dice = {final_single['mean_paired_delta']:.6f}, 95% CI [{final_single['case_cluster_bootstrap_ci95'][0]:.6f}, {final_single['case_cluster_bootstrap_ci95'][1]:.6f}].",
        f"5. **Multi-finding performance:** final mean paired Δ Dice = {final_multi['mean_paired_delta']:.6f}, 95% CI [{final_multi['case_cluster_bootstrap_ci95'][0]:.6f}, {final_multi['case_cluster_bootstrap_ci95'][1]:.6f}].",
        f"6. **Overall performance:** final mean paired Δ Dice = {final_overall['mean_paired_delta']:.6f}, 95% CI [{final_overall['case_cluster_bootstrap_ci95'][0]:.6f}, {final_overall['case_cluster_bootstrap_ci95'][1]:.6f}].",
        f"7. **First detectable stage:** {first_difference}.",
        f"8. **Coverage/exposure tradeoff:** {'The final singleton and multi deltas have opposite signs, which is evidence of a tradeoff.' if tradeoff else 'The final singleton and multi deltas do not have opposite signs; no directional tradeoff is evident at update 5000.'}",
        f"9. **Default recommendation:** {'Adopt S1 as the better default under the prespecified endpoint rule.' if better_default else 'Do not replace S0 by default on these prespecified endpoints; the evidence is insufficient or includes a material subgroup cost.'}",
        f"10. **Future mixture-ratio study:** {'Justified by the observed subgroup tradeoff, but not launched.' if mixture_justified else 'Not yet justified by the prespecified tradeoff criterion; no mixture study was launched.'}",
        "",
        "## Slurm provenance",
        "",
        f"```json\n{json.dumps(jobs, indent=2, sort_keys=True)}\n```",
    ])
    (root / "final_report.md").write_text("\n".join(lines) + "\n")
    (root / "paired_analysis/final_summary.json").write_text(
        json.dumps({"best": best, "final_paired": final, "jobs": jobs}, indent=2, sort_keys=True) + "\n"
    )
    print(root / "final_report.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
