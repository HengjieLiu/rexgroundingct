#!/usr/bin/env python3
"""Compare alignment loss with its matched lambda=0 fixed30 continuation."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--alignment-root", type=Path, required=True)
    parser.add_argument("--control-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--submit-full", action="store_true")
    parser.add_argument("--repo-root", type=Path, default=Path.cwd())
    return parser.parse_args()


def table_markdown(frame: pd.DataFrame) -> str:
    view = frame.copy()
    for col in view.select_dtypes(include="float").columns:
        view[col] = view[col].map(lambda value: f"{value:.6f}")
    header = "| " + " | ".join(view.columns) + " |"
    divider = "| " + " | ".join(["---"] * len(view.columns)) + " |"
    rows = [
        "| " + " | ".join(map(str, row)) + " |"
        for row in view.itertuples(index=False, name=None)
    ]
    return "\n".join([header, divider, *rows])


def main() -> int:
    args = parse_args()
    rows: list[pd.DataFrame] = []
    decisions = []
    for update in (250, 500):
        alignment = pd.read_csv(
            args.alignment_root / f"subset_eval_update{update}/subset_metrics.csv"
        )
        control = pd.read_csv(
            args.control_root / f"subset30_update{update}/subset_metrics.csv"
        )
        keys = ["variant", "policy", "subgroup", "findings"]
        paired = alignment.merge(
            control,
            on=keys,
            suffixes=("_alignment", "_lambda0"),
            validate="one_to_one",
        )
        paired.insert(0, "update", update)
        paired["delta_dice_alignment_vs_lambda0"] = (
            paired["mean_dice_alignment"] - paired["mean_dice_lambda0"]
        )
        paired["delta_hit_alignment_vs_lambda0"] = (
            paired["hit_count_alignment"] - paired["hit_count_lambda0"]
        )
        paired["volume_ratio_alignment_vs_lambda0"] = (
            paired["total_predicted_volume_mm3_alignment"]
            / paired["total_predicted_volume_mm3_lambda0"].replace(0, pd.NA)
        )
        rows.append(paired)
        semantic_all = paired[
            (paired["variant"] == "semantic_v1") & (paired["subgroup"] == "all")
        ].iloc[0]
        semantic_ac = paired[
            (paired["variant"] == "semantic_v1")
            & (paired["subgroup"] == "AC_alignment_eligible")
        ].iloc[0]
        meaningful = bool(
            semantic_all["delta_dice_alignment_vs_lambda0"] >= 0.002
            and semantic_ac["delta_dice_alignment_vs_lambda0"] >= 0.005
            and semantic_all["delta_hit_alignment_vs_lambda0"] >= 0
            and semantic_all["volume_ratio_alignment_vs_lambda0"] <= 1.05
        )
        decisions.append(
            {
                "update": update,
                "semantic_all_delta": float(
                    semantic_all["delta_dice_alignment_vs_lambda0"]
                ),
                "semantic_ac_delta": float(
                    semantic_ac["delta_dice_alignment_vs_lambda0"]
                ),
                "semantic_all_hit_delta": int(
                    semantic_all["delta_hit_alignment_vs_lambda0"]
                ),
                "semantic_all_volume_ratio": float(
                    semantic_all["volume_ratio_alignment_vs_lambda0"]
                ),
                "meaningful_alignment_advantage": meaningful,
            }
        )

    comparison = pd.concat(rows, ignore_index=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    comparison.to_csv(args.output_dir / "lambda0_subset30_comparison.csv", index=False)
    run_full = any(item["meaningful_alignment_advantage"] for item in decisions)
    decision = {
        "criterion": (
            "At either matched update: semantic-v1 all delta >= 0.002, "
            "semantic-v1 A+C delta >= 0.005, no semantic-v1 HIT disadvantage, "
            "and alignment/control predicted-volume ratio <= 1.05."
        ),
        "updates": decisions,
        "run_full_lambda0": run_full,
        "submitted_jobs": {},
    }

    if run_full and args.submit_full:
        wrapper = args.repo_root / "scripts/evaluate_prompt_location_full381_2gpu.sbatch"
        for update in (250, 500):
            output_dir = args.control_root / f"full381_update{update}"
            command = [
                "sbatch",
                "--parsable",
                f"--job-name=lambda0_u{update}_full381",
                "--gres=gpu:l40s:2",
                (
                    "--export=ALL,"
                    f"UPDATE={update},"
                    f"RUN_DIR={args.control_root.resolve()},"
                    f"OUTPUT_DIR={output_dir.resolve()},"
                    f"LABEL=lambda0_update{update}"
                ),
                str(wrapper.resolve()),
            ]
            job_id = subprocess.check_output(command, text=True).strip()
            decision["submitted_jobs"][f"full381_update{update}"] = job_id

    selected = comparison[
        comparison["subgroup"].isin(
            [
                "all",
                "A_explicit_exact_lobe",
                "C_laterality_only",
                "AC_alignment_eligible",
                "explicit_lobe_parser_defined",
            ]
        )
    ][
        [
            "update",
            "variant",
            "subgroup",
            "findings",
            "mean_dice_alignment",
            "mean_dice_lambda0",
            "delta_dice_alignment_vs_lambda0",
            "hit_count_alignment",
            "hit_count_lambda0",
            "delta_hit_alignment_vs_lambda0",
            "volume_ratio_alignment_vs_lambda0",
        ]
    ]
    lines = [
        "# Matched lambda=0 fixed30 comparison",
        "",
        table_markdown(selected),
        "",
        "## Task-5 decision",
        "",
        f"- Run full lambda=0 validation: **{run_full}**.",
        f"- Prespecified operational criterion: {decision['criterion']}",
        "",
        "```json",
        json.dumps(decision, indent=2),
        "```",
        "",
    ]
    (args.output_dir / "lambda0_subset30_comparison.md").write_text("\n".join(lines))
    (args.output_dir / "lambda0_subset30_decision.json").write_text(
        json.dumps(decision, indent=2) + "\n"
    )
    print(json.dumps(decision, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
