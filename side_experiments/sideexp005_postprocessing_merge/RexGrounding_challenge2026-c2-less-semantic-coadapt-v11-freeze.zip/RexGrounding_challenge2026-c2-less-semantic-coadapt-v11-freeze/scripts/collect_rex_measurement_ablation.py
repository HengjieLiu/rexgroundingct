#!/usr/bin/env python3
"""Collect and summarize the sharded ReX measurement-removal paired ablation."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--target-csv", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-shards", type=int, default=4)
    parser.add_argument("--bootstrap-samples", type=int, default=20_000)
    parser.add_argument("--seed", type=int, default=20260731)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open() as handle:
        return list(csv.DictReader(handle))


def as_bool(value: str) -> bool:
    return value.lower() == "true"


def case_bootstrap_ci(
    rows: list[dict], field: str, samples: int, seed: int
) -> tuple[float, float]:
    by_case: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        value = float(row[field])
        if np.isfinite(value):
            by_case[row["case"]].append(value)
    cases = sorted(by_case)
    sums = np.asarray([np.sum(by_case[case]) for case in cases], dtype=np.float64)
    counts = np.asarray([len(by_case[case]) for case in cases], dtype=np.float64)
    rng = np.random.default_rng(seed)
    values = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 500):
        count = min(500, samples - start)
        chosen = rng.integers(0, len(cases), size=(count, len(cases)))
        values[start : start + count] = sums[chosen].sum(axis=1) / counts[chosen].sum(axis=1)
    return tuple(float(value) for value in np.quantile(values, [0.025, 0.975]))


def paired_rows(
    raw: list[dict[str, str]], targets: dict[tuple[str, int], dict[str, str]], threshold: float
) -> list[dict]:
    lookup = {
        (row["case"], int(row["finding_idx"]), row["variant"]): row
        for row in raw
        if abs(float(row["threshold"]) - threshold) < 1e-9
    }
    result = []
    for key, target in targets.items():
        original = lookup[(*key, "original")]
        removed = lookup[(*key, "measurement_removed")]
        result.append({
            **target,
            "threshold": threshold,
            "original_dice": float(original["dice"]),
            "measurement_removed_dice": float(removed["dice"]),
            "dice_delta_removed_minus_original": float(removed["dice"]) - float(original["dice"]),
            "original_hit": as_bool(original["global_hit"]),
            "measurement_removed_hit": as_bool(removed["global_hit"]),
            "hit_delta_removed_minus_original": float(as_bool(removed["global_hit"]))
            - float(as_bool(original["global_hit"])),
            "original_ap": float(original["voxel_average_precision"]),
            "measurement_removed_ap": float(removed["voxel_average_precision"]),
            "ap_delta_removed_minus_original": float(removed["voxel_average_precision"])
            - float(original["voxel_average_precision"]),
            "original_auroc": float(original["voxel_auroc"]),
            "measurement_removed_auroc": float(removed["voxel_auroc"]),
            "original_precision": float(original["precision"]),
            "measurement_removed_precision": float(removed["precision"]),
            "original_recall": float(original["positive_recall"]),
            "measurement_removed_recall": float(removed["positive_recall"]),
            "original_pred_voxels": float(original["pred_voxels"]),
            "measurement_removed_pred_voxels": float(removed["pred_voxels"]),
            "prediction_dice_between_variants": float(
                removed["prediction_dice_vs_original_same_threshold"]
            ),
            "probability_correlation": float(removed["probability_correlation_to_original"]),
            "mean_absolute_probability_difference": float(
                removed["mean_absolute_probability_difference"]
            ),
        })
    return result


def aggregate(group: str, rows: list[dict], args: argparse.Namespace, offset: int) -> dict:
    dice_delta = np.asarray([row["dice_delta_removed_minus_original"] for row in rows])
    hit_delta = np.asarray([row["hit_delta_removed_minus_original"] for row in rows])
    ap_delta = np.asarray([row["ap_delta_removed_minus_original"] for row in rows])
    dice_ci = case_bootstrap_ci(rows, "dice_delta_removed_minus_original", args.bootstrap_samples, args.seed + offset)
    hit_ci = case_bootstrap_ci(rows, "hit_delta_removed_minus_original", args.bootstrap_samples, args.seed + 10_000 + offset)
    ap_ci = case_bootstrap_ci(rows, "ap_delta_removed_minus_original", args.bootstrap_samples, args.seed + 20_000 + offset)
    return {
        "group": group,
        "findings": len(rows),
        "cases": len({row["case"] for row in rows}),
        "original_dice": float(np.mean([row["original_dice"] for row in rows])),
        "measurement_removed_dice": float(np.mean([row["measurement_removed_dice"] for row in rows])),
        "dice_delta_removed_minus_original": float(dice_delta.mean()),
        "dice_ci95_low_case_bootstrap": dice_ci[0],
        "dice_ci95_high_case_bootstrap": dice_ci[1],
        "original_hit_rate": float(np.mean([row["original_hit"] for row in rows])),
        "measurement_removed_hit_rate": float(np.mean([row["measurement_removed_hit"] for row in rows])),
        "hit_delta_removed_minus_original": float(hit_delta.mean()),
        "hit_ci95_low_case_bootstrap": hit_ci[0],
        "hit_ci95_high_case_bootstrap": hit_ci[1],
        "original_ap": float(np.nanmean([row["original_ap"] for row in rows])),
        "measurement_removed_ap": float(np.nanmean([row["measurement_removed_ap"] for row in rows])),
        "ap_delta_removed_minus_original": float(np.nanmean(ap_delta)),
        "ap_ci95_low_case_bootstrap": ap_ci[0],
        "ap_ci95_high_case_bootstrap": ap_ci[1],
        "improved_findings": int((dice_delta > 1e-8).sum()),
        "tied_findings": int((np.abs(dice_delta) <= 1e-8).sum()),
        "worse_findings": int((dice_delta < -1e-8).sum()),
        "mean_prediction_dice_between_variants": float(
            np.mean([row["prediction_dice_between_variants"] for row in rows])
        ),
        "mean_probability_correlation": float(
            np.mean([row["probability_correlation"] for row in rows])
        ),
        "mean_absolute_probability_difference": float(
            np.mean([row["mean_absolute_probability_difference"] for row in rows])
        ),
    }


def write_rows(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    targets_list = read_csv(args.target_csv)
    targets = {(row["case"], int(row["finding_idx"])): row for row in targets_list}
    if len(targets) != 72:
        raise RuntimeError(f"Expected 72 target findings, found {len(targets)}")

    raw = []
    manifests = []
    for shard in range(args.expected_shards):
        shard_dir = args.input_dir / f"shard_{shard:02d}"
        manifests.append(json.loads((shard_dir / "manifest.json").read_text()))
        raw.extend(read_csv(shard_dir / "per_finding_threshold_metrics.csv"))
    variants = {row["variant"] for row in raw}
    if variants != {"original", "measurement_removed"}:
        raise RuntimeError(f"Unexpected variants: {sorted(variants)}")

    thresholds = sorted({float(row["threshold"]) for row in raw})
    threshold_rows = []
    all_paired = []
    for threshold_index, threshold in enumerate(thresholds):
        paired = paired_rows(raw, targets, threshold)
        all_paired.extend(paired)
        summary = aggregate(f"all_measurement_findings@{threshold:.2f}", paired, args, threshold_index)
        summary["threshold"] = threshold
        threshold_rows.append(summary)

    primary = paired_rows(raw, targets, 0.5)
    subgroups: list[tuple[str, list[dict]]] = [
        ("all", primary),
        ("category_2d", [row for row in primary if row["category"] == "2d"]),
        ("exact_3mm", [row for row in primary if as_bool(row["exact_3mm"])]),
        ("maximum_size_le_3mm", [row for row in primary if float(row["maximum_measurement_mm"]) <= 3]),
        ("maximum_size_3_to_5mm", [row for row in primary if 3 < float(row["maximum_measurement_mm"]) <= 5]),
        ("maximum_size_gt_5mm", [row for row in primary if float(row["maximum_measurement_mm"]) > 5]),
        ("fine_z_le_1mm", [row for row in primary if float(row["spacing_z_mm"]) <= 1]),
        ("coarse_z_ge_1p25mm", [row for row in primary if float(row["spacing_z_mm"]) >= 1.25]),
    ]
    subgroup_rows = [aggregate(name, rows, args, 100 + index) for index, (name, rows) in enumerate(subgroups)]

    # Non-target prompts use bitwise-identical cached embeddings and form an internal control.
    target_keys = set(targets)
    control = [
        row for row in raw
        if abs(float(row["threshold"]) - 0.5) < 1e-9
        and row["variant"] == "measurement_removed"
        and (row["case"], int(row["finding_idx"])) not in target_keys
    ]
    control_summary = {
        "findings": len(control),
        "maximum_probability_mad": max(float(row["mean_absolute_probability_difference"]) for row in control),
        "minimum_probability_correlation": min(float(row["probability_correlation_to_original"]) for row in control),
        "minimum_prediction_dice": min(float(row["prediction_dice_vs_original_same_threshold"]) for row in control),
    }

    write_rows(args.output_dir / "paired_per_finding_all_thresholds.csv", all_paired)
    write_rows(args.output_dir / "threshold_summary.csv", threshold_rows)
    write_rows(args.output_dir / "subgroup_summary_at_0p5.csv", subgroup_rows)
    summary = {
        "design": "Same CT, GT, checkpoint, threshold, and inference; only explicit numeric measurement phrases are removed.",
        "checkpoint": manifests[0]["checkpoint"],
        "target_findings": len(targets),
        "target_cases": len({key[0] for key in targets}),
        "thresholds": thresholds,
        "primary_threshold": 0.5,
        "primary": subgroup_rows[0],
        "unchanged_prompt_control": control_summary,
    }
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")

    headline = subgroup_rows[0]
    report = [
        "# ReX numeric-measurement prompt paired ablation",
        "",
        "The image, GT, frozen checkpoint, sliding-window inference, and threshold are fixed. "
        "The intervention removes only explicit numeric mm/cm measurement phrases.",
        "",
        "## Primary result at threshold 0.50",
        "",
        "| Findings | Original Dice | Measurement-removed Dice | Paired delta | Case-bootstrap 95% CI | Original hit | Removed hit | AP delta |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|",
        f"| {headline['findings']} | {headline['original_dice']:.6f} | "
        f"{headline['measurement_removed_dice']:.6f} | "
        f"{headline['dice_delta_removed_minus_original']:+.6f} | "
        f"[{headline['dice_ci95_low_case_bootstrap']:+.6f}, {headline['dice_ci95_high_case_bootstrap']:+.6f}] | "
        f"{headline['original_hit_rate']:.2%} | {headline['measurement_removed_hit_rate']:.2%} | "
        f"{headline['ap_delta_removed_minus_original']:+.6f} |",
        "",
        "## Subgroups",
        "",
        "| Group | n | Dice delta | 95% CI | Hit-rate delta | AP delta | Improved / tied / worse |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in subgroup_rows[1:]:
        report.append(
            f"| {row['group']} | {row['findings']} | {row['dice_delta_removed_minus_original']:+.6f} | "
            f"[{row['dice_ci95_low_case_bootstrap']:+.6f}, {row['dice_ci95_high_case_bootstrap']:+.6f}] | "
            f"{row['hit_delta_removed_minus_original']:+.2%} | {row['ap_delta_removed_minus_original']:+.6f} | "
            f"{row['improved_findings']} / {row['tied_findings']} / {row['worse_findings']} |"
        )
    report.extend([
        "",
        "## Internal unchanged-prompt control",
        "",
        f"- Findings: {control_summary['findings']}",
        f"- Maximum probability MAD: {control_summary['maximum_probability_mad']:.9g}",
        f"- Minimum probability correlation: {control_summary['minimum_probability_correlation']:.9g}",
        f"- Minimum binary prediction Dice: {control_summary['minimum_prediction_dice']:.9g}",
        "",
    ])
    (args.output_dir / "report.md").write_text("\n".join(report))
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
