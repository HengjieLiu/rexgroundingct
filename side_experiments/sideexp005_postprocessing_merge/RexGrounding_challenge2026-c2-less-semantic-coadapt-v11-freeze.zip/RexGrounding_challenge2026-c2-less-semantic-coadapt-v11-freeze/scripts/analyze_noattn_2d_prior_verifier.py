#!/usr/bin/env python3
"""Prior learnability, component verification, and five-fold cross-fit analysis."""

from __future__ import annotations

import argparse
import json
import math
import shutil
import sys
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd
from scipy import ndimage
from scipy.spatial import cKDTree
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import analyze_2d_s3prior_component_verifier as verifier  # noqa: E402

OUT = ROOT / "outputs/2d_noattn_prior_verifier_feasibility"
MANIFEST = ROOT / "outputs/s3_2d_specialist_fast_comparison/full381_category_2d_manifest.json"
BASE_SEG = ROOT / "outputs/nonattention_baseline_selection/full381_update10000"
BASE_METRICS = BASE_SEG / "summary_tables/per_finding_metrics.csv"
S3_PREVIOUS = ROOT / "outputs/2d_s3prior_component_verifier_feasibility"
GT_DIR = ROOT / "data/segmentations"
CT_DIR = ROOT / "data/ct_rate_volumes_fixed"
STRUCTURE = ndimage.generate_binary_structure(3, 3)
SCORES = ["s_max", "s_top1", "s_top5", "s_mean", "s_mass_density"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--oldloss-maps", type=Path, required=True)
    parser.add_argument("--component-maps", type=Path, required=True)
    return parser.parse_args()


def write_json(name: str, payload: object) -> None:
    (OUT / name).write_text(json.dumps(payload, indent=2, default=str) + "\n")


def sampled_auc(score: np.ndarray, target: np.ndarray) -> tuple[float, float, float]:
    step = max(1, math.ceil(score.size / 2_000_000))
    x = score.reshape(-1)[::step]
    y = target.reshape(-1)[::step].astype(np.uint8)
    prevalence = float(y.mean())
    if len(np.unique(y)) < 2:
        return float("nan"), float("nan"), prevalence
    return float(roc_auc_score(y, x)), float(average_precision_score(y, x)), prevalence


def prior_metrics(prior: np.ndarray, target: np.ndarray, spacing: np.ndarray) -> tuple[dict, list[dict]]:
    auroc, auprc, prevalence = sampled_auc(prior, target)
    peak = np.asarray(np.unravel_index(int(prior.argmax()), prior.shape))
    tree = cKDTree(np.argwhere(target).astype(np.float64) * spacing)
    peak_distance = float(tree.query(peak.astype(np.float64) * spacing, k=1)[0])
    gt_voxels = int(target.sum())
    indices = np.argpartition(prior.reshape(-1), -gt_voxels)[-gt_voxels:]
    selected = np.zeros(prior.size, dtype=bool)
    selected[indices] = True
    selected = selected.reshape(prior.shape)
    labels, count = ndimage.label(target, structure=STRUCTURE)
    component_rows = []
    covered = 0
    coverage = {value: 0 for value in (0.1, 0.25, 0.5)}
    for component_id in range(1, count + 1):
        component = labels == component_id
        topk = bool((selected & component).any())
        covered += int(topk)
        row = {"component_id": component_id, "voxels": int(component.sum()), "below_1000": int(component.sum()) < 1000, "topk_covered": topk}
        for threshold in coverage:
            hit = bool((prior[component] >= threshold).any())
            coverage[threshold] += int(hit)
            row[f"covered_{threshold}"] = hit
        component_rows.append(row)
    return {
        "voxel_AUROC": auroc,
        "voxel_AUPRC": auprc,
        "foreground_prevalence": prevalence,
        "AUPRC_over_prevalence": auprc / max(prevalence, 1e-12),
        "peak_in_GT": bool(target[tuple(peak)]),
        "peak_to_GT_distance_mm": peak_distance,
        "GT_sized_topk_precision": float(target.reshape(-1)[indices].mean()),
        "GT_sized_topk_component_recall": covered / max(count, 1),
        "component_coverage_0.1": coverage[0.1] / max(count, 1),
        "component_coverage_0.25": coverage[0.25] / max(count, 1),
        "component_coverage_0.5": coverage[0.5] / max(count, 1),
        "GT_component_count": count,
        "prior_mean": float(prior.mean()),
        "prior_std": float(prior.std()),
        "prior_max": float(prior.max()),
        "peak_xyz": json.dumps(peak.tolist()),
    }, component_rows


def load_map(directory: Path, file: str, finding: int) -> np.ndarray:
    path = directory / f"{file.removesuffix('.nii.gz')}_finding_{finding}.npz"
    with np.load(path, allow_pickle=False) as archive:
        return archive["prior"].astype(np.float32)


def component_score_rows(
    arm: str, item: dict, prior: np.ndarray, prediction: np.ndarray,
    target: np.ndarray, spacing: np.ndarray, reference: pd.Series,
) -> list[dict]:
    labels, count = ndimage.label(prediction, structure=STRUCTURE)
    objects = ndimage.find_objects(labels)
    gt_labels, gt_count = ndimage.label(target, structure=STRUCTURE)
    del gt_labels
    peak = np.asarray(np.unravel_index(int(prior.argmax()), prior.shape), dtype=np.float64)
    gt_tree = cKDTree(np.argwhere(target).astype(np.float64) * spacing)
    rows = []
    for component_id, obj in enumerate(objects, 1):
        if obj is None:
            continue
        local = labels[obj] == component_id
        values = prior[obj][local]
        voxels = int(local.sum())
        overlap = int(target[obj][local].sum())
        starts = np.asarray([axis.start for axis in obj])
        coords = np.argwhere(local) + starts
        if overlap:
            nearest = 0.0
        else:
            nearest = float(gt_tree.query(coords * spacing, k=1, workers=1)[0].min())
        distance_peak = float(np.sqrt(np.square((coords - peak) * spacing).sum(1).min()))
        rows.append({
            "arm": arm, **item, "small_2d": item["pixels"] < 1000,
            "gt_component_count": gt_count, "original_hit": bool(reference.global_hit),
            "original_dice": float(reference.global_dice),
            "original_fp_gt": float(reference.fp_voxels / max(reference.gt_voxels, 1)),
            "component_id": component_id, "component_voxels": voxels,
            "physical_volume_mm3": float(voxels * np.prod(spacing)),
            "gt_overlap_positive": overlap > 0,
            "overlap_dice_with_gt": 2 * overlap / max(voxels + int(target.sum()), 1),
            "overlap_voxels": overlap, "distance_to_nearest_gt_mm": nearest,
            "s_max": float(values.max()), "s_top1": verifier.top_mean(values, .01),
            "s_top5": verifier.top_mean(values, .05), "s_mean": float(values.mean()),
            "s_mass": float(values.sum(dtype=np.float64)),
            "s_mass_density": float(values.mean()),
            "prior_peak_distance_mm": distance_peak,
            "seg_probability_available": False, "seg_mean": 1.0,
            "seg_log_volume": float(np.log1p(voxels)),
        })
    if count != len(rows):
        raise RuntimeError("Predicted component extraction lost components")
    return rows


def aggregate_prior(frame: pd.DataFrame, components: pd.DataFrame) -> dict:
    result = {}
    masks = {
        "all_2d": np.ones(len(frame), dtype=bool), "small_2d": frame.small_2d,
        "other_2d": ~frame.small_2d, "single_component": frame.GT_component_count == 1,
        "multi_component": frame.GT_component_count > 1,
    }
    metrics = ["voxel_AUROC", "voxel_AUPRC", "AUPRC_over_prevalence", "peak_in_GT", "peak_to_GT_distance_mm", "GT_sized_topk_precision", "GT_sized_topk_component_recall", "component_coverage_0.1", "component_coverage_0.25", "component_coverage_0.5"]
    for name, mask in masks.items():
        group = frame.loc[mask]
        result[name] = {"n": len(group), **{key: float(group[key].mean()) for key in metrics}}
    small_components = components[components.below_1000]
    result["components_below_1000"] = {
        "n": len(small_components),
        "GT_sized_topk_component_recall": float(small_components.topk_covered.mean()),
        "coverage_0.1": float(small_components["covered_0.1"].mean()),
    }
    return result


def finding_table(metrics: pd.DataFrame) -> pd.DataFrame:
    return metrics.rename(columns={
        "global_dice": "original_dice", "global_hit": "original_hit",
        "tp_voxels": "original_tp", "fp_voxels": "original_fp",
        "fn_voxels": "original_fn", "pred_voxels": "original_pred_voxels",
    }).assign(
        small_2d=lambda d: d.pixels < 1000,
        original_fp_gt=lambda d: d.original_fp / d.gt_voxels.clip(lower=1),
        gt_component_count=1,
        rescuable=lambda d: d.original_tp > 0,
    )[["file", "finding_idx", "pixels", "small_2d", "gt_voxels", "gt_component_count", "original_dice", "original_hit", "original_tp", "original_fp", "original_fn", "original_pred_voxels", "original_fp_gt", "rescuable"]]


def summarize_subset(candidate: pd.DataFrame, reference: pd.DataFrame) -> dict:
    current = candidate.set_index(["file", "finding_idx"])
    base = reference.set_index(["file", "finding_idx"]).loc[current.index]
    delta = current.dice - base.dice
    return {
        "n": len(current), "mean_dice": float(current.dice.mean()),
        "dice_delta": float(delta.mean()), "hits": int(current.hit.sum()),
        "hit_delta": int(current.hit.sum() - base.hit.sum()),
        "small_hits_delta": int(current.loc[current.small_2d, "hit"].sum() - base.loc[base.small_2d, "hit"].sum()),
        "small_dice_delta": float((current.loc[current.small_2d, "dice"] - base.loc[base.small_2d, "dice"]).mean()),
        "FP_GT_delta": float((current.FP_GT - base.FP_GT).mean()),
        "precision_delta": float((current.precision - base.precision).mean()),
        "recall_delta": float((current.recall - base.recall).mean()),
    }


def crossfit(per: pd.DataFrame, seed: int = 260811) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    cases = np.asarray(sorted(per.file.unique()))
    rng = np.random.default_rng(seed)
    rng.shuffle(cases)
    folds = {case: index % 5 for index, case in enumerate(cases)}
    original = per[per.strategy == "original"].copy()
    selected_rows, held_rows = [], []
    complexity = {name: index for index, name in enumerate(sorted(per.strategy.unique()))}
    for fold in range(5):
        test_cases = {case for case, value in folds.items() if value == fold}
        train = per[~per.file.isin(test_cases)]
        train_ref = train[train.strategy == "original"]
        evaluations = []
        for strategy, group in train[train.strategy != "original"].groupby("strategy"):
            stats = summarize_subset(group, train_ref)
            stats["strategy"] = strategy
            stats["selection_score"] = stats["dice_delta"] + min(0.0, stats["recall_delta"]) * 0.10
            evaluations.append(stats)
        table = pd.DataFrame(evaluations)
        safe = table[(table.hit_delta >= 0) & (table.small_hits_delta >= 0)]
        pool = safe if len(safe) else table
        pool = pool.assign(complexity=pool.strategy.map(complexity)).sort_values(
            ["selection_score", "complexity"], ascending=[False, True]
        )
        chosen = str(pool.iloc[0].strategy)
        selected_rows.append({"fold": fold, "selected_strategy": chosen, "training_safe_candidate_available": bool(len(safe)), **{f"training_{k}": v for k, v in pool.iloc[0].to_dict().items() if k not in {"strategy", "complexity"}}})
        block = per[(per.file.isin(test_cases)) & (per.strategy == chosen)].copy()
        block["fold"] = fold
        block["selected_strategy"] = chosen
        held_rows.append(block)
    held = pd.concat(held_rows, ignore_index=True)
    combined = summarize_subset(held, original)
    return held, pd.DataFrame(selected_rows), combined


def main() -> int:
    args = parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy2(OUT / "oldloss/training_metrics.csv", OUT / "oldloss_training_log.csv")
    shutil.copy2(OUT / "component/training_metrics.csv", OUT / "component_treatment_training_log.csv")
    entries = verifier.flatten_manifest(MANIFEST)
    references = verifier.load_reference_metrics(BASE_METRICS, entries)
    metric_table = pd.read_csv(BASE_METRICS)
    wanted = {(x["file"], x["finding_idx"]) for x in entries}
    metric_table = metric_table[[tuple(x) in wanted for x in metric_table[["file", "finding_idx"]].itertuples(index=False, name=None)]].copy()
    findings = finding_table(metric_table)
    finding_lookup = findings.set_index(["file", "finding_idx"])
    arms = {"oldloss": args.oldloss_maps, "component": args.component_maps}
    component_tables, prior_tables, component_prior_rows = {}, {}, {}
    sanity = []
    for arm, directory in arms.items():
        prior_rows, gt_component_rows, score_rows = [], [], []
        for item_index, item in enumerate(entries):
            gt_img = nib.load(str(GT_DIR / item["file"]))
            pred_img = nib.load(str(BASE_SEG / item["file"]))
            ct_img = nib.load(str(CT_DIR / item["file"]))
            target = np.asarray(np.asanyarray(gt_img.dataobj[item["finding_idx"]]) > 0)
            prediction = np.asarray(np.asanyarray(pred_img.dataobj[item["finding_idx"]]) > 0)
            prior = load_map(directory, item["file"], item["finding_idx"])
            if not (target.shape == prediction.shape == prior.shape == ct_img.shape):
                raise RuntimeError(f"Grid mismatch: {arm} {item}")
            spacing = np.asarray(nib.affines.voxel_sizes(ct_img.affine))
            metrics, components = prior_metrics(prior, target, spacing)
            prior_rows.append({"arm": arm, **item, "small_2d": item["pixels"] < 1000, **metrics})
            for row in components:
                gt_component_rows.append({"arm": arm, **item, **row})
            ref = references.loc[(item["file"], item["finding_idx"])]
            score_rows.extend(component_score_rows(arm, item, prior, prediction, target, spacing, ref))
            if arm == "component" and len(sanity) < 8:
                peak = np.asarray(np.unravel_index(int(prior.argmax()), prior.shape))
                tree = cKDTree(np.argwhere(target) * spacing)
                sanity.append({"file": item["file"], "finding_idx": item["finding_idx"], "GT_bbox_xyz": verifier.bbox(target), "baseline_segmentation_bbox_xyz": verifier.bbox(prediction), "prior_peak_xyz": peak.tolist(), "prior_peak_to_GT_mm": float(tree.query(peak * spacing)[0]), "shape_xyz": list(target.shape), "same_grid": True})
        prior_frame = pd.DataFrame(prior_rows)
        component_frame = pd.DataFrame(gt_component_rows)
        score_frame = pd.DataFrame(score_rows)
        prior_frame.to_csv(OUT / f"prior_only_metrics_{arm}.csv", index=False)
        score_frame.to_csv(OUT / f"component_scores_{arm}_prior.csv", index=False)
        prior_tables[arm] = prior_frame
        component_tables[arm] = component_frame
        component_prior_rows[arm] = score_frame
    write_json("prior_only_metrics_summary.json", {arm: aggregate_prior(prior_tables[arm], component_tables[arm]) for arm in arms})
    write_json("coordinate_sanity_check.json", {"status": "pass", "checks": sanity})
    write_json("prior_map_generation_summary.json", {arm: {"maps": len(list(directory.glob("*.npz"))), "manifest": str(directory.parent / "prior_map_manifest.json")} for arm, directory in arms.items()})

    base_table = component_prior_rows["component"].drop(columns=[c for c in component_prior_rows["component"].columns if c.startswith("s_") or c == "prior_peak_distance_mm"])
    base_table.to_csv(OUT / "baseline_component_table.csv", index=False)
    previous_s3 = pd.read_csv(S3_PREVIOUS / "baseline_seg_prior_component_scores.csv")
    s3 = previous_s3.rename(columns={"source": "arm"}).assign(arm="s3_prior")
    s3.to_csv(OUT / "component_scores_s3prior_comparison.csv", index=False)
    comparison = {**component_prior_rows, "s3_prior": s3}

    ranking_rows, subgroup_rows = [], []
    for arm, frame in comparison.items():
        q75 = float(frame.original_fp_gt.quantile(.75))
        for score in [*SCORES, "s_mass", "seg_log_volume"]:
            ranking_rows.append({"arm": arm, "score": score, "subgroup": "all_2d", **verifier.ranking_metrics(frame, score, 132)})
            masks = {"small_2d": frame.small_2d, "other_2d": ~frame.small_2d, "single_GT_component": frame.gt_component_count == 1, "multi_GT_component": frame.gt_component_count > 1, "high_FP_burden": frame.original_fp_gt >= q75, "baseline_hit": frame.original_hit, "baseline_miss": ~frame.original_hit}
            for subgroup, mask in masks.items():
                block = frame.loc[mask]
                n_findings = len(block[["file", "finding_idx"]].drop_duplicates())
                subgroup_rows.append({"arm": arm, "score": score, "subgroup": subgroup, **verifier.ranking_metrics(block, score, n_findings)})
    ranking = pd.DataFrame(ranking_rows)
    ranking.to_csv(OUT / "component_ranking_summary.csv", index=False)
    pd.DataFrame(subgroup_rows).to_csv(OUT / "component_ranking_by_subgroup.csv", index=False)

    all_per, all_summary = [], []
    strategy_by_arm = {}
    for arm, frame in comparison.items():
        per = verifier.build_strategies(frame, findings.assign(source=arm))
        per["arm"] = arm
        summary = verifier.strategy_summary(per)
        summary["arm"] = arm
        all_per.append(per); all_summary.append(summary); strategy_by_arm[arm] = per
    same_per = pd.concat(all_per, ignore_index=True)
    same_summary = pd.concat(all_summary, ignore_index=True)
    same_per.to_csv(OUT / "mask_strategy_per_finding_same_cohort.csv", index=False)
    same_summary.to_csv(OUT / "mask_strategy_summary_same_cohort.csv", index=False)

    held, selections, cross_summary = crossfit(strategy_by_arm["component"])
    held.to_csv(OUT / "crossfit_per_finding.csv", index=False)
    selections.to_csv(OUT / "crossfit_selected_strategies.csv", index=False)
    write_json("crossfit_strategy_summary.json", cross_summary)

    # Reuse the coordinate-corrected baseline oracle, which is based on the same
    # exact masks and component definition, and verify its raw reference here.
    oracle = json.loads((S3_PREVIOUS / "oracle_upper_bound_summary.json").read_text())["baseline_seg"]
    if abs(float(oracle["unmodified_mean_dice"]) - float(metric_table.global_dice.mean())) > 2e-6:
        raise RuntimeError("Baseline oracle provenance mismatch")
    write_json("oracle_upper_bound_summary.json", oracle)

    treatment_summary = same_summary[(same_summary.arm == "component") & (same_summary.stratum == "all_2d") & (same_summary.strategy != "original")]
    safe = treatment_summary[(treatment_summary.hit_delta >= 0) & (treatment_summary.strategy.str.startswith("prune_"))]
    best = (safe if len(safe) else treatment_summary).sort_values("dice_delta", ascending=False).iloc[0]
    best_name = str(best.strategy)
    original = strategy_by_arm["component"][strategy_by_arm["component"].strategy == "original"]
    best_frame = strategy_by_arm["component"][strategy_by_arm["component"].strategy == best_name]
    bootstrap_rows = []
    for label, candidate in [("same_cohort_best", best_frame), ("crossfit", held)]:
        for stratum, mask in [("all_2d", np.ones(len(candidate), bool)), ("small_2d", candidate.small_2d.to_numpy(bool))]:
            cand = candidate.iloc[np.flatnonzero(mask)]
            keys = set(map(tuple, cand[["file", "finding_idx"]].itertuples(index=False, name=None)))
            ref = original[[tuple(x) in keys for x in original[["file", "finding_idx"]].itertuples(index=False, name=None)]]
            bootstrap_rows.append({"analysis": label, "strategy": best_name if label == "same_cohort_best" else "5fold_crossfit", "stratum": stratum, **verifier.bootstrap(cand, ref, 260811 + len(bootstrap_rows))})
    pd.DataFrame(bootstrap_rows).to_csv(OUT / "bootstrap_results.csv", index=False)
    merged = original.merge(best_frame, on=["file", "finding_idx"], suffixes=("_reference", "_candidate"), validate="one_to_one")
    influence = []
    for case in sorted(merged.file.unique()):
        keep = merged.file != case
        influence.append({"left_out_case": case, "dice_delta": float((merged.loc[keep, "dice_candidate"] - merged.loc[keep, "dice_reference"]).mean())})
    pd.DataFrame(influence).to_csv(OUT / "leave_one_case_out.csv", index=False)

    best_rank = {}
    for arm in comparison:
        block = ranking[(ranking.arm == arm) & ranking.score.isin(SCORES)]
        row = block.sort_values("component_AUPRC", ascending=False).iloc[0]
        best_rank[arm] = {"score": row.score, "component_AUPRC": float(row.component_AUPRC), "component_AUROC": float(row.component_AUROC), "top1_recall": float(row.top1_recall_rescuable)}
    volume_auprc = float(ranking[(ranking.arm == "component") & (ranking.score == "seg_log_volume")].iloc[0].component_AUPRC)
    rank_positive = best_rank["component"]["component_AUPRC"] > max(best_rank["oldloss"]["component_AUPRC"], best_rank["s3_prior"]["component_AUPRC"], volume_auprc)
    cross_positive = cross_summary["dice_delta"] > 0 and cross_summary["hit_delta"] >= 0 and cross_summary["small_hits_delta"] >= 0
    if rank_positive and cross_positive:
        classification = "A. NOATTN PRIOR VERIFIER IS PROMISING AND CROSS-FIT POSITIVE"
    elif rank_positive and not cross_positive:
        classification = "B. NOATTN PRIOR HAS RANKING SIGNAL BUT MASK-LEVEL PRUNING STILL UNSAFE"
    elif best_rank["component"]["component_AUPRC"] <= best_rank["s3_prior"]["component_AUPRC"]:
        classification = "C. NOATTN PRIOR DOES NOT IMPROVE OVER S3 PRIOR"
    elif float(best.dice_delta) > 0 and not cross_positive:
        classification = "D. PRIOR SIGNAL EXISTS ONLY AS SAME-COHORT OVERFIT"
    else:
        classification = "E. PRIOR HEAD LEARNS LOCALIZATION BUT NOT COMPONENT VERIFICATION"
    decision = {"classification": classification, "best_component_ranking": best_rank, "volume_comparator_AUPRC": volume_auprc, "same_cohort_best_strategy": best_name, "same_cohort_best_dice_delta": float(best.dice_delta), "crossfit": cross_summary, "ranking_rule_pass": rank_positive, "crossfit_rule_pass": cross_positive, "recommendation": "pre-specified/cross-fitted no-attention verifier policy" if classification.startswith("A.") else "do not continue this verifier design automatically"}
    write_json("decision.json", decision)
    report = f"""# No-attention category-2d prior verifier

## 1. Prior-only learnability

Treatment versus old-loss metrics are in `prior_only_metrics_summary.json`.

## 2. Component-ranking audit

Best AUPRC: old-loss={best_rank['oldloss']['component_AUPRC']:.6f}, component-treatment={best_rank['component']['component_AUPRC']:.6f}, existing S3 prior={best_rank['s3_prior']['component_AUPRC']:.6f}, volume comparator={volume_auprc:.6f}.

## 3. Same-cohort feasibility

Best conservative treatment strategy: `{best_name}`, Dice delta={float(best.dice_delta):+.6f}, hit delta={int(best.hit_delta)}. This is validation-tuned and not deployable evidence.

## 4. Five-fold cross-fit

Dice delta={cross_summary['dice_delta']:+.6f}; small-2d delta={cross_summary['small_dice_delta']:+.6f}; hits={cross_summary['hit_delta']:+d}; small hits={cross_summary['small_hits_delta']:+d}; FP/GT delta={cross_summary['FP_GT_delta']:+.6f}.

## 5. Existing S3-prior comparison

The S3 comparison reuses coordinate-corrected component scores from `{S3_PREVIOUS}`.

## 6. Decision

**{classification}**

Recommendation: {decision['recommendation']}.
"""
    (OUT / "report.md").write_text(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
