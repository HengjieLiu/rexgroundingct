#!/usr/bin/env python3
"""Fail-closed initialization and smoke audit for the common-init pilot."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import subprocess
from pathlib import Path
from typing import Any

import torch


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EXP = ROOT / "outputs/token_attention_common_init_pilot"
ARMS = ("B0_original", "A1_replace", "A2_FAN")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text())


def read_history(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def load_weights(path: Path) -> tuple[dict[str, torch.Tensor], dict[str, Any]]:
    payload = torch.load(path, map_location="cpu", mmap=True, weights_only=False)
    return payload["network_weights"], payload


def tensor_delta_summary(
    before: dict[str, torch.Tensor],
    after: dict[str, torch.Tensor],
    prefix: str,
) -> dict[str, Any]:
    names = sorted(name for name in before if name.startswith(prefix))
    changed = 0
    squared = 0.0
    max_abs = 0.0
    for name in names:
        delta = after[name].float() - before[name].float()
        if bool(torch.count_nonzero(delta).item()):
            changed += 1
        squared += float(delta.square().sum().item())
        max_abs = max(max_abs, float(delta.abs().max().item()))
    return {
        "prefix": prefix,
        "tensor_count": len(names),
        "changed_tensor_count": changed,
        "delta_l2": math.sqrt(squared),
        "delta_max_abs": max_abs,
    }


def compare_common_weights(
    reference: dict[str, torch.Tensor],
    candidate: dict[str, torch.Tensor],
    allowed_new_prefixes: tuple[str, ...],
) -> dict[str, Any]:
    missing = sorted(set(reference) - set(candidate))
    unexpected = sorted(
        name
        for name in set(candidate) - set(reference)
        if not name.startswith(allowed_new_prefixes)
    )
    new = sorted(set(candidate) - set(reference))
    unequal: list[str] = []
    for name in sorted(set(reference) & set(candidate)):
        if reference[name].shape != candidate[name].shape or not torch.equal(
            reference[name], candidate[name]
        ):
            unequal.append(name)
    return {
        "status": "pass" if not (missing or unexpected or unequal) else "fail",
        "reference_tensors": len(reference),
        "candidate_tensors": len(candidate),
        "missing": missing,
        "unexpected_not_allowed": unexpected,
        "unequal_common_tensors": unequal,
        "new_tensor_count": len(new),
        "new_prefixes": sorted({name.split(".", 1)[0] for name in new}),
    }


def optimizer_audit(path: Path, expected_special_group: str | None) -> dict[str, Any]:
    payload = read_json(path)
    names = [row["name"] for row in payload["group_summaries"]]
    status = payload.get("status") == "pass"
    if expected_special_group is not None:
        status = status and names.count(expected_special_group) == 1
    return {
        "status": "pass" if status else "fail",
        "group_names": names,
        "group_summaries": payload["group_summaries"],
        "missing_trainable_parameters": payload["missing_trainable_parameters"],
        "duplicated_trainable_parameters": payload["duplicated_trainable_parameters"],
    }


def source_revision(path: Path) -> str | None:
    try:
        return subprocess.check_output(
            ["git", "-C", str(path), "rev-parse", "HEAD"], text=True
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--exp", type=Path, default=DEFAULT_EXP)
    parser.add_argument("--stage", choices=("initial", "smoke"), required=True)
    args = parser.parse_args()
    exp = args.exp.resolve()
    audit_dir = exp / "audits"
    audit_dir.mkdir(parents=True, exist_ok=True)

    canonical_path = ROOT / "VoxTell/voxtell_v1.1/fold_0/checkpoint_final.pth"
    plans_path = ROOT / "VoxTell/voxtell_v1.1/plans.json"
    canonical, canonical_payload = load_weights(canonical_path)
    info_path = ROOT / "VoxTell/voxtell_v1.1/fold_0/INFO.txt"
    lineage_args_path = (
        ROOT / "outputs/voxtell_v11_e1e-5_d1e-4_1gpu_bs1_acc4_10kupd/args.json"
    )
    output: dict[str, Any] = {
        "stage": args.stage,
        "canonical_checkpoint": str(canonical_path),
        "canonical_checkpoint_sha256": sha256(canonical_path),
        "canonical_checkpoint_size_bytes": canonical_path.stat().st_size,
        "canonical_checkpoint_mtime_ns": canonical_path.stat().st_mtime_ns,
        "canonical_checkpoint_top_level_keys": sorted(canonical_payload.keys()),
        "canonical_checkpoint_has_optimizer": "optimizer" in canonical_payload,
        "canonical_info_file": str(info_path),
        "canonical_info": info_path.read_text().strip(),
        "canonical_lineage_args": str(lineage_args_path),
        "canonical_lineage_args_sha256": sha256(lineage_args_path),
        "plans": str(plans_path),
        "plans_sha256": sha256(plans_path),
        "root_git_revision": source_revision(ROOT),
        "voxtell_git_revision": source_revision(ROOT / "VoxTell"),
        "hierarchy": [
            {"level": 3, "channels": 256, "shape": [24, 24, 24], "image_tokens": 13824},
            {"level": 4, "channels": 320, "shape": [12, 12, 12], "image_tokens": 1728},
            {"level": 5, "channels": 320, "shape": [6, 6, 6], "image_tokens": 216},
        ],
        "selected_fan_levels": [4, 5],
        "level3_exclusion": (
            "24^3=13,824 image tokens makes joint self-attention 191,102,976 "
            "image-image pairs per head before word tokens; this is outside the "
            "lightweight pilot memory budget."
        ),
        "arms": {},
        "failures": [],
    }
    initial_weights: dict[str, dict[str, torch.Tensor]] = {}
    allowed = {
        "B0_original": (),
        "A1_replace": ("token_image_text_block.",),
        "A2_FAN": ("fan_image_text_blocks.",),
    }
    expected_group = {
        "B0_original": None,
        "A1_replace": "token_image_text",
        "A2_FAN": "fan_image_text",
    }
    for arm in ARMS:
        run_dir = exp / "initial" / arm
        checkpoint_path = run_dir / "checkpoints/checkpoint_initial.pth"
        weights, checkpoint = load_weights(checkpoint_path)
        initial_weights[arm] = weights
        comparison = compare_common_weights(canonical, weights, allowed[arm])
        optimizer = optimizer_audit(
            run_dir / "optimizer_group_audit.json", expected_group[arm]
        )
        config = checkpoint.get("experimental_model_config", {})
        arm_payload = {
            "checkpoint": str(checkpoint_path),
            "checkpoint_sha256": sha256(checkpoint_path),
            "common_weight_comparison": comparison,
            "optimizer": optimizer,
            "trainable_info": checkpoint.get("trainable_info", {}),
            "experimental_model_config": config,
        }
        output["arms"][arm] = arm_payload
        if comparison["status"] != "pass":
            output["failures"].append(f"{arm}: common weights differ")
        if optimizer["status"] != "pass":
            output["failures"].append(f"{arm}: optimizer coverage")

    # Cross-arm base weights must be bitwise identical, not merely compatible.
    for arm in ARMS[1:]:
        result = compare_common_weights(
            initial_weights["B0_original"], initial_weights[arm], allowed[arm]
        )
        output["arms"][arm]["cross_arm_vs_B0"] = result
        if result["status"] != "pass":
            output["failures"].append(f"{arm}: cross-arm initialization mismatch")

    if args.stage == "smoke":
        trace_hashes: dict[str, str] = {}
        for arm in ARMS:
            run_dir = exp / "smoke" / arm
            trace_hashes[arm] = sha256(run_dir / "sampler_trace_rank0.jsonl")
            records = read_history(run_dir / "history.jsonl")
            trained = [row for row in records if int(row.get("optimizer_update", 0)) > 0]
            finite_loss = all(
                math.isfinite(float(row.get("total_loss", float("nan"))))
                for row in trained
            )
            gradients = {
                key: [float(row.get(key, 0.0)) for row in trained]
                for key in (
                    "grad_norm_token_image_text_q",
                    "grad_norm_token_image_text_k",
                    "grad_norm_token_image_text_v",
                    "grad_norm_token_image_text_out",
                    "grad_norm_fan_image_text",
                    "grad_norm_fan_level4",
                    "grad_norm_fan_level5",
                    "grad_norm_fan_level4_joint_attention",
                    "grad_norm_fan_level4_cross_attention",
                    "grad_norm_fan_level5_joint_attention",
                    "grad_norm_fan_level5_cross_attention",
                )
            }
            initial, _ = load_weights(run_dir / "checkpoints/checkpoint_initial.pth")
            final, _ = load_weights(run_dir / "checkpoints/checkpoint_update_20.pth")
            prefixes = []
            if arm == "B0_original":
                prefixes = ["decoder."]
            elif arm == "A1_replace":
                prefixes = [
                    "token_image_text_block.q_proj.",
                    "token_image_text_block.k_proj.",
                    "token_image_text_block.v_proj.",
                    "token_image_text_block.out_proj.",
                ]
            elif arm == "A2_FAN":
                prefixes = [
                    "fan_image_text_blocks.level4.joint_attention.",
                    "fan_image_text_blocks.level4.cross_attention.",
                    "fan_image_text_blocks.level5.joint_attention.",
                    "fan_image_text_blocks.level5.cross_attention.",
                ]
            deltas = [tensor_delta_summary(initial, final, prefix) for prefix in prefixes]
            final_record = trained[-1]
            fan_audits = final_record.get("fan_image_text_audits", {})
            special_gradient_ok = all(
                math.isfinite(float(row.get("grad_norm", float("nan"))))
                and float(row.get("grad_norm", 0.0)) > 0
                for row in trained
                if bool(row.get("optimizer_step_performed"))
            )
            no_amp_skips = not any(bool(row.get("amp_step_skipped")) for row in trained)
            if arm == "A1_replace":
                special_gradient_ok = special_gradient_ok and all(
                    any(value > 0 for value in gradients[key])
                    for key in (
                        "grad_norm_token_image_text_q",
                        "grad_norm_token_image_text_k",
                        "grad_norm_token_image_text_v",
                        "grad_norm_token_image_text_out",
                    )
                )
                special_gradient_ok = special_gradient_ok and int(
                    final_record.get("original_cross_attention_forward_count", -1)
                ) == 0
                special_gradient_ok = special_gradient_ok and any(
                    float(row.get("train_pred_voxels", 0.0)) > 0 for row in trained
                )
            elif arm == "A2_FAN":
                special_gradient_ok = special_gradient_ok and all(
                    any(value > 0 for value in gradients[key])
                    for key in (
                        "grad_norm_fan_level4_joint_attention",
                        "grad_norm_fan_level4_cross_attention",
                        "grad_norm_fan_level5_joint_attention",
                        "grad_norm_fan_level5_cross_attention",
                    )
                )
                special_gradient_ok = special_gradient_ok and set(fan_audits) == {
                    "level4", "level5"
                }
                special_gradient_ok = special_gradient_ok and int(
                    final_record.get("original_cross_attention_forward_count", 0)
                ) > 0
                special_gradient_ok = special_gradient_ok and all(
                    list(audit.get("output_feature_shape", []))[1:3]
                    == [3, 320]
                    and float(audit.get("cosine_before_after", 1.0)) < 0.999999
                    and float(audit.get("feature_rms_ratio", 0.0)) > 0
                    for audit in fan_audits.values()
                )
            changed_ok = all(row["changed_tensor_count"] > 0 for row in deltas)
            status = finite_loss and special_gradient_ok and changed_ok and no_amp_skips
            smoke_payload = {
                "status": "pass" if status else "fail",
                "trained_records": len(trained),
                "last_optimizer_update": int(final_record["optimizer_update"]),
                "finite_losses": finite_loss,
                "amp_step_skips": sum(
                    int(bool(row.get("amp_step_skipped"))) for row in trained
                ),
                "gradients": gradients,
                "parameter_deltas": deltas,
                "fan_audits": fan_audits,
                "original_cross_attention_forward_count": int(
                    final_record.get("original_cross_attention_forward_count", 0)
                ),
                "peak_allocated_gib": max(
                    float(row.get("gpu_peak_allocated_gib") or 0.0) for row in trained
                ),
                "peak_reserved_gib": max(
                    float(row.get("gpu_peak_reserved_gib") or 0.0) for row in trained
                ),
                "mean_iteration_seconds": sum(
                    float(row["iteration_seconds"]) for row in trained
                ) / len(trained),
            }
            output["arms"][arm]["smoke"] = smoke_payload
            if not status:
                output["failures"].append(f"{arm}: smoke gate")
        output["sampler_trace_sha256"] = trace_hashes
        output["sampler_traces_identical"] = len(set(trace_hashes.values())) == 1
        if not output["sampler_traces_identical"]:
            output["failures"].append("sampler traces differ across arms")

    output["status"] = "pass" if not output["failures"] else "fail"
    destination = audit_dir / f"{args.stage}_gate.json"
    destination.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": output["status"], "output": str(destination), "failures": output["failures"]}))
    return 0 if output["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
