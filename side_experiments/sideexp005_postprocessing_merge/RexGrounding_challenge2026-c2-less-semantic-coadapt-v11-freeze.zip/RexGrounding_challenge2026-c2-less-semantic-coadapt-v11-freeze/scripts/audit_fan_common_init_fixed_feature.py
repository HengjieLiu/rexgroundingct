#!/usr/bin/env python3
"""Track A2-FAN feature change on one fixed diagnostic crop across checkpoints."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT, ROOT / "VoxTell"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from scripts.diagnose_token_image_text_phase0 import (  # noqa: E402
    key,
    load_image,
    load_maps,
    load_reference_mask_for_window_diagnostic,
    pad_and_crop,
)
from scripts.diagnose_token_image_text_phase0b_gate import (  # noqa: E402
    make_predictor,
    run_model,
    selected_records,
)
from scripts.run_controlled_fixed30_validation import DEFAULT_CACHE, build_manifest  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-root", type=Path, required=True)
    parser.add_argument(
        "--token-cache",
        type=Path,
        default=ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt",
    )
    parser.add_argument("--pooled-cache", type=Path, default=DEFAULT_CACHE)
    parser.add_argument(
        "--selected-findings",
        type=Path,
        default=ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv",
    )
    parser.add_argument(
        "--dataset-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json"
    )
    args = parser.parse_args()
    args.experiment_root = args.experiment_root.resolve()
    output_dir = args.experiment_root / "diagnostics/A2_FAN/fixed_feature_trajectory"
    output_dir.mkdir(parents=True, exist_ok=True)
    args.experiment_dir = output_dir
    manifest_path, _, selection_sha = build_manifest(args)
    record = selected_records(json.loads(manifest_path.read_text()), 1)[0]
    token_map, pooled_map = load_maps(args.token_cache, args.pooled_cache)
    cache_key = key(record)
    token = token_map[cache_key]
    device = torch.device("cuda")

    rows = []
    for update in (0, 50, 100, 250, 500):
        checkpoint = (
            args.experiment_root / "A2_FAN/checkpoints/checkpoint_initial.pth"
            if update == 0
            else args.experiment_root / f"A2_FAN/checkpoints/checkpoint_update_{update}.pth"
        )
        predictor = make_predictor(output_dir, f"u{update}", checkpoint, device)
        model = predictor.network.eval().to(device)
        image, properties = load_image(ROOT / "data/ct_rate_volumes_fixed" / record["case"])
        data, bbox, original_shape = predictor.preprocess(image)
        target = load_reference_mask_for_window_diagnostic(
            ROOT / "data/segmentations" / record["case"], 1,
            tuple(original_shape), bbox, image_properties=properties,
            finding_ids=[record["finding_idx"]],
        )[0]
        patch, _, starts, padding = pad_and_crop(data, target)
        pooled = pooled_map[cache_key][None, None].to(device)
        contextual = token["feature"][None, None].to(device)
        valid = torch.ones(contextual.shape[:3], dtype=torch.bool, device=device)
        _ = run_model(model, patch[None].to(device), pooled, contextual, valid, torch.bfloat16)
        for scale, audit in model.last_fan_image_text_audits.items():
            rows.append({
                "update": update,
                "scale": scale,
                "case": record["case"],
                "finding_idx": record["finding_idx"],
                "finding": record["prompt"],
                "crop_start_after_padding": starts,
                "padding_wxyz_pairs": padding,
                **audit,
            })
        del model, predictor
        torch.cuda.empty_cache()
    payload = {
        "precision": "bfloat16",
        "fixed_sample": record,
        "selected_findings_sha256": selection_sha,
        "rows": rows,
    }
    destination = output_dir / "feature_trajectory.json"
    destination.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(destination)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
