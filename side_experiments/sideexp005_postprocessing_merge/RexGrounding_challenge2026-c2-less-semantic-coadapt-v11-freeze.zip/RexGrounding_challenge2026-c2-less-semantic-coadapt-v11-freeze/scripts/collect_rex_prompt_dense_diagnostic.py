#!/usr/bin/env python
"""Collect dense original/canonical prompt diagnostics from sharded inference."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


REX_ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=REX_ROOT / "outputs/prompt_standardization_rule_only_v1/dense_original_vs_canonical_v1_2",
    )
    parser.add_argument("--expected-shards", type=int, default=4)
    parser.add_argument("--expected-cases", type=int, default=200)
    parser.add_argument("--expected-findings", type=int, default=381)
    parser.add_argument("--bootstrap-samples", type=int, default=5000)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--parser-provenance", type=Path, default=None)
    return parser.parse_args()


def logit(p: float) -> float:
    p = min(max(float(p), 1e-6), 1 - 1e-6)
    return math.log(p / (1 - p))


def bootstrap_ci_by_case(df: pd.DataFrame, value: str, samples: int, seed: int) -> tuple[float, float]:
    case_values = df.groupby("case", sort=True)[value].mean().to_numpy(np.float64)
    rng = np.random.default_rng(seed)
    means = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 500):
        count = min(500, samples - start)
        idx = rng.integers(0, len(case_values), size=(count, len(case_values)))
        means[start:start + count] = case_values[idx].mean(axis=1)
    return tuple(float(x) for x in np.quantile(means, [0.025, 0.975]))


def assign_folds(df: pd.DataFrame, folds: int, seed: int) -> dict[str, int]:
    counts = df[["case", "finding_idx"]].drop_duplicates().groupby("case").size().sort_values(ascending=False)
    rng = np.random.default_rng(seed)
    fold_loads = [0] * folds
    mapping: dict[str, int] = {}
    for count, group in counts.groupby(counts):
        cases = list(group.index)
        rng.shuffle(cases)
        for case in cases:
            fold = int(np.argmin(fold_loads))
            mapping[case] = fold
            fold_loads[fold] += int(counts[case])
    return mapping


def summarize(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (variant, threshold), selected in df.groupby(["variant", "threshold"], sort=True):
        rows.append({
            "variant": variant,
            "threshold": threshold,
            "findings": int(selected[["case", "finding_idx"]].drop_duplicates().shape[0]),
            "cases": int(selected["case"].nunique()),
            "mean_global_dice_per_finding": selected["dice"].mean(),
            "mean_global_dice_per_case": selected.groupby("case")["dice"].mean().mean(),
            "hit_rate": selected["global_hit"].mean(),
            "hits": int(selected["global_hit"].sum()),
            "mean_precision": selected["precision"].mean(),
            "mean_recall": selected["positive_recall"].mean(),
            "mean_fp_volume_mm3": selected["fp_volume_mm3"].mean(),
            "mean_pred_voxels": selected["pred_voxels"].mean(),
            "empty_predictions": int(selected["empty_prediction"].sum()),
            "gross_oversegmentations": int(selected["gross_oversegmentation"].sum()),
            "mean_voxel_average_precision": selected["voxel_average_precision"].mean(),
            "mean_voxel_auroc": selected["voxel_auroc"].mean(),
            "mean_logit": selected["mean_logit"].mean(),
            "mean_gt_interior_logit": selected["mean_gt_interior_logit"].mean(),
            "mean_gt_exterior_logit": selected["mean_gt_exterior_logit"].mean(),
        })
    return pd.DataFrame(rows)


def matched_points(df: pd.DataFrame, summary: pd.DataFrame, samples: int, seed: int) -> pd.DataFrame:
    lookup = {(r.variant, round(float(r.threshold), 6)): r for r in summary.itertuples(index=False)}
    comparisons = [
        ("original_match_canonical_0p50_volume", "original", "canonical_visual", "mean_pred_voxels"),
        ("canonical_match_original_0p50_volume", "canonical_visual", "original", "mean_pred_voxels"),
        ("original_match_canonical_0p50_recall", "original", "canonical_visual", "mean_recall"),
        ("canonical_match_original_0p50_recall", "canonical_visual", "original", "mean_recall"),
        ("original_match_canonical_0p50_precision", "original", "canonical_visual", "mean_precision"),
        ("canonical_match_original_0p50_precision", "canonical_visual", "original", "mean_precision"),
    ]
    rows = []
    for name, candidate_variant, target_variant, metric in comparisons:
        target = lookup[(target_variant, 0.5)]
        candidates = summary[summary["variant"].eq(candidate_variant)].copy()
        candidates["match_error"] = (candidates[metric] - getattr(target, metric)).abs()
        nearest = candidates.sort_values(["match_error", "threshold"]).iloc[0]
        cand = df[df["variant"].eq(candidate_variant) & df["threshold"].eq(nearest.threshold)]
        targ = df[df["variant"].eq(target_variant) & df["threshold"].eq(0.5)]
        merged = cand.merge(targ, on=["case", "finding_idx"], suffixes=("_candidate", "_target"))
        merged["dice_delta_target_minus_candidate"] = merged["dice_target"] - merged["dice_candidate"]
        ci = bootstrap_ci_by_case(merged, "dice_delta_target_minus_candidate", samples, seed)
        rows.append({
            "comparison": name,
            "target_variant": target_variant,
            "target_threshold": 0.5,
            "candidate_variant": candidate_variant,
            "candidate_threshold": float(nearest.threshold),
            "target_metric": metric,
            "target_metric_value": float(getattr(target, metric)),
            "candidate_metric_value": float(nearest[metric]),
            "residual_abs": float(nearest.match_error),
            "target_dice": float(getattr(target, "mean_global_dice_per_finding")),
            "candidate_dice": float(nearest.mean_global_dice_per_finding),
            "dice_delta_target_minus_candidate": float(merged["dice_delta_target_minus_candidate"].mean()),
            "dice_delta_ci95_low_by_case": ci[0],
            "dice_delta_ci95_high_by_case": ci[1],
            "target_precision": float(getattr(target, "mean_precision")),
            "candidate_precision": float(nearest.mean_precision),
            "target_recall": float(getattr(target, "mean_recall")),
            "candidate_recall": float(nearest.mean_recall),
            "target_hit_rate": float(getattr(target, "hit_rate")),
            "candidate_hit_rate": float(nearest.hit_rate),
            "target_mean_pred_voxels": float(getattr(target, "mean_pred_voxels")),
            "candidate_mean_pred_voxels": float(nearest.mean_pred_voxels),
            "improved_findings_target_vs_candidate": int((merged["dice_delta_target_minus_candidate"] > 1e-8).sum()),
            "worse_findings_target_vs_candidate": int((merged["dice_delta_target_minus_candidate"] < -1e-8).sum()),
            "tied_findings": int((merged["dice_delta_target_minus_candidate"].abs() <= 1e-8).sum()),
        })
    return pd.DataFrame(rows)


def crossfit(df: pd.DataFrame, folds: int, samples: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    mapping = assign_folds(df, folds, seed)
    folded = df.copy()
    folded["fold"] = folded["case"].map(mapping)
    selections = []
    heldout = []
    for fold in range(folds):
        train = folded[folded["fold"].ne(fold)]
        test = folded[folded["fold"].eq(fold)]
        for variant in ("original", "canonical_visual"):
            train_scores = train[train["variant"].eq(variant)].groupby("threshold")["dice"].mean()
            threshold = float(train_scores.idxmax())
            part = test[test["variant"].eq(variant) & test["threshold"].eq(threshold)].copy()
            part["selected_threshold"] = threshold
            heldout.append(part)
            selections.append({
                "fold": fold,
                "variant": variant,
                "selected_threshold": threshold,
                "selected_bias_equivalent": -logit(threshold),
                "train_mean_dice": float(train_scores.loc[threshold]),
                "heldout_cases": int(part["case"].nunique()),
                "heldout_findings": int(part[["case", "finding_idx"]].drop_duplicates().shape[0]),
            })
    heldout_df = pd.concat(heldout, ignore_index=True)
    rows = []
    for variant, selected in heldout_df.groupby("variant"):
        rows.append({
            "variant": variant,
            "crossfit_mean_global_dice_per_finding": selected["dice"].mean(),
            "crossfit_mean_global_dice_per_case": selected.groupby("case")["dice"].mean().mean(),
            "precision": selected["precision"].mean(),
            "recall": selected["positive_recall"].mean(),
            "hit_rate": selected["global_hit"].mean(),
            "mean_pred_voxels": selected["pred_voxels"].mean(),
            "mean_fp_volume_mm3": selected["fp_volume_mm3"].mean(),
            "mean_voxel_average_precision": selected["voxel_average_precision"].mean(),
            "mean_voxel_auroc": selected["voxel_auroc"].mean(),
        })
    paired = heldout_df.pivot_table(index=["case", "finding_idx"], columns="variant", values="dice", aggfunc="first").dropna()
    paired["delta"] = paired["canonical_visual"] - paired["original"]
    ci = bootstrap_ci_by_case(paired.reset_index(), "delta", samples, seed + 17)
    summary = pd.DataFrame(rows)
    summary["canonical_minus_original_dice_delta"] = np.nan
    idx = summary.index[summary["variant"].eq("canonical_visual")]
    if len(idx):
        delta = (
            float(summary.loc[idx[0], "crossfit_mean_global_dice_per_finding"])
            - float(summary.loc[summary["variant"].eq("original"), "crossfit_mean_global_dice_per_finding"].iloc[0])
        )
        summary.loc[idx[0], "canonical_minus_original_dice_delta"] = delta
        summary.loc[idx[0], "ci95_low_by_case"] = ci[0]
        summary.loc[idx[0], "ci95_high_by_case"] = ci[1]
    return summary, pd.DataFrame(selections)


def calibration_results(df: pd.DataFrame, folds: int, seed: int) -> pd.DataFrame:
    """Binary calibration at threshold 0.5 is equivalent to selecting an original threshold."""
    mapping = assign_folds(df, folds, seed)
    folded = df[df["variant"].eq("original")].copy()
    folded["fold"] = folded["case"].map(mapping)
    rows = []
    for fold in range(folds):
        train = folded[folded["fold"].ne(fold)]
        test = folded[folded["fold"].eq(fold)]
        by_threshold = train.groupby("threshold")["dice"].mean()
        best = float(by_threshold.idxmax())
        selected = test[test["threshold"].eq(best)]
        rows.append({
            "fold": fold,
            "method": "global_logit_bias",
            "selected_original_probability_threshold": best,
            "bias_b": -logit(best),
            "affine_a": 1.0,
            "temperature_T": np.nan,
            "dice": selected["dice"].mean(),
            "precision": selected["precision"].mean(),
            "recall": selected["positive_recall"].mean(),
            "hit_rate": selected["global_hit"].mean(),
            "mean_pred_voxels": selected["pred_voxels"].mean(),
            "mean_fp_volume_mm3": selected["fp_volume_mm3"].mean(),
            "mean_voxel_average_precision": selected["voxel_average_precision"].mean(),
            "ap_invariance_expected": True,
        })
        selected_default = test[test["threshold"].eq(0.5)]
        rows.append({
            "fold": fold,
            "method": "temperature_only",
            "selected_original_probability_threshold": 0.5,
            "bias_b": 0.0,
            "affine_a": np.nan,
            "temperature_T": 1.0,
            "dice": selected_default["dice"].mean(),
            "precision": selected_default["precision"].mean(),
            "recall": selected_default["positive_recall"].mean(),
            "hit_rate": selected_default["global_hit"].mean(),
            "mean_pred_voxels": selected_default["pred_voxels"].mean(),
            "mean_fp_volume_mm3": selected_default["fp_volume_mm3"].mean(),
            "mean_voxel_average_precision": selected_default["voxel_average_precision"].mean(),
            "ap_invariance_expected": True,
        })
    return pd.DataFrame(rows)


def parser_rule_associations(provenance_path: Path | None, df: pd.DataFrame) -> pd.DataFrame:
    if provenance_path is None or not provenance_path.exists():
        return pd.DataFrame([{"status": "missing_parser_provenance", "path": str(provenance_path)}])
    base = df[df["threshold"].eq(0.5)]
    paired = base.pivot_table(
        index=["case", "finding_idx"],
        columns="variant",
        values=["dice", "pred_voxels", "precision", "positive_recall", "voxel_average_precision"],
        aggfunc="first",
    )
    paired.columns = [f"{m}_{v}" for m, v in paired.columns]
    paired = paired.reset_index()
    rows = []
    prov = []
    with provenance_path.open() as handle:
        for line in handle:
            item = json.loads(line)
            for trace in item.get("trace", []):
                prov.append({
                    "case": item["case"],
                    "finding_idx": int(item["finding_idx"]),
                    "rule_id": trace["rule_id"],
                    "rule_category": trace["rule_category"],
                    "removed_temporal_language": trace.get("removed_temporal_language", False),
                    "removed_comparison_language": trace.get("removed_comparison_language", False),
                    "removed_speculation": trace.get("removed_speculation", False),
                    "removed_recommendation": trace.get("removed_recommendation", False),
                    "removed_visual_morphology": trace.get("removed_visual_morphology", False),
                    "removed_visual_distribution": trace.get("removed_visual_distribution", False),
                    "removed_anatomical_information": trace.get("removed_anatomical_information", False),
                    "removed_size": trace.get("removed_size", False),
                })
    if not prov:
        return pd.DataFrame([{"status": "no_trace_rows"}])
    prov_df = pd.DataFrame(prov).drop_duplicates(["case", "finding_idx", "rule_id"])
    merged = prov_df.merge(paired, on=["case", "finding_idx"], how="left")
    merged["dice_delta"] = merged["dice_canonical_visual"] - merged["dice_original"]
    merged["ap_delta"] = merged["voxel_average_precision_canonical_visual"] - merged["voxel_average_precision_original"]
    merged["pred_voxels_delta"] = merged["pred_voxels_canonical_visual"] - merged["pred_voxels_original"]
    merged["precision_delta"] = merged["precision_canonical_visual"] - merged["precision_original"]
    merged["recall_delta"] = merged["positive_recall_canonical_visual"] - merged["positive_recall_original"]
    for (kind, value), selected in pd.concat([
        merged.assign(group_kind="rule_id", group_value=merged["rule_id"]),
        merged.assign(group_kind="rule_category", group_value=merged["rule_category"]),
    ]).groupby(["group_kind", "group_value"], sort=True):
        rows.append({
            "group_kind": kind,
            "group_value": value,
            "findings": int(selected[["case", "finding_idx"]].drop_duplicates().shape[0]),
            "mean_dice_delta": selected["dice_delta"].mean(),
            "mean_ap_delta": selected["ap_delta"].mean(),
            "mean_pred_voxels_delta": selected["pred_voxels_delta"].mean(),
            "mean_precision_delta": selected["precision_delta"].mean(),
            "mean_recall_delta": selected["recall_delta"].mean(),
            "improved_findings": int((selected["dice_delta"] > 1e-8).sum()),
            "worse_findings": int((selected["dice_delta"] < -1e-8).sum()),
        })
    return pd.DataFrame(rows)


def collect_shards(input_dir: Path, expected_shards: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, list[dict]]:
    metrics = []
    summaries = []
    repeats = []
    manifests = []
    for shard_id in range(expected_shards):
        shard = input_dir / f"shard_{shard_id:02d}"
        manifests.append(json.loads((shard / "manifest.json").read_text()))
        metrics.append(pd.read_csv(shard / "per_finding_threshold_metrics.csv"))
        summaries.append(pd.read_csv(shard / "per_finding_logit_summary.csv"))
        repeats.append(pd.read_csv(shard / "per_finding_ap_repeats.csv"))
    return pd.concat(metrics, ignore_index=True), pd.concat(summaries, ignore_index=True), pd.concat(repeats, ignore_index=True), manifests


def main() -> int:
    args = parse_args()
    args.input_dir.mkdir(parents=True, exist_ok=True)
    df, logit_summary, ap_repeats, manifests = collect_shards(args.input_dir, args.expected_shards)
    for col in ("global_hit", "empty_prediction", "gross_oversegmentation"):
        if df[col].dtype == object:
            df[col] = df[col].astype(str).str.lower().eq("true")
    cases = df["case"].nunique()
    findings = df[["case", "finding_idx"]].drop_duplicates().shape[0]
    if cases != args.expected_cases or findings != args.expected_findings:
        raise RuntimeError(f"Coverage mismatch: cases={cases}, findings={findings}")

    df.to_csv(args.input_dir / "dense_threshold_metrics.csv", index=False)
    logit_summary.to_csv(args.input_dir / "text_interface_diagnostics.csv", index=False)
    ap_repeats.to_csv(args.input_dir / "ap_repeated_sampling.csv", index=False)

    threshold_summary = summarize(df)
    threshold_summary.to_csv(args.input_dir / "threshold_summary_dense.csv", index=False)
    matched = matched_points(df, threshold_summary, args.bootstrap_samples, args.seed)
    matched.to_csv(args.input_dir / "matched_operating_points.csv", index=False)
    crossfit_summary, crossfit_thresholds = crossfit(df, args.folds, args.bootstrap_samples, args.seed)
    crossfit_summary.to_csv(args.input_dir / "cross_fitted_threshold_results.csv", index=False)
    crossfit_thresholds.to_csv(args.input_dir / "cross_fitted_selected_thresholds.csv", index=False)
    calibration_results(df, args.folds, args.seed).to_csv(args.input_dir / "calibration_results.csv", index=False)

    repeat_pivot = ap_repeats.pivot_table(
        index=["case", "finding_idx", "repeat_seed_index"],
        columns="variant",
        values="voxel_average_precision",
        aggfunc="first",
    ).dropna()
    repeat_pivot["ap_delta_canonical_minus_original"] = repeat_pivot["canonical_visual"] - repeat_pivot["original"]
    repeat_pivot.groupby("repeat_seed_index")["ap_delta_canonical_minus_original"].agg(["mean", "std", "count"]).to_csv(
        args.input_dir / "ap_delta_by_sampling_seed.csv"
    )
    parser_rule_associations(args.parser_provenance, df).to_csv(
        args.input_dir / "parser_rule_outcome_associations.csv", index=False
    )

    sampled_files = sorted(str((args.input_dir / f"shard_{i:02d}" / "sampled_voxel_logits.npz").resolve()) for i in range(args.expected_shards))
    (args.input_dir / "sampled_voxel_logits_manifest.json").write_text(json.dumps({
        "sampled_voxel_logits_files": sampled_files,
        "note": "Each shard NPZ stores paired original/canonical sampled voxel logits/probabilities and exact flat voxel indices.",
    }, indent=2) + "\n")

    best_orig = threshold_summary[threshold_summary["variant"].eq("original")].sort_values("mean_global_dice_per_finding", ascending=False).iloc[0]
    best_can = threshold_summary[threshold_summary["variant"].eq("canonical_visual")].sort_values("mean_global_dice_per_finding", ascending=False).iloc[0]
    report = [
        "# Dense Prompt Parser Diagnostic",
        "",
        f"- Cases: {cases}",
        f"- Findings: {findings}",
        f"- Thresholds: {df['threshold'].nunique()} ({df['threshold'].min():.2f}-{df['threshold'].max():.2f})",
        f"- Best original threshold: {best_orig.threshold:.2f}, Dice {best_orig.mean_global_dice_per_finding:.6f}",
        f"- Best canonical threshold: {best_can.threshold:.2f}, Dice {best_can.mean_global_dice_per_finding:.6f}",
        "",
        "## Storage Strategy",
        "",
        "- Full logits were not saved for all findings.",
        "- Compact sampled voxel logits are stored per shard in `sampled_voxel_logits.npz`.",
        "- Full-logit subset visual diagnostics should be run separately on the selected 60-finding subset.",
        "",
        "## Next Interpretation Files",
        "",
        "- `matched_operating_points.csv`",
        "- `cross_fitted_threshold_results.csv`",
        "- `calibration_results.csv`",
        "- `parser_rule_outcome_associations.csv`",
        "- `ap_delta_by_sampling_seed.csv`",
    ]
    (args.input_dir / "final_prompt_parser_diagnostic.md").write_text("\n".join(report) + "\n")
    print(json.dumps({
        "input_dir": str(args.input_dir.resolve()),
        "cases": cases,
        "findings": findings,
        "thresholds": int(df["threshold"].nunique()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
