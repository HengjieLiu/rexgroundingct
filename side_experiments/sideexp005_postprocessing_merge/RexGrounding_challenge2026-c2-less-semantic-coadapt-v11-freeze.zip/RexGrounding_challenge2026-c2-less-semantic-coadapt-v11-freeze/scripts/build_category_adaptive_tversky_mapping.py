#!/usr/bin/env python3
"""Build a reproducible category-adaptive Tversky map from Anchor85 errors."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_METRICS = (
    ROOT
    / "outputs/analysis/hard_negative_diagnostic_full/"
    "per_finding_metrics_anchor85_samecase15_step3800_bestval.csv"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metrics-csv", type=Path, default=DEFAULT_METRICS)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--min-category-count", type=int, default=10)
    parser.add_argument("--dominance-ratio", type=float, default=1.5)
    parser.add_argument("--overprediction-ratio", type=float, default=1.25)
    return parser.parse_args()


def classify(row: pd.Series, args: argparse.Namespace) -> tuple[str, float, float, str]:
    if int(row["sample_count"]) < args.min_category_count:
        return "mixed", 0.5, 0.5, "insufficient_sample_count"
    fp_dominant = (
        row["median_fp_over_gt"] >= args.dominance_ratio * row["median_fn_over_gt"]
        and row["median_prediction_gt_volume_ratio"] >= args.overprediction_ratio
    )
    fn_dominant = (
        row["median_fn_over_gt"] >= args.dominance_ratio * row["median_fp_over_gt"]
        and row["baseline_recall"] < 0.5
    )
    if fp_dominant and not fn_dominant:
        return "fp_heavy", 0.7, 0.3, "fp_gt_dominates_and_prediction_volume_is_high"
    if fn_dominant and not fp_dominant:
        return "fn_heavy", 0.3, 0.7, "fn_gt_dominates_and_recall_is_low"
    return "mixed", 0.5, 0.5, "no_clear_single_error_mode"


def main() -> int:
    args = parse_args()
    metrics = pd.read_csv(args.metrics_csv)
    required = {
        "category_code",
        "dice",
        "precision",
        "recall",
        "global_hit",
        "fp_volume_mm3",
        "fn_volume_mm3",
        "gt_volume_mm3",
        "pred_gt_volume_ratio",
    }
    missing = sorted(required - set(metrics.columns))
    if missing:
        raise ValueError(f"Baseline metrics missing columns: {missing}")
    metrics = metrics.copy()
    gt = metrics["gt_volume_mm3"].clip(lower=np.finfo(float).eps)
    metrics["fp_over_gt"] = metrics["fp_volume_mm3"] / gt
    metrics["fn_over_gt"] = metrics["fn_volume_mm3"] / gt
    grouped = (
        metrics.groupby("category_code", dropna=False)
        .agg(
            sample_count=("dice", "size"),
            baseline_dice=("dice", "mean"),
            baseline_precision=("precision", "mean"),
            baseline_recall=("recall", "mean"),
            baseline_hit_rate=("global_hit", "mean"),
            median_prediction_gt_volume_ratio=("pred_gt_volume_ratio", "median"),
            median_fp_volume_mm3=("fp_volume_mm3", "median"),
            median_fn_volume_mm3=("fn_volume_mm3", "median"),
            mean_fp_volume_mm3=("fp_volume_mm3", "mean"),
            mean_fn_volume_mm3=("fn_volume_mm3", "mean"),
            median_fp_over_gt=("fp_over_gt", "median"),
            median_fn_over_gt=("fn_over_gt", "median"),
        )
        .reset_index()
        .rename(columns={"category_code": "category"})
        .sort_values("category")
    )
    assignments = [classify(row, args) for _, row in grouped.iterrows()]
    grouped[["assigned_group", "alpha_fp", "beta_fn", "assignment_reason"]] = pd.DataFrame(
        assignments,
        index=grouped.index,
    )
    mapping = {
        str(row.category): {
            "group": str(row.assigned_group),
            "alpha_fp": float(row.alpha_fp),
            "beta_fn": float(row.beta_fn),
        }
        for row in grouped.itertuples(index=False)
    }
    for path in (args.output_json, args.output_csv, args.report):
        path.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(mapping, indent=2, sort_keys=True) + "\n")
    grouped.to_csv(args.output_csv, index=False)

    counts = grouped.groupby("assigned_group")["sample_count"].sum().to_dict()
    category_counts = grouped["assigned_group"].value_counts().to_dict()
    lines = [
        "# Category-adaptive Tversky mapping audit",
        "",
        f"Baseline source: `{args.metrics_csv}`",
        "",
        "Rules are evaluated on category-level medians. Categories below the minimum count are mixed.",
        f"FP-heavy requires FP/GT >= {args.dominance_ratio} * FN/GT and median pred/GT >= {args.overprediction_ratio}.",
        f"FN-heavy requires FN/GT >= {args.dominance_ratio} * FP/GT and mean recall < 0.5.",
        "Unknown categories fall back to mixed alpha=0.5, beta=0.5 at training time.",
        "",
        f"Category counts by group: `{category_counts}`",
        f"Finding counts by group: `{counts}`",
        "",
        "```text",
        grouped.round(4).to_string(index=False),
        "```",
        "",
    ]
    args.report.write_text("\n".join(lines))
    print(grouped.to_string(index=False))
    print(f"Saved mapping: {args.output_json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
