#!/usr/bin/env python3
"""Static adapter and prompt-cache checks for the medcomposeCT evaluation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch


ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--adapter", type=Path, action="append", required=True)
    parser.add_argument("--full-cache", type=Path, required=True)
    parser.add_argument("--pilot-cache", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    return parser.parse_args()


def cache_map(path: Path) -> dict[tuple[str, str, int], torch.Tensor]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    records, embeddings = payload.get("records") or [], payload.get("embeddings")
    if embeddings is None or len(records) != len(embeddings):
        raise ValueError(f"Invalid embedding cache: {path}")
    return {
        (str(row["split"]), str(row["case"]), int(row["finding_idx"])): embeddings[index]
        for index, row in enumerate(records)
    }


def main() -> int:
    args = parse_args()
    expected_mapping = {
        "unknown": 0, "1a": 1, "1b": 2, "1c": 3, "1d": 4, "1e": 5, "1f": 6,
        "2a": 7, "2b": 8, "2c": 9, "2d": 10, "2e": 11, "2f": 12, "2g": 13, "2h": 14,
    }
    adapters = []
    for path in args.adapter:
        payload = torch.load(path, map_location="cpu", weights_only=False)
        mapping = payload.get("category_to_index")
        state = payload.get("category_embedding_state") or {}
        weight = state.get("weight")
        if payload.get("format_version") != "voxtell_rex_category_adapter.v1":
            raise ValueError(f"Unexpected adapter format: {path}")
        if mapping != expected_mapping:
            raise ValueError(f"Category mapping mismatch: {path}: {mapping}")
        if weight is None or tuple(weight.shape) != (15, 2048):
            raise ValueError(f"Unexpected category embedding shape in {path}")
        unknown_max_abs = float(weight[expected_mapping["unknown"]].abs().max())
        if unknown_max_abs != 0.0:
            raise ValueError(f"Unknown/padding embedding is nonzero in {path}: {unknown_max_abs}")
        adapters.append(
            {
                "path": str(path.resolve()),
                "optimizer_update": int(payload["optimizer_update"]),
                "category_mapping_matches": True,
                "unknown_padding_max_abs": unknown_max_abs,
                "unknown_padding_is_zero": True,
            }
        )

    full, pilot = cache_map(args.full_cache), cache_map(args.pilot_cache)
    shared = sorted(set(full) & set(pilot))
    if not shared:
        raise ValueError("The full and pilot prompt caches have no shared findings")
    unequal = [key for key in shared if not torch.equal(full[key], pilot[key])]
    max_difference = max(
        (float((full[key].float() - pilot[key].float()).abs().max()) for key in unequal),
        default=0.0,
    )
    cache_tolerance = 1e-4
    if max_difference > cache_tolerance:
        raise ValueError(
            f"Full prompt cache differs materially from pilot cache on {len(unequal)} shared findings; "
            f"maximum absolute difference={max_difference} > {cache_tolerance}"
        )
    report = {
        "experiment": "medcomposeCT experiment",
        "category_index_mapping": expected_mapping,
        "adapters": adapters,
        "prompt_cache_equivalence": {
            "full_cache": str(args.full_cache.resolve()),
            "pilot_cache": str(args.pilot_cache.resolve()),
            "shared_findings": len(shared),
            "bit_exact": not unequal,
            "non_bit_exact_findings": len(unequal),
            "maximum_absolute_difference": max_difference,
            "allclose_absolute_tolerance": cache_tolerance,
            "within_tolerance": True,
        },
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
