#!/usr/bin/env python3
"""Collect and compare structured prompt mini-pilot inference outputs."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    threshold_summary = args.input_dir / "threshold_summary.csv"
    metrics_path = args.input_dir / "per_finding_threshold_metrics.csv"
    if not threshold_summary.exists() or not metrics_path.exists():
        raise FileNotFoundError(f"Missing collected metrics in {args.input_dir}")

    summary_rows = list(csv.DictReader(threshold_summary.open(newline="", encoding="utf-8")))
    with (args.input_dir / "structured_frozen_results.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary_rows[0]))
        writer.writeheader()
        writer.writerows(summary_rows)

    metric_rows = list(csv.DictReader(metrics_path.open(newline="", encoding="utf-8")))
    for row in metric_rows:
        row["finding_idx"] = int(row["finding_idx"])
        row["threshold"] = float(row["threshold"])
        row["dice"] = float(row["dice"])
    thresholds = sorted({row["threshold"] for row in metric_rows})
    variants = sorted({row["variant"] for row in metric_rows})
    paired = []
    for threshold in thresholds:
        rows_t = [row for row in metric_rows if row["threshold"] == threshold]
        lookup = {(row["case"], row["finding_idx"], row["variant"]): row for row in rows_t}
        keys = sorted({(row["case"], row["finding_idx"]) for row in rows_t})
        for baseline in ("original", "cleanup_only"):
            if baseline not in variants:
                continue
            for variant in variants:
                if variant == baseline:
                    continue
                deltas = np.asarray([
                    lookup[(*key, variant)]["dice"] - lookup[(*key, baseline)]["dice"]
                    for key in keys
                    if (*key, variant) in lookup and (*key, baseline) in lookup
                ], dtype=np.float64)
                if deltas.size == 0:
                    continue
                paired.append({
                    "baseline": baseline,
                    "variant": variant,
                    "threshold": threshold,
                    "findings": int(deltas.size),
                    "mean_dice_delta": float(deltas.mean()),
                    "improved_findings": int((deltas > 1e-8).sum()),
                    "tied_findings": int((np.abs(deltas) <= 1e-8).sum()),
                    "worse_findings": int((deltas < -1e-8).sum()),
                })
    with (args.input_dir / "paired_deltas_vs_cleanup.csv").open("w", newline="", encoding="utf-8") as handle:
        cleanup_rows = [row for row in paired if row["baseline"] == "cleanup_only"]
        writer = csv.DictWriter(handle, fieldnames=list(cleanup_rows[0]))
        writer.writeheader()
        writer.writerows(cleanup_rows)
    with (args.input_dir / "paired_deltas_all_baselines.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(paired[0]))
        writer.writeheader()
        writer.writerows(paired)

    best = sorted(
        summary_rows,
        key=lambda row: (float(row["threshold"]) == 0.5, float(row["mean_global_dice_per_finding"])),
        reverse=True,
    )[:8]
    report = [
        "# Structured Prompt Mini-Pilot Inference",
        "",
        f"Rows: {len(metric_rows)} per-finding/threshold/variant measurements",
        "",
        "| Variant | Threshold | Dice/finding | Dice/case | Hit rate | Precision | Recall |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summary_rows:
        report.append(
            f"| {row['variant']} | {float(row['threshold']):.2f} | "
            f"{float(row['mean_global_dice_per_finding']):.6f} | "
            f"{float(row['mean_global_dice_per_case']):.6f} | "
            f"{float(row['hit_rate']):.6f} | "
            f"{float(row['mean_precision']):.6f} | "
            f"{float(row['mean_recall']):.6f} |"
        )
    report.extend([
        "",
        "Top rows by threshold-0.5 preference and Dice/finding:",
        "",
        "| Variant | Threshold | Dice/finding |",
        "|---|---:|---:|",
    ])
    for row in best:
        report.append(
            f"| {row['variant']} | {float(row['threshold']):.2f} | "
            f"{float(row['mean_global_dice_per_finding']):.6f} |"
        )
    report.extend([
        "",
        "Paired deltas versus cleanup: `paired_deltas_vs_cleanup.csv`.",
        "",
    ])
    (args.input_dir / "final_structured_prompt_minipilot.md").write_text("\n".join(report), encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
