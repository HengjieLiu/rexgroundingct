#!/usr/bin/env python3
"""Measure whether the trained encoder token-spatial block selects tokens by location.

The training implementation uses ``scaled_dot_product_attention`` without
requesting its weights.  This audit reconstructs the exact QK softmax from the
trained checkpoint, and separately measures the output residual.  It does not
change any model weights or perform optimization.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from scripts.audit_encoder_token_spatial_18 import make_model  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint", type=Path,
        default=ROOT / "outputs/encoder_token_spatial_18_screen/f1_text/checkpoints/checkpoint_update_250.pth",
    )
    parser.add_argument(
        "--token-cache", type=Path,
        default=ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt",
    )
    parser.add_argument("--max-findings", type=int, default=12)
    parser.add_argument(
        "--output-dir", type=Path,
        default=ROOT / "outputs/encoder_token_spatial_18_screen/audits/selectivity_update250",
    )
    return parser.parse_args()


def crop_around_finding(case: str, finding_idx: int) -> torch.Tensor:
    arrays = np.load(ROOT / "data/rex_voxtell_preprocessed_v1/cases/val" / case.replace(".nii.gz", ".npz"))
    mask = arrays["masks"][finding_idx]
    center = np.argwhere(mask > 0).mean(axis=0).round().astype(int)
    start = np.maximum(0, np.minimum(center - 96, np.asarray(mask.shape) - 192))
    slices = tuple(slice(int(value), int(value + 192)) for value in start)
    return torch.from_numpy(arrays["image"][(slice(None), *slices)]).float()[None]


def valid_tokens(tokens: torch.Tensor) -> torch.Tensor:
    """The cache stores unpadded token rows followed by all-zero padding."""
    return tokens.abs().sum(dim=-1).ne(0)


def spatial_attention(block: torch.nn.Module, image_feature: torch.Tensor, tokens: torch.Tensor, valid: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Return exact attention weights [heads, locations, tokens] and delta [C,D,H,W]."""
    _, channels, depth, height, width = image_feature.shape
    locations = depth * height * width
    image = image_feature.permute(0, 2, 3, 4, 1).reshape(1, locations, channels)
    query = block.q_proj(block.image_norm(image)).view(1, locations, block.num_heads, block.head_dim).transpose(1, 2)
    text = tokens[None]
    key = block.k_proj(block.text_norm(text)).view(1, tokens.shape[0], block.num_heads, block.head_dim).transpose(1, 2)
    logits = (query.float() @ key.float().transpose(-2, -1)) * block.scale
    logits = logits.masked_fill(~valid[None, None, None], float("-inf"))
    attention = logits.softmax(dim=-1)[0]
    # Use the real module for its exact output projection and reshape.
    _, delta = block(image_feature, tokens[None, None], valid[None, None])
    return attention, delta[0, 0]


def entropy(probability: torch.Tensor) -> torch.Tensor:
    return -(probability.clamp_min(1e-12) * probability.clamp_min(1e-12).log()).sum(dim=-1)


def selectivity_metrics(attention: torch.Tensor, delta: torch.Tensor, valid: torch.Tensor) -> dict[str, float | int | list[int]]:
    """Location-wise attention diversity and residual-map concentration."""
    weights = attention[..., valid]  # [H,L,Tvalid]
    mean_by_location = weights.mean(dim=0)  # [L,T]
    global_mean = mean_by_location.mean(dim=0, keepdim=True)
    kl = (mean_by_location.clamp_min(1e-12) * (mean_by_location.clamp_min(1e-12).log() - global_mean.clamp_min(1e-12).log())).sum(dim=-1)
    token_entropy = entropy(mean_by_location)
    top = mean_by_location.argmax(dim=-1)
    counts = torch.bincount(top, minlength=weights.shape[-1])
    flat_delta = delta.float().permute(1, 2, 3, 0).reshape(-1, delta.shape[0])
    mean_delta = flat_delta.mean(dim=0, keepdim=True)
    norm_map = flat_delta.square().sum(dim=-1).sqrt()
    vector_relative_variation = (flat_delta - mean_delta).square().sum(dim=-1).sqrt().mean() / norm_map.mean().clamp_min(1e-12)
    vector_cosine_to_global = torch.nn.functional.cosine_similarity(flat_delta, mean_delta.expand_as(flat_delta), dim=-1).mean()
    return {
        "valid_tokens": int(weights.shape[-1]),
        "heads": int(weights.shape[0]),
        "locations": int(weights.shape[1]),
        "mean_location_to_global_token_kl_nats": float(kl.mean()),
        "p95_location_to_global_token_kl_nats": float(kl.quantile(0.95)),
        "mean_normalized_token_entropy": float((token_entropy / np.log(max(weights.shape[-1], 2))).mean()),
        "unique_top_tokens_across_locations": int((counts > 0).sum()),
        "largest_top_token_location_fraction": float(counts.max() / counts.sum()),
        "delta_norm_mean": float(norm_map.mean()),
        "delta_norm_spatial_cv": float(norm_map.std(unbiased=False) / norm_map.mean().clamp_min(1e-12)),
        "delta_norm_p95_to_median": float(norm_map.quantile(0.95) / norm_map.median().clamp_min(1e-12)),
        "delta_vector_spatial_relative_variation": float(vector_relative_variation),
        "delta_vector_mean_cosine_to_global": float(vector_cosine_to_global),
        "top_token_counts": [int(x) for x in counts.tolist()],
    }


def counterfactual_metrics(delta_a: torch.Tensor, delta_b: torch.Tensor) -> dict[str, float]:
    """Does swapping text make a spatially structured, rather than constant, change?"""
    a_vector = delta_a.float().permute(1, 2, 3, 0).reshape(-1, delta_a.shape[0])
    b_vector = delta_b.float().permute(1, 2, 3, 0).reshape(-1, delta_b.shape[0])
    a = a_vector.square().sum(dim=-1).sqrt()
    b = b_vector.square().sum(dim=-1).sqrt()
    change_vector = a_vector - b_vector
    change = change_vector.square().sum(dim=-1).sqrt()
    mean_change = change_vector.mean(dim=0, keepdim=True)
    change_vector_relative_variation = (change_vector - mean_change).square().sum(dim=-1).sqrt().mean() / change.mean().clamp_min(1e-12)
    correlation = torch.corrcoef(torch.stack([a, b]))[0, 1]
    return {
        "delta_map_correlation_correct_vs_donor": float(correlation.nan_to_num(0.0)),
        "counterfactual_change_mean": float(change.mean()),
        "counterfactual_change_spatial_cv": float(change.std(unbiased=False) / change.mean().clamp_min(1e-12)),
        "counterfactual_change_p95_to_median": float(change.quantile(0.95) / change.median().clamp_min(1e-12)),
        "counterfactual_change_nonzero_fraction": float((change > 1e-8).float().mean()),
        "counterfactual_change_vector_spatial_relative_variation": float(change_vector_relative_variation),
    }


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("This audit requires a CUDA GPU")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(2026); torch.cuda.manual_seed_all(2026)
    torch.backends.cudnn.benchmark = False
    device = torch.device("cuda")
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    model = make_model(True, device, checkpoint).eval().float()
    block = model.encoder_token_spatial_block
    assert block is not None
    payload = torch.load(args.token_cache, map_location="cpu", weights_only=False)
    records = [record for record in payload["records"] if record["split"] == "val"][: args.max_findings]
    index = {(r["split"], r["case"], int(r["finding_idx"])): i for i, r in enumerate(payload["records"])}
    rows: list[dict[str, object]] = []
    with torch.no_grad():
        for sample_index, record in enumerate(records):
            key = (record["split"], record["case"], int(record["finding_idx"]))
            token_index = index[key]
            tokens = payload["token_features"][token_index].float().to(device)
            valid = valid_tokens(tokens)
            image = crop_around_finding(record["case"], int(record["finding_idx"])).to(device)
            x = model.encoder.stem(image) if model.encoder.stem is not None else image
            for stage_index in range(model.encoder_token_spatial_stage + 1):
                x = model.encoder.stages[stage_index](x)
            attention, delta = spatial_attention(block, x, tokens, valid)
            donor_record = records[(sample_index + 1) % len(records)]
            donor_key = (donor_record["split"], donor_record["case"], int(donor_record["finding_idx"]))
            donor_tokens = payload["token_features"][index[donor_key]].float().to(device)
            donor_valid = valid_tokens(donor_tokens)
            _, donor_delta = spatial_attention(block, x, donor_tokens, donor_valid)
            row: dict[str, object] = {
                "case": record["case"], "finding_idx": int(record["finding_idx"]),
                "prompt": record.get("prompt"), "donor_case": donor_record["case"],
                "donor_finding_idx": int(donor_record["finding_idx"]),
                **selectivity_metrics(attention, delta, valid),
                **counterfactual_metrics(delta, donor_delta),
            }
            rows.append(row)
            print(json.dumps({k: row[k] for k in ("case", "finding_idx", "mean_location_to_global_token_kl_nats", "unique_top_tokens_across_locations", "largest_top_token_location_fraction", "delta_norm_spatial_cv", "counterfactual_change_spatial_cv")}, ensure_ascii=False))
            torch.cuda.empty_cache()
    numeric = [
        "mean_location_to_global_token_kl_nats", "p95_location_to_global_token_kl_nats",
        "mean_normalized_token_entropy", "unique_top_tokens_across_locations",
        "largest_top_token_location_fraction", "delta_norm_spatial_cv", "delta_norm_p95_to_median",
        "delta_vector_spatial_relative_variation", "delta_vector_mean_cosine_to_global",
        "delta_map_correlation_correct_vs_donor", "counterfactual_change_spatial_cv",
        "counterfactual_change_p95_to_median", "counterfactual_change_nonzero_fraction", "counterfactual_change_vector_spatial_relative_variation",
    ]
    summary = {f"median_{key}": float(np.median([float(row[key]) for row in rows])) for key in numeric}
    # A position-selective head must have non-zero location-to-global divergence,
    # use several winning tokens over space, and produce a non-uniform residual map.
    summary["position_selective"] = bool(
        summary["median_mean_location_to_global_token_kl_nats"] > 1e-3
        and summary["median_unique_top_tokens_across_locations"] >= 2
        and summary["median_delta_vector_spatial_relative_variation"] > 0.10
    )
    report = {
        "schema": "token_spatial_selectivity_audit_v1",
        "checkpoint": str(args.checkpoint.resolve()), "samples": len(rows),
        "method": {
            "attention": "exact softmax(QK^T/sqrt(head_dim)) reconstructed from trained Q/K projections",
            "counterfactual": "same image feature, token sequence replaced with the next validation finding",
            "interpretation": "KL=0 means every image location uses the same token distribution; higher residual CV means output conditioning is spatially non-uniform",
        },
        "summary": summary, "per_finding": rows,
    }
    (args.output_dir / "selectivity_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
