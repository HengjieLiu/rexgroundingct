#!/usr/bin/env python3
"""CPU-only maturity audit for dual-expert checkpoint selection.

This script consumes only existing raw full-381 summary tables. It never loads
prediction volumes, runs inference, or trains a model.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import resource
import subprocess
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
LINEAGE = ROOT / "outputs/voxtell_v11_e1e-5_d1e-4_1gpu_bs1_acc4_10kupd"
CANONICAL_FAMILY = ROOT / "outputs/nonattention_baseline_selection"
OUTPUT_DIR = ROOT / "outputs/dual_expert_checkpoint_maturity_audit"
EVALUATION_DRIVER = ROOT / "scripts/evaluate_nonattention_baseline_candidate_2gpu.sbatch"
EXPERT_CATEGORIES = ("1c", "1d", "1f", "2b", "2c")
DIFFUSE_CATEGORIES = ("1c", "1d", "1f")
MATURE_UPDATE = 10000
KNOWN_UPDATE8000_SHA256 = "47928c431288377d3708d0c722a77c3b6a25468fdcc8841435c87481e167038c"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    return parser.parse_args()


def digest_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(block_size):
            digest.update(chunk)
    return digest.hexdigest()


def json_dump(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True, default=str) + "\n")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as source:
        return list(csv.DictReader(source))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty CSV: {path}")
    with path.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def finding_signature(rows: list[dict[str, str]]) -> str:
    identity = sorted(
        "|".join(
            (
                row["file"],
                row["finding_idx"],
                row["category"],
                row["pixels"],
                row["prompt"],
                row["gt_voxels"],
                row["voxel_volume_mm3"],
            )
        )
        for row in rows
    )
    return hashlib.sha256("\n".join(identity).encode("utf-8")).hexdigest()


def bool_value(value: str) -> bool:
    return value.strip().lower() in {"true", "1", "yes"}


def aggregate(rows: list[dict[str, str]]) -> dict[str, Any]:
    if not rows:
        raise ValueError("Cannot aggregate zero findings")
    return {
        "n": len(rows),
        "mean_dice": sum(float(row["global_dice"]) for row in rows) / len(rows),
        "hits": sum(bool_value(row["global_hit"]) for row in rows),
        "mean_precision": sum(float(row["voxel_precision"]) for row in rows) / len(rows),
        "mean_recall": sum(float(row["voxel_recall"]) for row in rows) / len(rows),
        "mean_pred_gt_volume_ratio": sum(float(row["pred_gt_volume_ratio"]) for row in rows) / len(rows),
    }


def no_attention_evidence(result_dir: Path, candidate: dict[str, Any]) -> dict[str, Any]:
    configs = []
    for path in sorted(result_dir.glob("spatial_attention_config_shard_*.json")):
        payload = json.loads(path.read_text())
        checks = {
            "spatial_attention_enabled": payload.get("spatial_attention_enabled") is False,
            "s2_attention_enabled": payload.get("s2_attention_enabled") is False,
            "s3_voxel_text_matching_enabled": payload.get("s3_voxel_text_matching_enabled") is False,
            "s3_decoder_feature_gate_enabled": payload.get("s3_decoder_feature_gate", {}).get("enabled") is False,
            "category_gamma_json_is_null": payload.get("category_gamma_json") is None,
        }
        configs.append({"path": str(path), "checks": checks, "all_pass": all(checks.values())})
    verified = candidate.get("attention_enabled") is False and bool(configs) and all(
        entry["all_pass"] for entry in configs
    )
    return {
        "candidate_summary_attention_enabled": candidate.get("attention_enabled"),
        "shard_configs": configs,
        "verified_no_attention": verified,
    }


def git_snapshot() -> dict[str, Any]:
    status = subprocess.run(
        ["git", "status", "--short"], cwd=ROOT, text=True, capture_output=True, check=False
    )
    diff_check = subprocess.run(
        ["git", "diff", "--check"], cwd=ROOT, text=True, capture_output=True, check=False
    )
    return {
        "status_short": status.stdout.splitlines(),
        "status_exit_code": status.returncode,
        "diff_check_stdout": diff_check.stdout.splitlines(),
        "diff_check_stderr": diff_check.stderr.splitlines(),
        "diff_check_exit_code": diff_check.returncode,
        "audit_code_changed": True,
        "audit_script": str(Path(__file__).resolve()),
    }


def main() -> int:
    started = time.perf_counter()
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    included_updates = (8000, 10000)
    checkpoint_data: dict[int, dict[str, Any]] = {}
    common_signature: str | None = None
    common_keys: set[tuple[str, str]] | None = None

    for update in included_updates:
        result_dir = CANONICAL_FAMILY / f"full381_update{update}"
        candidate_path = result_dir / "candidate_summary.json"
        summary_path = result_dir / "summary_tables/summary.json"
        findings_path = result_dir / "summary_tables/per_finding_metrics.csv"
        resolved_path = result_dir / "resolved_checkpoint.txt"
        for required in (candidate_path, summary_path, findings_path, resolved_path):
            if not required.is_file():
                raise FileNotFoundError(required)
        candidate = json.loads(candidate_path.read_text())
        summary = json.loads(summary_path.read_text())
        findings = read_csv(findings_path)
        checkpoint = Path(resolved_path.read_text().strip()).resolve()
        expected_checkpoint = (LINEAGE / f"checkpoints/checkpoint_update_{update}.pth").resolve()
        if checkpoint != expected_checkpoint or Path(candidate["checkpoint"]).resolve() != expected_checkpoint:
            raise RuntimeError(f"Checkpoint provenance mismatch for update {update}")
        if not checkpoint.is_file():
            raise FileNotFoundError(checkpoint)
        if len(findings) != 381 or summary["total_cases"] != 200 or summary["total_findings"] != 381:
            raise RuntimeError(f"Update {update} is not complete full-200/381")
        if summary["params"] != {"global_only": True, "global_hit_thr": 0.1}:
            raise RuntimeError(f"Update {update} uses incompatible metric parameters")
        signature = finding_signature(findings)
        keys = {(row["file"], row["finding_idx"]) for row in findings}
        if common_signature is None:
            common_signature = signature
            common_keys = keys
        elif signature != common_signature or keys != common_keys:
            raise RuntimeError(f"Update {update} finding/GT mapping does not match canonical family")
        attention = no_attention_evidence(result_dir, candidate)
        if not attention["verified_no_attention"]:
            raise RuntimeError(f"Update {update} failed no-attention verification")
        by_category: dict[str, list[dict[str, str]]] = defaultdict(list)
        for row in findings:
            by_category[row["category"]].append(row)
        categories = {category: aggregate(by_category[category]) for category in EXPERT_CATEGORIES}
        expert_rows = [row for row in findings if row["category"] in EXPERT_CATEGORIES]
        diffuse_rows = [row for row in findings if row["category"] in DIFFUSE_CATEGORIES]
        attention_rows = [row for row in findings if row["category"] in {"2b", "2c"}]
        checkpoint_data[update] = {
            "update": update,
            "checkpoint": checkpoint,
            "result_dir": result_dir,
            "candidate_path": candidate_path,
            "summary_path": summary_path,
            "findings_path": findings_path,
            "resolved_path": resolved_path,
            "candidate": candidate,
            "summary": summary,
            "findings": findings,
            "finding_signature": signature,
            "attention": attention,
            "categories": categories,
            "expert_pool": aggregate(expert_rows),
            "category_macro_dice": sum(categories[c]["mean_dice"] for c in EXPERT_CATEGORIES) / len(EXPERT_CATEGORIES),
            "diffuse": aggregate(diffuse_rows),
            "attention_pool": aggregate(attention_rows),
        }

    update10000_hash = digest_file(checkpoint_data[10000]["checkpoint"])
    checkpoint_hashes = {
        8000: {"sha256": KNOWN_UPDATE8000_SHA256, "source": str(ROOT / "outputs/dual_expert_optimizer_state_audit/checkpoint_provenance.json")},
        10000: {"sha256": update10000_hash, "source": "computed once by this CPU audit"},
    }

    comparable_rows: list[dict[str, Any]] = []
    for update in included_updates:
        data = checkpoint_data[update]
        comparable_rows.append({
            "optimizer_update": update,
            "checkpoint_path": str(data["checkpoint"]),
            "checkpoint_sha256": checkpoint_hashes[update]["sha256"],
            "sha256_source": checkpoint_hashes[update]["source"],
            "result_directory": str(data["result_dir"]),
            "result_file_path": str(data["findings_path"]),
            "summary_file_path": str(data["summary_path"]),
            "cases": data["summary"]["total_cases"],
            "findings": data["summary"]["total_findings"],
            "overall_dice": data["summary"]["mean_global_dice_per_finding"],
            "overall_hits": data["summary"]["total_hits"],
            "inference_threshold": 0.5,
            "global_hit_threshold": data["summary"]["params"]["global_hit_thr"],
            "postprocessing": "none/raw segmentation",
            "finding_gt_mapping_sha256": data["finding_signature"],
            "verified_no_attention": data["attention"]["verified_no_attention"],
            "inclusion_reason": "complete canonical raw full-200/381 result with identical cohort/mapping/GT/threshold/metric",
        })
    write_csv(output_dir / "comparable_checkpoint_inventory.csv", comparable_rows)

    excluded_rows: list[dict[str, Any]] = []
    for update in range(0, 10001, 1000):
        if update in included_updates:
            continue
        checkpoint_name = "checkpoint_initial.pth" if update == 0 else f"checkpoint_update_{update}.pth"
        fixed30 = LINEAGE / f"full_volume/update_{update:05d}/controlled_summary.json"
        fixed_summary = json.loads(fixed30.read_text()) if fixed30.is_file() else {}
        excluded_rows.append({
            "optimizer_update": update,
            "checkpoint_path": str((LINEAGE / "checkpoints" / checkpoint_name).resolve()),
            "existing_result_artifact": str(fixed30) if fixed30.is_file() else "",
            "existing_result_family": "fixed30" if fixed30.is_file() else "none discovered",
            "existing_cases": fixed_summary.get("cases"),
            "existing_findings": fixed_summary.get("findings"),
            "compatible_raw_full381_result_available": False,
            "exclusion_reason": (
                "only fixed30 30-case/49-finding result exists; incompatible with canonical full-200/381 family"
                if fixed30.is_file()
                else "no existing compatible result discovered"
            ),
        })
    for update in included_updates:
        fixed30 = LINEAGE / f"full_volume/update_{update:05d}/controlled_summary.json"
        fixed_summary = json.loads(fixed30.read_text())
        excluded_rows.append({
            "optimizer_update": update,
            "checkpoint_path": str(checkpoint_data[update]["checkpoint"]),
            "existing_result_artifact": str(fixed30),
            "existing_result_family": "fixed30 alternative artifact",
            "existing_cases": fixed_summary.get("cases"),
            "existing_findings": fixed_summary.get("findings"),
            "compatible_raw_full381_result_available": True,
            "exclusion_reason": "fixed30 artifact excluded from primary comparison; canonical raw full-381 artifact is included separately",
        })
    semantic_posthoc = CANONICAL_FAMILY / "full381_update10000/summary.json"
    if semantic_posthoc.is_file():
        excluded_rows.append({
            "optimizer_update": 10000,
            "checkpoint_path": str(checkpoint_data[10000]["checkpoint"]),
            "existing_result_artifact": str(semantic_posthoc),
            "existing_result_family": "semantic-v1/whole-lung postprocessed",
            "existing_cases": 200,
            "existing_findings": 381,
            "compatible_raw_full381_result_available": True,
            "exclusion_reason": "postprocessed semantic-v1/whole-lung metrics are not canonical raw segmentation metrics",
        })
    write_csv(output_dir / "excluded_checkpoint_inventory.csv", excluded_rows)

    reference = checkpoint_data[MATURE_UPDATE]
    category_rows: list[dict[str, Any]] = []
    for update in included_updates:
        data = checkpoint_data[update]
        for category in EXPERT_CATEGORIES:
            metrics = data["categories"][category]
            reference_metrics = reference["categories"][category]
            category_rows.append({
                "optimizer_update": update,
                "category": category,
                "n": metrics["n"],
                "mean_dice": metrics["mean_dice"],
                "hits": metrics["hits"],
                "mean_precision": metrics["mean_precision"],
                "mean_recall": metrics["mean_recall"],
                "mean_pred_gt_volume_ratio": metrics["mean_pred_gt_volume_ratio"],
                "dice_gap_vs_update10000": metrics["mean_dice"] - reference_metrics["mean_dice"],
                "hit_gap_vs_update10000": metrics["hits"] - reference_metrics["hits"],
            })
    write_csv(output_dir / "per_checkpoint_category_metrics.csv", category_rows)

    pool_rows: list[dict[str, Any]] = []
    for update in included_updates:
        data = checkpoint_data[update]
        previous = checkpoint_data.get(included_updates[included_updates.index(update) - 1]) if included_updates.index(update) else None
        pool_rows.append({
            "optimizer_update": update,
            "overall_n": data["summary"]["total_findings"],
            "overall_dice": data["summary"]["mean_global_dice_per_finding"],
            "overall_hits": data["summary"]["total_hits"],
            "expert_pool_n": data["expert_pool"]["n"],
            "expert_pool_finding_weighted_dice": data["expert_pool"]["mean_dice"],
            "expert_pool_hits": data["expert_pool"]["hits"],
            "expert_pool_category_macro_dice": data["category_macro_dice"],
            "expert_pool_gap_vs_update10000": data["expert_pool"]["mean_dice"] - reference["expert_pool"]["mean_dice"],
            "relative_expert_pool_vs_update10000": data["expert_pool"]["mean_dice"] / reference["expert_pool"]["mean_dice"],
            "diffuse_1c1d1f_n": data["diffuse"]["n"],
            "diffuse_1c1d1f_dice": data["diffuse"]["mean_dice"],
            "diffuse_1c1d1f_hits": data["diffuse"]["hits"],
            "combined_2b2c_n": data["attention_pool"]["n"],
            "combined_2b2c_dice": data["attention_pool"]["mean_dice"],
            "combined_2b2c_hits": data["attention_pool"]["hits"],
            "gain_expert_pool_from_previous_available": (
                data["expert_pool"]["mean_dice"] - previous["expert_pool"]["mean_dice"] if previous else None
            ),
        })
    write_csv(output_dir / "expert_pool_summary.csv", pool_rows)

    maturity_rows: list[dict[str, Any]] = []
    passing_updates: list[int] = []
    for update in included_updates:
        data = checkpoint_data[update]
        pool_gap = data["expert_pool"]["mean_dice"] - reference["expert_pool"]["mean_dice"]
        pool_relative = data["expert_pool"]["mean_dice"] / reference["expert_pool"]["mean_dice"]
        b_gap = data["categories"]["2b"]["mean_dice"] - reference["categories"]["2b"]["mean_dice"]
        c_gap = data["categories"]["2c"]["mean_dice"] - reference["categories"]["2c"]["mean_dice"]
        combined_hit_gap = data["attention_pool"]["hits"] - reference["attention_pool"]["hits"]
        diffuse_gap = data["diffuse"]["mean_dice"] - reference["diffuse"]["mean_dice"]
        diffuse_hit_gap = data["diffuse"]["hits"] - reference["diffuse"]["hits"]
        pass_pool_relative = pool_relative >= 0.985
        pass_pool_gap = pool_gap >= -0.003
        pass_2b = b_gap >= -0.005
        pass_2c = c_gap >= -0.005
        pass_hits = combined_hit_gap >= -2
        # Operationalize "obvious collapse" jointly, avoiding rejection on a
        # single noisy 1d/1f finding: >0.01 Dice loss AND >2 lost hits is collapse.
        pass_diffuse = diffuse_gap >= -0.010 or diffuse_hit_gap >= -2
        passes = all((pass_pool_relative, pass_pool_gap, pass_2b, pass_2c, pass_hits, pass_diffuse))
        if passes:
            passing_updates.append(update)
        maturity_rows.append({
            "optimizer_update": update,
            "expert_pool_dice": data["expert_pool"]["mean_dice"],
            "expert_pool_gap_vs_reference": pool_gap,
            "relative_expert_pool": pool_relative,
            "pass_relative_at_least_0p985": pass_pool_relative,
            "pass_absolute_gap_at_least_minus0p003": pass_pool_gap,
            "2b_dice_gap": b_gap,
            "pass_2b_gap_at_least_minus0p005": pass_2b,
            "2c_dice_gap": c_gap,
            "pass_2c_gap_at_least_minus0p005": pass_2c,
            "combined_2b2c_hits": data["attention_pool"]["hits"],
            "combined_2b2c_hit_gap": combined_hit_gap,
            "pass_combined_hits_gap_at_least_minus2": pass_hits,
            "diffuse_1c1d1f_dice_gap": diffuse_gap,
            "diffuse_1c1d1f_hit_gap": diffuse_hit_gap,
            "pass_no_obvious_diffuse_collapse": pass_diffuse,
            "mature_enough": passes,
        })
    write_csv(output_dir / "maturity_criteria.csv", maturity_rows)
    earliest_pass = min(passing_updates)

    trajectory_rows: list[dict[str, Any]] = []
    for index, update in enumerate(included_updates):
        data = checkpoint_data[update]
        previous = checkpoint_data[included_updates[index - 1]] if index else None
        following = checkpoint_data[included_updates[index + 1]] if index + 1 < len(included_updates) else None
        metrics = {
            "overall_dice": data["summary"]["mean_global_dice_per_finding"],
            "expert_pool_dice": data["expert_pool"]["mean_dice"],
            "2b_dice": data["categories"]["2b"]["mean_dice"],
            "2c_dice": data["categories"]["2c"]["mean_dice"],
            "1c_dice": data["categories"]["1c"]["mean_dice"],
            "diffuse_1c1d1f_dice": data["diffuse"]["mean_dice"],
        }
        trajectory_rows.append({
            "optimizer_update": update,
            **metrics,
            **{
                f"gain_{name}_from_previous_available": value - (
                    previous["summary"]["mean_global_dice_per_finding"] if name == "overall_dice" else
                    previous["expert_pool"]["mean_dice"] if name == "expert_pool_dice" else
                    previous["categories"][name.removesuffix("_dice")]["mean_dice"] if name in {"2b_dice", "2c_dice", "1c_dice"} else
                    previous["diffuse"]["mean_dice"]
                ) if previous else None
                for name, value in metrics.items()
            },
            **{
                f"gain_{name}_to_next_available": (
                    following["summary"]["mean_global_dice_per_finding"] if name == "overall_dice" else
                    following["expert_pool"]["mean_dice"] if name == "expert_pool_dice" else
                    following["categories"][name.removesuffix("_dice")]["mean_dice"] if name in {"2b_dice", "2c_dice", "1c_dice"} else
                    following["diffuse"]["mean_dice"]
                ) - value if following else None
                for name, value in metrics.items()
            },
        })
    write_csv(output_dir / "training_trajectory.csv", trajectory_rows)

    if earliest_pass == 8000:
        recommendation_label = "KEEP UPDATE 8000"
    elif earliest_pass < 8000:
        recommendation_label = f"USE EARLIER CHECKPOINT {earliest_pass}"
    else:
        recommendation_label = f"USE LATER CHECKPOINT {earliest_pass}"

    runtime_seconds = time.perf_counter() - started
    peak_rss_mb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0
    git = git_snapshot()
    mature = checkpoint_data[MATURE_UPDATE]
    selected = checkpoint_data[earliest_pass]
    trajectory_interpretation = (
        "C — update 8000 is the earliest checkpoint demonstrably mature in the compatible full-381 family. "
        "Earlier maturity cannot be measured because updates 0–7000 have only fixed30 results. "
        "The expert-pool gain from 8000 to 10000 is only "
        f"{mature['expert_pool']['mean_dice'] - checkpoint_data[8000]['expert_pool']['mean_dice']:.9f}, "
        "so there is no material post-8000 expert-pool improvement."
    )

    provenance = {
        "audit_generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "repository_root": str(ROOT),
        "lineage_directory": str(LINEAGE),
        "canonical_result_family": str(CANONICAL_FAMILY),
        "family_selection_reason": "largest internally consistent canonical raw full-200/381 no-attention family; two checkpoints",
        "evaluation_driver": str(EVALUATION_DRIVER),
        "evaluation_driver_sha256": digest_file(EVALUATION_DRIVER),
        "evaluation_contract": {
            "validation_cohort": "MICCAI_challenge_dataset.json val split",
            "cases": 200,
            "findings": 381,
            "inference_threshold": 0.5,
            "postprocessing": "none/raw segmentation",
            "metric": "global-only Dice; hit if Dice >= 0.1",
            "gt_directory": "data/segmentations",
            "finding_gt_mapping_sha256": common_signature,
        },
        "usable_updates": list(included_updates),
        "checkpoint_hashes": checkpoint_hashes,
        "result_artifact_hashes": {
            str(update): {
                "per_finding_metrics_csv": str(checkpoint_data[update]["findings_path"]),
                "per_finding_metrics_sha256": digest_file(checkpoint_data[update]["findings_path"]),
                "summary_json": str(checkpoint_data[update]["summary_path"]),
                "summary_sha256": digest_file(checkpoint_data[update]["summary_path"]),
            }
            for update in included_updates
        },
        "no_attention_evidence": {
            str(update): checkpoint_data[update]["attention"] for update in included_updates
        },
        "analysis_constraints": {
            "cpu_only": True,
            "new_inference_run": False,
            "prediction_volumes_loaded": False,
            "training_run": False,
        },
        "runtime": {
            "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
            "cpus_per_task": os.environ.get("SLURM_CPUS_PER_TASK", "local"),
            "requested_memory_mb": os.environ.get("SLURM_MEM_PER_NODE"),
            "analysis_runtime_seconds_before_final_writes": runtime_seconds,
            "process_peak_rss_mb": peak_rss_mb,
        },
        "git": git,
    }
    json_dump(output_dir / "input_provenance.json", provenance)

    selected_row = next(row for row in maturity_rows if row["optimizer_update"] == earliest_pass)
    recommendation = {
        "recommendation": recommendation_label,
        "selected_optimizer_update": earliest_pass,
        "selected_checkpoint": str(selected["checkpoint"]),
        "selected_checkpoint_sha256": checkpoint_hashes[earliest_pass]["sha256"],
        "mature_reference_update": MATURE_UPDATE,
        "mature_reference_checkpoint": str(mature["checkpoint"]),
        "earliest_available_checkpoint_that_passes": earliest_pass,
        "selected_maturity_metrics": selected_row,
        "trajectory_classification": trajectory_interpretation,
        "uncertainty": "No compatible raw full-381 results exist before update 8000, so the audit cannot test whether an earlier checkpoint would also pass.",
        "optimizer_context": "Load model weights only; use fresh matched optimizer in both arms. Tentative LRs: encoder 5e-6, decoder/head 5e-5, attention 1e-4; effective global batch 4.",
        "dual_expert_training_launched": False,
    }
    json_dump(output_dir / "recommendation.json", recommendation)

    skipped = ", ".join(str(update) for update in range(0, 8000, 1000)) + ", 9000"
    category_table = "\n".join(
        f"| {row['optimizer_update']} | {row['category']} | {row['n']} | {row['mean_dice']:.9f} | "
        f"{row['hits']} | {row['mean_precision']:.6f} | {row['mean_recall']:.6f} | "
        f"{row['mean_pred_gt_volume_ratio']:.6f} | {row['dice_gap_vs_update10000']:+.9f} |"
        for row in category_rows
    )
    pool_table = "\n".join(
        f"| {row['optimizer_update']} | {row['overall_dice']:.9f} | {row['overall_hits']} | "
        f"{row['expert_pool_finding_weighted_dice']:.9f} | {row['expert_pool_category_macro_dice']:.9f} | "
        f"{row['expert_pool_gap_vs_update10000']:+.9f} | {row['relative_expert_pool_vs_update10000']:.6%} | "
        f"{row['combined_2b2c_hits']} | {row['diffuse_1c1d1f_dice']:.9f} |"
        for row in pool_rows
    )
    criteria_table = "\n".join(
        f"| {row['optimizer_update']} | {row['relative_expert_pool']:.6%} | {row['expert_pool_gap_vs_reference']:+.9f} | "
        f"{row['2b_dice_gap']:+.9f} | {row['2c_dice_gap']:+.9f} | {row['combined_2b2c_hit_gap']:+d} | "
        f"{row['diffuse_1c1d1f_dice_gap']:+.9f} | **{'PASS' if row['mature_enough'] else 'FAIL'}** |"
        for row in maturity_rows
    )
    report = f"""# Dual-expert checkpoint-maturity audit

## Recommendation

**{recommendation_label}.** Update 8000 is the earliest checkpoint with an existing compatible raw full-200/381 result, and it satisfies every maturity criterion relative to update 10000.

This audit ran CPU-only and did not train anything, run GPU inference, generate missing inference, or load NIfTI prediction volumes.

## Comparable evaluation family and provenance

The primary family is `outputs/nonattention_baseline_selection/full381_update{{8000,10000}}`, generated by `{EVALUATION_DRIVER}`. Both results use the same val cohort (200 cases / 381 findings), finding/channel and GT mapping (SHA256 `{common_signature}`), raw segmentation at inference threshold `0.5`, no postprocessing, and the same global Dice implementation with hit threshold `0.1`.

Usable checkpoints and exact artifacts:

- update 8000: `{checkpoint_data[8000]['checkpoint']}`; results `{checkpoint_data[8000]['findings_path']}`; SHA256 `{checkpoint_hashes[8000]['sha256']}`.
- update 10000: `{checkpoint_data[10000]['checkpoint']}`; results `{checkpoint_data[10000]['findings_path']}`; SHA256 `{checkpoint_hashes[10000]['sha256']}`.

Both candidate summaries and both shard configuration files explicitly disable spatial attention, S2, S3, and S3 decoder gating. They are ordinary no-attention checkpoints from the intended lineage.

Updates {skipped} were skipped from the primary audit. Their only existing lineage results are fixed30 (30 cases / 49 findings), not compatible raw full-381 results. No inference was submitted to fill these gaps. The update-10000 semantic-v1/whole-lung postprocessed summary was also excluded.

## Overall and expert-pool trajectory

The mature reference is update 10000: it has the higher overall Dice (`{mature['summary']['mean_global_dice_per_finding']:.9f}` versus `{checkpoint_data[8000]['summary']['mean_global_dice_per_finding']:.9f}`) and marginally higher primary expert-pool Dice. It remains the intended frozen preservation model.

| Update | Overall Dice | Overall hits | Expert-pool Dice | Category-macro Dice | Pool gap vs 10000 | Relative pool | 2b+2c hits | Diffuse 1c+1d+1f Dice |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
{pool_table}

From update 8000 to 10000, overall Dice gains `{mature['summary']['mean_global_dice_per_finding'] - checkpoint_data[8000]['summary']['mean_global_dice_per_finding']:+.9f}`, while expert-pool Dice gains only `{mature['expert_pool']['mean_dice'] - checkpoint_data[8000]['expert_pool']['mean_dice']:+.9f}`. The trajectories are: 2b `{checkpoint_data[8000]['categories']['2b']['mean_dice']:.9f} → {mature['categories']['2b']['mean_dice']:.9f}`, 2c `{checkpoint_data[8000]['categories']['2c']['mean_dice']:.9f} → {mature['categories']['2c']['mean_dice']:.9f}`, 1c `{checkpoint_data[8000]['categories']['1c']['mean_dice']:.9f} → {mature['categories']['1c']['mean_dice']:.9f}`, and diffuse 1c+1d+1f `{checkpoint_data[8000]['diffuse']['mean_dice']:.9f} → {mature['diffuse']['mean_dice']:.9f}`.

Trajectory classification: **{trajectory_interpretation}**

## Per-category expert metrics

| Update | Category | n | Mean Dice | Hits | Precision | Recall | Pred/GT volume | Dice gap vs 10000 |
|---:|:---:|---:|---:|---:|---:|---:|---:|---:|
{category_table}

## Maturity criteria

For the collective 1c/1d/1f safeguard, an obvious collapse is operationally defined as both more than `0.010` weighted Dice loss and more than two lost hits. This avoids rejecting a checkpoint due to one noisy 1d/1f finding.

| Update | Relative expert pool | Pool gap | 2b gap | 2c gap | 2b+2c hit gap | Diffuse gap | Result |
|---:|---:|---:|---:|---:|---:|---:|:---:|
{criteria_table}

Update 8000 passes: expert-pool Dice is `{selected['expert_pool']['mean_dice']:.9f}` (`{selected['expert_pool']['mean_dice'] / mature['expert_pool']['mean_dice']:.6%}` of reference, gap `{selected['expert_pool']['mean_dice'] - mature['expert_pool']['mean_dice']:+.9f}`); 2b gap is `{selected['categories']['2b']['mean_dice'] - mature['categories']['2b']['mean_dice']:+.9f}`; 2c gap is `{selected['categories']['2c']['mean_dice'] - mature['categories']['2c']['mean_dice']:+.9f}`; combined 2b+2c hits are `{selected['attention_pool']['hits']}` versus `{mature['attention_pool']['hits']}`; and the diffuse group is better, not collapsed.

## Resource and repository audit

- Slurm job: `{os.environ.get('SLURM_JOB_ID')}`; CPU-only, `{os.environ.get('SLURM_CPUS_PER_TASK', 'local')}` CPUs, requested memory `{os.environ.get('SLURM_MEM_PER_NODE')} MB`.
- Analysis runtime before final writes: `{runtime_seconds:.3f}` seconds; process peak RSS: `{peak_rss_mb:.1f}` MB.
- Code added: `{Path(__file__).resolve()}`.
- `git diff --check` exit code: `{git['diff_check_exit_code']}`.
- `git status --short` snapshot:

```text
{chr(10).join(git['status_short']) if git['status_short'] else '(clean)'}
```

The specialist arms should load model weights only and use the already-selected fresh matched optimizer policy. **No dual-expert training job was launched.**
"""
    (output_dir / "report.md").write_text(report)

    print(json.dumps({
        "status": "complete",
        "recommendation": recommendation_label,
        "earliest_pass": earliest_pass,
        "usable_updates": included_updates,
        "update8000_expert_pool_dice": checkpoint_data[8000]["expert_pool"]["mean_dice"],
        "update10000_expert_pool_dice": mature["expert_pool"]["mean_dice"],
        "update8000_relative": checkpoint_data[8000]["expert_pool"]["mean_dice"] / mature["expert_pool"]["mean_dice"],
        "output_dir": str(output_dir),
        "runtime_seconds": runtime_seconds,
        "peak_rss_mb": peak_rss_mb,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
