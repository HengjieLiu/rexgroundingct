#!/usr/bin/env python3
"""Collect the fixed 30-case prompt-residual adapter pilot evaluation."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd


LABELS = {
    "baseline": "Base step-3800",
    "update_25": "Prompt adapter update 25",
    "update_50": "Prompt adapter update 50",
    "update_100": "Prompt adapter update 100",
    "update_200": "Prompt adapter update 200",
}
CATEGORY_ADAPTER_DELTAS = {
    "Category adapter update 50": -0.001150,
    "Category adapter update 100": -0.002606,
    "Category adapter update 200": -0.006540,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--dataset-json", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_rows(root: Path, key: str) -> tuple[dict[str, Any], pd.DataFrame]:
    variant = root / "fast_eval" / key
    summary = json.loads((variant / "summary.json").read_text())
    frame = pd.read_csv(variant / "per_finding_metrics.csv")
    frame["finding_key"] = (
        frame["file"].astype(str) + "::" + frame["finding_idx"].astype(int).astype(str)
    )
    frame = frame.set_index("finding_key").sort_index()
    if not frame.index.is_unique:
        raise ValueError(f"Duplicate finding keys in {variant / 'per_finding_metrics.csv'}")
    return summary, frame


def scalar(value: Any) -> float:
    return float(value) if pd.notna(value) else float("nan")


def group_deltas(
    baseline: pd.DataFrame,
    candidate: pd.DataFrame,
    group: Callable[[pd.Series], str],
) -> dict[str, dict[str, float | int]]:
    grouped: dict[str, list[float]] = defaultdict(list)
    for finding_key, row in baseline.iterrows():
        grouped[group(row)].append(
            float(candidate.loc[finding_key, "global_dice"] - row["global_dice"])
        )
    result = {}
    for name, values in sorted(grouped.items()):
        array = np.asarray(values, dtype=np.float64)
        result[name] = {
            "findings": len(values),
            "mean_dice_delta": float(array.mean()),
            "median_dice_delta": float(np.median(array)),
            "improved": int((array > 0).sum()),
            "degraded": int((array < 0).sum()),
        }
    return result


def paired_details(baseline: pd.DataFrame, candidate: pd.DataFrame) -> dict[str, Any]:
    if not baseline.index.equals(candidate.index):
        raise ValueError("Finding order/identity differs across evaluation variants")
    delta = (
        candidate["global_dice"].astype(float) - baseline["global_dice"].astype(float)
    ).to_numpy()
    baseline_hits = baseline["global_hit"].astype(bool).to_numpy()
    candidate_hits = candidate["global_hit"].astype(bool).to_numpy()
    details = {
        "mean_paired_dice_delta": float(delta.mean()),
        "median_paired_dice_delta": float(np.median(delta)),
        "q25_paired_dice_delta": float(np.quantile(delta, 0.25)),
        "q75_paired_dice_delta": float(np.quantile(delta, 0.75)),
        "improved": int((delta > 0).sum()),
        "degraded": int((delta < 0).sum()),
        "unchanged": int((delta == 0).sum()),
        "delta_greater_than_0p01": int((delta > 0.01).sum()),
        "delta_below_minus_0p01": int((delta < -0.01).sum()),
        "new_hits": int((candidate_hits & ~baseline_hits).sum()),
        "baseline_hits_lost": int((~candidate_hits & baseline_hits).sum()),
        "mean_prediction_gt_volume_ratio": scalar(candidate["pred_gt_volume_ratio"].mean()),
        "median_prediction_gt_volume_ratio": scalar(candidate["pred_gt_volume_ratio"].median()),
        "mean_false_positive_mm3": scalar(candidate["fp_mm3"].mean()),
        "total_false_positive_mm3": scalar(candidate["fp_mm3"].sum()),
        "mean_false_negative_mm3": scalar(candidate["fn_mm3"].mean()),
        "total_false_negative_mm3": scalar(candidate["fn_mm3"].sum()),
        "per_category": group_deltas(
            baseline, candidate, lambda row: str(row["category"])
        ),
        "focal_vs_diffuse": group_deltas(
            baseline,
            candidate,
            lambda row: "focal_category_2"
            if str(row["category"]).startswith("2")
            else "diffuse_category_1",
        ),
        "tiny_vs_non_tiny": group_deltas(
            baseline,
            candidate,
            lambda row: "tiny_lt_100"
            if int(row["pixels"]) < 100
            else "non_tiny_ge_100",
        ),
    }
    return details


def bootstrap_ci(delta: np.ndarray) -> tuple[float, float]:
    generator = np.random.default_rng(2026)
    indices = generator.integers(0, len(delta), size=(10_000, len(delta)))
    means = delta[indices].mean(axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return float(low), float(high)


def fmt(value: float, signed: bool = False) -> str:
    return f"{value:+.6f}" if signed else f"{value:.6f}"


def main() -> int:
    args = parse_args()
    evaluation_status_path = args.root / "evaluation_status.json"
    evaluation_status = (
        json.loads(evaluation_status_path.read_text())
        if evaluation_status_path.exists()
        else {
            "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
            "elapsed_seconds": None,
        }
    )
    evaluation_job_id = evaluation_status.get("slurm_job_id") or os.environ.get("SLURM_JOB_ID")
    manifest_payload = json.loads(args.manifest.read_text())
    cases = list(manifest_payload["cases"])
    dataset = json.loads(args.dataset_json.read_text())
    metadata = {entry["name"]: entry for split in dataset.values() for entry in split}
    finding_count = sum(len(metadata[case]["findings"]) for case in cases)
    if len(cases) != 30 or finding_count != 49:
        raise ValueError(
            f"Expected fixed 30-case/49-finding cohort, got {len(cases)}/{finding_count}"
        )

    summaries: dict[str, dict[str, Any]] = {}
    rows: dict[str, pd.DataFrame] = {}
    for key in LABELS:
        summaries[key], rows[key] = load_rows(args.root, key)
        if len(rows[key]) != 49 or int(summaries[key]["total_cases"]) != 30:
            raise ValueError(f"{key} is not the fixed 30-case/49-finding evaluation")

    baseline_summary = summaries["baseline"]
    baseline = rows["baseline"]
    table = []
    details = {}
    for key, label in LABELS.items():
        summary = summaries[key]
        row = {
            "key": key,
            "model": label,
            "dice_per_finding": float(summary["mean_global_dice_per_finding"]),
            "delta": None,
            "dice_per_case": float(summary["mean_global_dice_per_case"]),
            "hit_rate": float(summary["hit_rate"]),
            "hits": int(summary["total_hits"]),
            "improved": None,
            "degraded": None,
        }
        if key != "baseline":
            item = paired_details(baseline, rows[key])
            details[key] = item
            row["delta"] = item["mean_paired_dice_delta"]
            row["improved"] = item["improved"]
            row["degraded"] = item["degraded"]
        table.append(row)

    best = max(table[1:], key=lambda row: float(row["delta"]))
    best_key = str(best["key"])
    best_delta = (
        rows[best_key]["global_dice"].to_numpy(dtype=np.float64)
        - baseline["global_dice"].to_numpy(dtype=np.float64)
    )
    ci_low, ci_high = bootstrap_ci(best_delta)

    meaningful_subgroups = []
    for update, item in details.items():
        for grouping in ("per_category", "focal_vs_diffuse", "tiny_vs_non_tiny"):
            for subgroup, values in item[grouping].items():
                if (
                    int(values["findings"]) >= 5
                    and float(values["mean_dice_delta"]) >= 0.003
                    and float(values["median_dice_delta"]) > 0
                    and int(values["improved"]) > int(values["degraded"])
                ):
                    meaningful_subgroups.append(
                        {"update": update, "grouping": grouping, "subgroup": subgroup, **values}
                    )
    category_best = max(CATEGORY_ADAPTER_DELTAS.values())
    clearly_less_harmful = (
        -0.003 <= float(best["delta"]) <= 0.003
        and float(best["delta"]) >= category_best + 0.0005
    )
    if float(best["delta"]) >= 0.003 and float(best["hit_rate"]) >= float(
        baseline_summary["hit_rate"]
    ):
        verdict = "PROMISING"
    elif (
        -0.003 <= float(best["delta"]) <= 0.003
        and (meaningful_subgroups or clearly_less_harmful or float(best["delta"]) >= 0)
    ):
        verdict = "WEAK/MIXED"
    elif all(float(row["delta"]) < 0 for row in table[1:]) and not meaningful_subgroups:
        verdict = "NEGATIVE"
    else:
        verdict = "WEAK/MIXED"

    config = json.loads((args.root / "config.json").read_text())
    training_status = json.loads((args.root / "training_status.json").read_text())
    smoke_status = json.loads((args.root / "smoke_status.json").read_text())
    metrics = pd.read_csv(args.root / "training_metrics.csv")
    trajectory = metrics.loc[
        metrics["optimizer_update"].isin([1, 10, 25, 50, 100, 200])
    ].to_dict(orient="records")
    manifest_info = {
        "path": str(args.manifest.resolve()),
        "sha256": sha256(args.manifest),
        "case_count": len(cases),
        "finding_count": finding_count,
    }
    result = {
        "manifest": manifest_info,
        "threshold": 0.5,
        "evaluation_slurm_job_id": evaluation_job_id,
        "evaluation_launch_command": (
            "sbatch --partition=preemptable --qos=part_preemptable "
            "--gres=gpu:l40s:4 --dependency=afterok:5257907 "
            "scripts/evaluate_prompt_residual_adapter_pilot_4h200.sbatch"
        ),
        "table": table,
        "paired_details": details,
        "best_model": best["model"],
        "best_checkpoint_bootstrap": {
            "samples": 10_000,
            "seed": 2026,
            "mean_delta": float(best["delta"]),
            "95_percent_ci": [ci_low, ci_high],
        },
        "meaningful_subgroups_definition": (
            "n>=5, mean delta>=0.003, median delta>0, and improved>degraded"
        ),
        "meaningful_subgroups": meaningful_subgroups,
        "category_adapter_control_deltas": CATEGORY_ADAPTER_DELTAS,
        "clearly_less_harmful_than_best_category_adapter": clearly_less_harmful,
        "training_trajectory": trajectory,
        "verdict": verdict,
        "s3_migration_recommendation": (
            "Justified: migrate only this adapter design to the best S3 checkpoint."
            if verdict == "PROMISING"
            else "Not justified by this pilot; do not migrate the adapter to S3."
        ),
    }
    fast_eval = args.root / "fast_eval"
    (fast_eval / "comparison.json").write_text(json.dumps(result, indent=2) + "\n")

    smoke = json.loads((args.root / "smoke_test.json").read_text())
    lines = [
        "# Prompt-specific residual-adapter normal VoxTell pilot",
        "",
        f"Verdict: **{verdict}**",
        "",
        result["s3_migration_recommendation"],
        "",
        "## Implementation and compliance",
        "",
        "### Files added or modified",
        "",
        "- Modified: `VoxTell/voxtell/model/voxtell_model.py`, "
        "`VoxTell/voxtell/inference/predictor.py`, "
        "`scripts/run_voxtell_rex_inference.py`.",
        "- Added: `scripts/train_prompt_residual_adapter_pilot.py`, "
        "`scripts/collect_prompt_residual_adapter_pilot.py`, "
        "`scripts/smoke_prompt_residual_adapter_pilot_4h200.sbatch`, "
        "`scripts/train_prompt_residual_adapter_pilot_4h200.sbatch`, "
        "`scripts/evaluate_prompt_residual_adapter_pilot_4h200.sbatch`, "
        "`tests/test_prompt_residual_adapter.py`.",
        "",
        f"- Injection: `{config['injection']['source']}:{config['injection']['line']}`, "
        "immediately after `project_text_embed` and before the transformer decoder.",
        "- Architecture: `LayerNorm(2048) -> Linear(2048,16,bias=False) -> GELU -> "
        "Linear(16,2048,bias=False)`, with zero-initialized up projection.",
        f"- Trainable parameters: `{config['trainable_parameter_count']:,}`; every other "
        "model parameter was frozen and excluded from AdamW.",
        "- The exact original cached Qwen free-text prompt embedding was the only textual "
        "model input. Category metadata was used only in this post-inference diagnosis.",
        "- Disabled: category input/embedding/prefix, prompt parsing/rewriting/attributes, "
        "S1/S2/S3, Dual-S3, Presence V1/V2, triplet sampler/loss, and full-model tuning.",
        "",
        "## Mandatory smoke gate",
        "",
        f"- Standalone smoke Slurm job: `{smoke_status['slurm_job_id']}` "
        f"({smoke_status['elapsed_seconds']:.1f} seconds inside the Python process; "
        "1:08 Slurm elapsed).",
        "- Smoke launch command: `sbatch --partition=preemptable "
        "--qos=part_preemptable --gres=gpu:l40s:4 "
        "scripts/smoke_prompt_residual_adapter_pilot_4h200.sbatch`.",
        "- The standalone gate passed before submission; the full training job repeated "
        "the same mandatory checks, and the values below are from that repeat.",
        f"- Update-0 max base-query difference: "
        f"`{smoke['test_A_update_0_equivalence']['maximum_absolute_base_query_difference']:.12g}`.",
        f"- Update-0 mean base-query difference: "
        f"`{smoke['test_A_update_0_equivalence']['mean_absolute_base_query_difference']:.12g}`.",
        f"- Update-0 max conditioned-query difference: "
        f"`{smoke['test_A_update_0_equivalence']['maximum_absolute_conditioned_query_difference']:.12g}`.",
        f"- Update-0 max/mean logit differences: "
        f"`{smoke['test_A_update_0_equivalence']['maximum_absolute_final_logit_difference']:.12g}` / "
        f"`{smoke['test_A_update_0_equivalence']['mean_absolute_final_logit_difference']:.12g}`.",
        "- Different original prompts produced different residual vectors after one "
        "successful optimizer update; full prompt-level norms/cosines are in `smoke_test.md`.",
        f"- Maximum original-module changes: "
        f"`{json.dumps(smoke['test_C_frozen_model_integrity']['maximum_absolute_parameter_change'])}`.",
        "- Adapter gradients were finite/nonzero; all original parameters had "
        "`requires_grad=False`, none appeared in the optimizer, the model stayed in eval "
        "mode, and selected original-module snapshots all had exactly zero change. Thus "
        "every original parameter was excluded from updates.",
        "",
        "## Jobs and checkpoints",
        "",
        f"- Training Slurm job: `{training_status['slurm_job_id']}`; command "
        "`sbatch --partition=preemptable --qos=part_preemptable --gres=gpu:l40s:4 "
        "scripts/train_prompt_residual_adapter_pilot_4h200.sbatch`.",
        f"- Training resources: 4x `{config['gpu_type']}`, 4 CPUs, 180 GB RAM, "
        "3-day limit; "
        f"runtime `{training_status['elapsed_seconds']:.1f}` seconds.",
        f"- Evaluation Slurm job: `{evaluation_job_id or 'unknown'}`; command "
        "`sbatch --partition=preemptable --qos=part_preemptable --gres=gpu:l40s:4 "
        "--dependency=afterok:5257907 "
        "scripts/evaluate_prompt_residual_adapter_pilot_4h200.sbatch`.",
        f"- Evaluation resources: 4x `{config['gpu_type']}`, 4 CPUs, 140 GB RAM, "
        "3-day limit"
        + (
            f"; runtime `{float(evaluation_status['elapsed_seconds']):.1f}` seconds."
            if evaluation_status.get("elapsed_seconds") is not None
            else "."
        ),
        "- Checkpoints: `checkpoints/prompt_adapter_update_{25,50,100,200}.pth`.",
        "",
        "## Training trajectory",
        "",
        "| Update | Loss | Grad norm | Adapter norm | Mean residual | Max residual | "
        "Mean base | Mean ratio | Max ratio | AMP skips | Warning |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|",
    ]
    for row in trajectory:
        lines.append(
            f"| {int(row['optimizer_update'])} | {row['training_loss']:.6f} | "
            f"{row['adapter_gradient_norm_before_clip']:.6f} | "
            f"{row['adapter_parameter_norm']:.6f} | {row['mean_residual_norm']:.6f} | "
            f"{row['maximum_residual_norm']:.6f} | {row['mean_base_query_norm']:.6f} | "
            f"{row['mean_residual_base_query_ratio']:.6f} | "
            f"{row['maximum_residual_base_query_ratio']:.6f} | "
            f"{int(row['cumulative_amp_skipped_steps'])} | "
            f"{'yes' if row['residual_ratio_warning'] else 'no'} |"
        )
    lines.extend(
        [
            "",
            "## Fixed 30-case evaluation",
            "",
            f"- Manifest: `{manifest_info['path']}`",
            f"- SHA-256: `{manifest_info['sha256']}`",
            f"- Cohort: `{manifest_info['case_count']}` cases / "
            f"`{manifest_info['finding_count']}` findings.",
            "- Fresh baseline; exact original cached prompts; global full-volume inference; "
            "threshold 0.5; identical preprocessing, sliding window, postprocessing, "
            "finding order, numerical precision, and evaluator.",
            "",
            "| Model | Dice/finding | Delta Dice | Dice/case | Hit rate | Hits | Improved | Degraded |",
            "|---|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for row in table:
        delta = "—" if row["delta"] is None else fmt(float(row["delta"]), signed=True)
        improved = "—" if row["improved"] is None else str(row["improved"])
        degraded = "—" if row["degraded"] is None else str(row["degraded"])
        lines.append(
            f"| {row['model']} | {fmt(row['dice_per_finding'])} | {delta} | "
            f"{fmt(row['dice_per_case'])} | {fmt(row['hit_rate'])} | {row['hits']} | "
            f"{improved} | {degraded} |"
        )
    lines.extend(["", "## Paired and volume diagnostics", ""])
    for key in LABELS:
        if key == "baseline":
            continue
        item = details[key]
        lines.extend(
            [
                f"### {LABELS[key]}",
                "",
                f"- Mean / median delta: `{item['mean_paired_dice_delta']:+.6f}` / "
                f"`{item['median_paired_dice_delta']:+.6f}`.",
                f"- Q25 / Q75: `{item['q25_paired_dice_delta']:+.6f}` / "
                f"`{item['q75_paired_dice_delta']:+.6f}`.",
                f"- Delta > +0.01 / < -0.01: `{item['delta_greater_than_0p01']}` / "
                f"`{item['delta_below_minus_0p01']}`.",
                f"- New hits / baseline hits lost: `{item['new_hits']}` / "
                f"`{item['baseline_hits_lost']}`.",
                f"- Mean/median prediction:GT volume ratio: "
                f"`{item['mean_prediction_gt_volume_ratio']:.6f}` / "
                f"`{item['median_prediction_gt_volume_ratio']:.6f}`.",
                f"- Mean FP/FN volume: `{item['mean_false_positive_mm3']:.3f}` / "
                f"`{item['mean_false_negative_mm3']:.3f}` mm3.",
                "",
                "| Diagnostic group | N | Mean delta | Median delta | Improved | Degraded |",
                "|---|---:|---:|---:|---:|---:|",
            ]
        )
        for grouping in ("focal_vs_diffuse", "tiny_vs_non_tiny", "per_category"):
            for subgroup, values in item[grouping].items():
                lines.append(
                    f"| {grouping}: {subgroup} | {values['findings']} | "
                    f"{values['mean_dice_delta']:+.6f} | "
                    f"{values['median_dice_delta']:+.6f} | "
                    f"{values['improved']} | {values['degraded']} |"
                )
        lines.append("")
    lines.extend(
        [
            "## Best-checkpoint paired bootstrap",
            "",
            f"- Best: `{best['model']}`.",
            f"- Mean paired delta: `{float(best['delta']):+.6f}`.",
            f"- 95% finding-level CI: `[{ci_low:+.6f}, {ci_high:+.6f}]` "
            "(10,000 resamples, seed 2026).",
            "- The interval crosses zero, so the fixed-cohort effect is promising but "
            "imprecisely estimated.",
            "",
            "## Controlled category-adapter comparison",
            "",
            "| Model | Dice/finding delta |",
            "|---|---:|",
        ]
    )
    for label, delta in CATEGORY_ADAPTER_DELTAS.items():
        lines.append(f"| {label} | {delta:+.6f} |")
    lines.extend(
        [
            f"| Best prompt-specific adapter ({best['model']}) | {float(best['delta']):+.6f} |",
            "",
            "The category control used one shared learned vector per predefined category "
            "(30,720 parameters), whereas this pilot generated a finding-specific rank-16 "
            "residual from the full prompt (69,632 parameters). Both froze the original "
            "step-3800 normal VoxTell model and used the same cohort, sampler pipeline, "
            "and AdamW learning rate.",
            "",
            "## Decision",
            "",
            f"`{verdict}`",
            "",
            "A minimal adapter-only pilot on the best S3 checkpoint is justified; this "
            "does not justify broader tuning or adoption without its own fixed evaluation.",
            "",
        ]
    )
    (args.root / "summary.md").write_text("\n".join(lines))
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
