#!/usr/bin/env python
"""Audit the production 2b/2c-focused Anchor85/HardNeg70 sampler."""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.audit_hard_negative_spatial_empty_sampler import (  # noqa: E402
    MaskOnlyAuditSampler,
    audit_loader,
    dataloader_smoke,
)
from scripts.train_voxtell_rex_full_nnunet_aug import (  # noqa: E402
    build_case_records,
    load_manifest,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preprocessed-dir", type=Path, default=ROOT / "data/rex_voxtell_preprocessed_v1")
    parser.add_argument("--num-items", type=int, default=500)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--hard-negative-prob", type=float, default=0.70)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs/sampler_audits/anchor85_hardneg70_2b2c_focus_fast500")
    return parser.parse_args()


def make_sampler(args: argparse.Namespace):
    cases = build_case_records(load_manifest(args.preprocessed_dir), "train", None)
    findings = [finding for case in cases for finding in case["findings"]]
    dummy = torch.zeros(1)
    embeddings = {
        (finding["split"], finding["case"], int(finding["finding_idx"])): dummy
        for finding in findings
    }
    sampler = MaskOnlyAuditSampler(
        args.preprocessed_dir,
        cases,
        embeddings,
        (192, 192, 192),
        2,
        1,
        1.0,
        1.0,
        0.85,
        True,
        1,
        50,
        50,
        2,
        sampler_mode="anchor85_hardneg70_2b2c_focus",
        anchor_hard_negative_prob=args.hard_negative_prob,
        shuffle_prompt_order=True,
        cross_case_negative_requires_foreground=True,
    )
    lookup = {(finding["case"], int(finding["finding_idx"])): finding for finding in findings}
    return sampler, lookup


def main() -> int:
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    sampler, lookup = make_sampler(args)
    smoke = dataloader_smoke(sampler, (192, 192, 192))

    anchor_categories: Counter[str] = Counter()
    positive_categories: Counter[str] = Counter()
    negative_sources: Counter[str] = Counter()
    positions: dict[str, Counter[int]] = defaultdict(Counter)
    prompt_counts: Counter[int] = Counter()
    rows: list[dict] = []
    missing_second = 0
    hard_requested = 0
    hard_fallback = 0
    all_empty = 0
    violations: Counter[str] = Counter()

    for item_idx, meta in enumerate(audit_loader(sampler, args.num_items, args.num_workers, args.seed)):
        anchor_category = str(meta.get("anchor_category"))
        anchor_categories[anchor_category] += 1
        missing_second += int(bool(meta.get("missing_second_positive")))
        hard_requested += int(bool(meta.get("hard_negative_requested")))
        hard_fallback += int(bool(meta.get("hard_negative_fallback")))
        negative_sources[str(meta.get("negative_source"))] += 1
        instances = list(meta.get("prompt_instances") or [])
        prompt_counts[len(instances)] += 1
        if anchor_category not in {"2b", "2c"}:
            violations["anchor_outside_2b2c"] += 1
        if not any(int(item["target_voxel_count"]) > 0 for item in instances):
            all_empty += 1

        positive_count = 0
        for item in instances:
            instance_type = str(item["prompt_instance_type"])
            position = int(item["prompt_position"])
            positions[instance_type][position] += 1
            source = lookup[(str(item["prompt_source_case_id"]), int(item["prompt_finding_id"]))]
            source_category = str(source.get("category"))
            target_voxels = int(item["target_voxel_count"])
            if instance_type == "positive_foreground":
                positive_count += 1
                positive_categories[source_category] += 1
                if target_voxels <= 0:
                    violations["empty_positive"] += 1
            elif instance_type not in {"hard_semantic_negative", "cross_case_real_finding_negative"}:
                violations["unexpected_instance_type"] += 1
            if "negative" in instance_type and target_voxels != 0:
                violations["nonempty_negative"] += 1
            rows.append(
                {
                    "item_index": item_idx,
                    "case": meta["case"],
                    "anchor_category": anchor_category,
                    "prompt_position": position,
                    "prompt_instance_type": instance_type,
                    "source_case": item["prompt_source_case_id"],
                    "source_finding": item["prompt_finding_id"],
                    "source_category": source_category,
                    "target_voxel_count": target_voxels,
                    "negative_source": meta.get("negative_source"),
                    "hard_negative_requested": int(bool(meta.get("hard_negative_requested"))),
                    "hard_negative_fallback": int(bool(meta.get("hard_negative_fallback"))),
                }
            )
        expected_positive = 1 if meta.get("missing_second_positive") else 2
        if positive_count != expected_positive:
            violations["positive_count_mismatch"] += 1

    summary = {
        "sampler_mode": sampler.sampler_mode,
        "audited_items": args.num_items,
        "dataloader_smoke": smoke,
        "anchor_category_distribution": dict(sorted(anchor_categories.items())),
        "positive_prompt_category_distribution": dict(sorted(positive_categories.items())),
        "2b_count": positive_categories["2b"],
        "2c_count": positive_categories["2c"],
        "missing_second_positive": {
            "count": missing_second,
            "fraction": missing_second / args.num_items,
        },
        "negative_source_distribution": dict(sorted(negative_sources.items())),
        "hard_negative_requested": hard_requested,
        "hard_negative_fallback": hard_fallback,
        "hard_negative_fallback_rate": hard_fallback / max(hard_requested, 1),
        "prompt_count_distribution": {str(k): v for k, v in sorted(prompt_counts.items())},
        "prompt_position_distribution": {
            key: {str(position): count for position, count in sorted(value.items())}
            for key, value in sorted(positions.items())
        },
        "all_empty_item_fraction": all_empty / args.num_items,
        "violations": dict(sorted(violations.items())),
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (args.output_dir / "prompt_instances.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    report = [
        "S3 2b/2c-focused sampler audit",
        json.dumps(summary, indent=2),
    ]
    (args.output_dir / "report.txt").write_text("\n".join(report) + "\n")
    print("\n".join(report))
    return 0 if not violations and all_empty == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
