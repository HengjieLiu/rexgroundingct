#!/usr/bin/env python3
"""Build an indexed, on-demand frozen-prefix cache for Qwen top-6 LoRA.

Each entry stores the output after Qwen layers 0--29 for one unpadded wrapped
prompt.  The index is deliberately tiny; entries are loaded only for prompts
sampled in the current training batch.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import torch
from transformers import AutoModel, AutoTokenizer, __version__ as transformers_version

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "VoxTell"))

from voxtell.model.qwen_lora_bica import cache_key  # noqa: E402
from voxtell.utils.text_embedding import wrap_with_instruction  # noqa: E402


def args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--pooled-cache",
        type=Path,
        default=ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--model", default="Qwen/Qwen3-Embedding-4B")
    parser.add_argument("--top-k", type=int, default=6)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument(
        "--storage-dtype",
        choices=("float16", "float32"),
        default="float32",
        help="Precision used on disk. float32 retains the native BF16 state exactly on reload.",
    )
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


@torch.inference_mode()
def main() -> int:
    cli = args()
    if cli.top_k != 6:
        raise ValueError("This first experiment fixes TOP_K=6")
    pooled = torch.load(cli.pooled_cache, map_location="cpu", weights_only=False)
    records = list(pooled["records"])
    if pooled.get("text_model") != cli.model:
        raise ValueError(f"Pooled cache model mismatch: {pooled.get('text_model')!r}")
    output = cli.output_dir
    entries_dir = output / "entries"
    index_path = output / "index.json"
    if index_path.exists() and not cli.overwrite:
        current = json.loads(index_path.read_text())
        if current.get("pooled_cache_sha256") == sha256(cli.pooled_cache):
            print(json.dumps({"status": "already_complete", "index": str(index_path)}, indent=2))
            return 0
        raise FileExistsError(f"Refusing to mix a different source cache into {output}")
    output.mkdir(parents=True, exist_ok=True)
    entries_dir.mkdir(parents=True, exist_ok=True)
    tokenizer = AutoTokenizer.from_pretrained(
        cli.model, padding_side="left", local_files_only=True, use_fast=True
    )
    model = AutoModel.from_pretrained(
        cli.model, local_files_only=True, torch_dtype=torch.bfloat16
    ).eval().to(cli.device)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    num_layers = int(model.config.num_hidden_layers)
    prefix_layers = num_layers - cli.top_k
    if prefix_layers != 30 or int(model.config.hidden_size) != 2560:
        raise RuntimeError(
            f"Unexpected Qwen architecture: layers={num_layers}, hidden={model.config.hidden_size}"
        )
    unique: dict[str, dict] = {}
    for record in records:
        key = cache_key(record)
        existing = unique.get(key)
        if existing is not None and str(existing["prompt"]) != str(record["prompt"]):
            raise RuntimeError("SHA256 collision in Qwen prompt cache")
        unique[key] = record
    ordered = list(unique.items())
    entries: dict[str, str] = {}
    for start in range(0, len(ordered), cli.batch_size):
        group = ordered[start : start + cli.batch_size]
        prompts = [str(record["prompt"]) for _, record in group]
        tokens = tokenizer(
            wrap_with_instruction(prompts), padding=True, truncation=True,
            max_length=cli.max_length, return_tensors="pt",
        )
        inputs = {key: value.to(cli.device) for key, value in tokens.items()}
        # Recent Transformers returns ``Qwen3Model`` directly from AutoModel;
        # older releases wrapped that module under ``.model``.  Support both
        # forms without changing the layer-level cache calculation.
        base = getattr(model, "model", model)
        hidden = base.embed_tokens(inputs["input_ids"])
        cache_position = torch.arange(hidden.shape[1], device=hidden.device)
        position_ids = cache_position.unsqueeze(0).expand(hidden.shape[0], -1)
        # Build exactly the Qwen causal mask used by its native forward.
        from transformers.masking_utils import create_causal_mask
        causal_mask = create_causal_mask(
            config=model.config, input_embeds=hidden,
            attention_mask=inputs["attention_mask"], cache_position=cache_position,
            past_key_values=None, position_ids=position_ids,
        )
        position_embeddings = base.rotary_emb(hidden, position_ids)
        for layer in base.layers[:prefix_layers]:
            hidden = layer(
                hidden, attention_mask=causal_mask, position_ids=position_ids,
                past_key_values=None, use_cache=False, cache_position=cache_position,
                position_embeddings=position_embeddings,
            )
        for row, (key, record) in enumerate(group):
            valid = inputs["attention_mask"][row].to(torch.bool)
            storage_dtype = torch.float32 if cli.storage_dtype == "float32" else torch.float16
            state = hidden[row, valid].detach().cpu().to(storage_dtype).contiguous()
            relative = f"entries/{key}.pt"
            torch.save(
                {
                    "prompt": str(record["prompt"]),
                    "wrapped_prompt": wrap_with_instruction([str(record["prompt"])])[0],
                    "hidden": state,
                    # Store the information needed to resume the causal Qwen
                    # suffix without inferring it from an unrelated batch.
                    "attention_mask": torch.ones(int(state.shape[0]), dtype=torch.long),
                    "position_ids": torch.arange(int(state.shape[0]), dtype=torch.long),
                    "sequence_length": int(state.shape[0]),
                    "last_valid_token_index": int(state.shape[0]) - 1,
                    "prefix_layers": prefix_layers,
                    "hidden_size": int(model.config.hidden_size),
                    "storage_dtype": cli.storage_dtype,
                },
                output / relative,
            )
            entries[key] = relative
        print(f"cached {min(start + len(group), len(ordered))}/{len(ordered)} unique prompts", flush=True)
    metadata = {
        "format_version": "rex_qwen_frozen_prefix.v1",
        "model": cli.model,
        "model_revision": str(getattr(model.config, "_name_or_path", cli.model)),
        "transformers_version": transformers_version,
        "hidden_size": int(model.config.hidden_size),
        "num_hidden_layers": num_layers,
        "prefix_layers": prefix_layers,
        "top_layer_indices": list(range(prefix_layers, num_layers)),
        "tokenizer_padding_side": tokenizer.padding_side,
        "instruction_wrapper": "voxtell.utils.text_embedding.wrap_with_instruction",
        "pooling_strategy": "voxtell.utils.text_embedding.last_token_pool",
        "storage_dtype": cli.storage_dtype,
        "entry_fields": [
            "prompt", "wrapped_prompt", "hidden", "attention_mask", "position_ids",
            "sequence_length", "last_valid_token_index", "prefix_layers", "hidden_size",
        ],
        "records": len(records),
        "unique_prompts": len(entries),
        "pooled_cache": str(cli.pooled_cache.resolve()),
        "pooled_cache_sha256": sha256(cli.pooled_cache),
        "entries": entries,
    }
    index_path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: value for key, value in metadata.items() if key != "entries"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
