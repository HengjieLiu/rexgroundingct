#!/usr/bin/env python3
"""Collect the single-threshold fixed-30-case full-volume S3-v2 evaluation."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def mean(values) -> float:
    return float(np.nanmean(np.asarray(list(values), dtype=np.float64)))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--expected-shards", type=int, default=4)
    parser.add_argument("--threshold", type=float, default=0.5)
    args = parser.parse_args()
    rows = []
    for shard_id in range(args.expected_shards):
        path = args.input_dir / f"shard_{shard_id:02d}" / "per_finding_threshold_metrics.csv"
        with path.open() as handle:
            rows.extend(csv.DictReader(handle))
    rows = [row for row in rows if row["variant"] == "original" and float(row["threshold"]) == args.threshold]
    if not rows:
        raise RuntimeError("No original-prompt rows found at the requested threshold")
    numeric = (
        "dice", "positive_recall", "precision", "fp_volume_mm3", "pred_voxels", "gt_voxels",
        "pred_gt_volume_ratio", "voxel_average_precision", "voxel_auroc",
    )
    for row in rows:
        for key in numeric:
            row[key] = float(row[key])
        row["global_hit"] = row["global_hit"].lower() == "true"
        row["empty_prediction"] = row["empty_prediction"].lower() == "true"
    with (args.input_dir / "per_finding_metrics.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    by_case = defaultdict(list)
    for row in rows:
        by_case[row["case"]].append(row)
    summary = {
        "threshold": args.threshold,
        "cases": len(by_case),
        "findings": len(rows),
        "mean_global_dice_per_finding": mean(row["dice"] for row in rows),
        "mean_global_dice_per_case": mean(mean(row["dice"] for row in group) for group in by_case.values()),
        "mean_precision": mean(row["precision"] for row in rows),
        "mean_recall": mean(row["positive_recall"] for row in rows),
        "hit_rate": mean(row["global_hit"] for row in rows),
        "hits": int(sum(row["global_hit"] for row in rows)),
        "misses": int(sum(not row["global_hit"] for row in rows)),
        "mean_voxel_average_precision": mean(row["voxel_average_precision"] for row in rows),
        "mean_voxel_auroc": mean(row["voxel_auroc"] for row in rows),
        "mean_predicted_voxels": mean(row["pred_voxels"] for row in rows),
        "mean_false_positive_volume_mm3": mean(row["fp_volume_mm3"] for row in rows),
        "empty_prediction_count": int(sum(row["empty_prediction"] for row in rows)),
    }
    group_rows = []
    for focality, group in sorted(((key, [r for r in rows if r["focality"] == key]) for key in {r["focality"] for r in rows})):
        group_rows.append({"group": focality, "findings": len(group), "dice": mean(r["dice"] for r in group), "precision": mean(r["precision"] for r in group), "recall": mean(r["positive_recall"] for r in group), "hit_rate": mean(r["global_hit"] for r in group), "mean_fp_volume_mm3": mean(r["fp_volume_mm3"] for r in group)})
    with (args.input_dir / "subgroup_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(group_rows[0]))
        writer.writeheader(); writer.writerows(group_rows)
    (args.input_dir / "eval_rexrank_metrics_global.json").write_text(json.dumps({"summary": summary, "subgroups": group_rows}, indent=2) + "\n")
    report = ["# Repaired S3-v2 Full-Volume Evaluation", "", f"- Threshold: {args.threshold:.1f}", f"- Cases/findings: {summary['cases']} / {summary['findings']}", f"- Dice per finding / case: {summary['mean_global_dice_per_finding']:.6f} / {summary['mean_global_dice_per_case']:.6f}", f"- Precision / recall / hit rate: {summary['mean_precision']:.6f} / {summary['mean_recall']:.6f} / {summary['hit_rate']:.6f}", f"- Voxel AP: {summary['mean_voxel_average_precision']:.6f}", f"- Mean predicted voxels / false-positive volume: {summary['mean_predicted_voxels']:.1f} / {summary['mean_false_positive_volume_mm3']:.1f} mm3", f"- Empty predictions: {summary['empty_prediction_count']}", "", "## Focality", ""]
    for item in group_rows:
        report.append(f"- {item['group']}: n={item['findings']}, Dice={item['dice']:.6f}, hit={item['hit_rate']:.6f}.")
    (args.input_dir / "report.md").write_text("\n".join(report) + "\n")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
