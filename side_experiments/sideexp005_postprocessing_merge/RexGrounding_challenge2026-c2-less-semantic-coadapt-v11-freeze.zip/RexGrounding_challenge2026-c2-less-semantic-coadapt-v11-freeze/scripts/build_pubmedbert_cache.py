#!/usr/bin/env python3
"""Cache frozen BiomedBERT/PubMedBERT representations for ReX prompts.

The cache intentionally uses ``AutoModel`` and ``last_hidden_state``.  It never
loads the MLM head or vocabulary logits.  Lexical WordPiece states exclude
CLS/SEP/PAD before being written, so downstream token attention cannot use a
global special token as a shortcut.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import torch
from tqdm import tqdm
from transformers import AutoConfig, AutoModel, AutoTokenizer


MODEL_ID = "microsoft/BiomedNLP-BiomedBERT-base-uncased-abstract-fulltext"
MODEL_REVISION = "e1354b7a3a09615f6aba48dfad4b7a613eef7062"
ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODEL_PATH = ROOT / "model_assets/pubmedbert" / MODEL_REVISION


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-path", type=Path, default=DEFAULT_MODEL_PATH)
    parser.add_argument(
        "--rex-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json"
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "model_assets/text_embedding_analysis/pubmedbert_train_val.pt",
    )
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--storage-dtype", choices=["float32", "float16", "bfloat16"], default="float16")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect_records(path: Path) -> list[dict]:
    payload = json.loads(path.read_text())
    records = []
    for split in ("train", "val"):
        for case in payload[split]:
            for finding_idx, prompt in sorted(
                case["findings"].items(), key=lambda item: int(item[0])
            ):
                records.append(
                    {
                        "split": split,
                        "case": case["name"],
                        "finding_idx": int(finding_idx),
                        "prompt": str(prompt),
                    }
                )
    return records


def storage_dtype(name: str) -> torch.dtype:
    return {
        "float32": torch.float32,
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
    }[name]


@torch.inference_mode()
def main() -> int:
    args = parse_args()
    if not args.model_path.is_dir():
        raise FileNotFoundError(f"Missing local PubMedBERT model path: {args.model_path}")
    records = collect_records(args.rex_json)
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path, local_files_only=True, use_fast=True, do_lower_case=True
    )
    config = AutoConfig.from_pretrained(args.model_path, local_files_only=True)
    model = AutoModel.from_pretrained(
        args.model_path, local_files_only=True, torch_dtype=torch.bfloat16
    ).eval().to(args.device)
    for parameter in model.parameters():
        parameter.requires_grad_(False)

    expected_hidden = int(config.hidden_size)
    token_features: list[torch.Tensor] = []
    token_ids: list[list[int]] = []
    token_strings: list[list[str]] = []
    cls_embeddings: list[torch.Tensor] = []
    mean_embeddings: list[torch.Tensor] = []
    special_masks: list[list[bool]] = []
    attention_masks: list[list[bool]] = []
    full_token_ids: list[list[int]] = []
    dtype = storage_dtype(args.storage_dtype)

    for start in tqdm(range(0, len(records), args.batch_size), desc="PubMedBERT cache"):
        batch = records[start : start + args.batch_size]
        encoded = tokenizer(
            [record["prompt"] for record in batch],
            padding=True,
            truncation=True,
            max_length=args.max_length,
            return_special_tokens_mask=True,
            return_tensors="pt",
        )
        special = encoded.pop("special_tokens_mask").bool()
        attention = encoded["attention_mask"].bool()
        outputs = model(**{key: value.to(args.device) for key, value in encoded.items()})
        hidden = outputs.last_hidden_state
        if tuple(hidden.shape[-1:]) != (expected_hidden,):
            raise RuntimeError(f"Unexpected PubMedBERT hidden shape: {tuple(hidden.shape)}")
        for row in range(len(batch)):
            lexical = attention[row] & ~special[row]
            if not bool(lexical.any()):
                raise RuntimeError(f"No lexical tokens selected for {batch[row]}")
            row_hidden = hidden[row].float()
            lexical_hidden = row_hidden[lexical].to(dtype).contiguous()
            lexical_ids = encoded["input_ids"][row, lexical].tolist()
            token_features.append(lexical_hidden.cpu())
            token_ids.append([int(value) for value in lexical_ids])
            token_strings.append([str(value) for value in tokenizer.convert_ids_to_tokens(lexical_ids)])
            cls_embeddings.append(row_hidden[0].to(dtype).cpu())
            mean_embeddings.append(row_hidden[lexical].mean(dim=0).to(dtype).cpu())
            special_masks.append(special[row].tolist())
            attention_masks.append(attention[row].tolist())
            full_token_ids.append(encoded["input_ids"][row].tolist())

    metadata = {
        "format_version": "rex_pubmedbert_representations.v1",
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "local_model_path": str(args.model_path.resolve()),
        "transformers_version": __import__("transformers").__version__,
        "tokenizer_class": tokenizer.__class__.__name__,
        "tokenizer_name_or_path": str(getattr(tokenizer, "name_or_path", args.model_path)),
        "tokenizer_lowercase": True,
        "max_length": int(args.max_length),
        "config": {
            "model_type": config.model_type,
            "hidden_size": int(config.hidden_size),
            "num_hidden_layers": int(config.num_hidden_layers),
            "num_attention_heads": int(config.num_attention_heads),
            "intermediate_size": int(config.intermediate_size),
            "max_position_embeddings": int(config.max_position_embeddings),
            "vocab_size": int(config.vocab_size),
        },
        "encoder_output": "AutoModel.last_hidden_state",
        "special_tokens_in_encoder": True,
        "token_interaction_selection": "attended non-special lexical WordPiece tokens; CLS/SEP/PAD excluded",
        "pooling_cls": "last_hidden_state[:, 0, :]",
        "pooling_mean": "masked mean over attended non-special lexical WordPiece tokens only",
        "hidden_dimension": expected_hidden,
        "storage_dtype": args.storage_dtype,
        "inference_dtype": "bfloat16",
        "records": len(records),
        "source_json": str(args.rex_json.resolve()),
        "source_json_sha256": sha256(args.rex_json),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "metadata": metadata,
            "records": records,
            "cls_embeddings": torch.stack(cls_embeddings),
            "mean_embeddings": torch.stack(mean_embeddings),
            "token_features": token_features,
            "token_ids": token_ids,
            "token_strings": token_strings,
            "attention_masks": attention_masks,
            "special_token_masks": special_masks,
            "full_token_ids": full_token_ids,
        },
        args.output,
    )
    print(json.dumps({**metadata, "output": str(args.output.resolve())}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
