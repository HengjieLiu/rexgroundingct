#!/usr/bin/env python3
"""Cache exact P0 train/fixed30 components and native VoxTell crop responses."""

from __future__ import annotations

import argparse
import csv
import json
import random
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import torch

from scripts.train_aca_anatomy_p0 import (
    fixed30_records,
    instantiate_baseline,
    make_sampler,
    tensor_patient_ids,
    unwrap_primary,
)
from scripts.train_voxtell_rex_full_nnunet_aug import (
    build_case_records,
    load_embedding_map,
    load_manifest,
)
from voxtell.model.aca_anatomy import (
    ACAAnatomyEncoder,
    labels_to_lobe_masks,
    lobe_centroid_spatial_features,
    routing_targets,
)


ROOT = Path(__file__).resolve().parents[1]
P0_TRAIN = ROOT / "outputs/aca_anatomy_p0_probe_20260730T225800Z_retry5_l40s"
P0_EVAL = ROOT / "outputs/aca_anatomy_p0_probe_eval_20260730T225800Z_retry6_l40s"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def load_config(output_root: Path, device: str) -> SimpleNamespace:
    config = json.loads((P0_TRAIN / "resolved_config.json").read_text())
    for key in ("model_dir", "preprocessed_dir", "lobe_label_dir", "embedding_cache", "fixed30_csv"):
        config[key] = Path(config[key])
    config["patch_size"] = tuple(config["patch_size"])
    config["device"] = device
    config["output_root"] = output_root
    return SimpleNamespace(**config)


def components(
    feature: torch.Tensor, lobes: torch.Tensor
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    visual, present, _ = ACAAnatomyEncoder._pool_visual_tokens(feature, lobes)
    spatial, _ = lobe_centroid_spatial_features(lobes)
    return visual, present, spatial


def anatomy_response_scores(
    response: torch.Tensor, lobes: torch.Tensor
) -> dict[str, list[float]]:
    masks = lobes[0].to(response.dtype)
    flat_masks = masks.flatten(1)
    flat = response.flatten()
    mass = torch.einsum("an,n->a", flat_masks, flat)
    mean = mass / flat_masks.sum(1).clamp_min(1)
    return {
        "sum": mass.detach().float().cpu().tolist(),
        "mean": mean.detach().float().cpu().tolist(),
    }


def append_prompt_rows(
    arrays: dict[str, list[Any]],
    *,
    update: int,
    case_id: str,
    finding_ids: list[int],
    source_cases: list[str],
    visual: torch.Tensor,
    present: torch.Tensor,
    spatial: torch.Tensor,
    text: torch.Tensor,
    targets: torch.Tensor,
    overlap: torch.Tensor,
    nonempty: torch.Tensor,
) -> None:
    prompt_count = int(text.shape[1])
    for prompt_index in range(prompt_count):
        arrays["update"].append(update)
        arrays["anchor_case"].append(case_id)
        arrays["source_case"].append(str(source_cases[prompt_index]))
        arrays["finding_idx"].append(int(finding_ids[prompt_index]))
        arrays["visual"].append(visual[0].detach().float().cpu().numpy())
        arrays["present"].append(present[0].detach().cpu().numpy())
        arrays["spatial"].append(spatial[0].detach().float().cpu().numpy())
        arrays["text"].append(text[0, prompt_index].detach().float().cpu().numpy())
        arrays["target"].append(targets[0, prompt_index].detach().float().cpu().numpy())
        arrays["overlap"].append(overlap[0, prompt_index].detach().float().cpu().numpy())
        arrays["nonempty"].append(bool(nonempty[0, prompt_index]))


def save_cache(path: Path, arrays: dict[str, list[Any]]) -> None:
    payload = {
        key: np.asarray(values, dtype=object if key in {"anchor_case", "source_case"} else None)
        for key, values in arrays.items()
    }
    np.savez_compressed(path, **payload)


def json_normalize(value: Any) -> Any:
    """Normalize tuples/NumPy scalars exactly as the JSON manifest writer did."""
    return json.loads(json.dumps(value))


def main() -> int:
    cli = parse_args()
    cli.output_root.mkdir(parents=True, exist_ok=True)
    args = load_config(cli.output_root, cli.device)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("Feature extraction requires CUDA")
    torch.cuda.set_device(0 if device.index is None else device.index)
    started = time.time()

    manifest_rows = load_manifest(args.preprocessed_dir)
    train_cases_all = build_case_records(manifest_rows, "train", None)
    validation_cases = build_case_records(manifest_rows, "val", None)
    cases_by_name = {
        str(case["case"]): case for case in train_cases_all + validation_cases
    }
    fixed_names = {
        row["case_id"]
        for row in csv.DictReader(args.fixed30_csv.open(newline="", encoding="utf-8"))
    }
    train_cases = [
        case for case in train_cases_all if str(case["case"]) not in fixed_names
    ]
    embedding_map = load_embedding_map(args.embedding_cache)
    model = instantiate_baseline(args, device).eval()
    encoder = model.encoder
    selected_layer = int(model.selected_decoder_layer)
    checkpoint = torch.load(
        P0_TRAIN / "checkpoints/checkpoint_update_100.pth",
        map_location="cpu",
        weights_only=False,
    )
    anatomy = ACAAnatomyEncoder(
        visual_dim=320,
        text_dim=2560,
        hidden_dim=args.hidden_dim,
        projection_dim=args.projection_dim,
        transformer_layers=2,
        attention_heads=4,
        dropout=0.1,
    ).to(device)
    anatomy.load_state_dict(checkpoint["aca_weights"], strict=True)
    anatomy.eval()
    amp_enabled = args.amp_dtype == "bfloat16"

    train_arrays: dict[str, list[Any]] = {
        key: []
        for key in (
            "update", "anchor_case", "source_case", "finding_idx", "visual",
            "present", "spatial", "text", "target", "nonempty",
            "overlap",
        )
    }
    original_samples = [
        json.loads(line)
        for line in (P0_TRAIN / "train_sample_manifest.jsonl").read_text().splitlines()
    ]
    sampler = make_sampler(
        train_cases,
        embedding_map,
        args,
        positive_prompts=2,
        negative_prompts=1,
        sampler_mode="anchor85_hardneg70",
        seed=args.sampler_seed,
        shuffle=True,
    )
    for update in range(1, 101):
        image, embeddings, target, _, meta = sampler.sample()
        expected = original_samples[update - 1]
        actual_replay_key = {
            "case_id": str(meta["case"]),
            "finding_ids": json_normalize(meta["prompt_indices_after_shuffle"]),
            "source_cases": json_normalize(meta["source_cases_after_shuffle"]),
            "crop_bbox": json_normalize(meta["crop_bbox"]),
        }
        expected_replay_key = {
            "case_id": str(expected["case_id"]),
            "finding_ids": expected["finding_ids"],
            "source_cases": expected["source_cases"],
            "crop_bbox": expected["crop_bbox"],
        }
        if actual_replay_key != expected_replay_key:
            raise AssertionError(
                f"Training replay mismatch at update {update}: "
                f"actual={actual_replay_key!r}, expected={expected_replay_key!r}"
            )
        ct = image[:1][None].to(device)
        lobes = labels_to_lobe_masks(image[1:2][None].to(device))
        text = embeddings[None].to(device)
        gt = target[None].to(device)
        with torch.no_grad(), torch.autocast(
            device.type, enabled=amp_enabled, dtype=torch.bfloat16
        ):
            feature = encoder(ct)[selected_layer]
            visual, present, spatial = components(feature, lobes)
            targets, nonempty, overlap = routing_targets(gt, lobes)
        append_prompt_rows(
            train_arrays,
            update=update,
            case_id=str(meta["case"]),
            finding_ids=list(meta["prompt_indices_after_shuffle"]),
            source_cases=list(meta["source_cases_after_shuffle"]),
            visual=visual,
            present=present,
            spatial=spatial,
            text=text,
            targets=targets,
            overlap=overlap,
            nonempty=nonempty,
        )
        if update % 10 == 0:
            print(f"train cache {update}/100", flush=True)
    save_cache(cli.output_root / "p0_train_components.npz", train_arrays)

    fixed_arrays: dict[str, list[Any]] = {
        key: []
        for key in (
            "update", "anchor_case", "source_case", "finding_idx", "visual",
            "present", "spatial", "text", "target", "nonempty",
            "overlap",
        )
    }
    fixed_metadata: list[dict[str, Any]] = []
    saved_p0 = json.loads((P0_EVAL / "fixed30_representation_details.json").read_text())
    maximum_route_probability_error = 0.0
    for index, (case, fixed_row) in enumerate(fixed30_records(args, cases_by_name)):
        fixed_sampler = make_sampler(
            [case],
            embedding_map,
            args,
            positive_prompts=1,
            negative_prompts=0,
            sampler_mode="current",
            seed=args.sampler_seed + 1_000_000 + index,
            shuffle=False,
        )
        requested = int(fixed_row["finding_idx"])
        for _attempt in range(100):
            image, embeddings, target, _, meta = fixed_sampler.sample()
            if (
                list(meta["prompt_indices_after_shuffle"]) == [requested]
                and list(meta["source_cases_after_shuffle"])
                == [str(fixed_row["case_id"])]
            ):
                break
        else:
            raise RuntimeError(f"Could not replay fixed30 {fixed_row}")
        ct = image[:1][None].to(device)
        lobes = labels_to_lobe_masks(image[1:2][None].to(device))
        text = embeddings[None].to(device)
        gt = target[None].to(device)
        with torch.no_grad(), torch.autocast(
            device.type, enabled=amp_enabled, dtype=torch.bfloat16
        ):
            native_logits = unwrap_primary(model(ct, text)).float()[0, 0]
            feature = encoder(ct)[selected_layer]
            visual, present, spatial = components(feature, lobes)
            targets, nonempty, overlap = routing_targets(gt, lobes)
            p0_output = anatomy(feature, lobes, text)
        route_probability = torch.softmax(p0_output["route_logits"][0, 0].float(), -1)
        saved_probability = torch.tensor(saved_p0[index]["probability"], device=device)
        maximum_route_probability_error = max(
            maximum_route_probability_error,
            float((route_probability - saved_probability).abs().max().item()),
        )
        probability_scores = anatomy_response_scores(torch.sigmoid(native_logits), lobes)
        logit_scores = anatomy_response_scores(native_logits, lobes)
        binary_scores = anatomy_response_scores((native_logits > 0).float(), lobes)
        append_prompt_rows(
            fixed_arrays,
            update=index + 1,
            case_id=str(meta["case"]),
            finding_ids=[requested],
            source_cases=[str(fixed_row["case_id"])],
            visual=visual,
            present=present,
            spatial=spatial,
            text=text,
            targets=targets,
            overlap=overlap,
            nonempty=nonempty,
        )
        fixed_metadata.append(
            {
                "case_id": str(fixed_row["case_id"]),
                "finding_idx": requested,
                "category": str(fixed_row["category"]),
                "prompt": str(fixed_row["prompt"]),
                "crop_bbox": json.dumps(meta["crop_bbox"]),
                "native_probability_sum": json.dumps(probability_scores["sum"]),
                "native_probability_mean": json.dumps(probability_scores["mean"]),
                "native_logit_sum": json.dumps(logit_scores["sum"]),
                "native_logit_mean": json.dumps(logit_scores["mean"]),
                "native_binary_sum": json.dumps(binary_scores["sum"]),
                "p0_route_probability": json.dumps(route_probability.cpu().tolist()),
            }
        )
        print(f"fixed cache {index + 1}/49", flush=True)
    if maximum_route_probability_error > 1e-6:
        raise AssertionError(
            f"P0 checkpoint replay mismatch: max probability error {maximum_route_probability_error}"
        )
    save_cache(cli.output_root / "p0_fixed30_components.npz", fixed_arrays)
    with (cli.output_root / "native_voxtell_crop_scores.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fixed_metadata[0]))
        writer.writeheader()
        writer.writerows(fixed_metadata)
    summary = {
        "schema": "aca_p0_incremental_component_cache_v1",
        "train_rows": len(train_arrays["update"]),
        "train_updates": 100,
        "fixed30_rows": len(fixed_arrays["update"]),
        "exact_training_replay": True,
        "maximum_p0_route_probability_replay_error": maximum_route_probability_error,
        "feature_source": "frozen VoxTell encoder skips[4], 320x12x12x12",
        "native_model_received_lobe_masks": False,
        "runtime_seconds": time.time() - started,
        "gpu": torch.cuda.get_device_name(0),
    }
    (cli.output_root / "feature_cache_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
