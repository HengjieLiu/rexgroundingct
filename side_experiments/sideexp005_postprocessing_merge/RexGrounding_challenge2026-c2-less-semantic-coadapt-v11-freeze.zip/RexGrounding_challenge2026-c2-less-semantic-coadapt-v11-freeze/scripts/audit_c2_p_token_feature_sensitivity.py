#!/usr/bin/env python3
"""Patch-level feature sensitivity for C2/P fixed30 Correct vs token-order shuffle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]
from acvl_utils.cropping_and_padding.padding import pad_nd_image
from voxtell.inference.predictor import VoxTellPredictor
from run_voxtell_rex_inference import load_entries, load_image, sorted_finding_keys


def measure(a: torch.Tensor, b: torch.Tensor) -> dict[str, float | int]:
    a = a.detach().float().flatten(); b = b.detach().float().flatten()
    return {"rel_l2": float((a-b).norm() / a.norm().clamp_min(1e-12)), "cosine": float(torch.nn.functional.cosine_similarity(a, b, dim=0, eps=1e-12)), "rms": float(torch.sqrt(((a-b).square()).mean())), "num_values": int(a.numel())}


def pack(mapping, keys):
    values = [mapping[k] for k in keys]; length = max(int(v.shape[0]) for v in values); hidden = int(values[0].shape[1])
    tokens = torch.zeros(1, len(values), length, hidden, dtype=torch.float16); valid = torch.zeros(1, len(values), length, dtype=torch.bool)
    for i, value in enumerate(values):
        tokens[0, i, :len(value)] = value.to(torch.float16); valid[0, i, :len(value)] = True
    return tokens, valid


def first_patch(predictor, image):
    image = np.asarray(image, dtype=np.float32); image = image[None] if image.ndim == 3 else image
    data, _, _ = predictor.preprocess(image)
    data, _ = pad_nd_image(data, tuple(predictor.patch_size), "constant", {"value": 0}, True, None)
    slicer = predictor._internal_get_sliding_window_slicers(data.shape[1:], patch_size=tuple(predictor.patch_size))[0]
    # Predictor preprocessing can retain BF16 from its inference configuration;
    # keep the eager model input FP32 and let CUDA autocast perform the matched
    # BF16 conversion inside the forward, as canonical inference does.
    return data[slicer][None].contiguous().float().to(predictor.device)


def forward(model, patch, embedding, tokens, valid):
    captured = {}
    # The semantic-training convenience tensor is populated only when the
    # pathology head exists.  Capture the identical native decoder stage (3)
    # directly so C2 and P are compared at the same representation.
    handles = [
        model.decoder.stages[3].register_forward_hook(lambda _m, _i, output: captured.setdefault("decoder_stage3", output.detach())),
        model.decoder.stages[-1].register_forward_hook(lambda _m, _i, output: captured.setdefault("final_decoder", output.detach())),
    ]
    try:
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            output = model(patch, embedding, token_features=tokens, token_valid_mask=valid)
        captured["logits"] = (output[0] if isinstance(output, (tuple, list)) else output).detach()
        return captured
    finally:
        for handle in handles: handle.remove()


def load_cache(path):
    data = torch.load(path, map_location="cpu", weights_only=False)
    return {(str(r["split"]), str(r["case"]), int(r["finding_idx"])): value for r, value in zip(data["records"], data["token_features"])}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True); parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--correct-cache", type=Path, required=True); parser.add_argument("--shuffle-cache", type=Path, required=True)
    parser.add_argument("--selected", type=Path, default=ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv")
    parser.add_argument("--prompt-cache", type=Path, default=ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/qwen_original_subset30.pt")
    parser.add_argument("--dataset", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json"); parser.add_argument("--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed")
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    predictor = VoxTellPredictor(model_dir=str(ROOT / "VoxTell/voxtell_v1.1"), checkpoint_path=str(args.checkpoint.resolve()), device=torch.device("cuda:0"), load_text_backbone=False, amp_dtype="bfloat16")
    model = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    # Match the existing, validated C2@9000 sensitivity audit: use the eager
    # CUDA model explicitly before entering BF16 autocast.
    model = model.to(predictor.device).eval()
    if getattr(predictor, "less_encoder_mode", "none") == "none": raise RuntimeError("LESS checkpoint required")
    prompts = torch.load(args.prompt_cache, map_location="cpu", weights_only=False)
    embeddings = {(str(r["split"]), str(r["case"]), int(r["finding_idx"])): prompts["embeddings"][i].float() for i, r in enumerate(prompts["records"])}
    correct, shuffled = load_cache(args.correct_cache), load_cache(args.shuffle_cache)
    cases = pd.read_csv(args.selected)["case"].astype(str).drop_duplicates().tolist(); entries = {e["name"]: e for e in load_entries(args.dataset, ["val"])}
    rows = []
    for number, case in enumerate(cases, 1):
        entry = entries[case]; entry["_split"] = "val"; keys = [("val", case, int(i)) for i in sorted_finding_keys(entry)]
        embed = torch.stack([embeddings[k] for k in keys])[None].to(predictor.device); tc, mc = pack(correct, keys); ts, ms = pack(shuffled, keys)
        patch = first_patch(predictor, load_image(args.image_dir / case)[0]); fc = forward(model, patch, embed, tc.to(predictor.device), mc.to(predictor.device)); fs = forward(model, patch, embed, ts.to(predictor.device), ms.to(predictor.device))
        for layer in ("decoder_stage3", "final_decoder", "logits"): rows.append({"case": case, "layer": layer, **measure(fc[layer], fs[layer])})
        del patch, embed, tc, mc, ts, ms, fc, fs; torch.cuda.empty_cache(); print(f"[{number}/30] {case}", flush=True)
    detail = pd.DataFrame(rows); detail.to_csv(args.output / "per_case.csv", index=False)
    summary = detail.groupby("layer", sort=False)[["rel_l2", "cosine", "rms"]].agg(["mean", "median"]).reset_index(); summary.columns = ["_".join(filter(None, map(str, x))).rstrip("_") for x in summary.columns]; summary.to_csv(args.output / "summary.csv", index=False)
    (args.output / "metadata.json").write_text(json.dumps({"checkpoint": str(args.checkpoint.resolve()), "conditions": "Correct vs deterministic within-finding LESS token-order shuffle; canonical whole-sentence embedding unchanged"}, indent=2) + "\n")


if __name__ == "__main__": main()
