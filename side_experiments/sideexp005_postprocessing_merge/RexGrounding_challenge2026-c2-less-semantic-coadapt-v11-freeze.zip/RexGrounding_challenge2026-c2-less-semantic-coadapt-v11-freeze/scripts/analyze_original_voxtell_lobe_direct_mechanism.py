#!/usr/bin/env python3
"""Paired intended-behavior readout for Lobe-Direct versus matched B0."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path("outputs/original_voxtell_semantic_screen_1k").resolve()


def load(arm: str) -> pd.DataFrame:
    path = ROOT / arm / "mechanism/anatomy_diagnostic/per_finding_metrics.csv"
    frame = pd.read_csv(path)
    volumes = pd.read_csv(
        ROOT / arm / "full200_1000/summary_tables/per_finding_metrics.csv",
        usecols=["file", "finding_idx", "voxel_volume_mm3"],
    ).rename(columns={"file": "case"})
    frame = frame.merge(volumes, on=["case", "finding_idx"], validate="one_to_one")
    exact = frame[
        frame.has_mentioned_lobes.astype(bool)
        & ~frame.mentioned_lobes.fillna("").astype(str).str.contains(";")
        & frame.missing_lobe_masks.fillna("").eq("")
    ].copy()
    exact["target_lobe_predicted_foreground_mm3"] = [
        json.loads(values).get(lobe, 0) * voxel
        for values, lobe, voxel in zip(
            exact.pred_lobe_overlap_voxels_json, exact.mentioned_lobes, exact.voxel_volume_mm3
        )
    ]
    return exact


def main() -> None:
    b0 = load("b0_original")
    arm = load("lobe_direct")
    keys = ["case", "finding_idx"]
    merged = b0.merge(arm, on=keys, suffixes=("_b0", "_arm"), validate="one_to_one")
    if not len(merged):
        raise RuntimeError("No paired exact-lobe findings")
    summary = {
        "eligible_findings": len(merged), "eligible_cases": int(merged.case.nunique()),
        "outside_target_lobe_predicted_foreground_mm3": {
            "b0": float(merged.pred_outside_mentioned_lobes_mm3_b0.mean()),
            "lobe_direct": float(merged.pred_outside_mentioned_lobes_mm3_arm.mean()),
            "delta": float((merged.pred_outside_mentioned_lobes_mm3_arm - merged.pred_outside_mentioned_lobes_mm3_b0).mean()),
        },
        "outside_target_lobe_fp_mm3": {
            "b0": float(merged.fp_outside_mentioned_lobes_mm3_b0.mean()),
            "lobe_direct": float(merged.fp_outside_mentioned_lobes_mm3_arm.mean()),
            "delta": float((merged.fp_outside_mentioned_lobes_mm3_arm - merged.fp_outside_mentioned_lobes_mm3_b0).mean()),
        },
        "inside_target_lobe_foreground_mm3": {
            "b0": float(merged.target_lobe_predicted_foreground_mm3_b0.mean()),
            "lobe_direct": float(merged.target_lobe_predicted_foreground_mm3_arm.mean()),
        },
        "tp_retention_vs_b0": float(merged.tp_volume_mm3_arm.sum() / max(merged.tp_volume_mm3_b0.sum(), 1e-12)),
        "mean_recall": {"b0": float(merged.recall_b0.mean()), "lobe_direct": float(merged.recall_arm.mean())},
    }
    out = ROOT / "lobe_direct/mechanism"
    out.mkdir(parents=True, exist_ok=True)
    merged.to_csv(out / "paired_exact_lobe_findings.csv", index=False)
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
