#!/usr/bin/env python3
"""Compare cached PubMedBERT states with direct frozen encoder inference."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
import torch.nn.functional as F
from transformers import AutoModel, AutoTokenizer

ROOT = Path(__file__).resolve().parents[1]
REVISION = "e1354b7a3a09615f6aba48dfad4b7a613eef7062"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--model-path", type=Path, default=ROOT / "model_assets/pubmedbert" / REVISION)
    parser.add_argument("--count", type=int, default=10)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    cache = torch.load(args.cache, map_location="cpu", weights_only=False)
    tokenizer = AutoTokenizer.from_pretrained(args.model_path, local_files_only=True, use_fast=True)
    model = AutoModel.from_pretrained(
        args.model_path, local_files_only=True, torch_dtype=torch.bfloat16
    ).eval().to(args.device)
    records = cache["records"][: args.count]
    max_abs = []
    mean_abs = []
    cosine = []
    for index, record in enumerate(records):
        encoded = tokenizer(
            [record["prompt"]],
            return_special_tokens_mask=True,
            return_tensors="pt",
        )
        lexical = encoded["attention_mask"].bool() & ~encoded["special_tokens_mask"].bool()
        with torch.inference_mode():
            hidden = model(
                input_ids=encoded["input_ids"].to(args.device),
                attention_mask=encoded["attention_mask"].to(args.device),
                token_type_ids=encoded.get("token_type_ids", torch.zeros_like(encoded["input_ids"])).to(args.device),
            ).last_hidden_state[0].float().cpu()
        direct_token = hidden[lexical[0]]
        cached_token = cache["token_features"][index].float()
        direct_cls = hidden[0]
        cached_cls = cache["cls_embeddings"][index].float()
        direct_mean = direct_token.mean(dim=0)
        cached_mean = cache["mean_embeddings"][index].float()
        direct = torch.cat([direct_token.flatten(), direct_cls, direct_mean])
        cached = torch.cat([cached_token.flatten(), cached_cls, cached_mean])
        max_abs.append(float((direct - cached).abs().max()))
        mean_abs.append(float((direct - cached).abs().mean()))
        cosine.append(float(F.cosine_similarity(direct[None], cached[None]).item()))
    result = {
        "cache": str(args.cache.resolve()),
        "model_path": str(args.model_path.resolve()),
        "count": len(records),
        "storage_dtype": cache["metadata"].get("storage_dtype"),
        "max_absolute_error": max(max_abs),
        "mean_absolute_error": sum(mean_abs) / len(mean_abs),
        "minimum_cosine_similarity": min(cosine),
        "mean_cosine_similarity": sum(cosine) / len(cosine),
        "per_prompt": [
            {"index": i, "max_absolute_error": a, "mean_absolute_error": m, "cosine_similarity": c}
            for i, (a, m, c) in enumerate(zip(max_abs, mean_abs, cosine))
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
