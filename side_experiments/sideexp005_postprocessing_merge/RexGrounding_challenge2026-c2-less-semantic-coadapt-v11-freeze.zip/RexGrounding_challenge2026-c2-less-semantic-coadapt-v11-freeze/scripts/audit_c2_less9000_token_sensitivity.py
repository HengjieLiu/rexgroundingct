#!/usr/bin/env python3
"""Feature-only Correct-vs-Shuffle audit for C2 LESS @9000.

This never writes model weights.  It uses the first deterministic canonical
sliding-window patch from every fixed30 CT, so all compared activations share
the same image, prompt embedding, patch, and frozen checkpoint.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "VoxTell"))

from acvl_utils.cropping_and_padding.padding import pad_nd_image
from voxtell.inference.predictor import VoxTellPredictor
from run_voxtell_rex_inference import load_entries, load_image, sorted_finding_keys


STAGES = (
    ("early_less_conditioned_encoder_level2", "less_encoder_blocks.level2"),
    ("deep_less_conditioned_encoder_level4", "less_encoder_blocks.level4"),
    ("prompt_decoder_kv_memory", "transformer_decoder.memory"),
    ("decoder_feature_after_original_fusion", "decoder.stages.final"),
    ("final_logits", "network_output"),
)


def metrics(correct: torch.Tensor, shuffled: torch.Tensor) -> dict[str, float]:
    a = correct.detach().float().reshape(-1)
    b = shuffled.detach().float().reshape(-1)
    denom = a.norm().clamp_min(1e-12)
    return {
        "rel_l2": float((a - b).norm().div(denom).item()),
        "cosine": float(torch.nn.functional.cosine_similarity(a, b, dim=0, eps=1e-12).item()),
        "rms": float(torch.sqrt(torch.mean((a - b).square())).item()),
        "num_values": int(a.numel()),
    }


def make_token_mapping(payload: dict, condition: str) -> dict[tuple[str, str, int], torch.Tensor]:
    records = payload["records"]
    values = payload["token_features"]
    keys = [(str(r["split"]), str(r["case"]), int(r["finding_idx"])) for r in records]
    source = {key: value for key, value in zip(keys, values)}
    if condition == "correct":
        return source
    ordered = sorted(keys)
    records_by_key = {key: record for key, record in zip(keys, records)}
    result: dict[tuple[str, str, int], torch.Tensor] = {}
    for key in ordered:
        own_index = ordered.index(key)
        for offset in range(1, len(ordered) + 1):
            candidate = ordered[(own_index + offset) % len(ordered)]
            if candidate != key and candidate[1] != key[1]:
                result[key] = source[candidate]
                break
        else:
            raise RuntimeError(f"No deterministic cross-case shuffled token source for {key}")
    return result


def pack_tokens(mapping: dict, keys: list[tuple[str, str, int]]) -> tuple[torch.Tensor, torch.Tensor]:
    values = [mapping[key] for key in keys]
    length = max(int(value.shape[0]) for value in values)
    hidden = int(values[0].shape[1])
    tokens = torch.zeros(1, len(values), length, hidden, dtype=torch.float16)
    valid = torch.zeros(1, len(values), length, dtype=torch.bool)
    for index, value in enumerate(values):
        n = int(value.shape[0])
        tokens[0, index, :n] = value.to(torch.float16)
        valid[0, index, :n] = True
    return tokens, valid


def one_patch(predictor: VoxTellPredictor, image: np.ndarray) -> torch.Tensor:
    raw = np.asarray(image, dtype=np.float32)
    if raw.ndim == 3:
        raw = raw[None]
    data, _, _ = predictor.preprocess(raw)
    data, _ = pad_nd_image(data, tuple(predictor.patch_size), "constant", {"value": 0}, True, None)
    slicer = predictor._internal_get_sliding_window_slicers(data.shape[1:], patch_size=tuple(predictor.patch_size))[0]
    return data[slicer][None].contiguous().to(predictor.device)


def run_forward(model, patch, embeddings, tokens, valid, autocast_dtype) -> tuple[dict[str, torch.Tensor], torch.Tensor]:
    captured: dict[str, torch.Tensor] = {}
    handles = []

    def out_hook(name):
        def capture(_module, _inputs, output):
            captured[name] = output.detach()
        return capture

    def memory_hook(_module, _inputs, kwargs):
        memory = kwargs.get("memory")
        if memory is None:
            raise RuntimeError("Transformer decoder hook did not receive memory")
        captured["prompt_decoder_kv_memory"] = memory.detach()

    handles.append(model.less_encoder_blocks["level2"].register_forward_hook(out_hook("early_less_conditioned_encoder_level2")))
    handles.append(model.less_encoder_blocks["level4"].register_forward_hook(out_hook("deep_less_conditioned_encoder_level4")))
    handles.append(model.transformer_decoder.register_forward_pre_hook(memory_hook, with_kwargs=True))
    handles.append(model.decoder.stages[-1].register_forward_hook(out_hook("decoder_feature_after_original_fusion")))
    try:
        with torch.inference_mode(), torch.autocast("cuda", dtype=autocast_dtype):
            outputs = model(patch, embeddings, token_features=tokens, token_valid_mask=valid)
        logits = outputs[0] if isinstance(outputs, (tuple, list)) else outputs
        captured["final_logits"] = logits.detach()
        missing = [name for name, _ in STAGES if name not in captured]
        if missing:
            raise RuntimeError(f"Missing diagnostic activations: {missing}")
        return captured, logits.detach()
    finally:
        for handle in handles:
            handle.remove()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--selected-findings", type=Path, default=ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv")
    parser.add_argument("--prompt-cache", type=Path, default=ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/qwen_original_subset30.pt")
    parser.add_argument("--token-cache", type=Path, default=ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt")
    parser.add_argument("--dataset-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(20260822)
    predictor = VoxTellPredictor(
        model_dir=str(ROOT / "VoxTell/voxtell_v1.1"),
        checkpoint_path=str(args.checkpoint.resolve()),
        device=torch.device("cuda:0"),
        load_text_backbone=False,
        amp_dtype="bfloat16",
    )
    model = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    model = model.to(predictor.device).eval()
    if getattr(predictor, "less_encoder_mode", "none") == "none":
        raise RuntimeError("This audit requires an active LESS checkpoint")
    prompt_payload = torch.load(args.prompt_cache, map_location="cpu", weights_only=False)
    prompt_map = {
        (str(record["split"]), str(record["case"]), int(record["finding_idx"])): prompt_payload["embeddings"][index].float()
        for index, record in enumerate(prompt_payload["records"])
    }
    token_payload = torch.load(args.token_cache, map_location="cpu", weights_only=False)
    correct_tokens = make_token_mapping(token_payload, "correct")
    shuffled_tokens = make_token_mapping(token_payload, "shuffled")
    selected_cases = pd.read_csv(args.selected_findings)["case"].astype(str).drop_duplicates().tolist()
    entries = {entry["name"]: entry for entry in load_entries(args.dataset_json, ["val"])}
    if len(selected_cases) != 30 or any(case not in entries for case in selected_cases):
        raise RuntimeError("Fixed30 selection does not match validation entries")
    rows: list[dict[str, object]] = []
    identity: dict[str, float] | None = None
    for number, case in enumerate(selected_cases, start=1):
        entry = entries[case]
        entry["_split"] = "val"
        keys = [("val", case, int(index)) for index in sorted_finding_keys(entry)]
        embeddings = torch.stack([prompt_map[key] for key in keys]).unsqueeze(0).to(predictor.device)
        correct, correct_mask = pack_tokens(correct_tokens, keys)
        shuffled, shuffled_mask = pack_tokens(shuffled_tokens, keys)
        image, _ = load_image(args.image_dir / case)
        patch = one_patch(predictor, image)
        captured_correct, logits_correct = run_forward(model, patch, embeddings, correct.to(predictor.device), correct_mask.to(predictor.device), torch.bfloat16)
        if identity is None:
            # Hook identity check: a normal forward must match hook-enabled output.
            with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
                baseline_outputs = model(patch, embeddings, token_features=correct.to(predictor.device), token_valid_mask=correct_mask.to(predictor.device))
            baseline = baseline_outputs[0] if isinstance(baseline_outputs, (tuple, list)) else baseline_outputs
            identity = {
                "max_abs_output_logit_difference": float((baseline.float() - logits_correct.float()).abs().max().item()),
                "mean_abs_output_logit_difference": float((baseline.float() - logits_correct.float()).abs().mean().item()),
            }
        captured_shuffle, _ = run_forward(model, patch, embeddings, shuffled.to(predictor.device), shuffled_mask.to(predictor.device), torch.bfloat16)
        for stage, source in STAGES:
            row = {"case": case, "stage": stage, "source": source, **metrics(captured_correct[stage], captured_shuffle[stage])}
            rows.append(row)
        del patch, embeddings, correct, correct_mask, shuffled, shuffled_mask, captured_correct, captured_shuffle
        torch.cuda.empty_cache()
        print(f"[{number}/30] {case}", flush=True)
    detail = pd.DataFrame(rows)
    detail.to_csv(args.output_dir / "attenuation_chain_per_case.csv", index=False)
    summary = detail.groupby(["stage", "source"], sort=False)[["rel_l2", "cosine", "rms"]].agg(["mean", "median"]).reset_index()
    summary.columns = ["_".join(filter(None, map(str, column))).rstrip("_") for column in summary.columns]
    summary.to_csv(args.output_dir / "attenuation_chain.csv", index=False)
    metadata = {
        "checkpoint": str(args.checkpoint.resolve()),
        "cohort": "fixed30: first deterministic canonical sliding-window patch per each of 30 cases / 49 findings",
        "conditions": "Correct vs deterministic cross-case TokenShuffle; global sentence embedding unchanged",
        "hook_identity": identity,
        "stages": [{"stage": stage, "source": source} for stage, source in STAGES],
    }
    (args.output_dir / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
