#!/usr/bin/env python3
"""Post-hoc diagnosis of common-init A2-FAN update250 -> update500 decline."""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
EXP = ROOT / "outputs/token_attention_common_init_pilot"
OUT = EXP / "a2_fan_250_500_diagnosis"


PATHOLOGY_KEYWORDS = {
    "nodule_mass": ("nodule", "nodular", "mass"),
    "ground_glass": ("ground-glass", "ground glass", "ggo"),
    "consolidation_opacity": ("consolidation", "consolidative", "opacity"),
    "atelectasis": ("atelectasis", "atelectatic"),
    "effusion": ("effusion",),
    "bronchiectasis": ("bronchiectasis", "bronchiectatic"),
    "emphysema": ("emphysema", "emphysematous"),
    "fibrosis_scarring": ("fibrosis", "fibrotic", "scar", "scarring", "bandlike"),
    "calcification": ("calcification", "calcified"),
    "crazy_paving": ("crazy paving",),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-root", type=Path, default=EXP)
    parser.add_argument("--output-dir", type=Path, default=OUT)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260723)
    parser.add_argument("--skip-parameter-drift", action="store_true")
    return parser.parse_args()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def arm_dir(exp: Path, arm: str) -> Path:
    return exp / arm


def summary_path(exp: Path, arm: str, update: int) -> Path:
    return arm_dir(exp, arm) / f"full_volume/update_{update:05d}/controlled_summary.json"


def per_finding_path(exp: Path, arm: str, update: int) -> Path:
    return arm_dir(exp, arm) / f"full_volume/update_{update:05d}/summary_tables/per_finding_metrics.csv"


def checkpoint_path(exp: Path, arm: str, update: int) -> Path:
    return arm_dir(exp, arm) / f"checkpoints/checkpoint_update_{update}.pth"


def history_path(exp: Path, arm: str) -> Path:
    return arm_dir(exp, arm) / "history.jsonl"


def read_history(path: Path) -> list[dict[str, Any]]:
    rows = []
    for line in path.read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def pick_history(records: list[dict[str, Any]], update: int) -> dict[str, Any] | None:
    candidates = [row for row in records if int(row.get("optimizer_update", -1)) == update]
    if not candidates:
        return None
    stepped = [row for row in candidates if row.get("optimizer_step_performed")]
    if stepped:
        return max(stepped, key=lambda row: int(row.get("micro_step", -1)))
    return max(candidates, key=lambda row: int(row.get("micro_step", -1)))


def validation_rows(exp: Path) -> pd.DataFrame:
    rows = []
    for arm in ("A2_FAN", "B0_original"):
        for update in (100, 250, 500):
            summary = load_json(summary_path(exp, arm, update))
            rows.append(
                {
                    "arm": arm,
                    "update": update,
                    "dice": float(summary["mean_dice_per_finding"]),
                    "hit": int(summary["hit_count"]),
                    "findings": int(summary["findings"]),
                    "hit_rate": float(summary["hit_rate"]),
                    "mean_predicted_volume_mm3": float(summary["mean_predicted_volume_mm3"]),
                    "empty_prediction_count": int(summary["empty_prediction_count"]),
                }
            )
    return pd.DataFrame(rows)


def training_rows(exp: Path) -> pd.DataFrame:
    wanted = [100, 150, 200, 250, 300, 350, 400, 450, 500]
    val = validation_rows(exp)
    rows = []
    for arm in ("A2_FAN", "B0_original"):
        records = read_history(history_path(exp, arm))
        for update in wanted:
            row = pick_history(records, update)
            if row is None:
                rows.append({"arm": arm, "update": update, "status": "missing"})
                continue
            val_row = val[(val["arm"] == arm) & (val["update"] == update)]
            rows.append(
                {
                    "arm": arm,
                    "update": update,
                    "status": "done",
                    "total_loss": row.get("total_loss"),
                    "segmentation_loss": row.get("segmentation_loss"),
                    "scale0_loss": row.get("scale0_loss"),
                    "scale0_dice_loss": row.get("scale0_dice_loss"),
                    "scale0_tversky_loss": row.get("scale0_tversky_loss"),
                    "scale0_focal_tversky_loss": row.get("scale0_focal_tversky_loss"),
                    "grad_norm": row.get("grad_norm"),
                    "grad_norm_fan_image_text": row.get("grad_norm_fan_image_text"),
                    "lr": row.get("lr"),
                    "amp_step_skipped": row.get("amp_step_skipped"),
                    "fixed30_dice": None if val_row.empty else float(val_row.iloc[0]["dice"]),
                    "fixed30_hit": None if val_row.empty else int(val_row.iloc[0]["hit"]),
                    "fixed30_mean_volume": None
                    if val_row.empty
                    else float(val_row.iloc[0]["mean_predicted_volume_mm3"]),
                }
            )
    return pd.DataFrame(rows)


def read_pf(exp: Path, arm: str, update: int) -> pd.DataFrame:
    frame = pd.read_csv(per_finding_path(exp, arm, update))
    frame = frame.rename(columns={"file": "case_id", "global_dice": "dice", "global_hit": "hit"})
    frame["hit"] = frame["hit"].astype(bool)
    frame["update"] = update
    frame["arm"] = arm
    return frame


def prompt_flags(prompt: str) -> dict[str, str]:
    text = str(prompt).lower()
    laterality = "laterality_explicit" if any(word in text for word in ("left", "right", "bilateral", "both lungs")) else "no_laterality"
    lobe_terms = ("lobe", "lobar", "lingula", "apical", "basal", "segment", "middle lobe")
    lobe = "lobe_explicit" if any(term in text for term in lobe_terms) else "no_lobe"
    diffuse_terms = (
        "bilateral",
        "both lungs",
        "diffuse",
        "multifocal",
        "multiple",
        "several",
        "scattered",
        "crazy paving",
        "lobes",
        "tree-in-bud",
        "reticular",
        "interstitial",
    )
    diffuse = "diffuse_or_multifocal" if any(term in text for term in diffuse_terms) else "single_or_focal"
    pathologies = [
        name
        for name, terms in PATHOLOGY_KEYWORDS.items()
        if any(term in text for term in terms)
    ]
    pathology = "+".join(pathologies) if pathologies else "other"
    return {
        "laterality_group": laterality,
        "lobe_group": lobe,
        "diffuse_group": diffuse,
        "pathology_group": pathology,
    }


def paired_delta(exp: Path, out: Path, seed: int, bootstrap: int) -> tuple[pd.DataFrame, dict[str, Any], pd.DataFrame, pd.DataFrame]:
    u250 = read_pf(exp, "A2_FAN", 250)
    u500 = read_pf(exp, "A2_FAN", 500)
    keys = ["case_id", "finding_idx"]
    merged = u250.merge(u500, on=keys, suffixes=("_250", "_500"), validate="one_to_one")
    merged["dice_delta_500_minus_250"] = merged["dice_500"] - merged["dice_250"]
    merged["pred_volume_250"] = merged["pred_voxels_250"] * merged["voxel_volume_mm3_250"]
    merged["pred_volume_500"] = merged["pred_voxels_500"] * merged["voxel_volume_mm3_500"]
    merged["volume_delta"] = merged["pred_volume_500"] - merged["pred_volume_250"]
    merged["volume_ratio_500_over_250"] = merged["pred_volume_500"] / merged["pred_volume_250"].replace(0, np.nan)
    merged["hit_transition"] = np.select(
        [
            merged["hit_250"] & merged["hit_500"],
            merged["hit_250"] & ~merged["hit_500"],
            ~merged["hit_250"] & merged["hit_500"],
            ~merged["hit_250"] & ~merged["hit_500"],
        ],
        ["hit_both", "hit_lost", "hit_gained", "miss_both"],
        default="unknown",
    )
    flag_frame = pd.DataFrame([prompt_flags(prompt) for prompt in merged["prompt_250"]])
    merged = pd.concat([merged.reset_index(drop=True), flag_frame], axis=1)

    delta = merged["dice_delta_500_minus_250"].to_numpy()
    rng = np.random.default_rng(seed)
    cases = np.asarray(sorted(merged["case_id"].unique()))
    by_case = {case: merged.index[merged["case_id"] == case].to_numpy() for case in cases}
    samples = []
    for _ in range(bootstrap):
        selected = rng.choice(cases, size=len(cases), replace=True)
        indices = np.concatenate([by_case[case] for case in selected])
        samples.append(float(delta[indices].mean()))
    eps = 1e-12
    stats = {
        "n_findings": int(len(merged)),
        "mean_delta": float(delta.mean()),
        "median_delta": float(np.median(delta)),
        "case_bootstrap_95_ci": [float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))],
        "improved": int((delta > eps).sum()),
        "worsened": int((delta < -eps).sum()),
        "tied": int((np.abs(delta) <= eps).sum()),
        "hit_transition_counts": {str(k): int(v) for k, v in merged["hit_transition"].value_counts().items()},
        "mean_volume_250": float(merged["pred_volume_250"].mean()),
        "mean_volume_500": float(merged["pred_volume_500"].mean()),
        "median_volume_250": float(merged["pred_volume_250"].median()),
        "median_volume_500": float(merged["pred_volume_500"].median()),
        "median_volume_ratio": float(merged["volume_ratio_500_over_250"].median(skipna=True)),
        "pearson_delta_vs_log_volume_ratio": float(
            merged[["dice_delta_500_minus_250"]]
            .join(np.log2(merged["volume_ratio_500_over_250"]).rename("log2_volume_ratio"))
            .replace([np.inf, -np.inf], np.nan)
            .corr()
            .iloc[0, 1]
        ),
        "spearman_delta_vs_log_volume_ratio": float(
            merged[["dice_delta_500_minus_250"]]
            .join(np.log2(merged["volume_ratio_500_over_250"]).rename("log2_volume_ratio"))
            .replace([np.inf, -np.inf], np.nan)
            .corr(method="spearman")
            .iloc[0, 1]
        ),
    }
    subgroup_rows = []
    group_specs = [
        ("category", "category_250"),
        ("laterality", "laterality_group"),
        ("lobe", "lobe_group"),
        ("diffuse", "diffuse_group"),
        ("pathology", "pathology_group"),
    ]
    for group_type, column in group_specs:
        for group, sub in merged.groupby(column, sort=True):
            subgroup_rows.append(
                {
                    "group_type": group_type,
                    "group": str(group),
                    "n": int(len(sub)),
                    "dice250": float(sub["dice_250"].mean()),
                    "dice500": float(sub["dice_500"].mean()),
                    "delta": float(sub["dice_delta_500_minus_250"].mean()),
                    "mean_volume_ratio": float(sub["volume_ratio_500_over_250"].mean(skipna=True)),
                    "hit_lost": int((sub["hit_transition"] == "hit_lost").sum()),
                    "hit_gained": int((sub["hit_transition"] == "hit_gained").sum()),
                }
            )
    subgroups = pd.DataFrame(subgroup_rows)
    largest_degradations = merged.sort_values("dice_delta_500_minus_250").head(10)
    largest_improvements = merged.sort_values("dice_delta_500_minus_250", ascending=False).head(10)
    out.mkdir(parents=True, exist_ok=True)
    merged.to_csv(out / "per_finding/a2_fan_update250_to_500_delta.csv", index=False)
    largest_degradations.to_csv(out / "per_finding/largest_10_degradations.csv", index=False)
    largest_improvements.to_csv(out / "per_finding/largest_10_improvements.csv", index=False)
    subgroups.to_csv(out / "per_finding/subgroup_delta.csv", index=False)
    merged[
        [
            "case_id",
            "finding_idx",
            "category_250",
            "prompt_250",
            "dice_250",
            "dice_500",
            "dice_delta_500_minus_250",
            "pred_volume_250",
            "pred_volume_500",
            "volume_ratio_500_over_250",
            "hit_transition",
        ]
    ].to_csv(out / "volume/volume_delta.csv", index=False)
    pd.DataFrame([stats]).to_json(out / "analysis/per_finding_summary.json", indent=2, orient="records")
    return merged, stats, largest_degradations, largest_improvements


def feature_drift(exp: Path, out: Path) -> pd.DataFrame:
    source = exp / "diagnostics/A2_FAN/fixed_feature_trajectory/feature_trajectory.json"
    payload = load_json(source)
    rows = []
    for row in payload["rows"]:
        update = int(row["update"])
        if update not in (250, 500):
            continue
        rms_ratio = float(row["feature_rms_ratio"])
        cosine = float(row["cosine_before_after"])
        drift = math.sqrt(max(0.0, 1.0 + rms_ratio * rms_ratio - 2.0 * rms_ratio * cosine))
        rows.append(
            {
                "update": update,
                "scale": row["scale"],
                "cosine_before_after": cosine,
                "rms_after_over_before": rms_ratio,
                "relative_l2_drift_inferred": drift,
                "feature_rms_before": row.get("feature_rms_before"),
                "feature_rms_after": row.get("feature_rms_after"),
                "case": row.get("case"),
                "finding_idx": row.get("finding_idx"),
            }
        )
    frame = pd.DataFrame(rows)
    wide = frame.pivot(index="scale", columns="update", values="relative_l2_drift_inferred").reset_index()
    if 250 in wide and 500 in wide:
        wide["drift_change_500_minus_250"] = wide[500] - wide[250]
    frame.to_csv(out / "feature_drift/feature_drift_long.csv", index=False)
    wide.to_csv(out / "feature_drift/feature_drift_250_500.csv", index=False)
    return frame


def group_for_parameter(name: str) -> str:
    if name.startswith("fan_image_text_blocks."):
        if ".joint_attention." in name:
            return "fan_joint_self_attention"
        if ".cross_attention." in name:
            return "fan_image_to_word_cross_attention"
        if ".visual_projection." in name:
            return "fan_visual_projection"
        if ".text_projection." in name:
            return "fan_text_projection"
        if ".output_projection." in name:
            return "fan_output_projection"
        if ".joint_ffn" in name:
            return "fan_joint_ffn"
        if ".cross_ffn" in name:
            return "fan_cross_ffn"
        if "norm" in name:
            return "fan_layernorm"
        if "visual_position" in name:
            return "fan_visual_position"
        return "fan_other"
    if name.startswith("encoder."):
        return "encoder"
    if name.startswith("decoder."):
        return "native_decoder"
    if name.startswith("transformer_decoder."):
        return "global_sentence_transformer"
    if name.startswith("project_bottleneck_embed."):
        return "global_bottleneck_projection"
    if name.startswith("project_text_embed."):
        return "global_text_projection"
    if name.startswith("project_to_decoder_channels."):
        return "decoder_channel_projection"
    if name == "pos_embed":
        return "global_position_embedding"
    return "other"


def parameter_drift(exp: Path, out: Path) -> pd.DataFrame:
    cached = out / "analysis/parameter_drift_by_group.csv"
    if cached.is_file():
        return pd.read_csv(cached)
    ckpt250 = torch.load(checkpoint_path(exp, "A2_FAN", 250), map_location="cpu", weights_only=False)["network_weights"]
    ckpt500 = torch.load(checkpoint_path(exp, "A2_FAN", 500), map_location="cpu", weights_only=False)["network_weights"]
    accum: dict[str, dict[str, float]] = {}
    detail_rows = []
    for name, tensor250 in ckpt250.items():
        if name not in ckpt500 or not torch.is_tensor(tensor250):
            continue
        tensor500 = ckpt500[name]
        if not torch.is_floating_point(tensor250):
            continue
        group = group_for_parameter(name)
        a = tensor250.detach().float()
        b = tensor500.detach().float()
        norm250_sq = float(a.square().sum().item())
        norm500_sq = float(b.square().sum().item())
        delta_sq = float((b - a).square().sum().item())
        item = accum.setdefault(
            group,
            {"norm250_sq": 0.0, "norm500_sq": 0.0, "delta_sq": 0.0, "params": 0.0, "tensors": 0.0},
        )
        item["norm250_sq"] += norm250_sq
        item["norm500_sq"] += norm500_sq
        item["delta_sq"] += delta_sq
        item["params"] += float(tensor250.numel())
        item["tensors"] += 1.0
        detail_rows.append(
            {
                "parameter": name,
                "group": group,
                "numel": int(tensor250.numel()),
                "norm250": math.sqrt(norm250_sq),
                "norm500": math.sqrt(norm500_sq),
                "relative_delta": math.sqrt(delta_sq) / max(math.sqrt(norm250_sq), 1e-12),
            }
        )
    rows = []
    for group, item in sorted(accum.items()):
        norm250 = math.sqrt(item["norm250_sq"])
        norm500 = math.sqrt(item["norm500_sq"])
        delta = math.sqrt(item["delta_sq"])
        rows.append(
            {
                "group": group,
                "parameter_count": int(item["params"]),
                "tensor_count": int(item["tensors"]),
                "norm250": norm250,
                "norm500": norm500,
                "delta_norm": delta,
                "relative_delta": delta / max(norm250, 1e-12),
            }
        )
    frame = pd.DataFrame(rows).sort_values("relative_delta", ascending=False)
    detail = pd.DataFrame(detail_rows).sort_values("relative_delta", ascending=False)
    frame.to_csv(out / "analysis/parameter_drift_by_group.csv", index=False)
    detail.head(100).to_csv(out / "analysis/parameter_drift_top100_tensors.csv", index=False)
    return frame


def attention_delta(exp: Path, out: Path) -> pd.DataFrame:
    # Prefer diagnosis-local update250 if available; reuse existing update500.
    paths = {
        250: out / "attention/update_250/attention_summary.json",
        500: exp / "diagnostics/A2_FAN/update_500/attention_summary.json",
    }
    if not all(path.is_file() for path in paths.values()):
        return pd.DataFrame()
    rows = []
    for update, path in paths.items():
        payload = load_json(path)
        for row in payload["samples"]:
            rows.append(row)
    frame = pd.DataFrame(rows)
    group_cols = ["mechanism", "scale"]
    metrics = [
        "normalized_entropy_mean",
        "maximum_token_share_mean",
        "effective_token_count_mean",
        "top3_token_share_mean",
        "querywise_token_std_mean",
        "text_mass_mean",
    ]
    grouped = frame.groupby(["update", *group_cols])[metrics].mean().reset_index()
    wide_rows = []
    for keys, sub in grouped.groupby(group_cols):
        by_update = {int(row.update): row for row in sub.itertuples(index=False)}
        if 250 not in by_update or 500 not in by_update:
            continue
        base = {"mechanism": keys[0], "scale": keys[1]}
        for metric in metrics:
            v250 = float(getattr(by_update[250], metric))
            v500 = float(getattr(by_update[500], metric))
            wide_rows.append({"metric": metric, **base, "update250": v250, "update500": v500, "delta": v500 - v250})
    result = pd.DataFrame(wide_rows)
    result.to_csv(out / "attention/attention_250_500_delta.csv", index=False)

    ratio_paths = {
        250: out / "attention/update_250/grounding_ratios.csv",
        500: exp / "diagnostics/A2_FAN/update_500/grounding_ratios.csv",
    }
    if all(path.is_file() for path in ratio_paths.values()):
        ratio_rows = []
        for update, path in ratio_paths.items():
            df = pd.read_csv(path)
            df["update"] = update
            ratio_rows.append(df)
        ratios = pd.concat(ratio_rows, ignore_index=True)
        ratio_group = ratios.groupby(["update", "mechanism", "scale", "metric"])["ratio"].agg(["count", "mean", "median"]).reset_index()
        ratio_wide = []
        for keys, sub in ratio_group.groupby(["mechanism", "scale", "metric"]):
            by_update = {int(row.update): row for row in sub.itertuples(index=False)}
            if 250 not in by_update or 500 not in by_update:
                continue
            ratio_wide.append(
                {
                    "mechanism": keys[0],
                    "scale": keys[1],
                    "metric": keys[2],
                    "n250": int(by_update[250].count),
                    "n500": int(by_update[500].count),
                    "mean_ratio250": float(by_update[250].mean),
                    "mean_ratio500": float(by_update[500].mean),
                    "mean_delta": float(by_update[500].mean - by_update[250].mean),
                    "median_ratio250": float(by_update[250].median),
                    "median_ratio500": float(by_update[500].median),
                    "median_delta": float(by_update[500].median - by_update[250].median),
                }
            )
        pd.DataFrame(ratio_wide).to_csv(out / "attention/grounding_250_500_delta.csv", index=False)
    return result


def branch_bypass_summary(out: Path) -> dict[str, Any] | None:
    path = out / "branch_bypass/branch_bypass_summary.json"
    if not path.is_file():
        return None
    return load_json(path)


def tiny_gpu_job(out: Path) -> dict[str, Any] | None:
    path = out / "analysis/tiny_gpu_job.json"
    if not path.is_file():
        return None
    return load_json(path)


def format_float(value: Any, digits: int = 5) -> str:
    if value is None or (isinstance(value, float) and not math.isfinite(value)):
        return "NA"
    return f"{float(value):.{digits}f}"


def write_report(
    out: Path,
    *,
    validation: pd.DataFrame,
    training: pd.DataFrame,
    paired_stats: dict[str, Any],
    merged: pd.DataFrame,
    degradations: pd.DataFrame,
    improvements: pd.DataFrame,
    feature: pd.DataFrame,
    param: pd.DataFrame,
    attn: pd.DataFrame,
    bypass: dict[str, Any] | None,
    runtime_seconds: float,
) -> None:
    a2_250 = float(validation[(validation["arm"] == "A2_FAN") & (validation["update"] == 250)].iloc[0]["dice"])
    a2_500 = float(validation[(validation["arm"] == "A2_FAN") & (validation["update"] == 500)].iloc[0]["dice"])
    delta = a2_500 - a2_250
    h1_supported = False
    a2_train250 = training[(training["arm"] == "A2_FAN") & (training["update"] == 250)]
    a2_train500 = training[(training["arm"] == "A2_FAN") & (training["update"] == 500)]
    if not a2_train250.empty and not a2_train500.empty:
        h1_supported = float(a2_train500.iloc[0].total_loss) < float(a2_train250.iloc[0].total_loss)
    feature_wide = pd.read_csv(out / "feature_drift/feature_drift_250_500.csv")
    h2_supported = bool((feature_wide.get("drift_change_500_minus_250", pd.Series(dtype=float)) > 0.01).any())
    volume_factor = paired_stats["mean_volume_500"] / max(paired_stats["mean_volume_250"], 1e-12)
    h5_supported = volume_factor > 2.0
    h6_supported = abs(float(degradations.iloc[0]["dice_delta_500_minus_250"])) > abs(delta) * 10
    h7_supported = paired_stats["case_bootstrap_95_ci"][0] <= 0 <= paired_stats["case_bootstrap_95_ci"][1]
    h3_text = (
        "NOT SUPPORTED; entropy/max-token/effective-token metrics are essentially unchanged 250→500, while grounding ratios remain weak/near 1"
        if not attn.empty
        else "UNRESOLVED until update250 attention is generated; existing 0→500 summary shows minimal change and weak grounding near ratio 1"
    )
    if bypass is not None:
        late_bypass_rows = [row for row in bypass.get("summary", []) if int(row.get("update", -1)) == 500]
        h4_text = (
            "PARTIALLY SUPPORTED; at update500 the tiny patch FAN-bypass test improves mean patch Dice relative to normal FAN, but the test is not official full-volume validation"
            if late_bypass_rows and float(late_bypass_rows[0].get("bypass_minus_normal_mean_patch_dice", 0.0)) > 0
            else "UNRESOLVED; the tiny branch-bypass test did not show recovery"
        )
    else:
        h4_text = "PARTIALLY SUPPORTED; direct FAN path feeds the original global sentence transformer a heavily transformed level4 memory, while feature statistics remain far from identity"
    primary = (
        "prediction-volume drift / late over-segmentation dominates the observed A2-FAN 250→500 decline"
        if h5_supported
        else "broad small per-finding degradation without clear feature-drift growth"
    )
    confidence = "MODERATE" if h5_supported and h7_supported else ("HIGH" if h5_supported else "LOW")
    lines = [
        "A2-FAN 250→500 diagnosis",
        "",
        "Dice:",
        f"250 = {a2_250:.5f}",
        f"500 = {a2_500:.5f}",
        f"Delta = {delta:+.5f}",
        "",
        f"Primary explanation: {primary}.",
        "",
        f"Confidence: {confidence}",
        "",
        "# Focused post-hoc diagnosis",
        "",
        "## Artifact paths",
        "",
        f"- A2-FAN checkpoint_update_250: `{checkpoint_path(EXP, 'A2_FAN', 250)}`",
        f"- A2-FAN checkpoint_update_500: `{checkpoint_path(EXP, 'A2_FAN', 500)}`",
        f"- B0 checkpoint_update_250: `{checkpoint_path(EXP, 'B0_original', 250)}`",
        f"- B0 checkpoint_update_500: `{checkpoint_path(EXP, 'B0_original', 500)}`",
        f"- A2-FAN training log: `{history_path(EXP, 'A2_FAN')}`",
        f"- B0 training log: `{history_path(EXP, 'B0_original')}`",
        f"- A2-FAN fixed30 u250 per-finding: `{per_finding_path(EXP, 'A2_FAN', 250)}`",
        f"- A2-FAN fixed30 u500 per-finding: `{per_finding_path(EXP, 'A2_FAN', 500)}`",
        f"- Existing A2-FAN u500 attention diagnostics: `{EXP / 'diagnostics/A2_FAN/update_500'}`",
        f"- Diagnosis output root: `{out}`",
        "",
        "Confirmed same experiment: all paths are under `outputs/token_attention_common_init_pilot/`; formal sampler traces in the parent report are byte-identical across B0/A1/A2.",
        "",
        "## Training trajectory",
        "",
        "| Update | A2-FAN train loss | B0 train loss | A2-FAN fixed30 Dice | B0 fixed30 Dice | A2-FAN HIT | B0 HIT | A2-FAN mean volume |",
        "| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for update in (100, 150, 200, 250, 300, 350, 400, 450, 500):
        a2 = training[(training["arm"] == "A2_FAN") & (training["update"] == update)]
        b0 = training[(training["arm"] == "B0_original") & (training["update"] == update)]
        lines.append(
            f"| {update} | {format_float(None if a2.empty else a2.iloc[0].total_loss)} | {format_float(None if b0.empty else b0.iloc[0].total_loss)} | {format_float(None if a2.empty else a2.iloc[0].fixed30_dice)} | {format_float(None if b0.empty else b0.iloc[0].fixed30_dice)} | {'' if a2.empty or pd.isna(a2.iloc[0].fixed30_hit) else int(a2.iloc[0].fixed30_hit)} | {'' if b0.empty or pd.isna(b0.iloc[0].fixed30_hit) else int(b0.iloc[0].fixed30_hit)} | {format_float(None if a2.empty else a2.iloc[0].fixed30_mean_volume, 1)} |"
        )
    lines.extend(
        [
            "",
            "H1 note: A2-FAN train loss rose from update250 to 500 rather than continuing to improve, so the evidence does not cleanly support classic overfitting.",
            "",
            "## Finding-level change",
            "",
            "| Improved | Worsened | Tied | Mean delta | Median delta | 95% CI |",
            "| ---: | ---: | ---: | ---: | ---: | --- |",
            f"| {paired_stats['improved']} | {paired_stats['worsened']} | {paired_stats['tied']} | {paired_stats['mean_delta']:+.5f} | {paired_stats['median_delta']:+.5f} | [{paired_stats['case_bootstrap_95_ci'][0]:+.5f}, {paired_stats['case_bootstrap_95_ci'][1]:+.5f}] |",
            "",
            "### Largest 10 degradations",
            "",
            "| Case | Finding | Category | Prompt | Dice250 | Dice500 | Delta | Vol250 | Vol500 | Ratio |",
            "| --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for _, row in degradations.iterrows():
        lines.append(
            f"| {row.case_id} | {int(row.finding_idx)} | {row.category_250} | {row.prompt_250} | {row.dice_250:.5f} | {row.dice_500:.5f} | {row.dice_delta_500_minus_250:+.5f} | {row.pred_volume_250:.1f} | {row.pred_volume_500:.1f} | {format_float(row.volume_ratio_500_over_250, 2)} |"
        )
    lines.extend(["", "### Largest 10 improvements", "", "| Case | Finding | Category | Prompt | Dice250 | Dice500 | Delta | Vol250 | Vol500 | Ratio |", "| --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |"])
    for _, row in improvements.iterrows():
        lines.append(
            f"| {row.case_id} | {int(row.finding_idx)} | {row.category_250} | {row.prompt_250} | {row.dice_250:.5f} | {row.dice_500:.5f} | {row.dice_delta_500_minus_250:+.5f} | {row.pred_volume_250:.1f} | {row.pred_volume_500:.1f} | {format_float(row.volume_ratio_500_over_250, 2)} |"
        )
    lines.extend(["", "## Subgroup breakdown", "", "| Subgroup | N | Dice250 | Dice500 | Delta | Mean volume ratio |", "| --- | ---: | ---: | ---: | ---: | ---: |"])
    subgroups = pd.read_csv(out / "per_finding/subgroup_delta.csv")
    for _, row in subgroups.iterrows():
        if int(row.n) < 3:
            continue
        lines.append(f"| {row.group_type}:{row.group} | {int(row.n)} | {row.dice250:.5f} | {row.dice500:.5f} | {row.delta:+.5f} | {format_float(row.mean_volume_ratio, 2)} |")
    lines.extend(
        [
            "",
            "## Prediction-volume drift",
            "",
            f"- Mean predicted volume: {paired_stats['mean_volume_250']:.1f} → {paired_stats['mean_volume_500']:.1f} mm³; ratio {volume_factor:.2f}×.",
            f"- Median predicted volume: {paired_stats['median_volume_250']:.1f} → {paired_stats['median_volume_500']:.1f} mm³.",
            f"- Median per-finding volume ratio: {paired_stats['median_volume_ratio']:.2f}×.",
            f"- Dice delta vs log2(volume ratio): Pearson {paired_stats['pearson_delta_vs_log_volume_ratio']:.3f}, Spearman {paired_stats['spearman_delta_vs_log_volume_ratio']:.3f}.",
            "",
            "## HIT transition analysis",
            "",
        ]
    )
    for name, count in paired_stats["hit_transition_counts"].items():
        lines.append(f"- {name}: {count}")
    swap = merged[merged.hit_transition.isin(["hit_lost", "hit_gained"])]
    if not swap.empty:
        lines.extend(["", "| Transition | Case | Finding | Prompt | Dice250 | Dice500 |", "| --- | --- | ---: | --- | ---: | ---: |"])
        for _, row in swap.iterrows():
            lines.append(f"| {row.hit_transition} | {row.case_id} | {int(row.finding_idx)} | {row.prompt_250} | {row.dice_250:.5f} | {row.dice_500:.5f} |")
    lines.extend(["", "## Feature drift", "", "| Scale | drift250 | drift500 | change | cos250 | cos500 | RMS ratio250 | RMS ratio500 |", "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"])
    for scale in sorted(feature["scale"].unique()):
        r250 = feature[(feature["scale"] == scale) & (feature["update"] == 250)].iloc[0]
        r500 = feature[(feature["scale"] == scale) & (feature["update"] == 500)].iloc[0]
        lines.append(
            f"| {scale} | {r250.relative_l2_drift_inferred:.5f} | {r500.relative_l2_drift_inferred:.5f} | {r500.relative_l2_drift_inferred-r250.relative_l2_drift_inferred:+.5f} | {r250.cosine_before_after:.5f} | {r500.cosine_before_after:.5f} | {r250.rms_after_over_before:.5f} | {r500.rms_after_over_before:.5f} |"
        )
    lines.extend(["", "## Parameter drift", "", "| Group | Params | norm250 | norm500 | relative delta |", "| --- | ---: | ---: | ---: | ---: |"])
    if param.empty:
        lines.append("| PENDING | PENDING | PENDING | PENDING | PENDING |")
    else:
        for _, row in param.head(16).iterrows():
            lines.append(f"| {row.group} | {int(row.parameter_count)} | {row.norm250:.3f} | {row.norm500:.3f} | {row.relative_delta:.6f} |")
    lines.extend(["", "## Attention/grounding", ""])
    if attn.empty:
        lines.append("Update250 attention diagnostics are pending; update500 diagnostics already exist. Re-run this script after `attention/update_250` is generated.")
    else:
        lines.extend(["| Metric | Mechanism | Scale | 250 | 500 | Change |", "| --- | --- | --- | ---: | ---: | ---: |"])
        for _, row in attn.iterrows():
            lines.append(f"| {row.metric} | {row.mechanism} | {row.scale} | {row.update250:.5f} | {row.update500:.5f} | {row.delta:+.5f} |")
    lines.extend(["", "## Diagnostic branch-disable inference", ""])
    if bypass is None:
        lines.append("PENDING. No retraining is needed; the optional tiny patch-level FAN-bypass job has not produced `branch_bypass_summary.json` yet.")
    else:
        lines.append("Scope: GT-centered 192³ patch diagnostics on the same selected records, not official full-volume fixed30.")
        lines.extend(["", "| Update | N | Normal patch Dice | FAN-bypass patch Dice | Bypass - normal | Normal pred vox | Bypass pred vox |", "| ---: | ---: | ---: | ---: | ---: | ---: | ---: |"])
        for row in bypass.get("summary", []):
            lines.append(
                f"| {row['update']} | {row['n']} | {row['normal_mean_patch_dice']:.5f} | {row['bypass_mean_patch_dice']:.5f} | {row['bypass_minus_normal_mean_patch_dice']:+.5f} | {row['normal_mean_pred_voxels']:.1f} | {row['bypass_mean_pred_voxels']:.1f} |"
            )
    lines.extend(
        [
            "",
            "## Hypothesis ranking",
            "",
            f"- H1 — Overfitting/generalization degradation: {'SUPPORTED' if h1_supported else 'NOT SUPPORTED'}; train loss did not keep decreasing 250→500.",
            f"- H2 — FAN feature overwrite: {'SUPPORTED' if h2_supported else 'NOT SUPPORTED'} for late 250→500 growth; FAN is already a large direct overwrite, but saved drift does not grow late.",
            f"- H3 — Non-semantic token sharpening: {h3_text}.",
            f"- H4 — Fine/global pathway interference: {h4_text}.",
            f"- H5 — Prediction-volume drift: {'SUPPORTED' if h5_supported else 'NOT SUPPORTED'}; A2-FAN mean volume expands sharply 250→500.",
            f"- H6 — Few-case instability: {'PARTIALLY SUPPORTED' if h6_supported else 'NOT SUPPORTED'}; several outliers dominate more than the mean, but worsened findings are numerous.",
            f"- H7 — Ordinary noise: {'PARTIALLY SUPPORTED' if h7_supported else 'NOT SUPPORTED'}; the mean drop is small and CI includes zero, but volume drift is mechanically large.",
            "",
            "## Recommended action for A2-FAN-Preserve",
            "",
            "- Keep the identity-dominant controlled fusion and explicitly monitor `||Vnew−V||/||V||`, cosine, and RMS ratio at Stage1/Stage2 gates.",
            "- Use best-checkpoint/early-stop selection around update250-like checkpoints; do not assume 500 updates is better for Direct-style FAN.",
            "- Treat prediction-volume expansion as a safety signal; add volume-drift thresholds to validation gates.",
            "- Keep pretrained/global pathway LR conservative and consider freezing it longer if Preserve begins to expand masks.",
            "- Do not interpret sharper or active token attention as useful grounding unless laterality/lobe/pathology ratios improve.",
            "",
            "## Files/scripts changed or created",
            "",
            "- Created `scripts/diagnose_a2_fan_250_500_posthoc.py`.",
            "- Modified `scripts/diagnose_token_common_init_attention.py` to allow `--update 250` for this diagnosis.",
            "",
            "## Runtime / jobs / remaining work",
            "",
            f"- CPU aggregation runtime: {runtime_seconds:.1f} seconds.",
            "- No retraining jobs were launched by this script.",
            "- Optional tiny GPU attention/bypass diagnostics may still be pending depending on files under `attention/update_250` and `branch_bypass/`.",
        ]
    )
    (out / "report.md").write_text("\n".join(lines) + "\n")


def main() -> int:
    start = time.time()
    args = parse_args()
    exp = args.experiment_root.resolve()
    out = args.output_dir.resolve()
    for rel in ("feature_drift", "attention", "per_finding", "volume", "branch_bypass", "analysis"):
        (out / rel).mkdir(parents=True, exist_ok=True)

    artifacts = {
        "A2_FAN_checkpoint_update_250": str(checkpoint_path(exp, "A2_FAN", 250)),
        "A2_FAN_checkpoint_update_500": str(checkpoint_path(exp, "A2_FAN", 500)),
        "B0_checkpoint_update_250": str(checkpoint_path(exp, "B0_original", 250)),
        "B0_checkpoint_update_500": str(checkpoint_path(exp, "B0_original", 500)),
        "A2_FAN_training_log": str(history_path(exp, "A2_FAN")),
        "B0_training_log": str(history_path(exp, "B0_original")),
        "A2_FAN_fixed30_update_250": str(per_finding_path(exp, "A2_FAN", 250)),
        "A2_FAN_fixed30_update_500": str(per_finding_path(exp, "A2_FAN", 500)),
        "existing_attention_update_500": str(exp / "diagnostics/A2_FAN/update_500"),
    }
    (out / "analysis/artifact_paths.json").write_text(json.dumps(artifacts, indent=2) + "\n")
    validation = validation_rows(exp)
    training = training_rows(exp)
    validation.to_csv(out / "analysis/validation_trajectory.csv", index=False)
    training.to_csv(out / "analysis/training_trajectory.csv", index=False)
    merged, stats, degradations, improvements = paired_delta(exp, out, args.seed, args.bootstrap)
    feature = feature_drift(exp, out)
    param = pd.DataFrame() if args.skip_parameter_drift else parameter_drift(exp, out)
    attn = attention_delta(exp, out)
    bypass = branch_bypass_summary(out)
    job = tiny_gpu_job(out)
    write_report(
        out,
        validation=validation,
        training=training,
        paired_stats=stats,
        merged=merged,
        degradations=degradations,
        improvements=improvements,
        feature=feature,
        param=param,
        attn=attn,
        bypass=bypass,
        runtime_seconds=time.time() - start,
    )
    if job is not None:
        report = out / "report.md"
        text = report.read_text()
        marker = "- Optional tiny GPU attention/bypass diagnostics may still be pending depending on files under `attention/update_250` and `branch_bypass/`."
        replacement = marker + f"\n- Tiny GPU diagnostic job: `{job.get('job_id')}` (`{job.get('job_name')}`), script `{job.get('script')}`."
        report.write_text(text.replace(marker, replacement))
    print(out / "report.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
