#!/usr/bin/env python3
"""Next-stage A500 full-2d and B500 target-25 ranking audit."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import pandas as pd
from scipy import ndimage
from nibabel.orientations import axcodes2ornt, io_orientation, ornt_transform


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/2d_specialist_a500_full2d_and_b500_audit"
CMP = ROOT / "outputs/2d_seg_component_size_comparison"
A_DIR = ROOT / "outputs/2d_seg_specialist_control_u500"
B_DIR = ROOT / "outputs/2d_seg_component_size_u500"
BASELINE = ROOT / "outputs/nonattention_baseline_selection/full381_update10000/summary_tables/per_finding_metrics.csv"
BASELINE_PROV = CMP / "baseline10000_provenance.json"
KEYS = ["file", "finding_idx"]
STRUCTURE = ndimage.generate_binary_structure(3, 3)


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=str) + "\n")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def prob_path(arm: str, case_name: str) -> Path:
    stem = case_name.removesuffix(".nii.gz").removesuffix(".nii")
    return OUT / "target25_probabilities" / arm / f"{stem}.npz"


def load_manifest(label: str) -> dict[str, Any]:
    return json.loads((CMP / f"{label}_manifest.json").read_text())


def manifest_keys(label: str) -> set[tuple[str, int]]:
    data = load_manifest(label)
    return {(entry["name"], int(key)) for entry in data["val"] for key in entry["findings"]}


def baseline_for(label: str) -> pd.DataFrame:
    keys = manifest_keys(label)
    frame = pd.read_csv(BASELINE)
    frame = frame[[tuple(row) in keys for row in frame[KEYS].itertuples(index=False, name=None)]].copy()
    if len(frame) != len(keys) or frame.duplicated(KEYS).any():
        raise RuntimeError(f"baseline mapping mismatch for {label}")
    return frame.sort_values(KEYS).reset_index(drop=True)


def summary(frame: pd.DataFrame) -> dict[str, Any]:
    gt = frame.gt_voxels.clip(lower=1)
    return {
        "n": int(len(frame)),
        "mean_dice": float(frame.global_dice.mean()) if len(frame) else float("nan"),
        "hits": int(frame.global_hit.astype(bool).sum()) if len(frame) else 0,
        "precision": float(frame.voxel_precision.mean()) if len(frame) else float("nan"),
        "recall": float(frame.voxel_recall.mean()) if len(frame) else float("nan"),
        "FP_GT": float((frame.fp_voxels / gt).mean()) if len(frame) else float("nan"),
        "FN_GT": float((frame.fn_voxels / gt).mean()) if len(frame) else float("nan"),
        "predicted_GT_volume_ratio": float((frame.pred_voxels / gt).mean()) if len(frame) else float("nan"),
    }


def compare(candidate: pd.DataFrame, reference: pd.DataFrame) -> dict[str, Any]:
    merged = reference[KEYS + ["global_dice", "global_hit"]].merge(
        candidate[KEYS + ["global_dice", "global_hit"]],
        on=KEYS,
        suffixes=("_reference", "_candidate"),
        validate="one_to_one",
    )
    delta = merged.global_dice_candidate - merged.global_dice_reference
    return {
        "mean_dice_delta": float(delta.mean()),
        "hit_delta": int(merged.global_hit_candidate.sum() - merged.global_hit_reference.sum()),
        "improved": int((delta > 1e-12).sum()),
        "degraded": int((delta < -1e-12).sum()),
        "tied": int((delta.abs() <= 1e-12).sum()),
        "new_hits": int(((merged.global_hit_candidate.astype(bool)) & (~merged.global_hit_reference.astype(bool))).sum()),
        "lost_hits": int(((~merged.global_hit_candidate.astype(bool)) & merged.global_hit_reference.astype(bool)).sum()),
    }


def bootstrap(candidate: pd.DataFrame, reference: pd.DataFrame, mask: np.ndarray, seed: int = 260810) -> dict[str, Any]:
    merged = reference[KEYS + ["global_dice"]].merge(
        candidate[KEYS + ["global_dice", "global_hit"]],
        on=KEYS,
        suffixes=("_reference", "_candidate"),
        validate="one_to_one",
    )
    merged = merged.loc[mask].copy()
    cases = np.asarray(sorted(merged.file.unique()))
    grouped = {case: merged[merged.file.eq(case)] for case in cases}
    rng = np.random.default_rng(seed)
    draws = np.empty(10000, dtype=np.float64)
    for i in range(len(draws)):
        sample = rng.choice(cases, size=len(cases), replace=True)
        deltas = [grouped[case].global_dice_candidate.to_numpy() - grouped[case].global_dice_reference.to_numpy() for case in sample]
        draws[i] = np.concatenate(deltas).mean()
    observed = float((merged.global_dice_candidate - merged.global_dice_reference).mean())
    return {
        "paired_mean_dice_delta": observed,
        "ci_low": float(np.quantile(draws, 0.025)),
        "ci_high": float(np.quantile(draws, 0.975)),
        "p_delta_gt_0": float(np.mean(draws > 0)),
        "hit_delta": int(merged.global_hit.sum() - reference.loc[mask, "global_hit"].sum()),
        "replicates": 10000,
    }


def stratum_masks(frame: pd.DataFrame) -> dict[str, np.ndarray]:
    pixels = frame.pixels.to_numpy(float)
    return {
        "all_2d": np.ones(len(frame), dtype=bool),
        "tiny": pixels < 100,
        "small": (pixels >= 100) & (pixels < 1000),
        "medium": (pixels >= 1000) & (pixels < 10000),
        "large": pixels >= 10000,
        "small_2d": pixels < 1000,
        "other_2d": pixels >= 1000,
    }


def a500_full2d() -> None:
    a = pd.read_csv(A_DIR / "evaluation/full2d/per_finding.csv").sort_values(KEYS).reset_index(drop=True)
    acomp = pd.read_csv(A_DIR / "evaluation/full2d/per_component.csv")
    base = baseline_for("full2d")
    if len(a) != 132 or a.duplicated(KEYS).any():
        raise RuntimeError("A500 full2d result mapping mismatch")
    merged = a.merge(base, on=KEYS, suffixes=("_A500", "_baseline10000"), validate="one_to_one")
    merged["dice_delta_A500_minus_baseline10000"] = merged.global_dice_A500 - merged.global_dice_baseline10000
    merged["hit_delta_A500_minus_baseline10000"] = merged.global_hit_A500.astype(int) - merged.global_hit_baseline10000.astype(int)
    merged.to_csv(OUT / "a500_full2d_per_finding.csv", index=False)
    acomp.to_csv(OUT / "a500_full2d_per_component.csv", index=False)

    masks = stratum_masks(a)
    payload: dict[str, Any] = {
        "A500": {name: summary(a.loc[mask]) for name, mask in masks.items()},
        "baseline10000": {name: summary(base.loc[mask]) for name, mask in masks.items()},
        "A500_minus_baseline10000": {name: compare(a.loc[mask], base.loc[mask]) for name, mask in masks.items()},
        "component_metrics": {
            "components": int(len(acomp)),
            "component_any_overlap_fraction": float(acomp.any_predicted_overlap.mean()),
            "component_recall_ge_10pct": float(acomp.recalled_ge_10pct.mean()),
            "lt1000_any_overlap_fraction": float(acomp.loc[acomp.small_lt1000, "any_predicted_overlap"].mean()),
        },
    }
    write_json(OUT / "a500_full2d_summary.json", payload)

    rows = []
    for stratum in ("all_2d", "small_2d"):
        rows.append({"comparison": "A500_vs_baseline10000", "stratum": stratum, **bootstrap(a, base, masks[stratum])})
    pd.DataFrame(rows).to_csv(OUT / "a500_vs_baseline_bootstrap.csv", index=False)

    influence = []
    small = masks["small_2d"]
    for case in sorted(a.loc[small, "file"].unique()):
        keep = small & a.file.ne(case)
        if keep.any():
            influence.append({
                "left_out_case": case,
                "small_2d_delta": float((a.loc[keep, "global_dice"].to_numpy() - base.loc[keep, "global_dice"].to_numpy()).mean()),
            })
    pd.DataFrame(influence).to_csv(OUT / "a500_leave_one_case_out.csv", index=False)

    all_cmp = payload["A500_minus_baseline10000"]["all_2d"]
    small_cmp = payload["A500_minus_baseline10000"]["small_2d"]
    precision_ok = payload["A500"]["all_2d"]["precision"] >= payload["baseline10000"]["all_2d"]["precision"] - 0.02
    volume_ok = payload["A500"]["all_2d"]["predicted_GT_volume_ratio"] <= 1.15 * payload["baseline10000"]["all_2d"]["predicted_GT_volume_ratio"]
    promising = all_cmp["mean_dice_delta"] >= -0.001 and (
        small_cmp["mean_dice_delta"] > 0 or small_cmp["hit_delta"] > 0
    ) and precision_ok and volume_ok
    if promising:
        decision = "A. ORDINARY 2D SPECIALIST IS PROMISING AND DEPLOYABLE"
    elif small_cmp["mean_dice_delta"] > 0 and all_cmp["mean_dice_delta"] < 0:
        decision = "C. IMPROVES SMALL-2D BUT HARMS OVERALL 2D"
    elif all_cmp["mean_dice_delta"] > 0 and not (precision_ok and volume_ok):
        decision = "D. IMPROVES DICE BUT ONLY THROUGH VOLUME/FP TRADEOFF"
    elif abs(all_cmp["mean_dice_delta"]) < 0.003:
        decision = "E. INCONCLUSIVE / SAMPLE-DRIVEN"
    else:
        decision = "B. TARGET-25 POSITIVE SIGNAL DOES NOT GENERALIZE"
    write_json(OUT / "a500_decision.json", {"classification": decision, "precision_ok": precision_ok, "volume_ok": volume_ok})


def quantiles(values: np.ndarray) -> dict[str, float]:
    if values.size == 0:
        return {k: float("nan") for k in ("min", "p1", "p5", "p25", "median", "p75", "p95", "p99", "max")}
    q = np.quantile(values.astype(np.float32, copy=False), [0, .01, .05, .25, .5, .75, .95, .99, 1])
    return dict(zip(("min", "p1", "p5", "p25", "median", "p75", "p95", "p99", "max"), map(float, q)))


def binary_metrics(prob: np.ndarray, target: np.ndarray, mask: np.ndarray) -> dict[str, Any]:
    pred = mask.astype(bool, copy=False)
    gt = target.astype(bool, copy=False)
    tp = int(np.logical_and(pred, gt).sum())
    fp = int(np.logical_and(pred, ~gt).sum())
    fn = int(np.logical_and(~pred, gt).sum())
    pred_voxels = int(pred.sum())
    gt_voxels = int(gt.sum())
    labels, count = ndimage.label(gt, structure=STRUCTURE)
    any_overlap = ge10 = 0
    gt_sized_any = 0
    if count:
        k = min(gt_voxels, prob.size)
        top = np.zeros(prob.size, dtype=bool)
        if k > 0:
            top[np.argpartition(prob.ravel(), -k)[-k:]] = True
            top = top.reshape(prob.shape)
        for cid in range(1, count + 1):
            comp = labels == cid
            vox = int(comp.sum())
            ov = int(np.logical_and(pred, comp).sum())
            top_ov = int(np.logical_and(top, comp).sum())
            any_overlap += int(ov > 0)
            ge10 += int(vox and ov / vox >= 0.10)
            gt_sized_any += int(top_ov > 0)
    return {
        "global_dice": 2 * tp / max(1, pred_voxels + gt_voxels),
        "global_hit": (2 * tp / max(1, pred_voxels + gt_voxels)) >= 0.10,
        "tp_voxels": tp,
        "fp_voxels": fp,
        "fn_voxels": fn,
        "pred_voxels": pred_voxels,
        "gt_voxels": gt_voxels,
        "voxel_precision": tp / (tp + fp) if tp + fp else 1.0,
        "voxel_recall": tp / (tp + fn) if tp + fn else 1.0,
        "FP_GT": fp / gt_voxels if gt_voxels else 0.0,
        "FN_GT": fn / gt_voxels if gt_voxels else 0.0,
        "predicted_GT_volume_ratio": pred_voxels / gt_voxels if gt_voxels else 0.0,
        "gt_components": count,
        "component_recall_any": any_overlap / count if count else 1.0,
        "component_recall_ge10": ge10 / count if count else 1.0,
        "gt_sized_topk_component_recall_any": gt_sized_any / count if count else 1.0,
    }


def sampled_ranking(prob: np.ndarray, target: np.ndarray, seed: int, negative_cap: int = 200000) -> dict[str, float]:
    gt = target.ravel().astype(bool)
    scores = prob.ravel().astype(np.float32, copy=False)
    pos_idx = np.flatnonzero(gt)
    neg_idx = np.flatnonzero(~gt)
    rng = np.random.default_rng(seed)
    if neg_idx.size > negative_cap:
        neg_idx = rng.choice(neg_idx, size=negative_cap, replace=False)
    idx = np.concatenate([pos_idx, neg_idx])
    y = gt[idx].astype(np.uint8)
    s = scores[idx]
    if y.sum() == 0 or y.sum() == len(y):
        auroc = float("nan")
    else:
        order = np.argsort(s, kind="mergesort")
        ranks = np.empty_like(order, dtype=np.float64)
        ranks[order] = np.arange(1, len(s) + 1)
        n_pos = float(y.sum())
        n_neg = float(len(y) - y.sum())
        auroc = float((ranks[y.astype(bool)].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg))
    order = np.argsort(-s, kind="mergesort")
    y_sorted = y[order]
    tp = np.cumsum(y_sorted)
    positives = int(y.sum())
    ap = float((tp[y_sorted.astype(bool)] / (np.flatnonzero(y_sorted) + 1)).sum() / positives) if positives else float("nan")
    prevalence = float(y.mean()) if len(y) else float("nan")
    return {"voxel_AUROC_sampled": auroc, "voxel_AUPRC_sampled": ap, "foreground_prevalence_sampled": prevalence, "AUPRC_prevalence_ratio": ap / prevalence if prevalence > 0 else float("nan")}


def per_condition_summary(rows: list[dict[str, Any]], condition_key: str) -> pd.DataFrame:
    frame = pd.DataFrame(rows)
    out = []
    for condition, block in frame.groupby(condition_key):
        small = block.pixels < 1000
        for label, subset in (("all_2d", block), ("small_2d", block[small]), ("other_2d", block[~small])):
            out.append({
                condition_key: condition,
                "stratum": label,
                "n": len(subset),
                "mean_dice": float(subset.global_dice.mean()) if len(subset) else float("nan"),
                "hits": int(subset.global_hit.sum()) if len(subset) else 0,
                "precision": float(subset.voxel_precision.mean()) if len(subset) else float("nan"),
                "recall": float(subset.voxel_recall.mean()) if len(subset) else float("nan"),
                "FP_GT": float(subset.FP_GT.mean()) if len(subset) else float("nan"),
                "FN_GT": float(subset.FN_GT.mean()) if len(subset) else float("nan"),
                "predicted_GT_volume_ratio": float(subset.predicted_GT_volume_ratio.mean()) if len(subset) else float("nan"),
                "component_recall_any": float(subset.component_recall_any.mean()) if len(subset) else float("nan"),
                "component_recall_ge10": float(subset.component_recall_ge10.mean()) if len(subset) else float("nan"),
            })
    return pd.DataFrame(out)


def b500_audit() -> None:
    manifest = load_manifest("target25")
    a_ref = pd.read_csv(A_DIR / "evaluation/target25/per_finding.csv").sort_values(KEYS).reset_index(drop=True)
    thresholds = [0.5, 0.9, 0.95, 0.98, 0.99]
    ratios = [1, 2, 5, 10]
    threshold_rows: list[dict[str, Any]] = []
    topk_rows: list[dict[str, Any]] = []
    ranking_rows: list[dict[str, Any]] = []
    histogram_rows: list[dict[str, Any]] = []
    component_rows: list[dict[str, Any]] = []

    ref_lookup = {(row.file, int(row.finding_idx)): row for row in a_ref.itertuples(index=False)}
    for arm in ("A500", "B500"):
        for case_no, entry in enumerate(manifest["val"]):
            archive = np.load(prob_path(arm, entry["name"]), allow_pickle=False)
            prob_all = archive["probability"]
            finding_ids = [int(x) for x in archive["finding_ids"].tolist()]
            channel_by_finding = {fid: channel for channel, fid in enumerate(finding_ids)}
            gt_image = nib.load(str(ROOT / "data/segmentations" / entry["name"]))
            gt_all = np.asanyarray(gt_image.dataobj)
            ct_image = nib.load(str(ROOT / "data/ct_rate_volumes_fixed" / entry["name"]))
            reoriented_ct = ct_image.as_reoriented(io_orientation(ct_image.affine))
            from_canonical = ornt_transform(
                axcodes2ornt("RAS"), io_orientation(ct_image.affine)
            )
            saved_binary_all = np.asanyarray(
                nib.load(
                    str(
                        OUT
                        / "target25_probability_inference"
                        / arm
                        / entry["name"]
                    )
                ).dataobj
            )
            voxel_volume = float(abs(np.linalg.det(gt_image.affine[:3, :3])))
            for pred_channel, (key, prompt) in enumerate(entry["findings"].items()):
                fid = int(key)
                prob_network = prob_all[channel_by_finding[fid]].astype(np.float32)
                # Probability archives are stored in nnU-Net's reoriented
                # (D,H,W) coordinate system. Restore both the transpose and the
                # case-specific orientation flips exactly as save_rex_4d does
                # for binary predictions.
                prob_ras_xyz = np.transpose(prob_network, (2, 1, 0))
                prob_image = nib.Nifti1Image(
                    prob_ras_xyz, affine=reoriented_ct.affine
                ).as_reoriented(from_canonical)
                prob = np.asanyarray(prob_image.dataobj)
                target = np.asarray(gt_all[fid] > 0)
                if prob.shape != target.shape:
                    raise ValueError(
                        f"Cannot align probability/GT shapes for {entry['name']} "
                        f"finding {fid}: probability={prob.shape}, target={target.shape}"
                    )
                saved_binary = np.asarray(saved_binary_all[pred_channel] > 0)
                thresholded = prob > 0.5
                if not np.array_equal(thresholded, saved_binary):
                    raise RuntimeError(
                        f"Restored probability does not reproduce saved binary for "
                        f"{arm} {entry['name']} finding {fid}: "
                        f"mismatches={np.count_nonzero(thresholded != saved_binary)}"
                    )
                pixels = int(entry["pixels"][key])
                common = {"arm": arm, "file": entry["name"], "finding_idx": fid, "pixels": pixels, "prompt": prompt}
                rank = sampled_ranking(prob, target, seed=260810 + case_no * 100 + fid)
                dist = ndimage.distance_transform_edt(~target)
                peak_idx = np.unravel_index(int(np.argmax(prob)), prob.shape)
                k_gt = min(int(target.sum()), prob.size)
                if k_gt > 0:
                    top_idx = np.argpartition(prob.ravel(), -k_gt)[-k_gt:]
                    gt_sized_precision = float(target.ravel()[top_idx].mean())
                else:
                    gt_sized_precision = float("nan")
                rank.update({
                    **common,
                    "peak_in_gt": bool(target[peak_idx]),
                    "peak_to_GT_distance_voxels": float(dist[peak_idx]),
                    "GT_sized_topk_precision": gt_sized_precision,
                })
                ranking_rows.append(rank)

                gt_values = prob[target]
                distance = ndimage.distance_transform_edt(target == 0)
                local_bg = (distance <= 12) & (~target)
                far_bg = (distance > 12) & (~target)
                for region, values in (("GT", gt_values), ("local_bg_12vox", prob[local_bg]), ("far_bg", prob[far_bg])):
                    histogram_rows.append({**common, "region": region, **quantiles(values)})

                if arm == "B500":
                    ref = ref_lookup[(entry["name"], fid)]
                    for thr in thresholds:
                        metrics = binary_metrics(prob, target, prob > thr)
                        threshold_rows.append({
                            **common,
                            "threshold": thr,
                            **metrics,
                            "dice_delta_vs_A500_at_0p5": metrics["global_dice"] - float(ref.global_dice),
                            "hit_delta_vs_A500_at_0p5": int(metrics["global_hit"]) - int(ref.global_hit),
                        })
                    for ratio in ratios:
                        k = min(max(1, int(round(ratio * int(target.sum())))), prob.size)
                        mask = np.zeros(prob.size, dtype=bool)
                        mask[np.argpartition(prob.ravel(), -k)[-k:]] = True
                        metrics = binary_metrics(prob, target, mask.reshape(prob.shape))
                        topk_rows.append({
                            **common,
                            "topk_ratio": ratio,
                            **metrics,
                            "dice_delta_vs_A500_at_0p5": metrics["global_dice"] - float(ref.global_dice),
                            "hit_delta_vs_A500_at_0p5": int(metrics["global_hit"]) - int(ref.global_hit),
                        })

                    for label, mask in (("threshold_0.5", prob > 0.5), ("threshold_0.95", prob > 0.95), ("threshold_0.99", prob > 0.99)):
                        labels, count = ndimage.label(mask, structure=STRUCTURE)
                        objects = ndimage.find_objects(labels)
                        for cid, obj in enumerate(objects, start=1):
                            if obj is None:
                                continue
                            member = labels[obj] == cid
                            values = prob[obj][member]
                            overlap = int(target[obj][member].sum())
                            component_rows.append({
                                **common,
                                "candidate_source": label,
                                "component_id": cid,
                                "component_size": int(member.sum()),
                                "gt_overlap": overlap,
                                "overlaps_gt": overlap > 0,
                                "max_probability": float(values.max()),
                                "top1pct_mean_probability": float(np.partition(values, -max(1, int(np.ceil(values.size * .01))))[-max(1, int(np.ceil(values.size * .01))):].mean()),
                                "top5pct_mean_probability": float(np.partition(values, -max(1, int(np.ceil(values.size * .05))))[-max(1, int(np.ceil(values.size * .05))):].mean()),
                                "mean_probability": float(values.mean()),
                                "probability_mass_density": float(values.sum() / max(1, member.sum())),
                                "component_volume_mm3": float(member.sum() * voxel_volume),
                            })

    threshold_frame = pd.DataFrame(threshold_rows)
    topk_frame = pd.DataFrame(topk_rows)
    threshold_frame.to_csv(OUT / "b500_target25_per_finding_thresholds.csv", index=False)
    topk_frame.to_csv(OUT / "b500_target25_per_finding_topk.csv", index=False)
    per_condition_summary(threshold_rows, "threshold").to_csv(OUT / "b500_target25_threshold_summary.csv", index=False)
    per_condition_summary(topk_rows, "topk_ratio").to_csv(OUT / "b500_target25_topk_summary.csv", index=False)
    pd.DataFrame(ranking_rows).to_csv(OUT / "a500_b500_ranking_metrics.csv", index=False)
    pd.DataFrame(histogram_rows).to_csv(OUT / "probability_histograms.csv", index=False)
    pd.DataFrame(component_rows).to_csv(OUT / "component_ranking_audit.csv", index=False)

    b_rank = pd.DataFrame(ranking_rows)
    b500 = b_rank[b_rank.arm.eq("B500")]
    a500 = b_rank[b_rank.arm.eq("A500")]
    gt_topk_better = float(b500.GT_sized_topk_precision.mean() - a500.GT_sized_topk_precision.mean())
    best_topk = per_condition_summary(topk_rows, "topk_ratio")
    best_topk_all = best_topk[best_topk.stratum.eq("all_2d")].sort_values("mean_dice", ascending=False).iloc[0]
    best_thr = per_condition_summary(threshold_rows, "threshold")
    best_thr_all = best_thr[best_thr.stratum.eq("all_2d")].sort_values("mean_dice", ascending=False).iloc[0]
    if float(best_topk_all.mean_dice) >= 0.25 and gt_topk_better > 0:
        classification = "A. USEFUL RANKING SIGNAL BUT POOR CALIBRATION"
    elif float(best_thr_all.mean_dice) >= 0.25 and float(best_thr_all.precision) > 0.1:
        classification = "B. THRESHOLD/CALIBRATION FAILURE ONLY"
    elif gt_topk_better <= 0 and float(best_topk_all.mean_dice) < 0.15:
        classification = "C. DIFFUSE FOREGROUND COLLAPSE"
    else:
        classification = "D. COMPONENT LOSS HAS NO PRACTICAL VALUE"
    write_json(
        OUT / "b500_audit_decision.json",
        {
            "classification": classification,
            "best_topk_all_2d": best_topk_all.to_dict(),
            "best_threshold_all_2d": best_thr_all.to_dict(),
            "B500_minus_A500_GT_sized_topk_precision": gt_topk_better,
            "voxel_ranking_note": "AUROC/AUPRC use all foreground voxels and a deterministic capped background sample per finding.",
        },
    )


def combined() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    a_decision = json.loads((OUT / "a500_decision.json").read_text()) if (OUT / "a500_decision.json").exists() else {}
    b_decision = json.loads((OUT / "b500_audit_decision.json").read_text()) if (OUT / "b500_audit_decision.json").exists() else {}
    payload = {
        "A500_full2d": json.loads((OUT / "a500_full2d_summary.json").read_text()) if (OUT / "a500_full2d_summary.json").exists() else None,
        "A500_decision": a_decision,
        "B500_audit_decision": b_decision,
        "output_dir": str(OUT.resolve()),
    }
    write_json(OUT / "summary.json", payload)
    report = [
        "# A500 full-2d and B500 ranking audit",
        "",
        f"A500 decision: **{a_decision.get('classification', 'pending')}**",
        f"B500 decision: **{b_decision.get('classification', 'pending')}**",
        "",
        "See `a500_full2d_summary.json`, `b500_target25_threshold_summary.csv`, and `b500_target25_topk_summary.csv`.",
    ]
    (OUT / "report.md").write_text("\n".join(report) + "\n")


def provenance() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    a_ckpt = A_DIR / "checkpoints/checkpoint_update_500.pth"
    b_ckpt = B_DIR / "checkpoints/checkpoint_update_500.pth"
    write_json(
        OUT / "checkpoint_paths_and_digests.json",
        {
            "A500": {"checkpoint": str(a_ckpt.resolve()), "sha256": sha256(a_ckpt)},
            "B500": {"checkpoint": str(b_ckpt.resolve()), "sha256": sha256(b_ckpt)},
        },
    )
    write_json(OUT / "baseline10000_provenance.json", json.loads(BASELINE_PROV.read_text()))
    write_json(
        OUT / "provenance.json",
        {
            "source_comparison_dir": str(CMP.resolve()),
            "A500_control_dir": str(A_DIR.resolve()),
            "B500_component_aware_dir": str(B_DIR.resolve()),
            "target25_manifest": str((CMP / "target25_manifest.json").resolve()),
            "full2d_manifest": str((CMP / "full2d_manifest.json").resolve()),
            "baseline10000_reused": True,
        },
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["provenance", "a500_full2d", "b500_audit", "combined", "all"])
    args = parser.parse_args()
    if args.mode in {"provenance", "all"}:
        provenance()
    if args.mode in {"a500_full2d", "all"}:
        a500_full2d()
    if args.mode in {"b500_audit", "all"}:
        b500_audit()
    if args.mode in {"combined", "all"}:
        combined()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
