#!/usr/bin/env python3
"""Collect paired 381-finding results for a GO joint-gamma screen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "outputs/controlled_v11_selected_full200"


def bootstrap(frame: pd.DataFrame) -> list[float]:
    rng = np.random.default_rng(2026)
    cases = sorted(frame.file.unique())
    groups = {case: frame.loc[frame.file == case, "delta"].to_numpy() for case in cases}
    values = np.empty(10_000)
    for index in range(len(values)):
        sample = rng.choice(cases, len(cases), replace=True)
        values[index] = np.concatenate([groups[case] for case in sample]).mean()
    return np.quantile(values, [0.025, 0.975]).tolist()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", choices=["P", "F"], required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    baseline = pd.read_csv(
        BASE / ("s3_update8000" if args.job == "P" else "s3_update9000")
        / "per_finding_metrics.csv"
    )
    candidate = pd.read_csv(args.run_dir / "full381/final/per_finding_metrics.csv")
    paired = baseline.merge(
        candidate, on=["file", "finding_idx"], suffixes=("_base", "_candidate")
    )
    paired["delta"] = paired.global_dice_candidate - paired.global_dice_base
    tolerance = 1e-12
    result = {
        "job": args.job,
        "findings": len(paired),
        "baseline_dice": float(paired.global_dice_base.mean()),
        "candidate_dice": float(paired.global_dice_candidate.mean()),
        "mean_delta": float(paired.delta.mean()),
        "case_bootstrap_delta_95ci": bootstrap(paired),
        "baseline_hits": int(paired.global_hit_base.sum()),
        "candidate_hits": int(paired.global_hit_candidate.sum()),
        "improved": int((paired.delta > tolerance).sum()),
        "degraded": int((paired.delta < -tolerance).sum()),
        "tied": int((paired.delta.abs() <= tolerance).sum()),
        "new_hits": int(
            ((~paired.global_hit_base) & paired.global_hit_candidate).sum()
        ),
        "lost_hits": int(
            (paired.global_hit_base & (~paired.global_hit_candidate)).sum()
        ),
        "historical_control_quality": (
            "own_exact_start" if args.job == "P" else "weak_non_step_matched"
        ),
    }
    paired.to_csv(args.run_dir / "full381/paired_final.csv", index=False)
    (args.run_dir / "full381/full_result.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
