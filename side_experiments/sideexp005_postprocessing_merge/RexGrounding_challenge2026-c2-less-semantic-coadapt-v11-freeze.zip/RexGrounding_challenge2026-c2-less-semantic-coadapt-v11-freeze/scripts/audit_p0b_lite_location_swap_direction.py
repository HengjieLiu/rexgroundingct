#!/usr/bin/env python3
"""Inference-only anatomy-direction audit for the fixed P0 location-swap pairs."""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import platform
import re
import subprocess
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
import torch
from scipy import ndimage
from scipy.special import expit


ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT / "VoxTell", ROOT / "scripts"):
    if str(search_path) not in sys.path:
        sys.path.insert(0, str(search_path))

from audit_p0_minimal_location_swap_trace import (  # noqa: E402
    extract_qwen,
    tensor_digest,
)
from diagnose_spatial_attention_localization import (  # noqa: E402
    load_rex_masks_in_preprocessed_ras,
)
from run_voxtell_rex_inference import (  # noqa: E402
    load_entries,
    load_image,
    sorted_prompts,
)
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402


P0_DIR = ROOT / "outputs/p0_minimal_location_swap_trace_anchor85_fixed30"
DEFAULT_OUTPUT = ROOT / "outputs/p0b_lite_location_swap_direction_anchor85_fixed30"
DEFAULT_CHECKPOINT = (
    ROOT
    / "outputs/voxtell_rex_anchor85_samecase15_preprocessed_4l40s_to4000"
    / "checkpoints/checkpoint_best_val_dice_step_3800.pth"
)
DEFAULT_MANIFEST = ROOT / "data/rex_voxtell_preprocessed_v1/manifest.jsonl"
DEFAULT_LOBE_LABELS = ROOT / "data/rex_lobe_labels_preprocessed_v1"
DEFAULT_PRIOR_ROOT = (
    ROOT / "outputs/anatomy_prior_diagnostic_val_hardneg_step1000_thr0p7/lung_priors"
)

LABEL_NAMES = {
    0: "background_non_lung",
    1: "left_upper_lobe",
    2: "left_lower_lobe",
    3: "right_upper_lobe",
    4: "right_middle_lobe",
    5: "right_lower_lobe",
}
ANATOMY_LABELS = {
    "left_lung": (1, 2),
    "right_lung": (3, 4, 5),
    "left_upper_lobe": (1,),
    "left_lower_lobe": (2,),
    "right_upper_lobe": (3,),
    "right_lower_lobe": (5,),
}
TAUS = (0.025, 0.05, 0.10)
PRIMARY_TAU = 0.05
EPS = 1e-12
CONNECTIVITY = np.ones((3, 3, 3), dtype=np.uint8)
P0_REPRODUCTION_COLUMNS = (
    "correct_predicted_foreground_voxels",
    "swapped_predicted_foreground_voxels",
    "correct_dice",
    "swapped_dice",
    "mean_absolute_logit_difference",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--p0-dir", type=Path, default=P0_DIR)
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument(
        "--fixed30-manifest",
        type=Path,
        default=(
            ROOT
            / "outputs/prompt_standardization_rule_only_v1"
            / "stratified30_six_variant_ablation_v1/prepared_inputs/"
            "stratified_subset_manifest.json"
        ),
    )
    parser.add_argument(
        "--rex-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json"
    )
    parser.add_argument(
        "--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed"
    )
    parser.add_argument(
        "--mask-dir", type=Path, default=ROOT / "data/segmentations"
    )
    parser.add_argument(
        "--model-dir", type=Path, default=ROOT / "VoxTell/voxtell_v1.1"
    )
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--lobe-label-dir", type=Path, default=DEFAULT_LOBE_LABELS)
    parser.add_argument("--prior-root", type=Path, default=DEFAULT_PRIOR_ROOT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--text-model", default="Qwen/Qwen3-Embedding-4B")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--qwen-batch-size", type=int, default=16)
    parser.add_argument("--near-empty-voxels", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260729)
    return parser.parse_args()


def json_ready(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {str(key): json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(item) for item in value]
    return value


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(json_ready(payload), indent=2, sort_keys=False) + "\n"
    )
    temporary.replace(path)


def write_csv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git_state(path: Path) -> dict[str, Any]:
    try:
        commit = subprocess.check_output(
            ["git", "-C", str(path), "rev-parse", "HEAD"], text=True
        ).strip()
        dirty = subprocess.check_output(
            ["git", "-C", str(path), "status", "--short"], text=True
        ).splitlines()
        return {"commit": commit, "dirty_entries": dirty}
    except (subprocess.CalledProcessError, FileNotFoundError):
        return {"commit": None, "dirty_entries": []}


def case_stem(case_id: str) -> str:
    return case_id.removesuffix(".nii.gz").removesuffix(".nii")


def load_manifest(path: Path) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    with path.open() as handle:
        for line in handle:
            row = json.loads(line)
            if row.get("status") == "processed":
                rows[str(row["case"])] = row
    return rows


def one_location(text: str, choices: tuple[str, ...], pair_id: str) -> str:
    matches = {
        choice
        for choice in choices
        if re.search(rf"\b{re.escape(choice)}\b", text, flags=re.IGNORECASE)
    }
    if len(matches) != 1:
        raise ValueError(f"{pair_id}: expected one of {choices}, found {sorted(matches)}")
    return next(iter(matches))


def anatomy_definition(pair: dict[str, Any]) -> dict[str, Any]:
    pair_id = str(pair["pair_id"])
    original = str(pair["original_prompt"])
    swapped = str(pair["swapped_prompt"])
    original_side = one_location(original, ("left", "right"), pair_id)
    swapped_side = one_location(swapped, ("left", "right"), pair_id)
    swap_type = str(pair["swap_type"])
    if swap_type == "laterality":
        if original_side == swapped_side:
            raise ValueError(f"{pair_id}: laterality did not change")
        original_anatomy = f"{original_side}_lung"
        swapped_anatomy = f"{swapped_side}_lung"
    elif swap_type == "upper_lower":
        if original_side != swapped_side:
            raise ValueError(f"{pair_id}: upper/lower swap changed laterality")
        original_level = one_location(original, ("upper lobe", "lower lobe"), pair_id)
        swapped_level = one_location(swapped, ("upper lobe", "lower lobe"), pair_id)
        if original_level == swapped_level:
            raise ValueError(f"{pair_id}: upper/lower location did not change")
        original_anatomy = f"{original_side}_{original_level.replace(' ', '_')}"
        swapped_anatomy = f"{swapped_side}_{swapped_level.replace(' ', '_')}"
    else:
        raise ValueError(f"{pair_id}: unexpected swap type {swap_type!r}")
    return {
        "case_id": str(pair["case_id"]),
        "finding_id": int(pair["finding_id"]),
        "pair_id": pair_id,
        "swap_type": swap_type,
        "original_prompt": original,
        "swapped_prompt": swapped,
        "original_anatomy": original_anatomy,
        "swapped_anatomy": swapped_anatomy,
        "original_label_values": "|".join(map(str, ANATOMY_LABELS[original_anatomy])),
        "swapped_label_values": "|".join(map(str, ANATOMY_LABELS[swapped_anatomy])),
    }


def load_and_validate_pairs(p0_dir: Path) -> tuple[list[dict[str, Any]], pd.DataFrame]:
    pairs = json.loads((p0_dir / "prompt_pairs.json").read_text())
    if not isinstance(pairs, list):
        raise TypeError("P0 prompt_pairs.json is not a list")
    counts = Counter(str(pair.get("swap_type")) for pair in pairs)
    if len(pairs) != 16 or counts != {"laterality": 12, "upper_lower": 4}:
        raise RuntimeError(f"Expected 16 (12/4) fixed pairs, found {len(pairs)} {counts}")
    if len({str(pair["pair_id"]) for pair in pairs}) != 16:
        raise RuntimeError("P0 prompt pair IDs are not unique")
    frame = pd.DataFrame([anatomy_definition(pair) for pair in pairs])
    return pairs, frame


def load_lobes(path: Path) -> np.ndarray:
    with np.load(path, allow_pickle=False) as payload:
        label = payload["lobe_label"].astype(np.uint8, copy=False)
        result = label.copy()
    values = set(np.unique(result).tolist())
    if values != set(LABEL_NAMES):
        raise RuntimeError(f"{path}: expected labels 0..5, found {sorted(values)}")
    return result


def contour_if_present(
    axis: plt.Axes,
    mask: np.ndarray,
    color: str,
    linewidth: float = 1.0,
    label: str | None = None,
) -> None:
    if mask.any() and not mask.all():
        axis.contour(mask, levels=[0.5], colors=color, linewidths=linewidth)
    if label is not None:
        axis.plot([], [], color=color, linewidth=linewidth, label=label)


def save_alignment_visualization(
    output_path: Path,
    image: np.ndarray,
    lobes: np.ndarray,
    case_id: str,
    checks: dict[str, Any],
) -> None:
    lung = lobes > 0
    axial_counts = lung.reshape(lung.shape[0], -1).sum(axis=1)
    axial = int(np.argmax(axial_counts))
    coronal_counts = lung.sum(axis=(0, 2))
    coronal = int(np.argmax(coronal_counts))
    colors = {
        1: "#00ffff",
        2: "#0066ff",
        3: "#ffff00",
        4: "#ff9900",
        5: "#ff0000",
    }
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), constrained_layout=True)
    low, high = np.percentile(image[lung], [1, 99])
    axes[0].imshow(image[axial], cmap="gray", vmin=low, vmax=high)
    for value, color in colors.items():
        contour_if_present(
            axes[0],
            lobes[axial] == value,
            color,
            1.0,
            LABEL_NAMES[value].replace("_", " "),
        )
    axes[0].set_title(f"Axial D={axial}: patient L/R mask check")
    axes[0].legend(loc="lower left", fontsize=7, framealpha=0.7)
    axes[0].axis("off")

    # D-by-W plane: superior is displayed upward and rightward W is patient right.
    plane = image[:, coronal, :]
    axes[1].imshow(plane, cmap="gray", vmin=low, vmax=high, origin="lower")
    for value, color in colors.items():
        contour_if_present(
            axes[1],
            lobes[:, coronal, :] == value,
            color,
            1.0,
            LABEL_NAMES[value].replace("_", " "),
        )
    axes[1].set_title(f"Coronal H={coronal}: upper/lower ordering")
    axes[1].axis("off")
    fig.suptitle(
        f"{case_id}\n"
        f"right W > left W: {checks['right_centroid_w']:.1f} > "
        f"{checks['left_centroid_w']:.1f}; "
        f"LUL D > LLL D: {checks['lul_centroid_d']:.1f} > "
        f"{checks['lll_centroid_d']:.1f}; "
        f"RUL D > RLL D: {checks['rul_centroid_d']:.1f} > "
        f"{checks['rll_centroid_d']:.1f}",
        fontsize=10,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def validate_anatomy_alignment(
    pairs_frame: pd.DataFrame,
    manifest: dict[str, dict[str, Any]],
    lobe_label_dir: Path,
    output_dir: Path,
) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    cases = sorted(pairs_frame["case_id"].unique())
    upper_cases = sorted(
        pairs_frame.loc[pairs_frame["swap_type"] == "upper_lower", "case_id"].unique()
    )
    screenshot_cases = upper_cases[:2]
    masks: dict[str, np.ndarray] = {}
    case_checks = []
    for case_id in cases:
        if case_id not in manifest:
            raise FileNotFoundError(f"{case_id}: no processed manifest entry")
        row = manifest[case_id]
        label_path = lobe_label_dir / str(row["split"]) / f"{case_stem(case_id)}.npz"
        if not label_path.is_file():
            raise FileNotFoundError(label_path)
        lobes = load_lobes(label_path)
        expected_shape = tuple(int(value) for value in row["preprocessed_shape"])
        if lobes.shape != expected_shape:
            raise RuntimeError(
                f"{case_id}: lobe shape {lobes.shape} != manifest {expected_shape}"
            )
        if case_id in screenshot_cases:
            # Compute all lobe centroids in one labeled-volume traversal. Whole-side
            # ordering is validated on a fixed 4x spatial subsample; the separation
            # is macroscopic and this avoids a multi-GB coordinate-grid allocation.
            stride = 4
            sampled_lobes = lobes[::stride, ::stride, ::stride]
            lobe_centroids = {
                value: tuple(
                    float(coordinate) * stride for coordinate in coordinates
                )
                for value, coordinates in zip(
                    range(1, 6),
                    ndimage.center_of_mass(
                        sampled_lobes > 0,
                        labels=sampled_lobes,
                        index=list(range(1, 6)),
                    ),
                )
            }
            lobe_counts = np.bincount(sampled_lobes.reshape(-1), minlength=6)

            def combined_centroid(
                values: tuple[int, ...],
            ) -> tuple[float, float, float]:
                total = int(sum(lobe_counts[value] for value in values))
                if total == 0:
                    raise RuntimeError(f"{case_id}: empty lobe union {values}")
                return tuple(
                    float(
                        sum(
                            lobe_centroids[value][axis] * lobe_counts[value]
                            for value in values
                        )
                        / total
                    )
                    for axis in range(3)
                )

            left_centroid = combined_centroid(ANATOMY_LABELS["left_lung"])
            right_centroid = combined_centroid(ANATOMY_LABELS["right_lung"])
            lul = lobe_centroids[1]
            lll = lobe_centroids[2]
            rul = lobe_centroids[3]
            rll = lobe_centroids[5]
            left_right_passed: bool | None = (
                right_centroid[2] > left_centroid[2]
            )
            left_upper_lower_passed: bool | None = lul[0] > lll[0]
            right_upper_lower_passed: bool | None = rul[0] > rll[0]
        else:
            left_centroid = right_centroid = (float("nan"),) * 3
            lul = lll = rul = rll = (float("nan"),) * 3
            left_right_passed = None
            left_upper_lower_passed = None
            right_upper_lower_passed = None
        checks = {
            "case_id": case_id,
            "shape": list(lobes.shape),
            "left_centroid_w": left_centroid[2],
            "right_centroid_w": right_centroid[2],
            "lul_centroid_d": lul[0],
            "lll_centroid_d": lll[0],
            "rul_centroid_d": rul[0],
            "rll_centroid_d": rll[0],
            "orientation_order_checked": case_id in screenshot_cases,
            "left_right_passed": left_right_passed,
            "left_upper_lower_passed": left_upper_lower_passed,
            "right_upper_lower_passed": right_upper_lower_passed,
            "complete_labels_passed": True,
            "label_path": str(label_path.resolve()),
        }
        checks["alignment_passed"] = bool(
            checks["complete_labels_passed"]
            and (
                not checks["orientation_order_checked"]
                or (
                    checks["left_right_passed"]
                    and checks["left_upper_lower_passed"]
                    and checks["right_upper_lower_passed"]
                )
            )
        )
        case_checks.append(checks)
        masks[case_id] = lobes
    if not all(item["alignment_passed"] for item in case_checks):
        failure = {"status": "failed", "case_checks": case_checks}
        write_json(output_dir / "mask_alignment_failure.json", failure)
        raise RuntimeError("Anatomy masks failed orientation/order validation")

    for case_id in screenshot_cases:
        row = manifest[case_id]
        with np.load(row["cache_path"], allow_pickle=False) as payload:
            image = payload["image"][0].astype(np.float32)
        checks = next(item for item in case_checks if item["case_id"] == case_id)
        save_alignment_visualization(
            output_dir
            / "validation_visualizations"
            / f"{case_stem(case_id)}__orientation_and_lobes.png",
            image,
            masks[case_id],
            case_id,
            checks,
        )
        del image
    validation = {
        "status": "passed",
        "cases_checked": len(case_checks),
        "left_right_cases_checked": len(screenshot_cases),
        "upper_lower_cases_checked": len(screenshot_cases),
        "screenshot_cases": screenshot_cases,
        "case_checks": case_checks,
        "abort_on_failure": True,
    }
    write_json(output_dir / "validation_visualizations" / "validation.json", validation)
    return validation, masks


def region_masks(
    lobes: np.ndarray, original_anatomy: str, swapped_anatomy: str
) -> dict[str, np.ndarray]:
    original = np.isin(lobes, ANATOMY_LABELS[original_anatomy])
    swapped = np.isin(lobes, ANATOMY_LABELS[swapped_anatomy])
    lungs = lobes > 0
    other_lung = lungs & ~original & ~swapped
    outside_lungs = ~lungs
    if np.logical_and(original, swapped).any():
        raise RuntimeError(f"Anatomy masks overlap: {original_anatomy}/{swapped_anatomy}")
    return {
        "original": original,
        "swapped": swapped,
        "other_lung": other_lung,
        "outside_lungs": outside_lungs,
        "lungs": lungs,
    }


def probability_fraction(probability: np.ndarray, mask: np.ndarray) -> float:
    return float(probability[mask].sum(dtype=np.float64)) / (
        float(probability.sum(dtype=np.float64)) + EPS
    )


def foreground_region_fractions(
    foreground: np.ndarray, regions: dict[str, np.ndarray]
) -> dict[str, float | int]:
    total = int(foreground.sum())
    answer: dict[str, float | int] = {"total_voxels": total}
    for key in ("original", "swapped", "other_lung", "outside_lungs"):
        count = int(np.logical_and(foreground, regions[key]).sum())
        answer[f"{key}_voxels"] = count
        answer[f"{key}_fraction"] = count / (total + EPS)
    return answer


def largest_component_destination(
    foreground: np.ndarray, regions: dict[str, np.ndarray]
) -> tuple[str, int, dict[str, int]]:
    labels, count = ndimage.label(foreground, structure=CONNECTIVITY)
    if count == 0:
        return "empty", 0, {
            "original_anatomy": 0,
            "swapped_anatomy": 0,
            "other_lung_region": 0,
            "outside_lung": 0,
        }
    sizes = np.bincount(labels.reshape(-1))
    sizes[0] = 0
    component_id = int(np.argmax(sizes))
    component = labels == component_id
    overlaps = {
        "original_anatomy": int(np.logical_and(component, regions["original"]).sum()),
        "swapped_anatomy": int(np.logical_and(component, regions["swapped"]).sum()),
        "other_lung_region": int(
            np.logical_and(component, regions["other_lung"]).sum()
        ),
        "outside_lung": int(
            np.logical_and(component, regions["outside_lungs"]).sum()
        ),
    }
    priority = {
        "swapped_anatomy": 3,
        "original_anatomy": 2,
        "other_lung_region": 1,
        "outside_lung": 0,
    }
    destination = max(overlaps, key=lambda key: (overlaps[key], priority[key]))
    return destination, int(sizes[component_id]), overlaps


def dice(prediction: np.ndarray, target: np.ndarray) -> float:
    denominator = int(prediction.sum()) + int(target.sum())
    if denominator == 0:
        return 1.0
    return float(2 * np.logical_and(prediction, target).sum() / denominator)


def classification(row: dict[str, Any] | pd.Series, tau: float) -> str:
    loss = float(row["original_target_loss"])
    gain = float(row["swap_target_gain"])
    outside = float(row["outside_lung_fraction_change"])
    other = float(row["other_lung_region_fraction_change"])
    off_target = float(row["off_target_change"])
    little = (
        abs(loss) <= tau
        and abs(gain) <= tau
        and abs(outside) <= tau
        and abs(other) <= tau
    )
    if bool(row["swapped_near_empty_prediction"]):
        if loss > tau:
            return "suppression"
        if little:
            return "little_change"
        return "off_target_change"
    largest_moved_off_target = (
        str(row["correct_largest_component_destination"]) == "original_anatomy"
        and str(row["swapped_largest_component_destination"])
        in {"other_lung_region", "outside_lung"}
    )
    meaningful_binary_off_target_gain = (
        float(row["binary_off_target_fraction_gain"]) > tau
        and str(row["swapped_largest_component_destination"])
        in {"other_lung_region", "outside_lung"}
    )
    if off_target > tau or largest_moved_off_target or meaningful_binary_off_target_gain:
        return "off_target_change"
    if loss > tau and gain > tau and outside <= tau and other <= tau:
        return "directional_transfer"
    if loss > tau and gain <= tau:
        return "suppression"
    if little:
        return "little_change"
    # The requested four classes are exhaustive. Residual mixed changes that do
    # not meet the positive transfer/suppression/little-change rules are off-target.
    return "off_target_change"


def save_pair_slice_payload(
    path: Path,
    ct: np.ndarray,
    gt: np.ndarray,
    lobes: np.ndarray,
    correct_probability: np.ndarray,
    swapped_probability: np.ndarray,
    threshold: float,
) -> int:
    correct_foreground = correct_probability >= threshold
    swapped_foreground = swapped_probability >= threshold
    def normalized_slice_score(volume: np.ndarray) -> np.ndarray:
        score = volume.reshape(volume.shape[0], -1).sum(axis=1, dtype=np.float64)
        maximum = float(score.max())
        return score / maximum if maximum > 0 else np.zeros_like(score)

    score = (
        normalized_slice_score(gt)
        + normalized_slice_score(correct_foreground)
        + normalized_slice_score(swapped_foreground)
    )
    if not np.any(score):
        score = normalized_slice_score(correct_probability + swapped_probability)
    z = int(np.argmax(score))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as handle:
        np.savez_compressed(
            handle,
            ct=ct[z].astype(np.float32),
            gt=gt[z].astype(np.uint8),
            lobes=lobes[z].astype(np.uint8),
            correct_probability=correct_probability[z].astype(np.float32),
            swapped_probability=swapped_probability[z].astype(np.float32),
            z=np.asarray(z, dtype=np.int32),
        )
    return z


def pair_metrics(
    pair: dict[str, Any],
    anatomy: pd.Series,
    lobes: np.ndarray,
    correct_logits: np.ndarray,
    swapped_logits: np.ndarray,
    target: np.ndarray,
    ct: np.ndarray,
    threshold: float,
    near_empty_voxels: int,
    payload_path: Path,
) -> dict[str, Any]:
    correct_probability = expit(correct_logits.astype(np.float32, copy=False))
    swapped_probability = expit(swapped_logits.astype(np.float32, copy=False))
    correct_foreground = correct_probability >= threshold
    swapped_foreground = swapped_probability >= threshold
    regions = region_masks(
        lobes, str(anatomy["original_anatomy"]), str(anatomy["swapped_anatomy"])
    )
    correct_fraction = {
        key: probability_fraction(correct_probability, mask)
        for key, mask in regions.items()
        if key != "lungs"
    }
    swapped_fraction = {
        key: probability_fraction(swapped_probability, mask)
        for key, mask in regions.items()
        if key != "lungs"
    }
    original_target_loss = (
        correct_fraction["original"] - swapped_fraction["original"]
    )
    swap_target_gain = swapped_fraction["swapped"] - correct_fraction["swapped"]
    outside_change = (
        swapped_fraction["outside_lungs"] - correct_fraction["outside_lungs"]
    )
    other_change = (
        swapped_fraction["other_lung"] - correct_fraction["other_lung"]
        if str(pair["swap_type"]) == "upper_lower"
        else 0.0
    )
    off_target_change = (
        outside_change
        if str(pair["swap_type"]) == "laterality"
        else max(outside_change, other_change)
    )
    correct_binary = foreground_region_fractions(correct_foreground, regions)
    swapped_binary = foreground_region_fractions(swapped_foreground, regions)
    correct_destination, correct_largest_size, correct_overlaps = (
        largest_component_destination(correct_foreground, regions)
    )
    swapped_destination, swapped_largest_size, swapped_overlaps = (
        largest_component_destination(swapped_foreground, regions)
    )
    binary_swap_gain = float(
        swapped_binary["swapped_fraction"] - correct_binary["swapped_fraction"]
    )
    binary_outside_gain = float(
        swapped_binary["outside_lungs_fraction"]
        - correct_binary["outside_lungs_fraction"]
    )
    binary_other_gain = float(
        swapped_binary["other_lung_fraction"]
        - correct_binary["other_lung_fraction"]
    )
    binary_off_target_gain = (
        binary_outside_gain
        if str(pair["swap_type"]) == "laterality"
        else max(binary_outside_gain, binary_other_gain)
    )
    overall_mass_change = float(
        np.abs(swapped_probability - correct_probability).sum(dtype=np.float64)
        / (
            correct_probability.sum(dtype=np.float64)
            + swapped_probability.sum(dtype=np.float64)
            + EPS
        )
    )
    target = target.astype(bool, copy=False)
    display_slice = save_pair_slice_payload(
        payload_path,
        ct,
        target,
        lobes,
        correct_probability,
        swapped_probability,
        threshold,
    )
    row: dict[str, Any] = {
        **{key: anatomy[key] for key in anatomy.index},
        "pair_id": str(pair["pair_id"]),
        "correct_total_probability_mass": float(
            correct_probability.sum(dtype=np.float64)
        ),
        "swapped_total_probability_mass": float(
            swapped_probability.sum(dtype=np.float64)
        ),
        "correct_original_target_fraction": correct_fraction["original"],
        "swapped_original_target_fraction": swapped_fraction["original"],
        "correct_swap_target_fraction": correct_fraction["swapped"],
        "swapped_swap_target_fraction": swapped_fraction["swapped"],
        "correct_outside_lung_fraction": correct_fraction["outside_lungs"],
        "swapped_outside_lung_fraction": swapped_fraction["outside_lungs"],
        "correct_other_lung_region_fraction": correct_fraction["other_lung"],
        "swapped_other_lung_region_fraction": swapped_fraction["other_lung"],
        "original_target_loss": original_target_loss,
        "swap_target_gain": swap_target_gain,
        "directional_transfer_score": original_target_loss + swap_target_gain,
        "outside_lung_fraction_change": outside_change,
        "other_lung_region_fraction_change": other_change,
        "off_target_change": off_target_change,
        "binary_swap_target_fraction_change": binary_swap_gain,
        "binary_outside_lung_fraction_change": binary_outside_gain,
        "binary_other_lung_region_fraction_change": binary_other_gain,
        "binary_off_target_fraction_gain": binary_off_target_gain,
        "overall_probability_mass_change": overall_mass_change,
        "correct_largest_component_destination": correct_destination,
        "swapped_largest_component_destination": swapped_destination,
        "correct_largest_component_voxels": correct_largest_size,
        "swapped_largest_component_voxels": swapped_largest_size,
        "correct_largest_component_region_overlaps": json.dumps(correct_overlaps),
        "swapped_largest_component_region_overlaps": json.dumps(swapped_overlaps),
        "correct_binary_foreground_voxels": int(correct_binary["total_voxels"]),
        "swapped_binary_foreground_voxels": int(swapped_binary["total_voxels"]),
        "correct_binary_original_anatomy_voxels": int(
            correct_binary["original_voxels"]
        ),
        "correct_binary_original_anatomy_fraction": float(
            correct_binary["original_fraction"]
        ),
        "correct_binary_swapped_anatomy_voxels": int(
            correct_binary["swapped_voxels"]
        ),
        "correct_binary_swapped_anatomy_fraction": float(
            correct_binary["swapped_fraction"]
        ),
        "correct_binary_other_lung_voxels": int(
            correct_binary["other_lung_voxels"]
        ),
        "correct_binary_other_lung_fraction": float(
            correct_binary["other_lung_fraction"]
        ),
        "correct_binary_outside_lung_voxels": int(
            correct_binary["outside_lungs_voxels"]
        ),
        "correct_binary_outside_lung_fraction": float(
            correct_binary["outside_lungs_fraction"]
        ),
        "swapped_binary_original_anatomy_voxels": int(
            swapped_binary["original_voxels"]
        ),
        "swapped_binary_original_anatomy_fraction": float(
            swapped_binary["original_fraction"]
        ),
        "swapped_binary_swapped_anatomy_voxels": int(
            swapped_binary["swapped_voxels"]
        ),
        "swapped_binary_swapped_anatomy_fraction": float(
            swapped_binary["swapped_fraction"]
        ),
        "swapped_binary_other_lung_voxels": int(
            swapped_binary["other_lung_voxels"]
        ),
        "swapped_binary_other_lung_fraction": float(
            swapped_binary["other_lung_fraction"]
        ),
        "swapped_binary_outside_lung_voxels": int(
            swapped_binary["outside_lungs_voxels"]
        ),
        "swapped_binary_outside_lung_fraction": float(
            swapped_binary["outside_lungs_fraction"]
        ),
        "correct_empty_prediction": int(correct_binary["total_voxels"]) == 0,
        "swapped_empty_prediction": int(swapped_binary["total_voxels"]) == 0,
        "any_empty_prediction": (
            int(correct_binary["total_voxels"]) == 0
            or int(swapped_binary["total_voxels"]) == 0
        ),
        "correct_near_empty_prediction": int(correct_binary["total_voxels"])
        <= near_empty_voxels,
        "swapped_near_empty_prediction": int(swapped_binary["total_voxels"])
        <= near_empty_voxels,
        "any_near_empty_prediction": (
            int(correct_binary["total_voxels"]) <= near_empty_voxels
            or int(swapped_binary["total_voxels"]) <= near_empty_voxels
        ),
        "correct_dice": dice(correct_foreground, target),
        "swapped_dice": dice(swapped_foreground, target),
        "correct_gt_probability_mass_fraction": probability_fraction(
            correct_probability, target
        ),
        "swapped_gt_probability_mass_fraction": probability_fraction(
            swapped_probability, target
        ),
        "correct_gt_probability_mass_sum": float(
            correct_probability[target].sum(dtype=np.float64)
        ),
        "swapped_gt_probability_mass_sum": float(
            swapped_probability[target].sum(dtype=np.float64)
        ),
        "gt_voxels": int(target.sum()),
        "mean_absolute_logit_difference": float(
            np.abs(correct_logits.astype(np.float32) - swapped_logits.astype(np.float32))
            .mean()
        ),
        "display_slice_d": display_slice,
    }
    for tau in TAUS:
        row[f"classification_tau_{str(tau).replace('.', 'p')}"] = classification(
            row, tau
        )
    row["category_tau_0p05"] = row["classification_tau_0p05"]
    return row


def mask_provenance(
    pairs_frame: pd.DataFrame,
    masks: dict[str, np.ndarray],
    manifest: dict[str, dict[str, Any]],
    prior_root: Path,
    lobe_label_dir: Path,
) -> pd.DataFrame:
    rows = []
    label_counts_by_case = {
        case_id: np.bincount(lobes.reshape(-1), minlength=6)
        for case_id, lobes in masks.items()
    }
    for _, pair in pairs_frame.iterrows():
        case_id = str(pair["case_id"])
        lobes = masks[case_id]
        label_counts = label_counts_by_case[case_id]
        original_values = ANATOMY_LABELS[str(pair["original_anatomy"])]
        swapped_values = ANATOMY_LABELS[str(pair["swapped_anatomy"])]
        original_voxels = int(sum(label_counts[value] for value in original_values))
        swapped_voxels = int(sum(label_counts[value] for value in swapped_values))
        lung_voxels = int(label_counts[1:6].sum())
        other_lung_voxels = lung_voxels - original_voxels - swapped_voxels
        manifest_row = manifest[case_id]
        rows.append(
            {
                "case_id": case_id,
                "finding_id": int(pair["finding_id"]),
                "pair_id": pair["pair_id"],
                "swap_type": pair["swap_type"],
                "anatomy_mask_source": (
                    "TotalSegmentator five-lobe masks from "
                    + str(
                        (
                            prior_root / case_stem(case_id) / "totalseg"
                        ).resolve()
                    )
                ),
                "aligned_label_path": str(
                    (
                        lobe_label_dir
                        / str(manifest_row["split"])
                        / f"{case_stem(case_id)}.npz"
                    ).resolve()
                ),
                "geometry_operation": (
                    "Reuse prepare_rex_lobe_label_maps.py: "
                    "nibabel as_reoriented(io_orientation(original_affine)); "
                    "XYZ->DHW transpose; exact manifest/P0 crop_bbox; nearest/discrete "
                    "mask handling; no additional resampling in this audit"
                ),
                "crop_bbox": json.dumps(manifest_row["crop_bbox"]),
                "final_shape": "x".join(map(str, lobes.shape)),
                "original_anatomy": pair["original_anatomy"],
                "swapped_anatomy": pair["swapped_anatomy"],
                "original_anatomy_voxels": original_voxels,
                "swapped_anatomy_voxels": swapped_voxels,
                "other_lung_region_voxels": other_lung_voxels,
                "outside_lung_voxels": int(label_counts[0]),
                "whole_lung_voxels": lung_voxels,
                "alignment_validation_passed": True,
            }
        )
    return pd.DataFrame(rows)


def reproduce_p0_validation(
    frame: pd.DataFrame, p0_metrics_path: Path
) -> tuple[pd.DataFrame, dict[str, Any]]:
    dice_tolerance = 1e-3
    mean_logit_difference_tolerance = 2e-3
    volume_relative_tolerance = 5e-4
    volume_minimum_absolute_tolerance = 10
    previous = pd.read_csv(p0_metrics_path)
    expected = previous.set_index("pair_id")
    rows = []
    for _, current in frame.iterrows():
        pair_id = str(current["pair_id"])
        if pair_id not in expected.index:
            raise RuntimeError(f"{pair_id}: missing from P0 per-pair metrics")
        old = expected.loc[pair_id]
        correct_volume_difference = abs(
            int(current["correct_binary_foreground_voxels"])
            - int(old["correct_predicted_foreground_voxels"])
        )
        swapped_volume_difference = abs(
            int(current["swapped_binary_foreground_voxels"])
            - int(old["swapped_predicted_foreground_voxels"])
        )
        correct_volume_tolerance = max(
            volume_minimum_absolute_tolerance,
            int(
                math.ceil(
                    volume_relative_tolerance
                    * max(int(old["correct_predicted_foreground_voxels"]), 1)
                )
            ),
        )
        swapped_volume_tolerance = max(
            volume_minimum_absolute_tolerance,
            int(
                math.ceil(
                    volume_relative_tolerance
                    * max(int(old["swapped_predicted_foreground_voxels"]), 1)
                )
            ),
        )
        volume_pass = (
            correct_volume_difference <= correct_volume_tolerance
            and swapped_volume_difference <= swapped_volume_tolerance
        )
        dice_difference = max(
            abs(float(current["correct_dice"]) - float(old["correct_dice"])),
            abs(float(current["swapped_dice"]) - float(old["swapped_dice"])),
        )
        logit_mad_difference = abs(
            float(current["mean_absolute_logit_difference"])
            - float(old["mean_absolute_logit_difference"])
        )
        rows.append(
            {
                "pair_id": pair_id,
                "correct_foreground_volume_abs_difference": correct_volume_difference,
                "swapped_foreground_volume_abs_difference": swapped_volume_difference,
                "correct_foreground_volume_tolerance": correct_volume_tolerance,
                "swapped_foreground_volume_tolerance": swapped_volume_tolerance,
                "foreground_volumes_within_tolerance": volume_pass,
                "max_abs_dice_difference": dice_difference,
                "abs_mean_logit_difference_difference": logit_mad_difference,
                "dice_tolerance": dice_tolerance,
                "mean_logit_difference_tolerance": (
                    mean_logit_difference_tolerance
                ),
                "passed": volume_pass
                and dice_difference <= dice_tolerance
                and logit_mad_difference <= mean_logit_difference_tolerance,
            }
        )
    validation = pd.DataFrame(rows)
    summary = {
        "pairs_checked": len(validation),
        "pairs_passed": int(validation["passed"].sum()),
        "all_passed": bool(validation["passed"].all()),
        "checked_fields": list(P0_REPRODUCTION_COLUMNS),
        "volume_tolerance": (
            "max(10 voxels, ceil(0.0005 * P0 foreground voxels)) per prompt"
        ),
        "volume_relative_tolerance": volume_relative_tolerance,
        "volume_minimum_absolute_tolerance": volume_minimum_absolute_tolerance,
        "dice_tolerance": dice_tolerance,
        "mean_logit_difference_tolerance": mean_logit_difference_tolerance,
        "max_observed_correct_foreground_volume_abs_difference": int(
            validation["correct_foreground_volume_abs_difference"].max()
        ),
        "max_observed_swapped_foreground_volume_abs_difference": int(
            validation["swapped_foreground_volume_abs_difference"].max()
        ),
        "max_observed_dice_difference": float(
            validation["max_abs_dice_difference"].max()
        ),
        "max_observed_mean_logit_difference_difference": float(
            validation["abs_mean_logit_difference_difference"].max()
        ),
    }
    return validation, summary


CORE_NUMERIC_METRICS = (
    "original_target_loss",
    "swap_target_gain",
    "directional_transfer_score",
    "off_target_change",
    "binary_swap_target_fraction_change",
)
SECONDARY_METRICS = (
    "outside_lung_fraction_change",
    "other_lung_region_fraction_change",
    "correct_dice",
    "swapped_dice",
    "correct_gt_probability_mass_fraction",
    "swapped_gt_probability_mass_fraction",
)


def descriptive(values: Iterable[float]) -> dict[str, float | int | None]:
    array = np.asarray(list(values), dtype=np.float64)
    array = array[np.isfinite(array)]
    if array.size == 0:
        return {
            "n": 0,
            "mean": None,
            "median": None,
            "standard_deviation": None,
            "interquartile_range": None,
            "minimum": None,
            "maximum": None,
        }
    q1, q3 = np.percentile(array, [25, 75])
    return {
        "n": int(array.size),
        "mean": float(array.mean()),
        "median": float(np.median(array)),
        "standard_deviation": float(array.std(ddof=1)) if array.size > 1 else 0.0,
        "interquartile_range": float(q3 - q1),
        "minimum": float(array.min()),
        "maximum": float(array.max()),
    }


def count_percent(series: pd.Series) -> dict[str, dict[str, float | int]]:
    counts = series.value_counts().to_dict()
    total = len(series)
    return {
        category: {
            "count": int(counts.get(category, 0)),
            "percentage": 100.0 * int(counts.get(category, 0)) / total
            if total
            else 0.0,
        }
        for category in (
            "directional_transfer",
            "suppression",
            "off_target_change",
            "little_change",
        )
    }


def aggregate_results(frame: pd.DataFrame) -> dict[str, Any]:
    groups = {
        "all_16_pairs": frame,
        "laterality_12_pairs": frame.loc[frame["swap_type"] == "laterality"],
        "upper_lower_4_pairs": frame.loc[frame["swap_type"] == "upper_lower"],
    }
    result: dict[str, Any] = {
        "definitions": {
            "sample_standard_deviation_ddof": 1,
            "off_target_change_laterality": "outside_lung_fraction_change",
            "off_target_change_upper_lower": (
                "max(outside_lung_fraction_change, "
                "other_lung_region_fraction_change)"
            ),
            "fifth_numeric_core_metric": "binary_swap_target_fraction_change",
            "classification_primary_tau": PRIMARY_TAU,
            "classification_sensitivity_taus": list(TAUS),
        },
        "groups": {},
    }
    for group_name, group in groups.items():
        statistics = {
            metric: descriptive(group[metric])
            for metric in (*CORE_NUMERIC_METRICS, *SECONDARY_METRICS)
        }
        classifications = {}
        for tau in TAUS:
            column = f"classification_tau_{str(tau).replace('.', 'p')}"
            classifications[str(tau)] = count_percent(group[column])
        result["groups"][group_name] = {
            "n": len(group),
            "statistics": statistics,
            "classifications": classifications,
            "empty_predictions": {
                "any_output_empty": int(group["any_empty_prediction"].sum()),
                "correct_prompt_empty": int(
                    group["correct_empty_prediction"].sum()
                ),
                "swapped_prompt_empty": int(
                    group["swapped_empty_prediction"].sum()
                ),
                "any_output_near_empty_le_10_voxels": int(
                    group["any_near_empty_prediction"].sum()
                ),
            },
            "largest_component_destinations": {
                "correct_prompt": {
                    str(key): int(value)
                    for key, value in group[
                        "correct_largest_component_destination"
                    ]
                    .value_counts()
                    .items()
                },
                "swapped_prompt": {
                    str(key): int(value)
                    for key, value in group[
                        "swapped_largest_component_destination"
                    ]
                    .value_counts()
                    .items()
                },
            },
        }
    result["limitations"] = [
        "Findings from the same CT are not independent.",
        "The four upper/lower pairs are descriptive only.",
    ]
    return result


CATEGORY_COLORS = {
    "directional_transfer": "#2ca02c",
    "suppression": "#1f77b4",
    "off_target_change": "#d62728",
    "little_change": "#7f7f7f",
}


def make_summary_plot(frame: pd.DataFrame, output_path: Path) -> None:
    plot_frame = frame.sort_values(
        ["swap_type", "pair_id"], kind="stable"
    ).reset_index(drop=True)
    y = np.arange(len(plot_frame))
    fig, axes = plt.subplots(1, 3, figsize=(16, 8), sharey=True, constrained_layout=True)
    fields = (
        ("original_target_loss", "Original-target loss"),
        ("swap_target_gain", "Swap-target gain"),
        ("off_target_change", "Off-target change"),
    )
    colors = [
        CATEGORY_COLORS[str(category)] for category in plot_frame["category_tau_0p05"]
    ]
    for axis, (field, title) in zip(axes, fields):
        axis.barh(y, plot_frame[field], color=colors, alpha=0.88)
        axis.axvline(0, color="black", linewidth=0.7)
        axis.axvline(PRIMARY_TAU, color="black", linewidth=0.7, linestyle="--")
        axis.axvline(-PRIMARY_TAU, color="black", linewidth=0.7, linestyle=":")
        axis.set_title(title)
        axis.grid(axis="x", alpha=0.2)
    labels = [
        f"{row.pair_id} [{row.swap_type}]"
        for row in plot_frame.itertuples(index=False)
    ]
    axes[0].set_yticks(y, labels, fontsize=7)
    axes[0].invert_yaxis()
    handles = [
        Patch(facecolor=color, label=category.replace("_", " "))
        for category, color in CATEGORY_COLORS.items()
    ]
    axes[2].legend(handles=handles, loc="lower right", fontsize=8)
    fig.suptitle("P0-B directional anatomy audit (primary τ=0.05)")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=170)
    plt.close(fig)


def representative_selections(frame: pd.DataFrame) -> list[dict[str, str]]:
    selections: list[tuple[str, pd.DataFrame, str, bool]] = [
        (
            "01_largest_swap_target_gain",
            frame,
            "swap_target_gain",
            False,
        ),
        (
            "02_largest_loss_little_no_gain",
            frame.loc[frame["swap_target_gain"] <= PRIMARY_TAU],
            "original_target_loss",
            False,
        ),
        (
            "03_largest_off_target_increase",
            frame,
            "off_target_change",
            False,
        ),
        (
            "04_smallest_overall_mass_change",
            frame,
            "overall_probability_mass_change",
            True,
        ),
    ]
    selected: list[dict[str, str]] = []
    used: set[str] = set()
    for rule, candidates, field, ascending in selections:
        if candidates.empty:
            candidates = frame
        ranked = candidates.sort_values(
            [field, "pair_id"],
            ascending=[ascending, True],
            kind="stable",
        )
        available = ranked.loc[~ranked["pair_id"].isin(used)]
        chosen = (available if not available.empty else ranked).iloc[0]
        pair_id = str(chosen["pair_id"])
        used.add(pair_id)
        selected.append(
            {
                "rule": rule,
                "pair_id": pair_id,
                "ranking_field": field,
                "ranking_value": float(chosen[field]),
                "unique_pair_preferred": True,
            }
        )
    return selected


def make_representative_visualization(
    row: pd.Series,
    payload_path: Path,
    output_path: Path,
    selection_rule: str,
) -> None:
    with np.load(payload_path, allow_pickle=False) as payload:
        values = {key: payload[key].copy() for key in payload.files}
    ct = values["ct"]
    gt = values["gt"].astype(bool)
    lobes = values["lobes"]
    original = np.isin(lobes, ANATOMY_LABELS[str(row["original_anatomy"])])
    swapped = np.isin(lobes, ANATOMY_LABELS[str(row["swapped_anatomy"])])
    low, high = np.percentile(ct, [1, 99])
    probability_high = max(
        0.05,
        float(
            np.percentile(
                np.concatenate(
                    [
                        values["correct_probability"].reshape(-1),
                        values["swapped_probability"].reshape(-1),
                    ]
                ),
                99.8,
            )
        ),
    )
    fig = plt.figure(figsize=(17, 9), constrained_layout=True)
    grid = fig.add_gridspec(2, 3)
    axes = [fig.add_subplot(grid[row_index, column]) for row_index in range(2) for column in range(3)]
    axes[0].imshow(ct, cmap="gray", vmin=low, vmax=high)
    contour_if_present(axes[0], gt, "lime", 1.3, "GT")
    contour_if_present(axes[0], original, "cyan", 1.1, "original anatomy")
    contour_if_present(axes[0], swapped, "yellow", 1.1, "swapped anatomy")
    axes[0].legend(loc="lower left", fontsize=8)
    axes[0].set_title(f"CT + boundaries; D={int(values['z'])}")
    image = None
    for axis, key, title in (
        (axes[1], "correct_probability", "Correct-prompt probability"),
        (axes[2], "swapped_probability", "Swapped-prompt probability"),
    ):
        image = axis.imshow(
            values[key], cmap="magma", vmin=0, vmax=probability_high
        )
        contour_if_present(axis, gt, "lime", 1.0)
        contour_if_present(axis, original, "cyan", 0.9)
        contour_if_present(axis, swapped, "yellow", 0.9)
        axis.set_title(title)
    assert image is not None
    fig.colorbar(image, ax=axes[1:3], shrink=0.8, label="probability (shared scale)")
    axes[3].imshow(
        values["correct_probability"] >= 0.5,
        cmap="Blues",
        vmin=0,
        vmax=1,
    )
    contour_if_present(axes[3], original, "cyan", 1.0)
    contour_if_present(axes[3], swapped, "yellow", 1.0)
    axes[3].set_title(
        "Correct binary; largest → "
        + str(row["correct_largest_component_destination"]).replace("_", " ")
    )
    axes[4].imshow(
        values["swapped_probability"] >= 0.5,
        cmap="Reds",
        vmin=0,
        vmax=1,
    )
    contour_if_present(axes[4], original, "cyan", 1.0)
    contour_if_present(axes[4], swapped, "yellow", 1.0)
    axes[4].set_title(
        "Swapped binary; largest → "
        + str(row["swapped_largest_component_destination"]).replace("_", " ")
    )
    axes[5].axis("off")
    axes[5].text(
        0,
        1,
        "Original:\n"
        + str(row["original_prompt"])
        + "\n\nSwapped:\n"
        + str(row["swapped_prompt"])
        + "\n\n"
        + f"original-target loss: {row['original_target_loss']:+.4f}\n"
        + f"swap-target gain: {row['swap_target_gain']:+.4f}\n"
        + f"directional transfer score: {row['directional_transfer_score']:+.4f}\n"
        + f"off-target change: {row['off_target_change']:+.4f}\n"
        + f"  outside lung: {row['outside_lung_fraction_change']:+.4f}\n"
        + f"  other lung: {row['other_lung_region_fraction_change']:+.4f}\n"
        + f"binary swap-target Δ: {row['binary_swap_target_fraction_change']:+.4f}\n"
        + f"category (τ=.05): {row['category_tau_0p05']}",
        ha="left",
        va="top",
        wrap=True,
        fontsize=9,
    )
    for axis in axes[:5]:
        axis.axis("off")
    fig.suptitle(
        f"{selection_rule}: {row['pair_id']} ({row['swap_type']})",
        fontsize=12,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=165)
    plt.close(fig)


def fmt(value: float) -> str:
    return f"{float(value):+.4f}"


def category_summary(frame: pd.DataFrame, swap_type: str | None = None) -> str:
    group = frame if swap_type is None else frame.loc[frame["swap_type"] == swap_type]
    counts = group["category_tau_0p05"].value_counts()
    return ", ".join(
        f"{category.replace('_', ' ')} {int(counts.get(category, 0))}/{len(group)}"
        for category in (
            "directional_transfer",
            "suppression",
            "off_target_change",
            "little_change",
        )
    )


def choose_conclusion(frame: pd.DataFrame) -> tuple[str, str]:
    counts = frame["category_tau_0p05"].value_counts()
    total = len(frame)
    transfer = int(counts.get("directional_transfer", 0))
    suppression = int(counts.get("suppression", 0))
    off_target = int(counts.get("off_target_change", 0))
    if transfer > total / 2:
        return (
            "A. Directional location grounding is reliable",
            "Do not modify Qwen; focus on instance selection, morphology/size "
            "grounding, and false-positive suppression.",
        )
    if suppression > total / 2:
        return (
            "B. Location swaps mainly suppress the original prediction",
            "Test anatomy-direction supervision that explicitly rewards response "
            "inside the target anatomy.",
        )
    if off_target > total / 2:
        return (
            "C. Output changes are mainly off-target",
            "Test anatomy-aware region-level alignment/consistency loss and "
            "false-positive penalties.",
        )
    return (
        "D. Mixed or inconclusive behavior",
        "Use the dominant laterality versus upper/lower failure mode to select a "
        "small anatomy-supervision pilot; do not add Prompt Composer or Qwen LoRA.",
    )


def write_report(
    output_path: Path,
    config: dict[str, Any],
    validation: dict[str, Any],
    frame: pd.DataFrame,
    aggregate: dict[str, Any],
    conclusion: tuple[str, str],
) -> None:
    all_stats = aggregate["groups"]["all_16_pairs"]["statistics"]
    laterality = frame.loc[frame["swap_type"] == "laterality"]
    upper = frame.loc[frame["swap_type"] == "upper_lower"]
    lines = [
        "# P0-B Lite Location-Swap Anatomy-Direction Audit",
        "",
        "## 1. Execution summary",
        "",
        f"- Source P0 folder: `{config['source_p0_folder']}`.",
        f"- Checkpoint: `{config['checkpoint']}`.",
        f"- Fixed30 manifest: `{config['fixed30_manifest']}`.",
        f"- GPU: {config['gpu']}.",
        f"- Runtime: {config['runtime_seconds'] / 60:.2f} minutes.",
        f"- Slurm job: {config.get('slurm_job_id') or 'not run under Slurm'}.",
        "- Saved P0 dense prediction maps were unavailable; inference was rerun "
        f"for {config['unique_prompt_inferences']} unique case/prompt combinations.",
        f"- Analyzed pairs: {len(frame)}/16.",
        "- Inference only: no optimizer, backward pass, training loop, or parameter "
        "update; Qwen and VoxTell parameter digests were unchanged and no gradients "
        "were created.",
        f"- P0 reproduction check: {config['p0_reproduction']['pairs_passed']}/"
        f"{config['p0_reproduction']['pairs_checked']} pairs passed.",
        "",
        "## 2. Mask validation",
        "",
        "- Mask source: existing five-lobe TotalSegmentator masks aligned by "
        "`prepare_rex_lobe_label_maps.py`.",
        "- Geometry: source masks were reoriented with the CT affine, transposed "
        "XYZ→DHW, and cropped with the exact P0/manifest crop; discrete labels were "
        "not resampled again by this audit.",
        f"- Exact shape/label validation passed for {validation['cases_checked']} "
        "cases.",
        f"- Left/right centroid ordering and upper/lower centroid ordering passed "
        f"on {len(validation['screenshot_cases'])} prespecified cases; screenshots "
        "were saved before inference. Exact shape and complete-label checks passed "
        "for every case.",
        "- Excluded pairs: 0.",
        "",
        "## 3. Laterality results",
        "",
        f"- Primary classifications: {category_summary(frame, 'laterality')}.",
        f"- Mean/median original-target loss: "
        f"{fmt(laterality['original_target_loss'].mean())}/"
        f"{fmt(laterality['original_target_loss'].median())}.",
        f"- Mean/median contralateral swap-target gain: "
        f"{fmt(laterality['swap_target_gain'].mean())}/"
        f"{fmt(laterality['swap_target_gain'].median())}.",
        f"- Swapped largest component entered the contralateral intended lung in "
        f"{int((laterality['swapped_largest_component_destination'] == 'swapped_anatomy').sum())}/"
        f"{len(laterality)} pairs.",
        "",
        "## 4. Upper/lower results",
        "",
        "Only four pairs are available; these results are descriptive.",
        "",
        "| Pair | Loss | Gain | Outside-lung Δ | Other-lung Δ | Category |",
        "|---|---:|---:|---:|---:|---|",
    ]
    for _, row in upper.iterrows():
        lines.append(
            f"| `{row['pair_id']}` | {fmt(row['original_target_loss'])} | "
            f"{fmt(row['swap_target_gain'])} | "
            f"{fmt(row['outside_lung_fraction_change'])} | "
            f"{fmt(row['other_lung_region_fraction_change'])} | "
            f"{str(row['category_tau_0p05']).replace('_', ' ')} |"
        )
    lines.extend(
        [
            "",
            f"Primary classifications: {category_summary(frame, 'upper_lower')}.",
            "",
            "## 5. Transfer versus suppression",
            "",
            f"- Across all pairs, mean/median original-target loss was "
            f"{fmt(all_stats['original_target_loss']['mean'])}/"
            f"{fmt(all_stats['original_target_loss']['median'])}; mean/median "
            f"swap-target gain was {fmt(all_stats['swap_target_gain']['mean'])}/"
            f"{fmt(all_stats['swap_target_gain']['median'])}.",
            f"- Under τ=0.05, {int((frame['category_tau_0p05'] == 'directional_transfer').sum())}/"
            f"16 pairs showed directional transfer and "
            f"{int((frame['category_tau_0p05'] == 'suppression').sum())}/16 "
            "showed suppression.",
            "- Transfer requires both loss from the original anatomy and gain in "
            "the swapped anatomy; loss alone is not counted as transfer.",
            "",
            "## 6. Off-target changes",
            "",
            f"- Off-target classification occurred in "
            f"{int((frame['category_tau_0p05'] == 'off_target_change').sum())}/16 pairs.",
            f"- Swapped largest components ended outside the lungs in "
            f"{int((frame['swapped_largest_component_destination'] == 'outside_lung').sum())}/16, "
            "in other valid lung tissue in "
            f"{int((frame['swapped_largest_component_destination'] == 'other_lung_region').sum())}/16, "
            "and in the intended swapped anatomy in "
            f"{int((frame['swapped_largest_component_destination'] == 'swapped_anatomy').sum())}/16.",
            f"- Exact empty outputs occurred in "
            f"{int(frame['any_empty_prediction'].sum())}/16 pairs; near-empty "
            f"(≤{config['near_empty_voxels']} voxels) in "
            f"{int(frame['any_near_empty_prediction'].sum())}/16.",
            "",
            "## 7. Pair classifications",
            "",
            "| Pair | Swap | τ=.025 | τ=.05 | τ=.10 |",
            "|---|---|---|---|---|",
        ]
    )
    for _, row in frame.iterrows():
        lines.append(
            f"| `{row['pair_id']}` | {row['swap_type']} | "
            f"{str(row['classification_tau_0p025']).replace('_', ' ')} | "
            f"{str(row['classification_tau_0p05']).replace('_', ' ')} | "
            f"{str(row['classification_tau_0p1']).replace('_', ' ')} |"
        )
    primary = frame["classification_tau_0p05"]
    low_changed = int((frame["classification_tau_0p025"] != primary).sum())
    high_changed = int((frame["classification_tau_0p1"] != primary).sum())
    lines.extend(
        [
            "",
            f"Relative to τ=0.05, {low_changed}/16 assignments change at τ=0.025 "
            f"and {high_changed}/16 change at τ=0.10. Full counts and descriptive "
            "statistics are in `aggregate.json`.",
            "",
            "## 8. Conclusion and next-step recommendation",
            "",
            f"**{conclusion[0]}.**",
            "",
            conclusion[1],
            "",
            f"Laterality: {category_summary(frame, 'laterality')}. Upper/lower: "
            f"{category_summary(frame, 'upper_lower')}.",
            "",
            "Findings from the same CT are not independent. The upper/lower subset "
            "contains only four pairs and is descriptive. This lightweight audit "
            "does not support complex inferential claims.",
            "",
        ]
    )
    output_path.write_text("\n".join(lines))


def get_gpu_name() -> str:
    if not torch.cuda.is_available():
        return "CUDA unavailable"
    return torch.cuda.get_device_name(torch.device("cuda:0"))


def main() -> int:
    args = parse_args()
    started = time.time()
    if abs(args.threshold - 0.5) > EPS:
        raise ValueError("P0 used the fixed threshold 0.5; it must not be changed")
    if args.near_empty_voxels < 0:
        raise ValueError("--near-empty-voxels must be nonnegative")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "validation_visualizations").mkdir(exist_ok=True)
    (args.output_dir / "visualizations").mkdir(exist_ok=True)
    (args.output_dir / "visualization_payloads").mkdir(exist_ok=True)

    pairs, pairs_frame = load_and_validate_pairs(args.p0_dir)
    write_csv(args.output_dir / "validated_prompt_pairs.csv", pairs_frame)
    manifest = load_manifest(args.manifest)
    validation, anatomy_masks = validate_anatomy_alignment(
        pairs_frame, manifest, args.lobe_label_dir, args.output_dir
    )
    provenance = mask_provenance(
        pairs_frame,
        anatomy_masks,
        manifest,
        args.prior_root,
        args.lobe_label_dir,
    )
    write_csv(args.output_dir / "mask_provenance.csv", provenance)

    config: dict[str, Any] = {
        "audit": "p0b_lite_location_swap_direction_anchor85_fixed30",
        "rules_frozen_before_aggregate_at_unix": time.time(),
        "source_p0_folder": str(args.p0_dir.resolve()),
        "source_prompt_pairs": str((args.p0_dir / "prompt_pairs.json").resolve()),
        "source_prompt_pairs_sha256": sha256_file(args.p0_dir / "prompt_pairs.json"),
        "checkpoint": str(args.checkpoint.resolve()),
        "checkpoint_sha256": sha256_file(args.checkpoint),
        "fixed30_manifest": str(args.fixed30_manifest.resolve()),
        "fixed30_manifest_sha256": sha256_file(args.fixed30_manifest),
        "manifest": str(args.manifest.resolve()),
        "rex_json": str(args.rex_json.resolve()),
        "image_dir": str(args.image_dir.resolve()),
        "mask_dir": str(args.mask_dir.resolve()),
        "model_dir": str(args.model_dir.resolve()),
        "lobe_label_dir": str(args.lobe_label_dir.resolve()),
        "prior_root": str(args.prior_root.resolve()),
        "threshold": args.threshold,
        "tau_primary": PRIMARY_TAU,
        "tau_sensitivity": list(TAUS),
        "near_empty_voxels": args.near_empty_voxels,
        "pairs": len(pairs),
        "laterality_pairs": int((pairs_frame["swap_type"] == "laterality").sum()),
        "upper_lower_pairs": int(
            (pairs_frame["swap_type"] == "upper_lower").sum()
        ),
        "strict_inference_only": True,
        "optimizer_created": False,
        "backward_called": False,
        "parameter_updates": False,
        "checkpoint_modified": False,
        "gt_used_as_model_input": False,
        "prediction_maps_reused": False,
        "prediction_maps_reuse_reason": (
            "P0 retained metrics and six 2D slices but no dense 3D logits or "
            "probability maps."
        ),
        "dense_prediction_maps_retained": False,
        "dense_prediction_retention_reason": (
            "Lightweight audit retains per-pair deterministic 2D visualization "
            "payloads and all region sums, not multi-GB dense volumes."
        ),
        "classification_rule_order": [
            "near-empty: suppression if loss>tau, little if all changes small, else off-target",
            "off-target criteria",
            "directional transfer",
            "suppression",
            "little change",
            "residual mixed change -> off-target",
        ],
        "off_target_definition": {
            "laterality": "outside_lung_fraction_change",
            "upper_lower": (
                "max(outside_lung_fraction_change, "
                "other_lung_region_fraction_change)"
            ),
        },
        "binary_component_connectivity": 26,
        "largest_component_destination": (
            "region with greatest component voxel overlap; deterministic ties "
            "prefer swapped, original, other lung, outside"
        ),
        "geometry": (
            "Exact P0 VoxTell load_image + predictor.preprocess path; lobe labels "
            "use exact manifest crop and affine orientation transform."
        ),
        "command": " ".join([sys.executable, *sys.argv]),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "slurm_node": os.environ.get("SLURMD_NODENAME"),
        "host": platform.node(),
        "python": sys.version,
        "torch": torch.__version__,
        "repository_git": git_state(ROOT),
        "voxtell_git": git_state(ROOT / "VoxTell"),
        "mask_validation": validation,
        "completed": False,
    }
    write_json(args.output_dir / "audit_config.json", config)
    (args.output_dir / "run_command.txt").write_text(config["command"] + "\n")

    if not torch.cuda.is_available():
        raise RuntimeError("The required inference rerun needs exactly one CUDA GPU")
    if torch.cuda.device_count() != 1:
        raise RuntimeError(
            f"Expected exactly one visible GPU, found {torch.cuda.device_count()}"
        )
    device = torch.device(args.device)
    predictor = VoxTellPredictor(
        str(args.model_dir),
        device=device,
        text_encoding_model=args.text_model,
        checkpoint_path=str(args.checkpoint),
    )
    network = (
        predictor.network._orig_mod
        if hasattr(predictor.network, "_orig_mod")
        else predictor.network
    )
    network.requires_grad_(False)
    network.eval()
    network_before = tensor_digest(network)
    pooled_map, _, qwen_digests = extract_qwen(
        predictor, pairs, args.qwen_batch_size
    )
    predictor.text_backbone = None
    gc.collect()
    torch.cuda.empty_cache()

    pair_lookup = pairs_frame.set_index("pair_id")
    pairs_by_case: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for pair in pairs:
        pairs_by_case[str(pair["case_id"])].append(pair)
    entries = {
        str(entry["name"]): entry
        for entry in load_entries(args.rex_json, ["val"])
    }
    metric_rows: list[dict[str, Any]] = []
    unique_prompt_inferences = 0
    with torch.inference_mode():
        for case_index, case_id in enumerate(sorted(pairs_by_case), start=1):
            case_pairs = pairs_by_case[case_id]
            print(
                f"Case {case_index}/{len(pairs_by_case)}: {case_id} "
                f"({len(case_pairs)} pairs)",
                flush=True,
            )
            image, properties = load_image(args.image_dir / case_id)
            data, bbox, _ = predictor.preprocess(image)
            lobes = anatomy_masks[case_id]
            if tuple(data.shape[1:]) != tuple(lobes.shape):
                raise RuntimeError(
                    f"{case_id}: inference {tuple(data.shape[1:])} != lobes {lobes.shape}"
                )
            manifest_bbox = [
                [int(item.start), int(item.stop)]
                if isinstance(item, slice)
                else [int(item[0]), int(item[1])]
                for item in bbox
            ]
            if manifest_bbox != manifest[case_id]["crop_bbox"]:
                raise RuntimeError(
                    f"{case_id}: runtime crop {manifest_bbox} != manifest/P0 "
                    f"{manifest[case_id]['crop_bbox']}"
                )
            entry = entries[case_id]
            targets = load_rex_masks_in_preprocessed_ras(
                args.mask_dir / case_id,
                properties,
                len(sorted_prompts(entry)),
                bbox,
            ).numpy().astype(bool)
            ct = data[0].numpy()
            unique_prompts = list(
                dict.fromkeys(
                    text
                    for pair in case_pairs
                    for text in (
                        str(pair["original_prompt"]),
                        str(pair["swapped_prompt"]),
                    )
                )
            )
            logits_by_prompt: dict[str, np.ndarray] = {}
            for prompt_index, prompt in enumerate(unique_prompts, start=1):
                print(
                    f"  Inference {prompt_index}/{len(unique_prompts)}: "
                    f"{prompt[:100]}",
                    flush=True,
                )
                logits_tensor = predictor.predict_sliding_window_return_logits(
                    data, pooled_map[prompt][None, None]
                )
                logits_by_prompt[prompt] = logits_tensor[0].float().cpu().numpy()
                unique_prompt_inferences += 1
                del logits_tensor
                torch.cuda.empty_cache()
            for pair in case_pairs:
                pair_id = str(pair["pair_id"])
                anatomy = pair_lookup.loc[pair_id]
                finding_id = int(pair["finding_id"])
                row = pair_metrics(
                    pair,
                    anatomy,
                    lobes,
                    logits_by_prompt[str(pair["original_prompt"])],
                    logits_by_prompt[str(pair["swapped_prompt"])],
                    targets[finding_id],
                    ct,
                    args.threshold,
                    args.near_empty_voxels,
                    args.output_dir
                    / "visualization_payloads"
                    / f"{pair_id}.npz",
                )
                metric_rows.append(row)
            write_csv(
                args.output_dir / "partial_per_pair_direction_metrics.csv",
                pd.DataFrame(metric_rows),
            )
            del image, data, targets, ct, logits_by_prompt
            gc.collect()
            torch.cuda.empty_cache()

    frame = pd.DataFrame(metric_rows)
    if len(frame) != 16:
        raise RuntimeError(f"Expected 16 metric rows, obtained {len(frame)}")
    reproduction_frame, reproduction = reproduce_p0_validation(
        frame, args.p0_dir / "per_pair_metrics.csv"
    )
    write_csv(
        args.output_dir / "p0_reproduction_validation.csv", reproduction_frame
    )
    if not reproduction["all_passed"]:
        write_json(
            args.output_dir / "p0_reproduction_failure.json", reproduction
        )
        raise RuntimeError(f"P0 output reproduction failed: {reproduction}")

    write_csv(args.output_dir / "per_pair_direction_metrics.csv", frame)
    aggregate = aggregate_results(frame)
    selections = representative_selections(frame)
    aggregate["representative_visualizations"] = selections
    aggregate["p0_reproduction"] = reproduction
    conclusion = choose_conclusion(frame)
    aggregate["conclusion"] = {
        "selection": conclusion[0],
        "recommendation": conclusion[1],
    }
    write_json(args.output_dir / "aggregate.json", aggregate)
    make_summary_plot(
        frame, args.output_dir / "visualizations" / "summary_direction_metrics.png"
    )
    for selection in selections:
        pair_id = selection["pair_id"]
        row = frame.loc[frame["pair_id"] == pair_id].iloc[0]
        make_representative_visualization(
            row,
            args.output_dir / "visualization_payloads" / f"{pair_id}.npz",
            args.output_dir / "visualizations" / f"{selection['rule']}__{pair_id}.png",
            selection["rule"],
        )

    network.to("cpu")
    network_after = tensor_digest(network)
    no_gradients = all(parameter.grad is None for parameter in network.parameters())
    runtime = time.time() - started
    config.update(
        {
            "completed": True,
            "runtime_seconds": runtime,
            "gpu": get_gpu_name(),
            "exit_status": 0,
            "successfully_analyzed_pairs": len(frame),
            "unique_prompt_inferences": unique_prompt_inferences,
            "p0_reproduction": reproduction,
            "qwen_parameter_digest_before": qwen_digests["before"],
            "qwen_parameter_digest_after": qwen_digests["after"],
            "qwen_parameters_unchanged": qwen_digests["before"]
            == qwen_digests["after"],
            "voxtell_parameter_digest_before": network_before,
            "voxtell_parameter_digest_after": network_after,
            "voxtell_parameters_unchanged": network_before == network_after,
            "no_gradients_created": no_gradients,
            "representative_visualizations": selections,
            "conclusion": {
                "selection": conclusion[0],
                "recommendation": conclusion[1],
            },
        }
    )
    if (
        not config["qwen_parameters_unchanged"]
        or not config["voxtell_parameters_unchanged"]
        or not no_gradients
    ):
        raise RuntimeError("Frozen parameter/no-gradient verification failed")
    write_json(args.output_dir / "audit_config.json", config)
    write_report(
        args.output_dir / "report.md",
        config,
        validation,
        frame,
        aggregate,
        conclusion,
    )
    print(
        json.dumps(
            json_ready(
                {
                    "status": "complete",
                    "runtime_minutes": runtime / 60,
                    "pairs": len(frame),
                    "categories_tau_0.05": frame[
                        "category_tau_0p05"
                    ].value_counts().to_dict(),
                    "conclusion": conclusion,
                }
            ),
            indent=2,
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
