#!/usr/bin/env python3
"""Pair learned and forced-uniform B3 Full200 results and write the audit report."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy.stats import pearsonr, spearmanr

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "router_functional_audit"
LEARNED = ROOT / "outputs/word_global_v11_0to2000/full200_best_and_u4000/b3_u4000"
UNIFORM = AUDIT / "forced_uniform_inference"
BEHAVIOR = ROOT / "b3_behavior_audit"
PATHOLOGY = ROOT / "outputs/pathology_sensitivity_audit/pathology_counterfactual/b3/per_finding.csv"


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260906)
    return parser.parse_args()


def load_summary(path: Path) -> dict:
    return json.loads((path / "summary.json").read_text())


def correlation(x: pd.Series, y: pd.Series) -> dict:
    valid = x.notna() & y.notna()
    if valid.sum() < 3 or x[valid].nunique() < 2 or y[valid].nunique() < 2:
        return {"n": int(valid.sum()), "pearson_r": None, "spearman_rho": None}
    return {
        "n": int(valid.sum()),
        "pearson_r": float(pearsonr(x[valid], y[valid]).statistic),
        "spearman_rho": float(spearmanr(x[valid], y[valid]).statistic),
    }


def main() -> int:
    args = parse_args()
    AUDIT.mkdir(parents=True, exist_ok=True)
    learned_summary, uniform_summary = load_summary(LEARNED), load_summary(UNIFORM)
    if Path(learned_summary["checkpoint"]).resolve() != Path(uniform_summary["checkpoint"]).resolve():
        raise RuntimeError("Full200 arms do not use the same checkpoint")
    if not uniform_summary.get("force_uniform_router", False):
        raise RuntimeError("Uniform summary does not identify the forced-router intervention")

    lf = pd.read_csv(LEARNED / "summary_tables/per_finding_metrics.csv")
    uf = pd.read_csv(UNIFORM / "summary_tables/per_finding_metrics.csv")
    merge_keys = ["file", "finding_idx"]
    paired = lf.merge(uf, on=merge_keys, how="outer", suffixes=("_learned", "_uniform"), validate="one_to_one", indicator=True)
    if len(paired) != 381 or not (paired["_merge"] == "both").all():
        raise RuntimeError(f"Cannot pair Full200 finding-by-finding: {paired['_merge'].value_counts().to_dict()}")
    paired = paired.drop(columns="_merge").rename(columns={"file": "case"})
    keys = ["case", "finding_idx"]
    paired["dice_learned"] = paired["global_dice_learned"]
    paired["dice_uniform"] = paired["global_dice_uniform"]
    paired["delta_dice"] = paired["dice_learned"] - paired["dice_uniform"]
    paired["hit_learned"] = paired["global_hit_learned"].astype(bool)
    paired["hit_uniform"] = paired["global_hit_uniform"].astype(bool)
    paired["transition"] = np.select(
        [
            paired.hit_learned & paired.hit_uniform,
            paired.hit_learned & ~paired.hit_uniform,
            ~paired.hit_learned & paired.hit_uniform,
        ],
        ["HIT->HIT", "HIT->MISS", "MISS->HIT"],
        default="MISS->MISS",
    )
    paired["lesion_volume_mm3"] = paired["gt_voxels_learned"] * paired["voxel_volume_mm3_learned"]
    paired["prompt"] = paired["prompt_learned"]
    paired["category"] = paired["category_learned"]

    pathology = pd.read_csv(PATHOLOGY)
    pathology = pathology.rename(columns={"case_id": "case"})[
        ["case", "finding_idx", "factual_pathology", "side", "lobes", "anatomy_group"]
    ].drop_duplicates(keys)
    paired = paired.merge(pathology, on=keys, how="left", validate="one_to_one")

    cases = paired.case.unique()
    rng = np.random.default_rng(args.seed)
    means = np.empty(args.bootstrap_samples, dtype=np.float64)
    groups = {case: part.delta_dice.to_numpy() for case, part in paired.groupby("case")}
    for index in range(args.bootstrap_samples):
        sampled = rng.choice(cases, size=len(cases), replace=True)
        means[index] = np.concatenate([groups[case] for case in sampled]).mean()
    ci = np.quantile(means, [0.025, 0.975]).tolist()

    transition_counts = paired.transition.value_counts().reindex(
        ["HIT->HIT", "HIT->MISS", "MISS->HIT", "MISS->MISS"], fill_value=0
    )
    output_columns = [
        "case", "finding_idx", "category", "prompt", "factual_pathology", "side", "lobes",
        "anatomy_group", "lesion_volume_mm3", "dice_learned", "dice_uniform", "delta_dice",
        "hit_learned", "hit_uniform", "transition",
    ]
    paired[output_columns].sort_values(keys).to_csv(AUDIT / "per_finding.csv", index=False)
    paired[output_columns].sort_values(["transition", "case", "finding_idx"]).to_csv(
        AUDIT / "hit_transitions.csv", index=False
    )

    router = pd.read_csv(BEHAVIOR / "router_weights.csv")
    router = router[(router.condition == "factual") & (router.intervention == "factual")]
    alpha = router.pivot_table(index=["case_id", "finding_idx"], columns="candidate", values="alpha").reset_index()
    alpha.columns = ["case", "finding_idx", "alpha_1", "alpha_2", "alpha_3", "alpha_4"]
    alpha_values = alpha[[f"alpha_{i}" for i in range(1, 5)]].to_numpy()
    alpha["router_entropy"] = -(alpha_values * np.log(np.clip(alpha_values, 1e-12, None))).sum(1)
    alpha["normalized_router_entropy"] = alpha.router_entropy / np.log(4.0)
    alpha["router_max_weight"] = alpha_values.max(1)
    alpha["router_min_weight"] = alpha_values.min(1)
    alpha["router_weight_std"] = alpha_values.std(1)
    alpha["router_deviation_l2"] = np.linalg.norm(alpha_values - 0.25, axis=1)

    similarity = pd.read_csv(BEHAVIOR / "candidate_similarity.csv")
    similarity = similarity[(similarity.condition == "factual") & (similarity.intervention == "factual")]
    similarity = similarity.groupby(["case_id", "finding_idx"], as_index=False).agg(
        mean_pairwise_pre_pd_cosine=("pre_pd_query_cosine", "mean"),
        mean_pairwise_post_pd_cosine=("post_pd_candidate_cosine", "mean"),
    ).rename(columns={"case_id": "case"})

    raw = torch.load(BEHAVIOR / "raw_forward_tensors.pt", map_location="cpu", weights_only=False)
    dispersion_rows = []
    for record in raw["records"]:
        if record["condition"] != "factual":
            continue
        q = record["candidate_queries"].float()
        m = record["candidate_masks"].float()
        dispersion_rows.append({
            "case": record["case_id"],
            "finding_idx": int(record["finding_idx"]),
            "pre_pd_candidate_dispersion": float((q - q.mean(0)).norm(dim=-1).mean()),
            "post_pd_candidate_dispersion": float((m - m.mean(0)).norm(dim=-1).mean()),
        })
    dispersion = pd.DataFrame(dispersion_rows)
    stats = alpha.merge(similarity, on=keys, validate="one_to_one").merge(
        dispersion, on=keys, validate="one_to_one"
    ).merge(paired[["case", "finding_idx", "delta_dice"]], on=keys, validate="one_to_one")
    stats.sort_values(keys).to_csv(AUDIT / "router_stats.csv", index=False)

    correlations = {
        "router_deviation_vs_delta": correlation(stats.router_deviation_l2, stats.delta_dice),
        "router_std_vs_delta": correlation(stats.router_weight_std, stats.delta_dice),
        "pre_pd_dispersion_vs_delta": correlation(stats.pre_pd_candidate_dispersion, stats.delta_dice),
        "post_pd_dispersion_vs_delta": correlation(stats.post_pd_candidate_dispersion, stats.delta_dice),
    }
    bootstrap = {
        "estimand": "mean per-finding Dice(learned - forced uniform)",
        "resampling_unit": "case",
        "cases": int(len(cases)),
        "findings": int(len(paired)),
        "samples": args.bootstrap_samples,
        "seed": args.seed,
        "observed_mean": float(paired.delta_dice.mean()),
        "ci95_percentile": ci,
        "bootstrap_mean": float(means.mean()),
        "bootstrap_std": float(means.std(ddof=1)),
        "correlations_diagnostic_subset": correlations,
    }
    (AUDIT / "bootstrap_summary.json").write_text(json.dumps(bootstrap, indent=2) + "\n")

    mean_delta = float(paired.delta_dice.mean())
    if ci[0] > 0:
        used, beneficial = "YES", "YES"
        implication = "The final checkpoint has measurable inference-time router value. A weak candidate anti-collapse/diversity pilot is the best-motivated next experiment, but is outside this audit."
    elif ci[1] < 0:
        used, beneficial = "YES", "NO"
        implication = "The learned router changes predictions but hurts net Dice at final inference. The prior K4 training advantage should be treated as a training-path effect; forcing diversity is not supported yet."
    else:
        used = "YES" if bool((paired.delta_dice.abs() > 0).any()) else "NO"
        beneficial = "INCONCLUSIVE"
        implication = "The final router changes predictions, but its net Dice value is not resolved by the paired interval. A checkpoint-wise dependence trajectory or training-path audit is better motivated than a diversity loss."

    changed = paired[paired.transition.isin(["HIT->MISS", "MISS->HIT"])].copy()
    if changed.empty:
        changed_table = "No HIT-status transitions."
    else:
        transition_lines = [
            "| transition | case | finding | pathology | side/lobes | lesion mm³ | learned Dice | uniform Dice | delta |",
            "|---|---|---:|---|---|---:|---:|---:|---:|",
        ]
        for row in changed.sort_values(["transition", "case", "finding_idx"]).itertuples():
            anatomy = f"{row.side}/{row.lobes}" if pd.notna(row.side) or pd.notna(row.lobes) else ""
            transition_lines.append(
                f"| {row.transition} | {row.case} | {int(row.finding_idx)} | "
                f"{row.factual_pathology if pd.notna(row.factual_pathology) else row.prompt} | "
                f"{anatomy} | {row.lesion_volume_mm3:.1f} | {row.dice_learned:.6f} | "
                f"{row.dice_uniform:.6f} | {row.delta_dice:+.6f} |"
            )
        changed_table = "\n".join(transition_lines)

    lc = learned_summary["mean_global_dice_per_finding"]
    uc = uniform_summary["mean_global_dice_per_finding"]
    report = f"""# Learned-router functional audit

B3 LEARNED ROUTER:  
Dice `{lc:.8f}`  
HIT `{learned_summary['total_hits']}`

SAME B3 CHECKPOINT + FORCED UNIFORM ROUTER:  
Dice `{uc:.8f}`  
HIT `{uniform_summary['total_hits']}`

LEARNED - UNIFORM:  
Dice difference `{mean_delta:+.8f}`  
case-cluster 95% CI `[{ci[0]:+.8f}, {ci[1]:+.8f}]`

HIT TRANSITIONS:  
learned HIT -> uniform MISS: `{int(transition_counts['HIT->MISS'])}`  
learned MISS -> uniform HIT: `{int(transition_counts['MISS->HIT'])}`

ROUTER FUNCTIONALLY USED:  
`{used}`

ROUTER NET BENEFICIAL AT INFERENCE:  
`{beneficial}`

NEXT-STEP IMPLICATION:  
{implication}

## Primary paired results

- Case Dice: learned `{learned_summary['mean_global_dice_per_case']:.8f}`, uniform `{uniform_summary['mean_global_dice_per_case']:.8f}`.
- Finding Dice: learned `{lc:.8f}`, uniform `{uc:.8f}`.
- Mean paired finding difference: `{mean_delta:+.8f}`; median: `{paired.delta_dice.median():+.8f}`.
- Fraction learned better: `{(paired.delta_dice > 0).mean():.3%}`; fraction uniform better: `{(paired.delta_dice < 0).mean():.3%}`; exact ties: `{(paired.delta_dice == 0).mean():.3%}`.
- HIT counts: learned `{learned_summary['total_hits']}`, uniform `{uniform_summary['total_hits']}`.

| learned router | forced uniform | count |
|---|---|---:|
| HIT | HIT | {int(transition_counts['HIT->HIT'])} |
| HIT | MISS | {int(transition_counts['HIT->MISS'])} |
| MISS | HIT | {int(transition_counts['MISS->HIT'])} |
| MISS | MISS | {int(transition_counts['MISS->MISS'])} |

### Findings that change HIT status

{changed_table}

## Router and candidate diagnostics

Router/candidate statistics reuse the existing frozen-checkpoint diagnostic subset of `{len(stats)}` findings. Those measurements use one deterministic lesion-rich patch per case; their correlations are descriptive and are not Full200 sliding-window averages.

- Router deviation from uniform vs Dice benefit: Pearson `{correlations['router_deviation_vs_delta']['pearson_r']}`, Spearman `{correlations['router_deviation_vs_delta']['spearman_rho']}`.
- Post-PromptDecoder candidate dispersion vs Dice benefit: Pearson `{correlations['post_pd_dispersion_vs_delta']['pearson_r']}`, Spearman `{correlations['post_pd_dispersion_vs_delta']['spearman_rho']}`.
- Mean normalized router entropy: `{stats.normalized_router_entropy.mean():.8f}`; mean maximum alpha: `{stats.router_max_weight.mean():.8f}`.
- Mean pairwise candidate cosine: pre-PromptDecoder `{stats.mean_pairwise_pre_pd_cosine.mean():.8f}`, post-PromptDecoder `{stats.mean_pairwise_post_pd_cosine.mean():.8f}`.

These associations do not establish causality. The same-checkpoint Full200 intervention is the causal test of aggregate router value.

## Direct answers

1. **Does the model depend on the learned router?** `{used}`: forced uniform changes `{int((paired.delta_dice != 0).sum())}` of 381 per-finding Dice values.
2. **Are tiny deviations from 0.25 meaningful?** See the paired effect and interval above; the conclusion follows the net-benefit label `{beneficial}`.
3. **Does exact uniform routing significantly reduce Dice?** `{('YES' if ci[0] > 0 else 'NO')}` under the prespecified case-cluster 95% interval.
4. **How many HITs depend on learned routing?** `{int(transition_counts['HIT->MISS'])}` learned HITs become misses; `{int(transition_counts['MISS->HIT'])}` move in the opposite direction.
5. **Inference routing or training path?** {('The same-checkpoint result supports an inference-time routing contribution.' if ci[0] > 0 else 'The result does not establish a positive final inference-time routing contribution; the prior trained-arm advantage is more consistent with training path/co-adaptation.')}
6. **Case for forcing candidate diversity?** {('Strengthened, because learned weighting of the small candidate differences improves the paired Full200 result.' if ci[0] > 0 else 'Weakened for now; diagnose router dependence over training before adding a diversity objective.')}

Transition-level finding details, including pathology, side/lobes, lesion volume, and both Dice values, are in `hit_transitions.csv`.
"""
    (AUDIT / "report.md").write_text(report)
    print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
