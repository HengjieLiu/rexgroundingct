#!/usr/bin/env python3
"""Lightweight selected-update representation diagnostics for early C1/C2."""

from __future__ import annotations

import gc
import json
import sys
from pathlib import Path
from typing import Any

import pandas as pd
import torch
import torch.nn.functional as F


ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT, ROOT / "VoxTell"):
    if str(search_path) not in sys.path:
        sys.path.insert(0, str(search_path))

from scripts.diagnose_token_image_text_phase0 import pad_and_crop  # noqa: E402
from scripts.diagnose_token_image_text_phase0b_gate import replace_symlink  # noqa: E402
from scripts.run_voxtell_rex_inference import load_image  # noqa: E402
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402
from voxtell.model.qwen_lora_bica import IndexedFrozenPrefixCache, QwenTop6LoRA  # noqa: E402


OUT = ROOT / "outputs/qwen_early_coadaptation_from_v11"
CACHE_PATH = ROOT / "outputs/qwen_lora_bica_audit/frozen_prefix_cache/index.json"
UPDATES = [0, 1000, 2000, 3000, 4000, 5000]
ARMS = {
    "C1": ROOT / "outputs/qwen_lora_top6_global_from_v11",
    "C2": ROOT / "outputs/qwen_lora_top6_bica_stage3_from_v11",
}


def checkpoint_path(run: Path, update: int) -> Path:
    return run / "checkpoints" / (
        "checkpoint_initial.pth" if update == 0 else f"checkpoint_update_{update}.pth"
    )


def tensor_metrics(reference: torch.Tensor, value: torch.Tensor) -> dict[str, float]:
    reference = reference.detach().float().reshape(-1)
    value = value.detach().float().reshape(-1)
    return {
        "relative_l2": float(
            (value - reference).norm().div(reference.norm().clamp_min(1e-12))
        ),
        "cosine_to_update0": float(F.cosine_similarity(value, reference, dim=0)),
    }


@torch.inference_mode()
def intrinsic_text_drift(
    cache: IndexedFrozenPrefixCache, device: torch.device
) -> list[dict[str, Any]]:
    records = []
    for key in sorted(cache.entries)[:10]:
        item = torch.load(
            cache.root / cache.entries[key], map_location="cpu", weights_only=False
        )
        records.append({"prompt": str(item["prompt"])})
    adapter = QwenTop6LoRA().eval().to(device)
    prefix, mask, positions = cache.batch(
        records, device=device, dtype=torch.bfloat16
    )
    rows: list[dict[str, Any]] = []
    for arm, run in ARMS.items():
        baseline = None
        for update in UPDATES:
            payload = torch.load(
                checkpoint_path(run, update),
                map_location="cpu",
                weights_only=False,
                mmap=True,
            )
            state = {
                name.removeprefix("qwen_adapter."): value
                for name, value in payload["network_weights"].items()
                if name.startswith("qwen_adapter.") and ".lora_" in name
            }
            adapter.load_trainable_lora_state_dict(state)
            del state, payload
            gc.collect()
            pooled = adapter.last_token_pool(
                adapter.forward_from_prefix(prefix, mask, positions), mask
            ).float()
            if baseline is None:
                baseline = pooled.clone()
            for index, record in enumerate(records):
                rows.append(
                    {
                        "arm": arm,
                        "update": update,
                        "prompt_index": index,
                        "prompt": record["prompt"],
                        "scope": "qwen_pooled_intrinsic_top6_lora",
                        **tensor_metrics(baseline[index], pooled[index]),
                    }
                )
    del adapter, prefix, mask, positions
    torch.cuda.empty_cache()
    return rows


def representative_input(
    cache: IndexedFrozenPrefixCache,
) -> tuple[dict[str, Any], torch.Tensor, torch.Tensor, torch.Tensor]:
    manifest_path = (
        ROOT
        / "outputs/qwen_lora_top6_global_from_v11/fixed30/update_00000/fixed30_manifest.json"
    )
    manifest = json.loads(manifest_path.read_text())
    entry = manifest["val"][0]
    finding_key, prompt = next(iter(entry["findings"].items()))
    prefix, mask, positions = cache.batch(
        [{"prompt": prompt}], device=torch.device("cpu"), dtype=torch.float16
    )
    metadata = {
        "case": entry["name"],
        "finding_idx": int(finding_key),
        "prompt": prompt,
    }
    return metadata, prefix.unsqueeze(0), mask.unsqueeze(0), positions.unsqueeze(0)


@torch.inference_mode()
def image_and_interaction_drift(
    cache: IndexedFrozenPrefixCache, device: torch.device
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    metadata, prefix, mask, positions = representative_input(cache)
    model_assets = OUT / "diagnostic_model"
    replace_symlink(
        model_assets / "plans.json", ROOT / "VoxTell/voxtell_v1.1/plans.json"
    )
    image, _properties = load_image(
        ROOT / "data/ct_rate_volumes_fixed" / metadata["case"]
    )
    representation_rows: list[dict[str, Any]] = []
    interaction_rows: list[dict[str, Any]] = []
    patch_cpu = None

    for arm, run in ARMS.items():
        baselines: dict[str, torch.Tensor] = {}
        for update in UPDATES:
            predictor = VoxTellPredictor(
                str(model_assets),
                checkpoint_path=str(checkpoint_path(run, update)),
                device=device,
                load_text_backbone=False,
                text_representation="qwen",
                amp_dtype="bfloat16",
            )
            if patch_cpu is None:
                preprocessed, _bbox, _shape = predictor.preprocess(image)
                empty = torch.zeros(preprocessed.shape[-3:], dtype=torch.float32)
                patch_cpu, _target, _starts, _padding = pad_and_crop(
                    preprocessed, empty
                )
            network = (
                predictor.network._orig_mod
                if hasattr(predictor.network, "_orig_mod")
                else predictor.network
            )
            network.eval()
            captured: dict[str, torch.Tensor] = {}

            def capture(name: str):
                def hook(_module, _inputs, output):
                    captured[name] = output.detach().float().cpu()

                return hook

            handles = [
                network.encoder.stages[3].register_forward_hook(
                    capture("image_stage3_base")
                ),
                network.encoder.stages[4].register_forward_hook(
                    capture("image_stage4")
                ),
            ]
            try:
                placeholder = torch.zeros((1, 1, 2560), dtype=torch.float32)
                predictor.predict_sliding_window_return_logits(
                    patch_cpu.to(dtype=torch.float32),
                    placeholder,
                    qwen_prefix_hidden=prefix,
                    qwen_attention_mask=mask,
                    qwen_position_ids=positions,
                )
            finally:
                for handle in handles:
                    handle.remove()

            captured["qwen_pooled_after_interaction"] = (
                network.last_qwen_pooled_embedding.float().cpu()
            )
            if arm == "C2":
                captured["image_stage3_after_bica"] = (
                    network.last_qwen_bica_conditioned_stage3.float().cpu()
                )
                audit = dict(network.last_qwen_bica_audit)
                interaction_rows.append(
                    {
                        "arm": arm,
                        "update": update,
                        **metadata,
                        "delta_v_rel_l2": audit["delta_v_rel_l2"],
                        "delta_t_rel_l2": audit["delta_t_rel_l2"],
                        "delta_v_max_abs": audit["delta_v_max_abs"],
                        "delta_t_max_abs": audit["delta_t_max_abs"],
                        "valid_text_tokens": audit["valid_text_tokens_min"],
                        "metric_definition": (
                            "whole_tensor_relative_l2_valid_text_only"
                        ),
                    }
                )

            for scope, value in captured.items():
                if scope not in baselines:
                    baselines[scope] = value.clone()
                representation_rows.append(
                    {
                        "arm": arm,
                        "update": update,
                        "prompt_index": 0,
                        "prompt": metadata["prompt"],
                        "case": metadata["case"],
                        "scope": scope,
                        **tensor_metrics(baselines[scope], value),
                    }
                )
            del network, predictor, captured
            gc.collect()
            torch.cuda.empty_cache()
    return representation_rows, interaction_rows


@torch.inference_mode()
def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda")
    cache = IndexedFrozenPrefixCache(CACHE_PATH)
    rows = intrinsic_text_drift(cache, device)
    image_rows, interaction_rows = image_and_interaction_drift(cache, device)
    rows.extend(image_rows)
    pd.DataFrame(rows).to_csv(OUT / "representation_drift.csv", index=False)
    pd.DataFrame(interaction_rows).to_csv(
        OUT / "bica_interaction_magnitude.csv", index=False
    )
    summary = {
        "representation_rows": len(rows),
        "interaction_rows": len(interaction_rows),
        "updates": UPDATES,
        "status": "complete",
    }
    (OUT / "representation_drift_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
