#!/usr/bin/env python3
"""Evaluate trained P0 with visual/type/spatial/token-corruption ablations."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import numpy as np
import torch

from voxtell.model.aca_anatomy import ACAAnatomyEncoder, ANATOMY_NAMES


ROOT = Path(__file__).resolve().parents[1]
P0_CHECKPOINT = (
    ROOT
    / "outputs/aca_anatomy_p0_probe_20260730T225800Z_retry5_l40s"
    / "checkpoints/checkpoint_update_100.pth"
)
LOBE_NAMES = ANATOMY_NAMES[:5]
CONDITIONS = (
    "FULL",
    "ZERO_VISUAL",
    "MEAN_VISUAL",
    "SAME_SCAN_GLOBAL",
    "CONSTANT_VISUAL",
    "NO_TYPE",
    "NO_SPATIAL",
    "WITHIN_SCAN_LOBE_PERMUTED",
    "LEFT_RIGHT_VISUAL_SWAP",
    "OTHER_PATIENT_SAME_ANATOMY",
    "OTHER_PATIENT_RANDOM_ANATOMY",
    "TRAINING_MEAN_ANATOMY",
    "RANDOM_GAUSSIAN_MATCHED_NORM",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--permutation-seed", type=int, default=314159)
    return parser.parse_args()


def load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=True) as payload:
        return {key: np.asarray(payload[key]) for key in payload.files}


def forward_components(
    model: ACAAnatomyEncoder,
    visual: torch.Tensor,
    present: torch.Tensor,
    spatial: torch.Tensor,
    text: torch.Tensor,
    *,
    use_type: bool = True,
    use_spatial: bool = True,
) -> dict[str, torch.Tensor]:
    if text.ndim == 4 and text.shape[2] == 1:
        text = text.squeeze(2)
    if text.ndim != 3:
        raise ValueError(f"Text components must be [B,P,E] or [B,P,1,E], got {tuple(text.shape)}")
    batch = visual.shape[0]
    type_ids = torch.arange(6, device=visual.device)
    visual_component = model.visual_projection(visual)
    type_component = model.anatomy_type_embedding(type_ids)[None].expand(batch, -1, -1)
    if not use_type:
        type_component = torch.zeros_like(type_component)
    spatial_lobes = model.spatial_mlp(spatial)
    spatial_component = torch.cat(
        (
            spatial_lobes,
            model.global_spatial_embedding[None, None].expand(batch, 1, -1),
        ),
        dim=1,
    )
    if not use_spatial:
        spatial_component = torch.zeros_like(spatial_component)
    tokens = visual_component + type_component + spatial_component
    tokens = model.anatomy_transformer(tokens, src_key_padding_mask=~present)
    tokens = tokens * present.unsqueeze(-1).to(tokens.dtype)
    image = model.image_projection_head(tokens)
    image = image * present.unsqueeze(-1).to(image.dtype)
    text_projected = model.text_projection_head(text)
    logits = torch.einsum("bpc,bac->bpa", text_projected, image) / model.route_temperature()
    logits = logits.masked_fill(~present[:, None], -torch.inf)
    return {
        "logits": logits,
        "probability": torch.softmax(logits, -1),
        "image_embedding": image,
        "text_embedding": text_projected,
    }


def means_from_training(train: dict[str, np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    # Visual inputs repeat across the three prompts in each update; keep one row
    # per update so each original optimizer update receives equal weight.
    first = np.asarray([np.flatnonzero(train["update"] == update)[0] for update in np.unique(train["update"])])
    visual = train["visual"][first].astype(np.float32)
    present = train["present"][first].astype(bool)
    anatomy_mean = np.zeros((6, visual.shape[-1]), dtype=np.float32)
    for anatomy in range(6):
        anatomy_mean[anatomy] = visual[present[:, anatomy], anatomy].mean(0)
    constant = visual[present].reshape(-1, visual.shape[-1]).mean(0)
    return anatomy_mean, constant


def donor_mappings(
    fixed: dict[str, np.ndarray], seed: int
) -> tuple[np.ndarray, np.ndarray, list[dict[str, Any]]]:
    rng = np.random.default_rng(seed)
    cases = fixed["anchor_case"].astype(str)
    present = fixed["present"].astype(bool)
    count = len(cases)
    same = np.full((count, 6), -1, dtype=np.int64)
    random_anatomy = np.full((count, 6, 2), -1, dtype=np.int64)
    records: list[dict[str, Any]] = []
    for row in range(count):
        for anatomy in range(6):
            eligible = np.flatnonzero((cases != cases[row]) & present[:, anatomy])
            if present[row, anatomy] and len(eligible):
                donor = int(eligible[rng.integers(len(eligible))])
                same[row, anatomy] = donor
            donor_anatomy = int(rng.integers(6))
            eligible_random = np.flatnonzero(
                (cases != cases[row]) & present[:, donor_anatomy]
            )
            if present[row, anatomy] and len(eligible_random):
                donor = int(eligible_random[rng.integers(len(eligible_random))])
                random_anatomy[row, anatomy] = (donor, donor_anatomy)
            records.append(
                {
                    "case_id": cases[row],
                    "finding_idx": int(fixed["finding_idx"][row]),
                    "target_anatomy": ANATOMY_NAMES[anatomy],
                    "same_anatomy_donor_case": (
                        "" if same[row, anatomy] < 0 else cases[same[row, anatomy]]
                    ),
                    "random_donor_case": (
                        "" if random_anatomy[row, anatomy, 0] < 0 else cases[random_anatomy[row, anatomy, 0]]
                    ),
                    "random_donor_anatomy": (
                        "" if random_anatomy[row, anatomy, 1] < 0 else ANATOMY_NAMES[random_anatomy[row, anatomy, 1]]
                    ),
                }
            )
    return same, random_anatomy, records


def modified_visual(
    condition: str,
    row: int,
    fixed: dict[str, np.ndarray],
    anatomy_mean: np.ndarray,
    constant: np.ndarray,
    same_donor: np.ndarray,
    random_donor: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    visual = fixed["visual"][row].astype(np.float32).copy()
    present = fixed["present"][row].astype(bool)
    if condition == "ZERO_VISUAL":
        visual[:] = 0
    elif condition in {"MEAN_VISUAL", "TRAINING_MEAN_ANATOMY"}:
        visual[:] = anatomy_mean
    elif condition == "SAME_SCAN_GLOBAL":
        visual[:5] = visual[5]
    elif condition == "CONSTANT_VISUAL":
        visual[:] = constant
    elif condition == "WITHIN_SCAN_LOBE_PERMUTED":
        visual[:5] = visual[[1, 4, 0, 2, 3]]
    elif condition == "LEFT_RIGHT_VISUAL_SWAP":
        visual[:5] = visual[[3, 1, 4, 0, 2]]
    elif condition == "OTHER_PATIENT_SAME_ANATOMY":
        for anatomy in range(6):
            donor = same_donor[row, anatomy]
            if donor >= 0:
                visual[anatomy] = fixed["visual"][donor, anatomy]
    elif condition == "OTHER_PATIENT_RANDOM_ANATOMY":
        for anatomy in range(6):
            donor, donor_anatomy = random_donor[row, anatomy]
            if donor >= 0:
                visual[anatomy] = fixed["visual"][donor, donor_anatomy]
    elif condition == "RANDOM_GAUSSIAN_MATCHED_NORM":
        for anatomy in range(6):
            if not present[anatomy]:
                continue
            sample = rng.normal(size=visual.shape[-1]).astype(np.float32)
            sample /= max(float(np.linalg.norm(sample)), 1e-8)
            visual[anatomy] = sample * float(np.linalg.norm(visual[anatomy]))
    return visual


def main() -> int:
    args = parse_args()
    device = torch.device(args.device)
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("Inference ablations require CUDA")
    torch.cuda.set_device(0 if device.index is None else device.index)
    train = load_npz(args.output_root / "p0_train_components.npz")
    fixed = load_npz(args.output_root / "p0_fixed30_components.npz")
    cohort_rows = list(
        csv.DictReader((args.output_root / "cohort_manifest.csv").open(newline="", encoding="utf-8"))
    )
    cohort = {
        (row["case_id"], int(row["finding_idx"])): row for row in cohort_rows
    }
    checkpoint = torch.load(P0_CHECKPOINT, map_location="cpu", weights_only=False)
    config = checkpoint["resolved_config"]
    model = ACAAnatomyEncoder(
        visual_dim=320,
        text_dim=2560,
        hidden_dim=int(config["hidden_dim"]),
        projection_dim=int(config["projection_dim"]),
        transformer_layers=2,
        attention_heads=4,
        dropout=0.1,
    ).to(device)
    model.load_state_dict(checkpoint["aca_weights"], strict=True)
    model.eval()
    anatomy_mean, constant = means_from_training(train)
    same_donor, random_donor, mappings = donor_mappings(fixed, args.permutation_seed)
    with (args.output_root / "visual_token_source_mappings.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(mappings[0]))
        writer.writeheader()
        writer.writerows(mappings)

    rng = np.random.default_rng(args.permutation_seed)
    scores: list[dict[str, Any]] = []
    image_embeddings = np.zeros((len(CONDITIONS), len(cohort_rows), 6, 256), dtype=np.float32)
    text_embeddings = np.zeros((len(CONDITIONS), len(cohort_rows), 256), dtype=np.float32)
    for condition_index, condition in enumerate(CONDITIONS):
        for row in range(len(cohort_rows)):
            key = (str(fixed["anchor_case"][row]), int(fixed["finding_idx"][row]))
            if key not in cohort:
                raise AssertionError(f"Fixed cache/cohort mismatch: {key}")
            visual_np = modified_visual(
                condition, row, fixed, anatomy_mean, constant,
                same_donor, random_donor, rng,
            )
            visual = torch.tensor(visual_np[None], device=device)
            present = torch.tensor(fixed["present"][row][None], device=device, dtype=torch.bool)
            spatial = torch.tensor(fixed["spatial"][row][None], device=device)
            text = torch.tensor(fixed["text"][row][None, None], device=device)
            with torch.no_grad(), torch.autocast(
                device.type, enabled=True, dtype=torch.bfloat16
            ):
                output = forward_components(
                    model,
                    visual,
                    present,
                    spatial,
                    text,
                    use_type=condition != "NO_TYPE",
                    use_spatial=condition != "NO_SPATIAL",
                )
            probability6 = output["probability"][0, 0].float()
            probability5 = probability6[:5] / probability6[:5].sum().clamp_min(1e-8)
            target = np.asarray(
                [float(cohort[key][f"gt_soft_{name}"]) for name in LOBE_NAMES],
                dtype=np.float64,
            )
            target /= max(target.sum(), 1e-12)
            dominant = int(target.argmax())
            prediction = int(probability5.argmax().item())
            right_score = float(probability5[:3].sum().item())
            left_score = float(probability5[3:].sum().item())
            true_side = cohort[key]["gt_dominant_side"]
            predicted_side = "right" if right_score > left_score else "left"
            wrong = torch.cat((probability5[:dominant], probability5[dominant + 1 :])).max()
            scores.append(
                {
                    "method": condition,
                    "case_id": key[0],
                    "finding_idx": key[1],
                    "predicted_lobe": LOBE_NAMES[prediction],
                    "top1_correct": prediction == dominant,
                    "top2_correct": dominant in probability5.topk(2).indices.tolist(),
                    "predicted_side": predicted_side,
                    "laterality_correct": predicted_side == true_side,
                    "target_lobe_mass": float(probability5[dominant].item()),
                    "target_side_mass": right_score if true_side == "right" else left_score,
                    "lobe_margin": float(probability5[dominant].item() - wrong.item()),
                    "side_margin": abs(right_score - left_score) * (1 if predicted_side == true_side else -1),
                    "cross_entropy": float(-(torch.tensor(target, device=device) * probability5.clamp_min(1e-8).log()).sum().item()),
                    "brier": float(np.square(probability5.cpu().numpy() - target).sum()),
                    **{f"score_{name}": float(probability5[index].item()) for index, name in enumerate(LOBE_NAMES)},
                }
            )
            image_embeddings[condition_index, row] = output["image_embedding"][0].float().cpu().numpy()
            text_embeddings[condition_index, row] = output["text_embedding"][0, 0].float().cpu().numpy()
        print(f"condition {condition}", flush=True)

    with (args.output_root / "inference_ablation_results.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(scores[0]))
        writer.writeheader()
        writer.writerows(scores)
    np.savez_compressed(
        args.output_root / "inference_ablation_embeddings.npz",
        conditions=np.asarray(CONDITIONS),
        image_embeddings=image_embeddings,
        text_embeddings=text_embeddings,
        case_ids=fixed["anchor_case"].astype(str),
        finding_ids=fixed["finding_idx"].astype(np.int64),
    )
    summary = {
        condition: {
            "top1": float(np.mean([row["top1_correct"] for row in scores if row["method"] == condition])),
            "top2": float(np.mean([row["top2_correct"] for row in scores if row["method"] == condition])),
            "laterality": float(np.mean([row["laterality_correct"] for row in scores if row["method"] == condition])),
            "target_lobe_mass": float(np.mean([row["target_lobe_mass"] for row in scores if row["method"] == condition])),
        }
        for condition in CONDITIONS
    }
    (args.output_root / "inference_ablation_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
