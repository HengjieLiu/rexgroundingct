#!/usr/bin/env python3
"""Check whether a subset rerun reproduces an existing prediction directory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-dir", type=Path, required=True)
    parser.add_argument("--candidate-dir", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--require-exact", action="store_true")
    parser.add_argument(
        "--max-different-voxels",
        type=int,
        default=None,
        help="Fail if any case exceeds this binary-mask disagreement count.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    rows = []
    for candidate_path in sorted(args.candidate_dir.glob("*.nii.gz")):
        reference_path = args.reference_dir / candidate_path.name
        if not reference_path.exists():
            raise FileNotFoundError(reference_path)
        reference = np.asanyarray(nib.load(str(reference_path)).dataobj)
        candidate = np.asanyarray(nib.load(str(candidate_path)).dataobj)
        if reference.shape != candidate.shape:
            raise ValueError(
                f"{candidate_path.name}: {candidate.shape} != {reference.shape}"
            )
        reference_fg = reference > 0
        candidate_fg = candidate > 0
        different = candidate_fg != reference_fg
        intersection = int(np.logical_and(reference_fg, candidate_fg).sum())
        denominator = int(reference_fg.sum() + candidate_fg.sum())
        different_voxels = int(np.count_nonzero(different))
        rows.append(
            {
                "name": candidate_path.name,
                "max_abs_difference": float(bool(different_voxels)),
                "different_voxels": different_voxels,
                "different_fraction": float(different_voxels / different.size),
                "binary_dice_between_runs": (
                    1.0 if denominator == 0 else float(2.0 * intersection / denominator)
                ),
            }
        )
    summary = {
        "files": len(rows),
        "all_exact": bool(rows) and all(row["different_voxels"] == 0 for row in rows),
        "all_within_voxel_tolerance": (
            None
            if args.max_different_voxels is None
            else bool(rows)
            and all(
                row["different_voxels"] <= args.max_different_voxels for row in rows
            )
        ),
        "max_abs_difference": max((row["max_abs_difference"] for row in rows), default=None),
        "cases": rows,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    with args.output_json.open("w") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))
    if args.require_exact and not summary["all_exact"]:
        return 1
    if (
        args.max_different_voxels is not None
        and not summary["all_within_voxel_tolerance"]
    ):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
