#!/usr/bin/env python3
"""Aggregate fixed30 causal metrics and case-cluster uncertainty for the rescue pilot."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
EXP = ROOT / "outputs/p5000_less_counterfactual_rescue"
PAIRS = ROOT / "outputs/c2_semantic_p_token_causal_audit/samecase/eligible_pairs.csv"
CONDITIONS = ("normal", "l_neutral", "l_shuffle", "less_bypass", "l_wrong")


def result_dir(arm: str, update: int, condition: str) -> Path:
    source_arm = "P0" if update == 0 else arm
    suffix = "_less_bypass" if condition == "less_bypass" else ""
    return EXP / "fixed30" / source_arm / f"update_{update:03d}" / condition / "full_volume" / f"update_{update:05d}{suffix}"


def frame(arm: str, update: int, condition: str) -> pd.DataFrame:
    path = result_dir(arm, update, condition) / "summary_tables/per_finding_metrics.csv"
    data = pd.read_csv(path).rename(columns={"file": "case", "global_dice": "dice"})
    data["case"] = data["case"].astype(str)
    data["finding_idx"] = data["finding_idx"].astype(int)
    data["pred_volume_mm3"] = data["pred_voxels"] * data["voxel_volume_mm3"]
    if condition == "l_wrong":
        eligible = pd.read_csv(PAIRS)
        eligible = eligible[eligible["eligible"]][["case", "finding_idx"]]
        data = data.merge(eligible, on=["case", "finding_idx"], validate="one_to_one")
    return data


def clustered_ci(values: pd.DataFrame, value: str, seed: int, draws: int = 5000) -> tuple[float, float]:
    grouped = {case: group[value].to_numpy() for case, group in values.groupby("case")}
    cases = sorted(grouped)
    rng = np.random.default_rng(seed)
    samples = []
    for _ in range(draws):
        picked = rng.choice(cases, len(cases), replace=True)
        samples.append(float(np.concatenate([grouped[case] for case in picked]).mean()))
    return float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))


def condition_summary(data: pd.DataFrame) -> dict:
    return {
        "n": int(len(data)),
        "dice": float(data["dice"].mean()),
        "hit": int(data["global_hit"].astype(bool).sum()),
        "mean_pred_volume_mm3": float(data["pred_volume_mm3"].mean()),
        "median_pred_volume_mm3": float(data["pred_volume_mm3"].median()),
        "empty": int((data["pred_voxels"] <= 0).sum()),
    }


def paired_gap(normal: pd.DataFrame, other: pd.DataFrame, seed: int) -> tuple[dict, pd.DataFrame]:
    keys = ["case", "finding_idx"]
    merged = normal[keys + ["dice", "global_hit"]].merge(
        other[keys + ["dice", "global_hit"]],
        on=keys,
        suffixes=("_normal", "_other"),
        validate="one_to_one",
    )
    merged["gap"] = merged["dice_normal"] - merged["dice_other"]
    low, high = clustered_ci(merged, "gap", seed)
    return {
        "n": int(len(merged)),
        "mean_gap": float(merged["gap"].mean()),
        "median_gap": float(merged["gap"].median()),
        "ci95_low": low,
        "ci95_high": high,
        "normal_better": int((merged["gap"] > 1e-12).sum()),
        "other_better": int((merged["gap"] < -1e-12).sum()),
        "tied": int((merged["gap"].abs() <= 1e-12).sum()),
        "hit_delta": int(merged["global_hit_normal"].sum() - merged["global_hit_other"].sum()),
    }, merged[keys + ["gap"]]


def main() -> None:
    summaries: list[dict] = []
    paired: list[dict] = []
    gap_frames: dict[tuple[str, int, str], pd.DataFrame] = {}
    for arm in ("R0", "R1"):
        for update in (0, 50, 100, 200):
            tables = {condition: frame(arm, update, condition) for condition in CONDITIONS}
            for condition, data in tables.items():
                summaries.append({"arm": arm, "update": update, "condition": condition, **condition_summary(data)})
            for index, condition in enumerate(CONDITIONS[1:]):
                result, values = paired_gap(tables["normal"], tables[condition], 25000 + update * 20 + index)
                paired.append({"arm": arm, "update": update, "condition": condition, **result})
                gap_frames[(arm, update, condition)] = values

    difference_rows: list[dict] = []
    for update in (50, 100, 200):
        for index, condition in enumerate(CONDITIONS[1:]):
            keys = ["case", "finding_idx"]
            r0 = gap_frames[("R0", update, condition)].rename(columns={"gap": "gap_r0"})
            r1 = gap_frames[("R1", update, condition)].rename(columns={"gap": "gap_r1"})
            merged = r1.merge(r0, on=keys, validate="one_to_one")
            merged["difference_in_gap"] = merged["gap_r1"] - merged["gap_r0"]
            low, high = clustered_ci(merged, "difference_in_gap", 44000 + update * 20 + index)
            difference_rows.append({
                "update": update,
                "condition": condition,
                "n": int(len(merged)),
                "mean_gap_r0": float(merged["gap_r0"].mean()),
                "mean_gap_r1": float(merged["gap_r1"].mean()),
                "difference_in_gap": float(merged["difference_in_gap"].mean()),
                "ci95_low": low,
                "ci95_high": high,
            })

    table_dir = EXP / "fixed30" / "tables"
    table_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(summaries).to_csv(table_dir / "condition_summary.csv", index=False)
    pd.DataFrame(paired).to_csv(table_dir / "paired_gaps.csv", index=False)
    pd.DataFrame(difference_rows).to_csv(table_dir / "difference_in_gaps.csv", index=False)
    payload = {
        "condition_summary": summaries,
        "paired_gaps": paired,
        "difference_in_gaps": difference_rows,
        "bootstrap": "5000 case-cluster resamples",
        "update0_reused_for_both_arms": True,
    }
    (EXP / "fixed30" / "analysis.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"rows": len(summaries), "paired": len(paired), "gap_differences": len(difference_rows)}))


if __name__ == "__main__":
    main()
