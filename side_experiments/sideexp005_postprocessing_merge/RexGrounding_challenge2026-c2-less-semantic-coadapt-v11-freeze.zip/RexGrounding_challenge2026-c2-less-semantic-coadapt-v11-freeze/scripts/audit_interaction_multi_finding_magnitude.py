#!/usr/bin/env python3
"""Small deterministic multi-finding interaction-magnitude audit.

Runs inference only on one target-centred 192^3 diagnostic patch per selected
fixed30 finding. Ground truth is used solely to choose the crop and to attach
already-available lesion-size metadata; it is never an input to the model.
"""

from __future__ import annotations

import gc
import json
import math
import sys
from pathlib import Path
from typing import Any

import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT, ROOT / "VoxTell"):
    if str(search_path) not in sys.path:
        sys.path.insert(0, str(search_path))

from scripts.diagnose_token_image_text_phase0 import pad_and_crop  # noqa: E402
from scripts.diagnose_token_image_text_phase0b_gate import replace_symlink  # noqa: E402
from scripts.run_voxtell_rex_inference import (  # noqa: E402
    load_image,
    load_reference_mask_for_window_diagnostic,
)
from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402
from voxtell.model.qwen_lora_bica import IndexedFrozenPrefixCache  # noqa: E402


OUT = ROOT / "outputs/image_text_interaction_mechanism_audit/multi_finding_magnitude"
MANIFEST = ROOT / "outputs/image_text_interaction_mechanism_audit/c2/fixed30_manifest.json"
QWEN_PREFIX = ROOT / "outputs/qwen_lora_bica_audit/frozen_prefix_cache/index.json"
MODEL_CONFIGS = {
    "Q-C2": {
        "checkpoint": ROOT / "outputs/qwen_lora_top6_bica_stage3_from_v11/checkpoints/checkpoint_update_5000.pth",
        "metrics": ROOT / "outputs/qwen_lora_top6_bica_stage3_from_v11/fixed30/update_05000/full_volume/update_05000/summary_tables/per_finding_metrics.csv",
        "representation": "qwen",
    },
    "P-M1": {
        "checkpoint": ROOT / "outputs/pbt_medplex_from4800/checkpoints/checkpoint_update_3200.pth",
        "metrics": ROOT / "outputs/pbt_medplex_from4800/fixed30/update_03200/full_volume/update_03200/summary_tables/per_finding_metrics.csv",
        "representation": "pubmedbert_cls",
        "cache": ROOT / "model_assets/text_embedding_analysis/pubmedbert_train_val.pt",
    },
    "B-M2": {
        "checkpoint": ROOT / "outputs/bclip_medplex_from4000/checkpoints/checkpoint_update_3200.pth",
        "metrics": ROOT / "outputs/bclip_medplex_from4000/fixed30/update_03200/full_volume/update_03200/summary_tables/per_finding_metrics.csv",
        "representation": "biomedclip_cls",
        "cache": ROOT / "model_assets/text_embedding_analysis/biomedclip_cls_train_val.pt",
    },
}


def key_frame(path: Path, prefix: str) -> pd.DataFrame:
    frame = pd.read_csv(path).rename(columns={"file": "case_id", "finding_idx": "finding_id"})
    frame["case_id"] = frame["case_id"].astype(str)
    frame["finding_id"] = frame["finding_id"].astype(int)
    return frame[["case_id", "finding_id", "prompt", "category", "gt_voxels", "global_dice", "global_hit"]].rename(
        columns={
            "global_dice": f"{prefix}_dice",
            "global_hit": f"{prefix}_hit",
            "gt_voxels": f"{prefix}_gt_voxels",
            "prompt": f"{prefix}_prompt",
            "category": f"{prefix}_category",
        }
    )


def select_findings(count: int = 10) -> pd.DataFrame:
    c2 = key_frame(MODEL_CONFIGS["Q-C2"]["metrics"], "q_c2")
    m1 = key_frame(MODEL_CONFIGS["P-M1"]["metrics"], "m1")
    m2 = key_frame(MODEL_CONFIGS["B-M2"]["metrics"], "m2")
    merged = c2.merge(m1, on=["case_id", "finding_id"]).merge(m2, on=["case_id", "finding_id"])
    for column in ("prompt", "category", "gt_voxels"):
        values = [merged[f"{prefix}_{column}"] for prefix in ("q_c2", "m1", "m2")]
        if not all(values[0].equals(value) for value in values[1:]):
            raise RuntimeError(f"Fixed30 metadata mismatch for {column}")
    merged["prompt"] = merged["q_c2_prompt"]
    merged["category"] = merged["q_c2_category"]
    merged["gt_voxels"] = merged["q_c2_gt_voxels"]
    merged["mean_normal_dice"] = merged[["q_c2_dice", "m1_dice", "m2_dice"]].mean(axis=1)
    lower = merged["prompt"].str.lower()
    merged["has_left"] = lower.str.contains(r"\bleft\b", regex=True)
    merged["has_right"] = lower.str.contains(r"\bright\b", regex=True)
    merged["has_upper_lobe"] = lower.str.contains("upper lobe", regex=False)
    merged["has_lower_lobe"] = lower.str.contains("lower lobe", regex=False)
    merged["has_middle_lobe"] = lower.str.contains("middle lobe", regex=False)

    chosen: list[int] = []
    reasons: dict[int, list[str]] = {}

    def take(frame: pd.DataFrame, reason: str, n: int = 1) -> None:
        for index in frame.index:
            if index in chosen:
                reasons[index].append(reason)
                continue
            chosen.append(index)
            reasons[index] = [reason]
            if sum(reason in value for value in reasons.values()) >= n:
                break

    stable = ["case_id", "finding_id"]
    take(merged.sort_values(["mean_normal_dice", *stable], ascending=[False, True, True]), "easy_high_dice", 2)
    take(merged.sort_values(["mean_normal_dice", *stable], ascending=[True, True, True]), "hard_low_dice", 2)
    take(merged.sort_values(["gt_voxels", *stable]), "small_lesion")
    take(merged.sort_values(["gt_voxels", *stable], ascending=[False, True, True]), "large_lesion")
    take(merged[merged.has_left].sort_values(stable), "left_sided")
    take(merged[merged.has_right].sort_values(stable), "right_sided")
    take(merged[merged.has_upper_lobe].sort_values(stable), "upper_lobe")
    take(merged[merged.has_lower_lobe].sort_values(stable), "lower_lobe")
    take(merged[merged.has_middle_lobe].sort_values(stable), "middle_lobe")
    # Fill deterministically while favoring categories not represented yet.
    while len(chosen) < count:
        represented = set(merged.loc[chosen, "category"])
        candidates = merged.loc[~merged.index.isin(chosen)].copy()
        candidates["new_category"] = ~candidates["category"].isin(represented)
        candidates["distance_from_median"] = (candidates["mean_normal_dice"] - merged["mean_normal_dice"].median()).abs()
        index = candidates.sort_values(
            ["new_category", "distance_from_median", *stable],
            ascending=[False, False, True, True],
        ).index[0]
        chosen.append(index)
        reasons[index] = ["category_and_difficulty_coverage"]
    # If mandatory coverage exceeded the target, retain all but cap at 12.
    chosen = chosen[:12]
    selected = merged.loc[chosen].copy()
    selected["selection_reason"] = [";".join(reasons[index]) for index in chosen]
    selected["selection_order"] = range(1, len(selected) + 1)
    columns = [
        "selection_order", "case_id", "finding_id", "prompt", "category", "gt_voxels",
        "mean_normal_dice", "q_c2_dice", "q_c2_hit", "m1_dice", "m1_hit", "m2_dice", "m2_hit",
        "has_left", "has_right", "has_upper_lobe", "has_lower_lobe", "has_middle_lobe", "selection_reason",
    ]
    return selected[columns].reset_index(drop=True)


def load_embedding_map(path: Path) -> dict[tuple[str, int], torch.Tensor]:
    payload = torch.load(path, map_location="cpu", weights_only=False, mmap=True)
    values = payload.get("cls_embeddings")
    if values is None:
        raise KeyError(f"No cls_embeddings in {path}")
    return {
        (str(record["case"]), int(record["finding_idx"])): value.float().clone()
        for record, value in zip(payload["records"], values)
    }


def diagnostic_patch(predictor: VoxTellPredictor, record: pd.Series) -> torch.Tensor:
    image, properties = load_image(ROOT / "data/ct_rate_volumes_fixed" / record.case_id)
    preprocessed, bbox, original_shape = predictor.preprocess(image)
    target = load_reference_mask_for_window_diagnostic(
        ROOT / "data/segmentations" / record.case_id,
        1,
        tuple(original_shape),
        bbox,
        image_properties=properties,
        finding_ids=[int(record.finding_id)],
    )[0]
    patch, _target_patch, _starts, _padding = pad_and_crop(preprocessed, target)
    return patch.to(dtype=torch.float32)


def predictor_for(model: str, device: torch.device) -> tuple[VoxTellPredictor, torch.nn.Module]:
    config = MODEL_CONFIGS[model]
    model_dir = OUT / "diagnostic_models" / model.lower().replace("-", "_")
    replace_symlink(model_dir / "plans.json", ROOT / "VoxTell/voxtell_v1.1/plans.json")
    predictor = VoxTellPredictor(
        str(model_dir),
        checkpoint_path=str(config["checkpoint"]),
        device=device,
        load_text_backbone=False,
        text_representation=config["representation"],
        amp_dtype="bfloat16",
    )
    network = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    return predictor, network.eval()


@torch.inference_mode()
def run_q_c2(selected: pd.DataFrame, device: torch.device) -> list[dict[str, Any]]:
    predictor, network = predictor_for("Q-C2", device)
    cache = IndexedFrozenPrefixCache(QWEN_PREFIX)
    rows = []
    for record in selected.itertuples(index=False):
        patch = diagnostic_patch(predictor, record)
        prefix, mask, positions = cache.batch(
            [{"prompt": record.prompt}], device=torch.device("cpu"), dtype=torch.float16
        )
        predictor.predict_sliding_window_return_logits(
            patch,
            torch.zeros((1, 1, 2560), dtype=torch.float32),
            qwen_prefix_hidden=prefix.unsqueeze(0),
            qwen_attention_mask=mask.unsqueeze(0),
            qwen_position_ids=positions.unsqueeze(0),
        )
        audit = dict(network.last_qwen_bica_audit)
        rows.append({
            "case_id": record.case_id,
            "finding_id": int(record.finding_id),
            "prompt": record.prompt,
            "normal_dice": float(record.q_c2_dice),
            "hit": bool(record.q_c2_hit),
            "gt_voxels": int(record.gt_voxels),
            "category": record.category,
            "r_image": float(audit["delta_v_rel_l2"]),
            "r_text": float(audit["delta_t_rel_l2"]),
            "valid_text_tokens": int(audit["valid_text_tokens_min"]),
        })
        print(f"Q-C2 {len(rows)}/{len(selected)} {record.case_id}:{record.finding_id}", flush=True)
    del network, predictor, cache
    gc.collect()
    torch.cuda.empty_cache()
    return rows


@torch.inference_mode()
def run_medplex(model: str, selected: pd.DataFrame, device: torch.device) -> list[dict[str, Any]]:
    predictor, network = predictor_for(model, device)
    config = MODEL_CONFIGS[model]
    embedding_map = load_embedding_map(config["cache"])
    dice_field = "m1_dice" if model == "P-M1" else "m2_dice"
    hit_field = "m1_hit" if model == "P-M1" else "m2_hit"
    rows = []
    for record in selected.itertuples(index=False):
        patch = diagnostic_patch(predictor, record)
        embedding = embedding_map[(record.case_id, int(record.finding_id))]
        predictor.predict_sliding_window_return_logits(
            patch,
            embedding.reshape(1, 1, 768),
            text_prompts=[record.prompt],
        )
        audit = dict(network.last_medplex_audit)
        if len(audit.get("stages", [])) != 4:
            raise RuntimeError(f"{model} did not produce four MedPlex stage audits: {audit}")
        for stage, item in enumerate(audit["stages"], start=1):
            rows.append({
                "case_id": record.case_id,
                "finding_id": int(record.finding_id),
                "prompt": record.prompt,
                "normal_dice": float(getattr(record, dice_field)),
                "hit": bool(getattr(record, hit_field)),
                "gt_voxels": int(record.gt_voxels),
                "category": record.category,
                "stage": stage,
                "gamma_v": float(audit["gamma_image"][stage - 1]),
                "gamma_t": float(audit["gamma_text"][stage - 1]),
                "r_image": float(item["image_relative_l2"]),
                "r_text": float(item["text_relative_l2"]),
                "image_tokens": int(item["image_tokens"]),
                "text_tokens": int(item["text_tokens"]),
            })
        print(f"{model} {len(rows)//4}/{len(selected)} {record.case_id}:{record.finding_id}", flush=True)
    del network, predictor, embedding_map
    gc.collect()
    torch.cuda.empty_cache()
    return rows


def summarize(model: str, frame: pd.DataFrame) -> list[dict[str, Any]]:
    rows = []
    stage_values = ["BiCA"] if model == "Q-C2" else sorted(frame["stage"].unique())
    for stage in stage_values:
        subset = frame if model == "Q-C2" else frame[frame.stage == stage]
        item: dict[str, Any] = {"model": model, "stage": stage, "findings": len(subset)}
        for name in ("r_image", "r_text"):
            values = subset[name].astype(float)
            q1, q3 = values.quantile([0.25, 0.75])
            item.update({
                f"{name}_mean": values.mean(),
                f"{name}_median": values.median(),
                f"{name}_min": values.min(),
                f"{name}_max": values.max(),
                f"{name}_q1": q1,
                f"{name}_q3": q3,
                f"{name}_iqr": q3 - q1,
            })
        rows.append(item)
    return rows


def rank_correlation(left: pd.Series, right: pd.Series) -> float:
    if left.nunique() < 2 or right.nunique() < 2:
        return float("nan")
    return float(left.rank(method="average").corr(right.rank(method="average")))


def relation_rows(model: str, frame: pd.DataFrame) -> list[dict[str, Any]]:
    if model != "Q-C2":
        frame = frame.groupby(["case_id", "finding_id"], as_index=False).agg(
            r_image=("r_image", "max"), r_text=("r_text", "max"),
            normal_dice=("normal_dice", "first"), gt_voxels=("gt_voxels", "first"), hit=("hit", "first"),
        )
    rows = []
    for magnitude in ("r_image", "r_text"):
        rows.extend([
            {"model": model, "magnitude": magnitude, "metadata": "normal_dice", "spearman_rho": rank_correlation(frame[magnitude], frame["normal_dice"]), "n": len(frame)},
            {"model": model, "magnitude": magnitude, "metadata": "gt_voxels", "spearman_rho": rank_correlation(frame[magnitude], frame["gt_voxels"]), "n": len(frame)},
        ])
        for hit, subset in frame.groupby("hit"):
            rows.append({"model": model, "magnitude": magnitude, "metadata": f"mean_when_hit_{bool(hit)}", "spearman_rho": float(subset[magnitude].mean()), "n": len(subset)})
    return rows


def markdown_summary(frame: pd.DataFrame) -> str:
    lines = [
        "| Model | Stage | Image median | Image max | Text median | Text max |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for row in frame.itertuples(index=False):
        lines.append(
            f"| {row.model} | {row.stage} | {row.r_image_median:.6g} | {row.r_image_max:.6g} | "
            f"{row.r_text_median:.6g} | {row.r_text_max:.6g} |"
        )
    return "\n".join(lines)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    selected = select_findings(10)
    selected.to_csv(OUT / "selected_findings.csv", index=False)
    device = torch.device("cuda")
    q_rows = run_q_c2(selected, device)
    pd.DataFrame(q_rows).to_csv(OUT / "q_c2_magnitude.csv", index=False)
    m1_rows = run_medplex("P-M1", selected, device)
    pd.DataFrame(m1_rows).to_csv(OUT / "m1_stage_magnitude.csv", index=False)
    m2_rows = run_medplex("B-M2", selected, device)
    pd.DataFrame(m2_rows).to_csv(OUT / "m2_stage_magnitude.csv", index=False)

    frames = {"Q-C2": pd.DataFrame(q_rows), "P-M1": pd.DataFrame(m1_rows), "B-M2": pd.DataFrame(m2_rows)}
    summary = pd.DataFrame([item for model, frame in frames.items() for item in summarize(model, frame)])
    summary.to_csv(OUT / "magnitude_summary.csv", index=False)
    relations = pd.DataFrame([item for model, frame in frames.items() for item in relation_rows(model, frame)])
    relations.to_csv(OUT / "descriptive_relations.csv", index=False)

    medplex = summary[summary.model.isin(["P-M1", "B-M2"])]
    medplex_consistently_tiny = bool((medplex.r_image_max < 0.001).all())
    candidate_rows = summary[summary.r_image_max >= 0.005]
    q_scale = float(summary.loc[summary.model == "Q-C2", "r_image_median"].iloc[0])
    med_scale = float(medplex.r_image_median.max())
    if medplex_consistently_tiny and candidate_rows.empty:
        conclusion = "A. Tiny interaction magnitude is consistent across findings."
    elif not candidate_rows.empty and candidate_rows.model.nunique() > 1:
        conclusion = "B. Interaction is heterogeneous; a subset shows meaningful image-side writing."
    elif not candidate_rows.empty:
        conclusion = "C. One specific model/stage consistently carries most interaction."
    else:
        conclusion = "A. Tiny interaction magnitude is consistent across MedPlex findings."
    semantic = (
        "A later targeted semantic propagation trace is warranted only for the flagged Q-C2/stage findings; it was not launched."
        if not candidate_rows.empty
        else "No targeted semantic propagation trace is warranted by the 0.5% image-residual criterion."
    )
    relation_lines = []
    for model in frames:
        subset = relations[(relations.model == model) & relations.metadata.isin(["normal_dice", "gt_voxels"]) & (relations.magnitude == "r_image")]
        relation_lines.append(
            f"- {model}: image magnitude vs Dice rho={subset.loc[subset.metadata == 'normal_dice', 'spearman_rho'].iloc[0]:+.3f}; "
            f"vs lesion size rho={subset.loc[subset.metadata == 'gt_voxels', 'spearman_rho'].iloc[0]:+.3f}."
        )
    report = f"""# Multi-finding interaction-magnitude audit

Inference-only audit of {len(selected)} deterministic fixed30 findings. Checkpoints: Q-C2@5000, P-M1@3200, B-M2@3200.

## Magnitude summary

{markdown_summary(summary)}

MedPlex image-side maximum is {medplex.r_image_max.max():.6g} ({100*medplex.r_image_max.max():.4f}%), while Q-C2 median image-side writing is {q_scale:.6g} ({100*q_scale:.3f}%). The largest MedPlex stage median is {med_scale:.6g}.

## Descriptive relationships

These {len(selected)}-finding rank correlations are descriptive only:

{chr(10).join(relation_lines)}

## Decision

{conclusion}

{semantic}
"""
    (OUT / "report.md").write_text(report)
    status = {
        "status": "complete",
        "selected_findings": len(selected),
        "checkpoints": {model: str(config["checkpoint"]) for model, config in MODEL_CONFIGS.items()},
        "medplex_all_image_max_below_0p1_percent": medplex_consistently_tiny,
        "semantic_trace_candidates": candidate_rows[["model", "stage", "r_image_max"]].to_dict("records"),
        "conclusion": conclusion,
    }
    (OUT / "audit_summary.json").write_text(json.dumps(status, indent=2) + "\n")
    print(json.dumps(status, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
