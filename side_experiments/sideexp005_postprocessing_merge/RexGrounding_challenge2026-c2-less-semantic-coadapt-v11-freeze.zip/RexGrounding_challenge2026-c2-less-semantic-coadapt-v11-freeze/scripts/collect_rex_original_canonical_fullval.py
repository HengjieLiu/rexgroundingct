#!/usr/bin/env python
"""Collect sharded original/canonical full-validation prompt audits."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


NUMERIC_FIELDS = {
    "threshold", "dice", "positive_recall", "precision", "fp_volume_mm3",
    "pred_voxels", "gt_voxels", "pred_gt_volume_ratio", "voxel_average_precision",
    "voxel_auroc", "prediction_dice_vs_original_same_threshold",
    "probability_correlation_to_original", "mean_absolute_probability_difference",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-shards", type=int, default=4)
    parser.add_argument("--expected-cases", type=int, default=200)
    parser.add_argument("--expected-findings", type=int, default=381)
    parser.add_argument("--bootstrap-samples", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=2026)
    return parser.parse_args()


def bootstrap_ci(values: np.ndarray, samples: int, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    means = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 500):
        count = min(500, samples - start)
        indices = rng.integers(0, len(values), size=(count, len(values)))
        means[start : start + count] = values[indices].mean(axis=1)
    return tuple(float(value) for value in np.quantile(means, [0.025, 0.975]))


def mean(values) -> float:
    values = np.asarray(list(values), dtype=np.float64)
    return float(np.nanmean(values))


def main() -> int:
    args = parse_args()
    rows = []
    manifests = []
    for shard_id in range(args.expected_shards):
        shard = args.input_dir / f"shard_{shard_id:02d}"
        manifests.append(json.loads((shard / "manifest.json").read_text()))
        with (shard / "per_finding_threshold_metrics.csv").open() as handle:
            for row in csv.DictReader(handle):
                for field in NUMERIC_FIELDS:
                    row[field] = float(row[field])
                row["global_hit"] = row["global_hit"].lower() == "true"
                rows.append(row)

    cases = sorted({row["case"] for row in rows})
    findings = sorted({(row["case"], int(row["finding_idx"])) for row in rows})
    if len(cases) != args.expected_cases or len(findings) != args.expected_findings:
        raise RuntimeError(
            f"Coverage mismatch: cases={len(cases)}/{args.expected_cases}, "
            f"findings={len(findings)}/{args.expected_findings}"
        )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    combined = args.output_dir / "per_finding_threshold_metrics.csv"
    with combined.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    summary = []
    thresholds = sorted({row["threshold"] for row in rows})
    for threshold in thresholds:
        for variant in ("original", "canonical_visual"):
            selected = [row for row in rows if row["threshold"] == threshold and row["variant"] == variant]
            case_dice = {}
            for row in selected:
                case_dice.setdefault(row["case"], []).append(row["dice"])
            summary.append({
                "variant": variant,
                "threshold": threshold,
                "findings": len(selected),
                "cases": len(case_dice),
                "mean_global_dice_per_finding": mean(row["dice"] for row in selected),
                "mean_global_dice_per_case": mean(np.mean(value) for value in case_dice.values()),
                "hit_rate": mean(row["global_hit"] for row in selected),
                "hits": sum(row["global_hit"] for row in selected),
                "mean_precision": mean(row["precision"] for row in selected),
                "mean_recall": mean(row["positive_recall"] for row in selected),
                "mean_pred_voxels": mean(row["pred_voxels"] for row in selected),
                "mean_pred_gt_volume_ratio": mean(row["pred_gt_volume_ratio"] for row in selected),
                "mean_voxel_average_precision": mean(row["voxel_average_precision"] for row in selected),
                "mean_voxel_auroc": mean(row["voxel_auroc"] for row in selected),
            })
    summary_path = args.output_dir / "threshold_summary.csv"
    with summary_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)

    paired = []
    for threshold in thresholds:
        lookup = {
            (row["case"], int(row["finding_idx"]), row["variant"]): row
            for row in rows if row["threshold"] == threshold
        }
        original = np.asarray([lookup[(*key, "original")]["dice"] for key in findings])
        canonical = np.asarray([lookup[(*key, "canonical_visual")]["dice"] for key in findings])
        delta = canonical - original
        original_ap = np.asarray([lookup[(*key, "original")]["voxel_average_precision"] for key in findings])
        canonical_ap = np.asarray([lookup[(*key, "canonical_visual")]["voxel_average_precision"] for key in findings])
        ap_delta = canonical_ap - original_ap
        dice_ci = bootstrap_ci(delta, args.bootstrap_samples, args.seed + int(threshold * 1000))
        ap_ci = bootstrap_ci(ap_delta[np.isfinite(ap_delta)], args.bootstrap_samples, args.seed + 10_000)
        paired.append({
            "threshold": threshold,
            "mean_dice_delta_canonical_minus_original": float(delta.mean()),
            "dice_delta_ci95_low": dice_ci[0],
            "dice_delta_ci95_high": dice_ci[1],
            "improved_findings": int((delta > 1e-8).sum()),
            "tied_findings": int((np.abs(delta) <= 1e-8).sum()),
            "worse_findings": int((delta < -1e-8).sum()),
            "mean_ranking_ap_delta": float(np.nanmean(ap_delta)),
            "ranking_ap_delta_ci95_low": ap_ci[0],
            "ranking_ap_delta_ci95_high": ap_ci[1],
        })
    paired_path = args.output_dir / "paired_prompt_deltas.csv"
    with paired_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(paired[0]))
        writer.writeheader()
        writer.writerows(paired)

    original_at_05 = next(item for item in summary if item["variant"] == "original" and item["threshold"] == 0.5)
    canonical_volume_match = min(
        (item for item in summary if item["variant"] == "canonical_visual"),
        key=lambda item: abs(item["mean_pred_voxels"] - original_at_05["mean_pred_voxels"]),
    )
    best_original = max((item for item in summary if item["variant"] == "original"), key=lambda item: item["mean_global_dice_per_finding"])
    best_canonical = max((item for item in summary if item["variant"] == "canonical_visual"), key=lambda item: item["mean_global_dice_per_finding"])
    ap_delta = paired[0]["mean_ranking_ap_delta"]
    ap_low = paired[0]["ranking_ap_delta_ci95_low"]
    ap_high = paired[0]["ranking_ap_delta_ci95_high"]
    if ap_low > 0:
        interpretation = "Canonical improves threshold-independent voxel ranking, supporting a semantic/spatial benefit."
    elif ap_high < 0:
        interpretation = (
            "Canonical significantly worsens threshold-independent voxel ranking. Its Dice gain therefore comes "
            "primarily from a more conservative operating point/calibration shift, not improved lesion localization."
        )
    elif abs(ap_delta) < 0.002:
        interpretation = "Canonical does not materially improve voxel ranking; any Dice gain is more consistent with calibration/threshold shift."
    else:
        interpretation = "Voxel-ranking evidence is inconclusive; treat the apparent gain as mixed until a broader threshold sweep confirms it."

    report = [
        "# Original vs Canonical Full-Validation Audit",
        "",
        f"- Cases: {len(cases)}",
        f"- Findings: {len(findings)}",
        f"- Thresholds: {', '.join(map(str, thresholds))}",
        "- Compared prompts: original, canonical_visual only",
        "",
        "| Prompt | Threshold | Dice/finding | Dice/case | Hit rate | Precision | Recall | Mean pred voxels | Ranking AP |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for item in summary:
        report.append(
            f"| {item['variant']} | {item['threshold']:.2f} | "
            f"{item['mean_global_dice_per_finding']:.6f} | {item['mean_global_dice_per_case']:.6f} | "
            f"{item['hit_rate']:.6f} | {item['mean_precision']:.6f} | {item['mean_recall']:.6f} | "
            f"{item['mean_pred_voxels']:.1f} | {item['mean_voxel_average_precision']:.6f} |"
        )
    report.extend([
        "",
        "## Calibration Control",
        "",
        f"- Best original threshold: {best_original['threshold']:.2f}, Dice {best_original['mean_global_dice_per_finding']:.6f}.",
        f"- Best canonical threshold: {best_canonical['threshold']:.2f}, Dice {best_canonical['mean_global_dice_per_finding']:.6f}.",
        f"- Canonical threshold closest in mean prediction volume to original@0.50: {canonical_volume_match['threshold']:.2f}, Dice {canonical_volume_match['mean_global_dice_per_finding']:.6f}.",
        "",
        "## Semantic Control",
        "",
        "Ranking AP/AUROC use the same deterministic, class-stratified voxel sample for both prompts. Their absolute values do not represent the natural voxel prevalence; the paired prompt difference is the diagnostic quantity.",
        "",
        f"- Mean canonical-original voxel-ranking AP delta: {ap_delta:+.6f} (95% CI {paired[0]['ranking_ap_delta_ci95_low']:+.6f}, {paired[0]['ranking_ap_delta_ci95_high']:+.6f}).",
        f"- Interpretation: {interpretation}",
        "",
        "No training decision should be made from the earlier 10-case subset alone.",
        "",
    ])
    report_path = args.output_dir / "report.md"
    report_path.write_text("\n".join(report))
    print("\n".join(report))
    print(f"Summary: {summary_path}")
    print(f"Paired deltas: {paired_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
