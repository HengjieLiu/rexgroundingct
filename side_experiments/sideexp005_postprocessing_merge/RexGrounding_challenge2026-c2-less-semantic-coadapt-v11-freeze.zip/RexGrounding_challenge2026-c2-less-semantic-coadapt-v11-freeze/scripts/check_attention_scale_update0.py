#!/usr/bin/env python3
"""GPU update-0 identity check for one arm of the attention-scale screen."""

from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
for directory in (ROOT / "VoxTell", ROOT / "scripts"):
    sys.path.insert(0, str(directory))

import train_voxtell_rex_full_nnunet_aug as train_lib  # noqa: E402
from prepare_attention_scale_screen import make_sampler  # noqa: E402


def build_model(base: dict, checkpoint: dict, device: torch.device, scale: str | None):
    torch.manual_seed(2026)
    model = train_lib.instantiate_voxtell(
        Path(base["model_dir"]), device, deep_supervision=True,
        enable_s3_voxel_text_matching_attention=scale is not None,
        s3_attention_hidden_channels=128,
        s3_rho_mode="fixed", s3_rho_fixed=0.25,
        s3_logit_scale_init=10.0,
        s3_attention_scales=[scale or "1/2"],
    )
    incompatible = model.load_state_dict(checkpoint["network_weights"], strict=scale is None)
    if scale is not None:
        invalid = [
            key for key in incompatible.missing_keys
            if not key.startswith(("s3_attention_gate.", "s3_extra_attention_gates."))
        ]
        if invalid or incompatible.unexpected_keys:
            raise RuntimeError(f"Checkpoint mismatch: missing={invalid}, unexpected={incompatible.unexpected_keys}")
    model.eval()
    return model


@torch.inference_mode()
def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=("control", "1_4", "1_2", "1_1"), required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--parent-args", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--patches", type=int, default=3)
    parser.add_argument("--seed", type=int, default=1701)
    args = parser.parse_args()
    base = json.loads(args.parent_args.read_text())
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    device = torch.device("cuda")
    sampler = make_sampler(base, args.seed)
    batches = []
    for _ in range(args.patches):
        image, embeddings, _, _, meta = sampler.sample()
        batches.append((image, embeddings, meta))

    control = build_model(base, checkpoint, device, None)
    control_logits = []
    for image, embeddings, _ in batches:
        with torch.autocast("cuda", dtype=torch.bfloat16):
            output = control(image[None].to(device), embeddings[None].to(device))[0]
        control_logits.append(output.float().cpu())
    del control
    gc.collect(); torch.cuda.empty_cache()

    scale = None if args.arm == "control" else args.arm.replace("_", "/")
    if scale is None:
        report = {
            "arm": args.arm, "active_scale": None, "patches": args.patches,
            "maximum_absolute_segmentation_logit_difference": 0.0,
            "mean_absolute_probability_difference": 0.0,
            "binary_voxel_difference_threshold_0_5": 0,
            "attention": None, "status": "passed",
        }
    else:
        model = build_model(base, checkpoint, device, scale)
        maximum, probability_sum, probability_count, binary_difference = 0.0, 0.0, 0, 0
        attention_stats = []
        for (image, embeddings, meta), expected in zip(batches, control_logits):
            gate_scale = torch.zeros((1, embeddings.shape[0]), device=device)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                actual = model(
                    image[None].to(device), embeddings[None].to(device),
                    s3_attention_gate_scale=gate_scale,
                )[0].float()
            expected_device = expected.to(device)
            maximum = max(maximum, float((actual - expected_device).abs().max()))
            probability_delta = (actual.sigmoid() - expected_device.sigmoid()).abs()
            probability_sum += float(probability_delta.sum())
            probability_count += probability_delta.numel()
            binary_difference += int(((actual > 0) != (expected_device > 0)).sum())
            maps = model.last_s3_attention_maps[scale]
            values = torch.cat([value.detach().float().flatten() for value in maps])
            attention_stats.append({
                "case_id": meta["case"], "mean": float(values.mean()),
                "min": float(values.min()), "max": float(values.max()),
            })
        tolerance = 1e-5
        report = {
            "arm": args.arm, "active_scale": scale, "patches": args.patches,
            "neutral_initialization": "runtime fixed gate multiplier 0 at update 0",
            "training_activation": "non-learned 20-update linear ramp to canonical fixed rho=0.25",
            "maximum_absolute_segmentation_logit_difference": maximum,
            "mean_absolute_probability_difference": probability_sum / max(1, probability_count),
            "binary_voxel_difference_threshold_0_5": binary_difference,
            "attention": attention_stats,
            "numerical_tolerance": tolerance,
            "status": "passed" if maximum <= tolerance and binary_difference == 0 else "failed",
        }
        if report["status"] != "passed":
            raise RuntimeError(json.dumps(report))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
