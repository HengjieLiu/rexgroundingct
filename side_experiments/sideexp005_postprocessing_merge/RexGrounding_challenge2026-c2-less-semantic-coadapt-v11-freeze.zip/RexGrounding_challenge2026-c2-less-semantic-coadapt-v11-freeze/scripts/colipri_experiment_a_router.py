#!/usr/bin/env python3
"""Experiment A: frozen CoLiPri features for the existing P0 finding router."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import random
import re
import socket
import sys
import time
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import pandas as pd
import torch
import torchio as tio


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import postzoom_routing_pipeline as p0  # noqa: E402

SEED = 20260804
P0_DIR = ROOT / "outputs/dual_s3_postzoom_routing"
ZOOM_DIR = ROOT / "outputs/dual_s3_two_stage_zoom96_bounded_update2000"
PREP_DIR = ROOT / "data/rex_voxtell_preprocessed_v1"
MATCHED_DIR = ROOT / "outputs/colipri_voxtell_matched_alignment_20260804"
COLIPRI_REVISION = "be872ebec5c62894cf183b09835ec6fd7be537f5"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--bootstrap-reps", type=int, default=10_000)
    parser.add_argument("--limit-findings", type=int)
    parser.add_argument(
        "--router-only",
        action="store_true",
        help="Resume OOF routing from an already completed colipri_router_features.csv.",
    )
    parser.add_argument(
        "--colipri-checkpoint",
        type=Path,
        default=Path(
            "./.cache/huggingface/hub/models--microsoft--colipri/"
            "snapshots/be872ebec5c62894cf183b09835ec6fd7be537f5/model.safetensors"
        ),
    )
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def atomic_json(value: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def load_prepare_manifest() -> dict[str, dict]:
    return {
        row["case"]: row
        for row in (json.loads(line) for line in (PREP_DIR / "manifest.jsonl").read_text().splitlines())
    }


SEMANTIC_TERMS = (
    "nodule", "mass", "ground glass", "ground-glass", "consolidation", "atelectasis",
    "bronchiectasis", "bronchial wall", "emphysema", "fibrosis", "scarring", "effusion",
    "pneumothorax", "cyst", "calcification", "honeycomb", "tree-in-bud", "reticular",
)


def semantic_signature(prompt: str) -> tuple[str, ...]:
    normalized = re.sub(r"[^a-z0-9]+", " ", prompt.lower()).strip()
    return tuple(term for term in SEMANTIC_TERMS if term.replace("-", " ") in normalized)


def semantically_distinct(left: str, right: str) -> bool:
    if left.strip().lower() == right.strip().lower():
        return False
    left_signature, right_signature = semantic_signature(left), semantic_signature(right)
    if left_signature and right_signature and set(left_signature) & set(right_signature):
        return False
    left_tokens, right_tokens = set(left.lower().split()), set(right.lower().split())
    union = left_tokens | right_tokens
    return not union or len(left_tokens & right_tokens) / len(union) < 0.5


def deterministic_shuffled_prompts(findings: pd.DataFrame) -> pd.DataFrame:
    records = findings[["finding_key", "file", "prompt"]].sort_values(["file", "finding_key"]).copy()
    all_rows = records.to_dict("records")
    output = []
    for index, row in enumerate(all_rows):
        candidates = [
            item for item in all_rows
            if item["file"] == row["file"]
            and item["finding_key"] != row["finding_key"]
            and semantically_distinct(item["prompt"], row["prompt"])
        ]
        source = "same_case"
        if not candidates:
            candidates = [
                all_rows[(index + offset) % len(all_rows)]
                for offset in range(1, len(all_rows))
                if all_rows[(index + offset) % len(all_rows)]["file"] != row["file"]
                and semantically_distinct(
                    all_rows[(index + offset) % len(all_rows)]["prompt"], row["prompt"]
                )
            ]
            source = "cross_case"
        if not candidates:
            raise RuntimeError(f"No leakage-safe shuffled prompt for {row['finding_key']}")
        chosen = sorted(candidates, key=lambda item: item["finding_key"])[0]
        output.append(
            {
                "finding_key": row["finding_key"],
                "shuffled_prompt": chosen["prompt"],
                "shuffled_prompt_source_key": chosen["finding_key"],
                "shuffled_prompt_source": source,
            }
        )
    return pd.DataFrame(output)


def encode_texts(model, processor, prompts: list[str], device: torch.device) -> dict[str, torch.Tensor]:
    unique = list(dict.fromkeys(prompts))
    output: dict[str, torch.Tensor] = {}
    for start in range(0, len(unique), 64):
        batch = unique[start : start + 64]
        ids, mask = processor.process_text(batch)
        with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            embedded = model.encode_text(ids.to(device), mask.to(device), pool=True, normalize=True)
        for prompt, vector in zip(batch, embedded.float().cpu()):
            output[prompt] = vector
    return output


def score_image(model, image: torch.Tensor, texts: torch.Tensor, device: torch.device) -> np.ndarray:
    with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
        pooled = model.encode_image(
            image[None].to(device), pool=True, project=True, normalize=True
        )
        scores = pooled.float() @ texts.to(device).float().T
    # Autocast may keep the matmul result in BF16 even when its inputs were
    # explicitly promoted. NumPy has no BF16 dtype, so convert after matmul.
    return scores[0].float().cpu().numpy()


def extract_padded(array: np.ndarray, start: tuple[int, int, int], size: int = 96) -> np.ndarray:
    result = np.full((size, size, size), -1000.0, dtype=np.float32)
    source_slices, target_slices = [], []
    for axis, value in enumerate(start):
        lo, hi = max(value, 0), min(value + size, array.shape[axis])
        source_slices.append(slice(lo, hi))
        target_slices.append(slice(lo - value, hi - value))
    result[tuple(target_slices)] = array[tuple(source_slices)]
    return result


def canonical_hu(case: str, prepare: dict[str, dict]) -> tuple[np.ndarray, np.ndarray]:
    record = prepare[case]
    image = nib.as_closest_canonical(nib.load(record.get("image_path", ROOT / "data/ct_rate_volumes_fixed" / case)))
    xyz = np.asanyarray(image.dataobj).astype(np.float32, copy=False)
    dhw = xyz.transpose(2, 1, 0)
    bbox = record.get("crop_bbox", [[0, dhw.shape[0]], [0, dhw.shape[1]], [0, dhw.shape[2]]])
    dhw = dhw[tuple(slice(int(lo), int(hi)) for lo, hi in bbox)]
    spacing_xyz = np.asarray(image.header.get_zooms()[:3], dtype=np.float64)
    return dhw, spacing_xyz


def process_zoom_patch(processor, patch_dhw: np.ndarray, spacing_xyz: np.ndarray) -> torch.Tensor:
    affine = np.diag([*spacing_xyz.tolist(), 1.0])
    subject = tio.Subject(
        image=tio.ScalarImage(
            tensor=torch.from_numpy(np.ascontiguousarray(patch_dhw.transpose(2, 1, 0)))[None],
            affine=affine,
        )
    )
    transformed = processor._image_transform(subject)
    if tuple(transformed.image.shape) != (1, 192, 192, 192):
        raise RuntimeError(f"Unexpected CoLiPri zoom shape: {transformed.image.shape}")
    return transformed.image.data.float()


def extract_features(args: argparse.Namespace) -> pd.DataFrame:
    from colipri import get_model, get_processor

    if not torch.cuda.is_available():
        raise RuntimeError("Experiment A requires one CUDA GPU")
    device = torch.device(args.device)
    torch.cuda.set_device(device)
    findings = pd.read_csv(P0_DIR / "feature_tables/finding_features.csv").sort_values(
        ["file", "finding_idx"]
    )
    if args.limit_findings:
        findings = findings.head(args.limit_findings).copy()
    shuffled = deterministic_shuffled_prompts(findings)
    findings = findings.merge(shuffled, on="finding_key", validate="one_to_one")
    atomic_csv(
        findings[["finding_key", "prompt", "shuffled_prompt", "shuffled_prompt_source_key", "shuffled_prompt_source"]],
        args.output_dir / "shuffled_prompt_manifest.csv",
    )
    prompts = findings.prompt.tolist() + findings.shuffled_prompt.tolist()
    processor = get_processor()
    model = get_model(checkpoint_path=args.colipri_checkpoint).to(device).eval()
    model.requires_grad_(False)
    text = encode_texts(model, processor, prompts, device)
    candidates = pd.read_csv(ZOOM_DIR / "ranked_candidates.csv")
    candidates = candidates[candidates.selected_top3.astype(bool)].sort_values(
        ["case", "finding_idx", "nms_rank"]
    )
    candidate_groups = {
        key: block.to_dict("records")
        for key, block in candidates.groupby(["case", "finding_idx"], sort=False)
    }
    prepare = load_prepare_manifest()
    rows = []
    started = time.perf_counter()
    torch.cuda.reset_peak_memory_stats(device)
    for case_index, (case, block) in enumerate(findings.groupby("file", sort=True), start=1):
        raw_image = tio.ScalarImage(ROOT / "data/ct_rate_volumes_fixed" / case)
        native = processor._image_transform(tio.Subject(image=raw_image)).image.data.float()
        hu, spacing = canonical_hu(case, prepare)
        for row in block.itertuples(index=False):
            prompt_vectors = torch.stack([text[row.prompt], text[row.shuffled_prompt]])
            native_scores = score_image(model, native, prompt_vectors, device)
            correct_zoom, shuffled_zoom = [], []
            for candidate in candidate_groups.get((case, int(row.finding_idx)), []):
                start = tuple(int(candidate[f"roi_requested_{axis}0"]) for axis in "dhw")
                patch = process_zoom_patch(processor, extract_padded(hu, start), spacing)
                score = score_image(model, patch, prompt_vectors, device)
                correct_zoom.append(float(score[0])); shuffled_zoom.append(float(score[1]))
            while len(correct_zoom) < 3:
                correct_zoom.append(float("nan")); shuffled_zoom.append(float("nan"))
            valid_correct = np.asarray([value for value in correct_zoom if np.isfinite(value)])
            valid_shuffled = np.asarray([value for value in shuffled_zoom if np.isfinite(value)])
            order = np.argsort(valid_correct)[::-1] if len(valid_correct) else np.asarray([], dtype=int)
            best_index = int(order[0]) if len(order) else -1
            gap = float(valid_correct[order[0]] - valid_correct[order[1]]) if len(order) > 1 else 0.0
            rows.append(
                {
                    "finding_key": row.finding_key,
                    "file": case,
                    "finding_idx": int(row.finding_idx),
                    "prompt": row.prompt,
                    "shuffled_prompt": row.shuffled_prompt,
                    "colipri_native_correct": float(native_scores[0]),
                    "colipri_native_shuffled": float(native_scores[1]),
                    "colipri_native_prompt_margin": float(native_scores[0] - native_scores[1]),
                    **{f"colipri_zoom_rank{rank + 1}_correct": correct_zoom[rank] for rank in range(3)},
                    **{f"colipri_zoom_rank{rank + 1}_shuffled": shuffled_zoom[rank] for rank in range(3)},
                    "colipri_zoom_correct_max": float(valid_correct.max()) if len(valid_correct) else np.nan,
                    "colipri_zoom_correct_mean": float(valid_correct.mean()) if len(valid_correct) else np.nan,
                    "colipri_zoom_correct_gap12": gap,
                    "colipri_zoom_minus_native": float(valid_correct.max() - native_scores[0]) if len(valid_correct) else np.nan,
                    "colipri_best_zoom_prompt_margin": float(valid_correct[best_index] - valid_shuffled[best_index]) if best_index >= 0 else np.nan,
                    "colipri_zoom_shuffled_max": float(valid_shuffled.max()) if len(valid_shuffled) else np.nan,
                    "colipri_zoom_shuffled_mean": float(valid_shuffled.mean()) if len(valid_shuffled) else np.nan,
                    "colipri_zoom_shuffled_gap12": float(np.sort(valid_shuffled)[-1] - np.sort(valid_shuffled)[-2]) if len(valid_shuffled) > 1 else 0.0,
                    "colipri_zoom_shuffled_minus_native": float(valid_shuffled.max() - native_scores[1]) if len(valid_shuffled) else np.nan,
                    "zoom_roi_count": int(len(valid_correct)),
                }
            )
        print(f"[A feature] {case_index}/{findings.file.nunique()} {case}", flush=True)
    features = pd.DataFrame(rows)
    atomic_csv(features, args.output_dir / "colipri_router_features.csv")
    atomic_json(
        {
            "model": "microsoft/colipri",
            "revision": COLIPRI_REVISION,
            "checkpoint": str(args.colipri_checkpoint.resolve()),
            "checkpoint_sha256": sha256(args.colipri_checkpoint),
            "frozen": all(not parameter.requires_grad for parameter in model.parameters()),
            "native_region": "official CoLiPri whole-CT RAS/2mm/192^3",
            "zoom_region": "P0 predicted native-96 ROI, converted from the same original HU physical crop then official CoLiPri transform",
            "runtime_seconds": time.perf_counter() - started,
            "peak_gpu_memory_gib": torch.cuda.max_memory_allocated(device) / 2**30,
            "gpu": torch.cuda.get_device_name(device),
            "host": socket.gethostname(),
            "slurm_job_id": os.environ.get("SLURM_JOB_ID", ""),
        },
        args.output_dir / "feature_provenance.json",
    )
    return features


CORRECT_FEATURES = [
    "colipri_native_correct",
    "colipri_zoom_rank1_correct",
    "colipri_zoom_rank2_correct",
    "colipri_zoom_rank3_correct",
    "colipri_zoom_correct_max",
    "colipri_zoom_correct_mean",
    "colipri_zoom_minus_native",
    "colipri_zoom_correct_gap12",
    "colipri_native_prompt_margin",
    "colipri_best_zoom_prompt_margin",
    "zoom_roi_count",
]


def control_features(features: pd.DataFrame) -> pd.DataFrame:
    result = features[["finding_key"]].copy()
    mapping = {
        "colipri_native_correct": "colipri_native_shuffled",
        "colipri_zoom_rank1_correct": "colipri_zoom_rank1_shuffled",
        "colipri_zoom_rank2_correct": "colipri_zoom_rank2_shuffled",
        "colipri_zoom_rank3_correct": "colipri_zoom_rank3_shuffled",
        "colipri_zoom_correct_max": "colipri_zoom_shuffled_max",
        "colipri_zoom_correct_mean": "colipri_zoom_shuffled_mean",
        "colipri_zoom_minus_native": "colipri_zoom_shuffled_minus_native",
        "colipri_zoom_correct_gap12": "colipri_zoom_shuffled_gap12",
        "colipri_native_prompt_margin": "colipri_native_prompt_margin",
        "colipri_best_zoom_prompt_margin": "colipri_best_zoom_prompt_margin",
        "zoom_roi_count": "zoom_roi_count",
    }
    for target, source in mapping.items():
        sign = -1.0 if target in {"colipri_native_prompt_margin", "colipri_best_zoom_prompt_margin"} else 1.0
        result[target] = sign * features[source]
    return result


def case_bootstrap_difference(left: pd.DataFrame, right: pd.DataFrame, reps: int) -> dict[str, float]:
    joined = left[["file", "finding_key", "dice"]].merge(
        right[["finding_key", "dice"]], on="finding_key", suffixes=("_left", "_right"), validate="one_to_one"
    )
    per_case = joined.assign(delta=joined.dice_left - joined.dice_right).groupby("file").delta.mean().to_numpy()
    rng = np.random.default_rng(SEED)
    draws = rng.choice(per_case, size=(reps, len(per_case)), replace=True).mean(axis=1)
    return {
        "estimate": float(per_case.mean()),
        "ci95_low": float(np.quantile(draws, 0.025)),
        "ci95_high": float(np.quantile(draws, 0.975)),
        "cases": int(len(per_case)),
        "replicates": int(reps),
    }


def summarize(name: str, frame: pd.DataFrame, native: pd.DataFrame, original: pd.DataFrame) -> dict[str, Any]:
    by_key_native = native.set_index("finding_key")
    by_key_original = original.set_index("finding_key")
    current = frame.set_index("finding_key")
    baseline_hit = by_key_native.loc[current.index, "hit"].astype(int)
    original_hit = by_key_original.loc[current.index, "hit"].astype(int)
    hit = current.hit.astype(int)
    gt = current.pixels.astype(float)
    approximate_tp = current.dice * (current.predicted_voxels + gt) / 2.0
    return {
        "setting": name,
        "findings": len(current),
        "mean_dice": float(current.dice.mean()),
        "median_dice": float(current.dice.median()),
        "hits": int(hit.sum()),
        "new_hits_vs_native": int(((hit == 1) & (baseline_hit == 0)).sum()),
        "lost_hits_vs_native": int(((hit == 0) & (baseline_hit == 1)).sum()),
        "new_hits_vs_A0": int(((hit == 1) & (original_hit == 0)).sum()),
        "lost_hits_vs_A0": int(((hit == 0) & (original_hit == 1)).sum()),
        "mean_predicted_voxels": float(current.predicted_voxels.mean()),
        "mean_fp_voxels_derived": float((current.predicted_voxels - approximate_tp).clip(lower=0).mean()),
        "fraction_routed_to_zoom": float(current.get("router_selected", pd.Series(0, index=current.index)).mean()),
    }


def evaluate_router(args: argparse.Namespace, features: pd.DataFrame) -> None:
    base = pd.read_csv(P0_DIR / "feature_tables/finding_features.csv")
    folds = pd.read_csv(P0_DIR / "fold_assignments.csv")
    a0 = pd.read_csv(P0_DIR / "binary_router_oof_per_finding.csv")
    # The report publishes six decimals, while the current CSV stores the exact
    # value 0.2742377445992087. Verify the published baseline at its precision.
    if len(base) != 381 or abs(base.baseline_dice.mean() - 0.274238) > 1e-6:
        raise RuntimeError("P0 native baseline reproduction failed")
    if abs(a0.dice.mean() - 0.27891622651020864) > 1e-9 or int(a0.hit.sum()) != 265:
        raise RuntimeError("P0 binary-router reproduction failed")
    merged = base.merge(features, on=["finding_key", "file", "finding_idx", "prompt"], validate="one_to_one")
    id_columns = [column for column in base.columns if column in p0.ID_COLS]
    a1_input = merged[id_columns + CORRECT_FEATURES].copy()
    a2_input = merged.copy()
    shuffled = control_features(features)
    a3_input = base.merge(shuffled, on="finding_key", validate="one_to_one")
    a1 = p0.nested_finding_router(a1_input, folds)
    a2 = p0.nested_finding_router(a2_input, folds)
    a3 = p0.nested_finding_router(a3_input, folds)
    variants = {"A0_existing_p0": a0, "A1_colipri_only": a1, "A2_p0_plus_correct_colipri": a2, "A3_p0_plus_shuffled_colipri": a3}
    for name, frame in variants.items():
        atomic_csv(frame, args.output_dir / "oof" / f"{name}.csv")
    native = base.assign(
        dice=base.baseline_dice, hit=base.baseline_hit, predicted_voxels=base.baseline_predicted_voxels
    )
    rows = [summarize("native192", native, native, a0)]
    rows.extend(summarize(name, frame, native, a0) for name, frame in variants.items())
    summary = pd.DataFrame(rows)
    atomic_csv(summary, args.output_dir / "router_summary.csv")
    comparisons = {
        "A2_minus_native": case_bootstrap_difference(a2, native, args.bootstrap_reps),
        "A2_minus_A0": case_bootstrap_difference(a2, a0, args.bootstrap_reps),
        "A2_minus_A3": case_bootstrap_difference(a2, a3, args.bootstrap_reps),
    }
    atomic_json(comparisons, args.output_dir / "bootstrap.json")

    metadata = pd.read_csv(MATCHED_DIR / "matched_roi_manifest.csv")
    entity_counts = metadata.groupby(["case_id", "entity"]).size()
    same_entity_keys = set(
        metadata.assign(
            key=metadata.case_id + "|" + metadata.finding_idx.astype(int).astype(str),
            repeated=[entity_counts.loc[(row.case_id, row.entity)] > 1 for row in metadata.itertuples()],
        ).loc[lambda frame: frame.repeated, "key"]
    )
    subgroup_rows = []
    for name, frame in variants.items():
        frame = frame.copy()
        frame["multi"] = frame.file.map(frame.groupby("file").size()).gt(1)
        frame["same_entity"] = frame.finding_key.isin(same_entity_keys)
        masks = {
            "single_finding": ~frame.multi,
            "multi_finding": frame.multi,
            "same_case_same_entity": frame.same_entity,
            **{f"size_{value}": frame.size_bin.eq(value) for value in sorted(frame.size_bin.dropna().unique())},
            **{f"focality_{value}": frame.focality.eq(value) for value in sorted(frame.focality.dropna().unique())},
        }
        for subgroup, mask in masks.items():
            block = frame.loc[mask]
            if len(block):
                original_block = a0.set_index("finding_key").loc[block.finding_key]
                subgroup_rows.append(
                    {
                        "setting": name,
                        "subgroup": subgroup,
                        "findings": len(block),
                        "mean_dice": float(block.dice.mean()),
                        "delta_vs_A0": float(block.dice.to_numpy().mean() - original_block.dice.mean()),
                        "hits": int(block.hit.sum()),
                    }
                )
    subgroup = pd.DataFrame(subgroup_rows)
    atomic_csv(subgroup, args.output_dir / "subgroup_summary.csv")
    values = summary.set_index("setting")
    a2_row, a0_row, a3_row = (values.loc[key] for key in ("A2_p0_plus_correct_colipri", "A0_existing_p0", "A3_p0_plus_shuffled_colipri"))
    a2_sub = subgroup[subgroup.setting.eq("A2_p0_plus_correct_colipri")].set_index("subgroup")
    go = bool(
        a2_row.mean_dice > a0_row.mean_dice
        and a2_row.mean_dice > a3_row.mean_dice
        and a2_row.hits >= a0_row.hits
        and comparisons["A2_minus_A0"]["ci95_low"] > 0
        and all(a2_sub.loc[name, "delta_vs_A0"] >= -0.002 for name in ("multi_finding", "same_case_same_entity") if name in a2_sub.index)
    )
    clear_no_go = bool(
        comparisons["A2_minus_A0"]["ci95_high"] <= 0
        or (
            a2_row.mean_dice <= a0_row.mean_dice
            and a2_row.mean_dice <= a3_row.mean_dice
        )
    )
    verdict = "GO" if go else ("NO-GO" if clear_no_go else "INCONCLUSIVE")
    report = [
        "# CoLiPri Experiment A: Finding-level P0 Router",
        "",
        f"**Verdict: {verdict}.**",
        "",
        "This inference-only experiment asks whether frozen CoLiPri scalar alignment features add incremental OOF routing utility. It does not test component selection or segmentation training.",
        "",
        "## OOF results",
        "",
        p0.markdown_table(summary),
        "",
        "## Paired case bootstrap",
        "",
        "```json",
        json.dumps(comparisons, indent=2),
        "```",
        "",
        "## Correct versus shuffled semantic control",
        "",
        f"A2 minus A3 Dice: {comparisons['A2_minus_A3']['estimate']:+.6f}, 95% CI [{comparisons['A2_minus_A3']['ci95_low']:+.6f}, {comparisons['A2_minus_A3']['ci95_high']:+.6f}].",
        "",
        "## Subgroups",
        "",
        p0.markdown_table(subgroup),
        "",
        "## Integrity",
        "",
        "- Exact original P0 folds and nested threshold/model-selection policy reused.",
        "- Category, focality, GT size, and all GT-derived quantities excluded from router inputs.",
        "- CoLiPri and VoxTell checkpoints were frozen; only CPU OOF router models were fit.",
        "- Original free-text prompts and a fixed same-case-preferred shuffled control were used.",
    ]
    report_path = ROOT / "reports/colipri_experiment_A_router.md"
    report_path.write_text("\n".join(report) + "\n")
    atomic_json({"verdict": verdict, "report": str(report_path), "comparisons": comparisons}, args.output_dir / "result.json")
    print(json.dumps({"verdict": verdict, "summary": rows, "comparisons": comparisons}, indent=2), flush=True)


def main() -> int:
    args = parse_args()
    args.output_dir = args.output_dir.resolve()
    if args.router_only:
        feature_path = args.output_dir / "colipri_router_features.csv"
        if not feature_path.exists():
            raise FileNotFoundError(feature_path)
        evaluate_router(args, pd.read_csv(feature_path))
        return 0
    if args.output_dir.exists():
        raise FileExistsError(f"Refusing to overwrite {args.output_dir}")
    args.output_dir.mkdir(parents=True)
    random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
    features = extract_features(args)
    evaluate_router(args, features)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
