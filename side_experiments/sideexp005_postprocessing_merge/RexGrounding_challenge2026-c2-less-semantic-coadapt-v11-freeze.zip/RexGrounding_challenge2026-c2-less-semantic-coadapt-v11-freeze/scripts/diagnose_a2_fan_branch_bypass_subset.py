#!/usr/bin/env python3
"""Tiny A2-FAN normal-vs-FAN-bypass patch diagnostic on fixed records."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any

import torch

ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT, ROOT / "VoxTell"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from scripts.diagnose_token_image_text_phase0 import (  # noqa: E402
    key,
    load_image,
    load_maps,
    load_reference_mask_for_window_diagnostic,
    pad_and_crop,
)
from scripts.diagnose_token_image_text_phase0b_gate import (  # noqa: E402
    make_predictor,
    run_model,
    selected_records,
)
from scripts.run_controlled_fixed30_validation import DEFAULT_CACHE, build_manifest  # noqa: E402


EXP = ROOT / "outputs/token_attention_common_init_pilot"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint250", type=Path, default=EXP / "A2_FAN/checkpoints/checkpoint_update_250.pth")
    parser.add_argument("--checkpoint500", type=Path, default=EXP / "A2_FAN/checkpoints/checkpoint_update_500.pth")
    parser.add_argument("--output-dir", type=Path, default=EXP / "a2_fan_250_500_diagnosis/branch_bypass")
    parser.add_argument("--max-findings", type=int, default=8)
    parser.add_argument(
        "--token-cache",
        type=Path,
        default=ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt",
    )
    parser.add_argument("--pooled-cache", type=Path, default=DEFAULT_CACHE)
    parser.add_argument(
        "--selected-findings",
        type=Path,
        default=ROOT
        / "outputs/prompt_standardization_rule_only_v1"
        / "stratified30_six_variant_ablation_v1"
        / "prepared_inputs/selected_findings.csv",
    )
    parser.add_argument("--dataset-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    return parser.parse_args()


def dice_stats(logits: torch.Tensor, target: torch.Tensor) -> dict[str, float | int]:
    probs = torch.sigmoid(logits.detach().float().cpu())
    pred = probs > 0.5
    truth = target.detach().cpu().bool()
    intersection = int((pred & truth).sum().item())
    pred_voxels = int(pred.sum().item())
    truth_voxels = int(truth.sum().item())
    denom = pred_voxels + truth_voxels
    return {
        "patch_dice": float(2.0 * intersection / denom) if denom else 1.0,
        "patch_hit": bool(intersection > 0),
        "tp_voxels": intersection,
        "pred_voxels": pred_voxels,
        "target_voxels": truth_voxels,
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    keys: list[str] = []
    for row in rows:
        for key_name in row:
            if key_name not in keys:
                keys.append(key_name)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.experiment_dir = args.output_dir / "manifest_build"
    args.experiment_dir.mkdir(parents=True, exist_ok=True)
    manifest_path, _, selection_sha = build_manifest(args)
    records = selected_records(json.loads(manifest_path.read_text()), args.max_findings)
    token_map, pooled_map = load_maps(args.token_cache, args.pooled_cache)
    device = torch.device("cuda")
    rows: list[dict[str, Any]] = []
    for update, checkpoint in ((250, args.checkpoint250), (500, args.checkpoint500)):
        predictor = make_predictor(args.output_dir, f"A2_FAN_u{update}", checkpoint.resolve(), device)
        model = predictor.network.eval().to(device)
        original_mode = getattr(model, "fan_image_text_mode", "none")
        if original_mode == "none":
            raise RuntimeError(f"{checkpoint} did not instantiate A2-FAN")
        for record in records:
            cache_key = key(record)
            token = token_map[cache_key]
            image, properties = load_image(ROOT / "data/ct_rate_volumes_fixed" / record["case"])
            data, bbox, original_shape = predictor.preprocess(image)
            target = load_reference_mask_for_window_diagnostic(
                ROOT / "data/segmentations" / record["case"],
                1,
                tuple(original_shape),
                bbox,
                image_properties=properties,
                finding_ids=[record["finding_idx"]],
            )[0]
            patch, target_patch, starts, padding = pad_and_crop(data, target)
            pooled = pooled_map[cache_key][None, None].to(device)
            contextual = token["feature"][None, None].to(device)
            valid = torch.ones(contextual.shape[:3], dtype=torch.bool, device=device)
            normal_logits = run_model(
                model,
                patch[None].to(device),
                pooled,
                contextual,
                valid,
                torch.bfloat16,
            )
            normal = dice_stats(normal_logits, target_patch)
            rows.append(
                {
                    "update": update,
                    "mode": "normal_fan_enabled",
                    "case": record["case"],
                    "finding_idx": int(record["finding_idx"]),
                    "prompt": record["prompt"],
                    "crop_start_after_padding": starts,
                    "padding_wxyz_pairs": padding,
                    **normal,
                }
            )
            model.fan_image_text_mode = "none"
            bypass_logits = run_model(
                model,
                patch[None].to(device),
                pooled,
                None,
                None,
                torch.bfloat16,
            )
            bypass = dice_stats(bypass_logits, target_patch)
            rows.append(
                {
                    "update": update,
                    "mode": "fan_bypass_use_original_visual_path",
                    "case": record["case"],
                    "finding_idx": int(record["finding_idx"]),
                    "prompt": record["prompt"],
                    "crop_start_after_padding": starts,
                    "padding_wxyz_pairs": padding,
                    **bypass,
                }
            )
            model.fan_image_text_mode = original_mode
        del model, predictor
        torch.cuda.empty_cache()
    write_csv(args.output_dir / "branch_bypass_patch_metrics.csv", rows)
    frame = []
    import pandas as pd

    df = pd.DataFrame(rows)
    for update, update_df in df.groupby("update"):
        wide = update_df.pivot_table(
            index=["case", "finding_idx", "prompt"],
            columns="mode",
            values=["patch_dice", "pred_voxels"],
            aggfunc="first",
        )
        normal = wide[("patch_dice", "normal_fan_enabled")]
        bypass = wide[("patch_dice", "fan_bypass_use_original_visual_path")]
        frame.append(
            {
                "update": int(update),
                "n": int(len(wide)),
                "normal_mean_patch_dice": float(normal.mean()),
                "bypass_mean_patch_dice": float(bypass.mean()),
                "bypass_minus_normal_mean_patch_dice": float((bypass - normal).mean()),
                "normal_mean_pred_voxels": float(wide[("pred_voxels", "normal_fan_enabled")].mean()),
                "bypass_mean_pred_voxels": float(wide[("pred_voxels", "fan_bypass_use_original_visual_path")].mean()),
            }
        )
    summary = {
        "selected_findings_sha256": selection_sha,
        "precision": "bfloat16",
        "diagnostic_scope": "GT-centered 192^3 patches, not official full-volume fixed30",
        "summary": frame,
    }
    (args.output_dir / "branch_bypass_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
