#!/usr/bin/env python3
"""Freeze a read-only audit of the formal A5-Contrast E4 experiment.

This script deliberately does not import or construct the model.  It validates
the persisted run configuration/result and records source/checkpoint hashes.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/anatomy_dual_audit/a5_implementation_audit"
RUN = ROOT / "outputs/original_voxtell_semantic_screen_1k/a5_contrast_e4"
SOURCE = ROOT / "scripts/original_voxtell_semantic_screen_losses.py"
TRAINER = ROOT / "scripts/train_voxtell_rex_full_nnunet_aug.py"
LAUNCHER = ROOT / "scripts/train_original_voxtell_semantic_screen_1k.sbatch"
CKPT = RUN / "checkpoints/checkpoint_update_1000.pth"
INFERENCE_CKPT = RUN / "full200_exports/checkpoint_update_1000_inference.pth"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def command(*args: str) -> str:
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    args = json.loads((RUN / "args.json").read_text())
    config = json.loads((RUN / "config/semantic_screen.json").read_text())
    summary = json.loads((RUN / "full200_1000/summary.json").read_text())
    optimizer = json.loads((RUN / "optimizer_group_audit.json").read_text())

    expected = {
        "semantic_screen_mode": "a5_contrast_e4",
        "semantic_screen_dim": 128,
        "semantic_screen_lambda": 0.05,
        "semantic_screen_lr": 1e-4,
        "semantic_screen_contrast_temperature": 0.07,
        "fan_image_text_mode": "none",
        "less_encoder_mode": "none",
        "token_image_text_mode": "original",
    }
    mismatches = {
        key: {"expected": value, "actual": args.get(key)}
        for key, value in expected.items()
        if args.get(key) != value
    }
    if mismatches:
        raise RuntimeError(f"Formal A5 configuration mismatch: {mismatches}")
    if summary["total_cases"] != 200 or summary["total_findings"] != 381:
        raise RuntimeError("A5 Full200 result is not canonical 200/381")
    if summary["total_hits"] != 278:
        raise RuntimeError("Unexpected A5 HIT count")
    if abs(summary["mean_global_dice_per_finding"] - 0.28535922133268327) > 1e-12:
        raise RuntimeError("Unexpected A5 Full200 Dice")
    if optimizer.get("status") != "pass" or optimizer.get("missing_trainable_parameters"):
        raise RuntimeError("Formal optimizer coverage audit did not pass")

    audit = {
        "formal_identity": {
            "experiment": "A5-Contrast E4",
            "training_job_id": 5754641,
            "training_checkpoint": str(CKPT.resolve()),
            "inference_checkpoint": str(INFERENCE_CKPT.resolve()),
            "run_config": str((RUN / "args.json").resolve()),
            "semantic_config": str((RUN / "config/semantic_screen.json").resolve()),
            "full200_summary": str((RUN / "full200_1000/summary.json").resolve()),
            "checkpoint_sha256": sha256(CKPT),
            "inference_checkpoint_sha256": sha256(INFERENCE_CKPT),
            "args_sha256": sha256(RUN / "args.json"),
            "semantic_config_sha256": sha256(RUN / "config/semantic_screen.json"),
        },
        "source": {
            "loss_and_head": str(SOURCE.resolve()),
            "head_lines": "29-69",
            "capture_lines": "116-157",
            "coordinate_lines": "160-189",
            "occupancy_lines": "192-203",
            "symmetric_loss_lines": "238-243",
            "contrast_objective_lines": "246-301",
            "trainer": str(TRAINER.resolve()),
            "model_setup_lines": "17005-17040",
            "loss_call_lines": "18787-18863",
            "optimizer_group_lines": "3223-3228, 3508-3524",
            "launcher": str(LAUNCHER.resolve()),
            "launcher_arm_lines": "53-63",
            "launcher_shared_config_lines": "109-146",
            "current_source_hashes": {
                str(SOURCE.relative_to(ROOT)): sha256(SOURCE),
                str(TRAINER.relative_to(ROOT)): sha256(TRAINER),
                str(LAUNCHER.relative_to(ROOT)): sha256(LAUNCHER),
            },
        },
        "run_provenance": {
            "launch_parent_commit_from_reflog": "1e33f6eec575cc2a1788a39a71877517bcd663f8",
            "launch_branch_from_reflog": "original-voxtell-wholefinding-semantic",
            "provenance_quality": "PARTIAL",
            "limitation": (
                "The A5 scientific scripts were untracked and the trainer was subsequently "
                "modified. The Slurm job did not persist a source snapshot/hash, so the exact "
                "loaded Python bytes cannot be proven from Git alone. Persisted args, checkpoint, "
                "optimizer audit, source behavior, file timestamps, and result identity agree."
            ),
            "audit_time_parent_commit": command("git", "rev-parse", "HEAD"),
            "audit_time_branch": command("git", "branch", "--show-current"),
        },
        "implementation": {
            "visual_feature": "native original-VoxTell encoder skip output[4] (E4)",
            "visual_shape_for_192_cubed_patch": [1, 320, 12, 12, 12],
            "position": "patient/preprocessed-grid voxel-centre LR/AP/SI coordinates in [-1,1]",
            "regional_pooling_mask": (
                "precomputed five-lobe TotalSegmentator-derived anatomy labels, average-pooled "
                "to E4 occupancy; not the finding lesion GT mask"
            ),
            "regions": ["right lung", "left lung", "RUL", "RML", "RLL", "LUL", "LLL"],
            "text_queries": (
                "seven standalone frozen-Qwen3-Embedding-4B phrase vectors from "
                "qwen_anatomy_phrase_embeddings.pt, projected 2560->128; not finding tokens"
            ),
            "visual_head": (
                "normalize(Conv1x1(E4) concatenated with Conv1x1(position) -> "
                "Conv1x1/GELU/Conv1x1)"
            ),
            "region_vector": "occupancy-weighted mean of the normalized 128-D semantic map, then L2 normalization",
            "similarity": "cosine similarity divided by temperature 0.07",
            "side_task": "2x2 region/phrase matrix",
            "lobe_task": "5x5 region/phrase matrix",
            "loss": (
                "L_aux=0.5*L_side+0.5*L_lobe; each L is "
                "0.5*(CE region->phrase + CE phrase->region); "
                "L_total=L_seg+0.05*L_aux"
            ),
            "inactive_rule": "skip the entire contrastive anatomy loss unless all seven region supports are nonempty",
            "dense_auxiliary_loss_active": False,
            "configured_but_unused_dense_temperature": 0.15,
            "writeback_to_segmentation": False,
            "gradient_route": (
                "auxiliary gradients update the A5 head and flow through E4 into encoder stage 4 "
                "and earlier shared encoder stages; they do not directly enter Prompt Decoder or "
                "decoder parameters. Segmentation gradients continue through the native E4 skip."
            ),
            "optimizer_groups": optimizer["group_summaries"],
        },
        "mtc_checklist": {
            "regional_visual_features_aligned_to_anatomy_phrases": "YES",
            "row_and_column_normalized_matching_loss": "YES",
            "multiple_regions_from_same_image": "YES",
            "within_image_anatomical_negatives": "YES",
            "standalone_anatomy_phrases": "YES",
            "no_gt_or_anatomy_masks_at_inference": "YES",
            "gradients_enter_shared_visual_segmentation_branch": "YES",
        },
        "formal_result": {
            "full200_dice": summary["mean_global_dice_per_finding"],
            "hit": summary["total_hits"],
            "findings": summary["total_findings"],
            "cases": summary["total_cases"],
            "threshold": summary["threshold"],
        },
        "verdict": "SUBSTANTIALLY_EQUIVALENT_TO_REGION_PHRASE_MTC_STYLE",
        "verdict_qualification": (
            "The objective has the central MTC mechanics (same-image regional visual vectors, "
            "standalone anatomy phrase vectors, symmetric row/column CE, and within-image "
            "negatives). It is not a literal paper reproduction: the visual vectors come from a "
            "learned E4+position head, regions use TotalSegmentator-derived anatomy occupancy, "
            "and the implementation splits side and lobe matrices rather than one joint matrix."
        ),
    }
    (OUT / "audit.json").write_text(json.dumps(audit, indent=2) + "\n")

    checklist = "\n".join(
        f"| {item.replace('_', ' ')} | {answer} |"
        for item, answer in audit["mtc_checklist"].items()
    )
    report = f"""# Formal A5-Contrast E4 implementation audit

## Identity and result

- Formal training job: `5754641` (`COMPLETED`, 1000 optimizer updates).
- Training checkpoint: `{CKPT.resolve()}`.
- Inference export: `{INFERENCE_CKPT.resolve()}`.
- Canonical raw Full200: **Dice {summary['mean_global_dice_per_finding']:.5f}, HIT {summary['total_hits']}/{summary['total_findings']}**.
- This is `a5_contrast_e4`, not the older A1-A5 probe and not `a5_dense_e4`.

## Exact computation

For a 192^3 training crop, native encoder E4 is `F in R^(1x320x12x12x12)`.  The implementation computes

```text
Z(x) = normalize(MLP_1x1([Conv_1x1(F(x)) || Conv_1x1(position(x))]))
t_k  = normalize(W_text q_k)
r_k  = normalize(sum_x occupancy_k(x) Z(x) / sum_x occupancy_k(x))
S_side = [r_right;r_left] [t_right;t_left]^T / 0.07
S_lobe = [r_RUL;r_RML;r_RLL;r_LUL;r_LLL]
         [t_RUL;t_RML;t_RLL;t_LUL;t_LLL]^T / 0.07
L_side = 0.5 (CE_rows(S_side) + CE_cols(S_side))
L_lobe = 0.5 (CE_rows(S_lobe) + CE_cols(S_lobe))
L_total = L_seg + 0.05 * (0.5 L_side + 0.5 L_lobe)
```

The regional masks are the five precomputed TotalSegmentator-derived lobe masks, occupancy-pooled to E4; right/left lungs are lobe unions. **The finding lesion GT is not used to pool A5 regional vectors.** All seven anatomy supports must be nonempty in the crop or the whole contrastive term is skipped.

The seven text queries are standalone frozen-Qwen phrase embeddings (`right`, `left`, and five full lobe names), projected 2560->128. They are not tokens from the current finding. The loss is symmetric region-to-phrase and phrase-to-region CE. There is no dense BCE/Dice anatomy loss in this arm; the configured `a5_temperature=0.15` belongs to the Dense sibling and is unused here.

## Gradient topology

The auxiliary head only reads E4 and does not write into the segmentation forward. Its gradients update the 418,432-parameter semantic head and flow into native E4 and earlier shared encoder stages. They do not directly update the Prompt Decoder or decoder through the auxiliary branch. E4 is nevertheless a native segmentation skip, so the same visual representation is jointly constrained by segmentation. Optimizer coverage passed with encoder LR 1e-5, decoder LR 1e-4, and semantic-head LR 1e-4.

## MTC-style checklist

| Criterion | Result |
|---|---|
{checklist}

## Verdict

**SUBSTANTIALLY EQUIVALENT TO REGION-PHRASE MTC STYLE**, not a literal paper reproduction. It contains the central mechanism: same-image regional vectors, standalone anatomy phrases, symmetric row/column contrast, and within-image anatomical negatives. Differences are the learned E4+patient-position head, TotalSegmentator-derived occupancy regions, and separate 2x2 side plus 5x5 lobe matrices.

## Provenance limitation

Git reflog places the launch at parent commit `1e33f6eec575cc2a1788a39a71877517bcd663f8` on `original-voxtell-wholefinding-semantic`. However the scientific scripts were untracked and the trainer was later edited; the Slurm job did not save an exact source snapshot. Therefore exact Git-byte provenance is **PARTIAL**, even though persisted args/checkpoint/config/optimizer audit and the formal result uniquely identify the executed arm. Current source hashes are in `audit.json`.
"""
    (OUT / "report.md").write_text(report)
    print(json.dumps({"status": "PASS", "output": str(OUT), "verdict": audit["verdict"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
