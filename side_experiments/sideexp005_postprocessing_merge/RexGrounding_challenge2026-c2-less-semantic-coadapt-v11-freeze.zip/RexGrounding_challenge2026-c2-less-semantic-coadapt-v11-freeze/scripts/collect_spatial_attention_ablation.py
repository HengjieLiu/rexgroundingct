#!/usr/bin/env python3
"""Collect spatial-attention ablation summaries."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def load_summary(run_dir: Path) -> dict:
    with (run_dir / "summary.json").open() as f:
        summary = json.load(f)
    return summary


def category_dice(run_dir: Path, category: str) -> float:
    df = pd.read_csv(run_dir / "per_category_metrics.csv")
    row = df.loc[df["category"].astype(str) == category]
    return float(row.iloc[0]["mean_dice"]) if not row.empty else float("nan")


def category_hit(run_dir: Path, category: str) -> float:
    df = pd.read_csv(run_dir / "per_category_metrics.csv")
    row = df.loc[df["category"].astype(str) == category]
    return float(row.iloc[0]["hit_rate"]) if not row.empty else float("nan")


def decompose_2d(label: str, run_dir: Path) -> dict:
    df = pd.read_csv(run_dir / "per_finding_metrics.csv")
    sub = df.loc[df["category"].astype(str) == "2d"].copy()
    hit = sub["global_hit"].astype(bool)
    out = {
        "run": label,
        "n": int(len(sub)),
        "mean_dice": float(sub["global_dice"].mean()),
        "hit_rate": float(hit.mean()),
        "hits": int(hit.sum()),
        "misses": int((~hit).sum()),
        "dice_on_hit_cases_only": float(sub.loc[hit, "global_dice"].mean()) if hit.any() else float("nan"),
    }
    for col in [
        "voxel_precision",
        "voxel_recall",
        "fp_voxels",
        "fn_voxels",
        "fp_mm3",
        "fn_mm3",
        "pred_gt_volume_ratio",
    ]:
        if col in sub:
            out[f"mean_{col}"] = float(sub[col].mean())
            out[f"median_{col}"] = float(sub[col].median())
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--anchor85-dir", type=Path, required=True)
    parser.add_argument("--s1-gamma1-dir", type=Path, required=True)
    parser.add_argument("--category-focaloff-dir", type=Path, default=None)
    parser.add_argument(
        "--gamma-run",
        action="append",
        default=[],
        help="gamma:path/to/run_dir",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    anchor = load_summary(args.anchor85_dir)
    s1 = load_summary(args.s1_gamma1_dir)
    anchor_dice = float(anchor["mean_global_dice_per_finding"])
    anchor_hit = float(anchor["hit_rate"])
    s1_dice = float(s1["mean_global_dice_per_finding"])

    rows = []
    for spec in args.gamma_run:
        gamma_str, path = spec.split(":", 1)
        gamma = float(gamma_str)
        run_dir = Path(path)
        summary = load_summary(run_dir)
        row = {
            "gamma": gamma,
            "Dice/finding": float(summary["mean_global_dice_per_finding"]),
            "Dice/case": float(summary["mean_global_dice_per_case"]),
            "hit_rate": float(summary["hit_rate"]),
            "hits": int(summary["total_hits"]),
            "misses": int(summary["total_misses"]),
        }
        row["Delta_Dice_finding_vs_Anchor85_step3800"] = row["Dice/finding"] - anchor_dice
        row["Delta_Dice_finding_vs_S1_step600_gamma1"] = row["Dice/finding"] - s1_dice
        row["Delta_hit_rate_vs_Anchor85_step3800"] = row["hit_rate"] - anchor_hit
        for cat in ["2d", "1e", "2b"]:
            dice = category_dice(run_dir, cat)
            row[f"{cat}_Dice"] = dice
            row[f"{cat}_Delta_Dice_vs_Anchor85"] = dice - category_dice(args.anchor85_dir, cat)
        rows.append(row)
    pd.DataFrame(rows).sort_values("gamma").to_csv(args.out_dir / "summary_all_gammas.csv", index=False)

    decomp_rows = [
        decompose_2d("Anchor85_step3800", args.anchor85_dir),
        decompose_2d("S1_step600_gamma1", args.s1_gamma1_dir),
    ]
    if args.category_focaloff_dir is not None:
        decomp_rows.append(decompose_2d("S1_step600_category_focaloff", args.category_focaloff_dir))
    for spec in args.gamma_run:
        gamma_str, path = spec.split(":", 1)
        run_dir = Path(path)
        if float(gamma_str) == 1.0 and run_dir.resolve() == args.s1_gamma1_dir.resolve():
            continue
        decomp_rows.append(decompose_2d(f"S1_step600_gamma{float(gamma_str):.2f}", run_dir))
    pd.DataFrame(decomp_rows).to_csv(args.out_dir / "category_2d_decomposition.csv", index=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
