#!/usr/bin/env python3
"""Cache official BiomedCLIP text-tower final-layer CLS features for ReX.

The cache has the same record order and ``cls_embeddings`` field as the
PubMedBERT cache consumed by the established VoxTell training/inference code.
Only the official BiomedCLIP checkpoint supplies learned text-tower weights:
the separately stored BERT config is architecture-only and OpenCLIP is created
with ``pretrained_hf=False``.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path

import open_clip
import torch
from open_clip.factory import _MODEL_CONFIGS
from tqdm import tqdm
from transformers import AutoTokenizer


ROOT = Path(__file__).resolve().parents[1]
MODEL_ID = "microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224"
REVISION = "9f341de24bfb00180f1b847274256e9b65a3a32e"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rex-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "model_assets/text_embedding_analysis/biomedclip_cls_train_val.pt",
    )
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect_records(path: Path) -> list[dict]:
    payload = json.loads(path.read_text())
    records: list[dict] = []
    for split in ("train", "val"):
        for case in payload[split]:
            for finding_idx, prompt in sorted(case["findings"].items(), key=lambda item: int(item[0])):
                records.append({"split": split, "case": case["name"], "finding_idx": int(finding_idx), "prompt": str(prompt)})
    return records


def load_official_text_model(device: str):
    local = ROOT / "model_assets/biomedclip" / REVISION
    arch = ROOT / "model_assets/biomedclip/biomedbert_arch_config"
    checkpoint = local / "open_clip_pytorch_model.bin"
    if not checkpoint.is_file() or not arch.is_dir():
        raise FileNotFoundError("Official BiomedCLIP checkpoint or architecture-only config is missing")
    model_cfg = copy.deepcopy(json.loads((local / "open_clip_config.json").read_text())["model_cfg"])
    model_cfg["text_cfg"]["hf_model_name"] = str(arch)
    model_cfg["text_cfg"]["hf_tokenizer_name"] = str(local)
    name = "biomedclip_official_local_cls_cache"
    _MODEL_CONFIGS[name] = model_cfg
    model, _, _ = open_clip.create_model_and_transforms(
        name, pretrained=str(checkpoint), pretrained_hf=False, device=device
    )
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True)
    return model, tokenizer, local, checkpoint


@torch.inference_mode()
def main() -> int:
    args = parse_args()
    records = collect_records(args.rex_json)
    model, tokenizer, local, checkpoint = load_official_text_model(args.device)
    features: list[torch.Tensor] = []
    for start in tqdm(range(0, len(records), args.batch_size), desc="BiomedCLIP CLS cache"):
        batch = records[start : start + args.batch_size]
        encoded = tokenizer(
            [row["prompt"] for row in batch], padding="max_length", truncation=True,
            max_length=256, return_tensors="pt",
        )
        hidden = model.text.transformer(
            input_ids=encoded["input_ids"].to(args.device),
            attention_mask=encoded["attention_mask"].to(args.device),
        ).last_hidden_state
        cls = hidden[:, 0, :]
        if cls.ndim != 2 or cls.shape[1] != 768:
            raise RuntimeError(f"Expected [B,768] pre-projection CLS, got {tuple(cls.shape)}")
        features.append(cls.float().cpu().to(torch.float16).contiguous())
    embeddings = torch.cat(features)
    metadata = {
        "format_version": "rex_biomedclip_cls.v1",
        "model_id": MODEL_ID,
        "model_revision": REVISION,
        "official_checkpoint": str(checkpoint.resolve()),
        "local_model_path": str(local.resolve()),
        "weight_source": "Official BiomedCLIP open_clip_pytorch_model.bin; pretrained_hf=False",
        "tokenizer_class": tokenizer.__class__.__name__,
        "tokenizer_name_or_path": str(local.resolve()),
        "max_length": 256,
        "encoder_output": "OpenCLIP HFTextEncoder.transformer.last_hidden_state",
        "pooling_cls": "last_hidden_state[:, 0, :] before the official MLP projection",
        "hidden_dimension": 768,
        "storage_dtype": "float16",
        "records": len(records),
        "source_json": str(args.rex_json.resolve()),
        "source_json_sha256": sha256(args.rex_json),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"metadata": metadata, "records": records, "cls_embeddings": embeddings}, args.output)
    print(json.dumps({**metadata, "output": str(args.output.resolve()), "shape": list(embeddings.shape)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
