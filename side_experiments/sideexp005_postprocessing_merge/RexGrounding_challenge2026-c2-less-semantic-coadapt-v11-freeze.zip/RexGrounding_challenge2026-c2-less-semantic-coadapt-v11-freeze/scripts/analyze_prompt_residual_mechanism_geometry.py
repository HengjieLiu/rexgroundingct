#!/usr/bin/env python3
"""Residual geometry, SVD/subspace, and bottleneck-unit diagnostics."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import re
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F


ROOT = Path(__file__).resolve().parents[1]
TOKEN_RE = re.compile(r"[a-z0-9]+")
STATE_SPECS = {
    "weak_update100": (
        "outputs/prompt_residual_adapter_best_s3_frozen",
        100,
        "weak",
    ),
    "allcategory_update25": (
        "outputs/prompt_residual_adapter_s3_allcategory_1over1_frozen",
        25,
        "allcategory_1over1",
    ),
    "allcategory_update100": (
        "outputs/prompt_residual_adapter_s3_allcategory_1over1_frozen",
        100,
        "allcategory_1over1",
    ),
    "multiscale_update25": (
        "outputs/prompt_residual_adapter_s3_multiscale_2b2c_frozen",
        25,
        "multiscale_2b2c",
    ),
    "multiscale_update100": (
        "outputs/prompt_residual_adapter_s3_multiscale_2b2c_frozen",
        100,
        "multiscale_2b2c",
    ),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument(
        "--embedding-cache",
        type=Path,
        default=ROOT
        / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/"
        "qwen_prompt_embeddings_train_val.pt",
    )
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def project_queries(checkpoint_path: Path, embeddings: torch.Tensor) -> torch.Tensor:
    payload = torch.load(
        checkpoint_path, map_location="cpu", mmap=True, weights_only=False
    )
    state = payload["network_weights"]
    with torch.inference_mode():
        hidden = F.linear(
            embeddings.float(),
            state["project_text_embed.0.weight"],
            state["project_text_embed.0.bias"],
        )
        hidden = F.gelu(hidden)
        query = F.linear(
            hidden,
            state["project_text_embed.2.weight"],
            state["project_text_embed.2.bias"],
        )
    del payload, state, hidden
    return query


def apply_adapter(
    adapter_path: Path, query: torch.Tensor
) -> tuple[torch.Tensor, torch.Tensor, dict[str, Any]]:
    payload = torch.load(adapter_path, map_location="cpu", weights_only=False)
    state = payload["adapter_state"]
    with torch.inference_mode():
        normalized = F.layer_norm(
            query,
            (query.shape[-1],),
            state["norm.weight"],
            state["norm.bias"],
        )
        bottleneck = F.gelu(F.linear(normalized, state["down.weight"]))
        residual = F.linear(bottleneck, state["up.weight"])
    metadata = {
        "architecture": payload["architecture"],
        "optimizer_update": int(payload["optimizer_update"]),
        "base_checkpoint_sha256": payload["base_checkpoint_sha256"],
        "experiment_config": payload["experiment_config"],
    }
    return residual, bottleneck, metadata


def paired_metrics(branch: str, update: int) -> pd.DataFrame:
    if branch == "weak":
        frame = pd.read_csv(
            ROOT
            / "outputs/prompt_residual_adapter_best_s3_frozen/full_eval/"
            "per_finding_paired.csv"
        )
    else:
        frame = pd.read_csv(
            ROOT
            / "outputs/prompt_residual_adapter_s3_early_checkpoint_diagnostic/"
            "paired_metrics.csv"
        )
        frame = frame[
            (frame["branch"] == branch) & (frame["update"] == update)
        ].copy()
    frame["key"] = (
        frame["file"].astype(str)
        + "::"
        + frame["finding_idx"].astype(int).astype(str)
    )
    return frame.set_index("key").sort_index()


def correlation_rows(frame: pd.DataFrame, fields: list[str]) -> dict[str, Any]:
    output = {}
    for geometry_field in fields:
        for outcome_field in (
            "dice_delta",
            "prediction_volume_change",
            "fp_volume_change",
            "fn_volume_change",
            "new_hit",
            "lost_hit",
        ):
            left = frame[geometry_field].astype(float)
            right = frame[outcome_field].astype(float)
            output[f"{geometry_field}__{outcome_field}"] = {
                "pearson": (
                    float(left.corr(right, method="pearson"))
                    if left.nunique() > 1 and right.nunique() > 1
                    else None
                ),
                "spearman": (
                    float(left.corr(right, method="spearman"))
                    if left.nunique() > 1 and right.nunique() > 1
                    else None
                ),
            }
    return output


def pairwise_similarity_summary(
    residual: np.ndarray, categories: np.ndarray, pixels: np.ndarray
) -> dict[str, Any]:
    normalized = residual / np.clip(
        np.linalg.norm(residual, axis=1, keepdims=True), 1e-12, None
    )
    similarity = normalized @ normalized.T
    upper = np.triu_indices(len(residual), k=1)
    values = similarity[upper]

    def selected(mask: np.ndarray) -> dict[str, float | int | None]:
        subset = similarity[upper][mask[upper]]
        if not len(subset):
            return {"n": 0, "mean": None, "median": None}
        return {
            "n": int(len(subset)),
            "mean": float(subset.mean()),
            "median": float(np.median(subset)),
        }

    same_category = categories[:, None] == categories[None, :]
    diffuse = np.char.startswith(categories.astype(str), "1")
    same_focus = diffuse[:, None] == diffuse[None, :]
    tiny = pixels < 100
    same_size = tiny[:, None] == tiny[None, :]
    return {
        "all_pairs": {
            "n": int(len(values)),
            "mean": float(values.mean()),
            "q25": float(np.quantile(values, 0.25)),
            "median": float(np.median(values)),
            "q75": float(np.quantile(values, 0.75)),
        },
        "within_category": selected(same_category),
        "between_category": selected(~same_category),
        "same_focal_diffuse_group": selected(same_focus),
        "between_focal_diffuse_group": selected(~same_focus),
        "same_tiny_group": selected(same_size),
        "between_tiny_group": selected(~same_size),
    }


def category_variance_fraction(residual: np.ndarray, categories: np.ndarray) -> float:
    center = residual.mean(axis=0, keepdims=True)
    total = float(np.square(residual - center).sum())
    between = 0.0
    for category in sorted(set(categories)):
        group = residual[categories == category]
        between += len(group) * float(np.square(group.mean(axis=0) - center).sum())
    return between / total if total else 0.0


def svd_summary(
    residual: np.ndarray,
    metrics: pd.DataFrame,
    categories: np.ndarray,
    pixels: np.ndarray,
) -> tuple[dict[str, Any], np.ndarray]:
    _, singular, right = np.linalg.svd(residual, full_matrices=False)
    energy = np.square(singular)
    fractions = energy / energy.sum()
    cumulative = np.cumsum(fractions)
    first = right[0].copy()
    mean_direction = residual.mean(axis=0)
    if float(first @ mean_direction) < 0:
        first *= -1
        right[0] *= -1
    scores = residual @ first
    summary = {
        "explained_energy_cumulative": {
            str(count): float(cumulative[min(count, len(cumulative)) - 1])
            for count in (1, 2, 4, 8, 16)
        },
        "singular_values_first_16": [float(value) for value in singular[:16]],
        "participation_ratio_effective_rank": float(
            energy.sum() ** 2 / np.square(energy).sum()
        ),
        "numerical_rank_relative_1e_minus_6": int(
            (singular >= singular[0] * 1e-6).sum()
        ),
        "numerical_rank_relative_1e_minus_4": int(
            (singular >= singular[0] * 1e-4).sum()
        ),
        "rank_for_99_percent_energy": int(np.searchsorted(cumulative, 0.99) + 1),
        "pairwise_residual_cosine": pairwise_similarity_summary(
            residual, categories, pixels
        ),
        "category_explained_variance_fraction": category_variance_fraction(
            residual, categories
        ),
        "pc1_score_correlations": {
            field: {
                "pearson": float(pd.Series(scores).corr(metrics[field], method="pearson")),
                "spearman": float(
                    pd.Series(scores).corr(metrics[field], method="spearman")
                ),
            }
            for field in (
                "dice_delta",
                "prediction_volume_change",
                "fp_volume_change",
                "fn_volume_change",
            )
        },
    }
    return summary, right[:16]


def ngrams(text: str) -> set[str]:
    tokens = TOKEN_RE.findall(text.lower())
    return set(tokens + [f"{a}_{b}" for a, b in zip(tokens, tokens[1:])])


def enriched_ngrams(prompts: list[str], top_indices: np.ndarray) -> list[dict[str, Any]]:
    top_set = set(map(int, top_indices))
    top = Counter()
    rest = Counter()
    for index, prompt in enumerate(prompts):
        target = top if index in top_set else rest
        target.update(ngrams(prompt))
    rows = []
    for term in sorted(top):
        top_rate = (top[term] + 0.5) / (len(top_set) + 1.0)
        rest_rate = (rest[term] + 0.5) / (len(prompts) - len(top_set) + 1.0)
        rows.append(
            {
                "term": term,
                "top_count": int(top[term]),
                "rest_count": int(rest[term]),
                "log_rate_ratio": float(math.log(top_rate / rest_rate)),
            }
        )
    return sorted(rows, key=lambda row: (-row["log_rate_ratio"], row["term"]))[:15]


def distribution(values: pd.Series) -> dict[str, int]:
    return {str(key): int(value) for key, value in values.value_counts().items()}


def bottleneck_summary(
    bottleneck: np.ndarray, metadata: pd.DataFrame
) -> dict[str, Any]:
    prompts = metadata["prompt"].astype(str).tolist()
    lengths = metadata["prompt"].astype(str).str.findall(TOKEN_RE).map(len)
    output = {}
    for unit in range(bottleneck.shape[1]):
        values = bottleneck[:, unit]
        top = np.argsort(values)[-20:][::-1]
        bottom = np.argsort(values)[:20]
        top_frame = metadata.iloc[top]
        output[str(unit)] = {
            "mean": float(values.mean()),
            "variance": float(values.var()),
            "sparsity_abs_lt_1e_minus_3": float(np.mean(np.abs(values) < 1e-3)),
            "fraction_nonpositive": float(np.mean(values <= 0)),
            "prompt_length_pearson": float(pd.Series(values).corr(lengths)),
            "prompt_length_spearman": float(
                pd.Series(values).corr(lengths, method="spearman")
            ),
            "top_20": [
                {
                    "file": row.file,
                    "finding_idx": int(row.finding_idx),
                    "activation": float(values[index]),
                    "category": str(row.category),
                    "pixels": int(row.pixels),
                    "prompt": str(row.prompt),
                }
                for index, row in zip(top, top_frame.itertuples())
            ],
            "bottom_20": [
                {
                    "file": row.file,
                    "finding_idx": int(row.finding_idx),
                    "activation": float(values[index]),
                    "category": str(row.category),
                    "pixels": int(row.pixels),
                    "prompt": str(row.prompt),
                }
                for index, row in zip(bottom, metadata.iloc[bottom].itertuples())
            ],
            "top_category_distribution": distribution(
                top_frame["category"].astype(str)
            ),
            "top_focal_diffuse_distribution": distribution(
                top_frame["category"]
                .astype(str)
                .map(lambda value: "diffuse" if value.startswith("1") else "focal")
            ),
            "top_tiny_distribution": distribution(
                top_frame["pixels"].astype(int).map(
                    lambda value: "tiny" if value < 100 else "non_tiny"
                )
            ),
            "enriched_unigrams_bigrams": enriched_ngrams(prompts, top),
        }
    return output


def main() -> int:
    args = parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    cache = torch.load(args.embedding_cache, map_location="cpu", weights_only=False)
    selected = [
        (index, record)
        for index, record in enumerate(cache["records"])
        if str(record["split"]) == "val"
    ]
    if len(selected) != 381:
        raise ValueError(f"Expected 381 validation findings, got {len(selected)}")
    embeddings = cache["embeddings"][[index for index, _ in selected]].float()
    records = pd.DataFrame([record for _, record in selected]).rename(
        columns={"case": "file"}
    )
    records["key"] = (
        records["file"].astype(str)
        + "::"
        + records["finding_idx"].astype(int).astype(str)
    )
    records = records.set_index("key").sort_index()
    embedding_by_key = pd.DataFrame(
        {"cache_index": range(len(records))}, index=[
            f"{record['case']}::{int(record['finding_idx'])}"
            for _, record in selected
        ]
    ).sort_index()
    embeddings = embeddings[embedding_by_key["cache_index"].to_numpy()]

    geometry_frames = []
    pca_results: dict[str, Any] = {}
    bottleneck_results: dict[str, Any] = {}
    subspaces: dict[str, np.ndarray] = {}
    artifact_rows = []
    vector_manifest = {}
    vector_root = args.output_root / "residual_vectors"
    vector_root.mkdir(parents=True, exist_ok=True)
    query_cache: dict[Path, torch.Tensor] = {}
    hash_cache: dict[Path, str] = {}

    for state_name, (relative_root, update, branch) in STATE_SPECS.items():
        experiment_root = ROOT / relative_root
        config = json.loads((experiment_root / "config.json").read_text())
        base_path = Path(config["base_checkpoint"])
        adapter_path = experiment_root / f"checkpoints/prompt_adapter_update_{update}.pth"
        if base_path not in hash_cache:
            hash_cache[base_path] = sha256(base_path)
        if adapter_path not in hash_cache:
            hash_cache[adapter_path] = sha256(adapter_path)
        if base_path not in query_cache:
            query_cache[base_path] = project_queries(base_path, embeddings)
        query = query_cache[base_path]
        residual, bottleneck, adapter_metadata = apply_adapter(adapter_path, query)
        metrics = paired_metrics(branch, update)
        if not records.index.equals(metrics.index):
            raise ValueError(f"{state_name}: validation finding identities differ")
        vector_path = vector_root / f"{state_name}.npz"
        np.savez_compressed(
            vector_path,
            finding_key=records.index.to_numpy(dtype=str),
            q=query.numpy(),
            r=residual.numpy(),
            q_conditioned=(query + residual).numpy(),
            h=bottleneck.numpy(),
        )
        vector_manifest[state_name] = {
            "path": str(vector_path.resolve()),
            "sha256": sha256(vector_path),
            "findings": len(records),
            "arrays": {
                "finding_key": [len(records)],
                "q": [len(records), 2048],
                "r": [len(records), 2048],
                "q_conditioned": [len(records), 2048],
                "h": [len(records), 16],
            },
            "dtype": {
                "finding_key": "unicode",
                "q": "float32",
                "r": "float32",
                "q_conditioned": "float32",
                "h": "float32",
            },
        }

        q_norm = query.norm(dim=1)
        r_norm = residual.norm(dim=1)
        dot = (query * residual).sum(dim=1)
        coefficient = dot / q_norm.square().clamp_min(1e-12)
        parallel = coefficient[:, None] * query
        perpendicular = residual - parallel
        conditioned = query + residual
        rotation_cosine = F.cosine_similarity(query, conditioned, dim=1).clamp(-1, 1)
        frame = records.reset_index(drop=True)[
            ["file", "finding_idx", "prompt", "category", "pixels"]
        ].copy()
        frame.insert(0, "state", state_name)
        frame["base_query_norm"] = q_norm.numpy()
        frame["residual_norm"] = r_norm.numpy()
        frame["residual_base_query_ratio"] = (r_norm / q_norm.clamp_min(1e-12)).numpy()
        frame["query_residual_cosine"] = F.cosine_similarity(
            query, residual, dim=1
        ).numpy()
        frame["query_conditioned_cosine"] = rotation_cosine.numpy()
        frame["angular_rotation_degrees"] = (
            torch.rad2deg(torch.acos(rotation_cosine)).numpy()
        )
        frame["parallel_coefficient"] = coefficient.numpy()
        frame["residual_parallel_norm"] = parallel.norm(dim=1).numpy()
        frame["residual_perpendicular_norm"] = perpendicular.norm(dim=1).numpy()
        frame["orthogonal_energy_fraction"] = (
            perpendicular.square().sum(dim=1)
            / residual.square().sum(dim=1).clamp_min(1e-12)
        ).numpy()
        for field in (
            "dice_delta",
            "new_hit",
            "lost_hit",
            "baseline_pred_voxels",
            "adapter_pred_voxels",
            "baseline_fp_mm3",
            "adapter_fp_mm3",
            "baseline_fn_mm3",
            "adapter_fn_mm3",
        ):
            frame[field] = metrics[field].to_numpy()
        frame["prediction_volume_change"] = (
            frame["adapter_pred_voxels"] - frame["baseline_pred_voxels"]
        )
        frame["fp_volume_change"] = frame["adapter_fp_mm3"] - frame["baseline_fp_mm3"]
        frame["fn_volume_change"] = frame["adapter_fn_mm3"] - frame["baseline_fn_mm3"]
        geometry_frames.append(frame)

        geometry_fields = [
            "residual_norm",
            "residual_base_query_ratio",
            "query_residual_cosine",
            "angular_rotation_degrees",
            "parallel_coefficient",
            "residual_parallel_norm",
            "residual_perpendicular_norm",
            "orthogonal_energy_fraction",
        ]
        pca, subspace = svd_summary(
            residual.numpy(),
            frame,
            frame["category"].astype(str).to_numpy(),
            frame["pixels"].astype(int).to_numpy(),
        )
        pca["geometry_summary"] = {
            field: {
                "mean": float(frame[field].mean()),
                "q25": float(frame[field].quantile(0.25)),
                "median": float(frame[field].median()),
                "q75": float(frame[field].quantile(0.75)),
                "max": float(frame[field].max()),
            }
            for field in geometry_fields
        }
        pca["outcome_correlations"] = correlation_rows(frame, geometry_fields)
        pca_results[state_name] = pca
        subspaces[state_name] = subspace
        bottleneck_results[state_name] = bottleneck_summary(
            bottleneck.numpy(), frame
        )
        artifact_rows.extend(
            [
                {
                    "family_state": state_name,
                    "kind": "base",
                    "path": str(base_path.resolve()),
                    "sha256": hash_cache[base_path],
                    "update": 0,
                },
                {
                    "family_state": state_name,
                    "kind": "adapter",
                    "path": str(adapter_path.resolve()),
                    "sha256": hash_cache[adapter_path],
                    "update": update,
                    "architecture": adapter_metadata["architecture"],
                    "base_identity_match": (
                        adapter_metadata["base_checkpoint_sha256"]
                        == config["base_checkpoint_sha256"]
                    ),
                },
            ]
        )

    subspace_results = {}
    for left, right in itertools.combinations(STATE_SPECS, 2):
        singular = np.linalg.svd(
            subspaces[left] @ subspaces[right].T, compute_uv=False
        )
        angles = np.degrees(np.arccos(np.clip(singular, -1, 1)))
        subspace_results[f"{left}__{right}"] = {
            "principal_angles_degrees": [float(value) for value in angles],
            "mean_principal_angle_degrees": float(angles.mean()),
            "maximum_principal_angle_degrees": float(angles.max()),
            "absolute_pc1_cosine": float(
                abs(subspaces[left][0] @ subspaces[right][0])
            ),
            "signed_pc1_cosine": float(
                subspaces[left][0] @ subspaces[right][0]
            ),
        }

    geometry = pd.concat(geometry_frames, ignore_index=True)
    geometry.to_csv(args.output_root / "residual_geometry.csv", index=False)
    (args.output_root / "residual_pca.json").write_text(
        json.dumps(pca_results, indent=2) + "\n"
    )
    (args.output_root / "subspace_comparison.json").write_text(
        json.dumps(subspace_results, indent=2) + "\n"
    )
    (args.output_root / "bottleneck_unit_analysis.json").write_text(
        json.dumps(bottleneck_results, indent=2) + "\n"
    )
    unique_artifacts = {
        (row["path"], row["kind"], row["update"]): row for row in artifact_rows
    }
    (args.output_root / "artifact_hashes.json").write_text(
        json.dumps(list(unique_artifacts.values()), indent=2) + "\n"
    )
    (vector_root / "manifest.json").write_text(
        json.dumps(vector_manifest, indent=2) + "\n"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
