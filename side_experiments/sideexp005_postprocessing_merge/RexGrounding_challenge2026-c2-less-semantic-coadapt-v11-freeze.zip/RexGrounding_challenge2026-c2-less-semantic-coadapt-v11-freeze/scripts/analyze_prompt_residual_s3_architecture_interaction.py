#!/usr/bin/env python3
"""Compare paired adapter effects between two S3 policies on identical findings."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--allcategory", type=Path, required=True)
    parser.add_argument("--multiscale", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-samples", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=2026)
    return parser.parse_args()


def load(path: Path, prefix: str) -> pd.DataFrame:
    frame = pd.read_csv(path)
    frame["key"] = (
        frame["file"].astype(str)
        + "::"
        + frame["finding_idx"].astype(int).astype(str)
    )
    frame = frame.set_index("key").sort_index()
    if len(frame) != 381 or not frame.index.is_unique:
        raise ValueError(f"{path} is not the unique canonical 381-finding cohort")
    keep = ["file", "finding_idx", "prompt", "category", "pixels", "dice_delta"]
    result = frame[keep].copy()
    result = result.rename(columns={"dice_delta": f"delta_{prefix}"})
    return result


def bootstrap_finding(values: np.ndarray, samples: int, seed: int) -> list[float]:
    generator = np.random.default_rng(seed)
    means = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 500):
        count = min(500, samples - start)
        indices = generator.integers(0, len(values), (count, len(values)))
        means[start : start + count] = values[indices].mean(axis=1)
    return [float(value) for value in np.quantile(means, [0.025, 0.975])]


def bootstrap_case(frame: pd.DataFrame, samples: int, seed: int) -> list[float]:
    values = (
        frame.groupby("file", sort=True)["interaction_delta"]
        .mean()
        .to_numpy(np.float64)
    )
    return bootstrap_finding(values, samples, seed)


def summarize(
    frame: pd.DataFrame, samples: int, seed: int
) -> dict[str, float | int | list[float]]:
    values = frame["interaction_delta"].to_numpy(np.float64)
    return {
        "findings": len(frame),
        "cases": int(frame["file"].nunique()),
        "mean_delta_allcategory": float(frame["delta_allcategory"].mean()),
        "mean_delta_multiscale": float(frame["delta_multiscale"].mean()),
        "mean_interaction_delta": float(values.mean()),
        "median_interaction_delta": float(np.median(values)),
        "finding_level_95_ci": bootstrap_finding(values, samples, seed),
        "case_clustered_95_ci": bootstrap_case(frame, samples, seed),
    }


def main() -> int:
    args = parse_args()
    allcategory = load(args.allcategory, "allcategory")
    multiscale = load(args.multiscale, "multiscale")
    if not allcategory.index.equals(multiscale.index):
        raise ValueError("The two branches do not contain identical finding identities")
    for column in ("file", "finding_idx", "prompt", "category", "pixels"):
        if not allcategory[column].equals(multiscale[column]):
            raise ValueError(f"Finding metadata differs between branches: {column}")

    paired = allcategory.join(multiscale[["delta_multiscale"]])
    paired["interaction_delta"] = (
        paired["delta_allcategory"] - paired["delta_multiscale"]
    )
    paired = paired.reset_index(drop=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    paired.to_csv(args.output_dir / "paired_metrics.csv", index=False)

    groupers: dict[str, Callable[[pd.DataFrame], pd.Series]] = {
        "2b": lambda x: x["category"].astype(str) == "2b",
        "2c": lambda x: x["category"].astype(str) == "2c",
        "2b_plus_2c": lambda x: x["category"].astype(str).isin(["2b", "2c"]),
        "all_except_2b2c": lambda x: ~x["category"].astype(str).isin(["2b", "2c"]),
        "category_1_diffuse": lambda x: x["category"].astype(str).str.startswith("1"),
        "category_2_focal": lambda x: x["category"].astype(str).str.startswith("2"),
        "2a": lambda x: x["category"].astype(str) == "2a",
        "2d": lambda x: x["category"].astype(str) == "2d",
        "tiny_lt_100_gt_voxels": lambda x: x["pixels"].astype(int) < 100,
        "non_tiny_ge_100_gt_voxels": lambda x: x["pixels"].astype(int) >= 100,
    }
    rows = []
    bootstrap = {
        "samples": args.bootstrap_samples,
        "seed": args.seed,
        "overall": summarize(paired, args.bootstrap_samples, args.seed),
        "groups": {},
    }
    for offset, (label, grouper) in enumerate(groupers.items(), start=1):
        subset = paired.loc[grouper(paired)].copy()
        summary = summarize(
            subset, args.bootstrap_samples, args.seed + offset
        )
        bootstrap["groups"][label] = summary
        rows.append({"group": label, **summary})
    pd.DataFrame(rows).to_csv(
        args.output_dir / "interaction_analysis.csv", index=False
    )
    (args.output_dir / "bootstrap_results.json").write_text(
        json.dumps(bootstrap, indent=2) + "\n"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
