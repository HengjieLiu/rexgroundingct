#!/usr/bin/env python3
"""Compare single-GPU and no-DDP case-sharded P0-I predictions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--single-dir", type=Path, required=True)
    parser.add_argument("--sharded-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    cases = [
        entry["name"]
        for split, values in manifest.items()
        if isinstance(values, list)
        for entry in values
    ]
    records = []
    for name in cases:
        single = np.asarray(
            nib.load(args.single_dir / name).dataobj, dtype=np.uint8
        )
        sharded = np.asarray(
            nib.load(args.sharded_dir / name).dataobj, dtype=np.uint8
        )
        records.append(
            {
                "case": name,
                "shape": list(single.shape),
                "maximum_absolute_mask_difference": int(
                    np.max(np.abs(single.astype(np.int16) - sharded.astype(np.int16)))
                ),
                "different_mask_voxels": int(np.count_nonzero(single != sharded)),
                "single_foreground_voxels": int(single.sum()),
                "sharded_foreground_voxels": int(sharded.sum()),
            }
        )
    single_metrics = json.loads(
        (args.single_dir / "eval_rexrank_metrics_global.json").read_text()
    )
    sharded_metrics = json.loads(
        (args.sharded_dir / "eval_rexrank_metrics_global.json").read_text()
    )
    merge_summary = json.loads((args.sharded_dir / "summary.json").read_text())
    keys = (
        "mean_global_dice_per_finding",
        "hit_rate",
        "total_hits",
        "total_findings",
    )
    metric_differences = {
        key: float(single_metrics["summary"][key])
        - float(sharded_metrics["summary"][key])
        for key in keys
    }
    passed = (
        all(record["different_mask_voxels"] == 0 for record in records)
        and all(value == 0.0 for value in metric_differences.values())
        and bool(
            merge_summary["coverage"]["preserved_original_manifest_order"]
        )
    )
    report = {
        "status": "pass" if passed else "fail",
        "scope": "two one-finding cases, one case assigned to each of two GPUs",
        "single_gpu_evaluator": str(args.single_dir.resolve()),
        "sharded_evaluator": str(args.sharded_dir.resolve()),
        "no_ddp_model_synchronization": True,
        "independent_complete_model_per_gpu": True,
        "cases": records,
        "metric_differences_single_minus_sharded": metric_differences,
        "merge_coverage": merge_summary["coverage"],
        "normal_numerical_tolerance": 0.0,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if not passed:
        raise AssertionError("Single/sharded validation failed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
