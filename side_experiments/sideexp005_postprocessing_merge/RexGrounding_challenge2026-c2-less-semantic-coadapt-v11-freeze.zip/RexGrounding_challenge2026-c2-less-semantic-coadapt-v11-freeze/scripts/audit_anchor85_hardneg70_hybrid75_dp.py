#!/usr/bin/env python
"""Run the required production-path audit for the hybrid75 dual-positive sampler."""

from __future__ import annotations

import argparse
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.audit_hard_negative_spatial_empty_sampler import (  # noqa: E402
    MaskOnlyAuditSampler,
    audit_loader,
)
from scripts.train_voxtell_rex_full_nnunet_aug import (  # noqa: E402
    build_case_records,
    load_manifest,
    segmentation_loss,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preprocessed-dir", type=Path, default=ROOT / "data/rex_voxtell_preprocessed_v1")
    parser.add_argument("--num-draws", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--num-workers", type=int, default=16)
    parser.add_argument("--hybrid-lambda", type=float, default=0.75)
    parser.add_argument("--global-dual-positive-prob", type=float, default=0.20)
    parser.add_argument("--global-same-case-negative-prob", type=float, default=0.15)
    parser.add_argument("--hard-negative-prob", type=float, default=0.70)
    parser.add_argument("--patch-size", type=int, nargs=3, default=(192, 192, 192))
    parser.add_argument("--max-crop-attempts", type=int, default=50)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs/sampler_audits/anchor85_hardneg70_hybrid75_dp_10000")
    return parser.parse_args()


def ignored_loss_diagnostic() -> dict[str, Any]:
    generator = torch.Generator().manual_seed(947)
    logits = torch.randn((1, 3, 8, 8, 8), generator=generator, requires_grad=True)
    target = torch.zeros_like(logits)
    target[:, 0, 2:6, 2:6, 2:6] = 1
    weights = torch.tensor([[1.0, 1.0, 0.0]])
    loss, _ = segmentation_loss(logits, target, weights, rex_loss_mode="dice_bce")
    loss.backward()
    ignored_gradient_max = float(logits.grad[:, 2].abs().max().item())
    changed = logits.detach().clone()
    changed[:, 2] = 100.0
    changed_loss, _ = segmentation_loss(changed, target, weights, rex_loss_mode="dice_bce")
    loss_delta = float(abs(changed_loss.item() - loss.detach().item()))
    return {
        "ignored_prompt_gradient_max_abs": ignored_gradient_max,
        "loss_delta_after_replacing_ignored_logits": loss_delta,
        "ignored_prompt_contribution_exactly_zero": ignored_gradient_max == 0.0 and loss_delta == 0.0,
    }


def bucket(count: int) -> str:
    return str(count) if count <= 5 else "6+"


def main() -> int:
    args = parse_args()
    if args.num_draws <= 0:
        raise ValueError("--num-draws must be positive")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    cases = build_case_records(load_manifest(args.preprocessed_dir), "train", None)
    dummy = torch.zeros(1, dtype=torch.float32)
    embeddings = {
        (finding["split"], finding["case"], int(finding["finding_idx"])): dummy
        for case in cases
        for finding in case["findings"]
    }
    sampler = MaskOnlyAuditSampler(
        preprocessed_dir=args.preprocessed_dir,
        cases=cases,
        embedding_map=embeddings,
        patch_size=tuple(args.patch_size),
        positive_prompts=2,
        negative_prompts=1,
        positive_loss_weight=1.0,
        negative_loss_weight=1.0,
        foreground_prob=0.85,
        require_positive_crop=True,
        min_positive_voxels=1,
        max_crop_attempts=args.max_crop_attempts,
        max_sample_attempts=50,
        cache_size=1,
        augmenter=None,
        hard_negative_sampler=False,
        hard_negative_match="category_then_keyword",
        hard_negative_exclude_identical_prompt=True,
        sampler_mode="anchor85_hardneg70_hybrid75_dp",
        anchor_positive_prob=0.85,
        same_case_negative_prob=args.global_same_case_negative_prob,
        shuffle_prompt_order=True,
        cross_case_negative_requires_foreground=True,
        anchor_hard_negative_prob=args.hard_negative_prob,
        hybrid_lambda=args.hybrid_lambda,
        global_dual_positive_prob=args.global_dual_positive_prob,
    )

    branch_counts: Counter[str] = Counter()
    requested_branch_counts: Counter[str] = Counter()
    finding_buckets: Counter[str] = Counter()
    nonempty_item_counts: Counter[str] = Counter()
    category_exposure: Counter[str] = Counter()
    a_selection: dict[str, Counter[str]] = defaultdict(Counter)
    violations: Counter[str] = Counter()
    hard_requested = hard_realized = 0
    active_slots = nonempty_active_slots = ignored_slots = single_items = 0
    dual_requested = dual_success = dual_fallback = dual_attempts = 0

    loader = audit_loader(sampler, args.num_draws, args.num_workers, args.seed)
    for meta in loader:
        weights = torch.tensor(meta["prompt_weights"], dtype=torch.float32)
        branch = str(meta["branch_type"])
        requested = str(meta.get("requested_branch_type", branch))
        branch_counts[branch] += 1
        requested_branch_counts[requested] += 1
        finding_count = int(meta["parent_case_finding_count"])
        finding_buckets[bucket(finding_count)] += 1
        single_items += int(finding_count == 1)
        active = [float(value) > 0 for value in weights.tolist()]
        voxels = [int(value) for value in meta["target_voxels"]]
        n_active = sum(active)
        n_nonempty = sum(flag and value >= sampler.min_positive_voxels for flag, value in zip(active, voxels))
        active_slots += n_active
        nonempty_active_slots += n_nonempty
        ignored_slots += len(active) - n_active
        nonempty_item_counts[str(n_nonempty)] += 1
        if n_active == 0:
            violations["zero_active_prompts"] += 1
        if n_nonempty == 0:
            violations["zero_nonempty_positive_target"] += 1
        if any((not flag) and value != 0 for flag, value in zip(active, voxels)):
            violations["ignored_slot_nonempty_target"] += 1
        if any((not flag) and float(value) != 0.0 for flag, value in zip(active, weights.tolist())):
            violations["ignored_slot_nonzero_weight"] += 1
        hard_requested += int(bool(meta.get("hard_negative_requested")))
        hard_realized += int(
            any(item.get("prompt_instance_type") == "hard_semantic_negative" for item in meta["prompt_instances"])
        )
        if requested == "dual_positive":
            dual_requested += 1
            dual_success += int(bool(meta.get("dual_positive_success")))
            dual_fallback += int(bool(meta.get("dual_positive_fallback")))
            dual_attempts += int(meta.get("dual_positive_attempts", 0))
        anchor_idx = str(meta["anchor_finding_idx"])
        a_selection[bucket(finding_count)][anchor_idx] += 1
        for category, flag, value in zip(meta["categories_after_shuffle"], active, voxels):
            if flag and value >= sampler.min_positive_voxels:
                category_exposure[str(category or "unknown")] += 1

    loss_diagnostic = ignored_loss_diagnostic()
    if not loss_diagnostic["ignored_prompt_contribution_exactly_zero"]:
        violations["ignored_slot_nonzero_loss"] += 1
    desired_range = (0.505, 0.515)
    nonempty_fraction = nonempty_active_slots / max(1, active_slots)
    summary = {
        "sampler_mode": sampler.sampler_mode,
        "seed": args.seed,
        "draws": args.num_draws,
        "parameters": {
            "hybrid_lambda": args.hybrid_lambda,
            "global_dual_positive_prob": args.global_dual_positive_prob,
            "global_same_case_negative_prob": args.global_same_case_negative_prob,
            "hard_negative_prob": args.hard_negative_prob,
            "patch_size": list(args.patch_size),
        },
        "expected_single_case_item_fraction": sampler.hybrid_expected_single_mass,
        "realized_single_case_item_fraction": single_items / args.num_draws,
        "finding_count_bucket_counts": {key: finding_buckets[key] for key in ("1", "2", "3", "4", "5", "6+")},
        "finding_count_bucket_fractions": {key: finding_buckets[key] / args.num_draws for key in ("1", "2", "3", "4", "5", "6+")},
        "branch_counts": dict(sorted(branch_counts.items())),
        "branch_fractions": {key: value / args.num_draws for key, value in sorted(branch_counts.items())},
        "requested_branch_counts": dict(sorted(requested_branch_counts.items())),
        "requested_branch_fractions": {key: value / args.num_draws for key, value in sorted(requested_branch_counts.items())},
        "hard_negative": {
            "requested_count": hard_requested,
            "requested_fraction": hard_requested / args.num_draws,
            "realized_semantic_count": hard_realized,
            "realized_semantic_fraction": hard_realized / args.num_draws,
        },
        "active_target_composition": {
            "items_by_nonempty_target_count": dict(sorted(nonempty_item_counts.items())),
            "active_prompt_slots": active_slots,
            "ignored_prompt_slots": ignored_slots,
            "ignored_slot_item_fraction": ignored_slots / args.num_draws,
            "nonempty_active_target_fraction": nonempty_fraction,
            "empty_active_target_fraction": 1.0 - nonempty_fraction,
            "desired_nonempty_fraction_range": list(desired_range),
            "inside_desired_range": desired_range[0] <= nonempty_fraction <= desired_range[1],
        },
        "dual_positive": {
            "requested": dual_requested,
            "successful": dual_success,
            "fallbacks": dual_fallback,
            "attempts": dual_attempts,
            "success_rate_given_requested": dual_success / max(1, dual_requested),
            "fallback_rate_given_requested": dual_fallback / max(1, dual_requested),
            "realized_global_fraction": dual_success / args.num_draws,
        },
        "category_exposure": dict(sorted(category_exposure.items())),
        "a_selection_exposure_by_parent_finding_count": {
            group: {
                "selections": sum(counts.values()),
                "distinct_finding_indices": len(counts),
                "counts_by_finding_index": dict(sorted(counts.items(), key=lambda item: int(item[0]))),
            }
            for group, counts in sorted(a_selection.items())
        },
        "ignored_loss_diagnostic": loss_diagnostic,
        "violations": dict(sorted(violations.items())),
    }
    args.output_dir.mkdir(parents=True, exist_ok=False)
    json_path = args.output_dir / "summary.json"
    md_path = args.output_dir / "report.md"
    json_path.write_text(json.dumps(summary, indent=2) + "\n")
    md_path.write_text(
        "\n".join(
            [
                "# Hybrid75 dual-positive sampler audit",
                "",
                f"- Draws: {args.num_draws}",
                f"- Expected / realized single-case items: {100 * sampler.hybrid_expected_single_mass:.3f}% / {100 * single_items / args.num_draws:.3f}%",
                f"- Branch fractions: {summary['branch_fractions']}",
                f"- Requested hard negatives: {100 * hard_requested / args.num_draws:.3f}%",
                f"- Realized semantic hard negatives: {100 * hard_realized / args.num_draws:.3f}%",
                f"- Nonempty targets among active slots: {100 * nonempty_fraction:.3f}%",
                f"- Ignored-slot item frequency: {100 * ignored_slots / args.num_draws:.3f}%",
                f"- Dual success / fallback given requested: {100 * dual_success / max(1, dual_requested):.3f}% / {100 * dual_fallback / max(1, dual_requested):.3f}%",
                f"- Ignored loss exactly zero: {loss_diagnostic['ignored_prompt_contribution_exactly_zero']}",
                f"- Violations: {dict(violations)}",
                "",
            ]
        )
    )
    print(json.dumps(summary, indent=2))
    return 0 if not violations else 2


if __name__ == "__main__":
    raise SystemExit(main())
