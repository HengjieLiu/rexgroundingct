#!/usr/bin/env python3
"""Inspect one ReXGroundingCT finding and render multi-slice QC."""

from __future__ import annotations

import argparse
import json
import textwrap
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np


def lung_window(img: np.ndarray, center: float = -500.0, width: float = 1500.0) -> np.ndarray:
    lo = center - width / 2
    hi = center + width / 2
    return np.clip((img.astype(np.float32) - lo) / (hi - lo), 0, 1)


def display_lp(arr_xy: np.ndarray) -> np.ndarray:
    """Axial display with patient left on image-left and posterior at top."""
    return arr_xy.T[::-1, ::-1]


def overlay_rgba(mask: np.ndarray, color: tuple[float, float, float], alpha: float = 0.45) -> np.ndarray:
    rgba = np.zeros((*mask.shape, 4), dtype=np.float32)
    rgba[mask] = [*color, alpha]
    return rgba


def gt_pred_overlay(gt: np.ndarray, pred: np.ndarray) -> np.ndarray:
    rgba = np.zeros((*gt.shape, 4), dtype=np.float32)
    rgba[gt & ~pred] = [0.0, 0.9, 0.25, 0.48]
    rgba[pred & ~gt] = [1.0, 0.1, 0.1, 0.45]
    rgba[gt & pred] = [1.0, 0.9, 0.0, 0.65]
    return rgba


def draw_orientation_labels(ax: plt.Axes) -> None:
    ax.text(0.02, 0.50, "L", transform=ax.transAxes, color="white", fontsize=10, weight="bold", va="center")
    ax.text(0.98, 0.50, "R", transform=ax.transAxes, color="white", fontsize=10, weight="bold", ha="right", va="center")
    ax.text(0.50, 0.03, "A", transform=ax.transAxes, color="white", fontsize=10, weight="bold", ha="center")
    ax.text(0.50, 0.97, "P", transform=ax.transAxes, color="white", fontsize=10, weight="bold", ha="center", va="top")


def load_rex_entry(rex_json: Path, case: str) -> tuple[str, dict]:
    with rex_json.open() as f:
        data = json.load(f)
    for split, rows in data.items():
        for row in rows:
            name = row.get("name") or row.get("image") or row.get("image_name")
            if name == case:
                return split, row
    raise KeyError(f"{case} not found in {rex_json}")


def dict_get_index(mapping: dict | list, idx: int, default=None):
    if isinstance(mapping, dict):
        return mapping.get(str(idx), mapping.get(idx, default))
    if isinstance(mapping, list) and idx < len(mapping):
        return mapping[idx]
    return default


def half_stats(mask: np.ndarray) -> dict:
    stats = {}
    for axis, name in [(0, "x"), (1, "y"), (2, "z")]:
        mid = mask.shape[axis] // 2
        low = [slice(None)] * 3
        high = [slice(None)] * 3
        low[axis] = slice(0, mid)
        high[axis] = slice(mid, None)
        stats[f"{name}_lt_mid_voxels"] = int(mask[tuple(low)].sum())
        stats[f"{name}_ge_mid_voxels"] = int(mask[tuple(high)].sum())
        stats[f"{name}_mid"] = int(mid)
    return stats


def z_summary(mask: np.ndarray, region: tuple[str, int, slice]) -> dict:
    label, axis, region_slice = region
    sub = mask[region_slice, :, :] if axis == 0 else mask[:, region_slice, :]
    per_z = sub.sum(axis=(0, 1))
    nz = np.where(per_z > 0)[0]
    return {
        "label": label,
        "z_range": [int(nz.min()), int(nz.max())] if nz.size else None,
        "max_z": int(per_z.argmax()),
        "max_voxels": int(per_z.max()),
    }


def select_slices(gt: np.ndarray, pred: np.ndarray | None) -> list[tuple[int, str]]:
    xmid = gt.shape[0] // 2
    ymid = gt.shape[1] // 2
    candidates: list[tuple[int, str]] = []
    for arr, name in [
        (gt.sum(axis=(0, 1)), "max GT"),
        (gt[:xmid].sum(axis=(0, 1)), "max GT x<mid"),
        (gt[xmid:].sum(axis=(0, 1)), "max GT x>=mid"),
        (gt[:, :ymid].sum(axis=(0, 1)), "max GT y<mid"),
        (gt[:, ymid:].sum(axis=(0, 1)), "max GT y>=mid"),
    ]:
        if arr.max() > 0:
            candidates.append((int(arr.argmax()), name))
    if pred is not None:
        inter = (gt & pred).sum(axis=(0, 1))
        if inter.max() > 0:
            candidates.insert(0, (int(inter.argmax()), "max overlap"))
        pred_z = pred.sum(axis=(0, 1))
        if pred_z.max() > 0:
            candidates.append((int(pred_z.argmax()), "max pred"))
    candidates.append((78, "previous category-example slice"))
    seen = set()
    out = []
    for z, label in candidates:
        if 0 <= z < gt.shape[2] and z not in seen:
            out.append((z, label))
            seen.add(z)
    return out[:8]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", default="train_13252_b_2.nii.gz")
    parser.add_argument("--finding-idx", type=int, default=1, help="0-based finding index")
    parser.add_argument("--rex-json", type=Path, default=Path("data/MICCAI_challenge_dataset.json"))
    parser.add_argument("--image-dir", type=Path, default=Path("data/ct_rate_volumes_fixed"))
    parser.add_argument("--mask-dir", type=Path, default=Path("data/segmentations"))
    parser.add_argument(
        "--pred-dir",
        type=Path,
        default=Path("outputs/voxtell_rex_aug_lr1e6_step500_fullvol_val_predictions"),
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("outputs/analysis_prompt_embedding_failures_aug_step500/case_checks"),
    )
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    split, entry = load_rex_entry(args.rex_json, args.case)
    prompt = dict_get_index(entry.get("findings", {}), args.finding_idx, "")
    category = dict_get_index(entry.get("categories", {}), args.finding_idx, "")
    expected_pixels = dict_get_index(entry.get("pixels", {}), args.finding_idx, None)

    image_nii = nib.load(str(args.image_dir / args.case))
    seg_nii = nib.load(str(args.mask_dir / args.case))
    gt = np.asarray(seg_nii.dataobj[args.finding_idx], dtype=np.uint8) > 0

    pred_path = args.pred_dir / args.case
    pred = None
    if pred_path.exists():
        pred_nii = nib.load(str(pred_path))
        pred = np.asarray(pred_nii.dataobj[args.finding_idx], dtype=np.uint8) > 0

    coords = np.argwhere(gt)
    stats = {
        "case": args.case,
        "split": split,
        "finding_idx_0based": args.finding_idx,
        "finding_number_1based": args.finding_idx + 1,
        "category": category,
        "prompt": prompt,
        "expected_pixels_from_json": expected_pixels,
        "ct_shape": list(image_nii.shape),
        "seg_shape": list(seg_nii.shape),
        "gt_voxels": int(gt.sum()),
        "gt_bbox_xyz": {"min": coords.min(0).tolist(), "max": coords.max(0).tolist()} if coords.size else None,
        "gt_half_stats": half_stats(gt),
        "gt_z_summaries": [
            z_summary(gt, ("x<mid", 0, slice(0, gt.shape[0] // 2))),
            z_summary(gt, ("x>=mid", 0, slice(gt.shape[0] // 2, None))),
            z_summary(gt, ("y<mid", 1, slice(0, gt.shape[1] // 2))),
            z_summary(gt, ("y>=mid", 1, slice(gt.shape[1] // 2, None))),
        ],
    }
    if pred is not None:
        inter = np.logical_and(gt, pred)
        stats["prediction"] = {
            "pred_dir": str(args.pred_dir),
            "pred_voxels": int(pred.sum()),
            "intersection_voxels": int(inter.sum()),
            "dice": float(2 * inter.sum() / (gt.sum() + pred.sum() + 1e-8)),
            "pred_half_stats": half_stats(pred),
        }

    stem = f"{args.case.replace('.nii.gz', '')}_finding{args.finding_idx + 1}"
    stats_path = args.out_dir / f"{stem}_qc_stats.json"
    with stats_path.open("w") as f:
        json.dump(stats, f, indent=2)

    slices = select_slices(gt, pred)
    n_rows = len(slices)
    n_cols = 3 if pred is not None else 2
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(4.8 * n_cols, 3.8 * n_rows), constrained_layout=True)
    if n_rows == 1:
        axes = axes[None, :]
    title = f"{args.case} | finding {args.finding_idx + 1} | {category}\n{textwrap.fill(str(prompt), 90)}"
    fig.suptitle(title, fontsize=13)
    for row, (z, reason) in enumerate(slices):
        img = np.asarray(image_nii.dataobj[:, :, z], dtype=np.float32)
        ct_lp = display_lp(lung_window(img))
        gt_lp = display_lp(gt[:, :, z])
        axes[row, 0].imshow(ct_lp, cmap="gray", interpolation="nearest")
        axes[row, 0].set_title(f"CT z={z} ({reason})")
        draw_orientation_labels(axes[row, 0])
        axes[row, 1].imshow(ct_lp, cmap="gray", interpolation="nearest")
        axes[row, 1].imshow(overlay_rgba(gt_lp, (0.0, 0.9, 0.25)), interpolation="nearest")
        if gt_lp.any():
            axes[row, 1].contour(gt_lp.astype(float), levels=[0.5], colors=["#00ff66"], linewidths=0.8)
        axes[row, 1].set_title(f"GT voxels on slice: {int(gt[:, :, z].sum())}")
        draw_orientation_labels(axes[row, 1])
        if pred is not None:
            pred_lp = display_lp(pred[:, :, z])
            axes[row, 2].imshow(ct_lp, cmap="gray", interpolation="nearest")
            axes[row, 2].imshow(gt_pred_overlay(gt_lp, pred_lp), interpolation="nearest")
            if gt_lp.any():
                axes[row, 2].contour(gt_lp.astype(float), levels=[0.5], colors=["#00ff66"], linewidths=0.8)
            if pred_lp.any():
                axes[row, 2].contour(pred_lp.astype(float), levels=[0.5], colors=["#ff3333"], linewidths=0.8)
            axes[row, 2].set_title("GT green, pred red, overlap yellow")
            draw_orientation_labels(axes[row, 2])
        for ax in axes[row]:
            ax.set_xticks([])
            ax.set_yticks([])

    png_path = args.out_dir / f"{stem}_multislice_qc.png"
    fig.savefig(png_path, dpi=180)
    plt.close(fig)
    print(f"Stats: {stats_path}")
    print(f"PNG: {png_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
