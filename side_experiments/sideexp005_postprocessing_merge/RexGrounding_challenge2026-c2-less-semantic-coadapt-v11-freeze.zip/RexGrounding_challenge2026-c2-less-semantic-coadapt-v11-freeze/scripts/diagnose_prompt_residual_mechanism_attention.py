#!/usr/bin/env python3
"""Compare baseline and shared-adapter S3 maps on the fixed 30-case cohort."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from scipy import ndimage


ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "VoxTell", ROOT / "scripts"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from diagnose_spatial_attention_localization import (  # noqa: E402
    load_rex_masks_in_preprocessed_ras,
)
from run_voxtell_rex_inference import (  # noqa: E402
    add_voxtell_to_path,
    load_entries,
    load_image,
    sorted_finding_keys,
    sorted_prompts,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--family", required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--adapter", type=Path, required=True)
    parser.add_argument("--category-gamma-json", type=Path, required=True)
    parser.add_argument("--paired-metrics", type=Path, required=True)
    parser.add_argument("--paired-branch")
    parser.add_argument("--paired-update", type=int, required=True)
    parser.add_argument("--selection", choices=["improvements", "degradations"], required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=ROOT
        / "outputs/prompt_standardization_rule_only_v1/"
        "stratified30_six_variant_ablation_v1/prepared_inputs/"
        "stratified_subset_manifest.json",
    )
    parser.add_argument(
        "--embedding-cache",
        type=Path,
        default=ROOT
        / "outputs/prompt_standardization_rule_only_v1/"
        "stratified30_six_variant_ablation_v1/prepared_inputs/"
        "qwen_original_subset30.pt",
    )
    parser.add_argument(
        "--rex-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json"
    )
    parser.add_argument(
        "--image-dir", type=Path, default=ROOT / "data/ct_rate_volumes_fixed"
    )
    parser.add_argument(
        "--mask-dir", type=Path, default=ROOT / "data/segmentations"
    )
    return parser.parse_args()


def key(case: str, finding_idx: int) -> str:
    return f"{case}::{int(finding_idx)}"


def selected_visualizations(args: argparse.Namespace, cases: set[str]) -> set[str]:
    frame = pd.read_csv(args.paired_metrics)
    if args.paired_branch is not None and "branch" in frame:
        frame = frame[
            (frame["branch"] == args.paired_branch)
            & (frame["update"] == args.paired_update)
        ]
    frame = frame[frame["file"].isin(cases)].copy()
    gamma = {
        str(category): float(value)
        for category, value in json.loads(
            args.category_gamma_json.read_text()
        ).items()
    }
    frame = frame[
        frame["category"].astype(str).map(lambda category: gamma.get(category, 0.0) > 0)
    ]
    ascending = args.selection == "degradations"
    primary = frame.sort_values("dice_delta", ascending=ascending).head(3)
    category_2c = frame[frame["category"].astype(str) == "2c"]
    if not category_2c.empty:
        category_2c = category_2c.iloc[
            [category_2c["dice_delta"].abs().argmax()]
        ]
    selected = pd.concat([primary, category_2c]).drop_duplicates(
        ["file", "finding_idx"]
    )
    return {
        key(row.file, int(row.finding_idx)) for row in selected.itertuples()
    }


def load_cache(path: Path) -> dict[tuple[str, str, int], torch.Tensor]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    return {
        (str(record["split"]), str(record["case"]), int(record["finding_idx"])): (
            payload["embeddings"][index].float()
        )
        for index, record in enumerate(payload["records"])
    }


def map_metrics(attention: np.ndarray, target: np.ndarray) -> dict[str, float | bool]:
    inside = attention[target]
    outside = attention[~target]
    flat = attention.astype(np.float64, copy=False).reshape(-1)
    total = float(flat.sum())
    probability = flat / total if total > 0 else np.full_like(flat, 1.0 / len(flat))
    entropy = float(-(probability * np.log(np.clip(probability, 1e-15, None))).sum())
    count = max(1, int(math.ceil(0.01 * flat.size)))
    top = np.argpartition(flat, flat.size - count)[-count:]
    target_flat = target.reshape(-1)
    return {
        "inside_mean": float(inside.mean()),
        "outside_mean": float(outside.mean()),
        "inside_outside_margin": float(inside.mean() - outside.mean()),
        "entropy": entropy,
        "effective_volume": float(math.exp(entropy)),
        "top_1pct_fraction_inside_gt": float(target_flat[top].mean()),
        "attention_peak_inside_gt": bool(target_flat[int(flat.argmax())]),
    }


def correlation(left: np.ndarray, right: np.ndarray) -> float:
    left = left.reshape(-1).astype(np.float64)
    right = right.reshape(-1).astype(np.float64)
    if left.std() == 0 or right.std() == 0:
        return float("nan")
    return float(np.corrcoef(left, right)[0, 1])


def save_visualization(
    path: Path,
    image: np.ndarray,
    target: np.ndarray,
    baseline_attention: np.ndarray,
    adapter_attention: np.ndarray,
    baseline_prediction: np.ndarray,
    adapter_prediction: np.ndarray,
    title: str,
) -> None:
    slice_index = int(np.argmax(target.sum(axis=(1, 2))))
    ct = image[slice_index]
    low, high = np.percentile(ct, [1, 99])
    fig, axes = plt.subplots(1, 5, figsize=(18, 4), constrained_layout=True)
    for axis in axes:
        axis.imshow(ct, cmap="gray", vmin=low, vmax=high)
        axis.axis("off")
    axes[0].contour(target[slice_index], levels=[0.5], colors="lime")
    axes[0].set_title("GT")
    axes[1].imshow(baseline_attention[slice_index], cmap="magma", alpha=0.65)
    axes[1].contour(target[slice_index], levels=[0.5], colors="lime")
    axes[1].set_title("Baseline S3")
    axes[2].imshow(adapter_attention[slice_index], cmap="magma", alpha=0.65)
    axes[2].contour(target[slice_index], levels=[0.5], colors="lime")
    axes[2].set_title("Adapter S3")
    difference = adapter_attention[slice_index] - baseline_attention[slice_index]
    bound = max(float(np.abs(difference).max()), 1e-6)
    axes[3].imshow(difference, cmap="coolwarm", vmin=-bound, vmax=bound, alpha=0.72)
    axes[3].contour(target[slice_index], levels=[0.5], colors="lime")
    axes[3].set_title("Adapter - baseline")
    axes[4].contour(target[slice_index], levels=[0.5], colors="lime")
    if baseline_prediction[slice_index].any():
        axes[4].contour(
            baseline_prediction[slice_index], levels=[0.5], colors="cyan"
        )
    if adapter_prediction[slice_index].any():
        axes[4].contour(
            adapter_prediction[slice_index], levels=[0.5], colors="red"
        )
    axes[4].set_title("GT green / base cyan / adapter red")
    fig.suptitle(title, fontsize=10)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=140)
    plt.close(fig)


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    case_dir = args.output_dir / "cases"
    visual_dir = args.output_dir / "visualizations"
    case_dir.mkdir(exist_ok=True)
    cases = json.loads(args.manifest.read_text())["cases"]
    case_set = set(map(str, cases))
    selected = selected_visualizations(args, case_set)
    entries = {
        entry["name"]: entry
        for entry in load_entries(args.rex_json, ["val"])
        if entry["name"] in case_set
    }
    cache = load_cache(args.embedding_cache)
    gamma = {
        str(name): float(value)
        for name, value in json.loads(args.category_gamma_json.read_text()).items()
    }
    add_voxtell_to_path(ROOT / "VoxTell")
    from voxtell.inference.predictor import VoxTellPredictor

    predictor = VoxTellPredictor(
        str(args.model_dir),
        device=torch.device("cuda:0"),
        load_text_backbone=False,
        prompt_adapter_path=str(args.adapter),
    )
    model = (
        predictor.network._orig_mod
        if hasattr(predictor.network, "_orig_mod")
        else predictor.network
    )
    scales = tuple(model.s3_attention_scales)

    for case_name in cases:
        output_path = case_dir / f"{case_name.removesuffix('.nii.gz')}.csv"
        if output_path.exists():
            continue
        entry = entries[case_name]
        prompts = sorted_prompts(entry)
        finding_keys = sorted_finding_keys(entry)
        categories = [
            str((entry.get("categories") or {}).get(index, "unknown"))
            for index in finding_keys
        ]
        embeddings = torch.stack(
            [
                cache[("val", case_name, int(finding_index))]
                for finding_index in finding_keys
            ]
        ).unsqueeze(0)
        gate_scales = torch.tensor(
            [gamma.get(category, 0.0) for category in categories],
            dtype=torch.float32,
        )
        image, properties = load_image(args.image_dir / case_name)
        data, bbox, _ = predictor.preprocess(image)
        target = load_rex_masks_in_preprocessed_ras(
            args.mask_dir / case_name, properties, len(prompts), bbox
        ).numpy().astype(bool)

        baseline_logits, baseline_maps = predictor.predict_sliding_window_return_logits(
            data,
            embeddings,
            spatial_attention_rho_scale=gate_scales,
            return_spatial_attention_maps_by_scale=True,
            apply_prompt_residual_adapter=False,
        )
        adapter_logits, adapter_maps = predictor.predict_sliding_window_return_logits(
            data,
            embeddings,
            spatial_attention_rho_scale=gate_scales,
            return_spatial_attention_maps_by_scale=True,
            prompt_adapter_injection_mode="shared",
        )
        baseline_probability = torch.sigmoid(baseline_logits.float()).cpu().numpy()
        adapter_probability = torch.sigmoid(adapter_logits.float()).cpu().numpy()
        baseline_prediction = baseline_probability > 0.5
        adapter_prediction = adapter_probability > 0.5
        rows = []
        for finding_position, finding_index in enumerate(finding_keys):
            category = categories[finding_position]
            if gamma.get(category, 0.0) == 0.0:
                continue
            truth = target[finding_position]
            if not truth.any():
                continue
            baseline_fn = truth & ~baseline_prediction[finding_position]
            adapter_added_fn = (
                truth
                & baseline_prediction[finding_position]
                & ~adapter_prediction[finding_position]
            )
            boundary = ndimage.binary_dilation(truth, iterations=2) ^ ndimage.binary_erosion(
                truth, iterations=2
            )
            for scale in scales:
                base_attention = baseline_maps[scale][finding_position].float().cpu().numpy()
                adapted_attention = adapter_maps[scale][finding_position].float().cpu().numpy()
                base_metrics = map_metrics(base_attention, truth)
                adapted_metrics = map_metrics(adapted_attention, truth)
                row = {
                    "family": args.family,
                    "case_id": case_name,
                    "finding_idx": int(finding_index),
                    "category": category,
                    "prompt": prompts[finding_position],
                    "pixels": int((entry.get("pixels") or {}).get(finding_index, truth.sum())),
                    "scale": scale,
                    "baseline_adapter_attention_correlation": correlation(
                        base_attention, adapted_attention
                    ),
                    **{f"baseline_{key}": value for key, value in base_metrics.items()},
                    **{f"adapter_{key}": value for key, value in adapted_metrics.items()},
                    "delta_inside_mean": adapted_metrics["inside_mean"]
                    - base_metrics["inside_mean"],
                    "delta_outside_mean": adapted_metrics["outside_mean"]
                    - base_metrics["outside_mean"],
                    "delta_margin": adapted_metrics["inside_outside_margin"]
                    - base_metrics["inside_outside_margin"],
                    "delta_entropy": adapted_metrics["entropy"]
                    - base_metrics["entropy"],
                    "delta_effective_volume": adapted_metrics["effective_volume"]
                    - base_metrics["effective_volume"],
                    "baseline_attention_on_baseline_fn": float(
                        base_attention[baseline_fn].mean()
                        if baseline_fn.any()
                        else np.nan
                    ),
                    "adapter_attention_on_baseline_fn": float(
                        adapted_attention[baseline_fn].mean()
                        if baseline_fn.any()
                        else np.nan
                    ),
                    "baseline_attention_on_adapter_added_fn": float(
                        base_attention[adapter_added_fn].mean()
                        if adapter_added_fn.any()
                        else np.nan
                    ),
                    "adapter_attention_on_adapter_added_fn": float(
                        adapted_attention[adapter_added_fn].mean()
                        if adapter_added_fn.any()
                        else np.nan
                    ),
                    "baseline_boundary_attention": float(
                        base_attention[boundary].mean()
                    ),
                    "adapter_boundary_attention": float(
                        adapted_attention[boundary].mean()
                    ),
                    "delta_boundary_attention": float(
                        adapted_attention[boundary].mean()
                        - base_attention[boundary].mean()
                    ),
                }
                rows.append(row)
                visual_key = key(case_name, int(finding_index))
                if visual_key in selected and scale == ("1/1" if "1/1" in scales else scales[-1]):
                    save_visualization(
                        visual_dir
                        / f"{case_name.removesuffix('.nii.gz')}_f{finding_index}_{scale.replace('/', 'over')}.png",
                        data[0].numpy(),
                        truth,
                        base_attention,
                        adapted_attention,
                        baseline_prediction[finding_position],
                        adapter_prediction[finding_position],
                        (
                            f"{args.family} | {case_name} finding {finding_index} "
                            f"| {category} | {prompts[finding_position]}"
                        ),
                    )
        pd.DataFrame(rows).to_csv(output_path, index=False)
        del baseline_logits, adapter_logits, baseline_maps, adapter_maps
        torch.cuda.empty_cache()

    frames = []
    for path in sorted(case_dir.glob("*.csv")):
        try:
            frame = pd.read_csv(path)
        except pd.errors.EmptyDataError:
            # A cohort case can contain no category enabled by this family's
            # S3 gamma policy.  Its empty per-case marker remains useful for
            # restart safety but contributes no attention rows.
            continue
        if not frame.empty:
            frames.append(frame)
    if not frames:
        raise RuntimeError("No S3-enabled attention rows were produced")
    output = pd.concat(frames, ignore_index=True)
    output.to_csv(args.output_dir / "attention_analysis.csv", index=False)
    summary = (
        output.groupby(["family", "scale"], as_index=False)
        .agg(
            findings=("finding_idx", "size"),
            mean_map_correlation=("baseline_adapter_attention_correlation", "mean"),
            mean_delta_inside=("delta_inside_mean", "mean"),
            mean_delta_outside=("delta_outside_mean", "mean"),
            mean_delta_margin=("delta_margin", "mean"),
            mean_delta_entropy=("delta_entropy", "mean"),
            mean_delta_effective_volume=("delta_effective_volume", "mean"),
            mean_delta_boundary_attention=("delta_boundary_attention", "mean"),
        )
    )
    summary.to_csv(args.output_dir / "attention_summary.csv", index=False)
    (args.output_dir / "status.json").write_text(
        json.dumps(
            {
                "status": "completed",
                "family": args.family,
                "cases": len(cases),
                "rows": len(output),
                "scales": scales,
                "visualizations": len(list(visual_dir.glob("*.png"))),
                "trained": False,
                "optimizer_steps": 0,
            },
            indent=2,
        )
        + "\n"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
