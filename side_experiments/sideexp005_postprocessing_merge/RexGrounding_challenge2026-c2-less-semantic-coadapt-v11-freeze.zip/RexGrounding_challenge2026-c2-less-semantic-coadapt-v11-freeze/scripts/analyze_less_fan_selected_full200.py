#!/usr/bin/env python3
"""Summarize selected C0--C3 full200 inference and paired case bootstrap."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EXP = ROOT / "outputs/less_fan_conditioning_10k"
OUT = EXP / "full200_selected"
ROWS = (
    ("C0 B0", "c0_b0_continue", 6800, "c0_b0_update6800", 0.30354305524320285),
    ("C1 Direct", "c1_a2_direct_continue", 5400, "c1_direct_update5400", 0.30057516276639495),
    ("C1 Direct", "c1_a2_direct_continue", 7000, "c1_direct_update7000", 0.2908231891477578),
    ("C2 LESS", "c2_less_encoder_conditioning", 3600, "c2_less_update3600", 0.30614578586036156),
    ("C2 LESS", "c2_less_encoder_conditioning", 9000, "c2_less_update9000", 0.29726168022006133),
    ("C3 Faithful-FAN", "c3_faithful_fan", 7000, "c3_faithful_fan_update7000", 0.29956362787310525),
)
BASELINE = "c0_b0_update6800"
PAIRS = (
    ("c2_less_update3600", BASELINE),
    ("c2_less_update9000", BASELINE),
    ("c1_direct_update5400", BASELINE),
    ("c1_direct_update7000", BASELINE),
    ("c3_faithful_fan_update7000", BASELINE),
    ("c2_less_update3600", "c2_less_update9000"),
    ("c1_direct_update5400", "c1_direct_update7000"),
)


def summary_path(label: str) -> Path:
    return OUT / label / "summary.json"


def per_finding_path(label: str) -> Path:
    return OUT / label / "summary_tables/per_finding_metrics.csv"


def full_row(arm: str, update: int, label: str, fixed30: float) -> dict[str, object]:
    summary = json.loads(summary_path(label).read_text())
    df = pd.read_csv(per_finding_path(label))
    volume = df["pred_voxels"].astype(float) * df["voxel_volume_mm3"].astype(float)
    return {
        "arm": arm,
        "update": update,
        "label": label,
        "fixed30_dice": fixed30,
        "full200_dice": float(summary["mean_global_dice_per_finding"]),
        "hit": int(summary["total_hits"]),
        "findings": int(summary["total_findings"]),
        "mean_predicted_volume_mm3": float(volume.mean()),
        "median_predicted_volume_mm3": float(volume.median()),
        "empty_prediction_count": int((df["pred_voxels"].astype(float) == 0).sum()),
        "wall_seconds": int(summary.get("wall_seconds", 0)),
        "checkpoint": str(EXP / next(r[1] for r in ROWS if r[3] == label) / "checkpoints" / f"checkpoint_update_{update}.pth"),
        "output_dir": str(OUT / label),
    }


def paired(candidate: str, control: str, n_boot: int = 5000) -> dict[str, object]:
    cand = pd.read_csv(per_finding_path(candidate))
    ctrl = pd.read_csv(per_finding_path(control))
    merged = cand.merge(ctrl, on=["file", "finding_idx"], suffixes=("_candidate", "_control"))
    if len(merged) != 381:
        raise RuntimeError(f"Expected 381 paired findings for {candidate} vs {control}, got {len(merged)}")
    delta = (merged["global_dice_candidate"].astype(float) - merged["global_dice_control"].astype(float)).to_numpy()
    groups = [indices.to_numpy() for _, indices in merged.groupby("file", sort=True).groups.items()]
    rng = np.random.default_rng(20260822)
    boot = np.empty(n_boot, dtype=np.float64)
    for i in range(n_boot):
        sampled = rng.integers(0, len(groups), size=len(groups))
        sampled_delta = np.concatenate([delta[groups[j]] for j in sampled])
        boot[i] = float(sampled_delta.mean())
    return {
        "comparison": f"{candidate} - {control}",
        "candidate": candidate,
        "control": control,
        "findings": int(len(merged)),
        "mean_paired_dice_delta": float(delta.mean()),
        "median_paired_dice_delta": float(np.median(delta)),
        "improved": int((delta > 1e-12).sum()),
        "worsened": int((delta < -1e-12).sum()),
        "tied": int((np.abs(delta) <= 1e-12).sum()),
        "hit_delta": int(merged["global_hit_candidate"].astype(int).sum() - merged["global_hit_control"].astype(int).sum()),
        "case_cluster_bootstrap_ci_low": float(np.percentile(boot, 2.5)),
        "case_cluster_bootstrap_ci_high": float(np.percentile(boot, 97.5)),
        "bootstrap_replicates": n_boot,
    }


def md_table(columns: list[str], rows: list[list[object]]) -> list[str]:
    return [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
        *["| " + " | ".join(str(v) for v in row) + " |" for row in rows],
    ]


def main() -> int:
    missing = [label for _, _, _, label, _ in ROWS if not summary_path(label).is_file() or not per_finding_path(label).is_file()]
    OUT.mkdir(parents=True, exist_ok=True)
    if missing:
        (OUT / "analysis_status.json").write_text(json.dumps({"status": "pending", "missing": missing}, indent=2) + "\n")
        print("Pending full200 results: " + ", ".join(missing))
        return 2

    full = [full_row(row[0], row[2], row[3], row[4]) for row in ROWS]
    by_label = {str(row["label"]): row for row in full}
    pairs = [paired(a, b) for a, b in PAIRS]
    pd.DataFrame(full).to_csv(OUT / "full200_summary.csv", index=False)
    pd.DataFrame(pairs).to_csv(OUT / "paired_case_cluster_bootstrap.csv", index=False)

    c0 = by_label[BASELINE]
    c1 = [by_label["c1_direct_update5400"], by_label["c1_direct_update7000"]]
    c2 = [by_label["c2_less_update3600"], by_label["c2_less_update9000"]]
    c3 = by_label["c3_faithful_fan_update7000"]
    best_c1 = max(c1, key=lambda r: float(r["full200_dice"]))
    best_c2 = max(c2, key=lambda r: float(r["full200_dice"]))
    recommendations = {
        "C2 checkpoint for causal testing": best_c2["label"],
        "C1 checkpoint for causal testing": best_c1["label"] if float(best_c1["full200_dice"]) >= float(c0["full200_dice"]) else "none (does not match C0 full200)",
        "C3 causal priority": "yes" if float(c3["full200_dice"]) >= float(c0["full200_dice"]) else "no (below C0 full200)",
    }
    status = {"status": "complete", "recommendations": recommendations}
    (OUT / "analysis_status.json").write_text(json.dumps(status, indent=2) + "\n")

    lines = [
        "# C0--C3 Selected Checkpoint Full200 Validation",
        "",
        "Protocol: canonical raw ReXGroundingCT val split; 200 cases / 381 findings; threshold 0.5; BF16; no token manipulation or postprocessing.",
        "",
        "## Full200 summary",
        "",
        *md_table(
            ["Arm", "Update", "Fixed30 Dice", "Full200 Dice", "HIT", "Mean pred volume (mm³)", "Median volume (mm³)", "Empty"],
            [[r["arm"], r["update"], f'{r["fixed30_dice"]:.5f}', f'{r["full200_dice"]:.6f}', f'{r["hit"]}/{r["findings"]}', f'{r["mean_predicted_volume_mm3"]:.2f}', f'{r["median_predicted_volume_mm3"]:.2f}', r["empty_prediction_count"]] for r in full],
        ),
        "",
        "## Paired case-cluster bootstrap",
        "",
        *md_table(
            ["Comparison", "Mean Δ", "Median Δ", "95% CI", "Improved", "Worsened", "Tied", "HIT Δ"],
            [[p["comparison"], f'{p["mean_paired_dice_delta"]:.6f}', f'{p["median_paired_dice_delta"]:.6f}', f'[{p["case_cluster_bootstrap_ci_low"]:.6f}, {p["case_cluster_bootstrap_ci_high"]:.6f}]', p["improved"], p["worsened"], p["tied"], p["hit_delta"]] for p in pairs],
        ),
        "",
        "## Decision for later token-causal testing",
        "",
        f"1. C2 @3600 remains strongest LESS checkpoint on full200: {'YES' if best_c2['label'] == 'c2_less_update3600' else 'NO'}.",
        f"2. Late C2 @9000 generalizes better than @3600: {'YES' if best_c2['label'] == 'c2_less_update9000' else 'NO'}.",
        f"3. C1 @7000 outperforms C1 @5400 on full200: {'YES' if best_c1['label'] == 'c1_direct_update7000' else 'NO'}.",
        f"4. C1 causal recommendation: {recommendations['C1 checkpoint for causal testing']}.",
        f"5. C2 causal recommendation: {recommendations['C2 checkpoint for causal testing']}.",
        f"6. C3 @7000 is competitive enough for causal testing: {recommendations['C3 causal priority']}.",
        "",
        "No shuffle, neutral, cross-category, or other causal inference was run in this task.",
    ]
    (OUT / "report.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
