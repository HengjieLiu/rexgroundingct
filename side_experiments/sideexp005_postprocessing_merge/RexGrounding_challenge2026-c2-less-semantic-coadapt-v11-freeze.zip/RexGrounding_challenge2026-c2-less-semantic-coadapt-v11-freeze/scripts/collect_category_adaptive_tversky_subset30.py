#!/usr/bin/env python3
"""Collect matched subset evaluations for Dice control versus adaptive Tversky."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        default=ROOT / "outputs/category_adaptive_tversky_subset30",
    )
    parser.add_argument(
        "--mapping-csv",
        type=Path,
        default=ROOT / "outputs/category_adaptive_tversky_audit/category_mapping.csv",
    )
    parser.add_argument("--steps", nargs="+", type=int, default=[200, 400, 600])
    return parser.parse_args()


def load_run(root: Path, branch: str, step: int) -> pd.DataFrame:
    path = root / branch / f"step{step}" / "per_finding_metrics.csv"
    if not path.is_file():
        raise FileNotFoundError(path)
    frame = pd.read_csv(path)
    required = {
        "file",
        "finding_idx",
        "category",
        "global_dice",
        "global_hit",
        "voxel_precision",
        "voxel_recall",
        "fp_mm3",
        "fn_mm3",
        "pred_gt_volume_ratio",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"{path} missing {missing}")
    return frame


def run_summary(frame: pd.DataFrame, branch: str, step: int) -> dict:
    case_dice = frame.groupby("file")["global_dice"].mean()
    return {
        "step": step,
        "branch": branch,
        "findings": len(frame),
        "cases": frame["file"].nunique(),
        "dice_per_finding": frame["global_dice"].mean(),
        "dice_per_case": case_dice.mean(),
        "hit_rate": frame["global_hit"].mean(),
        "hits": int(frame["global_hit"].sum()),
        "misses": int((~frame["global_hit"].astype(bool)).sum()),
        "precision": frame["voxel_precision"].mean(),
        "recall": frame["voxel_recall"].mean(),
        "median_fp_mm3": frame["fp_mm3"].median(),
        "median_fn_mm3": frame["fn_mm3"].median(),
        "median_pred_gt_volume_ratio": frame["pred_gt_volume_ratio"].median(),
        "positive_predicted_volume_mm3": (
            frame["pred_voxels"] * frame["voxel_volume_mm3"]
        ).sum(),
    }


def paired_rows(
    control: pd.DataFrame,
    test: pd.DataFrame,
    step: int,
    group_map: dict[str, str],
) -> pd.DataFrame:
    keys = ["file", "finding_idx"]
    control_cols = keys + [
        "category",
        "prompt",
        "global_dice",
        "global_hit",
        "voxel_precision",
        "voxel_recall",
        "fp_mm3",
        "fn_mm3",
        "pred_gt_volume_ratio",
    ]
    test_cols = keys + [
        "global_dice",
        "global_hit",
        "voxel_precision",
        "voxel_recall",
        "fp_mm3",
        "fn_mm3",
        "pred_gt_volume_ratio",
    ]
    paired = control[control_cols].merge(
        test[test_cols], on=keys, suffixes=("_control", "_test"), validate="one_to_one"
    )
    paired.insert(0, "step", step)
    paired["assigned_group"] = paired["category"].astype(str).map(group_map).fillna("mixed")
    for metric in (
        "global_dice",
        "voxel_precision",
        "voxel_recall",
        "fp_mm3",
        "fn_mm3",
        "pred_gt_volume_ratio",
    ):
        paired[f"delta_{metric}"] = paired[f"{metric}_test"] - paired[f"{metric}_control"]
    paired["dice_improved"] = paired["delta_global_dice"] > 0
    paired["hit_delta"] = paired["global_hit_test"].astype(int) - paired["global_hit_control"].astype(int)
    return paired


def grouped_summary(paired: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (step, group), sub in paired.groupby(["step", "assigned_group"], sort=True):
        control_fp = sub["fp_mm3_control"].sum()
        test_fp = sub["fp_mm3_test"].sum()
        rows.append(
            {
                "step": step,
                "assigned_group": group,
                "n": len(sub),
                "control_dice": sub["global_dice_control"].mean(),
                "test_dice": sub["global_dice_test"].mean(),
                "paired_mean_dice_delta": sub["delta_global_dice"].mean(),
                "fraction_findings_improved": sub["dice_improved"].mean(),
                "control_precision": sub["voxel_precision_control"].mean(),
                "test_precision": sub["voxel_precision_test"].mean(),
                "control_recall": sub["voxel_recall_control"].mean(),
                "test_recall": sub["voxel_recall_test"].mean(),
                "recall_delta": sub["delta_voxel_recall"].mean(),
                "control_total_fp_mm3": control_fp,
                "test_total_fp_mm3": test_fp,
                "relative_fp_change": (test_fp - control_fp) / max(control_fp, np.finfo(float).eps),
                "control_total_fn_mm3": sub["fn_mm3_control"].sum(),
                "test_total_fn_mm3": sub["fn_mm3_test"].sum(),
                "control_hit_count": int(sub["global_hit_control"].sum()),
                "test_hit_count": int(sub["global_hit_test"].sum()),
            }
        )
    return pd.DataFrame(rows)


def decision(overall: pd.DataFrame, groups: pd.DataFrame) -> dict:
    comparisons = overall.pivot(index="step", columns="branch")
    candidate_rows = []
    for step in sorted(overall.step.unique()):
        control = overall[(overall.step == step) & (overall.branch == "control")].iloc[0]
        test = overall[(overall.step == step) & (overall.branch == "adaptive")].iloc[0]
        group = groups[(groups.step == step) & (groups.assigned_group == "fp_heavy")]
        fp_ok = False
        fp_change = np.nan
        recall_delta = np.nan
        target_fraction = np.nan
        if not group.empty:
            fp_change = float(group.iloc[0].relative_fp_change)
            recall_delta = float(group.iloc[0].recall_delta)
            target_fraction = float(group.iloc[0].fraction_findings_improved)
            fp_ok = fp_change <= -0.05 and recall_delta >= -0.02
        dice_delta = float(test.dice_per_finding - control.dice_per_finding)
        hit_ok = int(test.hits) >= int(control.hits)
        candidate_rows.append(
            {
                "step": int(step),
                "paired_mean_dice_delta": dice_delta,
                "hit_count_not_lower": hit_ok,
                "fp_heavy_relative_fp_change": fp_change,
                "fp_heavy_recall_delta": recall_delta,
                "fp_heavy_fraction_improved": target_fraction,
                "passes": bool(hit_ok and target_fraction >= 0.60 and (dice_delta >= 0.003 or fp_ok)),
            }
        )
    candidates = pd.DataFrame(candidate_rows)
    passing = candidates[candidates.passes]
    best = candidates.sort_values("paired_mean_dice_delta", ascending=False).iloc[0]
    recommended = not passing.empty
    selected = (
        passing.sort_values("paired_mean_dice_delta", ascending=False).iloc[0]
        if recommended
        else best
    )
    return {
        "recommend_full_200_case_evaluation": bool(recommended),
        "selected_step": int(selected.step),
        "reason": (
            "At least one matched checkpoint met the predeclared Dice/FP, improvement-fraction, and hit criteria."
            if recommended
            else "No matched checkpoint met the predeclared subset criteria; stop before full evaluation."
        ),
        "per_step": candidates.to_dict(orient="records"),
    }


def main() -> int:
    args = parse_args()
    mapping = pd.read_csv(args.mapping_csv)
    group_map = dict(zip(mapping.category.astype(str), mapping.assigned_group.astype(str)))
    all_pairs = []
    summaries = []
    for step in args.steps:
        control = load_run(args.root, "control", step)
        test = load_run(args.root, "adaptive", step)
        if set(zip(control.file, control.finding_idx)) != set(zip(test.file, test.finding_idx)):
            raise RuntimeError(f"Control/test finding keys differ at step {step}")
        summaries.extend([run_summary(control, "control", step), run_summary(test, "adaptive", step)])
        all_pairs.append(paired_rows(control, test, step, group_map))
    overall = pd.DataFrame(summaries)
    paired = pd.concat(all_pairs, ignore_index=True)
    groups = grouped_summary(paired)
    result = decision(overall, groups)
    overall.to_csv(args.root / "overall_summary.csv", index=False)
    paired.to_csv(args.root / "paired_per_finding.csv", index=False)
    groups.to_csv(args.root / "paired_group_summary.csv", index=False)
    (args.root / "decision.json").write_text(json.dumps(result, indent=2) + "\n")
    report = [
        "# Category-adaptive Tversky short experiment",
        "",
        "## Overall",
        "",
        "```text",
        overall.round(6).to_string(index=False),
        "```",
        "",
        "## Paired groups",
        "",
        "```text",
        groups.round(6).to_string(index=False),
        "```",
        "",
        "## Decision",
        "",
        f"Recommend full 200-case evaluation: **{result['recommend_full_200_case_evaluation']}**",
        f"Selected checkpoint: step {result['selected_step']}",
        result["reason"],
        "",
    ]
    (args.root / "report.md").write_text("\n".join(report))
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
