#!/usr/bin/env python3
"""Diagnose whether VoxTell prompt spatial attention localizes ReX lesions."""

from __future__ import annotations

import argparse
import json
import math
import sys
import textwrap
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import pandas as pd
import torch
from nibabel.orientations import io_orientation
from scipy import ndimage


REX_ROOT = Path(__file__).resolve().parents[1]
if str(REX_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(REX_ROOT / "scripts"))

from run_voxtell_rex_inference import (  # noqa: E402
    add_voxtell_to_path,
    load_entries,
    load_image,
    sorted_finding_keys,
    sorted_prompts,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rex-json", type=Path, default=REX_ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--image-dir", type=Path, default=REX_ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--mask-dir", type=Path, default=REX_ROOT / "data/segmentations")
    parser.add_argument(
        "--model-dir",
        type=Path,
        default=REX_ROOT / "outputs/H-S1_beta1p5_step1000_inference_model",
    )
    parser.add_argument(
        "--finding-metrics",
        type=Path,
        default=(
            REX_ROOT
            / "outputs/spatial_attention_ablation_s1_beta1p5_step1000"
            / "category_focaloff_2c_on/per_finding_metrics.csv"
        ),
    )
    parser.add_argument(
        "--category-gamma-json",
        type=Path,
        default=(
            REX_ROOT
            / "outputs/spatial_attention_ablation_s1_beta1p5_step1000"
            / "category_focaloff_2c_on/category_gamma.json"
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REX_ROOT / "outputs/s1_step1000_attention_localization_diagnostic",
    )
    parser.add_argument("--voxtell-repo", type=Path, default=REX_ROOT / "VoxTell")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260714)
    parser.add_argument("--per-category", type=int, default=3)
    parser.add_argument("--priority-per-category", type=int, default=8)
    parser.add_argument("--priority-categories", nargs="+", default=["2c", "2d"])
    parser.add_argument("--max-findings", type=int, default=49)
    parser.add_argument("--max-example-pngs", type=int, default=49)
    parser.add_argument("--selection-only", action="store_true")
    return parser.parse_args()


def evenly_spaced_rows(group: pd.DataFrame, count: int) -> pd.DataFrame:
    group = group.sort_values(["global_dice", "file", "finding_idx"]).reset_index(drop=True)
    if len(group) <= count:
        return group
    indices = np.linspace(0, len(group) - 1, count).round().astype(int)
    return group.iloc[np.unique(indices)]


def select_findings(args: argparse.Namespace, entries: list[dict]) -> pd.DataFrame:
    entry_names = {entry["name"] for entry in entries}
    metrics = pd.read_csv(args.finding_metrics)
    metrics = metrics.loc[metrics["file"].isin(entry_names)].copy()
    metrics = metrics.loc[
        metrics["file"].map(lambda name: (args.image_dir / name).exists())
        & metrics["file"].map(lambda name: (args.mask_dir / name).exists())
    ]
    selected = []
    priority = set(args.priority_categories)
    for category, group in metrics.groupby("category", sort=True):
        count = args.priority_per_category if str(category) in priority else args.per_category
        selected.append(evenly_spaced_rows(group, count))
    result = pd.concat(selected, ignore_index=True)
    result = result.sort_values(["category", "global_dice", "file", "finding_idx"]).reset_index(drop=True)
    if len(result) > args.max_findings:
        keep_priority = result["category"].astype(str).isin(priority)
        priority_rows = result.loc[keep_priority]
        other_rows = result.loc[~keep_priority]
        remaining = max(0, args.max_findings - len(priority_rows))
        result = pd.concat([priority_rows, other_rows.head(remaining)], ignore_index=True)
        result = result.head(args.max_findings)
    return assign_shuffled_prompts(result)


def assign_shuffled_prompts(selected: pd.DataFrame) -> pd.DataFrame:
    result = selected.copy()
    shuffled_prompt = []
    shuffled_category = []
    shuffled_source = []
    rows = list(result.itertuples(index=False))
    for idx, row in enumerate(rows):
        candidate = None
        for offset in range(1, len(rows) + 1):
            other = rows[(idx + offset) % len(rows)]
            if str(other.category) != str(row.category) and other.file != row.file:
                candidate = other
                break
        if candidate is None:
            candidate = rows[(idx + 1) % len(rows)]
        shuffled_prompt.append(candidate.prompt)
        shuffled_category.append(str(candidate.category))
        shuffled_source.append(f"{candidate.file}:finding{int(candidate.finding_idx)}")
    result["shuffled_prompt"] = shuffled_prompt
    result["shuffled_category"] = shuffled_category
    result["shuffled_source"] = shuffled_source
    return result


def histogram_ranking_metrics(attention: np.ndarray, target: np.ndarray, bins: int = 2048) -> tuple[float, float]:
    pos = attention[target]
    neg = attention[~target]
    if pos.size == 0 or neg.size == 0:
        return float("nan"), float("nan")
    pos_hist, edges = np.histogram(pos, bins=bins, range=(0.0, 1.0))
    neg_hist, _ = np.histogram(neg, bins=edges)
    tp = np.cumsum(pos_hist[::-1], dtype=np.float64)
    fp = np.cumsum(neg_hist[::-1], dtype=np.float64)
    recall = tp / max(float(pos.size), 1.0)
    fpr = fp / max(float(neg.size), 1.0)
    precision = tp / np.maximum(tp + fp, 1.0)
    auroc = float(np.trapezoid(np.r_[0.0, recall], np.r_[0.0, fpr]))
    auprc = float(np.trapezoid(np.r_[1.0, precision], np.r_[0.0, recall]))
    return auroc, auprc


def approximate_gt_sized_topk(attention: np.ndarray, target: np.ndarray) -> tuple[float, float, float]:
    fraction = float(target.mean())
    if fraction <= 0:
        return float("nan"), float("nan"), float("nan")
    hist, edges = np.histogram(attention, bins=4096, range=(0.0, 1.0))
    descending = np.cumsum(hist[::-1])
    requested = max(1, int(target.sum()))
    reverse_idx = int(np.searchsorted(descending, requested, side="left"))
    threshold_idx = max(0, len(edges) - 2 - reverse_idx)
    threshold = float(edges[threshold_idx])
    selected = attention >= threshold
    intersection = int(np.logical_and(selected, target).sum())
    precision = intersection / max(int(selected.sum()), 1)
    recall = intersection / max(int(target.sum()), 1)
    return float(precision), float(recall), threshold


def sampled_correlation(first: np.ndarray, second: np.ndarray, max_points: int = 250_000) -> float:
    a = first.reshape(-1)
    b = second.reshape(-1)
    if a.size > max_points:
        step = max(1, a.size // max_points)
        a = a[::step][:max_points]
        b = b[::step][:max_points]
    if np.std(a) < 1e-8 or np.std(b) < 1e-8:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def attention_metrics(
    attention: np.ndarray,
    target: np.ndarray,
    spacing_zyx: tuple[float, float, float] = (1.0, 1.0, 1.0),
) -> dict[str, float | bool]:
    attention = np.clip(attention.astype(np.float32, copy=False), 0.0, 1.0)
    target = target.astype(bool, copy=False)
    gt_voxels = int(target.sum())
    total_voxels = int(target.size)
    if gt_voxels == 0:
        raise ValueError("Cannot evaluate attention against an empty target")
    gt_fraction = gt_voxels / total_voxels
    inside_mean = float(attention[target].mean())
    outside_mean = float(attention[~target].mean())
    total_energy = float(attention.sum())
    inside_energy_fraction = float(attention[target].sum() / max(total_energy, 1e-8))
    enrichment = inside_energy_fraction / max(gt_fraction, 1e-12)
    peak = np.unravel_index(int(np.argmax(attention)), attention.shape)
    pointing_hit = bool(target[peak])
    gt_coords = np.nonzero(target)
    peak_distance_sq = (
        (gt_coords[0] - peak[0]) ** 2
        + (gt_coords[1] - peak[1]) ** 2
        + (gt_coords[2] - peak[2]) ** 2
    )
    peak_distance = float(np.sqrt(peak_distance_sq.min()))
    peak_distance_mm = float(np.sqrt(
        min(
            ((gt_coords[0] - peak[0]) * spacing_zyx[0]) ** 2
            + ((gt_coords[1] - peak[1]) * spacing_zyx[1]) ** 2
            + ((gt_coords[2] - peak[2]) * spacing_zyx[2]) ** 2
        )
    ))
    dilated = ndimage.distance_transform_edt(~target, sampling=spacing_zyx) <= 5.0
    stable_score = np.log(np.clip(attention, 1e-4, 1 - 1e-4)) - np.log1p(-np.clip(attention, 1e-4, 1 - 1e-4))
    normalized = (stable_score - stable_score.mean()) / (stable_score.std() + 1e-6)
    exponent = normalized.reshape(-1) / 0.5
    exponent -= exponent.max()
    q = np.exp(exponent)
    q /= max(float(q.sum()), 1e-12)
    dilated_flat = dilated.reshape(-1)
    mass_dilated = float(q[dilated_flat].sum())
    rank_k = min(64, max(16, gt_voxels // 4))
    inside_values, outside_values = normalized[dilated], normalized[~dilated]
    inside_k, outside_k = min(rank_k, inside_values.size), min(rank_k, outside_values.size)
    inside_top = float(np.partition(inside_values, -inside_k)[-inside_k:].mean())
    outside_top = float(np.partition(outside_values, -outside_k)[-outside_k:].mean())
    topk_precision, topk_recall, topk_threshold = approximate_gt_sized_topk(attention, target)
    auroc, auprc = histogram_ranking_metrics(attention, target)
    return {
        "gt_voxels": gt_voxels,
        "gt_fraction": gt_fraction,
        "attention_inside_gt_mean": inside_mean,
        "attention_outside_gt_mean": outside_mean,
        "attention_inside_minus_outside": inside_mean - outside_mean,
        "attention_inside_outside_ratio": inside_mean / max(outside_mean, 1e-8),
        "attention_energy_inside_gt_fraction": inside_energy_fraction,
        "attention_enrichment": enrichment,
        "attention_pointing_hit": pointing_hit,
        "attention_peak_in_dilated_5mm": bool(dilated[peak]),
        "attention_peak_distance_voxels": peak_distance,
        "attention_peak_distance_mm": peak_distance_mm,
        "attention_softmax_mass_in_dilated_5mm": mass_dilated,
        "attention_rank_inside_minus_outside": inside_top - outside_top,
        "attention_gt_sized_topk_precision": topk_precision,
        "attention_gt_sized_topk_recall": topk_recall,
        "attention_gt_sized_topk_threshold": topk_threshold,
        "attention_voxel_auroc": auroc,
        "attention_voxel_auprc": auprc,
    }


def gt_component_recall(prediction: np.ndarray, target: np.ndarray, minimum_fraction: float = 0.10) -> float:
    labels, count = ndimage.label(target, structure=ndimage.generate_binary_structure(3, 2))
    if count == 0:
        return float("nan")
    detected = 0
    for component in range(1, count + 1):
        current = labels == component
        detected += float(np.logical_and(prediction, current).sum()) / max(int(current.sum()), 1) >= minimum_fraction
    return float(detected / count)


def dice_score(prediction: np.ndarray, target: np.ndarray) -> float:
    prediction = prediction.astype(bool, copy=False)
    target = target.astype(bool, copy=False)
    denominator = int(prediction.sum()) + int(target.sum())
    if denominator == 0:
        return 1.0
    return float(2 * np.logical_and(prediction, target).sum() / denominator)


def load_rex_masks_in_preprocessed_ras(
    mask_path: Path,
    image_properties: dict,
    finding_count: int,
    bbox,
) -> torch.Tensor:
    """Apply the same CT affine/orientation/crop transform used by training."""
    mask4 = np.asanyarray(nib.load(str(mask_path)).dataobj)
    if mask4.ndim != 4 or mask4.shape[0] != finding_count:
        raise ValueError(
            f"{mask_path}: expected {finding_count} first-axis masks, got {mask4.shape}"
        )
    image_affine = image_properties["nibabel_stuff"]["original_affine"]
    spatial_slices = tuple(
        item if isinstance(item, slice) else slice(int(item[0]), int(item[1]))
        for item in bbox
    )
    masks = []
    for finding_idx in range(finding_count):
        mask_nib = nib.Nifti1Image(mask4[finding_idx].astype(np.uint8, copy=False), image_affine)
        reoriented = mask_nib.as_reoriented(io_orientation(image_affine))
        mask_ras = np.asanyarray(reoriented.dataobj).transpose((2, 1, 0)) > 0
        masks.append(mask_ras[spatial_slices].astype(np.uint8, copy=False))
    return torch.from_numpy(np.stack(masks))


def contour(ax, mask: np.ndarray, color: str, linewidth: float = 1.2) -> None:
    if np.any(mask):
        ax.contour(mask.astype(float), levels=[0.5], colors=[color], linewidths=linewidth)


def save_example_png(
    path: Path,
    ct: np.ndarray,
    target: np.ndarray,
    prediction: np.ndarray,
    attention: np.ndarray,
    shuffled_attention: np.ndarray,
    row: dict,
) -> None:
    slice_idx = int(np.argmax(target.sum(axis=(1, 2))))
    image_slice = ct[slice_idx]
    gt_slice = target[slice_idx]
    pred_slice = prediction[slice_idx]
    att_slice = attention[slice_idx]
    shuffled_slice = shuffled_attention[slice_idx]
    low, high = np.percentile(image_slice, [1, 99])
    att_low = min(float(np.percentile(att_slice, 2)), float(np.percentile(shuffled_slice, 2)))
    att_high = max(float(np.percentile(att_slice, 98)), float(np.percentile(shuffled_slice, 98)))
    if math.isclose(att_low, att_high):
        att_low, att_high = 0.0, 1.0

    fig, axes = plt.subplots(1, 6, figsize=(22, 4.2), constrained_layout=True)
    for ax in axes:
        ax.imshow(image_slice, cmap="gray", vmin=low, vmax=high)
        ax.axis("off")
    axes[0].set_title("CT")
    contour(axes[1], gt_slice, "lime", 1.6)
    axes[1].set_title("GT")
    axes[2].imshow(att_slice, cmap="magma", alpha=0.62, vmin=att_low, vmax=att_high)
    contour(axes[2], gt_slice, "lime")
    axes[2].set_title("Correct-prompt attention")
    axes[3].imshow(shuffled_slice, cmap="magma", alpha=0.62, vmin=att_low, vmax=att_high)
    contour(axes[3], gt_slice, "lime")
    axes[3].set_title("Shuffled-prompt attention")
    contour(axes[4], gt_slice, "lime")
    contour(axes[4], pred_slice, "red")
    axes[4].set_title("GT green / pred red")
    axes[5].imshow(att_slice, cmap="magma", alpha=0.62, vmin=att_low, vmax=att_high)
    contour(axes[5], pred_slice, "cyan")
    axes[5].set_title("Attention + prediction")
    title = (
        f"{row['case_id']} finding {row['finding_idx']} | category {row['category']} | "
        f"Dice={row['segmentation_dice']:.3f} | enrichment={row['attention_enrichment']:.2f} | "
        f"shuffled={row['shuffled_attention_enrichment']:.2f}\n"
        + textwrap.fill(str(row["prompt"]), width=145)
    )
    fig.suptitle(title, fontsize=11)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=140)
    plt.close(fig)


def make_summary_plots(metrics: pd.DataFrame, output_dir: Path) -> None:
    categories = sorted(metrics["category"].astype(str).unique())
    correct = metrics.groupby("category")["attention_enrichment"].median().reindex(categories)
    shuffled = metrics.groupby("category")["shuffled_attention_enrichment"].median().reindex(categories)
    x = np.arange(len(categories))
    fig, ax = plt.subplots(figsize=(12, 5), constrained_layout=True)
    ax.bar(x - 0.2, correct, width=0.4, label="correct prompt", color="#3f7cac")
    ax.bar(x + 0.2, shuffled, width=0.4, label="shuffled prompt", color="#c76d5e")
    ax.axhline(1.0, color="black", linestyle="--", linewidth=1, label="uniform-map expectation")
    ax.set_xticks(x, categories)
    ax.set_ylabel("Median attention enrichment in GT")
    ax.set_title("Does attention concentrate in the lesion?")
    ax.legend()
    fig.savefig(output_dir / "attention_enrichment_by_category.png", dpi=160)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6), constrained_layout=True)
    for category, group in metrics.groupby("category"):
        ax.scatter(group["attention_enrichment"], group["segmentation_dice"], label=category, alpha=0.78)
    ax.axvline(1.0, color="black", linestyle="--", linewidth=1)
    ax.set_xlabel("Correct-prompt attention enrichment")
    ax.set_ylabel("Full-volume segmentation Dice")
    ax.set_title("Attention localization vs segmentation quality")
    ax.legend(ncol=2, fontsize=8)
    fig.savefig(output_dir / "attention_localization_vs_dice.png", dpi=160)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6), constrained_layout=True)
    ax.scatter(
        metrics["shuffled_attention_enrichment"],
        metrics["attention_enrichment"],
        c=metrics["segmentation_dice"],
        cmap="viridis",
        alpha=0.8,
    )
    bounds = [
        min(metrics["shuffled_attention_enrichment"].min(), metrics["attention_enrichment"].min()),
        max(metrics["shuffled_attention_enrichment"].max(), metrics["attention_enrichment"].max()),
    ]
    ax.plot(bounds, bounds, "k--", linewidth=1)
    ax.set_xlabel("Shuffled-prompt enrichment")
    ax.set_ylabel("Correct-prompt enrichment")
    ax.set_title("Prompt specificity of spatial attention")
    fig.savefig(output_dir / "correct_vs_shuffled_attention.png", dpi=160)
    plt.close(fig)


def exact_binomial_greater(successes: int, trials: int) -> float:
    """One-sided exact sign-test p-value under p=0.5."""
    if trials <= 0:
        return float("nan")
    tail = sum(math.comb(trials, k) for k in range(successes, trials + 1))
    return float(tail / (2**trials))


def summarize(
    metrics: pd.DataFrame,
    output_dir: Path,
    rho: float,
    attention_module: str,
    attention_scale: str,
) -> None:
    grouped = (
        metrics.groupby("category", sort=True)
        .agg(
            n=("attention_enrichment", "size"),
            mean_segmentation_dice=("segmentation_dice", "mean"),
            median_attention_enrichment=("attention_enrichment", "median"),
            median_shuffled_enrichment=("shuffled_attention_enrichment", "median"),
            median_correct_minus_shuffled=("attention_enrichment_delta_vs_shuffled", "median"),
            correct_better_fraction=(
                "attention_enrichment_delta_vs_shuffled",
                lambda values: float((values > 0).mean()),
            ),
            pointing_accuracy=("attention_pointing_hit", "mean"),
            median_gt_sized_topk_precision=("attention_gt_sized_topk_precision", "median"),
            median_peak_distance_voxels=("attention_peak_distance_voxels", "median"),
            median_voxel_auroc=("attention_voxel_auroc", "median"),
            median_voxel_auprc=("attention_voxel_auprc", "median"),
            median_map_correlation=("attention_map_correlation_with_shuffled", "median"),
        )
        .reset_index()
    )
    grouped.to_csv(output_dir / "attention_localization_by_category.csv", index=False)
    dice_corr = metrics[["segmentation_dice", "attention_enrichment"]].corr(method="spearman").iloc[0, 1]
    median_correct = float(metrics["attention_enrichment"].median())
    median_shuffled = float(metrics["shuffled_attention_enrichment"].median())
    median_delta = float(metrics["attention_enrichment_delta_vs_shuffled"].median())
    pointing = float(metrics["attention_pointing_hit"].mean())
    delta = metrics["attention_enrichment_delta_vs_shuffled"]
    better_count = int((delta > 0).sum())
    better_fraction = float(better_count / len(metrics))
    sign_test_p = exact_binomial_greater(better_count, len(metrics))
    median_corr = float(metrics["attention_map_correlation_with_shuffled"].median())
    median_topk_precision = float(metrics["attention_gt_sized_topk_precision"].median())
    median_peak_distance = float(metrics["attention_peak_distance_voxels"].median())
    median_auroc = float(metrics["attention_voxel_auroc"].median())
    median_auprc = float(metrics["attention_voxel_auprc"].median())
    summary = {
        "n_findings": int(len(metrics)),
        "n_cases": int(metrics["case_id"].nunique()),
        "attention_module": attention_module,
        "attention_scale": attention_scale,
        "spatial_attention_rho": rho,
        "median_correct_attention_enrichment": median_correct,
        "median_shuffled_attention_enrichment": median_shuffled,
        "median_correct_minus_shuffled_enrichment": median_delta,
        "fraction_correct_enrichment_above_shuffled": better_fraction,
        "correct_enrichment_above_shuffled_count": better_count,
        "correct_vs_shuffled_exact_sign_test_p": sign_test_p,
        "attention_pointing_accuracy": pointing,
        "median_gt_sized_topk_precision": median_topk_precision,
        "median_attention_peak_distance_voxels": median_peak_distance,
        "median_attention_voxel_auroc": median_auroc,
        "median_attention_voxel_auprc": median_auprc,
        "median_correct_shuffled_map_correlation": median_corr,
        "spearman_attention_enrichment_vs_segmentation_dice": float(dice_corr),
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")

    if median_correct <= 1.05:
        specificity = "The attention map is close to spatially uniform and does not strongly concentrate in GT."
    elif sign_test_p < 0.05 and median_delta > 0:
        specificity = (
            "Correct prompts produce a statistically detectable but small increase in lesion enrichment over "
            "shuffled prompts. This is weak prompt specificity, not precise lesion localization."
        )
    else:
        specificity = (
            "Correct prompts do not reliably outperform shuffled prompts; the map is dominated by generic "
            "image anatomy rather than prompt-specific localization."
        )
    if pointing == 0 or median_topk_precision < 0.01:
        precision = (
            "Spatial precision is poor: the attention peak does not enter GT and the highest-attention region "
            "has negligible overlap with the lesion."
        )
    else:
        precision = "The attention map shows measurable lesion-level spatial precision."
    category_lines = []
    for category in ("2c", "2d"):
        row = grouped[grouped["category"] == category]
        if row.empty:
            continue
        item = row.iloc[0]
        category_lines.append(
            f"- {category}: median correct-minus-shuffled enrichment "
            f"{item['median_correct_minus_shuffled']:+.3f}; correct wins in "
            f"{item['correct_better_fraction'] * 100:.1f}% of {int(item['n'])} findings."
        )
    lines = [
        f"# {attention_module} Spatial Attention Localization Diagnostic",
        "",
        f"- Findings: {len(metrics)} from {metrics['case_id'].nunique()} validation cases.",
        f"- Attention map scale: {attention_scale}.",
        f"- Residual gate rho: {rho:.4f} (maximum suppression when attention=0: {rho * 100:.1f}%).",
        f"- Median correct-prompt enrichment: {median_correct:.3f} (1.0 is spatially uniform).",
        f"- Median shuffled-prompt enrichment: {median_shuffled:.3f}.",
        f"- Median paired enrichment delta: {median_delta:+.3f}.",
        f"- Correct prompt beats shuffled prompt in {better_fraction * 100:.1f}% of findings.",
        f"- Exact one-sided paired sign-test p-value: {sign_test_p:.4g}.",
        f"- Pointing accuracy: {pointing * 100:.1f}%.",
        f"- Median GT-sized top-k precision: {median_topk_precision:.4f}.",
        f"- Median attention-peak distance to GT: {median_peak_distance:.1f} voxels.",
        f"- Median voxel AUROC / AUPRC: {median_auroc:.3f} / {median_auprc:.6f}.",
        f"- Median correct/shuffled map correlation: {median_corr:.3f}.",
        f"- Spearman localization-vs-Dice correlation: {dice_corr:.3f}.",
        "",
        "## Interpretation",
        "",
        specificity,
        "",
        precision,
        "",
        "## Category Highlights",
        "",
        *category_lines,
        "",
        "Categories whose best inference rule sets gamma=0 still have a raw map, but that map is not used to gate features.",
    ]
    (output_dir / "report.md").write_text("\n".join(lines) + "\n")


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    entries = load_entries(args.rex_json, ["val"])
    entry_map = {entry["name"]: entry for entry in entries}
    selected = select_findings(args, entries)
    selected.to_csv(args.output_dir / "selected_findings.csv", index=False)
    print(f"Selected {len(selected)} findings from {selected['file'].nunique()} case(s)")
    print(selected.groupby("category").size().to_string())
    if args.selection_only:
        return 0

    add_voxtell_to_path(args.voxtell_repo)
    from voxtell.inference.predictor import VoxTellPredictor

    device = torch.device(f"cuda:{args.gpu}" if args.device == "cuda" else args.device)
    predictor = VoxTellPredictor(str(args.model_dir), device=device)
    model = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    gate = getattr(model, "prompt_spatial_attention_gate", None)
    attention_module = "S1"
    attention_scale = str(getattr(model, "spatial_attention_level", "configured"))
    if gate is None:
        s3_enabled = bool(
            getattr(model, "enable_s3_voxel_text_matching_attention", False)
        )
        s3_scales = tuple(getattr(model, "s3_attention_scales", ()))
        if s3_enabled and s3_scales:
            # Historical S3 diagnostics assumed the original 1/2 gate. Newer
            # 1/4 and 1/1 experiments keep those gates in the keyed extra-gate
            # ModuleDict for checkpoint compatibility.
            attention_scale = "1/2" if "1/2" in s3_scales else s3_scales[0]
            if attention_scale == "1/2":
                gate = getattr(model, "s3_attention_gate", None)
            else:
                extra_gates = getattr(model, "s3_extra_attention_gates", None)
                gate_key = model._s2_scale_key(attention_scale)
                gate = (
                    extra_gates[gate_key]
                    if extra_gates is not None and gate_key in extra_gates
                    else None
                )
            if gate is None:
                raise RuntimeError(
                    f"S3 is enabled at {s3_scales}, but gate {attention_scale} is absent"
                )
            attention_module = "S3 voxel-text matching"
            print(
                "Detected S3 voxel-text matching attention; "
                f"diagnosing captured scale={attention_scale}"
            )
        else:
            s2_gates = getattr(model, "s2_attention_gates", None)
            if not s2_gates:
                raise RuntimeError("Selected checkpoint does not contain S1, S2, or S3 spatial attention")
            attention_module = "S2"
            configured_scales = tuple(getattr(model, "s2_attention_scales", ()))
            attention_scale = "1/2" if "1/2" in configured_scales else configured_scales[0]
            gate_key = model._s2_scale_key(attention_scale)
            gate = s2_gates[gate_key]
            print(
                f"Detected S2 attention with scales={configured_scales}; "
                f"diagnosing captured scale={attention_scale}"
            )
    else:
        print(f"Detected S1 attention; diagnosing scale={attention_scale}")
    rho = (
        float(gate.rho_fixed)
        if attention_module.startswith("S3")
        else float(torch.sigmoid(gate.beta.detach()).cpu())
    )
    with args.category_gamma_json.open() as f:
        category_gamma = {str(key): float(value) for key, value in json.load(f).items()}

    rows: list[dict] = []
    png_count = 0
    grouped = selected.groupby("file", sort=True)
    for case_idx, (case_name, case_rows) in enumerate(grouped, start=1):
        entry = entry_map[case_name]
        case_rows = case_rows.sort_values("finding_idx").reset_index(drop=True)
        image, image_properties = load_image(args.image_dir / case_name)
        data, bbox, _ = predictor.preprocess(image)
        spacing_zyx = tuple(float(value) for value in image_properties.get("spacing", (1.0, 1.0, 1.0)))
        all_prompts = sorted_prompts(entry)
        full_target = load_rex_masks_in_preprocessed_ras(
            args.mask_dir / case_name,
            image_properties,
            len(all_prompts),
            bbox,
        )
        if tuple(full_target.shape[1:]) != tuple(data.shape[1:]):
            raise RuntimeError(
                f"GT/image mismatch for {case_name}: {tuple(full_target.shape[1:])} "
                f"vs {tuple(data.shape[1:])}"
            )
        finding_indices = [int(value) for value in case_rows["finding_idx"]]
        targets = full_target[finding_indices].numpy().astype(bool)
        if any(not target.any() for target in targets):
            raise RuntimeError(f"Selected empty GT in {case_name}")

        finding_keys = sorted_finding_keys(entry)
        all_categories = [(entry.get("categories") or {}).get(key, "unknown") for key in finding_keys]
        correct_prompts = list(all_prompts)
        shuffled_prompts = list(all_prompts)
        shuffled_categories = list(all_categories)
        for _, source in case_rows.iterrows():
            finding_idx = int(source["finding_idx"])
            shuffled_prompts[finding_idx] = str(source["shuffled_prompt"])
            shuffled_categories[finding_idx] = str(source["shuffled_category"])
        correct_scales = [category_gamma.get(str(cat), 1.0) for cat in all_categories]
        shuffled_scales = [category_gamma.get(str(cat), 1.0) for cat in shuffled_categories]

        correct_embeddings = predictor.embed_text_prompts(correct_prompts)
        logits, attention = predictor.predict_sliding_window_return_logits(
            data,
            correct_embeddings,
            spatial_attention_rho_scale=torch.tensor(correct_scales),
            return_spatial_attention_maps=True,
        )
        shuffled_embeddings = predictor.embed_text_prompts(shuffled_prompts)
        _, shuffled_attention = predictor.predict_sliding_window_return_logits(
            data,
            shuffled_embeddings,
            spatial_attention_rho_scale=torch.tensor(shuffled_scales),
            return_spatial_attention_maps=True,
        )
        probabilities = torch.sigmoid(logits.float()).cpu().numpy()
        attention = attention.float().cpu().numpy()
        shuffled_attention = shuffled_attention.float().cpu().numpy()
        ct = data[0].cpu().numpy()
        for local_idx, source in case_rows.iterrows():
            target = targets[local_idx]
            finding_idx = int(source["finding_idx"])
            prediction = probabilities[finding_idx] > 0.5
            correct_attention = attention[finding_idx]
            shuffled_attention_for_finding = shuffled_attention[finding_idx]
            correct_metrics = attention_metrics(correct_attention, target, spacing_zyx)
            shuffled_metrics = attention_metrics(shuffled_attention_for_finding, target, spacing_zyx)
            row = {
                "case_id": case_name,
                "finding_idx": int(source["finding_idx"]),
                "category": str(source["category"]),
                "prompt": str(source["prompt"]),
                "shuffled_prompt": str(source["shuffled_prompt"]),
                "shuffled_category": str(source["shuffled_category"]),
                "shuffled_source": str(source["shuffled_source"]),
                "reference_full_volume_dice": float(source["global_dice"]),
                "segmentation_dice": dice_score(prediction, target),
                "gt_component_recall_ge_10pct": gt_component_recall(prediction, target),
                "attention_gamma_in_best_rule": float(correct_scales[finding_idx]),
                "attention_used_in_best_rule": bool(correct_scales[finding_idx] != 0),
                "attention_module": attention_module,
                "attention_scale": attention_scale,
                "spatial_attention_rho": rho,
                **correct_metrics,
            }
            for key, value in shuffled_metrics.items():
                row[f"shuffled_{key}"] = value
            row["attention_enrichment_delta_vs_shuffled"] = (
                float(row["attention_enrichment"]) - float(row["shuffled_attention_enrichment"])
            )
            row["attention_map_correlation_with_shuffled"] = sampled_correlation(
                correct_attention, shuffled_attention_for_finding
            )
            rows.append(row)
            if png_count < args.max_example_pngs:
                stem = case_name.replace(".nii.gz", "")
                save_example_png(
                    args.output_dir / "examples" / f"{stem}_finding{int(source['finding_idx'])}_{source['category']}.png",
                    ct,
                    target,
                    prediction,
                    correct_attention,
                    shuffled_attention_for_finding,
                    row,
                )
                png_count += 1
        print(f"[{case_idx}/{len(grouped)}] {case_name}: {len(case_rows)} finding(s)")
        del logits, attention, shuffled_attention, probabilities, correct_embeddings, shuffled_embeddings
        if device.type == "cuda":
            torch.cuda.empty_cache()

    metrics = pd.DataFrame(rows)
    metrics.to_csv(args.output_dir / "attention_localization_per_finding.csv", index=False)
    summarize(metrics, args.output_dir, rho, attention_module, attention_scale)
    make_summary_plots(metrics, args.output_dir)
    print((args.output_dir / "report.md").read_text())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
