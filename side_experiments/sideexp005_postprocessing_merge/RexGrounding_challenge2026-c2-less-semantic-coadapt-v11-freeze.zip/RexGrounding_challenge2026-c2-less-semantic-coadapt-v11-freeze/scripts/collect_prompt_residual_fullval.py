#!/usr/bin/env python3
"""Collect canonical full-validation metrics and residual diagnostics."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--dataset-json", type=Path, required=True)
    parser.add_argument("--bootstrap-samples", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--adapter-key", default="update_200")
    parser.add_argument("--stage", type=int, choices=(1, 2), default=1)
    return parser.parse_args()


def load_variant(root: Path, key: str) -> tuple[dict[str, Any], pd.DataFrame]:
    directory = root / key
    summary = json.loads((directory / "summary.json").read_text())
    frame = pd.read_csv(directory / "per_finding_metrics.csv")
    if len(frame) != 381 or int(summary["total_cases"]) != 200:
        raise ValueError(f"{key} is not the canonical 200-case/381-finding cohort")
    frame["key"] = (
        frame["file"].astype(str) + "::" + frame["finding_idx"].astype(int).astype(str)
    )
    frame = frame.set_index("key").sort_index()
    if not frame.index.is_unique:
        raise ValueError(f"Duplicate finding identities in {key}")
    return summary, frame


def bootstrap_finding(delta: np.ndarray, samples: int, seed: int) -> list[float]:
    generator = np.random.default_rng(seed)
    means = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 500):
        count = min(500, samples - start)
        indices = generator.integers(0, len(delta), size=(count, len(delta)))
        means[start : start + count] = delta[indices].mean(axis=1)
    return [float(value) for value in np.quantile(means, [0.025, 0.975])]


def bootstrap_case(
    frame: pd.DataFrame, samples: int, seed: int
) -> list[float]:
    case_values = (
        frame.groupby("file", sort=True)["dice_delta"].mean().to_numpy(np.float64)
    )
    generator = np.random.default_rng(seed)
    means = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 500):
        count = min(500, samples - start)
        indices = generator.integers(
            0, len(case_values), size=(count, len(case_values))
        )
        means[start : start + count] = case_values[indices].mean(axis=1)
    return [float(value) for value in np.quantile(means, [0.025, 0.975])]


def summarize_group(values: pd.DataFrame) -> dict[str, Any]:
    delta = values["dice_delta"].to_numpy(np.float64)
    return {
        "findings": len(values),
        "cases": int(values["file"].nunique()),
        "mean_dice_delta": float(delta.mean()),
        "median_dice_delta": float(np.median(delta)),
        "q25_dice_delta": float(np.quantile(delta, 0.25)),
        "q75_dice_delta": float(np.quantile(delta, 0.75)),
        "improved": int((delta > 0).sum()),
        "degraded": int((delta < 0).sum()),
        "new_hits": int(values["new_hit"].sum()),
        "lost_hits": int(values["lost_hit"].sum()),
        "baseline_dice": float(values["baseline_dice"].mean()),
        "adapter_dice": float(values["adapter_dice"].mean()),
    }


def grouped(
    frame: pd.DataFrame, grouper: Callable[[pd.Series], str]
) -> dict[str, dict[str, Any]]:
    labels = frame.apply(grouper, axis=1)
    return {
        str(label): summarize_group(frame.loc[labels == label])
        for label in sorted(labels.unique())
    }


def safe_correlation(left: pd.Series, right: pd.Series, method: str) -> float:
    value = left.corr(right, method=method)
    return float(value) if pd.notna(value) else float("nan")


def main() -> int:
    args = parse_args()
    baseline_summary, baseline = load_variant(args.root, "baseline")
    adapter_summary, adapter = load_variant(args.root, args.adapter_key)
    if not baseline.index.equals(adapter.index):
        raise ValueError("Baseline and adapter finding identities/order differ")
    residual = pd.read_csv(args.root / "residual_diagnostics.csv")
    residual["key"] = (
        residual["file"].astype(str)
        + "::"
        + residual["finding_idx"].astype(int).astype(str)
    )
    residual = residual.set_index("key").sort_index()
    if not baseline.index.equals(residual.index):
        raise ValueError("Residual diagnostics do not match evaluated findings")

    paired = pd.DataFrame(index=baseline.index)
    paired["file"] = baseline["file"]
    paired["finding_idx"] = baseline["finding_idx"].astype(int)
    for field in ("prompt", "category", "pixels"):
        paired[field] = baseline[field]
    paired["baseline_dice"] = baseline["global_dice"].astype(float)
    paired["adapter_dice"] = adapter["global_dice"].astype(float)
    paired["dice_delta"] = paired["adapter_dice"] - paired["baseline_dice"]
    paired["baseline_hit"] = baseline["global_hit"].astype(bool)
    paired["adapter_hit"] = adapter["global_hit"].astype(bool)
    paired["new_hit"] = paired["adapter_hit"] & ~paired["baseline_hit"]
    paired["lost_hit"] = ~paired["adapter_hit"] & paired["baseline_hit"]
    for prefix, source in (("baseline", baseline), ("adapter", adapter)):
        for field in (
            "pred_voxels",
            "gt_voxels",
            "pred_gt_volume_ratio",
            "fp_mm3",
            "fn_mm3",
        ):
            paired[f"{prefix}_{field}"] = source[field]
    for field in (
        "base_query_norm",
        "residual_norm",
        "residual_base_query_ratio",
        "query_residual_cosine",
    ):
        paired[field] = residual[field]
    paired = paired.reset_index(drop=True)
    paired.to_csv(args.root / "per_finding_paired.csv", index=False)

    delta = paired["dice_delta"].to_numpy(np.float64)
    overall = {
        "mean_paired_dice_delta": float(delta.mean()),
        "median_paired_dice_delta": float(np.median(delta)),
        "q25_paired_dice_delta": float(np.quantile(delta, 0.25)),
        "q75_paired_dice_delta": float(np.quantile(delta, 0.75)),
        "improved": int((delta > 0).sum()),
        "degraded": int((delta < 0).sum()),
        "unchanged": int((delta == 0).sum()),
        "delta_greater_than_0p01": int((delta > 0.01).sum()),
        "delta_below_minus_0p01": int((delta < -0.01).sum()),
        "new_hits": int(paired["new_hit"].sum()),
        "baseline_hits_lost": int(paired["lost_hit"].sum()),
        "mean_adapter_prediction_gt_volume_ratio": float(
            paired["adapter_pred_gt_volume_ratio"].mean()
        ),
        "median_adapter_prediction_gt_volume_ratio": float(
            paired["adapter_pred_gt_volume_ratio"].median()
        ),
        "mean_adapter_false_positive_mm3": float(paired["adapter_fp_mm3"].mean()),
        "mean_adapter_false_negative_mm3": float(paired["adapter_fn_mm3"].mean()),
        "total_adapter_false_positive_mm3": float(paired["adapter_fp_mm3"].sum()),
        "total_adapter_false_negative_mm3": float(paired["adapter_fn_mm3"].sum()),
    }
    bootstrap = {
        "samples": args.bootstrap_samples,
        "seed": args.seed,
        "finding_level_95_ci": bootstrap_finding(
            delta, args.bootstrap_samples, args.seed
        ),
        "case_clustered_95_ci": bootstrap_case(
            paired, args.bootstrap_samples, args.seed
        ),
        "case_clustered_method": (
            "Resample 200 cases with replacement after averaging finding deltas "
            "within case; existing repository method."
        ),
    }

    subgroups = {
        "focal_vs_diffuse": grouped(
            paired,
            lambda row: "focal_category_2"
            if str(row["category"]).startswith("2")
            else "diffuse_category_1",
        ),
        "tiny_vs_non_tiny": grouped(
            paired,
            lambda row: "tiny_lt_100"
            if int(row["pixels"]) < 100
            else "non_tiny_ge_100",
        ),
        "category": grouped(paired, lambda row: str(row["category"])),
        "baseline_hit_status": grouped(
            paired,
            lambda row: "baseline_hit" if bool(row["baseline_hit"]) else "baseline_miss",
        ),
        "gt_volume_bins": grouped(
            paired,
            lambda row: (
                "tiny_lt100"
                if int(row["pixels"]) < 100
                else "small_100_999"
                if int(row["pixels"]) < 1000
                else "medium_1k_9999"
                if int(row["pixels"]) < 10_000
                else "large_ge10k"
            ),
        ),
    }
    (args.root / "subgroups.json").write_text(json.dumps(subgroups, indent=2) + "\n")

    extremes = pd.concat(
        [
            paired.nlargest(10, "dice_delta").assign(extreme_group="largest_improvement"),
            paired.nsmallest(10, "dice_delta").assign(extreme_group="largest_degradation"),
        ],
        ignore_index=True,
    )
    extremes["hit_transition"] = np.select(
        [extremes["new_hit"], extremes["lost_hit"]],
        ["new_hit", "lost_hit"],
        default="unchanged_hit_status",
    )
    extreme_columns = [
        "extreme_group",
        "file",
        "finding_idx",
        "prompt",
        "category",
        "pixels",
        "baseline_dice",
        "adapter_dice",
        "dice_delta",
        "baseline_pred_voxels",
        "adapter_pred_voxels",
        "baseline_pred_gt_volume_ratio",
        "adapter_pred_gt_volume_ratio",
        "hit_transition",
        "residual_base_query_ratio",
    ]
    extremes[extreme_columns].to_csv(args.root / "extreme_findings.csv", index=False)

    ratio = paired["residual_base_query_ratio"]
    quartile_label = pd.qcut(
        ratio,
        q=4,
        labels=["Q1_low", "Q2", "Q3", "Q4_high"],
        duplicates="drop",
    )
    ratio_quartiles = {
        str(label): {
            **summarize_group(paired.loc[quartile_label == label]),
            "ratio_min": float(ratio.loc[quartile_label == label].min()),
            "ratio_max": float(ratio.loc[quartile_label == label].max()),
            "ratio_mean": float(ratio.loc[quartile_label == label].mean()),
            "degraded_fraction": float(
                (paired.loc[quartile_label == label, "dice_delta"] < 0).mean()
            ),
        }
        for label in quartile_label.cat.categories
    }
    thresholds = {}
    for threshold in (0.5, 1.0):
        high = paired.loc[ratio > threshold]
        low = paired.loc[ratio <= threshold]
        thresholds[str(threshold)] = {
            "above": summarize_group(high) if len(high) else {"findings": 0},
            "at_or_below": summarize_group(low) if len(low) else {"findings": 0},
            "fraction_of_total_delta_sum_from_above": (
                float(high["dice_delta"].sum() / paired["dice_delta"].sum())
                if paired["dice_delta"].sum() != 0
                else float("nan")
            ),
            "overall_delta_if_above_contribution_zeroed": float(
                low["dice_delta"].sum() / len(paired)
            ),
        }
    residual_analysis = {
        "pearson_ratio_vs_dice_delta": safe_correlation(
            ratio, paired["dice_delta"], "pearson"
        ),
        "spearman_ratio_vs_dice_delta": safe_correlation(
            ratio, paired["dice_delta"], "spearman"
        ),
        "ratio_summary": {
            "mean": float(ratio.mean()),
            "median": float(ratio.median()),
            "max": float(ratio.max()),
            "greater_than_0p5": int((ratio > 0.5).sum()),
            "greater_than_1p0": int((ratio > 1.0).sum()),
        },
        "quartiles": ratio_quartiles,
        "threshold_dependence": thresholds,
    }
    (args.root / "residual_analysis.json").write_text(
        json.dumps(residual_analysis, indent=2) + "\n"
    )

    dice_delta = float(
        adapter_summary["mean_global_dice_per_finding"]
        - baseline_summary["mean_global_dice_per_finding"]
    )
    if (
        dice_delta >= 0.003
        and float(adapter_summary["hit_rate"]) >= float(baseline_summary["hit_rate"])
        and overall["new_hits"] > overall["baseline_hits_lost"]
    ):
        verdict = "VALIDATED"
    elif -0.003 <= dice_delta <= 0.003:
        verdict = "WEAK/MIXED"
    else:
        verdict = "NOT VALIDATED"

    result = {
        "stage": args.stage,
        "cohort": {"cases": 200, "findings": 381},
        "baseline": baseline_summary,
        "adapter": adapter_summary,
        "dice_per_finding_delta": dice_delta,
        "paired": overall,
        "bootstrap": bootstrap,
        "subgroups": subgroups,
        "residual_analysis": residual_analysis,
        "verdict": verdict,
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
    }
    (args.root / "comparison.json").write_text(json.dumps(result, indent=2) + "\n")

    stage_title = (
        "Stage 1 — normal VoxTell prompt-adapter full validation"
        if args.stage == 1
        else "Stage 2 — frozen S3 prompt-adapter full validation"
    )
    baseline_label = (
        "Normal VoxTell baseline" if args.stage == 1 else "Selected S3 baseline"
    )
    lines = [
        f"# {stage_title}",
        "",
        f"Verdict: **{verdict}**",
        "",
        "## Overall",
        "",
        "| Model | Dice/finding | Delta | Dice/case | Hit rate | Hits |",
        "|---|---:|---:|---:|---:|---:|",
        f"| {baseline_label} | {baseline_summary['mean_global_dice_per_finding']:.6f} | — | "
        f"{baseline_summary['mean_global_dice_per_case']:.6f} | "
        f"{baseline_summary['hit_rate']:.6f} | {baseline_summary['total_hits']} |",
        f"| Prompt adapter {args.adapter_key.replace('_', ' ')} | "
        f"{adapter_summary['mean_global_dice_per_finding']:.6f} | "
        f"{dice_delta:+.6f} | {adapter_summary['mean_global_dice_per_case']:.6f} | "
        f"{adapter_summary['hit_rate']:.6f} | {adapter_summary['total_hits']} |",
        "",
        "## Paired finding metrics",
        "",
        f"- Mean / median delta: `{overall['mean_paired_dice_delta']:+.6f}` / "
        f"`{overall['median_paired_dice_delta']:+.6f}`.",
        f"- Q25 / Q75: `{overall['q25_paired_dice_delta']:+.6f}` / "
        f"`{overall['q75_paired_dice_delta']:+.6f}`.",
        f"- Improved / degraded: `{overall['improved']}` / `{overall['degraded']}`.",
        f"- Delta > +0.01 / < -0.01: `{overall['delta_greater_than_0p01']}` / "
        f"`{overall['delta_below_minus_0p01']}`.",
        f"- New hits / lost baseline hits: `{overall['new_hits']}` / "
        f"`{overall['baseline_hits_lost']}`.",
        f"- Adapter mean/median prediction:GT volume ratio: "
        f"`{overall['mean_adapter_prediction_gt_volume_ratio']:.6f}` / "
        f"`{overall['median_adapter_prediction_gt_volume_ratio']:.6f}`.",
        f"- Adapter mean FP/FN volume: "
        f"`{overall['mean_adapter_false_positive_mm3']:.3f}` / "
        f"`{overall['mean_adapter_false_negative_mm3']:.3f}` mm3.",
        "",
        "## Bootstrap",
        "",
        f"- Finding-level 95% CI: `[{bootstrap['finding_level_95_ci'][0]:+.6f}, "
        f"{bootstrap['finding_level_95_ci'][1]:+.6f}]`.",
        f"- Case-clustered 95% CI: `[{bootstrap['case_clustered_95_ci'][0]:+.6f}, "
        f"{bootstrap['case_clustered_95_ci'][1]:+.6f}]`.",
        f"- `{args.bootstrap_samples}` resamples, seed `{args.seed}`.",
        "",
        "## Subgroups",
        "",
    ]
    for grouping, values in subgroups.items():
        lines.extend(
            [
                f"### {grouping}",
                "",
                "| Group | Findings | Cases | Mean delta | Median delta | Improved | Degraded | New/lost hits |",
                "|---|---:|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for name, item in values.items():
            lines.append(
                f"| {name} | {item['findings']} | {item['cases']} | "
                f"{item['mean_dice_delta']:+.6f} | {item['median_dice_delta']:+.6f} | "
                f"{item['improved']} | {item['degraded']} | "
                f"{item['new_hits']}/{item['lost_hits']} |"
            )
        lines.append("")
    lines.extend(
        [
            "## Residual diagnostic",
            "",
            f"- Ratio mean/median/max: `{ratio.mean():.6f}` / `{ratio.median():.6f}` / "
            f"`{ratio.max():.6f}`.",
            f"- Pearson / Spearman correlation with Dice delta: "
            f"`{residual_analysis['pearson_ratio_vs_dice_delta']:+.6f}` / "
            f"`{residual_analysis['spearman_ratio_vs_dice_delta']:+.6f}`.",
            f"- Ratios >0.5 / >1.0: `{int((ratio > 0.5).sum())}` / "
            f"`{int((ratio > 1.0).sum())}` findings.",
            "",
            "| Ratio quartile | N | Ratio range | Mean delta | Degraded fraction |",
            "|---|---:|---:|---:|---:|",
        ]
    )
    for name, item in ratio_quartiles.items():
        lines.append(
            f"| {name} | {item['findings']} | {item['ratio_min']:.4f}–"
            f"{item['ratio_max']:.4f} | {item['mean_dice_delta']:+.6f} | "
            f"{item['degraded_fraction']:.6f} |"
        )
    lines.extend(
        [
            "",
            "Full top-10 improvement/degradation details are in `extreme_findings.csv`; "
            "representative overlays are in `visualizations/`.",
            "",
            "## Decision",
            "",
            f"`{verdict}`",
            "",
        ]
    )
    (args.root / "summary.md").write_text("\n".join(lines))
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
