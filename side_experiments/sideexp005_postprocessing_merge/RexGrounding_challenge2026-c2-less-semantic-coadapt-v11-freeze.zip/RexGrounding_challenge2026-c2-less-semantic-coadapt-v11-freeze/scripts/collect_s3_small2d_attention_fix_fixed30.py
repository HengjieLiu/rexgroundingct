#!/usr/bin/env python3
"""Collect the matched fixed30 screen and enforce the predeclared GO/NO-GO rule."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EPS = 1e-12


def load(run: Path, update: int) -> pd.DataFrame:
    directory = run / "fixed30" / f"update_{update}"
    segmentation = pd.read_csv(directory / "per_finding_metrics.csv")
    attention = pd.read_csv(directory / "attention/attention_localization_per_finding.csv").rename(columns={"case_id": "file"})
    keep = [column for column in attention if column not in segmentation or column in {"file", "finding_idx"}]
    return segmentation.merge(attention[keep], on=["file", "finding_idx"], validate="one_to_one")


def masks(frame: pd.DataFrame) -> dict[str, pd.Series]:
    category, pixels = frame.category.astype(str), frame.pixels.astype(int)
    return {
        "2d-small": (category == "2d") & pixels.between(100, 999),
        "other-2d": (category == "2d") & ~pixels.between(100, 999),
        "2b": category == "2b", "2c": category == "2c",
        "2b+2c": category.isin(["2b", "2c"]),
        "tiny-non-2b2c": (pixels < 1000) & ~category.isin(["2b", "2c"]),
        "overall": pd.Series(True, index=frame.index),
    }


def summary(frame: pd.DataFrame, arm: str, update: int) -> list[dict]:
    rows = []
    for group, mask in masks(frame).items():
        values = frame.loc[mask]
        rows.append({
            "arm": arm, "update": update, "group": group, "n": len(values),
            "dice": values.global_dice.mean(), "hits": int(values.global_hit.sum()),
            "precision": values.voxel_precision.mean(), "recall": values.voxel_recall.mean(),
            "fp_voxels": values.fp_voxels.sum(), "fn_voxels": values.fn_voxels.sum(),
            "predicted_voxels": values.pred_voxels.sum(),
            "gt_component_recall_ge_10pct": values.gt_component_recall_ge_10pct.mean(),
            "attention_peak_in_gt": values.attention_pointing_hit.mean(),
            "attention_peak_in_dilated_5mm": values.attention_peak_in_dilated_5mm.mean(),
            "attention_gt_sized_topk_precision": values.attention_gt_sized_topk_precision.mean(),
            "attention_peak_distance_mm": values.attention_peak_distance_mm.mean(),
            "attention_mass_in_dilated_5mm": values.attention_softmax_mass_in_dilated_5mm.mean(),
            "attention_inside_minus_outside": values.attention_rank_inside_minus_outside.mean(),
        })
    return rows


def paired(control: pd.DataFrame, repair: pd.DataFrame, update: int) -> pd.DataFrame:
    columns = ["file", "finding_idx", "category", "pixels", "prompt", "global_dice", "global_hit",
               "attention_pointing_hit", "attention_gt_sized_topk_precision"]
    result = control[columns].merge(repair[columns], on=["file", "finding_idx"], suffixes=("_control", "_repair"), validate="one_to_one")
    result.insert(0, "update", update)
    result["dice_delta"] = result.global_dice_repair - result.global_dice_control
    result["hit_delta"] = result.global_hit_repair.astype(int) - result.global_hit_control.astype(int)
    result["paired_outcome"] = result.dice_delta.map(lambda value: "improved" if value > EPS else ("degraded" if value < -EPS else "tied"))
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control", type=Path, required=True); parser.add_argument("--repair", type=Path, required=True)
    parser.add_argument("--comparison", type=Path, required=True); parser.add_argument("--submit-full-on-go", action="store_true")
    args = parser.parse_args(); args.comparison.mkdir(parents=True, exist_ok=True)
    frames, summaries, pairs = {}, [], []
    for update in (0, 200, 400):
        for arm, run in (("control", args.control), ("repair", args.repair)):
            frames[(arm, update)] = load(run, update)
            summaries.extend(summary(frames[(arm, update)], arm, update))
        if update:
            pairs.append(paired(frames[("control", update)], frames[("repair", update)], update))
    summary_frame = pd.DataFrame(summaries); summary_frame.to_csv(args.comparison / "fixed30_group_summary.csv", index=False)
    paired_frame = pd.concat(pairs, ignore_index=True); paired_frame.to_csv(args.comparison / "fixed30_paired_findings.csv", index=False)
    candidates = []
    for update in (200, 400):
        table = summary_frame[summary_frame.update.eq(update)].set_index(["arm", "group"])
        delta = lambda group, metric: float(table.loc[("repair", group), metric] - table.loc[("control", group), metric])
        target_pair = paired_frame[(paired_frame.update == update) & (paired_frame.category_control.astype(str) == "2d") & paired_frame.pixels_control.between(100, 999)]
        criteria = {
            "target_segmentation": delta("2d-small", "dice") >= .003 or delta("2d-small", "hits") >= 1,
            "attention_localization": delta("2d-small", "attention_peak_in_gt") >= .10 or delta("2d-small", "attention_gt_sized_topk_precision") >= .05,
            "preserve_2b2c": delta("2b+2c", "dice") >= -.002,
            "preserve_tiny_non_2b2c": delta("tiny-non-2b2c", "dice") >= -.002,
            "preserve_overall": delta("overall", "dice") >= -.001,
            "not_one_finding": int((target_pair.dice_delta > EPS).sum()) >= 2,
        }
        candidates.append({
            "update": update, "target_dice_delta": delta("2d-small", "dice"), "target_hit_delta": int(delta("2d-small", "hits")),
            "target_peak_in_gt_delta": delta("2d-small", "attention_peak_in_gt"),
            "target_topk_precision_delta": delta("2d-small", "attention_gt_sized_topk_precision"),
            "delta_2b2c_dice": delta("2b+2c", "dice"), "delta_tiny_non_2b2c_dice": delta("tiny-non-2b2c", "dice"),
            "delta_overall_dice": delta("overall", "dice"), "target_findings_improved": int((target_pair.dice_delta > EPS).sum()),
            "new_hits": int((target_pair.hit_delta == 1).sum()), "lost_hits": int((target_pair.hit_delta == -1).sum()),
            "criteria": criteria, "passes_go": all(criteria.values()),
        })
    # Selection is independent of GO: max target Dice delta, then target hits,
    # then peak-in-GT, then earlier update.
    selected = sorted(candidates, key=lambda row: (-row["target_dice_delta"], -row["target_hit_delta"], -row["target_peak_in_gt_delta"], row["update"]))[0]
    decision = {"record_name": "small 2d attention fix", "candidates": candidates, "selected_update": selected["update"],
                "decision": "GO" if selected["passes_go"] else "NO-GO", "full_job_ids": {}, "full_collector_job_id": None}
    if selected["passes_go"] and args.submit_full_on_go:
        for arm in ("control", "repair"):
            output = subprocess.check_output([
                "sbatch", f"--job-name=s2d_{arm[:3]}_full381",
                f"--export=ALL,ARM={arm},UPDATE={selected['update']}",
                str(ROOT / "scripts/evaluate_s3_small2d_attention_fix_full381_4h200.sbatch"),
            ], cwd=ROOT, text=True).strip()
            decision["full_job_ids"][arm] = int(output.rsplit(maxsplit=1)[-1])
        dependency = ":".join(str(value) for value in decision["full_job_ids"].values())
        output = subprocess.check_output([
            "sbatch", f"--dependency=afterok:{dependency}", "--job-name=s2d_fix_full381_collect",
            f"--export=ALL,UPDATE={selected['update']}",
            str(ROOT / "scripts/collect_s3_small2d_attention_fix_full381.sbatch"),
        ], cwd=ROOT, text=True).strip()
        decision["full_collector_job_id"] = int(output.rsplit(maxsplit=1)[-1])
    (args.comparison / "fixed30_go_no_go.json").write_text(json.dumps(decision, indent=2) + "\n")
    print(json.dumps(decision, indent=2))
    return 0


if __name__ == "__main__": raise SystemExit(main())
