#!/usr/bin/env python3
"""Gate diagnosis before any Phase-0B token Image->Text training.

This script is intentionally inference-only.  It compares the completed
Phase-0 B0 and A2 update-0 checkpoints on a deterministic fixed30 diagnostic
subset, then runs a zero-branch and alpha sweep through the exact A2 code path.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
import types
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "VoxTell") not in sys.path:
    sys.path.insert(0, str(ROOT / "VoxTell"))

from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402
from scripts.diagnose_token_image_text_phase0 import (  # noqa: E402
    KEYWORDS,
    key,
    load_image,
    load_maps,
    load_reference_mask_for_window_diagnostic,
    pad_and_crop,
)
from scripts.run_controlled_fixed30_validation import (  # noqa: E402
    DEFAULT_CACHE,
    build_manifest,
)


PHASE0 = ROOT / "outputs/token_image_text_attention_phase0"
DEFAULT_OUT = ROOT / "outputs/token_image_text_attention_phase0b/diagnosis"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase0-dir", type=Path, default=PHASE0)
    parser.add_argument("--b0-checkpoint", type=Path, default=None)
    parser.add_argument("--a2-checkpoint", type=Path, default=None)
    parser.add_argument("--a2-update500-checkpoint", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--pooled-cache", type=Path, default=DEFAULT_CACHE)
    parser.add_argument(
        "--token-cache",
        type=Path,
        default=PHASE0 / "cache/qwen_contextual_content_tokens_train_val.pt",
    )
    parser.add_argument(
        "--selected-findings",
        type=Path,
        default=ROOT
        / "outputs/prompt_standardization_rule_only_v1"
        / "stratified30_six_variant_ablation_v1"
        / "prepared_inputs/selected_findings.csv",
    )
    parser.add_argument(
        "--dataset-json",
        type=Path,
        default=ROOT / "data/MICCAI_challenge_dataset.json",
    )
    parser.add_argument("--max-findings", type=int, default=8)
    parser.add_argument(
        "--alphas",
        type=float,
        nargs="+",
        default=[0.0, 0.01, 0.03, 0.1, 0.3, 1.0],
    )
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--amp-dtype", choices=["float16", "bfloat16", "none"], default="float16")
    return parser.parse_args()


def tensor_stats(tensor: torch.Tensor) -> dict[str, float]:
    value = tensor.detach().float()
    return {
        "mean": float(value.mean().item()),
        "std": float(value.std().item()),
        "rms": float(value.square().mean().sqrt().item()),
        "l2": float(value.norm().item()),
        "min": float(value.amin().item()),
        "max": float(value.amax().item()),
        "mean_abs": float(value.abs().mean().item()),
    }


def cosine_flat(left: torch.Tensor, right: torch.Tensor) -> float:
    lhs = left.detach().float().reshape(-1)
    rhs = right.detach().float().reshape(-1)
    return float(F.cosine_similarity(lhs, rhs, dim=0).item())


def spatial_token_cosine(left: torch.Tensor, right: torch.Tensor) -> float:
    lhs = left.detach().float()
    rhs = right.detach().float()
    if lhs.ndim != 3:
        return float("nan")
    values = F.cosine_similarity(lhs, rhs, dim=-1)
    return float(values.mean().item())


def dice_from_logits(logits: torch.Tensor, target: torch.Tensor) -> tuple[float, int, int]:
    probs = torch.sigmoid(logits.detach().float()).cpu()
    pred = probs > 0.5
    truth = target.cpu().bool()
    intersection = int((pred & truth).sum().item())
    pred_voxels = int(pred.sum().item())
    truth_voxels = int(truth.sum().item())
    denominator = pred_voxels + truth_voxels
    dice = (2.0 * intersection / denominator) if denominator else 1.0
    return float(dice), pred_voxels, truth_voxels


def attention_stats(weights: torch.Tensor, valid_mask: torch.Tensor) -> dict[str, float]:
    attn = weights.detach().float()
    valid = valid_mask.detach().bool().cpu()
    n_valid = int(valid.sum().item())
    clamped = attn.clamp_min(1e-12)
    entropy = -(clamped * clamped.log()).sum(dim=-1)
    max_weight = attn.amax(dim=-1)
    masked_mass = float(attn[..., ~valid].sum().item()) if (~valid).any() else 0.0
    return {
        "valid_tokens": n_valid,
        "entropy_mean": float(entropy.mean().item()),
        "entropy_norm": float((entropy / max(math.log(max(n_valid, 2)), 1e-12)).mean().item()),
        "max_attention_mean": float(max_weight.mean().item()),
        "max_attention_max": float(max_weight.amax().item()),
        "effective_tokens_mean": float(torch.exp(entropy).mean().item()),
        "padding_special_attention_mass": masked_mass,
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    keys: list[str] = []
    for row in rows:
        for key_name in row:
            if key_name not in keys:
                keys.append(key_name)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def atomic_json(path: Path, payload: object) -> None:
    temporary = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def selected_records(manifest: dict[str, Any], maximum: int) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for entry in manifest["val"]:
        for finding_id, prompt in sorted(entry["findings"].items(), key=lambda item: int(item[0])):
            text = str(prompt).lower()
            hits = [term for term in KEYWORDS if term in text]
            candidates.append(
                {
                    "split": "val",
                    "case": entry["name"],
                    "finding_idx": int(finding_id),
                    "prompt": prompt,
                    "hits": hits,
                }
            )
    with_hits = [row for row in candidates if row["hits"]]
    pool = with_hits if len(with_hits) >= maximum else candidates
    chosen: list[dict[str, Any]] = []
    covered: set[str] = set()
    while pool and len(chosen) < maximum:
        pool.sort(
            key=lambda row: (len(set(row["hits"]) - covered), len(row["hits"]), row["case"], row["finding_idx"]),
            reverse=True,
        )
        current = pool.pop(0)
        chosen.append(current)
        covered.update(current["hits"])
    return sorted(chosen, key=lambda row: (row["case"], row["finding_idx"]))


def replace_symlink(link: Path, target: Path) -> None:
    link.parent.mkdir(parents=True, exist_ok=True)
    tmp = link.with_name(link.name + f".tmp.{os.getpid()}")
    tmp.unlink(missing_ok=True)
    tmp.symlink_to(os.path.relpath(target, link.parent))
    tmp.replace(link)


def make_predictor(output_dir: Path, name: str, checkpoint: Path, device: torch.device) -> VoxTellPredictor:
    model_dir = output_dir / "models" / name
    replace_symlink(model_dir / "plans.json", ROOT / "VoxTell/voxtell_v1.1/plans.json")
    replace_symlink(model_dir / "fold_0/checkpoint_final.pth", checkpoint.resolve())
    return VoxTellPredictor(str(model_dir), device=device, load_text_backbone=False)


def install_encoder_capture(model: torch.nn.Module, store: dict[str, torch.Tensor]) -> Any:
    def hook(_module: torch.nn.Module, _inputs: tuple[torch.Tensor, ...], output: Any) -> None:
        selected = output[model.selected_decoder_layer]
        store["selected_feature"] = selected.detach()
        store["image_tokens"] = selected.detach().permute(0, 2, 3, 4, 1).reshape(selected.shape[0], -1, selected.shape[1])

    return model.encoder.register_forward_hook(hook)


def install_alpha_wrapper(model: torch.nn.Module, alpha: float, store: dict[str, torch.Tensor]) -> None:
    block = model.token_image_text_block
    if block is None:
        raise RuntimeError("A2 model has no token_image_text_block")

    def wrapped_forward(self: torch.nn.Module, image_tokens: torch.Tensor, text_tokens: torch.Tensor, valid_token_mask: torch.Tensor) -> torch.Tensor:
        if image_tokens.ndim != 3 or text_tokens.ndim != 3:
            raise ValueError("image_tokens and text_tokens must both be rank three")
        if valid_token_mask.shape != text_tokens.shape[:2]:
            raise ValueError("valid_token_mask must match text token axes")
        batch, n_image, _ = image_tokens.shape
        n_text = text_tokens.shape[1]
        image_norm = self.image_norm(image_tokens)
        text_norm = self.text_norm(text_tokens)
        query_linear = self.q_proj(image_norm)
        key_linear = self.k_proj(text_norm)
        value_linear = self.v_proj(text_norm)
        query = query_linear.view(batch, n_image, self.num_heads, self.head_dim).transpose(1, 2)
        key = key_linear.view(batch, n_text, self.num_heads, self.head_dim).transpose(1, 2)
        value = value_linear.view(batch, n_text, self.num_heads, self.head_dim).transpose(1, 2)
        invalid = ~valid_token_mask.to(device=query.device, dtype=torch.bool)
        attention_mask = torch.zeros(
            (batch, 1, 1, n_text), device=query.device, dtype=query.dtype
        ).masked_fill(invalid[:, None, None], torch.finfo(query.dtype).min)
        logits = torch.matmul(query, key.transpose(-2, -1)) * self.scale
        weights = torch.softmax(logits + attention_mask, dim=-1)
        attended = torch.matmul(weights, value)
        attended_flat = attended.transpose(1, 2).reshape(batch, n_image, self.attention_dim)
        attention_residual = self.out_proj(attended_flat)
        after_attention = image_tokens + attention_residual
        ffn_residual = self.ffn(self.ffn_norm(after_attention))
        full_delta = attention_residual + ffn_residual
        output = image_tokens + float(alpha) * full_delta
        self.last_attention = weights.detach()
        self.forward_count += 1
        store.clear()
        store.update(
            {
                "image_tokens": image_tokens.detach(),
                "image_norm": image_norm.detach(),
                "text_norm": text_norm.detach(),
                "q_projection": query_linear.detach(),
                "k_projection": key_linear.detach(),
                "v_projection": value_linear.detach(),
                "attention_logits": logits.detach(),
                "attention_weights": weights.detach(),
                "attention_weighted_sum": attended_flat.detach(),
                "attention_residual": attention_residual.detach(),
                "after_attention": after_attention.detach(),
                "ffn_residual": ffn_residual.detach(),
                "delta_full": full_delta.detach(),
                "output_tokens": output.detach(),
                "valid_token_mask": valid_token_mask.detach(),
            }
        )
        return output

    block.capture_attention = True
    block.forward = types.MethodType(wrapped_forward, block)


def logits_from_output(output: torch.Tensor | list[torch.Tensor]) -> torch.Tensor:
    logits = output[0] if isinstance(output, list) else output
    if logits.ndim == 5:
        return logits[0, 0]
    if logits.ndim == 4:
        return logits[0]
    raise ValueError(f"Unexpected model output shape: {tuple(logits.shape)}")


def run_model(
    model: torch.nn.Module,
    patch: torch.Tensor,
    pooled: torch.Tensor,
    token_features: torch.Tensor | None,
    token_mask: torch.Tensor | None,
    amp_dtype: torch.dtype | None,
) -> torch.Tensor:
    model_dtype = next(model.parameters()).dtype
    patch = patch.to(dtype=model_dtype)
    pooled = pooled.to(dtype=model_dtype)
    if token_features is not None:
        token_features = token_features.to(dtype=model_dtype)
    with torch.inference_mode():
        context = (
            torch.autocast("cuda", dtype=amp_dtype)
            if amp_dtype is not None and patch.device.type == "cuda"
            else torch.autocast("cpu", enabled=False)
        )
        with context:
            output = model(
                patch,
                pooled,
                token_features=token_features,
                token_valid_mask=token_mask,
            )
    return logits_from_output(output).detach().float().cpu()


def parameter_audit(model: torch.nn.Module) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    block = model.token_image_text_block
    for name, parameter in block.named_parameters():
        value = parameter.detach().float().cpu()
        rows.append(
            {
                "parameter": name,
                "shape": list(parameter.shape),
                "mean": float(value.mean().item()),
                "std": float(value.std().item()) if value.numel() > 1 else 0.0,
                "rms": float(value.square().mean().sqrt().item()),
                "min": float(value.amin().item()),
                "max": float(value.amax().item()),
                "zero_fraction": float((value == 0).float().mean().item()),
            }
        )
    return rows


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.experiment_dir = args.output_dir
    device = torch.device(args.device)
    amp_dtype = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "none": None,
    }[args.amp_dtype]
    manifest_path, _cases, _selection_sha = build_manifest(args)
    manifest = json.loads(manifest_path.read_text())
    records = selected_records(manifest, args.max_findings)
    token_map, pooled_map = load_maps(args.token_cache, args.pooled_cache)

    b0_ckpt = args.b0_checkpoint or (
        args.phase0_dir / "B0_original/checkpoints/checkpoint_initial.pth"
    )
    a2_ckpt = args.a2_checkpoint or (
        args.phase0_dir / "A2_add/checkpoints/checkpoint_initial.pth"
    )
    a2_500_ckpt = args.a2_update500_checkpoint or (
        args.phase0_dir / "A2_add/checkpoints/checkpoint_update_500.pth"
    )
    for checkpoint in (b0_ckpt, a2_ckpt, a2_500_ckpt):
        if not checkpoint.is_file():
            raise FileNotFoundError(checkpoint)

    b0_predictor = make_predictor(args.output_dir, "B0_update0", b0_ckpt, device)
    a2_predictor = make_predictor(args.output_dir, "A2_update0", a2_ckpt, device)
    a2_500_predictor = make_predictor(args.output_dir, "A2_update500", a2_500_ckpt, device)
    b0 = b0_predictor.network.eval().to(device)
    a2 = a2_predictor.network.eval().to(device)
    a2_500 = a2_500_predictor.network.eval().to(device)
    if amp_dtype is None:
        b0 = b0.float()
        a2 = a2.float()
        a2_500 = a2_500.float()

    init_rows = parameter_audit(a2)
    write_csv(args.output_dir / "attention_init_parameters.csv", init_rows)

    b0_capture: dict[str, torch.Tensor] = {}
    a2_encoder_capture: dict[str, torch.Tensor] = {}
    b0_hook = install_encoder_capture(b0, b0_capture)
    a2_hook = install_encoder_capture(a2, a2_encoder_capture)

    sample_rows: list[dict[str, Any]] = []
    alpha_rows: list[dict[str, Any]] = []
    feature_rows: list[dict[str, Any]] = []
    attention_rows: list[dict[str, Any]] = []
    diff_rows: list[dict[str, Any]] = []

    for record in records:
        cache_key = key(record)
        token = token_map[cache_key]
        pooled_value = pooled_map[cache_key]
        image, properties = load_image(ROOT / "data/ct_rate_volumes_fixed" / record["case"])
        data, bbox, original_shape = b0_predictor.preprocess(image)
        target = load_reference_mask_for_window_diagnostic(
            ROOT / "data/segmentations" / record["case"],
            1,
            tuple(original_shape),
            bbox,
            image_properties=properties,
            finding_ids=[record["finding_idx"]],
        )[0]
        patch, target_patch, _starts, _padding = pad_and_crop(data, target)
        patch_gpu = patch[None].to(device)
        target_patch = target_patch.cpu()
        pooled = pooled_value[None, None].to(device)
        contextual = token["feature"][None, None].to(device)
        valid = torch.ones(contextual.shape[:3], device=device, dtype=torch.bool)

        b0_capture.clear()
        b0_logits = run_model(b0, patch_gpu, pooled, None, None, amp_dtype)
        b0_dice, b0_voxels, truth_voxels = dice_from_logits(b0_logits, target_patch)

        per_alpha_logits: dict[float, torch.Tensor] = {}
        for alpha in args.alphas:
            token_store: dict[str, torch.Tensor] = {}
            install_alpha_wrapper(a2, alpha, token_store)
            a2_encoder_capture.clear()
            logits = run_model(a2, patch_gpu, pooled, contextual, valid, amp_dtype)
            per_alpha_logits[float(alpha)] = logits
            dice, pred_voxels, _ = dice_from_logits(logits, target_patch)
            alpha_rows.append(
                {
                    "case": record["case"],
                    "finding_idx": record["finding_idx"],
                    "prompt": record["prompt"],
                    "alpha": float(alpha),
                    "dice": dice,
                    "hit": int(dice > 0.0),
                    "pred_voxels": pred_voxels,
                    "truth_voxels": truth_voxels,
                    "delta_dice_vs_b0": dice - b0_dice,
                    "max_abs_logit_diff_vs_b0": float((logits - b0_logits).abs().amax().item()),
                    "mean_abs_logit_diff_vs_b0": float((logits - b0_logits).abs().mean().item()),
                }
            )
            if math.isclose(float(alpha), 1.0):
                z = token_store["image_tokens"]
                delta = token_store["delta_full"]
                z_after = token_store["output_tokens"]
                for label, tensor in (
                    ("Z", z),
                    ("DeltaZ_full", delta),
                    ("attention_residual", token_store["attention_residual"]),
                    ("ffn_residual", token_store["ffn_residual"]),
                    ("Z_after_new_branch", z_after),
                    ("Q_projection", token_store["q_projection"]),
                    ("K_projection", token_store["k_projection"]),
                    ("V_projection", token_store["v_projection"]),
                    ("attention_weighted_sum", token_store["attention_weighted_sum"]),
                ):
                    row = {
                        "case": record["case"],
                        "finding_idx": record["finding_idx"],
                        "prompt": record["prompt"],
                        "tensor": label,
                        "shape": list(tensor.shape),
                    }
                    row.update(tensor_stats(tensor))
                    feature_rows.append(row)
                z_stats = tensor_stats(z)
                delta_stats = tensor_stats(delta)
                feature_rows.append(
                    {
                        "case": record["case"],
                        "finding_idx": record["finding_idx"],
                        "prompt": record["prompt"],
                        "tensor": "relative_perturbation",
                        "shape": [],
                        "l2_ratio_delta_over_z": delta_stats["l2"] / max(z_stats["l2"], 1e-12),
                        "rms_ratio_delta_over_z": delta_stats["rms"] / max(z_stats["rms"], 1e-12),
                        "mean_abs_ratio_delta_over_z": delta_stats["mean_abs"] / max(z_stats["mean_abs"], 1e-12),
                        "cos_z_z_after": cosine_flat(z, z_after),
                        "spatial_token_cos_z_z_after": spatial_token_cosine(z, z_after),
                    }
                )
                attn = attention_stats(token_store["attention_weights"].cpu(), token_store["valid_token_mask"].cpu()[0])
                attention_rows.append(
                    {
                        "case": record["case"],
                        "finding_idx": record["finding_idx"],
                        "prompt": record["prompt"],
                        **attn,
                    }
                )
                b0_tokens = b0_capture["image_tokens"].cpu()
                a2_input = z_after.cpu()
                diff = a2_input - b0_tokens
                diff_rows.append(
                    {
                        "case": record["case"],
                        "finding_idx": record["finding_idx"],
                        "prompt": record["prompt"],
                        "b0_vs_a2_input_l2_ratio": float(diff.norm().item() / max(b0_tokens.float().norm().item(), 1e-12)),
                        "b0_vs_a2_input_cosine": cosine_flat(b0_tokens, a2_input),
                        "b0_vs_a2_input_mean_abs_diff": float(diff.float().abs().mean().item()),
                        "b0_z_mean": tensor_stats(b0_tokens)["mean"],
                        "a2_z_after_mean": tensor_stats(a2_input)["mean"],
                        "b0_z_std": tensor_stats(b0_tokens)["std"],
                        "a2_z_after_std": tensor_stats(a2_input)["std"],
                    }
                )

        a2_logits = per_alpha_logits.get(1.0)
        zero_logits = per_alpha_logits.get(0.0)
        if a2_logits is None or zero_logits is None:
            raise RuntimeError("--alphas must include 0.0 and 1.0")
        a2_dice, a2_voxels, _ = dice_from_logits(a2_logits, target_patch)
        zero_dice, zero_voxels, _ = dice_from_logits(zero_logits, target_patch)
        sample_rows.append(
            {
                "case": record["case"],
                "finding_idx": record["finding_idx"],
                "prompt": record["prompt"],
                "b0_dice": b0_dice,
                "b0_pred_voxels": b0_voxels,
                "a2_alpha1_dice": a2_dice,
                "a2_alpha1_pred_voxels": a2_voxels,
                "a2_zero_dice": zero_dice,
                "a2_zero_pred_voxels": zero_voxels,
                "truth_voxels": truth_voxels,
                "a2_alpha1_delta_dice_vs_b0": a2_dice - b0_dice,
                "a2_zero_delta_dice_vs_b0": zero_dice - b0_dice,
                "a2_zero_max_abs_logit_diff_vs_b0": float((zero_logits - b0_logits).abs().amax().item()),
                "a2_zero_mean_abs_logit_diff_vs_b0": float((zero_logits - b0_logits).abs().mean().item()),
            }
        )

    b0_hook.remove()
    a2_hook.remove()

    # Update-500 branch statistics only; no alpha sweep needed.
    a2_500_hook_store: dict[str, torch.Tensor] = {}
    a2_500_hook = install_encoder_capture(a2_500, a2_500_hook_store)
    update500_rows: list[dict[str, Any]] = []
    for record in records:
        token_store = {}
        install_alpha_wrapper(a2_500, 1.0, token_store)
        token = token_map[key(record)]
        pooled_value = pooled_map[key(record)]
        image, properties = load_image(ROOT / "data/ct_rate_volumes_fixed" / record["case"])
        data, bbox, original_shape = b0_predictor.preprocess(image)
        target = load_reference_mask_for_window_diagnostic(
            ROOT / "data/segmentations" / record["case"],
            1,
            tuple(original_shape),
            bbox,
            image_properties=properties,
            finding_ids=[record["finding_idx"]],
        )[0]
        patch, _target_patch, _starts, _padding = pad_and_crop(data, target)
        _ = run_model(
            a2_500,
            patch[None].to(device),
            pooled_value[None, None].to(device),
            token["feature"][None, None].to(device),
            torch.ones((1, 1, token["feature"].shape[0]), device=device, dtype=torch.bool),
            amp_dtype,
        )
        z_stats = tensor_stats(token_store["image_tokens"])
        delta_stats = tensor_stats(token_store["delta_full"])
        update500_rows.append(
            {
                "case": record["case"],
                "finding_idx": record["finding_idx"],
                "prompt": record["prompt"],
                "l2_ratio_delta_over_z": delta_stats["l2"] / max(z_stats["l2"], 1e-12),
                "rms_ratio_delta_over_z": delta_stats["rms"] / max(z_stats["rms"], 1e-12),
                "mean_abs_ratio_delta_over_z": delta_stats["mean_abs"] / max(z_stats["mean_abs"], 1e-12),
                "cos_z_z_after": cosine_flat(token_store["image_tokens"], token_store["output_tokens"]),
                **attention_stats(token_store["attention_weights"].cpu(), token_store["valid_token_mask"].cpu()[0]),
            }
        )
    a2_500_hook.remove()

    write_csv(args.output_dir / "sample_prediction_summary.csv", sample_rows)
    write_csv(args.output_dir / "alpha_sweep.csv", alpha_rows)
    write_csv(args.output_dir / "feature_stats_update0.csv", feature_rows)
    write_csv(args.output_dir / "attention_stats_update0.csv", attention_rows)
    write_csv(args.output_dir / "b0_a2_input_shift_update0.csv", diff_rows)
    write_csv(args.output_dir / "branch_stats_update500.csv", update500_rows)

    zero_max = max(row["a2_zero_max_abs_logit_diff_vs_b0"] for row in sample_rows)
    zero_mean = float(np.mean([row["a2_zero_mean_abs_logit_diff_vs_b0"] for row in sample_rows]))
    alpha0_mean = float(np.mean([row["dice"] for row in alpha_rows if row["alpha"] == 0.0]))
    alpha1_mean = float(np.mean([row["dice"] for row in alpha_rows if row["alpha"] == 1.0]))
    b0_mean = float(np.mean([row["b0_dice"] for row in sample_rows]))
    rel_rows = [row for row in feature_rows if row["tensor"] == "relative_perturbation"]
    mean_l2_ratio = float(np.mean([row["l2_ratio_delta_over_z"] for row in rel_rows]))
    mean_cos = float(np.mean([row["cos_z_z_after"] for row in rel_rows]))
    alpha_means = {
        str(alpha): float(np.mean([row["dice"] for row in alpha_rows if row["alpha"] == alpha]))
        for alpha in args.alphas
    }
    max_padding_mass = max(row["padding_special_attention_mass"] for row in attention_rows)

    alpha_support = alpha1_mean + 1e-6 < alpha0_mean and abs(alpha0_mean - b0_mean) < 1e-4
    zero_support = zero_max < 1e-2 and abs(alpha0_mean - b0_mean) < 1e-4
    magnitude_support = mean_l2_ratio > 0.01 or mean_cos < 0.999
    if zero_support and alpha_support and magnitude_support:
        decision = "D1_RANDOM_RESIDUAL_PERTURBATION_SUPPORTED"
    elif not zero_support:
        decision = "D2_HIDDEN_PATH_DIFFERENCE_OR_IMPLEMENTATION_ISSUE"
    else:
        decision = "D3_PERTURBATION_TOO_SMALL_TO_EXPLAIN_DROP"

    summary = {
        "decision": decision,
        "samples": len(sample_rows),
        "b0_patch_mean_dice": b0_mean,
        "a2_zero_patch_mean_dice": alpha0_mean,
        "a2_alpha1_patch_mean_dice": alpha1_mean,
        "zero_branch_max_abs_logit_diff_vs_b0_max": zero_max,
        "zero_branch_mean_abs_logit_diff_vs_b0_mean": zero_mean,
        "mean_l2_ratio_delta_over_z": mean_l2_ratio,
        "mean_cos_z_z_after": mean_cos,
        "alpha_mean_dice": alpha_means,
        "max_padding_special_attention_mass": max_padding_mass,
        "phase0_dir": str(args.phase0_dir.resolve()),
        "output_dir": str(args.output_dir.resolve()),
    }
    atomic_json(args.output_dir / "diagnosis_summary.json", summary)

    report = [
        "# Token Image->Text Phase-0B Gate Diagnosis",
        "",
        f"Decision: **{decision}**",
        "",
        "## Zero-Branch Check",
        "",
        f"- Mean B0 patch Dice: {b0_mean:.6f}",
        f"- Mean A2 alpha=0 patch Dice: {alpha0_mean:.6f}",
        f"- Max abs logit diff, A2 zero vs B0: {zero_max:.6g}",
        f"- Mean abs logit diff, A2 zero vs B0: {zero_mean:.6g}",
        "",
        "## Random-Branch Perturbation",
        "",
        f"- Mean ||DeltaZ|| / ||Z||: {mean_l2_ratio:.6f}",
        f"- Mean cos(Z, Z_after): {mean_cos:.6f}",
        f"- Mean A2 alpha=1 patch Dice: {alpha1_mean:.6f}",
        "",
        "## Alpha Sweep Mean Dice",
        "",
    ]
    for alpha in args.alphas:
        report.append(f"- alpha={alpha:g}: {alpha_means[str(alpha)]:.6f}")
    report.extend(
        [
            "",
            "## Attention Sanity",
            "",
            f"- Max padding/special-token attention mass: {max_padding_mass:.6g}",
            "",
            "## Files",
            "",
            "- `sample_prediction_summary.csv`",
            "- `alpha_sweep.csv`",
            "- `feature_stats_update0.csv`",
            "- `attention_stats_update0.csv`",
            "- `b0_a2_input_shift_update0.csv`",
            "- `branch_stats_update500.csv`",
            "- `diagnosis_summary.json`",
        ]
    )
    (args.output_dir / "report.md").write_text("\n".join(report) + "\n")
    print(json.dumps(summary, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
