#!/usr/bin/env python3
"""Compare existing COLIPRI and VoxTell prompt-response outputs without inference."""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score


ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--colipri-dir",
        type=Path,
        default=ROOT / "outputs/colipri_rex_minipilot_v1",
    )
    parser.add_argument(
        "--native-dir",
        type=Path,
        default=ROOT
        / "outputs/native_response_attention_minipilot_v1/native_response_audit_anchor85_step3800_v3",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "outputs/colipri_voxtell_nextstep_v1",
    )
    return parser.parse_args()


def effect_size(delta: pd.Series) -> float:
    values = delta.dropna().to_numpy(dtype=float)
    if values.size < 2:
        return float("nan")
    std = values.std(ddof=1)
    return float(values.mean() / std) if std > 0 else float("nan")


def discrimination_auroc(correct: pd.Series, shuffled: pd.Series) -> float:
    positive = correct.dropna().to_numpy(dtype=float)
    negative = shuffled.dropna().to_numpy(dtype=float)
    if positive.size == 0 or negative.size == 0:
        return float("nan")
    labels = np.concatenate([np.ones(positive.size), np.zeros(negative.size)])
    values = np.concatenate([positive, negative])
    return float(roc_auc_score(labels, values))


def add_metric(rows: list[dict], model: str, group: str, name: str, value: float, n: int, note: str = "") -> None:
    rows.append(
        {
            "model": model,
            "group": group,
            "metric": name,
            "value": value,
            "n": n,
            "status": "available" if math.isfinite(value) else "missing_or_not_derivable",
            "note": note,
        }
    )


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    colipri_global_path = args.colipri_dir / "global_alignment_results.csv"
    colipri_dense_path = args.colipri_dir / "dense_similarity_metrics.csv"
    native_selection_path = args.native_dir / "selected_findings_with_shuffle.csv"
    native_metrics_path = args.native_dir / "native_response_metrics.csv"
    for path in (colipri_global_path, colipri_dense_path, native_selection_path):
        if not path.exists():
            raise FileNotFoundError(path)

    colipri_global = pd.read_csv(colipri_global_path)
    colipri_global = colipri_global[colipri_global["variant"].eq("original")].copy()
    colipri_dense = pd.read_csv(colipri_dense_path)
    colipri_dense = colipri_dense[colipri_dense["variant"].eq("original")].copy()
    native_selected = pd.read_csv(native_selection_path).rename(columns={"case": "case_id"})
    native_selected["finding_id"] = [
        f"val:{case}:finding_{int(index)}"
        for case, index in zip(native_selected.case_id, native_selected.finding_idx)
    ]

    colipri_keys = set(colipri_global.finding_id)
    native_keys = set(native_selected.finding_id)
    union = sorted(colipri_keys | native_keys)
    manifest_rows = []
    colipri_meta = colipri_global.set_index("finding_id").to_dict("index")
    native_meta = native_selected.set_index("finding_id").to_dict("index")
    for finding_id in union:
        in_colipri = finding_id in colipri_keys
        in_native = finding_id in native_keys
        source = colipri_meta.get(finding_id, native_meta.get(finding_id, {}))
        if in_colipri and in_native:
            reason = ""
        elif not in_colipri:
            reason = "not selected by existing COLIPRI pilot"
        else:
            reason = "not selected by existing VoxTell native-response audit"
        manifest_rows.append(
            {
                "finding_id": finding_id,
                "case_id": source.get("case_id", ""),
                "finding_idx": source.get("finding_idx", ""),
                "category": source.get("category", ""),
                "focality": source.get("focality", ""),
                "prompt": source.get("prompt", ""),
                "available_colipri": in_colipri,
                "available_voxtell_native": in_native,
                "included_in_paired_comparison": in_colipri and in_native,
                "exclusion_reason": reason,
            }
        )
    manifest = pd.DataFrame(manifest_rows)
    manifest.to_csv(args.output_dir / "functional_comparison_common_manifest.csv", index=False)
    common_keys = set(manifest.loc[manifest.included_in_paired_comparison, "finding_id"])

    rows: list[dict] = []
    missing = []
    if not native_metrics_path.exists():
        missing.append(
            f"`{native_metrics_path}` is not yet available; the running native audit must finish."
        )
    else:
        native = pd.read_csv(native_metrics_path)
        native["finding_id"] = [
            f"val:{case}:finding_{int(index)}"
            for case, index in zip(native.case_id, native.finding_idx)
        ]
        native = native[native.finding_id.isin(common_keys)].copy()
        colipri = colipri_global[colipri_global.finding_id.isin(common_keys)].copy()
        dense = colipri_dense[colipri_dense.finding_id.isin(common_keys)].copy()

        for group in ("all", "focal", "diffuse"):
            c = colipri if group == "all" else colipri[colipri.focality.eq(group)]
            d = dense if group == "all" else dense[dense.focality.eq(group)]
            v = native if group == "all" else native[native.focality.eq(group)]
            c_delta = c.correct_similarity - c.shuffled_prompt_similarity
            v_delta = v.native_inside_minus_outside - v.shuffled_native_inside_minus_outside

            add_metric(rows, "COLIPRI", group, "correct_vs_shuffled_pairwise_accuracy", float((c_delta > 0).mean()), len(c))
            add_metric(rows, "COLIPRI", group, "correct_vs_shuffled_standardized_effect", effect_size(c_delta), len(c))
            add_metric(rows, "COLIPRI", group, "prompt_discrimination_auroc", discrimination_auroc(c.correct_similarity, c.shuffled_prompt_similarity), len(c))
            add_metric(rows, "COLIPRI", group, "voxel_ap", float(d.voxel_ap.mean()), len(d))
            add_metric(rows, "COLIPRI", group, "voxel_auroc", float(d.voxel_auroc.mean()), len(d))
            add_metric(rows, "COLIPRI", group, "inside_minus_outside_margin", float(d.inside_minus_outside_margin.mean()), len(d))
            add_metric(rows, "COLIPRI", group, "correct_vs_shuffled_map_correlation", float("nan"), len(d), "Existing COLIPRI pilot did not save shuffled dense maps.")

            add_metric(rows, "VoxTell", group, "correct_vs_shuffled_pairwise_accuracy", float((v_delta > 0).mean()), len(v))
            add_metric(rows, "VoxTell", group, "correct_vs_shuffled_standardized_effect", effect_size(v_delta), len(v))
            add_metric(rows, "VoxTell", group, "prompt_discrimination_auroc", discrimination_auroc(v.native_inside_minus_outside, v.shuffled_native_inside_minus_outside), len(v))
            add_metric(rows, "VoxTell", group, "voxel_ap", float(v.native_voxel_ap.mean()), len(v))
            add_metric(rows, "VoxTell", group, "voxel_auroc", float(v.native_voxel_auroc.mean()), len(v))
            add_metric(rows, "VoxTell", group, "inside_minus_outside_margin", float(v.native_inside_minus_outside.mean()), len(v))
            add_metric(rows, "VoxTell", group, "correct_vs_shuffled_map_correlation", float(v.native_map_correlation_with_shuffled.mean()), len(v))
            add_metric(rows, "VoxTell", group, "final_foreground_volume_change_under_shuffle", float("nan"), len(v), "Audit discarded shuffled final logits.")
            add_metric(rows, "VoxTell", group, "final_dice_change_under_shuffle", float("nan"), len(v), "Audit discarded shuffled final logits.")
            add_metric(rows, "VoxTell", group, "final_hit_change_under_shuffle", float("nan"), len(v), "Audit discarded shuffled final logits.")

    comparison = pd.DataFrame(rows, columns=["model", "group", "metric", "value", "n", "status", "note"])
    comparison.to_csv(args.output_dir / "inference_only_functional_comparison.csv", index=False)
    common = manifest[manifest.included_in_paired_comparison]
    report = [
        "# COLIPRI vs VoxTell Inference-Only Functional Comparison",
        "",
        f"- Common cases: **{common.case_id.nunique()}**",
        f"- Common findings: **{len(common)}**",
        f"- COLIPRI-only findings excluded: **{int((manifest.available_colipri & ~manifest.available_voxtell_native).sum())}**",
        f"- VoxTell-only findings excluded: **{int((~manifest.available_colipri & manifest.available_voxtell_native).sum())}**",
        "- Raw response magnitudes are not compared; all comparisons use standardized functional metrics.",
        "",
    ]
    if missing:
        report += ["## Current Status", "", *[f"- {item}" for item in missing], ""]
    if not comparison.empty:
        report += [
            "## Metrics",
            "",
            "The complete machine-readable table is in `inference_only_functional_comparison.csv`.",
            "",
            "```csv",
            comparison.to_csv(index=False).strip(),
            "```",
            "",
        ]
        available = comparison[comparison.status.eq("available")]
        lookup = {
            (row.model, row.group, row.metric): row.value
            for row in available.itertuples(index=False)
        }
        report += [
            "## Answers",
            "",
            (
                "- **Prompt discrimination:** COLIPRI is stronger on this tiny paired focal-only subset: "
                f"pairwise accuracy {lookup.get(('COLIPRI', 'all', 'correct_vs_shuffled_pairwise_accuracy'), float('nan')):.3f} "
                f"versus {lookup.get(('VoxTell', 'all', 'correct_vs_shuffled_pairwise_accuracy'), float('nan')):.3f}, and "
                f"AUROC {lookup.get(('COLIPRI', 'all', 'prompt_discrimination_auroc'), float('nan')):.3f} "
                f"versus {lookup.get(('VoxTell', 'all', 'prompt_discrimination_auroc'), float('nan')):.3f}."
            ),
            (
                "- **Local response quality:** neither model localizes reliably. VoxTell has higher mean voxel AP "
                f"({lookup.get(('VoxTell', 'all', 'voxel_ap'), float('nan')):.4f} versus "
                f"{lookup.get(('COLIPRI', 'all', 'voxel_ap'), float('nan')):.4f}), but COLIPRI has the less-poor "
                f"voxel AUROC ({lookup.get(('COLIPRI', 'all', 'voxel_auroc'), float('nan')):.3f} versus "
                f"{lookup.get(('VoxTell', 'all', 'voxel_auroc'), float('nan')):.3f}). Both AUROCs are below 0.5."
            ),
            "- **Global versus spatial:** the data are consistent with COLIPRI carrying better global prompt discrimination while its dense map is weak. VoxTell's native map is spatially tied to the segmentation decoder, but its correct/shuffled map correlation is high and its prompt discrimination is near chance.",
            "- **Focal versus diffuse:** all nine common findings are focal. No diffuse comparison is estimable from the exact existing-output intersection.",
            "",
        ]
    report += [
        "## Missing Metrics",
        "",
        "- Existing VoxTell audit does not retain shuffled final logits, so shuffled final foreground volume, Dice, and hit changes cannot be reconstructed.",
        "- Existing COLIPRI pilot does not retain shuffled dense maps, so dense-map correlation under shuffling cannot be reconstructed.",
        "- No new GPU inference was launched by this collector.",
        "",
        "## Interpretation Guardrail",
        "",
        "The paired sample is only 9 findings from 5 cases. Any model-level conclusion is exploratory and must not be generalized to the full validation set.",
    ]
    (args.output_dir / "inference_only_functional_comparison.md").write_text("\n".join(report) + "\n")
    print(f"Common cases={common.case_id.nunique()}, findings={len(common)}; native_metrics_available={native_metrics_path.exists()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
