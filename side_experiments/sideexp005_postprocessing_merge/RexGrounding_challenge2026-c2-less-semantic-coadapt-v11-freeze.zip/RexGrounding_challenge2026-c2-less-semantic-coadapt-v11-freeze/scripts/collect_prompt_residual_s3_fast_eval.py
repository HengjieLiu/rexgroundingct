#!/usr/bin/env python3
"""Collect paired metrics and the fixed decision for the S3 adapter subset-30 run."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))

from collect_prompt_residual_adapter_pilot import (  # noqa: E402
    bootstrap_ci,
    load_rows,
    paired_details,
    sha256,
)


KEYS = ("baseline", "update_25", "update_50", "update_100", "update_200")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--dataset-json", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    manifest = json.loads(args.manifest.read_text())
    cases = list(manifest["cases"])
    dataset = json.loads(args.dataset_json.read_text())
    metadata = {entry["name"]: entry for split in dataset.values() for entry in split}
    findings = sum(len(metadata[case]["findings"]) for case in cases)
    if len(cases) != 30 or findings != 49:
        raise ValueError(f"Expected 30 cases/49 findings, got {len(cases)}/{findings}")

    summaries = {}
    frames = {}
    for key in KEYS:
        summaries[key], frames[key] = load_rows(args.root, key)
        if int(summaries[key]["total_cases"]) != 30 or len(frames[key]) != 49:
            raise ValueError(f"{key} is not the fixed cohort")
    baseline = frames["baseline"]
    baseline_summary = summaries["baseline"]
    table = [
        {
            "key": "baseline",
            "model": "Selected S3 baseline",
            "dice_per_finding": float(
                baseline_summary["mean_global_dice_per_finding"]
            ),
            "delta": None,
            "dice_per_case": float(baseline_summary["mean_global_dice_per_case"]),
            "hit_rate": float(baseline_summary["hit_rate"]),
            "hits": int(baseline_summary["total_hits"]),
            "improved": None,
            "degraded": None,
        }
    ]
    details = {}
    for key in KEYS[1:]:
        item = paired_details(baseline, frames[key])
        details[key] = item
        summary = summaries[key]
        table.append(
            {
                "key": key,
                "model": f"Adapter {key.replace('_', ' ')}",
                "dice_per_finding": float(
                    summary["mean_global_dice_per_finding"]
                ),
                "delta": item["mean_paired_dice_delta"],
                "dice_per_case": float(summary["mean_global_dice_per_case"]),
                "hit_rate": float(summary["hit_rate"]),
                "hits": int(summary["total_hits"]),
                "improved": item["improved"],
                "degraded": item["degraded"],
            }
        )
    best = max(table[1:], key=lambda row: float(row["delta"]))
    delta = (
        frames[str(best["key"])]["global_dice"].to_numpy(dtype=np.float64)
        - baseline["global_dice"].to_numpy(dtype=np.float64)
    )
    ci = bootstrap_ci(delta)

    meaningful = []
    for key, item in details.items():
        for grouping in ("per_category", "focal_vs_diffuse", "tiny_vs_non_tiny"):
            for subgroup, values in item[grouping].items():
                if (
                    int(values["findings"]) >= 5
                    and float(values["mean_dice_delta"]) >= 0.003
                    and float(values["median_dice_delta"]) > 0
                    and int(values["improved"]) > int(values["degraded"])
                ):
                    meaningful.append(
                        {
                            "checkpoint": key,
                            "grouping": grouping,
                            "subgroup": subgroup,
                            **values,
                        }
                    )
    best_delta = float(best["delta"])
    if best_delta >= 0.003 and float(best["hit_rate"]) >= float(
        baseline_summary["hit_rate"]
    ):
        verdict = "PROMISING"
    elif -0.003 <= best_delta <= 0.003 and (
        meaningful or details[str(best["key"])]["new_hits"]
        > details[str(best["key"])]["baseline_hits_lost"]
    ):
        verdict = "WEAK/MIXED"
    elif all(float(row["delta"]) < 0 for row in table[1:]) and not meaningful:
        verdict = "NEGATIVE"
    else:
        verdict = "WEAK/MIXED"
    payload = {
        "manifest": {
            "path": str(args.manifest.resolve()),
            "sha256": sha256(args.manifest),
            "cases": len(cases),
            "findings": findings,
        },
        "threshold": 0.5,
        "table": table,
        "paired_details": details,
        "best_checkpoint": str(best["key"]),
        "best_checkpoint_bootstrap": {
            "samples": 10_000,
            "seed": 2026,
            "mean_delta": best_delta,
            "95_percent_ci": list(ci),
        },
        "meaningful_subgroups": meaningful,
        "verdict": verdict,
        "full_validation_triggered": verdict == "PROMISING",
    }
    fast = args.root / "fast_eval"
    (fast / "comparison.json").write_text(json.dumps(payload, indent=2) + "\n")
    lines = [
        "# Frozen S3 prompt residual adapter: fixed 30-case evaluation",
        "",
        f"Verdict: **{verdict}**",
        "",
        "| Model | Dice/finding | Delta | Dice/case | Hit rate | Hits | Improved | Degraded |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in table:
        delta_text = "—" if row["delta"] is None else f"{row['delta']:+.6f}"
        improved_text = "—" if row["improved"] is None else str(row["improved"])
        degraded_text = "—" if row["degraded"] is None else str(row["degraded"])
        lines.append(
            f"| {row['model']} | {row['dice_per_finding']:.6f} | "
            f"{delta_text} | "
            f"{row['dice_per_case']:.6f} | {row['hit_rate']:.6f} | "
            f"{row['hits']} | {improved_text} | {degraded_text} |"
        )
    lines.extend(
        [
            "",
            f"- Best checkpoint: `{best['key']}`.",
            f"- Paired bootstrap 95% CI: `[{ci[0]:+.6f}, {ci[1]:+.6f}]` "
            "(10,000 samples; seed 2026).",
            f"- Conditional full validation: "
            f"`{'triggered' if verdict == 'PROMISING' else 'not triggered'}`.",
            "",
            "Full paired, volume, category, focal/diffuse, and tiny/non-tiny "
            "diagnostics are in `comparison.json`.",
        ]
    )
    (fast / "summary.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"verdict": verdict, "best": best, "ci": ci}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
