#!/usr/bin/env python3
"""Save token attention maps and exploratory grounding ratios on fixed30."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "VoxTell") not in sys.path:
    sys.path.insert(0, str(ROOT / "VoxTell"))

from voxtell.inference.predictor import VoxTellPredictor  # noqa: E402
from scripts.run_voxtell_rex_inference import (  # noqa: E402
    load_image,
    load_reference_mask_for_window_diagnostic,
)


KEYWORDS = (
    "left", "right", "upper lobe", "lower lobe", "posterior", "anterior",
    "bronchiectasis", "nodule", "nodular", "ground-glass", "ground glass",
    "consolidation", "opacity",
)
PATHOLOGY = (
    "bronchiectasis", "nodule", "nodular", "ground-glass", "ground", "opacity",
    "consolidation",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", required=True, choices=["A1_replace", "A2_add"])
    parser.add_argument("--update", required=True, type=int, choices=[0, 500])
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--token-cache", required=True, type=Path)
    parser.add_argument("--pooled-cache", required=True, type=Path)
    parser.add_argument("--fixed30-manifest", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--max-findings", type=int, default=10)
    return parser.parse_args()


def key(record: dict) -> tuple[str, str, int]:
    return str(record["split"]), str(record["case"]), int(record["finding_idx"])


def load_maps(token_path: Path, pooled_path: Path):
    token = torch.load(token_path, map_location="cpu", weights_only=False)
    pooled = torch.load(pooled_path, map_location="cpu", weights_only=False)
    token_map = {
        key(record): {
            "feature": feature,
            "ids": ids,
            "strings": strings,
            "prompt": record["prompt"],
        }
        for record, feature, ids, strings in zip(
            token["records"], token["token_features"], token["token_ids"], token["token_strings"]
        )
    }
    pooled_map = {
        key(record): value.float()
        for record, value in zip(pooled["records"], pooled["embeddings"])
    }
    return token_map, pooled_map


def select_findings(manifest: dict, maximum: int) -> list[dict]:
    candidates = []
    for entry in manifest["val"]:
        for finding_id, prompt in sorted(entry["findings"].items(), key=lambda item: int(item[0])):
            text = prompt.lower()
            hits = [term for term in KEYWORDS if term in text]
            if hits:
                candidates.append(
                    {
                        "split": "val", "case": entry["name"],
                        "finding_idx": int(finding_id), "prompt": prompt,
                        "hits": hits,
                    }
                )
    selected = []
    covered = set()
    while candidates and len(selected) < maximum:
        candidates.sort(
            key=lambda row: (len(set(row["hits"]) - covered), len(row["hits"])),
            reverse=True,
        )
        chosen = candidates.pop(0)
        selected.append(chosen)
        covered.update(chosen["hits"])
    return selected


def pad_and_crop(array: torch.Tensor, target: torch.Tensor, patch=(192, 192, 192)):
    padding = []
    for size, wanted in reversed(list(zip(array.shape[-3:], patch))):
        total = max(0, wanted - size)
        padding.extend([total // 2, total - total // 2])
    array = F.pad(array, padding)
    target = F.pad(target, padding)
    foreground = torch.nonzero(target > 0, as_tuple=False)
    if foreground.numel():
        centroid = foreground.float().mean(dim=0)
        # Disconnected lesions can have a centroid in empty lung.  Center on
        # the foreground voxel nearest that centroid so the diagnostic crop is
        # guaranteed to contain GT without exposing GT to the model itself.
        center = foreground[(foreground.float() - centroid).square().sum(dim=1).argmin()]
    else:
        center = torch.tensor(array.shape[-3:]) // 2
    starts = []
    for value, size, wanted in zip(center.tolist(), array.shape[-3:], patch):
        starts.append(max(0, min(int(value) - wanted // 2, size - wanted)))
    slices = tuple(slice(start, start + wanted) for start, wanted in zip(starts, patch))
    return array[(slice(None), *slices)], target[slices], starts, padding


def clean_piece(piece: str) -> str:
    return piece.replace("Ġ", "").replace("▁", "").lower()


def readable_word_groups(pieces: list[str]) -> list[tuple[str, list[int]]]:
    groups: list[tuple[str, list[int]]] = []
    current = ""
    indices: list[int] = []
    for index, raw in enumerate(pieces):
        starts_word = index == 0 or raw.startswith(("Ġ", "▁"))
        if starts_word and indices:
            groups.append((current, indices))
            current, indices = "", []
        current += clean_piece(raw)
        indices.append(index)
    if indices:
        groups.append((current, indices))
    return groups


def means(attention: torch.Tensor, region: torch.Tensor) -> float:
    values = attention[region]
    return float(values.mean().item()) if values.numel() else float("nan")


def ratio(numerator: float, denominator: float) -> float:
    return numerator / max(denominator, 1e-12)


@torch.inference_mode()
def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(args.fixed30_manifest.read_text())
    selected = select_findings(manifest, args.max_findings)
    token_map, pooled_map = load_maps(args.token_cache, args.pooled_cache)

    model_dir = args.output_dir / "model"
    (model_dir / "fold_0").mkdir(parents=True, exist_ok=True)
    for link, target in (
        (model_dir / "plans.json", ROOT / "VoxTell/voxtell_v1.1/plans.json"),
        (model_dir / "fold_0/checkpoint_final.pth", args.checkpoint.resolve()),
    ):
        link.unlink(missing_ok=True)
        link.symlink_to(target)
    predictor = VoxTellPredictor(
        str(model_dir), device=torch.device("cuda"), load_text_backbone=False
    )
    model = predictor.network
    model.capture_token_image_text_attention = True
    model.eval().cuda()

    rows = []
    metadata = []
    for sample_index, record in enumerate(selected):
        cache_key = key(record)
        token = token_map[cache_key]
        image, properties = load_image(ROOT / "data/ct_rate_volumes_fixed" / record["case"])
        data, bbox, original_shape = predictor.preprocess(image)
        target = load_reference_mask_for_window_diagnostic(
            ROOT / "data/segmentations" / record["case"],
            1,
            tuple(original_shape),
            bbox,
            image_properties=properties,
            finding_ids=[record["finding_idx"]],
        )[0]
        patch, target_patch, starts, padding = pad_and_crop(data, target)
        pooled = pooled_map[cache_key][None, None].cuda()
        contextual = token["feature"][None, None].cuda()
        valid = torch.ones(contextual.shape[:3], device="cuda", dtype=torch.bool)
        with torch.autocast("cuda", dtype=torch.float16):
            _ = model(
                patch[None].cuda(), pooled,
                token_features=contextual, token_valid_mask=valid,
            )
        captured = model.last_token_image_text_attention[0][0].float().cpu()
        # [heads, H*W*D, text] -> [text, D, H, W]
        mean_head = captured.mean(dim=0).reshape(12, 12, 12, -1).permute(3, 2, 0, 1)
        # A tiny lesion can disappear under point-sampled nearest resizing.
        # Max pooling marks a bottleneck cell if any source GT voxel falls in
        # that cell and is appropriate because this mask is evaluation-only.
        target_small = F.adaptive_max_pool3d(
            target_patch[None, None].float(), output_size=(12, 12, 12)
        )[0, 0].bool()
        stem = record["case"].removesuffix(".nii.gz").removesuffix(".nii")
        lobe_path = ROOT / "data/rex_lobe_labels_preprocessed_v1/val" / f"{stem}.npz"
        lobe_small = None
        if lobe_path.is_file():
            with np.load(lobe_path) as payload:
                lobe = torch.from_numpy(np.asarray(payload["lobe_label"], dtype=np.uint8))
            lobe_padded = F.pad(lobe, padding)
            lobe_patch = lobe_padded[
                tuple(slice(start, start + 192) for start in starts)
            ]
            lobe_small = F.interpolate(
                lobe_patch[None, None].float(), size=(12, 12, 12), mode="nearest"
            )[0, 0].to(torch.uint8)

        pieces = [clean_piece(piece) for piece in token["strings"]]
        word_groups = readable_word_groups(token["strings"])
        sample_rows = []
        for piece, group_indices in word_groups:
            attention = mean_head[group_indices].mean(dim=0)
            token_index = "+".join(map(str, group_indices))
            base = {
                "arm": args.arm, "update": args.update, "case": record["case"],
                "finding_idx": record["finding_idx"], "finding": record["prompt"],
                "token_index": token_index,
                "token_id": "+".join(str(token["ids"][index]) for index in group_indices),
                "token": "+".join(token["strings"][index] for index in group_indices),
                "clean_token": piece,
            }
            if piece in {"left", "right"} and lobe_small is not None:
                correct = lobe_small >= 4 if piece == "left" else (lobe_small >= 1) & (lobe_small <= 3)
                opposite = (lobe_small >= 1) & (lobe_small <= 3) if piece == "left" else lobe_small >= 4
                correct_mean, opposite_mean = means(attention, correct), means(attention, opposite)
                if math.isfinite(correct_mean) and math.isfinite(opposite_mean):
                    sample_rows.append({**base, "metric": "laterality", "inside_mean": correct_mean,
                                        "outside_mean": opposite_mean, "ratio": ratio(correct_mean, opposite_mean)})
            if piece in PATHOLOGY:
                body = (lobe_small > 0) if lobe_small is not None else torch.ones_like(target_small)
                outside = body & ~target_small
                inside_mean, outside_mean = means(attention, target_small), means(attention, outside)
                if math.isfinite(inside_mean) and math.isfinite(outside_mean):
                    sample_rows.append({**base, "metric": "pathology_gt", "inside_mean": inside_mean,
                                        "outside_mean": outside_mean, "ratio": ratio(inside_mean, outside_mean)})
        if lobe_small is not None and ("upper lobe" in record["prompt"].lower() or "lower lobe" in record["prompt"].lower()):
            text = record["prompt"].lower()
            sides = {side for side in ("left", "right") if side in text}
            levels = {level for level in ("upper", "lower") if f"{level} lobe" in text}
            lobe_labels = {
                ("right", "upper"): 1, ("right", "lower"): 3,
                ("left", "upper"): 4, ("left", "lower"): 5,
            }
            mentioned = (
                lobe_small == lobe_labels[(next(iter(sides)), next(iter(levels)))]
                if len(sides) == 1 and len(levels) == 1
                else None
            )
            anatomy_indices = [
                index
                for word, indices in word_groups
                if word in {"upper", "lower", "lobe"}
                for index in indices
            ]
            if mentioned is not None and anatomy_indices:
                anatomy_attention = mean_head[anatomy_indices].mean(dim=0)
                other = (lobe_small > 0) & ~mentioned
                inside_mean, outside_mean = means(anatomy_attention, mentioned), means(anatomy_attention, other)
                if math.isfinite(inside_mean) and math.isfinite(outside_mean):
                    sample_rows.append({
                        "arm": args.arm, "update": args.update, "case": record["case"],
                        "finding_idx": record["finding_idx"], "finding": record["prompt"],
                        "token_index": "+".join(map(str, anatomy_indices)), "token_id": "",
                        "token": "lobe_phrase", "clean_token": "lobe_phrase", "metric": "lobe",
                        "inside_mean": inside_mean, "outside_mean": outside_mean,
                        "ratio": ratio(inside_mean, outside_mean),
                    })
        rows.extend(sample_rows)
        output = args.output_dir / f"sample_{sample_index:02d}_{stem}_f{record['finding_idx']}.npz"
        np.savez_compressed(
            output,
            mean_over_heads_attention=mean_head.numpy().astype(np.float16),
            target_bottleneck=target_small.numpy().astype(np.uint8),
            token_ids=np.asarray(token["ids"], dtype=np.int64),
            token_strings=np.asarray(token["strings"]),
        )
        metadata.append({
            **record, "token_ids": token["ids"], "token_strings": token["strings"],
            "attention_tensor_before_head_mean": list(captured.shape),
            "saved_attention_shape": list(mean_head.shape),
            "bottleneck_geometry_dhw": [12, 12, 12], "aggregation": "mean over 8 heads",
            "crop_start_after_padding": starts, "padding_wxyz_pairs": padding,
            "crop_selection": "GT-centered diagnostic crop; GT is used only to choose/evaluate the crop and is never a model input",
            "attention_is_calibrated_probability": False, "file": str(output),
            "target_voxels_in_crop": int(target_patch.sum().item()),
            "target_bottleneck_cells": int(target_small.sum().item()),
        })

    fieldnames = [
        "arm", "update", "case", "finding_idx", "finding", "token_index", "token_id",
        "token", "clean_token", "metric", "inside_mean", "outside_mean", "ratio",
    ]
    with (args.output_dir / "grounding_metrics.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    (args.output_dir / "attention_metadata.json").write_text(
        json.dumps({"arm": args.arm, "update": args.update, "samples": metadata}, indent=2) + "\n"
    )
    print(json.dumps({"samples": len(metadata), "metrics": len(rows)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
