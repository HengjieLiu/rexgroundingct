#!/usr/bin/env python3
"""Compare the matched ACA P0 run with its lambda_ACA=0 route-only ablation."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any

MATCHED_CONFIG_KEYS = (
    "model_dir",
    "preprocessed_dir",
    "lobe_label_dir",
    "embedding_cache",
    "fixed30_csv",
    "patch_size",
    "hidden_dim",
    "projection_dim",
    "queue_length",
    "min_overlap_threshold",
    "learning_rate",
    "weight_decay",
    "clip_grad_norm",
    "seed",
    "sampler_seed",
    "amp_dtype",
)

METRICS = (
    "dominant_anatomy_top1_accuracy",
    "top2_accuracy",
    "gt_overlap_probability_mass",
    "explicit_lobe_accuracy",
    "laterality_accuracy",
    "correct_route_loss",
    "left_right_swapped_route_loss",
    "correct_vs_swapped_margin",
    "mean_correct_visual_text_contrastive_loss",
    "mean_anatomy_permuted_visual_text_contrastive_loss",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-eval", type=Path, required=True)
    parser.add_argument("--reference-training-root", type=Path, required=True)
    parser.add_argument("--ablation-root", type=Path, required=True)
    return parser.parse_args()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def exact_mcnemar_p(improved: int, degraded: int) -> float:
    discordant = improved + degraded
    if discordant == 0:
        return 1.0
    tail = sum(math.comb(discordant, k) for k in range(min(improved, degraded) + 1))
    return min(1.0, 2.0 * tail / (2**discordant))


def paired_binary(
    reference: list[dict[str, str]],
    ablation: list[dict[str, str]],
    column: str,
) -> dict[str, Any]:
    pairs = [
        (left[column] == "True", right[column] == "True")
        for left, right in zip(reference, ablation)
        if left[column] != "" and right[column] != ""
    ]
    reference_only = sum(left and not right for left, right in pairs)
    ablation_only = sum(right and not left for left, right in pairs)
    return {
        "n": len(pairs),
        "reference_correct": sum(left for left, _ in pairs),
        "ablation_correct": sum(right for _, right in pairs),
        "reference_only_correct": reference_only,
        "ablation_only_correct": ablation_only,
        "mcnemar_exact_two_sided_p": exact_mcnemar_p(
            ablation_only, reference_only
        ),
    }


def per_anatomy_top1(rows: list[dict[str, str]]) -> dict[str, dict[str, Any]]:
    output: dict[str, dict[str, Any]] = {}
    for anatomy in sorted({row["dominant_anatomy"] for row in rows}):
        selected = [row for row in rows if row["dominant_anatomy"] == anatomy]
        correct = sum(row["top1_correct"] == "True" for row in selected)
        output[anatomy] = {
            "n": len(selected),
            "correct": correct,
            "accuracy": correct / len(selected),
        }
    return output


def main() -> int:
    args = parse_args()
    reference_aggregate = load_json(args.reference_eval / "aggregate.json")
    ablation_aggregate = load_json(args.ablation_root / "aggregate.json")
    reference_config = load_json(args.reference_training_root / "resolved_config.json")
    ablation_config = load_json(args.ablation_root / "resolved_config.json")

    mismatches = {
        key: {"reference": reference_config.get(key), "ablation": ablation_config.get(key)}
        for key in MATCHED_CONFIG_KEYS
        if reference_config.get(key) != ablation_config.get(key)
    }
    reference_samples = (
        args.reference_training_root / "train_sample_manifest.jsonl"
    ).read_text()
    ablation_samples = (args.ablation_root / "train_sample_manifest.jsonl").read_text()
    sample_sequence_exact_match = reference_samples == ablation_samples

    reference_rows = load_csv(args.reference_eval / "anatomy_retrieval.csv")
    ablation_rows = load_csv(args.ablation_root / "anatomy_retrieval.csv")
    reference_ids = [(row["case_id"], row["finding_idx"]) for row in reference_rows]
    ablation_ids = [(row["case_id"], row["finding_idx"]) for row in ablation_rows]
    if reference_ids != ablation_ids:
        raise AssertionError("Fixed30 finding order differs between the two runs")

    reference_metrics = reference_aggregate["fixed30_probe"]
    ablation_metrics = ablation_aggregate["fixed30_probe"]
    metric_comparison = {
        metric: {
            "aca_p0": reference_metrics[metric],
            "route_only": ablation_metrics[metric],
            "aca_minus_route_only": (
                reference_metrics[metric] - ablation_metrics[metric]
            ),
        }
        for metric in METRICS
    }
    paired = {
        "top1": paired_binary(reference_rows, ablation_rows, "top1_correct"),
        "top2": paired_binary(reference_rows, ablation_rows, "top2_correct"),
        "explicit_lobe": paired_binary(
            reference_rows, ablation_rows, "explicit_lobe_correct"
        ),
        "laterality": paired_binary(
            reference_rows, ablation_rows, "laterality_correct"
        ),
    }
    contrastive_separation = {
        "aca_p0": (
            reference_metrics["mean_anatomy_permuted_visual_text_contrastive_loss"]
            - reference_metrics["mean_correct_visual_text_contrastive_loss"]
        ),
        "route_only": (
            ablation_metrics["mean_anatomy_permuted_visual_text_contrastive_loss"]
            - ablation_metrics["mean_correct_visual_text_contrastive_loss"]
        ),
    }
    contrastive_separation["aca_minus_route_only"] = (
        contrastive_separation["aca_p0"] - contrastive_separation["route_only"]
    )
    above_frequency_baseline = {
        "top1": {
            "aca_p0": reference_metrics["dominant_anatomy_top1_accuracy"]
            - reference_metrics["dominant_anatomy_frequency_baseline"],
            "route_only": ablation_metrics["dominant_anatomy_top1_accuracy"]
            - ablation_metrics["dominant_anatomy_frequency_baseline"],
        },
        "explicit_lobe": {
            "aca_p0": reference_metrics["explicit_lobe_accuracy"]
            - reference_metrics["explicit_lobe_frequency_baseline"],
            "route_only": ablation_metrics["explicit_lobe_accuracy"]
            - ablation_metrics["explicit_lobe_frequency_baseline"],
        },
        "laterality": {
            "aca_p0": reference_metrics["laterality_accuracy"]
            - reference_metrics["laterality_frequency_baseline"],
            "route_only": ablation_metrics["laterality_accuracy"]
            - ablation_metrics["laterality_frequency_baseline"],
        },
    }
    integrity = {
        "matched_config_keys": list(MATCHED_CONFIG_KEYS),
        "config_mismatches": mismatches,
        "training_sample_sequence_exact_match": sample_sequence_exact_match,
        "fixed30_finding_sequence_exact_match": True,
        "reference_loss_weights": {"aca": 1.0, "route": 1.0},
        "ablation_loss_weights": ablation_aggregate.get("loss_weights"),
        "passed": (
            not mismatches
            and sample_sequence_exact_match
            and ablation_aggregate.get("loss_weights") == {"aca": 0.0, "route": 1.0}
            and ablation_aggregate.get("base_model_exactly_unchanged") is True
        ),
    }
    comparison = {
        "schema": "aca_p0_route_only_ablation_comparison_v1",
        "question": "Does L_ACA add representation value beyond L_route on the same frozen VoxTell features?",
        "integrity": integrity,
        "metrics": metric_comparison,
        "derived": {
            "contrastive_permutation_separation": contrastive_separation,
            "accuracy_above_frequency_baseline": above_frequency_baseline,
            "top1_by_dominant_anatomy": {
                "aca_p0": per_anatomy_top1(reference_rows),
                "route_only": per_anatomy_top1(ablation_rows),
            },
        },
        "paired_binary_outcomes": paired,
    }
    (args.ablation_root / "comparison_to_aca_p0.json").write_text(
        json.dumps(comparison, indent=2) + "\n"
    )

    lines = [
        "# ACA P0 versus route-only ablation",
        "",
        f"Matched-run integrity: **{'PASS' if integrity['passed'] else 'FAIL'}**.",
        "",
        "| Metric | ACA P0 | Route-only | ACA - route-only |",
        "|---|---:|---:|---:|",
    ]
    labels = {
        "dominant_anatomy_top1_accuracy": "Dominant anatomy top-1",
        "top2_accuracy": "Top-2",
        "gt_overlap_probability_mass": "GT-overlap probability mass",
        "explicit_lobe_accuracy": "Explicit-lobe accuracy",
        "laterality_accuracy": "Laterality accuracy",
        "correct_route_loss": "Correct route loss",
        "left_right_swapped_route_loss": "Swapped route loss",
        "correct_vs_swapped_margin": "Correct-vs-swapped margin",
        "mean_correct_visual_text_contrastive_loss": "Correct contrastive loss",
        "mean_anatomy_permuted_visual_text_contrastive_loss": "Permuted contrastive loss",
    }
    for metric in METRICS:
        row = metric_comparison[metric]
        lines.append(
            f"| {labels[metric]} | {row['aca_p0']:.6f} | "
            f"{row['route_only']:.6f} | {row['aca_minus_route_only']:+.6f} |"
        )
    lines.extend(["", "## Paired correctness", ""])
    for name, row in paired.items():
        lines.append(
            f"- {name}: ACA-only correct {row['reference_only_correct']}, "
            f"route-only correct {row['ablation_only_correct']}, "
            f"exact McNemar p={row['mcnemar_exact_two_sided_p']:.6g} (n={row['n']})."
        )
    lines.extend(
        [
            "",
            "## Derived diagnostics",
            "",
            f"- Contrastive permutation separation (permuted minus correct): ACA "
            f"{contrastive_separation['aca_p0']:.6f}, route-only "
            f"{contrastive_separation['route_only']:.6f}, delta "
            f"{contrastive_separation['aca_minus_route_only']:+.6f}.",
            f"- Top-1 above majority-frequency baseline: ACA "
            f"{above_frequency_baseline['top1']['aca_p0']:+.6f}, route-only "
            f"{above_frequency_baseline['top1']['route_only']:+.6f}.",
            f"- Explicit-lobe above majority-frequency baseline: ACA "
            f"{above_frequency_baseline['explicit_lobe']['aca_p0']:+.6f}, route-only "
            f"{above_frequency_baseline['explicit_lobe']['route_only']:+.6f}.",
            f"- Laterality above majority-frequency baseline: ACA "
            f"{above_frequency_baseline['laterality']['aca_p0']:+.6f}, route-only "
            f"{above_frequency_baseline['laterality']['route_only']:+.6f}.",
        ]
    )
    lines.extend(
        [
            "",
            "Positive `ACA - route-only` accuracy deltas favor ACA. For loss metrics, negative deltas favor ACA. Contrastive metrics for route-only are diagnostic because no contrastive gradient was applied.",
        ]
    )
    (args.ablation_root / "comparison_to_aca_p0.md").write_text(
        "\n".join(lines) + "\n"
    )
    print(json.dumps(comparison, indent=2))
    return 0 if integrity["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
