#!/usr/bin/env python3
"""Score native VoxTell full-volume/crop responses on the canonical five-lobe cohort."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
LOBE_NAMES = ("RUL", "RML", "RLL", "LUL", "LLL")
LOBE_VALUES = {"RUL": 3, "RML": 4, "RLL": 5, "LUL": 1, "LLL": 2}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    return parser.parse_args()


def normalized_nonnegative(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    total = float(values.sum())
    if total <= 0 or not np.isfinite(total):
        return np.full(5, 0.2, dtype=np.float64)
    return values / total


def softmax(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    values = values - np.nanmax(values)
    probability = np.exp(values)
    return normalized_nonnegative(probability)


def truth(row: dict[str, str]) -> np.ndarray:
    target = np.asarray([float(row[f"gt_soft_{name}"]) for name in LOBE_NAMES])
    return normalized_nonnegative(target)


def score_row(
    method: str,
    cohort: dict[str, str],
    probability: np.ndarray,
    *,
    raw_scores: np.ndarray | None = None,
) -> dict[str, Any]:
    probability = normalized_nonnegative(probability)
    target = truth(cohort)
    dominant = int(target.argmax())
    prediction = int(probability.argmax())
    right = float(probability[:3].sum())
    left = float(probability[3:].sum())
    true_side = cohort["gt_dominant_side"]
    predicted_side = "right" if right > left else "left"
    wrong = float(np.max(np.delete(probability, dominant)))
    record: dict[str, Any] = {
        "method": method,
        "case_id": cohort["case_id"],
        "finding_idx": int(cohort["finding_idx"]),
        "predicted_lobe": LOBE_NAMES[prediction],
        "top1_correct": prediction == dominant,
        "top2_correct": dominant in np.argsort(-probability, kind="stable")[:2],
        "predicted_side": predicted_side,
        "laterality_correct": predicted_side == true_side,
        "target_lobe_mass": float(probability[dominant]),
        "target_side_mass": right if true_side == "right" else left,
        "lobe_margin": float(probability[dominant] - wrong),
        "side_margin": abs(right - left) * (1 if predicted_side == true_side else -1),
        "cross_entropy": float(-(target * np.log(np.clip(probability, 1e-8, 1))).sum()),
        "brier": float(np.square(probability - target).sum()),
        **{f"score_{name}": float(probability[index]) for index, name in enumerate(LOBE_NAMES)},
    }
    if raw_scores is not None:
        record.update(
            {f"raw_{name}": float(raw_scores[index]) for index, name in enumerate(LOBE_NAMES)}
        )
    return record


def load_preprocessed_manifest() -> dict[str, dict[str, Any]]:
    path = ROOT / "data/rex_voxtell_preprocessed_v1/manifest.jsonl"
    return {
        row["case"]: row
        for row in (json.loads(line) for line in path.read_text().splitlines())
    }


def full_volume_rows(
    output_root: Path,
    cohort_rows: list[dict[str, str]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    manifest = load_preprocessed_manifest()
    by_case: dict[str, list[dict[str, str]]] = {}
    for row in cohort_rows:
        by_case.setdefault(row["case_id"], []).append(row)
    scores: list[dict[str, Any]] = []
    audit: list[dict[str, Any]] = []
    for case_id, rows in sorted(by_case.items()):
        stem = case_id.removesuffix(".nii.gz").removesuffix(".nii")
        probability_path = output_root / "native_voxtell_probabilities" / f"{stem}.npz"
        with np.load(probability_path) as payload:
            probability = np.asarray(payload["probability"], dtype=np.float32)
            finding_ids = [int(value) for value in payload["finding_ids"]]
            metadata = json.loads(str(payload["metadata_json"]))
        channel = {finding_id: index for index, finding_id in enumerate(finding_ids)}
        manifest_row = manifest[case_id]
        lobe_path = (
            ROOT / "data/rex_lobe_labels_preprocessed_v1" / manifest_row["split"] / f"{stem}.npz"
        )
        lobe = np.load(lobe_path)["lobe_label"]
        if tuple(probability.shape[1:]) != tuple(lobe.shape):
            raise AssertionError(
                f"Native probability/lobe mismatch {case_id}: {probability.shape[1:]} != {lobe.shape}"
            )
        label_order = np.asarray([LOBE_VALUES[name] for name in LOBE_NAMES], dtype=np.int64)
        flat_lobe = lobe.reshape(-1)
        lobe_voxels = np.bincount(flat_lobe, minlength=6)[label_order]
        if np.any(lobe_voxels == 0):
            raise AssertionError(f"Empty lobe in native scoring volume: {case_id}")
        for cohort in rows:
            finding = int(cohort["finding_idx"])
            response = probability[channel[finding]].reshape(-1)
            mass = np.bincount(flat_lobe, weights=response, minlength=6)[label_order]
            mean = mass / lobe_voxels
            binary_mass = np.bincount(
                flat_lobe, weights=response > 0.5, minlength=6
            )[label_order]
            scores.extend(
                (
                    score_row("native_full_probability_sum", cohort, normalized_nonnegative(mass), raw_scores=mass),
                    score_row("native_full_probability_mean", cohort, normalized_nonnegative(mean), raw_scores=mean),
                    score_row("native_full_binary_sum", cohort, normalized_nonnegative(binary_mass), raw_scores=binary_mass),
                )
            )
        audit.append(
            {
                "case_id": case_id,
                "probability_path": str(probability_path.resolve()),
                "lobe_path": str(lobe_path.resolve()),
                "probability_shape": json.dumps(list(probability.shape)),
                "lobe_shape": json.dumps(list(lobe.shape)),
                "finding_ids": json.dumps(finding_ids),
                "threshold_boundary_repairs": metadata.get("threshold_boundary_repairs", 0),
                "reference_binary_mismatches_before_anchor": metadata.get(
                    "reference_binary_mismatches_before_anchor", 0
                ),
            }
        )
    return scores, audit


def crop_rows(
    output_root: Path,
    cohort_by_key: dict[tuple[str, int], dict[str, str]],
) -> list[dict[str, Any]]:
    source = list(
        csv.DictReader(
            (output_root / "native_voxtell_crop_scores.csv").open(newline="", encoding="utf-8")
        )
    )
    result: list[dict[str, Any]] = []
    definitions = (
        ("native_crop_probability_sum", "native_probability_sum", normalized_nonnegative),
        ("native_crop_probability_mean", "native_probability_mean", normalized_nonnegative),
        ("native_crop_logit_sum", "native_logit_sum", softmax),
        ("native_crop_logit_mean", "native_logit_mean", softmax),
        ("native_crop_binary_sum", "native_binary_sum", normalized_nonnegative),
    )
    for row in source:
        key = (row["case_id"], int(row["finding_idx"]))
        cohort = cohort_by_key[key]
        for method, field, transform in definitions:
            raw = np.asarray(json.loads(row[field]), dtype=np.float64)[:5]
            result.append(score_row(method, cohort, transform(raw), raw_scores=raw))
    return result


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    cohort_rows = list(
        csv.DictReader((args.output_root / "cohort_manifest.csv").open(newline="", encoding="utf-8"))
    )
    cohort_by_key = {
        (row["case_id"], int(row["finding_idx"])): row for row in cohort_rows
    }
    full, audit = full_volume_rows(args.output_root, cohort_rows)
    crop = crop_rows(args.output_root, cohort_by_key)
    write_csv(args.output_root / "native_voxtell_scores.csv", full)
    write_csv(args.output_root / "native_internal_response_scores.csv", crop)
    write_csv(args.output_root / "native_alignment_audit.csv", audit)
    methods = sorted({row["method"] for row in full + crop})
    summary = {
        method: {
            "top1": float(np.mean([row["top1_correct"] for row in full + crop if row["method"] == method])),
            "top2": float(np.mean([row["top2_correct"] for row in full + crop if row["method"] == method])),
            "laterality": float(np.mean([row["laterality_correct"] for row in full + crop if row["method"] == method])),
            "target_lobe_mass": float(np.mean([row["target_lobe_mass"] for row in full + crop if row["method"] == method])),
        }
        for method in methods
    }
    (args.output_root / "native_voxtell_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
