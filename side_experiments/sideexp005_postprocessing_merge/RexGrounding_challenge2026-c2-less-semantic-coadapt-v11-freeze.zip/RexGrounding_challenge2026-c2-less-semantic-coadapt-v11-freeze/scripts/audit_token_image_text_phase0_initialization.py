#!/usr/bin/env python3
"""Verify exact Phase-0 update-0 weight provenance and path configuration."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ROOT = ROOT / "outputs/token_image_text_attention_phase0"
DEFAULT_CANONICAL = (
    ROOT
    / "outputs/s3d_matched_continue_from_weakdiffuse_control_step1000"
    / "allcat_1over1_only_to_step6000/checkpoints/checkpoint_step_6000.pth"
)
ARMS = {
    "B0_original": "original",
    "A1_replace": "replace_image_to_text",
    "A2_add": "add_image_to_text",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--canonical-checkpoint", type=Path, default=DEFAULT_CANONICAL)
    parser.add_argument("--stage", choices=("smoke", "formal"), default="smoke")
    return parser.parse_args()


def stable_object_digest(value) -> str:
    digest = hashlib.sha256()

    def update(item) -> None:
        if torch.is_tensor(item):
            tensor = item.detach().cpu().contiguous()
            digest.update(b"torch")
            digest.update(str(tensor.dtype).encode())
            digest.update(str(tuple(tensor.shape)).encode())
            digest.update(memoryview(tensor.view(torch.uint8).numpy()))
        elif isinstance(item, np.ndarray):
            array = np.ascontiguousarray(item)
            digest.update(b"numpy")
            digest.update(str(array.dtype).encode())
            digest.update(str(array.shape).encode())
            digest.update(memoryview(array.view(np.uint8)))
        elif isinstance(item, dict):
            digest.update(b"dict")
            for key in sorted(item, key=repr):
                update(key)
                update(item[key])
        elif isinstance(item, (list, tuple)):
            digest.update(type(item).__name__.encode())
            for child in item:
                update(child)
        else:
            digest.update(type(item).__name__.encode())
            digest.update(repr(item).encode())

    update(value)
    return digest.hexdigest()


def state_dict(path: Path) -> tuple[dict[str, torch.Tensor], dict, dict[str, str]]:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False, mmap=True)
    network = checkpoint.get("network_weights", checkpoint.get("state_dict", checkpoint))
    if not isinstance(network, dict):
        raise TypeError(f"No state dict in {path}")
    state = {
        key.removeprefix("module."): value
        for key, value in network.items()
        if torch.is_tensor(value)
    }
    # The trainer stores several opt-in modules in explicit weight groups.
    # They are model state too and must be included in the canonical equality
    # check even though they are outside ``network_weights``.
    for group, values in checkpoint.items():
        if group == "network_weights" or not group.endswith("_weights"):
            continue
        if isinstance(values, dict):
            for key, value in values.items():
                if torch.is_tensor(value):
                    state[f"{group}.{key.removeprefix('module.')}"] = value
    config = {}
    for field in ("model_config", "config", "experimental_model_config", "args"):
        value = checkpoint.get(field, {})
        if isinstance(value, dict):
            config.update(value)
    rng_digests = {
        field: stable_object_digest(checkpoint.get(field))
        for field in (
            "python_rng_state", "numpy_rng_state", "torch_cpu_rng_state",
            "torch_cuda_rng_state_all", "sampler_state",
        )
    }
    return state, config, rng_digests


def tensor_digest(tensor: torch.Tensor) -> str:
    tensor = tensor.detach().cpu().contiguous()
    raw = tensor.view(torch.uint8).numpy()
    return hashlib.sha256(memoryview(raw)).hexdigest()


def compare(reference: dict[str, torch.Tensor], candidate: dict[str, torch.Tensor]) -> dict:
    common = sorted(reference.keys() & candidate.keys())
    mismatched = []
    for key in common:
        left, right = reference[key], candidate[key]
        if left.shape != right.shape or left.dtype != right.dtype or not torch.equal(left, right):
            mismatched.append(key)
    return {
        "reference_tensor_count": len(reference),
        "candidate_tensor_count": len(candidate),
        "common_tensor_count": len(common),
        "missing_from_candidate": sorted(reference.keys() - candidate.keys()),
        "extra_in_candidate": sorted(candidate.keys() - reference.keys()),
        "mismatched_common_tensors": mismatched,
        "all_common_tensors_bit_exact": not mismatched,
    }


def main() -> int:
    args = parse_args()
    experiment_root = args.experiment_root.resolve()
    canonical_path = args.canonical_checkpoint.resolve()
    canonical, _, _ = state_dict(canonical_path)
    arm_states: dict[str, dict[str, torch.Tensor]] = {}
    report = {
        "canonical_checkpoint": str(canonical_path),
        "stage": args.stage,
        "arms": {},
    }
    for arm, expected_mode in ARMS.items():
        prefix = experiment_root / ("smoke" if args.stage == "smoke" else "") / arm
        path = prefix / "checkpoints/checkpoint_initial.pth"
        state, config, rng_digests = state_dict(path)
        arm_states[arm] = state
        comparison = compare(canonical, state)
        actual_mode = config.get("token_image_text_mode")
        token_keys = sorted(key for key in state if key.startswith("token_image_text_block."))
        report["arms"][arm] = {
            "checkpoint": str(path),
            "configured_mode": actual_mode,
            "expected_mode": expected_mode,
            "mode_matches": actual_mode == expected_mode,
            "token_tensor_count": len(token_keys),
            "rng_state_digests": rng_digests,
            "canonical_comparison": comparison,
        }

    a1_token = {
        key: value
        for key, value in arm_states["A1_replace"].items()
        if key.startswith("token_image_text_block.")
    }
    a2_token = {
        key: value
        for key, value in arm_states["A2_add"].items()
        if key.startswith("token_image_text_block.")
    }
    token_comparison = compare(a1_token, a2_token)
    report["a1_a2_new_block_comparison"] = token_comparison
    report["arm_rng_state_fields_identical"] = {
        field: len({item["rng_state_digests"][field] for item in report["arms"].values()}) == 1
        for field in next(iter(report["arms"].values()))["rng_state_digests"]
    }
    report["arm_rng_states_identical"] = all(
        report["arm_rng_state_fields_identical"].values()
    )

    b0 = report["arms"]["B0_original"]["canonical_comparison"]
    compatible_exact = all(
        item["canonical_comparison"]["all_common_tensors_bit_exact"]
        and not item["canonical_comparison"]["missing_from_candidate"]
        for item in report["arms"].values()
    )
    passed = (
        compatible_exact
        and not b0["extra_in_candidate"]
        and all(item["mode_matches"] for item in report["arms"].values())
        and report["arms"]["B0_original"]["token_tensor_count"] == 0
        and report["arms"]["A1_replace"]["token_tensor_count"] > 0
        and report["arms"]["A2_add"]["token_tensor_count"] > 0
        and token_comparison["all_common_tensors_bit_exact"]
        and not token_comparison["missing_from_candidate"]
        and not token_comparison["extra_in_candidate"]
        and report["arm_rng_states_identical"]
    )
    report["passed"] = passed
    output = experiment_root / f"initialization_audit_{args.stage}.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
