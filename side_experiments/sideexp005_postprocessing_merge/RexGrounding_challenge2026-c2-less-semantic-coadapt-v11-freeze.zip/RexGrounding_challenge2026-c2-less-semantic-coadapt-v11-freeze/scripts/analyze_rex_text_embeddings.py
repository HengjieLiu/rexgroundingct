#!/usr/bin/env python
"""Analyze ReXGroundingCT text-prompt embeddings against validation Dice.

For each validation finding, this script embeds the prompt with the same Qwen
embedding path used by VoxTell, retrieves nearest training prompts by cosine
similarity, and joins the result with an existing validation metrics JSON.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import torch
import torch.nn.functional as F
from tqdm import tqdm
from transformers import AutoModel, AutoTokenizer


REX_ROOT = Path(__file__).resolve().parents[1]
VOXTELL_ROOT = REX_ROOT / "VoxTell"
if str(VOXTELL_ROOT) not in sys.path:
    sys.path.insert(0, str(VOXTELL_ROOT))

from voxtell.utils.text_embedding import last_token_pool, wrap_with_instruction  # noqa: E402


KEYWORD_GROUPS = {
    "nodule": ["nodule", "nodular", "lymph node"],
    "ground_glass": ["ground-glass", "ground glass", "ggo", "crazy paving"],
    "consolidation": ["consolidation", "consolidative", "opacity", "opacities"],
    "atelectasis": ["atelectasis", "atelectatic"],
    "effusion": ["effusion"],
    "emphysema": ["emphysema", "emphysematous", "paraseptal", "centrilobular"],
    "scarring_fibrosis": ["scar", "scarring", "fibrosis", "fibrotic", "architectural distortion"],
    "bronchiectasis": ["bronchiectasis", "bronchiolectasis"],
    "calcification": ["calcified", "calcification", "calcium"],
    "cyst": ["cyst", "cystic", "bulla", "bullae"],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate semantic neighborhoods of ReX prompt embeddings."
    )
    parser.add_argument(
        "--rex-json",
        type=Path,
        default=REX_ROOT / "data/MICCAI_challenge_dataset.json",
        help="ReXGroundingCT JSON file.",
    )
    parser.add_argument(
        "--eval-json",
        type=Path,
        default=REX_ROOT / "outputs/voxtell_rex_miccai_val/eval_rexrank_metrics.json",
        help="Validation metric JSON from evaluate_rex_predictions.py.",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=REX_ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis",
        help="Directory for cached embeddings and reports.",
    )
    parser.add_argument("--train-split", default="train")
    parser.add_argument("--val-split", default="val")
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument(
        "--text-model",
        default="Qwen/Qwen3-Embedding-4B",
        help="Text embedding model. Defaults to VoxTell inference model.",
    )
    parser.add_argument(
        "--max-length",
        type=int,
        default=8192,
        help="Maximum text tokens for the embedding model.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Recompute cached embeddings.",
    )
    return parser.parse_args()


def collect_prompts(rex_json: Path, split: str) -> list[dict]:
    with rex_json.open() as f:
        data = json.load(f)
    records = []
    for entry in data[split]:
        for finding_idx, prompt in sorted(
            entry["findings"].items(), key=lambda kv: int(kv[0])
        ):
            records.append(
                {
                    "split": split,
                    "case": entry["name"],
                    "finding_idx": int(finding_idx),
                    "prompt": prompt,
                    "category": entry.get("categories", {}).get(str(finding_idx)),
                    "pixels": entry.get("pixels", {}).get(str(finding_idx)),
                }
            )
    return records


def category_from_keywords(prompt: str) -> str:
    text = prompt.lower()
    hits = []
    for group, keywords in KEYWORD_GROUPS.items():
        if any(keyword in text for keyword in keywords):
            hits.append(group)
    return "+".join(hits) if hits else "other"


def load_eval(eval_json: Path) -> dict[tuple[str, int], dict]:
    with eval_json.open() as f:
        data = json.load(f)
    metrics = {}
    for case in data.get("cases", []):
        case_name = case["file"]
        for key, value in case.get("findings", {}).items():
            idx = int(key.replace("finding_", ""))
            metrics[(case_name, idx)] = {
                "global_dice": float(value["global_dice"]),
                "global_hit": bool(value["global_hit"]),
            }
    return metrics


@torch.inference_mode()
def embed_prompts(
    prompts: list[str],
    text_model: str,
    device: torch.device,
    batch_size: int,
    max_length: int,
) -> torch.Tensor:
    tokenizer = AutoTokenizer.from_pretrained(text_model, padding_side="left")
    model = AutoModel.from_pretrained(text_model).eval().to(device)
    embeddings = []
    for start in tqdm(range(0, len(prompts), batch_size), desc="Embedding prompts"):
        batch = prompts[start : start + batch_size]
        batch = wrap_with_instruction(batch)
        inputs = tokenizer(
            batch,
            padding=True,
            truncation=True,
            max_length=max_length,
            return_tensors="pt",
        ).to(device)
        outputs = model(**inputs)
        pooled = last_token_pool(outputs.last_hidden_state, inputs["attention_mask"])
        embeddings.append(pooled.cpu())
    del model
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return torch.cat(embeddings, dim=0)


def rankdata(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        avg = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def pearson(xs: list[float], ys: list[float]) -> float:
    if len(xs) < 2:
        return float("nan")
    mx = sum(xs) / len(xs)
    my = sum(ys) / len(ys)
    vx = sum((x - mx) ** 2 for x in xs)
    vy = sum((y - my) ** 2 for y in ys)
    if vx == 0 or vy == 0:
        return float("nan")
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / math.sqrt(vx * vy)


def spearman(xs: list[float], ys: list[float]) -> float:
    return pearson(rankdata(xs), rankdata(ys))


def summarize_by_bins(rows: list[dict], value_key: str) -> list[dict]:
    bins = [
        ("<0.70", lambda x: x < 0.70),
        ("0.70-0.80", lambda x: 0.70 <= x < 0.80),
        ("0.80-0.90", lambda x: 0.80 <= x < 0.90),
        (">=0.90", lambda x: x >= 0.90),
    ]
    out = []
    for label, pred in bins:
        sub = [r for r in rows if pred(float(r[value_key]))]
        if not sub:
            out.append({"bin": label, "n": 0})
            continue
        out.append(
            {
                "bin": label,
                "n": len(sub),
                "mean_dice": sum(float(r["global_dice"]) for r in sub) / len(sub),
                "hit_rate": sum(bool(r["global_hit"]) for r in sub) / len(sub),
            }
        )
    return out


def write_markdown(report_path: Path, summary: dict, rows: list[dict]) -> None:
    top_failures = sorted(rows, key=lambda r: (float(r["global_dice"]), -float(r["top1_similarity"])))[:12]
    isolated = sorted(rows, key=lambda r: float(r["top1_similarity"]))[:12]
    best = sorted(rows, key=lambda r: float(r["global_dice"]), reverse=True)[:8]

    with report_path.open("w") as f:
        f.write("# ReX Prompt Embedding Analysis\n\n")
        f.write("## Summary\n\n")
        for key, value in summary.items():
            if isinstance(value, float):
                f.write(f"- **{key}**: {value:.4f}\n")
            else:
                f.write(f"- **{key}**: {value}\n")
        f.write("\n## Similarity Bins\n\n")
        f.write("| Top-1 similarity bin | Findings | Mean Dice | HIT rate |\n")
        f.write("|---|---:|---:|---:|\n")
        for row in summary["top1_similarity_bins"]:
            if row["n"] == 0:
                f.write(f"| {row['bin']} | 0 | NA | NA |\n")
            else:
                f.write(
                    f"| {row['bin']} | {row['n']} | {row['mean_dice']:.4f} | "
                    f"{row['hit_rate']:.4f} |\n"
                )

        def table(title: str, subset: list[dict]) -> None:
            f.write(f"\n## {title}\n\n")
            f.write("| Dice | Top-1 sim | Case | Finding | Keyword group | Prompt | Nearest train prompt |\n")
            f.write("|---:|---:|---|---:|---|---|---|\n")
            for row in subset:
                prompt = row["prompt"].replace("|", "\\|")
                nearest = row["top1_prompt"].replace("|", "\\|")
                f.write(
                    f"| {float(row['global_dice']):.4f} | {float(row['top1_similarity']):.4f} | "
                    f"{row['case']} | {row['finding_idx']} | {row['keyword_group']} | "
                    f"{prompt} | {nearest} |\n"
                )

        table("Lowest Dice Findings", top_failures)
        table("Most Semantically Isolated Validation Prompts", isolated)
        table("Highest Dice Findings", best)


def main() -> int:
    args = parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA was requested but is not available in this session. Run this on a GPU node "
            "or pass --device cpu with a much smaller embedding model."
        )
    device = torch.device(f"cuda:{args.gpu}" if args.device == "cuda" else "cpu")

    train_records = collect_prompts(args.rex_json, args.train_split)
    val_records = collect_prompts(args.rex_json, args.val_split)
    all_prompts = [r["prompt"] for r in train_records + val_records]
    cache = args.out_dir / f"qwen_prompt_embeddings_{args.train_split}_{args.val_split}.pt"

    if cache.exists() and not args.force:
        cached = torch.load(cache, map_location="cpu", weights_only=False)
        embeddings = cached["embeddings"]
        print(f"Loaded cached embeddings: {cache}")
    else:
        embeddings = embed_prompts(
            all_prompts,
            args.text_model,
            device,
            args.batch_size,
            args.max_length,
        )
        torch.save(
            {
                "embeddings": embeddings,
                "text_model": args.text_model,
                "records": train_records + val_records,
            },
            cache,
        )
        print(f"Saved embeddings: {cache}")

    train_emb = F.normalize(embeddings[: len(train_records)].float(), dim=1)
    val_emb = F.normalize(embeddings[len(train_records) :].float(), dim=1)
    sims = val_emb @ train_emb.T
    top_values, top_indices = torch.topk(sims, k=args.top_k, dim=1)

    metrics = load_eval(args.eval_json)
    rows = []
    for i, val_record in enumerate(val_records):
        metric = metrics.get((val_record["case"], val_record["finding_idx"]))
        if metric is None:
            continue
        neighbor_indices = top_indices[i].tolist()
        neighbor_values = top_values[i].tolist()
        row = {
            **val_record,
            **metric,
            "keyword_group": category_from_keywords(val_record["prompt"]),
            "top1_similarity": neighbor_values[0],
            "top1_case": train_records[neighbor_indices[0]]["case"],
            "top1_finding_idx": train_records[neighbor_indices[0]]["finding_idx"],
            "top1_prompt": train_records[neighbor_indices[0]]["prompt"],
        }
        for rank, (idx, sim) in enumerate(zip(neighbor_indices, neighbor_values), start=1):
            row[f"top{rank}_similarity"] = sim
            row[f"top{rank}_case"] = train_records[idx]["case"]
            row[f"top{rank}_finding_idx"] = train_records[idx]["finding_idx"]
            row[f"top{rank}_prompt"] = train_records[idx]["prompt"]
        rows.append(row)

    csv_path = args.out_dir / "val_prompt_nearest_train.csv"
    fieldnames = list(rows[0].keys())
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    dice = [float(r["global_dice"]) for r in rows]
    top1 = [float(r["top1_similarity"]) for r in rows]
    summary = {
        "train_prompts": len(train_records),
        "val_prompts_with_metrics": len(rows),
        "mean_top1_similarity": sum(top1) / len(top1),
        "median_top1_similarity": sorted(top1)[len(top1) // 2],
        "min_top1_similarity": min(top1),
        "max_top1_similarity": max(top1),
        "mean_global_dice": sum(dice) / len(dice),
        "spearman_top1_similarity_vs_dice": spearman(top1, dice),
        "pearson_top1_similarity_vs_dice": pearson(top1, dice),
        "top1_similarity_bins": summarize_by_bins(rows, "top1_similarity"),
    }

    json_path = args.out_dir / "summary.json"
    with json_path.open("w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)

    md_path = args.out_dir / "text_embedding_analysis.md"
    write_markdown(md_path, summary, rows)

    print(json.dumps(summary, indent=2))
    print(f"Wrote CSV: {csv_path}")
    print(f"Wrote JSON: {json_path}")
    print(f"Wrote report: {md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
