#!/usr/bin/env python3
"""Offline forensics of the exact saved C-global 32-pair gradient audit."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT
    / "outputs/original_voxtell_wholefinding_semantic/c_global/"
    "lambda_scaling_recheck/per_pair_gradients.tsv"
)
CALIBRATION = (
    ROOT
    / "outputs/original_voxtell_wholefinding_semantic/c_global/"
    "calibration/calibration.json"
)
GRADIENT_AUDIT = SOURCE.with_name("gradient_audit.json")
PARAMETER_GROUPS = SOURCE.with_name("parameter_groups.json")
PAIR_METADATA = ROOT / "outputs/semantic_alignment_placement_audit/same_case_pairs/pairs.csv"
MANIFEST = ROOT / "data/rex_voxtell_preprocessed_v1/manifest.jsonl"
OUT = ROOT / "outputs/c_global_32pair_gradient_forensics"

PAIR_LABELS = {
    "same_pathology_different_anatomy": ("A", "same pathology, different anatomy"),
    "different_pathology_same_anatomy": ("B", "different pathology, same anatomy"),
    "different_pathology_different_anatomy": ("C", "different pathology, different anatomy"),
    "same_pathology_same_anatomy_distinct": ("D", "same pathology, same anatomy"),
}
LAMBDAS = (0.10, 0.25, 0.50, 1.00)


def clean(value: object) -> str | None:
    if pd.isna(value):
        return None
    text = str(value).strip()
    return None if not text or text.casefold() in {"nan", "none", "unspecified"} else text


def equality_label(left: str | None, right: str | None) -> str:
    if left is None or right is None:
        return "UNKNOWN"
    return "same" if left == right else "different"


def manifest_by_case() -> dict[str, dict]:
    records: dict[str, dict] = {}
    with MANIFEST.open() as handle:
        for line in handle:
            record = json.loads(line)
            records[str(record["case"])] = record
    return records


def pair_metadata_index() -> dict[tuple[str, tuple[int, int]], pd.Series]:
    pairs = pd.read_csv(PAIR_METADATA)
    return {
        (str(row.case), tuple(sorted((int(row.left_idx), int(row.right_idx))))): row
        for _, row in pairs.iterrows()
    }


def describe_group(frame: pd.DataFrame) -> dict[str, float | int]:
    active_cosines = frame.loc[frame["hinge_active"].astype(bool), "gradient_cosine"].dropna()
    return {
        "N": int(len(frame)),
        "hinge_active_count": int(frame["hinge_active"].sum()),
        "hinge_active_rate": float(frame["hinge_active"].mean()),
        "median_g_C_norm": float(frame["g_C_norm"].median()),
        "median_g_seg_norm": float(frame["g_seg_norm"].median()),
        "median_ratio": float(frame["gradient_ratio"].median()),
        "p90_ratio": float(frame["gradient_ratio"].quantile(0.90)),
        "median_cosine_active": float(active_cosines.median()) if len(active_cosines) else math.nan,
    }


def markdown_table(frame: pd.DataFrame, columns: list[str] | None = None) -> str:
    selected = frame if columns is None else frame[columns]
    def render(value: object) -> str:
        if pd.isna(value):
            return "NA"
        if isinstance(value, (float, np.floating)):
            return f"{float(value):.6g}"
        return str(value).replace("|", "\\|").replace("\n", " ")

    headers = [str(column) for column in selected.columns]
    lines = [
        "| " + " | ".join(headers) + " |",
        "|" + "|".join("---" for _ in headers) + "|",
    ]
    lines.extend(
        "| " + " | ".join(render(value) for value in row) + " |"
        for row in selected.itertuples(index=False, name=None)
    )
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    gradients = pd.read_csv(SOURCE, sep="\t")
    calibration = json.loads(CALIBRATION.read_text())
    gradient_audit = json.loads(GRADIENT_AUDIT.read_text())
    parameter_groups = json.loads(PARAMETER_GROUPS.read_text())
    if len(gradients) != 32 or int(gradient_audit["pair_count"]) != 32:
        raise RuntimeError("The saved audit is not the exact expected 32-pair cohort")
    expected = [
        (str(row["case_id"]), int(row["correct_finding_id"]), int(row["wrong_finding_id"]))
        for row in calibration["rows"]
    ]
    observed = [
        (str(row.case_id), int(row.correct_finding_id), int(row.wrong_finding_id))
        for _, row in gradients.iterrows()
    ]
    if observed != expected:
        raise RuntimeError("Saved per-pair gradient identities differ from the calibration sequence")

    cases = manifest_by_case()
    metadata = pair_metadata_index()
    rows: list[dict] = []
    for _, source in gradients.iterrows():
        case_id = str(source.case_id)
        correct_id = int(source.correct_finding_id)
        wrong_id = int(source.wrong_finding_id)
        case = cases[case_id]
        positions = {int(finding): index for index, finding in enumerate(case["finding_indices"])}
        if correct_id not in positions or wrong_id not in positions:
            raise RuntimeError(f"Missing finding in preprocessed manifest: {case_id}")
        correct_position, wrong_position = positions[correct_id], positions[wrong_id]
        pair = metadata[(case_id, tuple(sorted((correct_id, wrong_id))))]
        if int(pair.left_idx) == correct_id:
            correct_side, wrong_side = clean(pair.left_side), clean(pair.right_side)
            correct_lobes, wrong_lobes = clean(pair.left_lobes), clean(pair.right_lobes)
        else:
            correct_side, wrong_side = clean(pair.right_side), clean(pair.left_side)
            correct_lobes, wrong_lobes = clean(pair.right_lobes), clean(pair.left_lobes)
        label, description = PAIR_LABELS.get(str(source.pair_type), ("UNKNOWN", "UNKNOWN"))
        rows.append(
            {
                "pair_index": int(source.pair_index),
                "case_id": case_id,
                "target_finding_id": correct_id,
                "wrong_finding_id": wrong_id,
                "target_finding": case["prompts"][correct_position],
                "wrong_same_case_finding": case["prompts"][wrong_position],
                "pair_type": label,
                "pair_type_description": description,
                "same_laterality": equality_label(correct_side, wrong_side),
                "target_laterality": correct_side or "UNKNOWN",
                "wrong_laterality": wrong_side or "UNKNOWN",
                "same_lobe": equality_label(correct_lobes, wrong_lobes),
                "target_lobe": correct_lobes or "UNKNOWN",
                "wrong_lobe": wrong_lobes or "UNKNOWN",
                "g_seg_norm": float(source.all_shared_seg_norm),
                "g_C_norm": float(source.all_shared_c_norm),
                "gradient_ratio": float(source.all_shared_raw_ratio),
                "gradient_cosine": float(source.all_shared_cosine),
                "L_correct": float(source.L_correct),
                "L_wrong": float(source.L_wrong),
                "D_wrong_minus_correct": float(source.D_wrong_minus_correct),
                "hinge_raw": float(source.hinge_raw),
                "hinge_active": int(source.hinge_active),
                "target_gt_volume_preprocessed_voxels": int(
                    case["preprocessed_mask_voxels"][correct_position]
                ),
                "target_gt_volume_original_voxels": int(
                    case["original_mask_voxels"][correct_position]
                ),
            }
        )
    per_pair = pd.DataFrame(rows).sort_values("pair_index").reset_index(drop=True)

    high_count = int(math.ceil(0.20 * len(per_pair)))
    high_indices = set(per_pair.nlargest(high_count, "gradient_ratio")["pair_index"])
    per_pair["high_ratio_top20pct"] = per_pair["pair_index"].isin(high_indices)
    per_pair["volume_bin"] = pd.qcut(
        per_pair["target_gt_volume_preprocessed_voxels"].rank(method="first"),
        3,
        labels=["small", "medium", "large"],
    ).astype(str)
    per_pair.to_csv(OUT / "per_pair.tsv", sep="\t", index=False)

    type_rows = []
    for label in ("A", "B", "C", "D", "UNKNOWN"):
        subset = per_pair[per_pair["pair_type"] == label]
        if subset.empty:
            continue
        type_rows.append(
            {
                "pair_type": label,
                "description": subset.iloc[0]["pair_type_description"],
                **describe_group(subset),
                "high_ratio_tail_count": int(subset["high_ratio_top20pct"].sum()),
            }
        )
    type_summary = pd.DataFrame(type_rows)
    type_summary.to_csv(OUT / "pair_type_summary.tsv", sep="\t", index=False)

    volume_rows = []
    for label in ("small", "medium", "large"):
        subset = per_pair[per_pair["volume_bin"] == label]
        summary = describe_group(subset)
        volume_rows.append(
            {
                "volume_bin": label,
                "N": len(subset),
                "min_gt_voxels": int(subset["target_gt_volume_preprocessed_voxels"].min()),
                "median_gt_voxels": float(subset["target_gt_volume_preprocessed_voxels"].median()),
                "max_gt_voxels": int(subset["target_gt_volume_preprocessed_voxels"].max()),
                "high_ratio_tail_count": int(subset["high_ratio_top20pct"].sum()),
                "median_g_C_norm": summary["median_g_C_norm"],
                "median_g_seg_norm": summary["median_g_seg_norm"],
                "median_ratio": summary["median_ratio"],
                "p90_ratio": summary["p90_ratio"],
            }
        )
    volume_summary = pd.DataFrame(volume_rows)
    volume_summary.to_csv(OUT / "volume_summary.tsv", sep="\t", index=False)

    lambda_rows = []
    raw_ratio = per_pair["gradient_ratio"].to_numpy(dtype=np.float64)
    for value in LAMBDAS:
        weighted = value * raw_ratio
        lambda_rows.append(
            {
                "lambda": value,
                "median": float(np.median(weighted)),
                "p75": float(np.quantile(weighted, 0.75)),
                "p90": float(np.quantile(weighted, 0.90)),
                "fraction_0p2_to_0p6": float(np.mean((weighted >= 0.2) & (weighted <= 0.6))),
                "fraction_gt_1": float(np.mean(weighted > 1.0)),
                "fraction_gt_2": float(np.mean(weighted > 2.0)),
                "fraction_gt_5": float(np.mean(weighted > 5.0)),
            }
        )
    lambda_summary = pd.DataFrame(lambda_rows)
    lambda_summary.to_csv(OUT / "lambda_simulation.tsv", sep="\t", index=False)

    high = per_pair[per_pair["high_ratio_top20pct"]].sort_values(
        "gradient_ratio", ascending=False
    )
    cohort_seg = float(per_pair["g_seg_norm"].median())
    cohort_c = float(per_pair["g_C_norm"].median())
    high_seg = float(high["g_seg_norm"].median())
    high_c = float(high["g_C_norm"].median())
    high_ratio = float(high["gradient_ratio"].median())
    high_small = int((high["volume_bin"] == "small").sum())
    high_c_count = int((high["pair_type"] == "C").sum())
    compatible = per_pair.loc[per_pair["hinge_active"].astype(bool), "gradient_cosine"].dropna()

    high_table = high[
        [
            "pair_index",
            "case_id",
            "pair_type",
            "g_C_norm",
            "g_seg_norm",
            "gradient_ratio",
            "gradient_cosine",
            "L_correct",
            "L_wrong",
            "D_wrong_minus_correct",
            "target_gt_volume_preprocessed_voxels",
        ]
    ]
    report = f"""# C-global 32-pair gradient forensics

Decision: **NEED_FURTHER_NORMALIZATION_AUDIT**

This is an offline analysis of the exact saved 32-pair gradient cohort. No pairs were resampled, no forward/backward was repeated, and no model weights were changed.

## Exact setup

- Checkpoint: `{gradient_audit['checkpoint']}`
- Pair count: `{len(per_pair)}`; exact replay identity verified: `YES`
- Margin: `{float(calibration['margin']):.9f}`
- Loss: `L_C = max(0, margin + L_correct - L_wrong)`, where both predictions use the same CT and target GT, and only the whole-finding prompt changes.
- Per-prompt segmentation loss: full-resolution `BCEWithLogits + category-adaptive Tversky`, using the target finding's category and the established category map.
- Main gradient group: `all_shared = transformer_decoder + decoder + project_to_decoder_channels`; `{parameter_groups['all_shared']['parameter_tensors']}` tensors / `{parameter_groups['all_shared']['parameters']}` parameters.
- GT volume below is the exact preprocessed-mask voxel count used to define the target; original-grid counts are also retained in `per_pair.tsv`.

## Primary diagnosis

The top 20% is the largest `{high_count}` ratios. Its median `||g_C||` is `{high_c:.6g}` versus cohort `{cohort_c:.6g}` (`{high_c / cohort_c:.2f}×`), while median `||g_seg||` is `{high_seg:.6g}` versus cohort `{cohort_seg:.6g}` (`{high_seg / cohort_seg:.3f}×`). All `{high_count}/{high_count}` tail pairs have below-median segmentation gradients; `{int((high['g_C_norm'] > cohort_c).sum())}/{high_count}` also have above-median C gradients.

Therefore:

- **H1 — unusually large C gradients:** YES for most tail pairs.
- **H2 — unusually small segmentation gradients:** YES for every tail pair.
- **H3:** the tail is caused by **both**, with tiny `g_seg` acting as the universal denominator problem and elevated `g_C` amplifying six of seven cases. The single largest ratio is not merely a huge C gradient: it combines `||g_seg||={float(high.iloc[0].g_seg_norm):.6g}` with `||g_C||={float(high.iloc[0].g_C_norm):.6g}`.

### Highest-ratio pairs

{markdown_table(high_table)}

## Pair-type summary

{markdown_table(type_summary)}

The tail is enriched for type C (`different pathology, different anatomy`): `{high_c_count}/{high_count}` tail pairs, compared with `{int((per_pair['pair_type'] == 'C').sum())}/{len(per_pair)}` overall. It is not exclusive to C: types A and B also enter the tail, and type A has a high p90. Pair selection alone therefore does not cleanly explain or remove the heterogeneity.

## Lesion-size relationship

{markdown_table(volume_summary)}

Small lesions are enriched but are not the sole cause: `{high_small}/{high_count}` tail pairs are in the small tertile, versus `{int((per_pair['volume_bin'] == 'small').sum())}/{len(per_pair)}` overall. Two large-tertile lesions also have extreme ratios. The more direct invariant is the small segmentation-gradient norm: every tail pair is below the cohort median.

## Static-lambda simulation

{markdown_table(lambda_summary)}

No tested static lambda simultaneously controls the tail and gives a useful central contribution. `lambda=0.10` lowers p90 to `{float(lambda_summary.iloc[0].p90):.3f}`, but its median is only `{float(lambda_summary.iloc[0]['median']):.3f}` and only `{float(lambda_summary.iloc[0].fraction_0p2_to_0p6):.1%}` fall in 0.2–0.6. `lambda=0.25` puts the median at `{float(lambda_summary.iloc[1]['median']):.3f}`, but p90 remains `{float(lambda_summary.iloc[1].p90):.3f}` and `{float(lambda_summary.iloc[1].fraction_gt_5):.1%}` exceed 5. Larger lambdas worsen the tail.

## Gradient direction

Among the `{len(compatible)}` hinge-active pairs, all-shared cosine has mean `{float(compatible.mean()):.6f}`, median `{float(compatible.median()):.6f}`, and `{float((compatible < 0).mean()):.1%}` negative. Direction is generally compatible with segmentation, so persistent directional conflict is not the principal failure.

## Answers and lowest-complexity next step

1. The p90 tail is caused by **both** elevated C gradients and tiny segmentation gradients; the small denominator is present in every top-tail pair.
2. It is enriched in pair type C, but not sufficiently specific to justify solving this only through negative-pair selection.
3. It is enriched in small lesions, but not confined to them.
4. Gradient direction is generally compatible with segmentation.
5. None of `0.10/0.25/0.50/1.00` produces a controlled central distribution and tail simultaneously.
6. Lowest-complexity decision: **NEED_FURTHER_NORMALIZATION_AUDIT**. This report does not implement normalization, clipping, adaptive weighting, pair redesign, or training.

## Provenance

- Saved gradients: `{SOURCE}`
- Exact pair identities/losses: `{CALIBRATION}`
- Structured pair metadata: `{PAIR_METADATA}`
- Preprocessed GT volume manifest: `{MANIFEST}`
- Runtime environment: `{sys.executable}`; pandas `{pd.__version__}`; NumPy `{np.__version__}`.
- Runtime for this forensics step: CPU-only; no Slurm/GPU job.
"""
    (OUT / "report.md").write_text(report)
    print(
        json.dumps(
            {
                "output": str(OUT),
                "pairs": len(per_pair),
                "high_tail_n": high_count,
                "decision": "NEED_FURTHER_NORMALIZATION_AUDIT",
                "reused_saved_gradients": True,
                "gpu_used": False,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
