#!/bin/bash
# Prepared only. Do not run without explicit matched-pair continuation approval.
set -euo pipefail
[[ ${ACK_CONTINUE_MATCHED_PAIR_TO_250:-NO} == YES ]] || {
  echo "Refusing submission without ACK_CONTINUE_MATCHED_PAIR_TO_250=YES" >&2; exit 2;
}
ROOT=.
GPU_TYPE=${GPU_TYPE:-h200}
PAIR_ROLE=treatment STAGE=continue250 OUTSIDE_MULTIPLIER=2 \
EXPERIMENT_ROOT=$ROOT/outputs/roi_aware_weighted_seg_v2strict_lowLR_outmult2_allcat1over1_step6000 \
ACK_CONTINUE_MATCHED_PAIR_TO_250=YES \
sbatch --gres=gpu:$GPU_TYPE:1 $ROOT/scripts/train_roi_aware_weighted_seg_v2strict.sbatch

