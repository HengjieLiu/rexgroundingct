#!/usr/bin/env python3
"""Construct strict-category predictions from adaptive and baseline channels."""

from __future__ import annotations

import argparse
import json
import tempfile
from pathlib import Path

import nibabel as nib
import numpy as np


def save_nifti_atomic(array: np.ndarray, source: nib.Nifti1Image, path: Path) -> None:
    header = source.header.copy()
    image = nib.Nifti1Image(array.astype(np.uint8, copy=False), source.affine, header)
    image.set_data_dtype(np.uint8)
    with tempfile.NamedTemporaryFile(
        prefix=f".{path.name}.", suffix=".nii.gz", dir=path.parent, delete=False
    ) as handle:
        temporary = Path(handle.name)
    try:
        nib.save(image, str(temporary))
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def link_prediction(source: Path, destination: Path) -> None:
    """Reuse an immutable source prediction without copying a large gzip file."""
    if destination.exists() or destination.is_symlink():
        destination.unlink()
    destination.symlink_to(source.resolve())


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-json", type=Path, required=True)
    parser.add_argument("--split", default="val")
    parser.add_argument("--baseline-dir", type=Path, required=True)
    parser.add_argument("--adaptive-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--categories", nargs="+", default=["2b", "2c"])
    parser.add_argument("--num-shards", type=int, default=1)
    parser.add_argument("--shard-id", type=int, default=0)
    parser.add_argument(
        "--case-manifest-json",
        type=Path,
        help="Optional JSON with a top-level cases list (for a fixed subset).",
    )
    parser.add_argument("--reuse-verification-json", type=Path)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    if args.num_shards < 1:
        raise ValueError("--num-shards must be positive")
    if not 0 <= args.shard_id < args.num_shards:
        raise ValueError("--shard-id must be in [0, num-shards)")
    if args.output_dir.exists() and any(args.output_dir.iterdir()) and not args.overwrite:
        raise FileExistsError(f"Refusing to overwrite non-empty: {args.output_dir}")
    if args.reuse_verification_json is not None:
        verification = json.loads(args.reuse_verification_json.read_text())
        if not verification.get("verified"):
            raise AssertionError(
                f"Reuse verification did not pass: {args.reuse_verification_json}"
            )

    dataset = json.loads(args.dataset_json.read_text())
    entries = dataset[args.split]
    if args.case_manifest_json is not None:
        selected_cases = set(
            json.loads(args.case_manifest_json.read_text())["cases"]
        )
        entries = [entry for entry in entries if entry["name"] in selected_cases]
        found_cases = {entry["name"] for entry in entries}
        if found_cases != selected_cases:
            raise ValueError(
                "Subset manifest contains cases absent from the selected dataset split: "
                f"{sorted(selected_cases - found_cases)}"
            )
    total_selected_cases = len(entries)
    entries = [
        entry
        for index, entry in enumerate(entries)
        if index % args.num_shards == args.shard_id
    ]
    wanted = {str(category) for category in args.categories}
    args.output_dir.mkdir(parents=True, exist_ok=True)

    case_records = []
    total_channels = 0
    replaced_channels = 0
    reused_baseline_channels = 0
    active_cases = 0
    linked_baseline_cases = 0
    linked_adaptive_cases = 0
    materialized_hybrid_cases = 0

    for entry in entries:
        name = str(entry["name"])
        finding_keys = sorted(entry["findings"], key=lambda value: int(value))
        active_keys = [
            key
            for key in finding_keys
            if str(entry["categories"].get(key)) in wanted
        ]
        baseline_path = args.baseline_dir / name
        adaptive_path = args.adaptive_dir / name
        output_path = args.output_dir / name
        if not baseline_path.is_file():
            raise FileNotFoundError(f"Missing baseline prediction: {baseline_path}")

        total_channels += len(finding_keys)
        replaced_channels += len(active_keys)
        reused_baseline_channels += len(finding_keys) - len(active_keys)
        if not active_keys:
            link_prediction(baseline_path, output_path)
            linked_baseline_cases += 1
            case_records.append(
                {
                    "name": name,
                    "active_finding_ids": [],
                    "adaptive_layout": None,
                    "non_target_max_abs_binary_difference_from_baseline": 0,
                    "target_max_abs_binary_difference_from_adaptive": 0,
                    "construction": "symlink_baseline_no_target_category",
                }
            )
            continue
        if not adaptive_path.is_file():
            raise FileNotFoundError(f"Missing adaptive prediction: {adaptive_path}")

        active_cases += 1
        baseline_image = nib.load(str(baseline_path))
        adaptive_image = nib.load(str(adaptive_path))
        if len(active_keys) == len(finding_keys):
            if adaptive_image.shape[0] != len(finding_keys):
                raise ValueError(
                    f"{adaptive_path}: all-target case must have "
                    f"{len(finding_keys)} channels, got {adaptive_image.shape[0]}"
                )
            link_prediction(adaptive_path, output_path)
            linked_adaptive_cases += 1
            case_records.append(
                {
                    "name": name,
                    "active_finding_ids": [int(key) for key in active_keys],
                    "adaptive_layout": "full_original_channels",
                    "non_target_max_abs_binary_difference_from_baseline": 0,
                    "target_max_abs_binary_difference_from_adaptive": 0,
                    "construction": "symlink_adaptive_all_channels_target_category",
                }
            )
            continue
        baseline = np.asanyarray(baseline_image.dataobj).astype(np.uint8, copy=False)
        adaptive = np.asanyarray(adaptive_image.dataobj).astype(np.uint8, copy=False)
        if baseline.ndim != 4 or baseline.shape[0] != len(finding_keys):
            raise ValueError(
                f"{baseline_path}: shape {baseline.shape} does not match "
                f"{len(finding_keys)} canonical findings"
            )
        if baseline.shape[1:] != adaptive.shape[1:]:
            raise ValueError(
                f"{name}: baseline/adaptive spatial mismatch "
                f"{baseline.shape[1:]} vs {adaptive.shape[1:]}"
            )

        original_indices = [int(key) for key in active_keys]
        if adaptive.shape[0] == baseline.shape[0]:
            adaptive_indices = original_indices
            adaptive_layout = "full_original_channels"
        elif adaptive.shape[0] == len(active_keys):
            adaptive_indices = list(range(len(active_keys)))
            adaptive_layout = "compressed_target_channels"
        else:
            raise ValueError(
                f"{adaptive_path}: channel count {adaptive.shape[0]} is neither "
                f"full ({baseline.shape[0]}) nor target-only ({len(active_keys)})"
            )

        hybrid = baseline.copy()
        for original_index, adaptive_index in zip(
            original_indices, adaptive_indices, strict=True
        ):
            hybrid[original_index] = adaptive[adaptive_index]
        inactive_indices = [
            int(key) for key in finding_keys if key not in set(active_keys)
        ]
        inactive_difference = (
            int(np.max(np.abs(
                hybrid[inactive_indices].astype(np.int8)
                - baseline[inactive_indices].astype(np.int8)
            )))
            if inactive_indices
            else 0
        )
        target_difference = int(
            max(
                np.max(np.abs(
                    hybrid[original_index].astype(np.int8)
                    - adaptive[adaptive_index].astype(np.int8)
                ))
                for original_index, adaptive_index in zip(
                    original_indices, adaptive_indices, strict=True
                )
            )
        )
        if inactive_difference != 0 or target_difference != 0:
            raise AssertionError(f"{name}: hybrid channel identity assertion failed")
        save_nifti_atomic(hybrid, baseline_image, output_path)
        materialized_hybrid_cases += 1
        case_records.append(
            {
                "name": name,
                "active_finding_ids": [int(key) for key in active_keys],
                "adaptive_layout": adaptive_layout,
                "non_target_max_abs_binary_difference_from_baseline": inactive_difference,
                "target_max_abs_binary_difference_from_adaptive": target_difference,
                "construction": "baseline_copy_with_target_channels_replaced",
            }
        )

    payload = {
        "policy": "strict_2b2c_prediction_reuse",
        "dataset_json": str(args.dataset_json.resolve()),
        "split": args.split,
        "num_shards": args.num_shards,
        "shard_id": args.shard_id,
        "total_selected_cases_before_sharding": total_selected_cases,
        "case_manifest_json": (
            None
            if args.case_manifest_json is None
            else str(args.case_manifest_json.resolve())
        ),
        "categories_using_adaptive_prediction": sorted(wanted),
        "baseline_dir": str(args.baseline_dir.resolve()),
        "adaptive_dir": str(args.adaptive_dir.resolve()),
        "output_dir": str(args.output_dir.resolve()),
        "reuse_verification_json": (
            None
            if args.reuse_verification_json is None
            else str(args.reuse_verification_json.resolve())
        ),
        "case_count": len(case_records),
        "active_case_count": active_cases,
        "symlinked_baseline_case_count": linked_baseline_cases,
        "symlinked_adaptive_case_count": linked_adaptive_cases,
        "materialized_mixed_hybrid_case_count": materialized_hybrid_cases,
        "total_finding_channels": total_channels,
        "adaptive_finding_channels": replaced_channels,
        "baseline_reused_finding_channels": reused_baseline_channels,
        "non_target_binary_identity": {
            "max_abs_difference": max(
                record["non_target_max_abs_binary_difference_from_baseline"]
                for record in case_records
            ),
            "changed_voxels": 0,
            "exact_by_construction": True,
        },
        "target_adaptive_binary_identity": {
            "max_abs_difference": max(
                record["target_max_abs_binary_difference_from_adaptive"]
                for record in case_records
            ),
            "changed_voxels": 0,
            "exact_by_construction": True,
        },
        "cases": case_records,
    }
    manifest_name = (
        "hybrid_manifest.json"
        if args.num_shards == 1
        else f"hybrid_manifest_shard_{args.shard_id:03d}.json"
    )
    (args.output_dir / manifest_name).write_text(
        json.dumps(payload, indent=2) + "\n"
    )
    print(json.dumps({key: value for key, value in payload.items() if key != "cases"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
