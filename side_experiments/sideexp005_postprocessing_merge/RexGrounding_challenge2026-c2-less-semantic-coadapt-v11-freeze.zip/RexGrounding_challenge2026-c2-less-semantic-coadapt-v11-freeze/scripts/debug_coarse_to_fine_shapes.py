#!/usr/bin/env python3
"""Debug one coarse-to-fine VoxTell batch and save quick overlays."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch


REX_ROOT = Path(__file__).resolve().parents[1]
VOXTELL_ROOT = REX_ROOT / "VoxTell"
if str(VOXTELL_ROOT) not in sys.path:
    sys.path.insert(0, str(VOXTELL_ROOT))
if str(REX_ROOT) not in sys.path:
    sys.path.insert(0, str(REX_ROOT))

from scripts.train_voxtell_coarse_to_fine import (  # noqa: E402
    coarse_to_fine_loss,
    instantiate_coarse_to_fine,
    make_samplers,
)
from scripts.train_voxtell_rex_full import load_embedding_map  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-mode", choices=["preprocessed", "raw"], default="preprocessed")
    parser.add_argument("--rex-json", type=Path, default=REX_ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--image-dir", type=Path, default=REX_ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--mask-dir", type=Path, default=REX_ROOT / "data/segmentations")
    parser.add_argument("--preprocessed-dir", type=Path, default=REX_ROOT / "data/rex_voxtell_preprocessed_v1")
    parser.add_argument("--model-dir", type=Path, default=REX_ROOT / "VoxTell/voxtell_v1.1")
    parser.add_argument("--highres-init-checkpoint", type=Path, default=None)
    parser.add_argument(
        "--embedding-cache",
        type=Path,
        default=REX_ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt",
    )
    parser.add_argument("--output-dir", type=Path, default=REX_ROOT / "outputs/coarse_to_fine_debug")
    parser.add_argument("--train-split", default="train")
    parser.add_argument("--val-split", default="val")
    parser.add_argument("--max-train-cases", type=int, default=2)
    parser.add_argument("--max-val-cases", type=int, default=2)
    parser.add_argument("--overfit-n", type=int, default=2)
    parser.add_argument("--patch-size", type=int, nargs=3, default=(192, 192, 192))
    parser.add_argument("--positive-prompts", type=int, default=2)
    parser.add_argument("--negative-prompts", type=int, default=1)
    parser.add_argument("--positive-loss-weight", type=float, default=1.0)
    parser.add_argument("--negative-loss-weight", type=float, default=1.0)
    parser.add_argument("--foreground-prob", type=float, default=0.85)
    parser.add_argument("--require-positive-crop", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--min-positive-voxels", type=int, default=1)
    parser.add_argument("--max-crop-attempts", type=int, default=50)
    parser.add_argument("--max-sample-attempts", type=int, default=50)
    parser.add_argument("--case-cache-size", type=int, default=4)
    parser.add_argument("--lowres-size", type=int, default=64)
    parser.add_argument("--lowres-base-channels", type=int, default=16)
    parser.add_argument("--lowres-branch", choices=["small_unet", "voxtell", "truncated_voxtell"], default="small_unet")
    parser.add_argument("--lowres-init-checkpoint", type=Path, default=None)
    parser.add_argument("--fusion-mode", choices=["input_concat_2ch", "adapter_2to1"], default="input_concat_2ch")
    parser.add_argument("--print-fusion-shapes", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--lambda-final", type=float, default=1.0)
    parser.add_argument("--lambda-lowres", type=float, default=0.3)
    parser.add_argument("--lambda-consistency", type=float, default=0.0)
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--amp", action=argparse.BooleanOptionalAction, default=True)
    return parser.parse_args()


def middle_slice(mask: torch.Tensor) -> int:
    coords = torch.nonzero(mask > 0.5)
    if coords.numel() == 0:
        return int(mask.shape[0] // 2)
    return int(coords[:, 0].float().mean().round().item())


def save_overlay(path: Path, image: torch.Tensor, gt: torch.Tensor, coarse: torch.Tensor, final: torch.Tensor) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    z = middle_slice(gt)
    fig, axes = plt.subplots(1, 4, figsize=(14, 4))
    panels = [
        ("CT", image[z]),
        ("GT", gt[z]),
        ("coarse_up", coarse[z]),
        ("final_prob", final[z]),
    ]
    for ax, (title, arr) in zip(axes, panels):
        ax.imshow(image[z].cpu(), cmap="gray")
        if title != "CT":
            ax.imshow(arr.detach().cpu(), cmap="magma", alpha=0.45, vmin=0, vmax=1)
        ax.set_title(title)
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def main() -> int:
    args = parse_args()
    if args.device == "cuda" and torch.cuda.is_available():
        torch.cuda.set_device(args.gpu)
        device = torch.device(f"cuda:{args.gpu}")
    else:
        device = torch.device("cpu")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    embedding_map = load_embedding_map(args.embedding_cache)
    train_sampler, _, _, _ = make_samplers(args, embedding_map)
    network = instantiate_coarse_to_fine(args, device)
    network.train()

    image, embeddings, target, prompt_weights, meta = train_sampler.sample()
    image = image[None].to(device)
    embeddings = embeddings[None].to(device)
    target = target[None].to(device)
    prompt_weights = prompt_weights[None].to(device)

    with torch.autocast(device.type, enabled=args.amp and device.type == "cuda"):
        outputs = network(image, text_embedding=embeddings)
        loss, stats = coarse_to_fine_loss(
            outputs,
            target,
            prompt_weights,
            args.lambda_final,
            args.lambda_lowres,
            args.lambda_consistency,
        )
    loss.backward()

    primary = outputs["logits"][0] if isinstance(outputs["logits"], list) else outputs["logits"]
    print(f"case: {meta['case']}")
    print(f"image: {tuple(image.shape)}")
    print(f"text_embedding: {tuple(embeddings.shape)}")
    print(f"target: {tuple(target.shape)}")
    print(f"lowres_logits: {tuple(outputs['lowres_logits'].shape)}")
    print(f"coarse_up: {tuple(outputs['coarse_up'].shape)}")
    print(f"final_logits: {tuple(primary.shape)}")
    print(f"finite outputs: {torch.isfinite(primary).all().item()} | finite loss: {torch.isfinite(loss).item()}")
    print(f"loss: {float(loss.detach().item()):.6f}")
    print(stats)

    save_overlay(
        args.output_dir / "debug_overlay_prompt0.png",
        image[0, 0].detach().cpu(),
        target[0, 0].detach().cpu(),
        outputs["coarse_up"][0, 0].detach().cpu(),
        torch.sigmoid(primary[0, 0]).detach().cpu(),
    )
    print(f"Saved overlay: {args.output_dir / 'debug_overlay_prompt0.png'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
