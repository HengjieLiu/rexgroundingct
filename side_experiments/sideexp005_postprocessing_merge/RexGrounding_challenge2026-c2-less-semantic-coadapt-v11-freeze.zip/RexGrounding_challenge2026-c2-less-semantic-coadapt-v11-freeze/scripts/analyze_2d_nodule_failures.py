#!/usr/bin/env python3
"""Analyze category 2d nodule/mass failure modes."""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Callable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def feature_patterns() -> dict[str, Callable[[str, pd.Series], bool]]:
    return {
        "tiny_lt100_vox": lambda s, r: r["pixels"] < 100,
        "small_100_1k_vox": lambda s, r: 100 <= r["pixels"] < 1000,
        "medium_1k_10k_vox": lambda s, r: 1000 <= r["pixels"] < 10000,
        "subcentimeter_or_mm": lambda s, r: bool(
            re.search(r"subcentimeter|sub-centimeter|millimetric|few millimeter|\b\d+(?:\.\d+)?\s*mm\b", s)
        ),
        "explicit_2_3mm": lambda s, r: bool(re.search(r"\b[23](?:\.\d+)?\s*mm\b", s)),
        "explicit_4_5mm": lambda s, r: bool(re.search(r"\b[45](?:\.\d+)?\s*mm\b", s)),
        "multiple_or_bilateral": lambda s, r: bool(
            re.search(r"multiple|several|few|both lungs|bilateral|bilaterally|scattered", s)
        ),
        "calcified": lambda s, r: bool(re.search(r"calcif", s)),
        "indeterminate_nonspecific": lambda s, r: bool(re.search(r"indeterminate|nonspecific|non-specific", s)),
        "subpleural_or_fissural": lambda s, r: bool(
            re.search(r"subpleural|pleural[- ]?based|perifissural|fissure|fissural", s)
        ),
        "ground_glass_halo": lambda s, r: bool(re.search(r"ground[- ]glass|ground glass|halo", s)),
        "consolidation_like": lambda s, r: bool(re.search(r"consolid", s)),
        "mass": lambda s, r: bool(re.search(r"\bmass\b|masses", s)),
        "cyst_or_bleb": lambda s, r: bool(re.search(r"\bcyst\b|bleb", s)),
    }


def summarize(df: pd.DataFrame, group_col: str) -> pd.DataFrame:
    return (
        df.groupby(group_col, observed=True)
        .agg(
            n=("case", "size"),
            misses=("miss", "sum"),
            miss_rate=("miss", "mean"),
            mean_dice=("global_dice", "mean"),
            median_dice=("global_dice", "median"),
            mean_pixels=("pixels", "mean"),
        )
        .reset_index()
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--analysis-dir", type=Path, default=Path("outputs/analysis_prompt_embedding_failures_aug_step500"))
    parser.add_argument("--out-dir", type=Path, default=None)
    args = parser.parse_args()

    out_dir = args.out_dir or args.analysis_dir / "2d_nodule_failure_analysis"
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.analysis_dir / "per_finding_current_best.csv")
    sub = df[df["category"] == "2d"].copy()

    sub.to_csv(out_dir / "category_2d_findings.csv", index=False)
    size_summary = summarize(sub, "size_bin").sort_values("miss_rate", ascending=False)
    keyword_summary = summarize(sub, "keyword_group").sort_values("miss_rate", ascending=False)
    size_summary.to_csv(out_dir / "size_summary_2d.csv", index=False)
    keyword_summary.to_csv(out_dir / "keyword_summary_2d.csv", index=False)

    rows = []
    patterns = feature_patterns()
    feature_table = []
    for _, row in sub.iterrows():
        text = str(row["prompt"]).lower()
        flags = {name: func(text, row) for name, func in patterns.items()}
        feature_table.append({**row.to_dict(), **flags})
    feature_df = pd.DataFrame(feature_table)
    feature_df.to_csv(out_dir / "feature_flags_2d.csv", index=False)
    for name in patterns:
        d = feature_df[feature_df[name]]
        if len(d) == 0:
            continue
        rows.append(
            {
                "feature": name,
                "n": len(d),
                "misses": int(d["miss"].sum()),
                "miss_rate": float(d["miss"].mean()),
                "mean_dice": float(d["global_dice"].mean()),
                "median_dice": float(d["global_dice"].median()),
                "mean_pixels": float(d["pixels"].mean()),
            }
        )
    feature_summary = pd.DataFrame(rows).sort_values(["miss_rate", "n"], ascending=[False, False])
    feature_summary.to_csv(out_dir / "feature_summary_2d.csv", index=False)

    worst_cols = ["case", "finding_idx", "pixels", "global_dice", "keyword_group", "size_bin", "prompt"]
    sub.sort_values("global_dice").head(40)[worst_cols].to_csv(out_dir / "worst_40_2d.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5), constrained_layout=True)
    size_order = ["<100", "100-1k", "1k-10k", "10k-100k", ">=100k"]
    s = size_summary.set_index("size_bin").reindex([x for x in size_order if x in set(size_summary["size_bin"])])
    axes[0].barh(s.index[::-1], s["miss_rate"][::-1], color="#c96b70")
    axes[0].set_xlabel("Miss rate, Dice <= 0.1")
    axes[0].set_title("2d Failure Rate By Mask Size")
    axes[0].grid(axis="x")
    for y, (_, row) in enumerate(s.iloc[::-1].iterrows()):
        axes[0].text(0.01, y, f"{int(row.misses)}/{int(row.n)}", va="center", color="white", fontsize=9)
        axes[0].text(row.miss_rate + 0.015, y, f"{row.miss_rate:.2f}", va="center", fontsize=9)

    f = feature_summary[feature_summary["n"] >= 3].sort_values("miss_rate", ascending=True).tail(10)
    axes[1].barh(f["feature"], f["miss_rate"], color="#c96b70")
    axes[1].set_xlabel("Miss rate, Dice <= 0.1")
    axes[1].set_title("2d Failure Rate By Nodule Feature")
    axes[1].grid(axis="x")
    for y, (_, row) in enumerate(f.iterrows()):
        axes[1].text(0.01, y, f"{int(row.misses)}/{int(row.n)}", va="center", color="white", fontsize=9)
        axes[1].text(row.miss_rate + 0.015, y, f"{row.miss_rate:.2f}", va="center", fontsize=9)
    fig.savefig(out_dir / "2d_nodule_failure_summary.png", dpi=200, bbox_inches="tight")
    plt.close(fig)

    lines = [
        "# Category 2d Nodule/Mass Failure Analysis",
        "",
        f"Total 2d findings: {len(sub)}",
        f"Misses (Dice <= 0.1): {int(sub['miss'].sum())}",
        f"Miss rate: {sub['miss'].mean():.3f}",
        f"Mean Dice: {sub['global_dice'].mean():.3f}",
        "",
        "## Main Readout",
        "",
        "- The dominant failure mode is small/tiny nodules, especially masks with fewer than 100 voxels.",
        "- Multiple/bilateral subcentimeter nodules are also harder, likely because the prompt is broad while individual annotated masks are small.",
        "- Calcified nodules are not uniquely worse after size normalization; many failures are still driven by tiny mask size.",
        "- Larger or mixed opacity/nodular findings tend to have better Dice, but sample sizes are small.",
        "",
        "## Files",
        "",
        "- `category_2d_findings.csv`: all 2d findings.",
        "- `size_summary_2d.csv`: performance by mask-size bin.",
        "- `keyword_summary_2d.csv`: performance by keyword group within 2d.",
        "- `feature_summary_2d.csv`: rule-based nodule feature summary.",
        "- `worst_40_2d.csv`: worst 40 2d findings by Dice.",
        "- `2d_nodule_failure_summary.png`: summary figure.",
    ]
    (out_dir / "README.md").write_text("\n".join(lines) + "\n")
    print(f"Wrote 2d analysis to {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
