#!/usr/bin/env python
"""Audit the production Anchor85 crop sampler with 70% HNT-style negatives."""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import torch


REX_ROOT = Path(__file__).resolve().parents[1]
if str(REX_ROOT) not in sys.path:
    sys.path.insert(0, str(REX_ROOT))

from scripts.audit_hard_negative_spatial_empty_sampler import (  # noqa: E402
    MODE_NUM_ITEMS,
    MaskOnlyAuditSampler,
    audit_loader,
    dataloader_smoke,
    voxel_stats,
)
from scripts.train_voxtell_rex_full_nnunet_aug import (  # noqa: E402
    build_case_records,
    load_manifest,
)


INSTANCE_TYPES = (
    "positive_foreground",
    "same_prompt_crop_empty",
    "hard_semantic_negative",
    "cross_case_real_finding_negative",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--preprocessed-dir",
        type=Path,
        default=REX_ROOT / "data/rex_voxtell_preprocessed_v1",
    )
    parser.add_argument("--split", default="train")
    parser.add_argument("--mode", choices=tuple(MODE_NUM_ITEMS), default="fast")
    parser.add_argument("--num-items", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--hard-negative-prob", type=float, default=0.70)
    parser.add_argument(
        "--sampler-mode",
        choices=[
            "anchor85_hardneg70",
            "anchor85_hardneg70_category_balanced_aggressive",
        ],
        default="anchor85_hardneg70",
    )
    parser.add_argument("--category-balance-lambda", type=float, default=0.60)
    parser.add_argument("--category-balance-alpha", type=float, default=0.25)
    parser.add_argument("--category-balance-tau", type=float, default=5.0)
    parser.add_argument("--patch-size", type=int, nargs=3, default=(192, 192, 192))
    parser.add_argument("--max-crop-attempts", type=int, default=50)
    parser.add_argument("--max-sample-attempts", type=int, default=50)
    parser.add_argument("--cache-size", type=int, default=1)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REX_ROOT / "outputs/sampler_audits/anchor85_hardneg70_fast500",
    )
    return parser.parse_args()


def make_sampler(args: argparse.Namespace):
    cases = build_case_records(load_manifest(args.preprocessed_dir), args.split, None)
    finding_lookup = {
        (finding["case"], int(finding["finding_idx"])): finding
        for case in cases
        for finding in case["findings"]
    }
    dummy_embedding = torch.zeros(1, dtype=torch.float32)
    embeddings = {
        (finding["split"], finding["case"], int(finding["finding_idx"])): dummy_embedding
        for finding in finding_lookup.values()
    }
    sampler = MaskOnlyAuditSampler(
        preprocessed_dir=args.preprocessed_dir,
        cases=cases,
        embedding_map=embeddings,
        patch_size=tuple(args.patch_size),
        positive_prompts=2,
        negative_prompts=1,
        positive_loss_weight=1.0,
        negative_loss_weight=1.0,
        foreground_prob=0.85,
        require_positive_crop=True,
        min_positive_voxels=1,
        max_crop_attempts=args.max_crop_attempts,
        max_sample_attempts=args.max_sample_attempts,
        cache_size=args.cache_size,
        augmenter=None,
        hard_negative_sampler=False,
        hard_negative_match="category_then_keyword",
        hard_negative_exclude_identical_prompt=True,
        sampler_mode=args.sampler_mode,
        anchor_positive_prob=0.85,
        same_case_negative_prob=0.15,
        shuffle_prompt_order=True,
        cross_case_negative_requires_foreground=True,
        anchor_hard_negative_prob=args.hard_negative_prob,
        category_balance_lambda=args.category_balance_lambda,
        category_balance_alpha=args.category_balance_alpha,
        category_balance_tau=args.category_balance_tau,
    )
    return sampler, finding_lookup


def main() -> int:
    args = parse_args()
    args.num_items = MODE_NUM_ITEMS[args.mode] if args.num_items is None else args.num_items
    if args.num_items <= 0 or args.num_workers < 0:
        raise ValueError("--num-items must be positive and --num-workers non-negative")
    if not 0 <= args.hard_negative_prob <= 1:
        raise ValueError("--hard-negative-prob must be in [0, 1]")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    sampler, lookup = make_sampler(args)
    smoke = dataloader_smoke(sampler, tuple(args.patch_size))
    loader = audit_loader(sampler, args.num_items, args.num_workers, args.seed)

    branches: Counter[str] = Counter()
    types: Counter[str] = Counter()
    positions: dict[str, Counter[int]] = defaultdict(Counter)
    target_voxels: dict[str, list[int]] = defaultdict(list)
    hard_reasons: Counter[str] = Counter()
    anchor_categories: Counter[str] = Counter()
    positive_categories: Counter[str] = Counter()
    positive_keyword_groups: Counter[str] = Counter()
    violations: Counter[str] = Counter()
    rows = []
    all_empty = 0
    fewer_than_two_positive = 0
    hard_requested = 0
    hard_fallback = 0
    direct_cross_case = 0
    valid_cross_case = 0
    cross_case_total = 0

    for item_index, meta in enumerate(loader):
        branch = str(meta.get("branch_type", "missing"))
        branches[branch] += 1
        anchor_categories[str(meta.get("anchor_category") or "unknown")] += 1
        instances = meta.get("prompt_instances", [])
        if len(instances) != 3:
            violations["prompt_count_not_three"] += 1
            continue
        if not any(int(item["target_voxel_count"]) > 0 for item in instances):
            all_empty += 1
        positive_count = sum(item["prompt_instance_type"] == "positive_foreground" for item in instances)
        fewer_than_two_positive += int(positive_count < 2)
        hard_requested += int(bool(meta.get("hard_negative_requested")))
        hard_fallback += int(bool(meta.get("hard_negative_fallback")))
        direct_cross_case += int(not bool(meta.get("hard_negative_requested")))
        current_prompts = {
            item["prompt_text"]
            for item in instances
            if item["prompt_source_case_id"] == meta["case"]
        }

        for instance in instances:
            instance_type = str(instance.get("prompt_instance_type", "missing"))
            position = int(instance["prompt_position"])
            voxels = int(instance["target_voxel_count"])
            source_case = str(instance["prompt_source_case_id"])
            finding_id = int(instance["prompt_finding_id"])
            source = lookup.get((source_case, finding_id))
            source_fg = None if source is None else source.get("source_foreground_voxels")
            source_category = "unknown" if source is None else str(source.get("category") or "unknown")
            source_keyword = "unknown" if source is None else str(source.get("keyword_group") or "unknown")
            types[instance_type] += 1
            positions[instance_type][position] += 1
            target_voxels[instance_type].append(voxels)

            if instance_type not in INSTANCE_TYPES:
                violations["unexpected_prompt_instance_type"] += 1
            if source is None or source["prompt"] != instance["prompt_text"]:
                violations[f"{instance_type}:prompt_source_mismatch"] += 1
            if source_fg is None or int(source_fg) <= 0:
                violations[f"{instance_type}:source_mask_empty"] += 1
            if instance_type == "positive_foreground" and voxels <= 0:
                violations["positive_foreground:empty_target"] += 1
            if instance_type == "positive_foreground":
                positive_categories[source_category] += 1
                positive_keyword_groups[source_keyword] += 1
            if instance_type == "same_prompt_crop_empty":
                if source_case != meta["case"] or voxels != 0:
                    violations["same_prompt_crop_empty:invalid"] += 1
            if instance_type in {"hard_semantic_negative", "cross_case_real_finding_negative"}:
                cross_case_total += 1
                valid = source_case != meta["case"] and voxels == 0 and source_fg is not None and int(source_fg) > 0
                valid_cross_case += int(valid)
                if not valid:
                    violations[f"{instance_type}:invalid_cross_case_empty_target"] += 1
                if instance["prompt_text"] in current_prompts:
                    violations[f"{instance_type}:identical_current_case_prompt"] += 1
            if instance_type == "hard_semantic_negative":
                reason = str(instance.get("hard_negative_match_reason") or "missing")
                hard_reasons[reason] += 1
                if reason not in {"same_category", "keyword_match"}:
                    violations["hard_semantic_negative:invalid_match_reason"] += 1

            rows.append(
                {
                    "item_index": item_index,
                    "branch_type": branch,
                    "prompt_position": position,
                    "prompt_instance_type": instance_type,
                    "case_id": meta["case"],
                    "prompt_source_case_id": source_case,
                    "prompt_finding_id": finding_id,
                    "prompt_text": instance["prompt_text"],
                    "target_voxel_count": voxels,
                    "source_foreground_voxels": source_fg,
                    "source_category": source_category,
                    "source_keyword_group": source_keyword,
                    "hard_negative_requested": int(bool(meta.get("hard_negative_requested"))),
                    "hard_negative_match_reason": instance.get("hard_negative_match_reason"),
                    "hard_negative_fallback": int(bool(meta.get("hard_negative_fallback"))),
                }
            )

    total_instances = sum(types.values())
    total_positive = sum(positive_categories.values())
    audited_items = sum(branches.values())
    anchor_category_fractions = {
        key: value / max(1, audited_items) for key, value in sorted(anchor_categories.items())
    }
    positive_category_fractions = {
        key: value / max(1, total_positive) for key, value in sorted(positive_categories.items())
    }
    positive_keyword_fractions = {
        key: value / max(1, total_positive) for key, value in sorted(positive_keyword_groups.items())
    }
    summary = {
        "sampler_mode": sampler.sampler_mode,
        "mode": args.mode,
        "requested_items": args.num_items,
        "audited_items": audited_items,
        "num_workers": args.num_workers,
        "seed": args.seed,
        "configured_hard_negative_probability": args.hard_negative_prob,
        "category_balance": {
            "lambda": args.category_balance_lambda,
            "alpha": args.category_balance_alpha,
            "tau": args.category_balance_tau,
            "natural_distribution": dict(sorted(sampler.category_natural_distribution.items())),
            "balanced_distribution": dict(sorted(sampler.category_balanced_distribution.items())),
            "mixed_distribution": dict(sorted(sampler.category_mixed_distribution.items())),
            "sampled_anchor_counts": dict(sorted(anchor_categories.items())),
            "sampled_anchor_distribution": anchor_category_fractions,
            "positive_prompt_counts": dict(sorted(positive_categories.items())),
            "positive_prompt_distribution": positive_category_fractions,
            "positive_keyword_counts": dict(sorted(positive_keyword_groups.items())),
            "positive_keyword_distribution": positive_keyword_fractions,
            "positive_2b_2c_fraction": (
                positive_categories["2b"] + positive_categories["2c"]
            ) / max(1, total_positive),
            "positive_2d_fraction": positive_categories["2d"] / max(1, total_positive),
            "positive_nodule_fraction": positive_keyword_groups["nodule"] / max(1, total_positive),
        },
        "dataloader_smoke": smoke,
        "branch_counts": dict(sorted(branches.items())),
        "branch_fractions": {k: v / args.num_items for k, v in sorted(branches.items())},
        "prompt_instance_counts": dict(sorted(types.items())),
        "prompt_instance_fractions": {k: v / total_instances for k, v in sorted(types.items())},
        "positive_target_voxel_stats": voxel_stats(target_voxels["positive_foreground"]),
        "target_voxel_stats_by_type": {k: voxel_stats(target_voxels[k]) for k in INSTANCE_TYPES},
        "prompt_position_distribution": {
            k: {str(p): n for p, n in sorted(positions[k].items())} for k in INSTANCE_TYPES
        },
        "hard_negative_match_reasons": dict(sorted(hard_reasons.items())),
        "hard_negative_selection": {
            "requested": hard_requested,
            "matched": types["hard_semantic_negative"],
            "fallback_to_cross_case": hard_fallback,
            "fallback_rate_given_requested": hard_fallback / max(1, hard_requested),
            "direct_cross_case": direct_cross_case,
        },
        "cross_case_negative_validity": {
            "valid": valid_cross_case,
            "total": cross_case_total,
            "fraction": valid_cross_case / max(1, cross_case_total),
        },
        "missing_second_positive": {
            "count": fewer_than_two_positive,
            "fraction": fewer_than_two_positive / args.num_items,
        },
        "all_empty_items": {"count": all_empty, "fraction": all_empty / args.num_items},
        "violations": dict(sorted(violations.items())),
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (args.output_dir / "prompt_instances.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    report = [
        f"{sampler.sampler_mode} sampler audit",
        f"items: {args.num_items}",
        f"branches: {dict(sorted(branches.items()))}",
        f"prompt_instance_types: {dict(sorted(types.items()))}",
        f"positive_target_voxels: {voxel_stats(target_voxels['positive_foreground'])}",
        f"hard_negative_match_reasons: {dict(sorted(hard_reasons.items()))}",
        f"natural_category_distribution: {dict(sorted(sampler.category_natural_distribution.items()))}",
        f"balanced_category_distribution: {dict(sorted(sampler.category_balanced_distribution.items()))}",
        f"mixed_category_distribution: {dict(sorted(sampler.category_mixed_distribution.items()))}",
        f"sampled_anchor_category_distribution: {anchor_category_fractions}",
        f"positive_prompt_category_distribution: {positive_category_fractions}",
        f"positive_2b_2c_fraction: {summary['category_balance']['positive_2b_2c_fraction']:.4%}",
        f"positive_2d_fraction: {summary['category_balance']['positive_2d_fraction']:.4%}",
        f"positive_nodule_fraction: {summary['category_balance']['positive_nodule_fraction']:.4%}",
        f"hard_negative_requested: {hard_requested}",
        f"hard_negative_fallbacks: {hard_fallback} ({hard_fallback / max(1, hard_requested):.4%})",
        f"direct_cross_case: {direct_cross_case}",
        f"cross_case_validity: {valid_cross_case}/{cross_case_total}",
        f"prompt_positions: {summary['prompt_position_distribution']}",
        f"missing_second_positive: {fewer_than_two_positive}/{args.num_items}",
        f"all_empty_items: {all_empty}/{args.num_items}",
        f"violations: {dict(sorted(violations.items()))}",
    ]
    (args.output_dir / "report.txt").write_text("\n".join(report) + "\n")
    print("\n".join(report))
    return 0 if not violations else 2


if __name__ == "__main__":
    raise SystemExit(main())
