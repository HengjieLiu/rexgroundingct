#!/usr/bin/env python3
"""Assert that two 12-micro-step smoke histories have identical sample streams."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


FIELDS = (
    "case",
    "positive_indices",
    "negative_cases",
    "negative_indices",
    "negative_source",
    "crop_bbox",
    "roles_after_shuffle",
    "final_prompt_order",
    "target_voxels",
    "crop_level_nonempty_targets",
    "crop_level_empty_targets",
)


def records(path: Path) -> list[dict]:
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    return [row for row in rows if int(row.get("micro_step", 0)) > 0]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("baseline", type=Path)
    parser.add_argument("s3", type=Path)
    args = parser.parse_args()
    left, right = records(args.baseline), records(args.s3)
    if len(left) != 12 or len(right) != 12:
        raise AssertionError(f"Expected 12 micro-steps per branch, got {len(left)} and {len(right)}")
    mismatches = []
    for index, (a, b) in enumerate(zip(left, right), start=1):
        for field in FIELDS:
            if a.get(field) != b.get(field):
                mismatches.append(
                    {"micro_step": index, "field": field, "baseline": a.get(field), "s3": b.get(field)}
                )
    if mismatches:
        raise AssertionError(json.dumps(mismatches, indent=2))
    result = {
        "micro_steps_compared": 12,
        "optimizer_updates_compared": 3,
        "fields": FIELDS,
        "match": True,
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
