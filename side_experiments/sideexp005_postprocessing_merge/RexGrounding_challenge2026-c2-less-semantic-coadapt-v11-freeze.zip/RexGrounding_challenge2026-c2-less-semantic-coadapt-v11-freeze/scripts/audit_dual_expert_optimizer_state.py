#!/usr/bin/env python3
"""CPU-only audit of the no-attention update-8000 optimizer/scheduler state."""

from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch


REPO_ROOT = Path(__file__).resolve().parents[1]
LINEAGE_DIR = REPO_ROOT / "outputs/voxtell_v11_e1e-5_d1e-4_1gpu_bs1_acc4_10kupd"
TARGET_CHECKPOINT = LINEAGE_DIR / "checkpoints/checkpoint_update_8000.pth"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "outputs/dual_expert_optimizer_state_audit"
TRAINING_SCRIPT = REPO_ROOT / "scripts/train_voxtell_rex_full_nnunet_aug.py"
PROPOSED_LRS = {"encoder": 1e-5, "decoder": 1e-4}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, default=TARGET_CHECKPOINT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--threads", type=int, default=2)
    return parser.parse_args()


def json_dump(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True, default=str) + "\n")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(16 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def load_checkpoint(path: Path) -> dict[str, Any]:
    return torch.load(path, map_location="cpu", weights_only=False, mmap=True)


def optimizer_name(optimizer: dict[str, Any]) -> str:
    groups = optimizer.get("param_groups", [])
    state_values = list(optimizer.get("state", {}).values())
    if groups and all("betas" in group for group in groups):
        return "AdamW" if any(float(group.get("weight_decay", 0.0)) > 0 for group in groups) else "Adam"
    if groups and any("momentum" in group for group in groups):
        return "SGD"
    if state_values and any("momentum_buffer" in state for state in state_values):
        return "SGD"
    return "unknown"


def group_lrs(path: Path) -> dict[str, Any]:
    checkpoint = load_checkpoint(path)
    optimizer = checkpoint.get("optimizer")
    result = {
        "checkpoint": str(path.resolve()),
        "optimizer_update": int(checkpoint.get("optimizer_update", -1)),
        "scheduler": checkpoint.get("scheduler"),
        "optimizer_present": optimizer is not None,
        "group_lrs": {},
    }
    if optimizer:
        result["group_lrs"] = {
            str(group.get("name", index)): {
                "lr": float(group["lr"]),
                "base_lr": float(group.get("base_lr", group["lr"])),
                "parameter_tensor_count": len(group.get("params", [])),
                "parameter_state_entries_present": sum(
                    parameter_id in optimizer.get("state", {})
                    for parameter_id in group.get("params", [])
                ),
            }
            for index, group in enumerate(optimizer.get("param_groups", []))
        }
    del checkpoint
    gc.collect()
    return result


def resolve_parameter_names(
    saved_args: dict[str, Any], optimizer: dict[str, Any]
) -> tuple[dict[Any, str], dict[Any, int]]:
    """Recreate the base architecture to map serialized optimizer IDs to module names."""
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    scripts_dir = REPO_ROOT / "scripts"
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))
    from train_voxtell_rex_full_nnunet_aug import instantiate_voxtell

    model = instantiate_voxtell(
        Path(saved_args["model_dir"]),
        torch.device("cpu"),
        deep_supervision=True,
    )
    named_parameters = list(model.named_parameters())
    expected_groups = {
        "encoder": [(name, parameter) for name, parameter in named_parameters if name.startswith("encoder.")],
        "decoder": [(name, parameter) for name, parameter in named_parameters if not name.startswith("encoder.")],
    }
    name_by_id: dict[Any, str] = {}
    numel_by_id: dict[Any, int] = {}
    for index, group in enumerate(optimizer.get("param_groups", [])):
        group_name = str(group.get("name", index))
        serialized_ids = list(group.get("params", []))
        model_parameters = expected_groups.get(group_name)
        if model_parameters is None or len(serialized_ids) != len(model_parameters):
            raise RuntimeError(
                f"Could not map optimizer group {group_name}: serialized={len(serialized_ids)}, "
                f"model={None if model_parameters is None else len(model_parameters)}"
            )
        for parameter_id, (name, parameter) in zip(serialized_ids, model_parameters, strict=True):
            name_by_id[parameter_id] = name
            numel_by_id[parameter_id] = int(parameter.numel())
            momentum = optimizer.get("state", {}).get(parameter_id, {}).get("momentum_buffer")
            if momentum is not None and tuple(momentum.shape) != tuple(parameter.shape):
                raise RuntimeError(
                    f"Optimizer/model shape mismatch for {name}: {tuple(momentum.shape)} != {tuple(parameter.shape)}"
                )
    del model
    gc.collect()
    return name_by_id, numel_by_id


def poly_factor(update: int, total: int, warmup: int, power: float, minimum: float) -> float:
    if warmup > 0 and update <= warmup:
        factor = update / warmup
    else:
        progress = (update - warmup) / max(1, total - warmup)
        factor = (1.0 - min(progress, 1.0)) ** power
    return max(float(minimum), float(factor))


def momentum_statistics(state: dict[Any, dict[str, Any]], parameter_ids: list[Any]) -> dict[str, Any]:
    buffer_count = 0
    missing_buffer_count = 0
    buffer_elements = 0
    tensor_state_count = 0
    state_entry_count = 0
    state_step_values: list[float] = []
    sum_values = 0.0
    sum_squared_l2 = 0.0
    minimum = math.inf
    maximum = -math.inf
    max_absolute = 0.0
    all_finite = True

    for parameter_id in parameter_ids:
        parameter_state = state.get(parameter_id, {})
        if parameter_state:
            state_entry_count += 1
        for key, value in parameter_state.items():
            if torch.is_tensor(value):
                tensor_state_count += 1
            if key == "step":
                state_step_values.append(float(value.item() if torch.is_tensor(value) else value))
        buffer = parameter_state.get("momentum_buffer")
        if buffer is None:
            missing_buffer_count += 1
            continue
        buffer = buffer.detach()
        buffer_count += 1
        count = int(buffer.numel())
        buffer_elements += count
        if count == 0:
            continue
        current_sum = float(torch.sum(buffer, dtype=torch.float64).item())
        current_norm = float(torch.linalg.vector_norm(buffer).item())
        current_min = float(torch.amin(buffer).item())
        current_max = float(torch.amax(buffer).item())
        current_abs = max(abs(current_min), abs(current_max))
        finite = all(math.isfinite(value) for value in (current_sum, current_norm, current_min, current_max))
        all_finite = all_finite and finite
        sum_values += current_sum
        sum_squared_l2 += current_norm * current_norm
        minimum = min(minimum, current_min)
        maximum = max(maximum, current_max)
        max_absolute = max(max_absolute, current_abs)

    total_l2 = math.sqrt(sum_squared_l2)
    mean = sum_values / buffer_elements if buffer_elements else None
    rms = total_l2 / math.sqrt(buffer_elements) if buffer_elements else None
    return {
        "parameter_state_entries_present": state_entry_count,
        "state_tensor_count": tensor_state_count,
        "momentum_buffers_present": buffer_count,
        "momentum_buffers_missing": missing_buffer_count,
        "momentum_buffer_elements": buffer_elements,
        "momentum_all_finite": all_finite,
        "momentum_mean": mean,
        "momentum_rms": rms,
        "momentum_l2": total_l2,
        "momentum_min": minimum if buffer_elements else None,
        "momentum_max": maximum if buffer_elements else None,
        "momentum_max_abs": max_absolute if buffer_elements else None,
        "step_state_present": bool(state_step_values),
        "step_state_min": min(state_step_values) if state_step_values else None,
        "step_state_max": max(state_step_values) if state_step_values else None,
    }


def top_level_modules(network_weights: dict[str, Any], group_name: str) -> list[str]:
    names: set[str] = set()
    for key in network_weights:
        is_encoder = key.startswith("encoder.")
        if (group_name == "encoder" and not is_encoder) or (group_name == "decoder" and is_encoder):
            continue
        if group_name not in {"encoder", "decoder"}:
            continue
        names.add(key.split(".", 1)[0])
    return sorted(names)


def main() -> int:
    args = parse_args()
    torch.set_num_threads(max(1, args.threads))
    checkpoint_path = args.checkpoint.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if not checkpoint_path.is_file():
        raise FileNotFoundError(checkpoint_path)

    sanity: dict[int, dict[str, Any]] = {}
    for update in (6000, 9000, 10000):
        path = checkpoint_path.parent / f"checkpoint_update_{update}.pth"
        if path.is_file():
            sanity[update] = group_lrs(path)

    checkpoint = load_checkpoint(checkpoint_path)
    optimizer = checkpoint.get("optimizer")
    scheduler = checkpoint.get("scheduler")
    if optimizer is None or scheduler is None:
        raise RuntimeError("Target checkpoint is missing optimizer or scheduler state")

    saved_args = checkpoint.get("args", {})
    optimizer_update = int(checkpoint.get("optimizer_update", -1))
    if optimizer_update != 8000:
        raise RuntimeError(f"Expected optimizer update 8000, found {optimizer_update}")
    attention_flags = {
        key: saved_args.get(key)
        for key in (
            "enable_prompt_spatial_attention",
            "enable_s2_attention",
            "enable_s3_voxel_text_matching_attention",
            "enable_dual_s3_voxel_text_matching_attention",
        )
    }
    if any(value is True for value in attention_flags.values()):
        raise RuntimeError(f"Target checkpoint is not no-attention: {attention_flags}")

    optimizer_type = optimizer_name(optimizer)
    state = optimizer.get("state", {})
    network_weights = checkpoint.get("network_weights", {})
    name_by_id, numel_by_id = resolve_parameter_names(saved_args, optimizer)
    group_rows: list[dict[str, Any]] = []
    group_details: list[dict[str, Any]] = []
    for index, group in enumerate(optimizer.get("param_groups", [])):
        name = str(group.get("name", index))
        parameter_ids = list(group.get("params", []))
        stats = momentum_statistics(state, parameter_ids)
        missing_state_ids = [parameter_id for parameter_id in parameter_ids if parameter_id not in state]
        missing_state_names = [name_by_id[parameter_id] for parameter_id in missing_state_ids]
        missing_state_numel = sum(numel_by_id[parameter_id] for parameter_id in missing_state_ids)
        current_lr = float(group["lr"])
        base_lr = float(group.get("base_lr", current_lr))
        proposed_lr = PROPOSED_LRS.get(name)
        modules = top_level_modules(network_weights, name)
        if name == "decoder" and "project_to_decoder_channels" not in modules:
            raise RuntimeError("Could not resolve segmentation head inside decoder group")
        detail = {
            "group_index": index,
            "group_name": name,
            "resolved_top_level_modules": modules,
            "resolved_module_scope": (
                "encoder.*" if name == "encoder" else
                "all trainable non-encoder shared modules, including decoder.*, transformer_decoder.*, "
                "project_bottleneck_embed.*, project_text_embed.*, and segmentation head "
                "project_to_decoder_channels.*" if name == "decoder" else name
            ),
            "segmentation_head_in_group": name == "decoder" and "project_to_decoder_channels" in modules,
            "current_lr": current_lr,
            "initial_base_lr": base_lr,
            "proposed_specialist_lr": proposed_lr,
            "current_to_proposed_ratio": current_lr / proposed_lr if proposed_lr else None,
            "weight_decay": float(group.get("weight_decay", 0.0)),
            "momentum": float(group["momentum"]) if "momentum" in group else None,
            "nesterov": bool(group.get("nesterov", False)),
            "dampening": float(group.get("dampening", 0.0)) if "dampening" in group else None,
            "betas": list(group["betas"]) if "betas" in group else None,
            "parameter_tensor_count": len(parameter_ids),
            "scalar_parameter_count": sum(numel_by_id[parameter_id] for parameter_id in parameter_ids),
            "scalar_parameter_count_with_optimizer_state": stats["momentum_buffer_elements"],
            "scalar_parameter_count_without_optimizer_state": missing_state_numel,
            "parameters_without_optimizer_state": missing_state_names,
            **stats,
        }
        group_details.append(detail)
        group_rows.append({
            **{
                key: value for key, value in detail.items()
                if key not in {"resolved_top_level_modules", "parameters_without_optimizer_state"}
            },
            "resolved_top_level_modules": ";".join(modules),
            "parameters_without_optimizer_state": ";".join(missing_state_names),
            "betas": "" if detail["betas"] is None else ";".join(str(value) for value in detail["betas"]),
        })

    csv_path = output_dir / "optimizer_groups_update8000.csv"
    with csv_path.open("w", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=list(group_rows[0]))
        writer.writeheader()
        writer.writerows(group_rows)

    total = int(scheduler["total"])
    warmup = int(scheduler["warmup"])
    power = float(scheduler["power"])
    minimum = float(scheduler.get("min_factor", 0.0))
    requested_updates = (8000, 8001, 8500, 9000, 10000)
    expected = {
        update: {
            "factor": poly_factor(update, total, warmup, power, minimum),
            "group_lrs": {
                detail["group_name"]: detail["initial_base_lr"] * poly_factor(update, total, warmup, power, minimum)
                for detail in group_details
            },
        }
        for update in requested_updates
    }

    scheduler_payload = {
        "scheduler_type": "custom polynomial schedule applied after each optimizer update",
        "stored_state": scheduler,
        "last_epoch_equivalent": int(scheduler.get("last_optimizer_update", optimizer_update)),
        "current_optimizer_update": optimizer_update,
        "warmup_complete": optimizer_update >= warmup,
        "milestones": None,
        "cosine_parameters": None,
        "polynomial_parameters": {
            "total_optimizer_updates": total,
            "warmup_optimizer_updates": warmup,
            "power": power,
            "minimum_factor": minimum,
        },
        "expected_lrs": {str(update): value for update, value in expected.items()},
        "minimum_final_lrs": {
            detail["group_name"]: detail["initial_base_lr"] * minimum for detail in group_details
        },
        "sanity_check_checkpoint_states": {str(update): value for update, value in sanity.items()},
    }
    json_dump(output_dir / "scheduler_state.json", scheduler_payload)

    trajectory_rows: list[dict[str, Any]] = []
    for update in range(0, total + 1):
        if update not in {0, 6000} and not 7990 <= update <= 9000 and update != 10000:
            continue
        factor = poly_factor(update, total, warmup, power, minimum)
        for detail in group_details:
            name = detail["group_name"]
            actual = None
            source = "formula_reconstruction"
            if update == 8000:
                actual = detail["current_lr"]
                source = "target_checkpoint_actual_and_formula"
            elif update in sanity and name in sanity[update]["group_lrs"]:
                actual = sanity[update]["group_lrs"][name]["lr"]
                source = "sanity_checkpoint_actual_and_formula"
            trajectory_rows.append({
                "optimizer_update": update,
                "group_name": name,
                "base_lr": detail["initial_base_lr"],
                "polynomial_factor": factor,
                "formula_lr": detail["initial_base_lr"] * factor,
                "checkpoint_actual_lr": actual,
                "absolute_difference": abs(actual - detail["initial_base_lr"] * factor) if actual is not None else None,
                "source": source,
            })
    with (output_dir / "lr_trajectory.csv").open("w", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=list(trajectory_rows[0]))
        writer.writeheader()
        writer.writerows(trajectory_rows)

    metric_evidence: dict[str, Any] = {}
    for update in (8000, 10000):
        summary_path = REPO_ROOT / f"outputs/nonattention_baseline_selection/full381_update{update}/summary_tables/summary.json"
        resolved_path = summary_path.parents[1] / "resolved_checkpoint.txt"
        metric_evidence[str(update)] = {
            "summary_path": str(summary_path),
            "summary": json.loads(summary_path.read_text()),
            "resolved_checkpoint_path_file": str(resolved_path),
            "resolved_checkpoint": resolved_path.read_text().strip(),
        }

    checkpoint_hash = sha256(checkpoint_path)
    provenance = {
        "audit_generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "checkpoint_path": str(checkpoint_path),
        "checkpoint_sha256": checkpoint_hash,
        "checkpoint_size_bytes": checkpoint_path.stat().st_size,
        "checkpoint_optimizer_update": optimizer_update,
        "checkpoint_micro_step": int(checkpoint.get("micro_step", checkpoint.get("step", -1))),
        "optimizer_state_exists": optimizer is not None,
        "scheduler_state_exists": scheduler is not None,
        "optimizer_type": optimizer_type,
        "training_script": str(TRAINING_SCRIPT),
        "training_config_path": str(LINEAGE_DIR / "args.json"),
        "training_config_from_checkpoint": saved_args,
        "no_attention_flags": attention_flags,
        "lineage_full381_metric_evidence": metric_evidence,
    }
    json_dump(output_dir / "checkpoint_provenance.json", provenance)

    important_ratios = [
        detail["current_to_proposed_ratio"]
        for detail in group_details
        if detail["group_name"] in {"encoder", "decoder"}
    ]
    state_consistent = all(detail["momentum_all_finite"] for detail in group_details) and all(
        sanity_update["group_lrs"][detail["group_name"]]["parameter_state_entries_present"]
        == detail["parameter_state_entries_present"]
        for sanity_update in sanity.values()
        for detail in group_details
    )
    lr_classification = "LR-TOO-LOW" if min(important_ratios) < 0.5 else "RESUME-APPROPRIATE"
    recommendation = {
        "classification": lr_classification,
        "selected_policy": "POLICY 2 — FRESH MATCHED OPTIMIZER",
        "selected_recommendation_label": "FRESH MATCHED OPTIMIZER",
        "old_optimizer_state_structurally_trustworthy": state_consistent,
        "optimizer_state_is_lazy_partial": any(
            detail["momentum_buffers_missing"] > 0 for detail in group_details
        ),
        "optimizer_state_coverage_note": (
            "SGD momentum state is lazily created. Encoder coverage is complete; 38 decoder-group "
            "parameters have no state in all inspected checkpoints (updates 6000/8000/9000/10000), "
            "indicating persistent never-gradient/unused parameters rather than checkpoint truncation."
        ),
        "old_momentum_recommended_for_specialist_distribution": False,
        "rationale": [
            "Actual shared LRs are only about 23.49% of the proposed specialist LRs at update 8000.",
            "Continuing the original polynomial schedule reduces them to about 18.13% at update 8500 and 12.59% at update 9000, reaching zero at update 10000.",
            "All saved momentum buffers are finite. SGD state is lazily partial: 38 decoder-group parameters have no state, with identical coverage at updates 6000/8000/9000/10000, so this is consistent with never-gradient parameters rather than checkpoint truncation.",
            "The populated momentum buffers were learned on the all-category distribution; the planned specialist-category sequence is a substantial distribution change.",
            "Fresh, identically configured optimizers and schedulers in both arms preserve the matched-control comparison without carrying potentially mismatched old momentum.",
        ],
        "matched_arm_requirements": {
            "shared_model_initialization": str(checkpoint_path),
            "shared_model_sha256": checkpoint_hash,
            "control_optimizer": "fresh",
            "attention_optimizer": "fresh",
            "encoder_lr": 1e-5,
            "decoder_lr": 1e-4,
            "segmentation_head_lr": 1e-4,
            "attention_lr_in_attention_arm_only": 1e-4,
            "shared_scheduler": "identical newly initialized scheduler/warmup in both arms",
            "effective_global_batch": 4,
        },
        "do_not_launch_training_until_audit_complete": True,
        "audit_complete": True,
    }
    json_dump(output_dir / "recommendation.json", recommendation)

    group_table = "\n".join(
        f"| {detail['group_name']} | {detail['current_lr']:.12g} | {detail['initial_base_lr']:.12g} | "
        f"{detail['proposed_specialist_lr']:.12g} | {detail['current_to_proposed_ratio']:.6f} | "
        f"{detail['parameter_tensor_count']:,} | {detail['scalar_parameter_count']:,} | "
        f"{detail['momentum_buffers_present']}/{detail['parameter_tensor_count']} |"
        for detail in group_details
    )
    projected_table = "\n".join(
        f"| {update} | {expected[update]['factor']:.9f} | "
        f"{expected[update]['group_lrs']['encoder']:.12g} | {expected[update]['group_lrs']['decoder']:.12g} |"
        for update in requested_updates
    )
    report = f"""# Dual-expert optimizer-state audit

## Verdict

**Classification: {lr_classification}. Recommendation: POLICY 2 — FRESH MATCHED OPTIMIZER.**

Both experiment arms should load the same update-8000 model weights only, then use fresh matched optimizers and an identical new scheduler for all shared parameters. The attention arm alone adds fresh attention parameters at `1e-4`.

## Checkpoint provenance

- Checkpoint: `{checkpoint_path}`
- SHA256: `{checkpoint_hash}`
- Optimizer update: `{optimizer_update}`
- Optimizer: `{optimizer_type}` with momentum `0.99`, Nesterov enabled, weight decay `3e-5`
- Scheduler: custom polynomial decay by optimizer update, horizon `{total}`, power `{power}`, warmup `{warmup}`, minimum factor `{minimum}`
- No-attention flags: `{json.dumps(attention_flags, sort_keys=True)}`
- Full-381 evidence: update 8000 Dice `{metric_evidence['8000']['summary']['mean_global_dice_per_finding']:.12f}`; update 10000 Dice `{metric_evidence['10000']['summary']['mean_global_dice_per_finding']:.12f}`

## Actual optimizer groups at update 8000

| Group | Actual LR | Base LR | Proposed LR | Actual/proposed | Parameter tensors | Scalar parameters | Momentum buffers |
|---|---:|---:|---:|---:|---:|---:|---:|
{group_table}

The segmentation head (`project_to_decoder_channels.*`) is part of the `decoder` optimizer group and therefore has the decoder LR. All saved momentum buffers are finite. Encoder state coverage is 224/224; decoder coverage is 140/178. The same 140/178 decoder coverage occurs at updates 6000, 9000, and 10000, and exact missing parameter names are in the CSV. This stable pattern is consistent with SGD's lazy momentum creation for parameters that never receive gradients, not a truncated checkpoint. SGD has no per-parameter `step` tensor; scheduler progress is stored separately as optimizer update 8000.

## Original-scheduler continuation

| Update | LR factor | Encoder LR | Decoder/head LR |
|---:|---:|---:|---:|
{projected_table}

The update-6000, update-9000, and update-10000 checkpoint LRs agree with the reconstructed polynomial curve; exact differences are recorded in `lr_trajectory.csv` and `scheduler_state.json`.

## Momentum assessment and initialization policy

The old state is **structurally trustworthy but lazily partial**: all populated buffers are finite, state coverage is stable across four checkpoints, and the optimizer/scheduler counters agree. It is nevertheless not the preferred initialization for specialist training. The update-8000 shared LRs are only `{important_ratios[0]:.2%}` of the proposed values, and the original curve would continue decaying to `{expected[8500]['factor']:.2%}` of base after 500 updates and `{expected[9000]['factor']:.2%}` after 1000. In addition, the old momentum reflects all-category sampling rather than the new specialist-category sequence.

Use **FRESH MATCHED OPTIMIZER** for both arms:

- identical update-8000 shared model weights (SHA256 above);
- fresh shared optimizer state in both arms;
- encoder `1e-5`, decoder and segmentation head `1e-4`;
- attention arm adds attention parameters at `1e-4`;
- identical new scheduler/warmup and effective global batch 4 for both arms.

No dual-expert training job was launched by this audit.
"""
    (output_dir / "report.md").write_text(report)
    print(json.dumps({
        "status": "complete",
        "checkpoint": str(checkpoint_path),
        "sha256": checkpoint_hash,
        "optimizer": optimizer_type,
        "optimizer_update": optimizer_update,
        "groups": group_details,
        "classification": lr_classification,
        "recommendation": "FRESH MATCHED OPTIMIZER",
        "output_dir": str(output_dir),
    }, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
