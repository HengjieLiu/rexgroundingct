#!/usr/bin/env python3
"""Patch-level route sensitivity audit for the trained B1/B2/B3 pilot arms.

The causal Dice endpoint is evaluated separately with full-volume fixed30
inference.  This script uses, for each fixed30 case, the deterministic sliding
window containing the most aggregate GT foreground and records where the
correct-vs-perturbed language signal is retained or attenuated.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from acvl_utils.cropping_and_padding.padding import pad_nd_image

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "VoxTell")]

from voxtell.inference.predictor import VoxTellPredictor
from scripts.run_voxtell_rex_inference import (
    load_entries,
    load_image,
    load_reference_mask_for_window_diagnostic,
    sorted_finding_keys,
)

SELECTION = ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv"
DATASET = ROOT / "data/MICCAI_challenge_dataset.json"
IMAGE_DIR = ROOT / "data/ct_rate_volumes_fixed"
MASK_DIR = ROOT / "data/segmentations"
TOKEN_ROOT = ROOT / "outputs/c2_semantic_p_token_causal_audit/token_caches"
GLOBAL_ROOT = ROOT / "outputs/c2_pathology_route_attribution_audit/prompt_caches"
PAIR_CSV = ROOT / "outputs/c2_semantic_p_token_causal_audit/samecase/eligible_pairs.csv"


def signature(value: torch.Tensor) -> torch.Tensor:
    value = value.detach().float()
    if value.ndim == 5:
        value = F.adaptive_avg_pool3d(value, (8, 8, 8))
    elif value.ndim > 5:
        lead = value.shape[:-3]
        value = F.adaptive_avg_pool3d(
            value.reshape(-1, 1, *value.shape[-3:]), (8, 8, 8)
        ).reshape(*lead, 8, 8, 8)
    return value.cpu()


def metric(correct: torch.Tensor, other: torch.Tensor) -> dict[str, float | int]:
    a = correct.float().reshape(-1)
    b = other.float().reshape(-1)
    return {
        "rel_l2": float((a - b).norm() / a.norm().clamp_min(1e-12)),
        "cosine": float(F.cosine_similarity(a, b, dim=0, eps=1e-12)),
        "rms": float((a - b).square().mean().sqrt()),
        "num_values": int(a.numel()),
    }


def key(record: dict) -> tuple[str, str, int]:
    return str(record["split"]), str(record["case"]), int(record["finding_idx"])


def load_token_cache(path: Path) -> dict[tuple[str, str, int], torch.Tensor]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    return {
        key(record): value
        for record, value in zip(payload["records"], payload["token_features"])
    }


def load_global_cache(path: Path) -> dict[tuple[str, str, int], torch.Tensor]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    return {
        key(record): payload["embeddings"][index].float()
        for index, record in enumerate(payload["records"])
    }


def pack_tokens(
    cache: dict[tuple[str, str, int], torch.Tensor],
    keys: list[tuple[str, str, int]],
) -> tuple[torch.Tensor, torch.Tensor]:
    values = [cache[item] for item in keys]
    length = max(int(value.shape[0]) for value in values)
    hidden = int(values[0].shape[1])
    tokens = torch.zeros(1, len(values), length, hidden, dtype=torch.float16)
    valid = torch.zeros(1, len(values), length, dtype=torch.bool)
    for prompt, value in enumerate(values):
        tokens[0, prompt, : value.shape[0]] = value.half()
        valid[0, prompt, : value.shape[0]] = True
    return tokens, valid


def lesion_max_patch(
    predictor: VoxTellPredictor,
    case: str,
    finding_ids: list[int],
) -> torch.Tensor:
    image, properties = load_image(IMAGE_DIR / case)
    raw = np.asarray(image, dtype=np.float32)
    if raw.ndim == 3:
        raw = raw[None]
    data, bbox, original_shape = predictor.preprocess(raw)
    target = load_reference_mask_for_window_diagnostic(
        MASK_DIR / case,
        len(finding_ids),
        tuple(original_shape),
        bbox,
        image_properties=properties,
        finding_ids=finding_ids,
    )
    if target is None:
        raise RuntimeError(f"Could not align fixed30 GT for {case}")
    data, _ = pad_nd_image(
        data, tuple(predictor.patch_size), "constant", {"value": 0}, True, None
    )
    target, _ = pad_nd_image(
        target, tuple(predictor.patch_size), "constant", {"value": 0}, True, None
    )
    slicers = predictor._internal_get_sliding_window_slicers(
        data.shape[1:], patch_size=tuple(predictor.patch_size)
    )
    chosen = max(
        slicers,
        key=lambda item: float(target[(slice(None), *item[1:])].sum()),
    )
    return data[chosen][None].contiguous().float().to(predictor.device)


def forward_capture(
    model: torch.nn.Module,
    arm: str,
    patch: torch.Tensor,
    global_embedding: torch.Tensor,
    tokens: torch.Tensor,
    valid: torch.Tensor,
) -> dict[str, torch.Tensor]:
    stage_values: dict[int, list[torch.Tensor]] = {
        index: [] for index in range(len(model.decoder.stages))
    }
    ca_values: list[torch.Tensor] = []
    post_ca_values: list[torch.Tensor] = []
    handles = []

    for index, stage in enumerate(model.decoder.stages):
        def capture_stage(_module, _inputs, output, *, stage_index=index):
            stage_values[stage_index].append(signature(output))
        handles.append(stage.register_forward_hook(capture_stage))

    if arm == "B1":
        block = model.word_global_b1_block
        if block is None:
            raise RuntimeError("B1 checkpoint has no late Word-CA block")

        def capture_b1(module, _inputs, output):
            if module.last_attention_output is None:
                raise RuntimeError("B1 raw CA output was not exposed")
            ca_values.append(signature(module.last_attention_output))
            post_ca_values.append(signature(output))

        handles.append(block.register_forward_hook(capture_b1))

    model.capture_word_global_features = True
    try:
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            output = model(
                patch,
                global_embedding,
                token_features=tokens,
                token_valid_mask=valid,
            )
        logits = output[0] if isinstance(output, (tuple, list)) else output
        captured: dict[str, torch.Tensor] = {
            f"decoder_stage{index}": torch.stack(values, dim=1)
            for index, values in stage_values.items()
            if values
        }
        captured["final_logits"] = signature(logits)
        native = dict(model.last_word_global_features)
        if arm == "B1":
            captured["late_word_ca_output"] = torch.stack(ca_values, dim=1)
            captured["post_ca_decoder_feature"] = torch.stack(post_ca_values, dim=1)
        elif arm == "B2":
            captured["q_word"] = signature(native["word_query"])
            captured["prompt_decoder_output"] = signature(
                native["decoder_input_mask_embedding"]
            )
        else:
            captured["candidate_queries"] = signature(native["candidate_queries"])
            captured["candidate_masks"] = signature(native["candidate_masks"])
            captured["router_beta"] = signature(native["router_weights"])
            captured["final_weighted_m"] = signature(
                native["decoder_input_mask_embedding"]
            )
        return captured
    finally:
        model.capture_word_global_features = False
        model.last_word_global_features = {}
        for handle in handles:
            handle.remove()


def stage_aliases(arm: str) -> dict[str, str]:
    if arm == "B1":
        return {
            "late_word_ca_output": "late_word_ca_output",
            "post_ca_decoder_feature": "post_ca_decoder_feature",
            "next_decoder_stage": "decoder_stage3",
            "final_decoder_feature": "decoder_stage4",
            "final_logits": "final_logits",
        }
    if arm == "B2":
        return {
            "q_word": "q_word",
            "prompt_decoder_output": "prompt_decoder_output",
            "first_decoder_fusion": "decoder_stage0",
            "final_decoder_feature": "decoder_stage4",
            "final_logits": "final_logits",
        }
    return {
        "candidate_queries": "candidate_queries",
        "candidate_mask_embedding": "candidate_masks",
        "router_beta": "router_beta",
        "final_weighted_m": "final_weighted_m",
        "first_decoder_fusion": "decoder_stage0",
        "final_decoder_feature": "decoder_stage4",
        "final_logits": "final_logits",
    }


def prompt_slice(value: torch.Tensor, prompt: int) -> torch.Tensor:
    if value.ndim < 2 or value.shape[0] != 1:
        raise RuntimeError(f"Unexpected captured tensor shape: {tuple(value.shape)}")
    return value[0, prompt]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=["B1", "B2", "B3"], required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-cases", type=int, default=0)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    token_paths = {
        "correct": TOKEN_ROOT / "correct.pt",
        "shuffle": TOKEN_ROOT / "within_shuffle.pt",
        "neutral": TOKEN_ROOT / "neutral.pt",
        "samecase": TOKEN_ROOT / "samecase_wrong.pt",
    }
    global_paths = {
        "correct": GLOBAL_ROOT / "correct.pt",
        "samecase": GLOBAL_ROOT / "global_samecase_wrong.pt",
    }
    tokens = {name: load_token_cache(path) for name, path in token_paths.items()}
    globals_ = {name: load_global_cache(path) for name, path in global_paths.items()}
    pairs = pd.read_csv(PAIR_CSV)
    eligible = {
        (str(row.case), int(row.finding_idx)): str(row.pair_type)
        for row in pairs.itertuples(index=False)
        if bool(row.eligible)
    }

    if args.arm in {"B1", "B2"}:
        conditions = {
            "correct": ("correct", "correct"),
            "shuffle": ("shuffle", "correct"),
            "neutral": ("neutral", "correct"),
            "samecase_wrong": ("samecase", "correct"),
        }
        comparisons = {
            "correct_vs_shuffle": ("correct", "shuffle", False),
            "correct_vs_neutral": ("correct", "neutral", False),
            "correct_vs_samecase_wrong": ("correct", "samecase_wrong", True),
        }
    else:
        conditions = {
            "CC": ("correct", "correct"),
            "WC": ("samecase", "correct"),
            "CW": ("correct", "samecase"),
            "WW": ("samecase", "samecase"),
            "shuffle": ("shuffle", "correct"),
            "neutral": ("neutral", "correct"),
        }
        comparisons = {
            "word_CC_vs_WC": ("CC", "WC", True),
            "router_CC_vs_CW": ("CC", "CW", True),
            "both_CC_vs_WW": ("CC", "WW", True),
            "CC_vs_shuffle": ("CC", "shuffle", False),
            "CC_vs_neutral": ("CC", "neutral", False),
        }

    predictor = VoxTellPredictor(
        model_dir=str(ROOT / "VoxTell/voxtell_v1.1"),
        checkpoint_path=str(args.checkpoint.resolve()),
        device=torch.device("cuda:0"),
        load_text_backbone=False,
        text_representation="qwen",
        amp_dtype="bfloat16",
    )
    model = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    model = model.to(predictor.device).eval()
    expected = args.arm.lower()
    if str(getattr(model, "word_global_mode", "none")) != expected:
        raise RuntimeError(
            f"Requested {args.arm}, loaded word_global_mode={model.word_global_mode}"
        )

    selected_cases = pd.read_csv(SELECTION)["case"].astype(str).drop_duplicates().tolist()
    if args.max_cases > 0:
        selected_cases = selected_cases[: args.max_cases]
    entries = {entry["name"]: entry for entry in load_entries(DATASET, ["val"])}
    rows: list[dict] = []
    route_rows: list[dict] = []
    aliases = stage_aliases(args.arm)
    for case_number, case in enumerate(selected_cases, 1):
        entry = entries[case]
        finding_ids = [int(value) for value in sorted_finding_keys(entry)]
        keys = [("val", case, index) for index in finding_ids]
        patch = lesion_max_patch(predictor, case, finding_ids)
        captured_by_condition: dict[str, dict[str, torch.Tensor]] = {}
        for condition, (token_condition, global_condition) in conditions.items():
            token_tensor, valid = pack_tokens(tokens[token_condition], keys)
            global_tensor = torch.stack(
                [globals_[global_condition][item] for item in keys]
            ).unsqueeze(0)
            captured_by_condition[condition] = forward_capture(
                model,
                args.arm,
                patch,
                global_tensor.to(predictor.device),
                token_tensor.to(predictor.device),
                valid.to(predictor.device),
            )
            del token_tensor, valid, global_tensor

        for comparison, (correct_name, other_name, eligible_only) in comparisons.items():
            correct = captured_by_condition[correct_name]
            other = captured_by_condition[other_name]
            for prompt, finding_idx in enumerate(finding_ids):
                pair_type = eligible.get((case, finding_idx))
                if eligible_only and pair_type is None:
                    continue
                for label, source_key in aliases.items():
                    row = {
                        "arm": args.arm,
                        "case": case,
                        "finding_idx": finding_idx,
                        "comparison": comparison,
                        "pair_type": pair_type or "all_fixed30",
                        "stage": label,
                    }
                    row.update(
                        metric(
                            prompt_slice(correct[source_key], prompt),
                            prompt_slice(other[source_key], prompt),
                        )
                    )
                    rows.append(row)

                if args.arm == "B3":
                    for name in (correct_name, other_name):
                        beta = prompt_slice(captured_by_condition[name]["router_beta"], prompt)
                        entropy = float(
                            -(beta.clamp_min(1e-12) * beta.clamp_min(1e-12).log()).sum()
                        )
                        candidate = prompt_slice(
                            captured_by_condition[name]["candidate_masks"], prompt
                        )
                        normalized = F.normalize(candidate.float(), dim=-1, eps=1e-12)
                        cosine = normalized @ normalized.transpose(-1, -2)
                        offdiag = cosine[~torch.eye(cosine.shape[0], dtype=torch.bool)]
                        diagnostic = {
                                "case": case,
                                "finding_idx": finding_idx,
                                "comparison": comparison,
                                "condition": name,
                                "router_entropy": entropy,
                                "candidate_cosine_diversity": float((1 - offdiag).mean()),
                                "router_selection": int(beta.argmax()),
                                "pair_type": pair_type or "all_fixed30",
                        }
                        for candidate_index, weight in enumerate(beta):
                            diagnostic[f"router_beta_{candidate_index}"] = float(weight)
                        for left in range(cosine.shape[0]):
                            for right in range(left + 1, cosine.shape[1]):
                                diagnostic[f"candidate_cosine_{left}_{right}"] = float(
                                    cosine[left, right]
                                )
                        route_rows.append(diagnostic)
        del patch, captured_by_condition
        torch.cuda.empty_cache()
        print(f"[{case_number}/30] {case}", flush=True)

    detail = pd.DataFrame(rows)
    detail.to_csv(args.output / "per_finding_route_sensitivity.csv", index=False)
    summary = (
        detail.groupby(["arm", "comparison", "stage"], sort=False)[
            ["rel_l2", "cosine", "rms"]
        ]
        .agg(["count", "mean", "median"])
        .reset_index()
    )
    summary.columns = [
        "_".join(filter(None, map(str, column))).rstrip("_")
        for column in summary.columns
    ]
    summary.to_csv(args.output / "route_sensitivity_summary.csv", index=False)
    if route_rows:
        pd.DataFrame(route_rows).to_csv(
            args.output / "b3_router_candidate_diagnostics.csv", index=False
        )
    metadata = {
        "checkpoint": str(args.checkpoint.resolve()),
        "arm": args.arm,
        "cases": len(selected_cases),
        "fixed30_findings": 49,
        "samecase_eligible": len(eligible),
        "patch_policy": "one deterministic sliding window per case maximizing aggregate fixed30 GT foreground",
        "spatial_signature": "adaptive-average-pooled to 8x8x8 before rel-L2/cosine/RMS",
        "pair_manifest": str(PAIR_CSV.resolve()),
        "conditions": conditions,
    }
    (args.output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")


if __name__ == "__main__":
    main()
