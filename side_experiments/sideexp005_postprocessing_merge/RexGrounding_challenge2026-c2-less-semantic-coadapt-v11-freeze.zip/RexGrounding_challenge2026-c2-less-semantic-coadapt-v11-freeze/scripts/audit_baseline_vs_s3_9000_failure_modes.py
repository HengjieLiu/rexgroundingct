#!/usr/bin/env python3
"""Paired binary-mask failure-mode audit: non-S3 update 8000 vs S3 update 9000."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import time
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any, Callable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import pandas as pd
from scipy import ndimage


ROOT = Path(__file__).resolve().parents[1]
BASELINE_DIR = ROOT / "outputs/nonattention_baseline_selection/full381_update8000"
S3_DIR = ROOT / "outputs/controlled_v11_selected_full200/s3_update9000"
GT_DIR = ROOT / "data/segmentations"
CT_DIR = ROOT / "data/ct_rate_volumes_fixed"
DATASET_JSON = ROOT / "data/MICCAI_challenge_dataset.json"
OUTPUT_DIR = ROOT / "outputs/baseline_vs_s3_9000_failure_mode_audit"
BASELINE_CHECKPOINT = (
    ROOT
    / "outputs/voxtell_v11_e1e-5_d1e-4_1gpu_bs1_acc4_10kupd"
    / "checkpoints/checkpoint_update_8000.pth"
)
S3_CHECKPOINT = (
    ROOT
    / "outputs/s3_1over1_allcat_v11_e1e-5_d1e-4_s3e1e-4_1gpu_bs1_acc4_10kupd"
    / "checkpoints/checkpoint_update_9000.pth"
)
CONNECTIVITY = 2
MIN_PRED_COMPONENT_VOXELS = 10
HIT_DICE_THRESHOLD = 0.1
STRUCTURE = ndimage.generate_binary_structure(3, CONNECTIVITY)
EPS = 1e-12


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-dir", type=Path, default=BASELINE_DIR)
    parser.add_argument("--s3-dir", type=Path, default=S3_DIR)
    parser.add_argument("--gt-dir", type=Path, default=GT_DIR)
    parser.add_argument("--ct-dir", type=Path, default=CT_DIR)
    parser.add_argument("--dataset-json", type=Path, default=DATASET_JSON)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--bootstrap-samples", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20260730)
    return parser.parse_args()


def size_group(voxels: int) -> str:
    if voxels < 100:
        return "tiny_lt100"
    if voxels < 1_000:
        return "small_100_999"
    if voxels < 10_000:
        return "medium_1k_9999"
    return "large_ge10k"


def multiplicity_group(count: int) -> str:
    if count == 1:
        return "single"
    if count <= 3:
        return "few_2_3"
    return "multiple_ge4"


def read_metadata(path: Path) -> pd.DataFrame:
    data = json.loads(path.read_text())
    rows: list[dict[str, Any]] = []
    for entry in data["val"]:
        for key, prompt in (entry.get("findings") or {}).items():
            rows.append(
                {
                    "case_id": entry["name"],
                    "finding_id": int(key),
                    "category": str((entry.get("categories") or {}).get(key, "unknown")),
                    "prompt": str(prompt),
                    "json_pixels": int((entry.get("pixels") or {}).get(key, 0)),
                }
            )
    frame = pd.DataFrame(rows).sort_values(["case_id", "finding_id"]).reset_index(drop=True)
    if len(frame) != 381 or frame.duplicated(["case_id", "finding_id"]).any():
        raise AssertionError("Validation metadata is not exactly 381 unique findings")
    return frame


def load_metric_table(directory: Path, baseline: bool) -> pd.DataFrame:
    path = (
        directory / "summary_tables/per_finding_metrics.csv"
        if baseline
        else directory / "per_finding_metrics.csv"
    )
    frame = pd.read_csv(path)
    frame = frame.rename(columns={"file": "case_id", "finding_idx": "finding_id"})
    if len(frame) != 381 or frame.duplicated(["case_id", "finding_id"]).any():
        raise AssertionError(f"{path} is not exactly 381 unique findings")
    return frame.sort_values(["case_id", "finding_id"]).reset_index(drop=True)


def assert_close(actual: float, expected: float, tolerance: float = 6e-5) -> None:
    if abs(actual - expected) > tolerance:
        raise AssertionError(f"{actual} does not reproduce {expected} within {tolerance}")


def reproduce_known_metrics(base: pd.DataFrame, s3: pd.DataFrame) -> dict[str, Any]:
    known_category = {
        "2b": (0.3422, 0.3578, 37, 38),
        "2c": (0.3732, 0.3866, 49, 50),
        "2a": (0.3435, 0.3358, 59, 58),
        "2d": (0.3710, 0.3692, 116, 111),
    }
    known_size = {
        "tiny_lt100": (0.2860, 0.3057, 15, 15),
        "small_100_999": (0.3199, 0.3129, 90, 85),
        "medium_1k_9999": (0.2866, 0.2884, 67, 66),
        "large_ge10k": (0.3815, 0.3902, 122, 123),
    }
    result: dict[str, Any] = {
        "overall": {
            "baseline_dice": float(base.global_dice.mean()),
            "s3_dice": float(s3.global_dice.mean()),
            "baseline_hits": int(base.global_hit.sum()),
            "s3_hits": int(s3.global_hit.sum()),
        },
        "category": {},
        "size": {},
    }
    assert_close(result["overall"]["baseline_dice"], 0.33264910155464106, 1e-10)
    assert_close(result["overall"]["s3_dice"], 0.3355345029481685, 1e-10)
    if (result["overall"]["baseline_hits"], result["overall"]["s3_hits"]) != (294, 289):
        raise AssertionError("Overall hit counts do not reproduce 294 -> 289")
    for category, expected in known_category.items():
        b = base.loc[base.category == category]
        s = s3.loc[s3.category == category]
        values = (float(b.global_dice.mean()), float(s.global_dice.mean()), int(b.global_hit.sum()), int(s.global_hit.sum()))
        assert_close(values[0], expected[0])
        assert_close(values[1], expected[1])
        if values[2:] != expected[2:]:
            raise AssertionError(f"{category} hit mismatch: {values[2:]} vs {expected[2:]}")
        result["category"][category] = dict(
            baseline_dice=values[0], s3_dice=values[1], baseline_hits=values[2], s3_hits=values[3]
        )
    for frame in (base, s3):
        frame["size_group"] = frame.gt_voxels.astype(int).map(size_group)
    for group, expected in known_size.items():
        b = base.loc[base.size_group == group]
        s = s3.loc[s3.size_group == group]
        values = (float(b.global_dice.mean()), float(s.global_dice.mean()), int(b.global_hit.sum()), int(s.global_hit.sum()))
        assert_close(values[0], expected[0])
        assert_close(values[1], expected[1])
        if values[2:] != expected[2:]:
            raise AssertionError(f"{group} hit mismatch: {values[2:]} vs {expected[2:]}")
        result["size"][group] = dict(
            n=len(b), baseline_dice=values[0], s3_dice=values[1],
            baseline_hits=values[2], s3_hits=values[3]
        )
    return result


def filtered_labels(mask: np.ndarray) -> tuple[np.ndarray, int, np.ndarray]:
    labels, _ = ndimage.label(mask, structure=STRUCTURE)
    sizes = np.bincount(labels.ravel())
    keep = sizes >= MIN_PRED_COMPONENT_VOXELS
    keep[0] = False
    filtered = keep[labels]
    del labels
    relabeled, count = ndimage.label(filtered, structure=STRUCTURE)
    component_sizes = np.bincount(relabeled.ravel(), minlength=count + 1)
    return relabeled, int(count), component_sizes


def component_metrics(
    gt: np.ndarray, prediction: np.ndarray, model: str, base: dict[str, Any]
) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    gt_labels, gt_count = ndimage.label(gt, structure=STRUCTURE)
    gt_sizes = np.bincount(gt_labels.ravel(), minlength=gt_count + 1)
    pred_labels, pred_count, pred_sizes = filtered_labels(prediction)
    overlap_mask = (gt_labels > 0) & (pred_labels > 0)
    pair_counts: dict[tuple[int, int], int] = {}
    if overlap_mask.any():
        encoded = (
            gt_labels[overlap_mask].astype(np.int64) * (pred_count + 1)
            + pred_labels[overlap_mask].astype(np.int64)
        )
        ids, counts = np.unique(encoded, return_counts=True)
        pair_counts = {
            (int(code // (pred_count + 1)), int(code % (pred_count + 1))): int(count)
            for code, count in zip(ids, counts)
        }
    gt_to_pred: dict[int, list[tuple[int, int]]] = defaultdict(list)
    pred_to_gt: dict[int, list[tuple[int, int]]] = defaultdict(list)
    pair_rows: list[dict[str, Any]] = []
    for (gt_id, pred_id), overlap in sorted(pair_counts.items()):
        gt_volume = int(gt_sizes[gt_id])
        pred_volume = int(pred_sizes[pred_id])
        union = gt_volume + pred_volume - overlap
        gt_to_pred[gt_id].append((pred_id, overlap))
        pred_to_gt[pred_id].append((gt_id, overlap))
        pair_rows.append(
            {
                **base, "model": model, "gt_component_id": gt_id,
                "pred_component_id": pred_id, "overlap_voxels": overlap,
                "gt_component_voxels": gt_volume, "pred_component_voxels": pred_volume,
                "pair_dice": 2 * overlap / (gt_volume + pred_volume),
                "pair_iou": overlap / union if union else 1.0,
            }
        )
    matching_rows: list[dict[str, Any]] = []
    detected = 0
    weighted_total_coverage = 0
    weighted_max_coverage = 0
    coverage_threshold_counts = {10: 0, 25: 0, 50: 0}
    gt_max_coverages: list[float] = []
    for gt_id in range(1, gt_count + 1):
        volume = int(gt_sizes[gt_id])
        overlaps = gt_to_pred.get(gt_id, [])
        total_overlap = sum(value for _, value in overlaps)
        max_overlap = max((value for _, value in overlaps), default=0)
        max_coverage = max_overlap / volume if volume else 1.0
        max_dice = max(
            (2 * value / (volume + int(pred_sizes[pred_id])) for pred_id, value in overlaps),
            default=0.0,
        )
        max_iou = max(
            (
                value / (volume + int(pred_sizes[pred_id]) - value)
                for pred_id, value in overlaps
            ),
            default=0.0,
        )
        detected += int(total_overlap > 0)
        weighted_total_coverage += total_overlap
        weighted_max_coverage += max_overlap
        gt_max_coverages.append(max_coverage)
        for threshold in coverage_threshold_counts:
            coverage_threshold_counts[threshold] += int(max_coverage >= threshold / 100)
        matching_rows.append(
            {
                **base, "model": model, "row_type": "gt_component",
                "component_id": gt_id, "component_voxels": volume,
                "overlaps_any": bool(total_overlap), "overlap_component_count": len(overlaps),
                "total_overlap_voxels": total_overlap, "max_overlap_voxels": max_overlap,
                "max_coverage_fraction": max_coverage, "max_pair_dice": max_dice,
                "max_pair_iou": max_iou, "coverage_ge_10pct": max_coverage >= 0.10,
                "coverage_ge_25pct": max_coverage >= 0.25,
                "coverage_ge_50pct": max_coverage >= 0.50,
                "overlap_partners_json": json.dumps(overlaps),
            }
        )
    detached_count = detached_volume = largest_detached = overlap_pred_count = 0
    for pred_id in range(1, pred_count + 1):
        volume = int(pred_sizes[pred_id])
        overlaps = pred_to_gt.get(pred_id, [])
        total_overlap = sum(value for _, value in overlaps)
        detached = total_overlap == 0
        overlap_pred_count += int(not detached)
        detached_count += int(detached)
        detached_volume += volume if detached else 0
        largest_detached = max(largest_detached, volume if detached else 0)
        matching_rows.append(
            {
                **base, "model": model, "row_type": "pred_component",
                "component_id": pred_id, "component_voxels": volume,
                "overlaps_any": not detached, "overlap_component_count": len(overlaps),
                "total_overlap_voxels": total_overlap, "max_overlap_voxels": max((v for _, v in overlaps), default=0),
                "max_coverage_fraction": np.nan, "max_pair_dice": np.nan,
                "max_pair_iou": np.nan, "coverage_ge_10pct": np.nan,
                "coverage_ge_25pct": np.nan, "coverage_ge_50pct": np.nan,
                "overlap_partners_json": json.dumps(overlaps),
            }
        )
    total_gt = int(gt.sum())
    total_filtered_pred = int(pred_sizes[1:].sum())
    summary = {
        "gt_component_count": int(gt_count),
        "gt_component_volumes_json": json.dumps([int(x) for x in gt_sizes[1:]]),
        "largest_gt_component_volume": int(gt_sizes[1:].max()) if gt_count else 0,
        "largest_gt_component_fraction": float(gt_sizes[1:].max() / total_gt) if total_gt else 1.0,
        "multiplicity_group": multiplicity_group(int(gt_count)),
        f"{model}_pred_component_count": pred_count,
        f"{model}_overlapping_pred_component_count": overlap_pred_count,
        f"{model}_detached_fp_component_count": detached_count,
        f"{model}_detached_fp_component_volume": detached_volume,
        f"{model}_largest_detached_fp_component_volume": largest_detached,
        f"{model}_largest_pred_component_fraction": (
            float(pred_sizes[1:].max() / total_filtered_pred) if total_filtered_pred else 1.0
        ),
        f"{model}_gt_component_detection_recall": detected / gt_count if gt_count else 1.0,
        f"{model}_volume_weighted_gt_component_coverage": (
            weighted_total_coverage / total_gt if total_gt else 1.0
        ),
        f"{model}_volume_weighted_max_component_coverage": (
            weighted_max_coverage / total_gt if total_gt else 1.0
        ),
        f"{model}_mean_max_gt_component_coverage": (
            float(np.mean(gt_max_coverages)) if gt_max_coverages else 1.0
        ),
        f"{model}_gt_component_recall_ge_10pct": (
            coverage_threshold_counts[10] / gt_count if gt_count else 1.0
        ),
        f"{model}_gt_component_recall_ge_25pct": (
            coverage_threshold_counts[25] / gt_count if gt_count else 1.0
        ),
        f"{model}_gt_component_recall_ge_50pct": (
            coverage_threshold_counts[50] / gt_count if gt_count else 1.0
        ),
    }
    return summary, matching_rows, pair_rows


def analyze_case(task: tuple[dict[str, Any], str, str, str]) -> dict[str, Any]:
    case_meta, gt_dir, baseline_dir, s3_dir = task
    case = case_meta["case_id"]
    gt_image = nib.load(str(Path(gt_dir) / case))
    baseline_image = nib.load(str(Path(baseline_dir) / case))
    s3_image = nib.load(str(Path(s3_dir) / case))
    if gt_image.shape != baseline_image.shape or gt_image.shape != s3_image.shape:
        raise AssertionError(f"{case}: shape mismatch")
    if not np.allclose(gt_image.affine, baseline_image.affine) or not np.allclose(gt_image.affine, s3_image.affine):
        raise AssertionError(f"{case}: affine mismatch")
    gt_all = np.asanyarray(gt_image.dataobj).astype(bool, copy=False)
    baseline_all = np.asanyarray(baseline_image.dataobj).astype(bool, copy=False)
    s3_all = np.asanyarray(s3_image.dataobj).astype(bool, copy=False)
    findings = case_meta["findings"]
    if gt_all.shape[0] != len(findings):
        raise AssertionError(f"{case}: {gt_all.shape[0]} mask channels != {len(findings)} findings")
    master_rows: list[dict[str, Any]] = []
    matching: dict[str, list[dict[str, Any]]] = {"baseline": [], "s3": []}
    pairs: dict[str, list[dict[str, Any]]] = {"baseline": [], "s3": []}
    for item in findings:
        index = int(item["finding_id"])
        gt = gt_all[index]
        baseline = baseline_all[index]
        s3 = s3_all[index]
        if not gt.any():
            raise AssertionError(f"{case}/{index}: zero-filled target channel")
        base = {
            "case_id": case, "finding_id": index, "category": item["category"],
            "prompt": item["prompt"],
        }
        b_summary, b_matching, b_pairs = component_metrics(gt, baseline, "baseline", base)
        s_summary, s_matching, s_pairs = component_metrics(gt, s3, "s3", base)
        matching["baseline"].extend(b_matching)
        matching["s3"].extend(s_matching)
        pairs["baseline"].extend(b_pairs)
        pairs["s3"].extend(s_pairs)
        master_rows.append({**base, **b_summary, **s_summary})
    return {"master": master_rows, "matching": matching, "pairs": pairs}


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def atomic_json(value: Any, path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=True) + "\n")
    temporary.replace(path)


def assemble_base_master(metadata: pd.DataFrame, base: pd.DataFrame, s3: pd.DataFrame) -> pd.DataFrame:
    keys = ["case_id", "finding_id"]
    for frame, label in ((base, "baseline"), (s3, "s3")):
        expected = metadata[keys + ["category", "prompt"]].copy()
        actual = frame[keys + ["category", "prompt"]].copy()
        merged = expected.merge(actual, on=keys, suffixes=("_metadata", f"_{label}"), validate="one_to_one")
        if len(merged) != 381:
            raise AssertionError(f"{label}: missing finding alignment")
        if not (merged.category_metadata.astype(str) == merged[f"category_{label}"].astype(str)).all():
            raise AssertionError(f"{label}: category mismatch")
        if not (merged.prompt_metadata.astype(str) == merged[f"prompt_{label}"].astype(str)).all():
            raise AssertionError(f"{label}: prompt mismatch")
    common = metadata.rename(columns={"json_pixels": "manifest_gt_voxels"}).copy()
    keep = [
        "global_dice", "global_hit", "tp_voxels", "fp_voxels", "fn_voxels",
        "pred_voxels", "gt_voxels", "voxel_precision", "voxel_recall",
        "pred_gt_volume_ratio",
    ]
    for frame, label in ((base, "baseline"), (s3, "s3")):
        addition = frame[keys + keep].rename(columns={name: f"{label}_{name}" for name in keep})
        common = common.merge(addition, on=keys, validate="one_to_one")
    if not (common.baseline_gt_voxels == common.s3_gt_voxels).all():
        raise AssertionError("GT voxel counts differ between model metric files")
    if not (common.baseline_gt_voxels == common.manifest_gt_voxels).all():
        raise AssertionError("GT voxel counts differ from manifest pixels")
    common["patient_case_group"] = common.case_id.str.replace(r"\.nii(\.gz)?$", "", regex=True)
    common["gt_voxels"] = common.baseline_gt_voxels.astype(int)
    common["size_group"] = common.gt_voxels.map(size_group)
    for prefix in ("baseline", "s3"):
        if not (
            common[f"{prefix}_tp_voxels"] + common[f"{prefix}_fn_voxels"]
            == common.gt_voxels
        ).all():
            raise AssertionError(f"{prefix}: TP + FN != GT")
        if not (
            common[f"{prefix}_tp_voxels"] + common[f"{prefix}_fp_voxels"]
            == common[f"{prefix}_pred_voxels"]
        ).all():
            raise AssertionError(f"{prefix}: TP + FP != predicted volume")
    return common


def add_deltas(master: pd.DataFrame) -> pd.DataFrame:
    pairs = {
        "dice": "global_dice", "precision": "voxel_precision", "recall": "voxel_recall",
        "fp": "fp_voxels", "fn": "fn_voxels", "predicted_volume": "pred_voxels",
        "detached_fp_count": "detached_fp_component_count",
        "detached_fp_volume": "detached_fp_component_volume",
        "gt_component_recall": "gt_component_detection_recall",
        "component_coverage": "volume_weighted_max_component_coverage",
    }
    for output, source in pairs.items():
        master[f"delta_{output}"] = master[f"s3_{source}"] - master[f"baseline_{source}"]
    master["baseline_fp_per_gt"] = master.baseline_fp_voxels / master.gt_voxels
    master["s3_fp_per_gt"] = master.s3_fp_voxels / master.gt_voxels
    master["delta_fp_per_gt"] = master.s3_fp_per_gt - master.baseline_fp_per_gt
    master["baseline_fn_per_gt"] = master.baseline_fn_voxels / master.gt_voxels
    master["s3_fn_per_gt"] = master.s3_fn_voxels / master.gt_voxels
    master["delta_fn_per_gt"] = master.s3_fn_per_gt - master.baseline_fn_per_gt
    return master


def summarize(frame: pd.DataFrame, label: str) -> dict[str, Any]:
    if frame.empty:
        return {
            "group": label, "findings": 0, "cases": 0,
            "baseline_dice": float("nan"), "s3_dice": float("nan"),
            "delta_dice": float("nan"), "baseline_hits": 0, "s3_hits": 0,
            "delta_precision": float("nan"), "delta_recall": float("nan"),
            "delta_fp_voxels_total": 0, "delta_fn_voxels_total": 0,
            "delta_predicted_voxels_total": 0,
            "baseline_fp_per_gt": float("nan"), "s3_fp_per_gt": float("nan"),
            "delta_fp_per_gt": float("nan"),
            "baseline_fn_per_gt": float("nan"), "s3_fn_per_gt": float("nan"),
            "delta_fn_per_gt": float("nan"),
            "delta_detached_fp_count": 0, "delta_detached_fp_volume": 0,
            "delta_gt_component_recall": float("nan"),
            "delta_component_coverage": float("nan"),
            "improved": 0, "degraded": 0, "tied": 0,
            "descriptive_only": True,
        }
    return {
        "group": label, "findings": len(frame), "cases": int(frame.case_id.nunique()),
        "baseline_dice": float(frame.baseline_global_dice.mean()),
        "s3_dice": float(frame.s3_global_dice.mean()),
        "delta_dice": float(frame.delta_dice.mean()),
        "baseline_hits": int(frame.baseline_global_hit.sum()),
        "s3_hits": int(frame.s3_global_hit.sum()),
        "delta_precision": float(frame.delta_precision.mean()),
        "delta_recall": float(frame.delta_recall.mean()),
        "delta_fp_voxels_total": int(frame.s3_fp_voxels.sum() - frame.baseline_fp_voxels.sum()),
        "delta_fn_voxels_total": int(frame.s3_fn_voxels.sum() - frame.baseline_fn_voxels.sum()),
        "delta_predicted_voxels_total": int(frame.s3_pred_voxels.sum() - frame.baseline_pred_voxels.sum()),
        "baseline_fp_per_gt": float(frame.baseline_fp_voxels.sum() / frame.gt_voxels.sum()),
        "s3_fp_per_gt": float(frame.s3_fp_voxels.sum() / frame.gt_voxels.sum()),
        "delta_fp_per_gt": float(
            (frame.s3_fp_voxels.sum() - frame.baseline_fp_voxels.sum()) / frame.gt_voxels.sum()
        ),
        "baseline_fn_per_gt": float(frame.baseline_fn_voxels.sum() / frame.gt_voxels.sum()),
        "s3_fn_per_gt": float(frame.s3_fn_voxels.sum() / frame.gt_voxels.sum()),
        "delta_fn_per_gt": float(
            (frame.s3_fn_voxels.sum() - frame.baseline_fn_voxels.sum()) / frame.gt_voxels.sum()
        ),
        "delta_detached_fp_count": int(
            frame.s3_detached_fp_component_count.sum()
            - frame.baseline_detached_fp_component_count.sum()
        ),
        "delta_detached_fp_volume": int(
            frame.s3_detached_fp_component_volume.sum()
            - frame.baseline_detached_fp_component_volume.sum()
        ),
        "delta_gt_component_recall": float(frame.delta_gt_component_recall.mean()),
        "delta_component_coverage": float(frame.delta_component_coverage.mean()),
        "improved": int((frame.delta_dice > EPS).sum()),
        "degraded": int((frame.delta_dice < -EPS).sum()),
        "tied": int((frame.delta_dice.abs() <= EPS).sum()),
        "descriptive_only": len(frame) < 5,
    }


def classify_2d_lost_hit(row: pd.Series) -> str:
    labels: list[str] = []
    if int(row.s3_tp_voxels) == 0:
        labels.append("A_complete_localization_failure")
    if int(row.s3_tp_voxels) > 0 and (
        float(row.delta_recall) <= -0.10 or float(row.delta_component_coverage) <= -0.10
    ):
        labels.append("B_coverage_shrinkage")
    if int(row.gt_component_count) > 1 and float(row.delta_gt_component_recall) < -EPS:
        labels.append("C_partial_multi_instance_coverage")
    if (
        int(row.s3_overlapping_pred_component_count)
        >= int(row.baseline_overlapping_pred_component_count) + 2
        and float(row.delta_component_coverage) <= -0.10
    ):
        labels.append("D_fragmentation")
    labels.append("E_threshold_edge_unavailable_no_probability_maps")
    substantive = [label for label in labels if not label.startswith("E_")]
    if not substantive:
        labels.insert(0, "F_mixed_or_other")
    return ";".join(labels)


def category_2d_audit(master: pd.DataFrame, output: Path) -> dict[str, Any]:
    frame = master.loc[master.category == "2d"].copy()
    frame["transition"] = np.select(
        [
            frame.baseline_global_hit & frame.s3_global_hit,
            frame.baseline_global_hit & ~frame.s3_global_hit,
            ~frame.baseline_global_hit & frame.s3_global_hit,
        ],
        ["hit_to_hit", "hit_to_miss", "miss_to_hit"],
        default="miss_to_miss",
    )
    atomic_csv(frame, output / "category_2d_hit_transition.csv")
    lost = frame.loc[frame.transition == "hit_to_miss"].copy()
    lost["failure_types"] = lost.apply(classify_2d_lost_hit, axis=1)
    atomic_csv(lost, output / "category_2d_lost_hit_detailed.csv")
    transition = frame.transition.value_counts().to_dict()
    if int(frame.baseline_global_hit.sum() - frame.s3_global_hit.sum()) != 5:
        raise AssertionError("2d net lost-hit count does not equal five")
    summary_rows = []
    for columns in (
        ["size_group"], ["multiplicity_group"], ["size_group", "multiplicity_group"],
    ):
        for key, group in frame.groupby(columns, observed=False, dropna=False):
            label = "|".join(map(str, key if isinstance(key, tuple) else (key,)))
            summary_rows.append({"stratification": "+".join(columns), **summarize(group, label)})
    atomic_csv(pd.DataFrame(summary_rows), output / "category_2d_stratified_summary.csv")
    failure_counts = Counter(
        part for value in lost.failure_types for part in str(value).split(";")
    )
    lines = [
        "# Category 2d lost-hit audit", "",
        f"- 2d findings: {len(frame)}; hits {int(frame.baseline_global_hit.sum())} -> {int(frame.s3_global_hit.sum())}.",
        f"- Transitions: `{transition}`.", f"- Failure labels: `{dict(failure_counts)}`.", "",
        "Probability/logit maps were not saved for these full-volume runs. Threshold-edge",
        "classification is therefore unavailable in the binary-mask audit and is not guessed.",
    ]
    (output / "category_2d_lost_hit_summary.md").write_text("\n".join(lines) + "\n")
    return {"transitions": transition, "lost_findings": len(lost), "failure_counts": dict(failure_counts)}


def mechanism_label(summary: dict[str, Any]) -> str:
    mechanisms: list[str] = []
    if summary["delta_fp_per_gt"] < 0 and summary["delta_precision"] > 0:
        mechanisms.append("FP_control")
    if summary["delta_fn_per_gt"] < 0 and summary["delta_recall"] > 0:
        mechanisms.append("recall_extent")
    if summary["delta_detached_fp_volume"] < 0:
        mechanisms.append("detached_component_removal")
    if summary["delta_gt_component_recall"] > 0:
        mechanisms.append("multi_instance_coverage")
    if not mechanisms:
        return "mixed_or_no_single_positive_mechanism"
    return mechanisms[0] if len(mechanisms) == 1 else "mixed:" + "+".join(mechanisms)


def mechanism_audit(master: pd.DataFrame, output: Path) -> dict[str, Any]:
    result = {}
    for label, categories, filename in (
        ("2b", ["2b"], "category_2b_mechanism_summary.csv"),
        ("2c", ["2c"], "category_2c_mechanism_summary.csv"),
        ("2b+2c", ["2b", "2c"], "category_2bc_combined_summary.csv"),
    ):
        summary = summarize(master.loc[master.category.isin(categories)], label)
        summary["mechanism"] = mechanism_label(summary)
        atomic_csv(pd.DataFrame([summary]), output / filename)
        result[label] = summary
    return result


def category_groups(master: pd.DataFrame) -> list[tuple[str, pd.DataFrame]]:
    groups = [(category, master.loc[master.category == category]) for category in ("2a", "2b", "2c", "2d")]
    groups += [
        ("all_other_categories", master.loc[~master.category.isin(["2a", "2b", "2c", "2d"])]),
        ("non_2b_2c", master.loc[~master.category.isin(["2b", "2c"])]),
    ]
    return groups


def interaction_tables(master: pd.DataFrame, output: Path) -> dict[str, Any]:
    full_rows = []
    size_rows = []
    multiplicity_rows = []
    for category_label, category_frame in category_groups(master):
        for size, size_frame in category_frame.groupby("size_group", observed=False):
            size_rows.append(summarize(size_frame, f"{category_label}|{size}") | {
                "category_group": category_label, "size_group": size
            })
            for multiplicity, cell in size_frame.groupby("multiplicity_group", observed=False):
                full_rows.append(summarize(cell, f"{category_label}|{size}|{multiplicity}") | {
                    "category_group": category_label, "size_group": size,
                    "multiplicity_group": multiplicity,
                })
        for multiplicity, cell in category_frame.groupby("multiplicity_group", observed=False):
            multiplicity_rows.append(summarize(cell, f"{category_label}|{multiplicity}") | {
                "category_group": category_label, "multiplicity_group": multiplicity
            })
    atomic_csv(pd.DataFrame(full_rows), output / "category_size_multiplicity_full.csv")
    atomic_csv(pd.DataFrame(size_rows), output / "category_size_summary.csv")
    atomic_csv(pd.DataFrame(multiplicity_rows), output / "category_multiplicity_summary.csv")
    tiny = master.loc[master.size_group == "tiny_lt100"]
    tiny_2bc = tiny.loc[tiny.category.isin(["2b", "2c"])]
    tiny_non = tiny.loc[~tiny.category.isin(["2b", "2c"])]
    answers = {
        "tiny_all": summarize(tiny, "tiny_all"),
        "tiny_2b2c": summarize(tiny_2bc, "tiny_2b2c"),
        "tiny_non_2b2c": summarize(tiny_non, "tiny_non_2b2c"),
        "tiny_gain_sum_all": float(tiny.delta_dice.sum()),
        "tiny_gain_sum_2b2c": float(tiny_2bc.delta_dice.sum()),
        "tiny_gain_fraction_from_2b2c": (
            float(tiny_2bc.delta_dice.sum() / tiny.delta_dice.sum())
            if abs(float(tiny.delta_dice.sum())) > EPS else math.nan
        ),
        "2b_by_size": {
            size: summarize(group, f"2b|{size}")
            for size, group in master.loc[master.category == "2b"].groupby("size_group")
        },
        "2c_by_size": {
            size: summarize(group, f"2c|{size}")
            for size, group in master.loc[master.category == "2c"].groupby("size_group")
        },
        "2d_small": summarize(
            master.loc[(master.category == "2d") & (master.size_group == "small_100_999")],
            "2d_small",
        ),
        "2d_multi": summarize(
            master.loc[(master.category == "2d") & (master.multiplicity_group == "multiple_ge4")],
            "2d_multi",
        ),
        "2d_small_multi": summarize(
            master.loc[
                (master.category == "2d")
                & (master.size_group == "small_100_999")
                & (master.multiplicity_group == "multiple_ge4")
            ],
            "2d_small_multi",
        ),
    }
    atomic_json(answers, output / "key_interaction_answers.json")
    return answers


def bootstrap_group(
    frame: pd.DataFrame, samples: int, seed: int
) -> dict[str, Any]:
    if frame.empty:
        return {"findings": 0, "cases": 0}
    grouped = frame.groupby("case_id", sort=True).delta_dice.agg(["sum", "count"])
    sums = grouped["sum"].to_numpy(float)
    counts = grouped["count"].to_numpy(float)
    rng = np.random.default_rng(seed)
    boot = np.empty(samples, dtype=float)
    for start in range(0, samples, 250):
        count = min(250, samples - start)
        indices = rng.integers(0, len(grouped), size=(count, len(grouped)))
        boot[start : start + count] = sums[indices].sum(axis=1) / counts[indices].sum(axis=1)
    leave_one_out = []
    total_sum = float(frame.delta_dice.sum())
    total_count = len(frame)
    for case_sum, case_count in zip(sums, counts):
        if total_count > case_count:
            leave_one_out.append((total_sum - case_sum) / (total_count - case_count))
    delta = frame.delta_dice.to_numpy(float)
    return {
        "findings": len(frame), "cases": len(grouped),
        "mean_delta": float(delta.mean()), "median_delta": float(np.median(delta)),
        "case_clustered_bootstrap_ci95": [float(x) for x in np.quantile(boot, [0.025, 0.975])],
        "probability_mean_positive": float((boot > 0).mean()),
        "improved": int((delta > EPS).sum()), "degraded": int((delta < -EPS).sum()),
        "tied": int((np.abs(delta) <= EPS).sum()),
        "leave_one_case_out_range": [
            float(min(leave_one_out)) if leave_one_out else float(delta.mean()),
            float(max(leave_one_out)) if leave_one_out else float(delta.mean()),
        ],
        "bootstrap_unit": "complete case cluster",
    }


def bootstrap_audit(master: pd.DataFrame, output: Path, samples: int, seed: int) -> dict[str, Any]:
    selectors: dict[str, Callable[[pd.DataFrame], pd.Series]] = {
        "all_findings": lambda x: pd.Series(True, index=x.index),
        "2b": lambda x: x.category == "2b", "2c": lambda x: x.category == "2c",
        "2b_2c": lambda x: x.category.isin(["2b", "2c"]), "2d": lambda x: x.category == "2d",
        "tiny": lambda x: x.size_group == "tiny_lt100",
        "small": lambda x: x.size_group == "small_100_999",
        "large": lambda x: x.size_group == "large_ge10k",
        "tiny_2b_2c": lambda x: (x.size_group == "tiny_lt100") & x.category.isin(["2b", "2c"]),
        "tiny_non_2b_2c": lambda x: (x.size_group == "tiny_lt100") & ~x.category.isin(["2b", "2c"]),
        "2d_small": lambda x: (x.category == "2d") & (x.size_group == "small_100_999"),
        "2d_multi": lambda x: (x.category == "2d") & (x.multiplicity_group == "multiple_ge4"),
        "2d_small_multi": lambda x: (
            (x.category == "2d") & (x.size_group == "small_100_999")
            & (x.multiplicity_group == "multiple_ge4")
        ),
    }
    results = {
        label: bootstrap_group(master.loc[selector(master)], samples, seed + index)
        for index, (label, selector) in enumerate(selectors.items())
    }
    atomic_json(results, output / "case_clustered_bootstrap.json")
    atomic_csv(
        pd.DataFrame([{"group": key, **value} for key, value in results.items()]),
        output / "case_clustered_bootstrap.csv",
    )
    return results


def select_visuals(master: pd.DataFrame) -> pd.DataFrame:
    selected: list[dict[str, Any]] = []
    used: set[tuple[str, int]] = set()

    def add(frame: pd.DataFrame, reason: str, limit: int | None = None) -> None:
        count = 0
        for _, row in frame.iterrows():
            key = (str(row.case_id), int(row.finding_id))
            if key in used:
                continue
            selected.append({**row.to_dict(), "selection_reason": reason})
            used.add(key)
            count += 1
            if limit is not None and count >= limit:
                break

    two_d = master.loc[master.category == "2d"]
    lost = two_d.loc[two_d.baseline_global_hit & ~two_d.s3_global_hit].sort_values("delta_dice")
    add(lost, "2d_baseline_hit_to_s3_miss")
    remaining_slots = max(0, 15 - len(selected))
    add(two_d.sort_values("delta_dice"), "additional_2d_largest_degradation", min(5, remaining_slots))
    remaining_slots = max(0, 15 - len(selected))
    add(master.loc[master.category == "2b"].sort_values("delta_dice", ascending=False), "largest_2b_gain", min(3, remaining_slots))
    remaining_slots = max(0, 15 - len(selected))
    add(master.loc[master.category == "2c"].sort_values("delta_dice", ascending=False), "largest_2c_gain", min(3, remaining_slots))
    return pd.DataFrame(selected)


def display_lp(array: np.ndarray) -> np.ndarray:
    return array.T[::-1, ::-1]


def lung_window(image: np.ndarray) -> np.ndarray:
    return np.clip((image.astype(np.float32) + 1250.0) / 1500.0, 0, 1)


def crop(mask: np.ndarray, pad: int = 40) -> tuple[slice, slice]:
    if not mask.any():
        return slice(None), slice(None)
    y, x = np.where(mask)
    return (
        slice(max(0, int(y.min()) - pad), min(mask.shape[0], int(y.max()) + pad + 1)),
        slice(max(0, int(x.min()) - pad), min(mask.shape[1], int(x.max()) + pad + 1)),
    )


def overlay(gt: np.ndarray, pred: np.ndarray) -> np.ndarray:
    rgba = np.zeros((*gt.shape, 4), dtype=float)
    rgba[gt & ~pred] = (0.0, 1.0, 0.2, 0.50)
    rgba[pred & ~gt] = (1.0, 0.1, 0.1, 0.48)
    rgba[gt & pred] = (1.0, 0.9, 0.0, 0.65)
    return rgba


def render_visuals(selected: pd.DataFrame, args: argparse.Namespace) -> pd.DataFrame:
    visual_dir = args.output_dir / "visualizations"
    visual_dir.mkdir()
    records = []
    for _, row in selected.iterrows():
        case, finding = str(row.case_id), int(row.finding_id)
        gt = np.asanyarray(nib.load(str(args.gt_dir / case)).dataobj[finding]).astype(bool)
        baseline = np.asanyarray(nib.load(str(args.baseline_dir / case)).dataobj[finding]).astype(bool)
        s3 = np.asanyarray(nib.load(str(args.s3_dir / case)).dataobj[finding]).astype(bool)
        score = (gt & baseline).sum(axis=(0, 1))
        if str(row.selection_reason).startswith("largest_2"):
            score = np.maximum(score, (gt & s3).sum(axis=(0, 1)))
        z = int(score.argmax()) if score.max() else int(gt.sum(axis=(0, 1)).argmax())
        ct_proxy = nib.load(str(args.ct_dir / case)).dataobj
        ct_slice = np.asanyarray(ct_proxy[:, :, z])
        image = display_lp(lung_window(ct_slice))
        gt2, b2, s2 = display_lp(gt[:, :, z]), display_lp(baseline[:, :, z]), display_lp(s3[:, :, z])
        ys, xs = crop(gt2)
        image, gt2, b2, s2 = image[ys, xs], gt2[ys, xs], b2[ys, xs], s2[ys, xs]
        fig, axes = plt.subplots(1, 6, figsize=(22, 4), constrained_layout=True)
        panels = [
            ("CT", None), ("GT", overlay(gt2, np.zeros_like(gt2))),
            ("Baseline pred", overlay(np.zeros_like(gt2), b2)),
            ("S3 pred", overlay(np.zeros_like(gt2), s2)),
            ("Baseline / GT", overlay(gt2, b2)), ("S3 / GT", overlay(gt2, s2)),
        ]
        for ax, (title, layer) in zip(axes, panels):
            ax.imshow(image, cmap="gray", vmin=0, vmax=1)
            if layer is not None:
                ax.imshow(layer)
            ax.set_title(title)
            ax.axis("off")
        fig.suptitle(
            f"{case} finding {finding} | {row.category} | {row.selection_reason}\n"
            f"Dice {row.baseline_global_dice:.3f} -> {row.s3_global_dice:.3f} "
            f"({row.delta_dice:+.3f}) | z={z}\n{str(row.prompt)[:180]}",
            fontsize=10,
        )
        filename = f"{case.removesuffix('.nii.gz')}__f{finding:03d}.png"
        fig.savefig(visual_dir / filename, dpi=160)
        plt.close(fig)
        records.append(
            {
                "case_id": case, "finding_id": finding, "category": row.category,
                "selection_reason": row.selection_reason, "slice_z": z,
                "panel_path": str((visual_dir / filename).resolve()),
                "probability_maps_available": False, "s3_attention_map_available": False,
            }
        )
    index = pd.DataFrame(records)
    atomic_csv(index, args.output_dir / "visual_index.csv")
    return index


def markdown_table(frame: pd.DataFrame, columns: list[str], digits: int = 4) -> str:
    shown = frame[columns].copy()
    for column in shown:
        if pd.api.types.is_float_dtype(shown[column]):
            shown[column] = shown[column].map(lambda value: f"{value:.{digits}f}" if pd.notna(value) else "NA")
    header = "| " + " | ".join(columns) + " |"
    divider = "| " + " | ".join(["---"] * len(columns)) + " |"
    rows = ["| " + " | ".join(map(str, row)) + " |" for row in shown.itertuples(index=False, name=None)]
    return "\n".join([header, divider, *rows])


def write_report(
    args: argparse.Namespace,
    reproduction: dict[str, Any],
    master: pd.DataFrame,
    two_d: dict[str, Any],
    mechanisms: dict[str, Any],
    interactions: dict[str, Any],
    bootstraps: dict[str, Any],
    runtime: float,
) -> None:
    category = pd.DataFrame(
        [
            summarize(master.loc[master.category == value], value)
            for value in sorted(master.category.unique())
        ]
    )
    size = pd.DataFrame(
        [
            summarize(master.loc[master.size_group == value], value)
            for value in ["tiny_lt100", "small_100_999", "medium_1k_9999", "large_ge10k"]
        ]
    )
    lost = master.loc[
        (master.category == "2d") & master.baseline_global_hit & ~master.s3_global_hit
    ]
    mechanism_lines = [
        f"- {key}: `{value['mechanism']}`; Dice {value['delta_dice']:+.4f}, "
        f"precision {value['delta_precision']:+.4f}, recall {value['delta_recall']:+.4f}, "
        f"FP/GT {value['delta_fp_per_gt']:+.4f}, FN/GT {value['delta_fn_per_gt']:+.4f}."
        for key, value in mechanisms.items()
    ]
    lines = [
        "# Baseline vs S3 update-9000 paired failure-mode audit", "",
        "## Scope and lineage", "",
        f"- Baseline checkpoint: `{BASELINE_CHECKPOINT}`.",
        f"- S3 checkpoint: `{S3_CHECKPOINT}`.",
        f"- Baseline predictions: `{args.baseline_dir}`.",
        f"- S3 predictions: `{args.s3_dir}`.",
        f"- Manifest: `{args.dataset_json}`; GT: `{args.gt_dir}`.",
        "- This compares two separately trained checkpoints; differences describe model behavior and are not attributed solely to the attention operation.",
        "", "## Reproduction and conventions", "",
        f"- Exactly {len(master)} aligned findings / {master.case_id.nunique()} cases.",
        f"- Overall Dice {reproduction['overall']['baseline_dice']:.6f} -> {reproduction['overall']['s3_dice']:.6f}; "
        f"hits {reproduction['overall']['baseline_hits']} -> {reproduction['overall']['s3_hits']}.",
        "- Hit: official global Dice >= 0.1. Binary threshold: 0.5 at inference.",
        "- Components: SciPy 3D 18-neighbor connectivity. Prediction components <10 voxels are excluded from component descriptors, matching evaluator defaults; global Dice/TP/FP/FN use raw saved binary masks.",
        "- GT components are unfiltered. Matching preserves every non-zero GT-prediction overlap and does not force one-to-one assignments.",
        "", "## Category behavior", "",
        markdown_table(category, ["group", "findings", "baseline_dice", "s3_dice", "delta_dice", "baseline_hits", "s3_hits"]),
        "", "## Size behavior", "",
        markdown_table(size, ["group", "findings", "baseline_dice", "s3_dice", "delta_dice", "baseline_hits", "s3_hits"]),
        "", "## 2d lost-hit answer", "",
        f"- Transitions: `{two_d['transitions']}`; net five lost hits.",
        f"- {len(lost)} baseline-hit -> S3-miss findings; operational labels: `{two_d['failure_counts']}`.",
        "- Exact per-case TP/FP/FN, coverage, component detection and detached-FP behavior are in `category_2d_lost_hit_detailed.csv`.",
        "- Threshold-edge behavior remains unavailable because neither full-volume run saved probabilities/logits; the report does not infer it from binary masks.",
        "", "## 2b/2c mechanism answer", "", *mechanism_lines,
        "", "## Category-size independence answer", "",
        f"- Tiny overall Dice delta: {interactions['tiny_all']['delta_dice']:+.4f}.",
        f"- Tiny 2b/2c delta: {interactions['tiny_2b2c']['delta_dice']:+.4f} "
        f"(n={interactions['tiny_2b2c']['findings']}).",
        f"- Tiny non-2b/2c delta: {interactions['tiny_non_2b2c']['delta_dice']:+.4f} "
        f"(n={interactions['tiny_non_2b2c']['findings']}).",
        f"- Fraction of the summed tiny-finding gain contributed by 2b/2c: "
        f"{interactions['tiny_gain_fraction_from_2b2c']:.3f}.",
        "- Full size and multiplicity crossings are in `category_size_multiplicity_full.csv`; cells with n<5 are marked descriptive-only.",
        "", "## Case-clustered statistics", "",
        markdown_table(
            pd.DataFrame([{"group": key, **value} for key, value in bootstraps.items()]),
            ["group", "findings", "cases", "mean_delta", "median_delta", "probability_mean_positive"],
        ),
        "", "## Visualizations and unavailable data", "",
        "- Binary CT/GT/baseline/S3 panels and their index are under `visualizations/` and `visual_index.csv`.",
        "- Full-run probability/logit and S3 attention maps were not present. Selected-case regeneration is a separate optional GPU step; no all-381 inference was run.",
        "", "## Code reuse and changes", "",
        "- Reused official definitions from `data/rexrank_eval.py` and metadata/voxel conventions from `scripts/summarize_rex_global_eval.py`.",
        "- Reused component conventions from `scripts/evaluate_low_threshold_component_oracle.py` and case-bootstrap design from `scripts/collect_prompt_residual_fullval.py`.",
        "- Added `scripts/audit_baseline_vs_s3_9000_failure_modes.py` and focused tests.",
        "", "## Runtime", "", f"- CPU audit runtime: {runtime / 60:.1f} minutes.",
        "- No SLURM inference job was required for the binary-mask audit.",
        "", "## Output inventory", "",
        "- `per_finding_failure_mode_master.csv`",
        "- `component_matching_baseline.csv`, `component_matching_s3.csv`",
        "- `component_overlap_pairs_baseline.csv`, `component_overlap_pairs_s3.csv`",
        "- `category_2d_hit_transition.csv`, `category_2d_lost_hit_detailed.csv`",
        "- `category_2b_mechanism_summary.csv`, `category_2c_mechanism_summary.csv`, `category_2bc_combined_summary.csv`",
        "- `category_size_multiplicity_full.csv`, category-size and category-multiplicity summaries",
        "- `case_clustered_bootstrap.csv/json`, `key_interaction_answers.json`",
        "- `visual_index.csv`, `visualizations/*.png`, `metric_definition.json`, `artifact_audit.json`",
    ]
    (args.output_dir / "baseline_vs_s3_9000_failure_mode_audit_summary.md").write_text(
        "\n".join(lines) + "\n"
    )


def main() -> int:
    args = parse_args()
    started = time.time()
    args.output_dir.mkdir(parents=True, exist_ok=False)
    metadata = read_metadata(args.dataset_json)
    baseline = load_metric_table(args.baseline_dir, True)
    s3 = load_metric_table(args.s3_dir, False)
    base_master = assemble_base_master(metadata, baseline, s3)
    reproduction = reproduce_known_metrics(baseline, s3)
    cases = [
        {
            "case_id": case,
            "findings": group[["finding_id", "category", "prompt"]].to_dict("records"),
        }
        for case, group in metadata.groupby("case_id", sort=True)
    ]
    tasks = [
        (case, str(args.gt_dir), str(args.baseline_dir), str(args.s3_dir))
        for case in cases
    ]
    component_master: list[dict[str, Any]] = []
    matching: dict[str, list[dict[str, Any]]] = {"baseline": [], "s3": []}
    pairs: dict[str, list[dict[str, Any]]] = {"baseline": [], "s3": []}
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for index, result in enumerate(pool.map(analyze_case, tasks), start=1):
            component_master.extend(result["master"])
            for model in ("baseline", "s3"):
                matching[model].extend(result["matching"][model])
                pairs[model].extend(result["pairs"][model])
            if index % 10 == 0:
                print(f"component audit: {index}/{len(tasks)} cases", flush=True)
    components = pd.DataFrame(component_master)
    master = base_master.merge(
        components, on=["case_id", "finding_id", "category", "prompt"], validate="one_to_one"
    )
    master = add_deltas(master).sort_values(["case_id", "finding_id"]).reset_index(drop=True)
    if len(master) != 381 or master.duplicated(["case_id", "finding_id"]).any():
        raise AssertionError("Final master table is not exactly 381 unique findings")
    for model in ("baseline", "s3"):
        component_recall = master[f"{model}_gt_component_detection_recall"]
        if not component_recall.between(0, 1).all():
            raise AssertionError(f"{model}: component recall outside [0,1]")
        matching_frame = pd.DataFrame(matching[model])
        pred_rows = matching_frame.loc[matching_frame.row_type == "pred_component"]
        detached = pred_rows.loc[~pred_rows.overlaps_any.astype(bool)]
        if (detached.total_overlap_voxels != 0).any():
            raise AssertionError(f"{model}: detached component overlaps GT")
        atomic_csv(matching_frame, args.output_dir / f"component_matching_{model}.csv")
        atomic_csv(pd.DataFrame(pairs[model]), args.output_dir / f"component_overlap_pairs_{model}.csv")
    atomic_csv(master, args.output_dir / "per_finding_failure_mode_master.csv")
    try:
        master.to_parquet(args.output_dir / "per_finding_failure_mode_master.parquet", index=False)
    except (ImportError, ValueError):
        pass
    component_summary = pd.DataFrame(
        [
            summarize(master, "all"),
            *[summarize(master.loc[master.category == category], category) for category in sorted(master.category.unique())],
        ]
    )
    atomic_csv(component_summary, args.output_dir / "component_matching_summary.csv")
    metric_definition = {
        "binary_threshold": 0.5,
        "hit_definition": "official global Dice >= 0.1",
        "global_metrics": "raw saved binary prediction masks; epsilon-smoothed official Dice is read from evaluator outputs",
        "component_connectivity": "3D 18-neighbor; scipy.ndimage.generate_binary_structure(3, 2)",
        "prediction_component_minimum_voxels": MIN_PRED_COMPONENT_VOXELS,
        "gt_component_minimum_voxels": 1,
        "matching": "full sparse matrix of all non-zero overlaps; no forced one-to-one assignment",
        "gt_component_detection": "any overlap with a retained prediction component",
        "volume_weighted_gt_component_coverage": "sum of all covered GT voxels / total GT voxels",
        "volume_weighted_max_component_coverage": "GT-volume-weighted maximum single-prediction coverage per GT component",
        "detached_fp_component": "retained prediction component with zero GT overlap",
        "size_groups": {
            "tiny_lt100": "<100", "small_100_999": "100-999",
            "medium_1k_9999": "1000-9999", "large_ge10k": ">=10000",
        },
        "multiplicity_groups": {"single": 1, "few_2_3": "2-3", "multiple_ge4": ">=4"},
        "lost_hit_operational_thresholds": {
            "coverage_shrinkage": "absolute recall or weighted max-component coverage drop >=0.10",
            "fragmentation": ">=2 extra overlapping predicted components and coverage drop >=0.10",
        },
        "bootstrap": "resample complete cases with replacement and recompute pooled finding mean",
    }
    atomic_json(metric_definition, args.output_dir / "metric_definition.json")
    two_d = category_2d_audit(master, args.output_dir)
    mechanisms = mechanism_audit(master, args.output_dir)
    interactions = interaction_tables(master, args.output_dir)
    bootstraps = bootstrap_audit(
        master, args.output_dir, args.bootstrap_samples, args.seed
    )
    selected = select_visuals(master)
    render_visuals(selected, args)
    artifact_audit = {
        "baseline_checkpoint": str(BASELINE_CHECKPOINT.resolve()),
        "s3_checkpoint": str(S3_CHECKPOINT.resolve()),
        "baseline_prediction_dir": str(args.baseline_dir.resolve()),
        "s3_prediction_dir": str(args.s3_dir.resolve()),
        "baseline_prediction_files": len(list(args.baseline_dir.glob("*.nii.gz"))),
        "s3_prediction_files": len(list(args.s3_dir.glob("*.nii.gz"))),
        "manifest": str(args.dataset_json.resolve()),
        "gt_dir": str(args.gt_dir.resolve()),
        "aligned_cases": int(master.case_id.nunique()),
        "aligned_findings": len(master),
        "probability_maps_found": False,
        "attention_maps_found": False,
        "reproduction": reproduction,
        "commands": [" ".join(os.sys.argv)],
    }
    atomic_json(artifact_audit, args.output_dir / "artifact_audit.json")
    runtime = time.time() - started
    write_report(
        args, reproduction, master, two_d, mechanisms, interactions, bootstraps, runtime
    )
    atomic_json(
        {
            "status": "complete", "runtime_seconds": runtime,
            "cases": int(master.case_id.nunique()), "findings": len(master),
        },
        args.output_dir / "run_status.json",
    )
    print(json.dumps({"status": "complete", "runtime_seconds": runtime}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
