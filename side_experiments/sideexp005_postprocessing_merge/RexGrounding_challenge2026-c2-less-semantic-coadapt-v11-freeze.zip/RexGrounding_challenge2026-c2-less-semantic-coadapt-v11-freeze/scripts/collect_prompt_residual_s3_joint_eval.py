#!/usr/bin/env python3
"""Collect fixed-30 summaries for the weak-S3 continuation experiment."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    rows = []
    for summary in sorted(args.root.glob("*_update_*/summary.json")):
        payload = json.loads(summary.read_text())
        rows.append(
            {
                "run": payload["run"],
                "mean_global_dice_per_finding": payload[
                    "mean_global_dice_per_finding"
                ],
                "mean_global_dice_per_case": payload[
                    "mean_global_dice_per_case"
                ],
                "hits": payload["total_hits"],
                "findings": payload["total_findings"],
            }
        )
    (args.root / "comparison.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
