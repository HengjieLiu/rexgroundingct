#!/usr/bin/env python3
"""Limited BF16 token-grounding audit for common-init A1 and A2-FAN."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT, ROOT / "VoxTell"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from scripts.diagnose_token_image_text_phase0 import (  # noqa: E402
    clean_piece,
    key,
    load_image,
    load_maps,
    load_reference_mask_for_window_diagnostic,
    means,
    pad_and_crop,
    ratio,
    readable_word_groups,
)
from scripts.diagnose_token_image_text_phase0b_gate import (  # noqa: E402
    make_predictor,
    run_model,
    selected_records,
)
from scripts.run_controlled_fixed30_validation import (  # noqa: E402
    DEFAULT_CACHE,
    build_manifest,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=("A1_replace", "A2_FAN"), required=True)
    parser.add_argument("--update", type=int, choices=(0, 250, 500), required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--token-cache",
        type=Path,
        default=ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt",
    )
    parser.add_argument("--pooled-cache", type=Path, default=DEFAULT_CACHE)
    parser.add_argument(
        "--selected-findings",
        type=Path,
        default=ROOT / "outputs/prompt_standardization_rule_only_v1/stratified30_six_variant_ablation_v1/prepared_inputs/selected_findings.csv",
    )
    parser.add_argument(
        "--dataset-json", type=Path, default=ROOT / "data/MICCAI_challenge_dataset.json"
    )
    parser.add_argument("--max-findings", type=int, default=8)
    return parser.parse_args()


def distribution_summary(
    weights: torch.Tensor,
    valid_mask: torch.Tensor,
    *,
    rows_are_normalized: bool,
) -> dict[str, float | int]:
    """Summarize [..., query, text] without treating weights as probabilities."""
    valid = valid_mask.detach().bool().flatten().cpu()
    values = weights.detach().float().cpu()[..., valid]
    text_mass = values.sum(dim=-1)
    normalized = values / text_mass.unsqueeze(-1).clamp_min(1e-12)
    entropy = -(normalized.clamp_min(1e-12) * normalized.clamp_min(1e-12).log()).sum(-1)
    n_text = int(valid.sum().item())
    topk = min(3, n_text)
    return {
        "valid_text_tokens": n_text,
        "row_normalized_by_attention": int(rows_are_normalized),
        "text_mass_mean": float(text_mass.mean().item()),
        "text_mass_std": float(text_mass.std().item()),
        "normalized_entropy_mean": float(
            (entropy / max(math.log(max(n_text, 2)), 1e-12)).mean().item()
        ),
        "effective_token_count_mean": float(entropy.exp().mean().item()),
        "maximum_token_share_mean": float(normalized.amax(dim=-1).mean().item()),
        "top3_token_share_mean": float(
            normalized.topk(topk, dim=-1).values.sum(dim=-1).mean().item()
        ),
        "querywise_token_std_mean": float(
            normalized.mean(dim=0).std(dim=-2).mean().item()
        ),
    }


def top_tokens(weights: torch.Tensor, strings: list[str], count: int = 8) -> list[dict[str, Any]]:
    average = weights.detach().float().cpu().mean(dim=tuple(range(weights.ndim - 1)))
    normalized = average / average.sum().clamp_min(1e-12)
    indices = normalized.topk(min(count, normalized.numel())).indices.tolist()
    return [
        {
            "index": int(index),
            "token": strings[index],
            "clean_token": clean_piece(strings[index]),
            "mean_share": float(normalized[index].item()),
        }
        for index in indices
    ]


def relation_rows(
    *,
    arm: str,
    update: int,
    record: dict[str, Any],
    mechanism: str,
    scale: str,
    attention: torch.Tensor,
    token_strings: list[str],
    target_small: torch.Tensor,
    lobe_small: torch.Tensor | None,
) -> list[dict[str, Any]]:
    """Compute exploratory correct-region/opposite-region attention ratios."""
    rows: list[dict[str, Any]] = []
    word_groups = readable_word_groups(token_strings)
    prompt = str(record["prompt"])
    base = {
        "arm": arm,
        "update": update,
        "case": record["case"],
        "finding_idx": record["finding_idx"],
        "finding": prompt,
        "mechanism": mechanism,
        "scale": scale,
    }
    # attention: [heads, image, text]
    mean_head = attention.detach().float().cpu().mean(dim=0)
    spatial_shape = tuple(target_small.shape)
    maps = mean_head.reshape(*spatial_shape, mean_head.shape[-1]).permute(3, 0, 1, 2)
    pathology_words = {
        "bronchiectasis", "nodule", "nodular", "ground", "ggo",
        "opacity", "consolidation", "scarring", "scar",
    }
    for word, indices in word_groups:
        attention_map = maps[indices].mean(dim=0)
        token_base = {
            **base,
            "token": word,
            "token_indices": "+".join(map(str, indices)),
        }
        if word in {"left", "right"} and lobe_small is not None:
            left = lobe_small >= 4
            right = (lobe_small >= 1) & (lobe_small <= 3)
            correct, opposite = (left, right) if word == "left" else (right, left)
            inside, outside = means(attention_map, correct), means(attention_map, opposite)
            if math.isfinite(inside) and math.isfinite(outside):
                rows.append({**token_base, "metric": "laterality", "inside_mean": inside,
                             "outside_mean": outside, "ratio": ratio(inside, outside)})
        if word in pathology_words:
            relevant = (lobe_small > 0) if lobe_small is not None else torch.ones_like(target_small)
            outside_mask = relevant & ~target_small
            inside, outside = means(attention_map, target_small), means(attention_map, outside_mask)
            if math.isfinite(inside) and math.isfinite(outside):
                rows.append({**token_base, "metric": "pathology_gt", "inside_mean": inside,
                             "outside_mean": outside, "ratio": ratio(inside, outside)})

    text = prompt.lower()
    sides = {side for side in ("left", "right") if side in text}
    levels = {level for level in ("upper", "lower") if f"{level} lobe" in text}
    if lobe_small is not None and len(sides) == 1 and len(levels) == 1:
        labels = {
            ("right", "upper"): 1, ("right", "lower"): 3,
            ("left", "upper"): 4, ("left", "lower"): 5,
        }
        mentioned = lobe_small == labels[(next(iter(sides)), next(iter(levels)))]
        other = (lobe_small > 0) & ~mentioned
        indices = [
            index
            for word, group in word_groups
            if word in {"upper", "lower", "lobe"}
            for index in group
        ]
        if indices:
            attention_map = maps[indices].mean(dim=0)
            inside, outside = means(attention_map, mentioned), means(attention_map, other)
            if math.isfinite(inside) and math.isfinite(outside):
                rows.append({**base, "token": "lobe_phrase",
                             "token_indices": "+".join(map(str, indices)), "metric": "lobe",
                             "inside_mean": inside, "outside_mean": outside,
                             "ratio": ratio(inside, outside)})
    return rows


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    keys: list[str] = []
    for row in rows:
        for field in row:
            if field not in keys:
                keys.append(field)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.experiment_dir = args.output_dir
    manifest_path, _, selection_sha = build_manifest(args)
    records = selected_records(json.loads(manifest_path.read_text()), args.max_findings)
    token_map, pooled_map = load_maps(args.token_cache, args.pooled_cache)
    device = torch.device("cuda")
    predictor = make_predictor(
        args.output_dir, f"{args.arm}_u{args.update}", args.checkpoint, device
    )
    model = predictor.network.eval().to(device)
    if args.arm == "A1_replace":
        model.capture_token_image_text_attention = True
    else:
        model.capture_fan_image_text_attention = True

    summaries: list[dict[str, Any]] = []
    ratios: list[dict[str, Any]] = []
    for record in records:
        cache_key = key(record)
        token = token_map[cache_key]
        image, properties = load_image(ROOT / "data/ct_rate_volumes_fixed" / record["case"])
        data, bbox, original_shape = predictor.preprocess(image)
        target = load_reference_mask_for_window_diagnostic(
            ROOT / "data/segmentations" / record["case"],
            1,
            tuple(original_shape),
            bbox,
            image_properties=properties,
            finding_ids=[record["finding_idx"]],
        )[0]
        patch, target_patch, starts, padding = pad_and_crop(data, target)
        pooled = pooled_map[cache_key][None, None].to(device)
        contextual = token["feature"][None, None].to(device)
        valid = torch.ones(contextual.shape[:3], dtype=torch.bool, device=device)
        _ = run_model(
            model,
            patch[None].to(device),
            pooled,
            contextual,
            valid,
            torch.bfloat16,
        )

        stem = record["case"].removesuffix(".nii.gz").removesuffix(".nii")
        lobe_path = ROOT / "data/rex_lobe_labels_preprocessed_v1/val" / f"{stem}.npz"
        lobe_patch = None
        if lobe_path.is_file():
            with np.load(lobe_path) as payload:
                lobe = torch.from_numpy(np.asarray(payload["lobe_label"], dtype=np.uint8))
            lobe_padded = F.pad(lobe, padding)
            lobe_patch = lobe_padded[
                tuple(slice(start, start + 192) for start in starts)
            ]

        mechanisms: list[tuple[str, str, torch.Tensor, bool, tuple[int, int, int]]] = []
        if args.arm == "A1_replace":
            mechanisms.append((
                "image_to_word_cross", "level4",
                model.last_token_image_text_attention[0][0], True, (12, 12, 12),
            ))
        else:
            for level in (4, 5):
                label = f"level{level}"
                captured = model.last_fan_image_text_attention[label]
                audit = model.last_fan_image_text_audits[label]
                n_image = int(audit["n_image"])
                n_text = int(audit["n_text"])
                joint = captured["joint"][0, 0, :, :n_image, n_image:n_image + n_text]
                cross = captured["image_to_word"][0, 0]
                shape = tuple(map(int, audit["spatial_shape"]))
                mechanisms.extend((
                    ("joint_image_to_word_slice", label, joint, False, shape),
                    ("image_to_word_cross", label, cross, True, shape),
                ))

        strings = list(token["strings"])
        for mechanism, scale, attention, normalized, spatial_shape in mechanisms:
            target_small = F.adaptive_max_pool3d(
                target_patch[None, None].float(), output_size=spatial_shape
            )[0, 0].bool()
            lobe_small = None
            if lobe_patch is not None:
                lobe_small = F.interpolate(
                    lobe_patch[None, None].float(), size=spatial_shape, mode="nearest"
                )[0, 0].to(torch.uint8)
            summaries.append({
                "arm": args.arm,
                "update": args.update,
                "case": record["case"],
                "finding_idx": record["finding_idx"],
                "finding": record["prompt"],
                "mechanism": mechanism,
                "scale": scale,
                "attention_shape": list(attention.shape),
                **distribution_summary(attention, valid[0, 0], rows_are_normalized=normalized),
                "top_tokens": top_tokens(attention, strings),
            })
            ratios.extend(relation_rows(
                arm=args.arm,
                update=args.update,
                record=record,
                mechanism=mechanism,
                scale=scale,
                attention=attention,
                token_strings=strings,
                target_small=target_small,
                lobe_small=lobe_small,
            ))
        del mechanisms
        torch.cuda.empty_cache()

    output = {
        "arm": args.arm,
        "update": args.update,
        "checkpoint": str(args.checkpoint.resolve()),
        "precision": "bfloat16",
        "selected_findings_sha256": selection_sha,
        "samples": summaries,
        "attention_is_calibrated_probability": False,
        "anatomy_masks_used_as_model_input": False,
    }
    (args.output_dir / "attention_summary.json").write_text(
        json.dumps(output, indent=2, sort_keys=True) + "\n"
    )
    write_csv(args.output_dir / "grounding_ratios.csv", ratios)
    print(json.dumps({"samples": len(records), "summaries": len(summaries), "ratios": len(ratios)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
