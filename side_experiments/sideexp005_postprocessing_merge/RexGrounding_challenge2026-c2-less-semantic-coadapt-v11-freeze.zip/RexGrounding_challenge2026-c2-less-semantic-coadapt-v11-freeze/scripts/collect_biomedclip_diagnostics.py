#!/usr/bin/env python3
"""Collect the BCLIP update-0 and PBT warm-swap fixed30 summaries."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def summary(path: Path) -> dict:
    value = json.loads(path.read_text())
    return {
        "label": "matched_bclip_update0" if "matched_update0" in str(path) else "pbt_cls_7200_bclip_direct_swap",
        "checkpoint": value["checkpoint"],
        "dice": value["mean_dice_per_finding"],
        "hit_count": value["hit_count"],
        "hit_rate": value["hit_rate"],
        "mean_predicted_voxels": value["mean_predicted_voxels"],
        "fixed30_findings": value["findings"],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    root = args.run_dir
    bclip = root / "matched_update0" / "full_volume/update_00000/controlled_summary.json"
    swap = root / "warm_swap_diagnostic" / "full_volume/update_07200/controlled_summary.json"
    rows = [summary(bclip), summary(swap)]
    for row in rows:
        if row["label"] == "pbt_cls_7200_bclip_direct_swap":
            row["reference_pbt_cls_7200_dice"] = 0.27927477976751197
            row["retention_ratio_vs_pbt_cls_7200"] = row["dice"] / 0.27927477976751197
            row["interpretation"] = "INTERFACE-COMPATIBILITY DIAGNOSTIC; not the primary encoder comparison"
    pd.DataFrame(rows).to_csv(root / "warm_swap_diagnostic.csv", index=False)
    print(root / "warm_swap_diagnostic.csv")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
