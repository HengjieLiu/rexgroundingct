#!/usr/bin/env python3
"""Create a ReX JSON containing only selected finding categories.

Original numeric finding keys are deliberately preserved. This lets inference
look up the canonical cached embedding and lets a later merge restore each
prediction to its original reference-mask channel.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path


FINDING_KEYED_FIELDS = ("findings", "entity_counts", "pixels", "categories")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-json", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--summary-json", type=Path, required=True)
    parser.add_argument("--splits", nargs="+", default=["val"])
    parser.add_argument("--categories", nargs="+", default=["2b", "2c"])
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    for path in (args.output_json, args.summary_json):
        if path.exists() and not args.overwrite:
            raise FileExistsError(f"Refusing to overwrite existing output: {path}")

    source = json.loads(args.input_json.read_text())
    wanted = {str(value) for value in args.categories}
    filtered = {split: [] for split in source}
    category_counts: Counter[str] = Counter()
    original_findings = 0
    retained_findings = 0
    original_cases = 0
    retained_cases = 0

    for split, entries in source.items():
        if split not in args.splits:
            filtered[split] = entries
            continue
        for original in entries:
            original_cases += 1
            categories = original.get("categories") or {}
            original_findings += len(original.get("findings") or {})
            retained_keys = [
                key
                for key in sorted(original.get("findings") or {}, key=lambda x: int(x))
                if str(categories.get(key)) in wanted
            ]
            if not retained_keys:
                continue
            entry = dict(original)
            for field in FINDING_KEYED_FIELDS:
                values = original.get(field)
                if values is not None:
                    entry[field] = {key: values[key] for key in retained_keys}
            filtered[split].append(entry)
            retained_cases += 1
            retained_findings += len(retained_keys)
            category_counts.update(str(categories[key]) for key in retained_keys)

    summary = {
        "source_json": str(args.input_json.resolve()),
        "output_json": str(args.output_json.resolve()),
        "splits_filtered": args.splits,
        "categories_retained": sorted(wanted),
        "original_cases": original_cases,
        "retained_cases": retained_cases,
        "original_findings": original_findings,
        "retained_findings": retained_findings,
        "retained_findings_by_category": dict(sorted(category_counts.items())),
        "original_numeric_finding_keys_preserved": True,
        "empty_cases_omitted": True,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.summary_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(filtered, indent=2) + "\n")
    args.summary_json.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
