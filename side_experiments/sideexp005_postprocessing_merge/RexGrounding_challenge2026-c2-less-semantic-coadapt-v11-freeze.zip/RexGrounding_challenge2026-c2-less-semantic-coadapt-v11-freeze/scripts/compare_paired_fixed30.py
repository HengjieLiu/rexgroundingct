#!/usr/bin/env python3
"""Paired finding-level comparison with bootstrap confidence interval."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


ENTITY_KEYWORDS = {
    "nodule_mass": ("nodule", "nodular", "mass"),
    "ground_glass": ("ground-glass", "ground glass", "ggo"),
    "consolidation": ("consolidation", "consolidative"),
    "atelectasis": ("atelectasis", "atelectatic"),
    "effusion": ("effusion",),
    "bronchiectasis": ("bronchiectasis", "bronchiectatic"),
    "bronchial_wall": ("bronchial wall", "peribronchial"),
    "emphysema": ("emphysema", "emphysematous"),
    "fibrosis_scarring": ("fibrosis", "fibrotic", "scar", "scarring"),
    "cyst": ("cyst", "cystic"),
    "calcification": ("calcification", "calcified"),
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--control", type=Path, required=True)
    parser.add_argument("--experiment", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260723)
    parser.add_argument("--bootstrap", type=int, default=10000)
    return parser.parse_args()


def entity_group(prompt: str) -> str:
    text = str(prompt).lower()
    matches = [
        name
        for name, keywords in ENTITY_KEYWORDS.items()
        if any(keyword in text for keyword in keywords)
    ]
    return "+".join(matches) if matches else "other"


def summarize_group(frame: pd.DataFrame, group_type: str, group: str) -> dict:
    delta = frame.dice_experiment - frame.dice_control
    return {
        "group_type": group_type,
        "group": group,
        "n_findings": int(len(frame)),
        "control_mean_dice": float(frame.dice_control.mean()),
        "experiment_mean_dice": float(frame.dice_experiment.mean()),
        "mean_paired_dice_delta": float(delta.mean()),
        "control_hit_rate": float(frame.hit_control.mean()),
        "experiment_hit_rate": float(frame.hit_experiment.mean()),
        "new_hits": int(((frame.hit_control == 0) & (frame.hit_experiment == 1)).sum()),
        "lost_hits": int(((frame.hit_control == 1) & (frame.hit_experiment == 0)).sum()),
        "control_mean_fp_voxels": float(frame.fp_voxels_control.mean()),
        "experiment_mean_fp_voxels": float(frame.fp_voxels_experiment.mean()),
        "control_mean_pred_voxels": float(frame.pred_voxels_control.mean()),
        "experiment_mean_pred_voxels": float(frame.pred_voxels_experiment.mean()),
    }


def subgroup_analysis(merged: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    prompt_col = "prompt_control" if "prompt_control" in merged else "prompt"
    gt_col = "gt_voxels_control" if "gt_voxels_control" in merged else "gt_voxels"
    counts = merged.groupby("case_id").finding_idx.transform("count")
    merged["case_finding_group"] = np.where(counts > 1, "multi_finding", "single_finding")

    size_cutoff = float(merged[gt_col].median())
    merged["lesion_size_group"] = np.where(
        merged[gt_col] <= size_cutoff, "small_le_median", "large_gt_median"
    )

    merged["entity_group"] = merged[prompt_col].map(entity_group)
    entity_counts = merged.groupby(["case_id", "entity_group"]).finding_idx.transform("count")
    merged["same_entity_group"] = np.where(
        (merged.entity_group != "other") & (entity_counts > 1),
        "same_entity_within_ct",
        "not_same_entity_within_ct",
    )

    rows = []
    for group_type, column in (
        ("case_findings", "case_finding_group"),
        ("lesion_size", "lesion_size_group"),
        ("same_entity", "same_entity_group"),
    ):
        for group, frame in merged.groupby(column, sort=True):
            rows.append(summarize_group(frame, group_type, str(group)))
    metadata = {
        "small_lesion_definition": f"{gt_col} <= fixed-subset median",
        "small_lesion_gt_voxel_cutoff": size_cutoff,
        "multi_finding_definition": "more than one evaluated finding in the same CT",
        "same_entity_definition": (
            "at least two findings in the same CT share a non-other keyword entity group"
        ),
        "entity_keyword_groups": ENTITY_KEYWORDS,
    }
    return pd.DataFrame(rows), metadata


def main():
    args = parse_args()
    control = pd.read_csv(args.control)
    experiment = pd.read_csv(args.experiment)
    keys = ["case_id", "finding_idx"]
    merged = control.merge(
        experiment, on=keys, suffixes=("_control", "_experiment"), validate="one_to_one"
    )
    if len(merged) != 49:
        raise ValueError(f"Expected 49 paired findings, got {len(merged)}")
    delta = (merged.dice_experiment - merged.dice_control).to_numpy()
    rng = np.random.default_rng(args.seed)
    samples = rng.choice(delta, size=(args.bootstrap, len(delta)), replace=True).mean(axis=1)
    report = {
        "n_findings": len(merged),
        "control_mean_dice": float(merged.dice_control.mean()),
        "experiment_mean_dice": float(merged.dice_experiment.mean()),
        "mean_paired_dice_delta": float(delta.mean()),
        "bootstrap_95_ci": [float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))],
        "new_hits": int(((merged.hit_control == 0) & (merged.hit_experiment == 1)).sum()),
        "lost_hits": int(((merged.hit_control == 1) & (merged.hit_experiment == 0)).sum()),
        "control_hit_rate": float(merged.hit_control.mean()),
        "experiment_hit_rate": float(merged.hit_experiment.mean()),
        "control_mean_fp_voxels": float(merged.fp_voxels_control.mean()),
        "experiment_mean_fp_voxels": float(merged.fp_voxels_experiment.mean()),
        "control_empty": int(merged.empty_prediction_control.sum()),
        "experiment_empty": int(merged.empty_prediction_experiment.sum()),
    }
    subgroups, subgroup_metadata = subgroup_analysis(merged)
    report["subgroup_definitions"] = subgroup_metadata
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    merged.to_csv(args.output.with_suffix(".paired.csv"), index=False)
    subgroups.to_csv(args.output.with_suffix(".subgroups.csv"), index=False)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
