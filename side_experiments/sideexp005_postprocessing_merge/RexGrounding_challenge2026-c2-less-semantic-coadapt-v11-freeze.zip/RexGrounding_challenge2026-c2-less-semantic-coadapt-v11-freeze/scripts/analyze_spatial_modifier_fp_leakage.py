#!/usr/bin/env python3
"""Analyze spatial-modifier false-positive leakage from saved binary predictions.

This is analysis-only. It reconstructs raw, whole-lung-10-mm, and frozen
semantic-v1 predictions from the saved threshold-0.5 baseline mask. GT is used
only for retrospective TP/FP measurements, never for ROI selection.
"""

from __future__ import annotations

import argparse
import json
import math
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import pandas as pd
from scipy import ndimage
from tqdm import tqdm

from evaluate_anatomy_prior_ablation import channel_first_mask
from evaluate_anatomy_prior_diagnostic import (
    LOBE_FILES,
    geometry_reference,
    load_prior,
)
from evaluate_semantic_aware_lobe_constraint_part1 import semantic_parse


LOBE_ORDER = ("LUL", "LLL", "RUL", "RML", "RLL")
LEFT_LOBES = ("LUL", "LLL")
RIGHT_LOBES = ("RUL", "RML", "RLL")
SIDE_LOBES = {"left": LEFT_LOBES, "right": RIGHT_LOBES}
POLICIES = ("raw", "whole10", "semantic_v1")
HIT_THRESHOLD = 0.1
CONNECTIVITY_26 = np.ones((3, 3, 3), dtype=np.uint8)
ROI_VERSIONS = {
    "semantic_selected": "semantic_selected_roi",
    "strict_side": "strict_side_roi",
    "strict_exact_lobe": "strict_exact_lobe_roi",
    "whole_lung_10mm": "whole_lung_10mm_roi",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pred-dir", type=Path, required=True)
    parser.add_argument("--gt-dir", type=Path, required=True)
    parser.add_argument("--ct-dir", type=Path, required=True)
    parser.add_argument("--prior-dir", type=Path, required=True)
    parser.add_argument("--findings-csv", type=Path, required=True)
    parser.add_argument("--parser-assignments", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--num-shards", type=int, default=1)
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--num-workers", type=int, default=1)
    return parser.parse_args()


def split_lobes(value: Any) -> list[str]:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return []
    return [item for item in str(value).replace(",", ";").split(";") if item]


def safe_ratio(numerator: int | float, denominator: int | float) -> float:
    return float(numerator / denominator) if denominator > 0 else float("nan")


def dice_score(pred: np.ndarray, gt: np.ndarray) -> float:
    pred_n = int(np.count_nonzero(pred))
    gt_n = int(np.count_nonzero(gt))
    denominator = pred_n + gt_n
    return 1.0 if denominator == 0 else 2.0 * int(np.count_nonzero(pred & gt)) / denominator


def dilate_mm(mask: np.ndarray, sampling: tuple[float, float, float], mm: float) -> np.ndarray:
    if not np.any(mask):
        return mask.copy()
    return ndimage.distance_transform_edt(~mask, sampling=sampling) <= float(mm)


def roi_measurements(
    pred: np.ndarray,
    fp: np.ndarray,
    tp: np.ndarray,
    gt: np.ndarray,
    roi: np.ndarray | None,
    voxel_volume: float,
) -> dict[str, Any]:
    if roi is None:
        return {
            "available": False,
            "pred_outside": float("nan"),
            "fp_outside": float("nan"),
            "pred_outside_ratio": float("nan"),
            "fp_outside_ratio": float("nan"),
            "tp_retention": float("nan"),
            "gt_retention": float("nan"),
        }
    pred_n = int(np.count_nonzero(pred))
    fp_n = int(np.count_nonzero(fp))
    tp_n = int(np.count_nonzero(tp))
    gt_n = int(np.count_nonzero(gt))
    pred_outside_n = int(np.count_nonzero(pred & ~roi))
    fp_outside_n = int(np.count_nonzero(fp & ~roi))
    tp_inside_n = int(np.count_nonzero(tp & roi))
    gt_inside_n = int(np.count_nonzero(gt & roi))
    return {
        "available": True,
        "pred_outside": pred_outside_n * voxel_volume,
        "fp_outside": fp_outside_n * voxel_volume,
        "pred_outside_ratio": safe_ratio(pred_outside_n, pred_n),
        "fp_outside_ratio": safe_ratio(fp_outside_n, fp_n),
        "tp_retention": safe_ratio(tp_inside_n, tp_n),
        "gt_retention": safe_ratio(gt_inside_n, gt_n),
    }


def dominant_compartment(counts: dict[str, int], total: int) -> str:
    if total <= 0:
        return "empty"
    nonzero = {key: value for key, value in counts.items() if value > 0}
    if not nonzero:
        return "unassigned"
    winner, count = max(nonzero.items(), key=lambda item: item[1])
    return winner if count / total >= 0.95 else "crossing_mixed"


def component_rows(
    pred: np.ndarray,
    gt: np.ndarray,
    specified_roi: np.ndarray,
    strict_masks: dict[str, np.ndarray | None],
    affine: np.ndarray,
    voxel_volume: float,
    base_row: dict[str, Any],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not np.any(pred):
        return [], {
            "num_pred_components": 0,
            "num_fp_components": 0,
            "num_components_fully_outside_roi": 0,
            "num_components_outside_roi": 0,
            "num_components_centroid_outside_roi": 0,
            "num_components_peak_outside_roi": float("nan"),
            "num_components_in_other_lobes": 0,
            "num_components_in_contralateral_lung": 0,
            "num_components_outside_whole_lung": 0,
            "largest_outside_roi_component_volume": 0.0,
            "largest_other_lobe_component_volume": 0.0,
            "largest_contralateral_component_volume": 0.0,
        }

    bounding = ndimage.find_objects(pred.astype(np.uint8), max_label=1)[0]
    cropped = pred[bounding]
    labels, count = ndimage.label(cropped, structure=CONNECTIVITY_26)
    objects = ndimage.find_objects(labels)
    rows: list[dict[str, Any]] = []
    for component_id, local_slice in enumerate(objects, start=1):
        if local_slice is None:
            continue
        label_view = labels[local_slice]
        component = label_view == component_id
        starts = [
            int(bounding[axis].start or 0) + int(local_slice[axis].start or 0)
            for axis in range(3)
        ]
        stops = [
            int(bounding[axis].start or 0) + int(local_slice[axis].stop)
            for axis in range(3)
        ]
        global_slice = tuple(slice(starts[axis], stops[axis]) for axis in range(3))
        gt_view = gt[global_slice]
        roi_view = specified_roi[global_slice]
        whole_view = strict_masks["whole"][global_slice]  # type: ignore[index]
        component_n = int(np.count_nonzero(component))
        tp_n = int(np.count_nonzero(component & gt_view))
        fp_n = component_n - tp_n
        outside_roi_n = int(np.count_nonzero(component & ~roi_view))
        centroid_local = ndimage.center_of_mass(component)
        centroid_voxel = tuple(
            float(starts[axis]) + float(centroid_local[axis]) for axis in range(3)
        )
        centroid_index = tuple(
            min(max(int(round(value)), 0), pred.shape[axis] - 1)
            for axis, value in enumerate(centroid_voxel)
        )
        centroid_world = nib.affines.apply_affine(affine, np.asarray(centroid_voxel))

        compartment_counts: dict[str, int] = {}
        target_exact = strict_masks.get("target_exact")
        target_side = strict_masks.get("target_side")
        other_ipsilateral = strict_masks.get("other_ipsilateral")
        contralateral = strict_masks.get("contralateral")
        other_lobes = strict_masks.get("other_lobes")
        outside_whole_n = int(np.count_nonzero(component & ~whole_view))

        target_exact_n = (
            int(np.count_nonzero(component & target_exact[global_slice]))
            if target_exact is not None
            else 0
        )
        target_side_n = (
            int(np.count_nonzero(component & target_side[global_slice]))
            if target_side is not None
            else 0
        )
        other_ipsilateral_n = (
            int(np.count_nonzero(component & other_ipsilateral[global_slice]))
            if other_ipsilateral is not None
            else 0
        )
        contralateral_n = (
            int(np.count_nonzero(component & contralateral[global_slice]))
            if contralateral is not None
            else 0
        )
        other_lobes_n = (
            int(np.count_nonzero(component & other_lobes[global_slice]))
            if other_lobes is not None
            else 0
        )
        within_whole_n = int(np.count_nonzero(component & whole_view))

        if target_exact is not None:
            compartment_counts["target_lobe"] = target_exact_n
            if other_ipsilateral is not None:
                compartment_counts["other_ipsilateral_lobe"] = other_ipsilateral_n
            if other_lobes is not None:
                compartment_counts["other_lobes"] = other_lobes_n
            if contralateral is not None:
                compartment_counts["contralateral_lung"] = contralateral_n
            accounted_inside = (
                target_exact_n + other_ipsilateral_n + other_lobes_n + contralateral_n
            )
        elif target_side is not None:
            compartment_counts["target_side_lung"] = target_side_n
            compartment_counts["contralateral_lung"] = contralateral_n
            accounted_inside = target_side_n + contralateral_n
        else:
            compartment_counts["within_whole_lung_unspecified"] = within_whole_n
            accounted_inside = within_whole_n
        compartment_counts["within_lung_unassigned"] = max(
            0, within_whole_n - accounted_inside
        )
        compartment_counts["outside_whole_lung"] = outside_whole_n

        rows.append(
            {
                **base_row,
                "component_id": component_id,
                "component_volume": component_n * voxel_volume,
                "component_voxels": component_n,
                "component_tp_volume": tp_n * voxel_volume,
                "component_fp_volume": fp_n * voxel_volume,
                "overlaps_gt": tp_n > 0,
                "is_fp_component": tp_n == 0,
                "fully_outside_specified_roi": outside_roi_n == component_n,
                "centroid_outside_specified_roi": not bool(
                    specified_roi[centroid_index]
                ),
                "peak_probability_available": False,
                "peak_probability": float("nan"),
                "peak_voxel_x": float("nan"),
                "peak_voxel_y": float("nan"),
                "peak_voxel_z": float("nan"),
                "peak_outside_specified_roi": float("nan"),
                "centroid_voxel_x": centroid_voxel[0],
                "centroid_voxel_y": centroid_voxel[1],
                "centroid_voxel_z": centroid_voxel[2],
                "centroid_world_x_mm": float(centroid_world[0]),
                "centroid_world_y_mm": float(centroid_world[1]),
                "centroid_world_z_mm": float(centroid_world[2]),
                "assigned_anatomical_compartment": dominant_compartment(
                    compartment_counts, component_n
                ),
                "target_lobe_volume": target_exact_n * voxel_volume,
                "target_side_lung_volume": target_side_n * voxel_volume,
                "other_ipsilateral_lobe_volume": other_ipsilateral_n * voxel_volume,
                "other_lobes_volume": other_lobes_n * voxel_volume,
                "contralateral_lung_volume": contralateral_n * voxel_volume,
                "outside_whole_lung_volume": outside_whole_n * voxel_volume,
                "outside_specified_roi_volume": outside_roi_n * voxel_volume,
                "overlaps_other_lobes": (other_ipsilateral_n + other_lobes_n) > 0,
                "overlaps_contralateral_lung": contralateral_n > 0,
                "overlaps_outside_whole_lung": outside_whole_n > 0,
            }
        )

    summary = {
        "num_pred_components": len(rows),
        "num_fp_components": sum(bool(row["is_fp_component"]) for row in rows),
        "num_components_fully_outside_roi": sum(
            bool(row["fully_outside_specified_roi"]) for row in rows
        ),
        "num_components_outside_roi": sum(
            bool(row["fully_outside_specified_roi"]) for row in rows
        ),
        "num_components_centroid_outside_roi": sum(
            bool(row["centroid_outside_specified_roi"]) for row in rows
        ),
        "num_components_peak_outside_roi": float("nan"),
        "num_components_in_other_lobes": sum(
            bool(row["overlaps_other_lobes"]) for row in rows
        ),
        "num_components_in_contralateral_lung": sum(
            bool(row["overlaps_contralateral_lung"]) for row in rows
        ),
        "num_components_outside_whole_lung": sum(
            bool(row["overlaps_outside_whole_lung"]) for row in rows
        ),
        "largest_outside_roi_component_volume": max(
            (
                float(row["component_volume"])
                for row in rows
                if bool(row["fully_outside_specified_roi"])
            ),
            default=0.0,
        ),
        "largest_other_lobe_component_volume": max(
            (
                float(row["component_volume"])
                for row in rows
                if bool(row["overlaps_other_lobes"])
            ),
            default=0.0,
        ),
        "largest_contralateral_component_volume": max(
            (
                float(row["component_volume"])
                for row in rows
                if bool(row["overlaps_contralateral_lung"])
            ),
            default=0.0,
        ),
    }
    return rows, summary


def process_case(task: tuple[str, list[dict[str, Any]], dict[str, str]]) -> dict[str, Any]:
    case, findings, settings = task
    pred, pred_ref = channel_first_mask(
        Path(settings["pred_dir"]) / case, 0.5, False
    )
    gt, _ = channel_first_mask(Path(settings["gt_dir"]) / case, 0.5, False)
    if pred.shape != gt.shape:
        raise ValueError(f"{case}: prediction {pred.shape} != GT {gt.shape}")
    ref = geometry_reference(case, pred_ref, Path(settings["ct_dir"]))
    sampling = tuple(float(value) for value in nib.affines.voxel_sizes(ref.affine)[:3])
    voxel_volume = float(abs(np.linalg.det(ref.affine[:3, :3])))
    prior_dir = Path(settings["prior_dir"])
    priors = {
        "whole": load_prior(prior_dir, case, "whole_lung", ref),
        "whole10": load_prior(prior_dir, case, "lung_dilated_10mm", ref),
    }
    case_lobes = {
        lobe
        for finding in findings
        for lobe in split_lobes(finding.get("lobes"))
    }
    case_sides = {
        str(finding.get("side"))
        for finding in findings
        if str(finding.get("side")) in {"left", "right"}
    }
    if case_lobes:
        for lobe, filename in LOBE_FILES.items():
            priors[lobe] = load_prior(prior_dir, case, filename, ref)
        priors["left"] = priors["LUL"] | priors["LLL"]
        priors["right"] = priors["RUL"] | priors["RML"] | priors["RLL"]
    elif case_sides:
        priors["left"] = load_prior(prior_dir, case, "left_lung", ref)
        priors["right"] = load_prior(prior_dir, case, "right_lung", ref)
    for name, mask in priors.items():
        if mask.shape != pred.shape[1:]:
            raise ValueError(f"{case}: prior {name} {mask.shape} != {pred.shape[1:]}")

    roi_cache: dict[tuple[str, ...], np.ndarray] = {}

    def exact_roi(lobes: list[str]) -> np.ndarray | None:
        valid = tuple(sorted({lobe for lobe in lobes if lobe in LOBE_ORDER}))
        if not valid:
            return None
        key = ("exact15", *valid)
        if key not in roi_cache:
            base = np.logical_or.reduce([priors[lobe] for lobe in valid])
            roi_cache[key] = dilate_mm(base, sampling, 15)
        return roi_cache[key]

    def side_roi(side: str | None) -> np.ndarray | None:
        if side not in ("left", "right"):
            return None
        key = ("side15", side)
        if key not in roi_cache:
            roi_cache[key] = dilate_mm(priors[side], sampling, 15)
        return roi_cache[key]

    finding_rows: list[dict[str, Any]] = []
    all_components: list[dict[str, Any]] = []
    parser_mismatches = 0
    for finding in findings:
        finding_id = int(finding["finding_id"])
        if finding_id >= pred.shape[0]:
            raise IndexError(f"{case}: finding {finding_id} outside {pred.shape[0]} channels")
        parsed = semantic_parse(str(finding["finding_text"]))
        lobes = split_lobes(finding.get("lobes"))
        side_value = finding.get("side")
        side = None if pd.isna(side_value) else str(side_value)
        group = str(finding["group"])
        if (
            parsed["group"] != group
            or (parsed.get("side") or None) != side
            or sorted(parsed.get("lobes") or []) != sorted(lobes)
        ):
            parser_mismatches += 1
        raw = pred[finding_id]
        gt_mask = gt[finding_id]
        strict_exact = exact_roi(lobes)
        strict_side = side_roi(side)
        if group == "high_conf_exact_lobe" and strict_exact is not None:
            semantic_roi = strict_exact
            selected_roi_kind = "exact_lobe"
            selected_roi_label = ";".join(lobes)
            selected_dilation_mm = 15
        elif group in {
            "high_conf_exact_lobe",
            "ambiguous_lobe",
            "laterality_only",
        } and strict_side is not None:
            semantic_roi = strict_side
            selected_roi_kind = "side_lung"
            selected_roi_label = str(side)
            selected_dilation_mm = 15
        else:
            semantic_roi = priors["whole10"]
            selected_roi_kind = "whole_lung"
            selected_roi_label = "whole"
            selected_dilation_mm = 10

        has_spatial_modifier = group != "nonlocalizable"
        parser_localizable = selected_roi_kind in {"exact_lobe", "side_lung"}
        exact_available = strict_exact is not None
        side_available = strict_side is not None
        explicit_lobe_parser_defined = bool(lobes)

        target_exact: np.ndarray | None = None
        target_side: np.ndarray | None = None
        other_ipsilateral: np.ndarray | None = None
        contralateral: np.ndarray | None = None
        other_lobes: np.ndarray | None = None
        unilateral_target_side: str | None = None
        if lobes:
            target_exact = np.logical_or.reduce([priors[lobe] for lobe in lobes])
            lobe_sides = {
                "left" if lobe in LEFT_LOBES else "right" for lobe in lobes
            }
            if len(lobe_sides) == 1:
                unilateral_target_side = next(iter(lobe_sides))
                ipsilateral_names = SIDE_LOBES[unilateral_target_side]
                other_names = [name for name in ipsilateral_names if name not in lobes]
                other_ipsilateral = (
                    np.logical_or.reduce([priors[name] for name in other_names])
                    if other_names
                    else np.zeros_like(priors["whole"])
                )
                contralateral = priors[
                    "right" if unilateral_target_side == "left" else "left"
                ]
            else:
                other_lobes = priors["whole"] & ~target_exact
        elif side in ("left", "right"):
            unilateral_target_side = side
            target_side = priors[side]
            contralateral = priors["right" if side == "left" else "left"]

        strict_masks: dict[str, np.ndarray | None] = {
            "whole": priors["whole"],
            "target_exact": target_exact,
            "target_side": target_side,
            "other_ipsilateral": other_ipsilateral,
            "other_lobes": other_lobes,
            "contralateral": contralateral,
        }
        roi_versions = {
            "semantic_selected": semantic_roi,
            "strict_side": strict_side,
            "strict_exact_lobe": strict_exact,
            "whole_lung_10mm": priors["whole10"],
        }

        raw_tp_n = int(np.count_nonzero(raw & gt_mask))
        policies = {
            "raw": raw,
            "whole10": raw & priors["whole10"],
            "semantic_v1": raw & semantic_roi,
        }
        for policy, policy_pred in policies.items():
            fp = policy_pred & ~gt_mask
            tp = policy_pred & gt_mask
            pred_n = int(np.count_nonzero(policy_pred))
            fp_n = int(np.count_nonzero(fp))
            tp_n = int(np.count_nonzero(tp))
            gt_n = int(np.count_nonzero(gt_mask))
            core = roi_measurements(
                policy_pred, fp, tp, gt_mask, semantic_roi, voxel_volume
            )
            row: dict[str, Any] = {
                "case_id": case,
                "finding_id": finding_id,
                "finding_text": finding["finding_text"],
                "category": finding.get("category"),
                "parser_group": group,
                "parsed_side": side,
                "parsed_lobes": ";".join(lobes),
                "matched_phrases": finding.get("matched_phrases", ""),
                "has_spatial_modifier": has_spatial_modifier,
                "parser_localizable": parser_localizable,
                "exact_lobe_available": exact_available,
                "side_available": side_available,
                "explicit_lobe_parser_defined": explicit_lobe_parser_defined,
                "policy": policy,
                "prediction_threshold": 0.5,
                "volume_unit": "mm3",
                "voxel_volume_mm3": voxel_volume,
                "selected_roi_kind": selected_roi_kind,
                "selected_roi_label": selected_roi_label,
                "selected_roi_dilation_mm": selected_dilation_mm,
                "roi_selection_uses_gt": False,
                "probability_available": False,
                "dice": dice_score(policy_pred, gt_mask),
                "hit": dice_score(policy_pred, gt_mask) >= HIT_THRESHOLD,
                "pred_volume_total": pred_n * voxel_volume,
                "fp_volume_total": fp_n * voxel_volume,
                "tp_volume_total": tp_n * voxel_volume,
                "gt_volume_total": gt_n * voxel_volume,
                "pred_voxels_total": pred_n,
                "fp_voxels_total": fp_n,
                "tp_voxels_total": tp_n,
                "gt_voxels_total": gt_n,
                "pred_volume_outside_specified_roi": core["pred_outside"],
                "fp_volume_outside_specified_roi": core["fp_outside"],
                "pred_outside_roi_ratio": core["pred_outside_ratio"],
                "fp_outside_roi_ratio": core["fp_outside_ratio"],
                "tp_retention_inside_roi": core["tp_retention"],
                "gt_retention_inside_roi": core["gt_retention"],
                "tp_retention_vs_raw": safe_ratio(tp_n, raw_tp_n),
                "no_prediction": pred_n == 0,
                "no_fp": fp_n == 0,
                "no_gt": gt_n == 0,
                "other_lobe_analysis_applicable": target_exact is not None,
                "contralateral_analysis_applicable": contralateral is not None,
            }
            for suffix, roi in roi_versions.items():
                values = roi_measurements(
                    policy_pred, fp, tp, gt_mask, roi, voxel_volume
                )
                row[f"{suffix}_available"] = values["available"]
                row[f"pred_volume_outside_{suffix}"] = values["pred_outside"]
                row[f"fp_volume_outside_{suffix}"] = values["fp_outside"]
                row[f"pred_outside_{suffix}_ratio"] = values["pred_outside_ratio"]
                row[f"fp_outside_{suffix}_ratio"] = values["fp_outside_ratio"]
                row[f"tp_retention_inside_{suffix}"] = values["tp_retention"]
                row[f"gt_retention_inside_{suffix}"] = values["gt_retention"]

            def compartment_count(mask: np.ndarray | None, foreground: np.ndarray) -> int:
                return (
                    int(np.count_nonzero(foreground & mask))
                    if mask is not None
                    else 0
                )

            compartment_masks = {
                "target_exact_lobe": target_exact,
                "other_ipsilateral_lobes": other_ipsilateral,
                "target_side_lung": (
                    priors[unilateral_target_side]
                    if unilateral_target_side in ("left", "right")
                    else None
                ),
                "contralateral_lung": contralateral,
                "outside_whole_lung": ~priors["whole"],
            }
            for name, mask in compartment_masks.items():
                row[f"pred_volume_{name}"] = (
                    compartment_count(mask, policy_pred) * voxel_volume
                )
                row[f"fp_volume_{name}"] = compartment_count(mask, fp) * voxel_volume

            component_base = {
                key: row[key]
                for key in (
                    "case_id",
                    "finding_id",
                    "finding_text",
                    "category",
                    "parser_group",
                    "parsed_side",
                    "parsed_lobes",
                    "has_spatial_modifier",
                    "parser_localizable",
                    "policy",
                    "selected_roi_kind",
                    "selected_roi_label",
                    "selected_roi_dilation_mm",
                )
            }
            components, component_summary = component_rows(
                policy_pred,
                gt_mask,
                semantic_roi,
                strict_masks,
                ref.affine,
                voxel_volume,
                component_base,
            )
            row.update(component_summary)
            all_components.extend(components)
            finding_rows.append(row)

    return {
        "case": case,
        "finding_rows": finding_rows,
        "component_rows": all_components,
        "quality": {
            "case": case,
            "findings": len(findings),
            "prediction_shape": list(pred.shape),
            "spatial_shape": list(pred.shape[1:]),
            "voxel_volume_mm3": voxel_volume,
            "parser_mismatches": parser_mismatches,
            "mask_alignment_pass": True,
            "probability_available": False,
        },
    }


def main() -> int:
    args = parse_args()
    if not 0 <= args.shard_index < args.num_shards:
        raise ValueError("shard-index must be in [0, num-shards)")
    findings = pd.read_csv(args.findings_csv).rename(
        columns={"finding_idx": "finding_id", "prompt": "finding_text"}
    )
    assignments = pd.read_csv(args.parser_assignments)
    # Accept both the original parser-assignment schema and the explicit
    # names emitted by the frozen fixed-30 preparation step.
    aliases = {
        "parser_group": "group",
        "parsed_side": "side",
        "parsed_lobes": "lobes",
    }
    assignments = assignments.rename(
        columns={source: target for source, target in aliases.items() if target not in assignments}
    )
    merged = findings.merge(
        assignments,
        on=["case_id", "finding_id"],
        how="inner",
        suffixes=("", "_parser"),
        validate="one_to_one",
    )
    if len(merged) != len(findings):
        raise RuntimeError(
            f"Parser assignment coverage mismatch: {len(merged)} != {len(findings)}"
        )
    if "finding_text_parser" in merged:
        mismatch = (
            merged["finding_text"].fillna("").astype(str)
            != merged["finding_text_parser"].fillna("").astype(str)
        )
        if mismatch.any():
            raise RuntimeError(f"{int(mismatch.sum())} finding-text mismatches")
    cases = sorted(merged["case_id"].unique())
    selected_cases = [
        case
        for index, case in enumerate(cases)
        if index % args.num_shards == args.shard_index
    ]
    settings = {
        "pred_dir": str(args.pred_dir),
        "gt_dir": str(args.gt_dir),
        "ct_dir": str(args.ct_dir),
        "prior_dir": str(args.prior_dir),
    }
    tasks = [
        (
            case,
            merged[merged["case_id"] == case].to_dict(orient="records"),
            settings,
        )
        for case in selected_cases
    ]
    results: list[dict[str, Any]] = []
    with ProcessPoolExecutor(max_workers=max(1, args.num_workers)) as pool:
        futures = [pool.submit(process_case, task) for task in tasks]
        for future in tqdm(
            as_completed(futures),
            total=len(futures),
            desc=f"spatial leakage shard {args.shard_index}",
        ):
            results.append(future.result())
    finding_rows = [
        row for result in results for row in result["finding_rows"]
    ]
    component_rows_output = [
        row for result in results for row in result["component_rows"]
    ]
    quality = [result["quality"] for result in results]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    per_finding_path = (
        args.output_dir / "spatial_modifier_fp_leakage_per_finding.csv"
    )
    components_path = (
        args.output_dir / "spatial_modifier_fp_leakage_components.csv"
    )
    pd.DataFrame(finding_rows).sort_values(
        ["case_id", "finding_id", "policy"]
    ).to_csv(per_finding_path, index=False)
    pd.DataFrame(component_rows_output).sort_values(
        ["case_id", "finding_id", "policy", "component_id"]
    ).to_csv(components_path, index=False)
    payload = {
        "shard_index": args.shard_index,
        "num_shards": args.num_shards,
        "cases": len(selected_cases),
        "findings": len(finding_rows) // len(POLICIES),
        "policy_rows": len(finding_rows),
        "component_rows": len(component_rows_output),
        "parser_mismatches": sum(item["parser_mismatches"] for item in quality),
        "mask_alignment_failures": sum(
            not item["mask_alignment_pass"] for item in quality
        ),
        "probability_availability": "unavailable_for_full_381",
        "cases_detail": quality,
    }
    (args.output_dir / "quality_checks.json").write_text(
        json.dumps(payload, indent=2) + "\n"
    )
    print(json.dumps({key: value for key, value in payload.items() if key != "cases_detail"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
