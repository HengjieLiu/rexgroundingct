#!/usr/bin/env python3
"""Feature/logit sensitivity audit for E3 A2-FAN semantic-grounding checkpoints.

This is a mechanistic, patch-level audit.  For each selected fixed30 finding it
runs the same cropped patch under:

  correct FAN tokens, shuffled FAN tokens, neutral FAN token, cross-category
  shuffled FAN tokens, and FAN bypass.

The global VoxTell whole-sentence embedding is kept correct in every condition.
The script records how much the FAN enriched skip tensors and final mask logits
move relative to the correct-token run.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
for candidate in (ROOT, ROOT / "VoxTell"):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from scripts.diagnose_token_image_text_phase0 import (  # noqa: E402
    key,
    pad_and_crop,
)
from scripts.diagnose_token_image_text_phase0b_gate import (  # noqa: E402
    make_predictor,
    selected_records,
)
from scripts.run_controlled_fixed30_validation import (  # noqa: E402
    DEFAULT_CACHE,
    DEFAULT_SELECTION,
    build_manifest,
)
from scripts.run_voxtell_rex_inference import (  # noqa: E402
    load_image,
    load_reference_mask_for_window_diagnostic,
)


CONDITIONS = (
    "correct",
    "shuffled",
    "neutral",
    "cross_category_shuffled",
    "fan_bypass",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--experiment-root",
        type=Path,
        default=ROOT / "outputs/a2_fan_preserve_semantic_grounding_v11_5000",
    )
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--update", type=int, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--token-cache",
        type=Path,
        default=ROOT
        / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt",
    )
    parser.add_argument("--pooled-cache", type=Path, default=DEFAULT_CACHE)
    parser.add_argument("--selected-findings", type=Path, default=DEFAULT_SELECTION)
    parser.add_argument(
        "--dataset-json",
        type=Path,
        default=ROOT / "data/MICCAI_challenge_dataset.json",
    )
    parser.add_argument("--max-findings", type=int, default=16)
    parser.add_argument(
        "--amp-dtype", choices=["bfloat16", "float16", "none"], default="bfloat16"
    )
    return parser.parse_args()


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    fieldnames: list[str] = []
    for row in rows:
        for name in row:
            if name not in fieldnames:
                fieldnames.append(name)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def atomic_json(path: Path, payload: object) -> None:
    temporary = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def tensor_rms(tensor: torch.Tensor) -> float:
    value = tensor.detach().float()
    return float(value.square().mean().sqrt().item())


def tensor_mean_abs(tensor: torch.Tensor) -> float:
    return float(tensor.detach().float().abs().mean().item())


def tensor_max_abs(tensor: torch.Tensor) -> float:
    return float(tensor.detach().float().abs().amax().item())


def cosine_flat(left: torch.Tensor, right: torch.Tensor) -> float:
    lhs = left.detach().float().reshape(-1)
    rhs = right.detach().float().reshape(-1)
    if lhs.numel() == 0:
        return float("nan")
    return float(F.cosine_similarity(lhs, rhs, dim=0).item())


def dice_from_logits(logits: torch.Tensor, target: torch.Tensor) -> dict[str, float | int]:
    probs = torch.sigmoid(logits.detach().float().cpu())
    pred = probs > 0.5
    truth = target.cpu().bool()
    intersection = int((pred & truth).sum().item())
    pred_voxels = int(pred.sum().item())
    truth_voxels = int(truth.sum().item())
    denominator = pred_voxels + truth_voxels
    dice = (2.0 * intersection / denominator) if denominator else 1.0
    return {
        "patch_dice": float(dice),
        "patch_pred_voxels": pred_voxels,
        "patch_truth_voxels": truth_voxels,
        "patch_intersection_voxels": intersection,
    }


def output_to_logits(output: torch.Tensor | list[torch.Tensor]) -> torch.Tensor:
    logits = output[0] if isinstance(output, list) else output
    if logits.ndim == 5:
        return logits[0, 0].detach().float().cpu()
    if logits.ndim == 4:
        return logits[0].detach().float().cpu()
    raise ValueError(f"Unexpected model output shape: {tuple(logits.shape)}")


def load_token_and_pooled_maps(token_path: Path, pooled_path: Path) -> tuple[dict, dict, dict, list]:
    token_payload = torch.load(token_path, map_location="cpu", weights_only=False)
    pooled_payload = torch.load(pooled_path, map_location="cpu", weights_only=False)
    token_records = list(token_payload.get("records") or [])
    token_values = list(token_payload.get("token_features") or [])
    if len(token_records) != len(token_values):
        raise ValueError(f"Invalid token cache: {token_path}")
    token_map: dict[tuple[str, str, int], torch.Tensor] = {}
    record_map: dict[tuple[str, str, int], dict[str, Any]] = {}
    for record, value in zip(token_records, token_values):
        cache_key = (str(record["split"]), str(record["case"]), int(record["finding_idx"]))
        token_map[cache_key] = value
        record_map[cache_key] = dict(record)
    pooled_map = {
        (str(record["split"]), str(record["case"]), int(record["finding_idx"])): value.float()
        for record, value in zip(pooled_payload["records"], pooled_payload["embeddings"])
    }
    return token_map, pooled_map, record_map, sorted(token_map)


def build_condition_cache(
    token_map: dict[tuple[str, str, int], torch.Tensor],
    record_map: dict[tuple[str, str, int], dict[str, Any]],
    sorted_keys: list[tuple[str, str, int]],
) -> dict[str, dict[tuple[str, str, int], torch.Tensor]]:
    if not token_map:
        raise ValueError("Empty token map")
    first = next(iter(token_map.values()))
    hidden = int(first.shape[1])
    accumulator = torch.zeros(hidden, dtype=torch.float32)
    count = 0
    for value in token_map.values():
        if value.ndim != 2 or int(value.shape[1]) != hidden:
            raise ValueError("Token cache contains incompatible token feature shapes")
        accumulator += value.float().sum(dim=0)
        count += int(value.shape[0])
    if count <= 0:
        raise ValueError("Token cache contains no token vectors")
    neutral = (accumulator / float(count)).to(dtype=first.dtype).unsqueeze(0)

    def source_for(cache_key: tuple[str, str, int], cross_category: bool) -> tuple[str, str, int]:
        own_record = record_map[cache_key]
        own_case = cache_key[1]
        own_category = str(own_record.get("category", ""))
        own_index = sorted_keys.index(cache_key)
        for offset in range(1, len(sorted_keys) + 1):
            candidate = sorted_keys[(own_index + offset) % len(sorted_keys)]
            candidate_record = record_map[candidate]
            if candidate == cache_key or candidate[1] == own_case:
                continue
            if cross_category and str(candidate_record.get("category", "")) == own_category:
                continue
            return candidate
        raise ValueError(f"Could not find shuffled token source for {cache_key}")

    return {
        "correct": dict(token_map),
        "neutral": {cache_key: neutral for cache_key in sorted_keys},
        "shuffled": {
            cache_key: token_map[source_for(cache_key, False)] for cache_key in sorted_keys
        },
        "cross_category_shuffled": {
            cache_key: token_map[source_for(cache_key, True)] for cache_key in sorted_keys
        },
    }


def install_fan_feature_hooks(model: torch.nn.Module, store: dict[str, dict[str, torch.Tensor]]) -> list[Any]:
    hooks: list[Any] = []
    projections = getattr(model, "fan_image_text_fusion_projections", None)
    if not projections:
        raise RuntimeError("Model has no FAN preserve fusion projections")

    def make_hook(level_name: str):
        def hook(_module: torch.nn.Module, inputs: tuple[torch.Tensor, ...], output: torch.Tensor) -> None:
            visual, fan = inputs[:2]
            store[level_name] = {
                "visual": visual.detach().float().cpu(),
                "fan": fan.detach().float().cpu(),
                "enriched": output.detach().float().cpu(),
            }

        return hook

    for level_name, module in projections.items():
        hooks.append(module.register_forward_hook(make_hook(level_name)))
    return hooks


def run_condition(
    *,
    model: torch.nn.Module,
    patch: torch.Tensor,
    pooled: torch.Tensor,
    token_value: torch.Tensor | None,
    condition: str,
    amp_dtype: torch.dtype | None,
    feature_store: dict[str, dict[str, torch.Tensor]],
) -> tuple[torch.Tensor, dict[str, Any], dict[str, dict[str, torch.Tensor]]]:
    feature_store.clear()
    original_mode = getattr(model, "fan_image_text_mode", "none")
    model_dtype = next(model.parameters()).dtype
    model.capture_fan_image_text_attention = True
    model.capture_fan_image_text_logits = True
    try:
        if condition == "fan_bypass":
            model.fan_image_text_mode = "none"
            token_features = None
            token_valid_mask = None
        else:
            model.fan_image_text_mode = original_mode
            if token_value is None:
                raise ValueError(f"{condition} requires token features")
            token_features = token_value[None, None].to(
                device=patch.device, dtype=model_dtype
            )
            token_valid_mask = torch.ones(
                token_features.shape[:3], device=patch.device, dtype=torch.bool
            )
        with torch.inference_mode():
            context = (
                torch.autocast("cuda", dtype=amp_dtype)
                if amp_dtype is not None and patch.device.type == "cuda"
                else torch.autocast("cpu", enabled=False)
            )
            with context:
                output = model(
                    patch.to(dtype=model_dtype),
                    pooled.to(dtype=model_dtype),
                    token_features=token_features,
                    token_valid_mask=token_valid_mask,
                )
    finally:
        model.fan_image_text_mode = original_mode

    logits = output_to_logits(output)
    audit = dict(getattr(model, "last_fan_image_text_audits", {}))
    captured = {
        level: {name: value.clone() for name, value in tensors.items()}
        for level, tensors in feature_store.items()
    }
    return logits, audit, captured


def compare_logits(reference: torch.Tensor, candidate: torch.Tensor) -> dict[str, float]:
    delta = candidate - reference
    ref_rms = max(tensor_rms(reference), 1e-12)
    prob_ref = torch.sigmoid(reference.float())
    prob_candidate = torch.sigmoid(candidate.float())
    pred_ref = prob_ref > 0.5
    pred_candidate = prob_candidate > 0.5
    return {
        "logit_delta_rms": tensor_rms(delta),
        "logit_delta_rel_rms": tensor_rms(delta) / ref_rms,
        "logit_delta_mean_abs": tensor_mean_abs(delta),
        "logit_delta_max_abs": tensor_max_abs(delta),
        "prob_delta_mean_abs": tensor_mean_abs(prob_candidate - prob_ref),
        "prob_delta_max_abs": tensor_max_abs(prob_candidate - prob_ref),
        "binary_disagreement_fraction": float((pred_candidate != pred_ref).float().mean().item()),
        "binary_disagreement_voxels": int((pred_candidate != pred_ref).sum().item()),
    }


def compare_features(
    reference: dict[str, dict[str, torch.Tensor]],
    candidate: dict[str, dict[str, torch.Tensor]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for level in sorted(reference):
        ref = reference[level]
        cand = candidate.get(level)
        ref_visual = ref["visual"]
        ref_fan = ref["fan"]
        ref_enriched = ref["enriched"]
        visual_rms = max(tensor_rms(ref_visual), 1e-12)
        enriched_rms = max(tensor_rms(ref_enriched), 1e-12)
        branch_delta = ref_enriched - ref_visual
        row: dict[str, Any] = {
            "level": level,
            "correct_visual_rms": tensor_rms(ref_visual),
            "correct_fan_rms": tensor_rms(ref_fan),
            "correct_enriched_rms": tensor_rms(ref_enriched),
            "correct_branch_delta_rms": tensor_rms(branch_delta),
            "correct_branch_delta_rel_visual": tensor_rms(branch_delta) / visual_rms,
            "correct_enriched_visual_cosine": cosine_flat(ref_enriched, ref_visual),
        }
        if cand is not None:
            enriched_delta = cand["enriched"] - ref_enriched
            fan_delta = cand["fan"] - ref_fan
            row.update(
                {
                    "condition_enriched_delta_rms": tensor_rms(enriched_delta),
                    "condition_enriched_delta_rel_correct": tensor_rms(enriched_delta)
                    / enriched_rms,
                    "condition_enriched_delta_rel_branch_delta": tensor_rms(enriched_delta)
                    / max(tensor_rms(branch_delta), 1e-12),
                    "condition_enriched_cosine_with_correct": cosine_flat(
                        cand["enriched"], ref_enriched
                    ),
                    "condition_fan_delta_rms": tensor_rms(fan_delta),
                    "condition_fan_delta_rel_correct": tensor_rms(fan_delta)
                    / max(tensor_rms(ref_fan), 1e-12),
                    "condition_fan_cosine_with_correct": cosine_flat(cand["fan"], ref_fan),
                }
            )
        return_missing = cand is None
        row["condition_has_fan_features"] = not return_missing
        rows.append(row)
    return rows


def mean_or_none(values: list[float]) -> float | None:
    finite = [float(value) for value in values if math.isfinite(float(value))]
    return (sum(finite) / len(finite)) if finite else None


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not args.checkpoint.is_file():
        raise FileNotFoundError(args.checkpoint)
    if not args.token_cache.is_file():
        raise FileNotFoundError(args.token_cache)
    if not args.pooled_cache.is_file():
        raise FileNotFoundError(args.pooled_cache)

    args.experiment_dir = args.output_dir / "manifest_build"
    args.experiment_dir.mkdir(parents=True, exist_ok=True)
    manifest_path, _cases, selected_sha = build_manifest(args)
    manifest = json.loads(manifest_path.read_text())
    records = selected_records(manifest, args.max_findings)

    token_map, pooled_map, record_map, sorted_token_keys = load_token_and_pooled_maps(
        args.token_cache, args.pooled_cache
    )
    condition_cache = build_condition_cache(token_map, record_map, sorted_token_keys)

    device = torch.device("cuda")
    amp_dtype = {"bfloat16": torch.bfloat16, "float16": torch.float16, "none": None}[
        args.amp_dtype
    ]
    predictor = make_predictor(
        args.output_dir, f"e3_feature_sensitivity_u{args.update}", args.checkpoint.resolve(), device
    )
    model = predictor.network.eval().to(device)
    if not getattr(model, "fan_image_text_blocks", None):
        raise RuntimeError("Model has no FAN image-text blocks")
    feature_store: dict[str, dict[str, torch.Tensor]] = {}
    hooks = install_fan_feature_hooks(model, feature_store)

    condition_rows: list[dict[str, Any]] = []
    feature_rows: list[dict[str, Any]] = []
    metadata: list[dict[str, Any]] = []
    try:
        for sample_index, record in enumerate(records):
            cache_key = key(record)
            if cache_key not in pooled_map:
                raise KeyError(f"Missing pooled embedding for {cache_key}")
            if cache_key not in condition_cache["correct"]:
                raise KeyError(f"Missing token features for {cache_key}")

            image, properties = load_image(
                ROOT / "data/ct_rate_volumes_fixed" / record["case"]
            )
            data, bbox, original_shape = predictor.preprocess(image)
            target = load_reference_mask_for_window_diagnostic(
                ROOT / "data/segmentations" / record["case"],
                1,
                tuple(original_shape),
                bbox,
                image_properties=properties,
                finding_ids=[record["finding_idx"]],
            )[0]
            patch, target_patch, starts, padding = pad_and_crop(data, target)
            patch = patch[None].to(device)
            pooled = pooled_map[cache_key][None, None].to(device)

            outputs: dict[str, dict[str, Any]] = {}
            for condition in CONDITIONS:
                token_value = (
                    None
                    if condition == "fan_bypass"
                    else condition_cache[condition][cache_key]
                )
                logits, audit, features = run_condition(
                    model=model,
                    patch=patch,
                    pooled=pooled,
                    token_value=token_value,
                    condition=condition,
                    amp_dtype=amp_dtype,
                    feature_store=feature_store,
                )
                outputs[condition] = {
                    "logits": logits,
                    "audit": audit,
                    "features": features,
                }
                dice_stats = dice_from_logits(logits, target_patch)
                row = {
                    "sample_index": sample_index,
                    "case": record["case"],
                    "finding_idx": int(record["finding_idx"]),
                    "prompt": record["prompt"],
                    "condition": condition,
                    "token_count": 0 if token_value is None else int(token_value.shape[0]),
                    **dice_stats,
                }
                if condition != "correct":
                    row.update(compare_logits(outputs["correct"]["logits"], logits))
                    row["patch_dice_delta_vs_correct"] = (
                        float(row["patch_dice"])
                        - float(condition_rows[-len(outputs)]["patch_dice"])
                        if False
                        else float(row["patch_dice"])
                        - float(dice_from_logits(outputs["correct"]["logits"], target_patch)["patch_dice"])
                    )
                condition_rows.append(row)

            correct_features = outputs["correct"]["features"]
            for condition in CONDITIONS:
                if condition == "correct":
                    comparison_rows = compare_features(correct_features, correct_features)
                else:
                    comparison_rows = compare_features(
                        correct_features, outputs[condition]["features"]
                    )
                for row in comparison_rows:
                    row.update(
                        {
                            "sample_index": sample_index,
                            "case": record["case"],
                            "finding_idx": int(record["finding_idx"]),
                            "prompt": record["prompt"],
                            "condition": condition,
                        }
                    )
                    feature_rows.append(row)

            metadata.append(
                {
                    **record,
                    "cache_key": list(cache_key),
                    "crop_start_after_padding": starts,
                    "padding_wxyz_pairs": padding,
                    "target_voxels_in_crop": int(target_patch.sum().item()),
                }
            )
            torch.cuda.empty_cache()
    finally:
        for handle in hooks:
            handle.remove()

    write_csv(args.output_dir / "per_sample_condition_metrics.csv", condition_rows)
    write_csv(args.output_dir / "feature_sensitivity_by_level.csv", feature_rows)

    summary_conditions: dict[str, dict[str, Any]] = {}
    for condition in CONDITIONS:
        rows = [row for row in condition_rows if row["condition"] == condition]
        summary_conditions[condition] = {
            "n": len(rows),
            "mean_patch_dice": mean_or_none([float(row["patch_dice"]) for row in rows]),
            "mean_pred_voxels": mean_or_none(
                [float(row["patch_pred_voxels"]) for row in rows]
            ),
            "mean_logit_delta_rms_vs_correct": mean_or_none(
                [float(row.get("logit_delta_rms", float("nan"))) for row in rows]
            ),
            "mean_logit_delta_rel_rms_vs_correct": mean_or_none(
                [float(row.get("logit_delta_rel_rms", float("nan"))) for row in rows]
            ),
            "mean_prob_delta_mean_abs_vs_correct": mean_or_none(
                [float(row.get("prob_delta_mean_abs", float("nan"))) for row in rows]
            ),
            "mean_binary_disagreement_fraction_vs_correct": mean_or_none(
                [
                    float(row.get("binary_disagreement_fraction", float("nan")))
                    for row in rows
                ]
            ),
        }

    summary_features: dict[str, dict[str, dict[str, Any]]] = {}
    for condition in CONDITIONS:
        summary_features[condition] = {}
        for level in sorted({str(row["level"]) for row in feature_rows}):
            rows = [
                row
                for row in feature_rows
                if row["condition"] == condition and str(row["level"]) == level
            ]
            summary_features[condition][level] = {
                "n": len(rows),
                "mean_correct_branch_delta_rel_visual": mean_or_none(
                    [float(row["correct_branch_delta_rel_visual"]) for row in rows]
                ),
                "mean_condition_enriched_delta_rel_correct": mean_or_none(
                    [
                        float(row.get("condition_enriched_delta_rel_correct", float("nan")))
                        for row in rows
                    ]
                ),
                "mean_condition_enriched_delta_rel_branch_delta": mean_or_none(
                    [
                        float(
                            row.get(
                                "condition_enriched_delta_rel_branch_delta", float("nan")
                            )
                        )
                        for row in rows
                    ]
                ),
                "mean_condition_fan_delta_rel_correct": mean_or_none(
                    [
                        float(row.get("condition_fan_delta_rel_correct", float("nan")))
                        for row in rows
                    ]
                ),
                "mean_condition_enriched_cosine_with_correct": mean_or_none(
                    [
                        float(
                            row.get(
                                "condition_enriched_cosine_with_correct", float("nan")
                            )
                        )
                        for row in rows
                    ]
                ),
            }

    payload = {
        "experiment": "E3 feature sensitivity audit",
        "checkpoint": str(args.checkpoint.resolve()),
        "update": args.update,
        "selected_findings_sha256": selected_sha,
        "max_findings": args.max_findings,
        "n_samples": len(metadata),
        "conditions": CONDITIONS,
        "condition_summary": summary_conditions,
        "feature_summary": summary_features,
        "metadata": metadata,
        "interpretation_hint": (
            "If token shuffles produce near-zero mask-logit/probability deltas "
            "and near-zero enriched-feature deltas, the FAN token path is not "
            "functionally sensitive to token identity.  If enriched features move "
            "but mask logits do not, downstream decoder usage is the bottleneck."
        ),
    }
    atomic_json(args.output_dir / "summary.json", payload)

    lines = [
        "# E3 feature sensitivity audit",
        "",
        f"- Checkpoint: `{args.checkpoint.resolve()}`",
        f"- Update: {args.update}",
        f"- Samples: {len(metadata)}",
        "",
        "## Mask-logit sensitivity",
        "",
        "| Condition | Patch Dice | Pred vox | Logit Δ RMS | Logit Δ rel | Prob MAE | Binary disagreement |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for condition in CONDITIONS:
        row = summary_conditions[condition]
        def fmt(value: Any, digits: int = 6) -> str:
            return "NA" if value is None else f"{float(value):.{digits}f}"

        lines.append(
            f"| {condition} | {fmt(row['mean_patch_dice'])} | "
            f"{fmt(row['mean_pred_voxels'], 1)} | "
            f"{fmt(row['mean_logit_delta_rms_vs_correct'])} | "
            f"{fmt(row['mean_logit_delta_rel_rms_vs_correct'])} | "
            f"{fmt(row['mean_prob_delta_mean_abs_vs_correct'])} | "
            f"{fmt(row['mean_binary_disagreement_fraction_vs_correct'])} |"
        )
    lines.extend(
        [
            "",
            "## Enriched-feature sensitivity",
            "",
            "| Condition | Level | Correct branch Δ / visual | Enriched Δ / correct | Enriched Δ / branch Δ | FAN feature Δ / correct | Enriched cosine |",
            "| --- | --- | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for condition in CONDITIONS:
        for level, row in summary_features[condition].items():
            def fmt(value: Any, digits: int = 6) -> str:
                return "NA" if value is None else f"{float(value):.{digits}f}"

            lines.append(
                f"| {condition} | {level} | "
                f"{fmt(row['mean_correct_branch_delta_rel_visual'])} | "
                f"{fmt(row['mean_condition_enriched_delta_rel_correct'])} | "
                f"{fmt(row['mean_condition_enriched_delta_rel_branch_delta'])} | "
                f"{fmt(row['mean_condition_fan_delta_rel_correct'])} | "
                f"{fmt(row['mean_condition_enriched_cosine_with_correct'])} |"
            )
    (args.output_dir / "report.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(payload["condition_summary"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
