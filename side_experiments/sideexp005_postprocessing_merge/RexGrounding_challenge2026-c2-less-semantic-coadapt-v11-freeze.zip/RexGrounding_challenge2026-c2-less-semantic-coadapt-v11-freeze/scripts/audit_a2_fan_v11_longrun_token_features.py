#!/usr/bin/env python3
"""Write a small token/global text-feature audit for the v1.1 A2-FAN long-run."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch


ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/a2_fan_v11_longrun_5000/analysis/token_feature_audit.json")
    parser.add_argument("--max-records", type=int, default=6)
    parser.add_argument(
        "--token-cache",
        type=Path,
        default=ROOT / "outputs/token_image_text_attention_phase0/cache/qwen_contextual_content_tokens_train_val.pt",
    )
    parser.add_argument(
        "--pooled-cache",
        type=Path,
        default=ROOT / "outputs/voxtell_rex_miccai_val/text_embedding_analysis/qwen_prompt_embeddings_train_val.pt",
    )
    return parser.parse_args()


def load_pooled_shapes(path: Path) -> dict[str, list[int]]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    shapes: dict[str, list[int]] = {}
    if isinstance(payload, dict):
        for key, value in payload.items():
            if torch.is_tensor(value):
                shapes[str(key)] = list(value.shape)
            elif isinstance(value, dict):
                for sub_key, sub_value in value.items():
                    if torch.is_tensor(sub_value):
                        shapes[str(sub_key)] = list(sub_value.shape)
                if shapes:
                    break
    return shapes


def main() -> int:
    args = parse_args()
    token_payload = torch.load(args.token_cache, map_location="cpu", weights_only=False)
    records = token_payload["records"]
    token_features = token_payload["token_features"]
    token_ids = token_payload["token_ids"]
    token_strings = token_payload["token_strings"]
    examples = []
    for index in range(min(args.max_records, len(records))):
        feature = token_features[index]
        examples.append(
            {
                "record": records[index],
                "raw_text": records[index].get("prompt") or records[index].get("finding"),
                "token_ids": [int(value) for value in token_ids[index]],
                "decoded_subtokens": list(token_strings[index]),
                "valid_token_mask": [1] * len(token_ids[index]),
                "token_feature_shape": list(feature.shape),
                "token_feature_dtype": str(feature.dtype),
            }
        )
    payload = {
        "text_encoder": "Qwen/Qwen3-Embedding-4B, frozen cached features",
        "fine_token_source": "outputs.last_hidden_state final transformer layer; valid contextualized content tokens only",
        "global_sentence_source": "normal VoxTell whole-finding pooled Qwen embedding cache",
        "token_cache": str(args.token_cache.resolve()),
        "pooled_cache": str(args.pooled_cache.resolve()),
        "records_in_token_cache": len(records),
        "examples": examples,
        "global_sentence_shape_examples": load_pooled_shapes(args.pooled_cache),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "examples": len(examples)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
