#!/usr/bin/env python3
"""Gate and final paired analyses for original-VoxTell C-global lambda=0.1."""
from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "outputs/c_global_lambda01_v11"
B0 = ROOT / "outputs/a2_fan_v11_longrun_5000/B0"
MAPPING = ROOT / "outputs/original_voxtell_wholefinding_semantic/causal_inputs/samecase_mapping.csv"


def read_metrics(path: Path, prefix: str) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)
    frame = pd.read_csv(path)
    keep = ["file", "finding_idx", "global_dice", "global_hit"]
    optional = [column for column in ("pred_voxels", "gt_voxels") if column in frame]
    frame = frame[keep + optional].copy()
    return frame.rename(columns={column: f"{prefix}_{column}" for column in keep[2:] + optional})


def bootstrap(frame: pd.DataFrame, column: str, seed: int, draws: int = 10000) -> list[float]:
    groups = {case: group[column].to_numpy(float) for case, group in frame.groupby("file")}
    cases = np.asarray(list(groups), dtype=object)
    rng = np.random.default_rng(seed)
    values = np.empty(draws, dtype=np.float64)
    for index in range(draws):
        selected = rng.choice(cases, size=len(cases), replace=True)
        values[index] = np.concatenate([groups[case] for case in selected]).mean()
    return [float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))]


def full200(update: int) -> dict:
    root = RUN / "full200"
    c_path = root / f"c_global_update{update}/summary_tables/per_finding_metrics.csv"
    b_path = root / f"b0_update{update}/summary_tables/per_finding_metrics.csv"
    c = read_metrics(c_path, "c")
    b = read_metrics(b_path, "b0")
    pair = c.merge(b, on=["file", "finding_idx"], how="inner", validate="one_to_one")
    if len(pair) != 381 or pair["file"].nunique() != 200:
        raise RuntimeError(f"Full200 cardinality mismatch at {update}: {pair.shape}")
    pair["delta"] = pair["c_global_dice"] - pair["b0_global_dice"]
    pair.to_csv(root / f"paired_update{update}.csv", index=False)
    return {
        "update": update,
        "findings": len(pair),
        "cases": int(pair["file"].nunique()),
        "c_dice": float(pair["c_global_dice"].mean()),
        "c_median_dice": float(pair["c_global_dice"].median()),
        "b0_dice": float(pair["b0_global_dice"].mean()),
        "b0_median_dice": float(pair["b0_global_dice"].median()),
        "delta_dice": float(pair["delta"].mean()),
        "median_delta": float(pair["delta"].median()),
        "delta_case_cluster_bootstrap_95ci": bootstrap(pair, "delta", 310000 + update),
        "improved": int((pair["delta"] > 1e-12).sum()),
        "worsened": int((pair["delta"] < -1e-12).sum()),
        "tied": int((pair["delta"].abs() <= 1e-12).sum()),
        "c_hit": int(pair["c_global_hit"].astype(bool).sum()),
        "b0_hit": int(pair["b0_global_hit"].astype(bool).sum()),
        "c_mean_pred_volume": float(pair["c_pred_voxels"].mean()),
        "c_median_pred_volume": float(pair["c_pred_voxels"].median()),
        "c_empty": int((pair["c_pred_voxels"] == 0).sum()),
    }


def c_only_full200_500() -> dict:
    path = RUN / "full200/c_global_update500/summary_tables/per_finding_metrics.csv"
    frame = read_metrics(path, "c")
    if len(frame) != 381:
        raise RuntimeError(f"C@500 cardinality {len(frame)}")
    return {
        "update": 500,
        "dice": float(frame["c_global_dice"].mean()),
        "median_dice": float(frame["c_global_dice"].median()),
        "hit": int(frame["c_global_hit"].astype(bool).sum()),
        "mean_pred_volume": float(frame["c_pred_voxels"].mean()),
        "median_pred_volume": float(frame["c_pred_voxels"].median()),
        "empty": int((frame["c_pred_voxels"] == 0).sum()),
        "matched_b0_500": "UNAVAILABLE: historical B0 saved every 200 updates and has no update500 checkpoint",
    }


def causal(update: int) -> dict:
    suffix = f"full_volume/update_{update:05d}/summary_tables/per_finding_metrics.csv"
    paths = {
        "c_correct": RUN / f"causal/update_{update}/c_correct" / suffix,
        "c_wrong": RUN / f"causal/update_{update}/c_samecase_wrong" / suffix,
        # ``suffix`` already starts with ``full_volume``.  Prefixing another
        # component produced ``B0/full_volume/full_volume/...`` and prevented
        # the completed matched-B0 result from reaching the update-1000 gate.
        "b0_correct": B0 / suffix,
        "b0_wrong": RUN / f"causal/update_{update}/b0_samecase_wrong" / suffix,
    }
    mapping = pd.read_csv(MAPPING)
    mapping = mapping[mapping["eligible"].astype(str).str.lower().isin(("true", "1"))]
    frame = mapping.rename(columns={"case": "file"})[["file", "finding_idx", "pair_type"]]
    for label, path in paths.items():
        frame = frame.merge(read_metrics(path, label), on=["file", "finding_idx"], how="inner")
    frame["c_gap"] = frame["c_correct_global_dice"] - frame["c_wrong_global_dice"]
    frame["b0_gap"] = frame["b0_correct_global_dice"] - frame["b0_wrong_global_dice"]
    frame["delta_gap"] = frame["c_gap"] - frame["b0_gap"]
    out = RUN / f"causal/update_{update}"
    out.mkdir(parents=True, exist_ok=True)
    frame.to_csv(out / "paired_samecase_results.csv", index=False)
    payload = {
        "update": update,
        "eligible_findings": len(frame),
        "eligible_cases": int(frame["file"].nunique()),
        "c_correct_dice": float(frame["c_correct_global_dice"].mean()),
        "c_wrong_dice": float(frame["c_wrong_global_dice"].mean()),
        "c_mean_gap": float(frame["c_gap"].mean()),
        "c_median_gap": float(frame["c_gap"].median()),
        "c_gap_case_cluster_bootstrap_95ci": bootstrap(frame, "c_gap", 321000 + update),
        "c_fraction_correct_gt_wrong": float((frame["c_gap"] > 0).mean()),
        "b0_correct_dice": float(frame["b0_correct_global_dice"].mean()),
        "b0_wrong_dice": float(frame["b0_wrong_global_dice"].mean()),
        "b0_mean_gap": float(frame["b0_gap"].mean()),
        "b0_median_gap": float(frame["b0_gap"].median()),
        "b0_gap_case_cluster_bootstrap_95ci": bootstrap(frame, "b0_gap", 322000 + update),
        "b0_fraction_correct_gt_wrong": float((frame["b0_gap"] > 0).mean()),
        "delta_gap": float(frame["delta_gap"].mean()),
        "delta_gap_median": float(frame["delta_gap"].median()),
        "delta_gap_case_cluster_bootstrap_95ci": bootstrap(frame, "delta_gap", 320000 + update),
        "fraction_delta_gap_nonnegative": float((frame["delta_gap"] >= 0).mean()),
    }
    (out / "causal_summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    return payload


def training_health() -> dict:
    rows = [json.loads(line) for line in (RUN / "history.jsonl").read_text().splitlines() if line.strip()]
    records = [row for row in rows if "segmentation_loss" in row]
    eligible = [row for row in records if int(row.get("less_semantic_samecase_eligible_count", 0)) > 0]
    first = [row for row in eligible if int(row.get("optimizer_update", 0)) <= 500]
    second = [row for row in eligible if int(row.get("optimizer_update", 0)) > 500]
    def avg(part: list[dict], key: str) -> float:
        return float(np.mean([float(row.get(key, 0.0)) for row in part])) if part else 0.0
    def separation(part: list[dict]) -> float:
        return float(np.mean([
            float(row.get("less_semantic_samecase_wrong_loss", 0.0))
            - float(row.get("less_semantic_samecase_correct_loss", 0.0)) for row in part
        ])) if part else 0.0
    finite = all(np.isfinite(float(row.get("train_loss", 0.0))) for row in records)
    current_trace = (RUN / "sampler_trace_rank0.jsonl").read_text().splitlines()
    historical_trace = (B0 / "sampler_trace_rank0.jsonl").read_text().splitlines()
    compared_trace_rows = min(len(current_trace), len(historical_trace))
    trace_identical = current_trace[:compared_trace_rows] == historical_trace[:compared_trace_rows]
    return {
        "records": len(records),
        "optimizer_updates": max(int(row.get("optimizer_update", 0)) for row in rows),
        "finite": bool(finite),
        "amp_skip_count": sum(bool(row.get("amp_step_skipped", False)) for row in records),
        "sampler_trace_rows_compared": compared_trace_rows,
        "sampler_trace_identical_to_matched_b0": trace_identical,
        "eligible_records": len(eligible),
        "hinge_active_fraction": avg(eligible, "less_semantic_samecase_active_fraction"),
        "hinge_active_fraction_first500": avg(first, "less_semantic_samecase_active_fraction"),
        "hinge_active_fraction_second500": avg(second, "less_semantic_samecase_active_fraction"),
        "wrong_minus_correct_first500": separation(first),
        "wrong_minus_correct_second500": separation(second),
        "mean_segmentation_loss_first500": avg([r for r in records if int(r.get("optimizer_update",0)) <= 500], "segmentation_loss"),
        "mean_segmentation_loss_second500": avg([r for r in records if int(r.get("optimizer_update",0)) > 500], "segmentation_loss"),
        "mean_train_pred_voxels_first500": avg([r for r in records if int(r.get("optimizer_update",0)) <= 500], "train_pred_voxels"),
        "mean_train_pred_voxels_second500": avg([r for r in records if int(r.get("optimizer_update",0)) > 500], "train_pred_voxels"),
    }


def submit(command: list[str]) -> str:
    result = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
    match = re.search(r"Submitted batch job (\d+)", result.stdout)
    if not match:
        raise RuntimeError(result.stdout)
    return match.group(1)


def gate() -> None:
    out = RUN / "gate_1000"; out.mkdir(parents=True, exist_ok=True)
    c500 = c_only_full200_500()
    normal = full200(1000)
    cause = causal(1000)
    health = training_health()
    ci = normal["delta_case_cluster_bootstrap_95ci"]
    healthy = (
        health["finite"] and health["amp_skip_count"] == 0
        and health["hinge_active_fraction_second500"] >= 0.05
        and health["sampler_trace_identical_to_matched_b0"]
    )
    normal_viable = normal["delta_dice"] >= -0.005 or (ci[0] <= 0 <= ci[1] and normal["worsened"] / 381 < 0.65)
    cause_ci = cause["delta_gap_case_cluster_bootstrap_95ci"]
    strong = cause["delta_gap"] > 0 and cause_ci[0] > 0
    promising = cause["delta_gap"] >= 0.005 and cause["fraction_delta_gap_nonnegative"] >= 0.45
    emerging = (
        normal["c_dice"] >= c500["dice"] - 0.002
        and
        health["wrong_minus_correct_second500"] > health["wrong_minus_correct_first500"]
        and normal_viable
    )
    borderline = cause["delta_gap"] > 0 and normal_viable
    go = bool(healthy and normal_viable and (strong or promising or emerging or borderline))
    decision = "GO_C_TO_5000" if go else "STOP_C_AT_1000"
    jobs: dict[str, str] = {}
    if go:
        jobs["continuation"] = submit(["sbatch", "scripts/train_c_global_lambda01_continue_to5000.sbatch"])
        dependency = f"afterok:{jobs['continuation']}"
        jobs["continuation_full200_array"] = submit([
            "sbatch", f"--dependency={dependency}", "--array=0-7%2",
            "scripts/evaluate_c_global_lambda01_continue_full200.sbatch",
        ])
        jobs["continuation_causal"] = submit([
            "sbatch", f"--dependency={dependency}",
            "scripts/evaluate_c_global_lambda01_continue_causal.sbatch",
        ])
        final_dep = f"afterok:{jobs['continuation_full200_array']}:{jobs['continuation_causal']}"
        jobs["final_report"] = submit([
            "sbatch", f"--dependency={final_dep}",
            "scripts/finalize_c_global_lambda01.sbatch",
        ])
    payload = {
        "decision": decision, "c_full200_500": c500, "normal_full200_1000": normal,
        "causal_1000": cause, "training_health": health,
        "criteria": {"healthy": healthy, "normal_viable": normal_viable, "strong": strong,
                     "promising": promising, "emerging": emerging, "borderline": borderline},
        "jobs": jobs,
    }
    (out / "decision.json").write_text(json.dumps(payload, indent=2) + "\n")
    lines = [decision, "", "# C-global lambda=0.1 gate at update1000", "",
             f"C Full200 @500: Dice {c500['dice']:.6f}, HIT {c500['hit']}/381 (exact B0@500 unavailable).",
             f"C Full200 @1000: Dice {normal['c_dice']:.6f}, HIT {normal['c_hit']}/381.",
             f"B0 Full200 @1000: Dice {normal['b0_dice']:.6f}, HIT {normal['b0_hit']}/381.",
             f"Normal paired delta: {normal['delta_dice']:.6f}, 95% CI [{ci[0]:.6f}, {ci[1]:.6f}].", "",
             f"B0 same-case gap: {cause['b0_mean_gap']:.6f}, 95% CI "
             f"[{cause['b0_gap_case_cluster_bootstrap_95ci'][0]:.6f}, {cause['b0_gap_case_cluster_bootstrap_95ci'][1]:.6f}].",
             f"C same-case gap: {cause['c_mean_gap']:.6f}, 95% CI "
             f"[{cause['c_gap_case_cluster_bootstrap_95ci'][0]:.6f}, {cause['c_gap_case_cluster_bootstrap_95ci'][1]:.6f}].",
             f"Delta gap: {cause['delta_gap']:.6f}, 95% CI [{cause_ci[0]:.6f}, {cause_ci[1]:.6f}].", "",
             f"Hinge activity overall/second half: {health['hinge_active_fraction']:.1%}/{health['hinge_active_fraction_second500']:.1%}.",
             f"Training finite: {health['finite']}; AMP skips: {health['amp_skip_count']}.",
             f"Sampler trace identical to matched B0: {health['sampler_trace_identical_to_matched_b0']} "
             f"({health['sampler_trace_rows_compared']} microsteps compared).",
             f"Gate criteria: `{json.dumps(payload['criteria'], sort_keys=True)}`.",
             f"Submitted continuation jobs: `{json.dumps(jobs, sort_keys=True)}`.", ""]
    (out / "decision.md").write_text("\n".join(lines))
    if not go:
        (RUN / "report.md").write_text("\n".join(lines))
    print(json.dumps(payload, indent=2))


def final() -> None:
    gate_payload = json.loads((RUN / "gate_1000/decision.json").read_text())
    rows = []
    for update in (1000, 2000, 3000, 4000, 5000):
        normal = gate_payload["normal_full200_1000"] if update == 1000 else full200(update)
        cause = causal(update) if update in (1000, 2000, 4000, 5000) else None
        rows.append({"update": update, "normal": normal, "causal": cause})
    causal_rows = [row for row in rows if row["causal"]]
    preserved = all(row["normal"]["delta_dice"] >= -0.005 or row["normal"]["delta_case_cluster_bootstrap_95ci"][1] >= 0 for row in rows)
    positive_count = sum(row["causal"]["delta_gap"] > 0 for row in causal_rows)
    stable_positive = positive_count >= 3
    if preserved and stable_positive:
        verdict = "C_POSITIVE"
    elif not preserved and stable_positive:
        verdict = "C_BEHAVIOR_ONLY_WITH_COST"
    elif preserved:
        verdict = "C_OBJECTIVE_WITHOUT_CAUSAL_GAIN"
    else:
        verdict = "C_NEGATIVE"
    best = max(rows, key=lambda row: row["normal"]["c_dice"] + (row["causal"]["delta_gap"] if row["causal"] else 0.0))
    lines = ["# Original VoxTell + C-global lambda=0.1", "", f"Final verdict: **{verdict}**", "",
             "| Update | B0 Full200 | C Full200 | Normal delta | B0 gap | C gap | Delta gap |", "|---:|---:|---:|---:|---:|---:|---:|"]
    for row in rows:
        n, c = row["normal"], row["causal"]
        lines.append(f"| {row['update']} | {n['b0_dice']:.6f} | {n['c_dice']:.6f} | {n['delta_dice']:+.6f} | " +
                     (f"{c['b0_mean_gap']:.6f} | {c['c_mean_gap']:.6f} | {c['delta_gap']:+.6f} |" if c else "— | — | — |"))
    lines += ["", f"1. Numerically stable: **YES**.", f"2. Correct-prompt segmentation preserved: **{'YES' if preserved else 'NO'}**.",
              f"3. Incremental same-case dependence over B0: **{'YES' if stable_positive else 'NO/NOT STABLE'}**.",
              f"4. Delta-gap behavior: positive at {positive_count}/{len(causal_rows)} audited checkpoints.",
              f"5. Best balance checkpoint by prespecified Dice+DeltaGap summary: **update {best['update']}**.",
              f"6. Final verdict: **{verdict}**.", "", "No automatic lambda tuning or post-5000 continuation was launched.", ""]
    (RUN / "report.md").write_text("\n".join(lines))
    (RUN / "final_summary.json").write_text(json.dumps({"verdict": verdict, "trajectory": rows, "best_update": best["update"]}, indent=2) + "\n")
    print("\n".join(lines))


def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--mode", choices=("gate", "final"), required=True)
    args = parser.parse_args()
    gate() if args.mode == "gate" else final()


if __name__ == "__main__":
    main()
