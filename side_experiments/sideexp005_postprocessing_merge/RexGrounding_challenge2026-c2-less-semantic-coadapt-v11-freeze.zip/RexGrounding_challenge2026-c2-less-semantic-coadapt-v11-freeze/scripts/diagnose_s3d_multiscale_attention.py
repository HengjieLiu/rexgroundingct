#!/usr/bin/env python3
"""Full-validation, per-category diagnostics for all S3 attention scales.

The S3 maps are generated at their native decoder scales, independently
upsampled to the preprocessed full-volume grid, and then compared with the
same ReX finding mask. This evaluates localization quality, not segmentation.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch


REX_ROOT = Path(__file__).resolve().parents[1]
if str(REX_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(REX_ROOT / "scripts"))

from diagnose_spatial_attention_localization import (  # noqa: E402
    attention_metrics,
    dice_score,
    load_rex_masks_in_preprocessed_ras,
)
from run_voxtell_rex_inference import (  # noqa: E402
    add_voxtell_to_path,
    load_entries,
    load_image,
    sorted_finding_keys,
    sorted_prompts,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rex-json", type=Path, default=REX_ROOT / "data/MICCAI_challenge_dataset.json")
    parser.add_argument("--image-dir", type=Path, default=REX_ROOT / "data/ct_rate_volumes_fixed")
    parser.add_argument("--mask-dir", type=Path, default=REX_ROOT / "data/segmentations")
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--finding-metrics", type=Path, required=True)
    parser.add_argument("--category-gamma-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--voxtell-repo", type=Path, default=REX_ROOT / "VoxTell")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--gpu", type=int, default=None)
    parser.add_argument(
        "--focus-categories",
        nargs="+",
        default=None,
        help="Optional ReX categories to diagnose; the default keeps every category.",
    )
    parser.add_argument(
        "--example-findings-csv",
        type=Path,
        default=None,
        help=(
            "Optional CSV containing file/case_id, finding_idx, and an optional "
            "selection_reason column. A GT-aligned multiscale attention panel is "
            "saved for every listed finding."
        ),
    )
    parser.add_argument("--max-findings", type=int, default=0, help="0 means every validation finding")
    parser.add_argument("--collect", action="store_true")
    return parser.parse_args()


def rank_info() -> tuple[int, int, int]:
    return (
        int(os.environ.get("RANK", "0")),
        int(os.environ.get("WORLD_SIZE", "1")),
        int(os.environ.get("LOCAL_RANK", "0")),
    )


def selected_metrics(args: argparse.Namespace, entries: list[dict]) -> pd.DataFrame:
    metrics = pd.read_csv(args.finding_metrics)
    available = {entry["name"] for entry in entries}
    metrics = metrics.loc[metrics["file"].isin(available)].copy()
    metrics = metrics.loc[
        metrics["file"].map(lambda name: (args.image_dir / name).exists())
        & metrics["file"].map(lambda name: (args.mask_dir / name).exists())
    ]
    if args.focus_categories:
        focus = {str(category) for category in args.focus_categories}
        metrics = metrics.loc[metrics["category"].astype(str).isin(focus)].copy()
    metrics = metrics.sort_values(["category", "file", "finding_idx"]).reset_index(drop=True)
    if args.max_findings > 0:
        metrics = metrics.head(args.max_findings).copy()
    if metrics.empty:
        raise RuntimeError("No evaluable findings were selected")
    return metrics


def gate_parameters(model, scale: str) -> tuple[float, float, float]:
    gate = model.s3_attention_gate if scale == "1/2" else model.s3_extra_attention_gates[model._s2_scale_key(scale)]
    return (
        float(gate.rho_fixed),
        float(gate.logit_scale.detach().exp().clamp(max=50).cpu()),
        float(gate.bias.detach().cpu()),
    )


def load_example_findings(path: Path | None) -> dict[tuple[str, int], str]:
    if path is None:
        return {}
    frame = pd.read_csv(path)
    case_column = "file" if "file" in frame.columns else "case_id"
    required = {case_column, "finding_idx"}
    if not required.issubset(frame.columns):
        raise ValueError(f"{path} must contain {sorted(required)}")
    reasons = frame.get("selection_reason", pd.Series("selected", index=frame.index))
    return {
        (str(case), int(finding_idx)): str(reason)
        for case, finding_idx, reason in zip(frame[case_column], frame["finding_idx"], reasons)
    }


def save_multiscale_example(
    path: Path,
    ct: np.ndarray,
    target: np.ndarray,
    probability: np.ndarray,
    attention_by_scale: dict[str, np.ndarray],
    prompt: str,
    reason: str,
) -> None:
    slice_idx = int(np.argmax(target.sum(axis=(1, 2))))
    scales = [scale for scale in ("1/4", "1/2", "1/1") if scale in attention_by_scale]
    fig, axes = plt.subplots(1, 2 + len(scales), figsize=(4.1 * (2 + len(scales)), 4.2))
    ct_slice = ct[slice_idx]
    low, high = np.percentile(ct_slice, [1, 99])
    axes[0].imshow(ct_slice, cmap="gray", vmin=low, vmax=high)
    axes[0].contour(target[slice_idx], levels=[0.5], colors=["lime"], linewidths=1.1)
    axes[0].set_title("CT + GT")
    seg = axes[1].imshow(probability[slice_idx], cmap="magma", vmin=0.0, vmax=1.0)
    axes[1].contour(target[slice_idx], levels=[0.5], colors=["lime"], linewidths=1.1)
    axes[1].set_title("Segmentation probability")
    fig.colorbar(seg, ax=axes[1], fraction=0.046, pad=0.04)
    for ax, scale in zip(axes[2:], scales):
        heat = ax.imshow(attention_by_scale[scale][slice_idx], cmap="magma", vmin=0.0, vmax=1.0)
        ax.contour(target[slice_idx], levels=[0.5], colors=["lime"], linewidths=1.1)
        ax.set_title(f"S3 attention {scale}")
        fig.colorbar(heat, ax=ax, fraction=0.046, pad=0.04)
    for ax in axes:
        ax.axis("off")
    fig.suptitle(f"{reason} | {prompt}", fontsize=9)
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(fig)


def run_shard(args: argparse.Namespace) -> None:
    rank, world_size, local_rank = rank_info()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    entries = load_entries(args.rex_json, ["val"])
    entry_map = {entry["name"]: entry for entry in entries}
    metrics = selected_metrics(args, entries)
    case_names = sorted(metrics["file"].unique())
    shard_cases = set(case_names[rank::world_size])
    shard_metrics = metrics.loc[metrics["file"].isin(shard_cases)].copy()

    add_voxtell_to_path(args.voxtell_repo)
    from voxtell.inference.predictor import VoxTellPredictor

    gpu = local_rank if args.gpu is None else args.gpu
    device = torch.device(f"cuda:{gpu}" if args.device == "cuda" else args.device)
    predictor = VoxTellPredictor(str(args.model_dir), device=device)
    model = predictor.network._orig_mod if hasattr(predictor.network, "_orig_mod") else predictor.network
    configured_scales = tuple(getattr(model, "s3_attention_scales", ()))
    if not configured_scales:
        raise RuntimeError("Checkpoint does not expose S3 multiscale attention")
    with args.category_gamma_json.open() as handle:
        category_gamma = {str(key): float(value) for key, value in json.load(handle).items()}
    example_findings = load_example_findings(args.example_findings_csv)

    rows: list[dict] = []
    for case_number, (case_name, case_rows) in enumerate(shard_metrics.groupby("file", sort=True), start=1):
        entry = entry_map[case_name]
        case_rows = case_rows.sort_values("finding_idx").reset_index(drop=True)
        image, image_properties = load_image(args.image_dir / case_name)
        data, bbox, _ = predictor.preprocess(image)
        prompts = sorted_prompts(entry)
        finding_keys = sorted_finding_keys(entry)
        categories = [(entry.get("categories") or {}).get(key, "unknown") for key in finding_keys]
        full_target = load_rex_masks_in_preprocessed_ras(
            args.mask_dir / case_name,
            image_properties,
            len(prompts),
            bbox,
        )
        if tuple(full_target.shape[1:]) != tuple(data.shape[1:]):
            raise RuntimeError(f"{case_name}: GT/image shape mismatch")
        embeddings = predictor.embed_text_prompts(prompts)
        gate_scales = torch.tensor(
            [category_gamma.get(str(category), 1.0) for category in categories],
            dtype=torch.float32,
        )
        logits, attention_by_scale = predictor.predict_sliding_window_return_logits(
            data,
            embeddings,
            spatial_attention_rho_scale=gate_scales,
            return_spatial_attention_maps_by_scale=True,
        )
        probabilities = torch.sigmoid(logits.float()).cpu().numpy()
        attention_by_scale = {
            scale: maps.float().cpu().numpy() for scale, maps in attention_by_scale.items()
        }
        target_array = full_target.numpy().astype(bool)
        for _, source in case_rows.iterrows():
            finding_idx = int(source["finding_idx"])
            target = target_array[finding_idx]
            if not target.any():
                raise RuntimeError(f"{case_name}: finding {finding_idx} has empty GT after preprocessing")
            for scale in configured_scales:
                if scale not in attention_by_scale:
                    raise RuntimeError(f"{case_name}: missing captured S3 map at {scale}")
                rho, logit_scale, bias = gate_parameters(model, scale)
                row = {
                    "case_id": case_name,
                    "finding_idx": finding_idx,
                    "category": str(source["category"]),
                    "prompt": str(source["prompt"]),
                    "attention_scale": scale,
                    "inference_gate_gamma": float(gate_scales[finding_idx]),
                    "segmentation_dice": dice_score(probabilities[finding_idx] > 0.5, target),
                    "s3_rho_fixed": rho,
                    "s3_logit_scale": logit_scale,
                    "s3_bias": bias,
                    **attention_metrics(attention_by_scale[scale][finding_idx], target),
                }
                rows.append(row)
            example_key = (case_name, finding_idx)
            if example_key in example_findings:
                safe_case = case_name.removesuffix(".nii.gz").replace("/", "_")
                save_multiscale_example(
                    args.output_dir / "examples" / f"{safe_case}_finding{finding_idx}.png",
                    data[0].cpu().numpy(),
                    target,
                    probabilities[finding_idx],
                    {
                        scale: maps[finding_idx]
                        for scale, maps in attention_by_scale.items()
                    },
                    str(source["prompt"]),
                    example_findings[example_key],
                )
        print(f"rank {rank}: [{case_number}/{len(shard_cases)}] {case_name}", flush=True)
        del logits, attention_by_scale, embeddings, probabilities
        if device.type == "cuda":
            torch.cuda.empty_cache()

    output = args.output_dir / f"attention_per_finding_shard_{rank:03d}.csv"
    pd.DataFrame(rows).to_csv(output, index=False)
    print(f"rank {rank}: wrote {len(rows)} rows to {output}", flush=True)


def make_heatmap(summary: pd.DataFrame, column: str, title: str, output: Path) -> None:
    pivot = summary.pivot(index="category", columns="attention_scale", values=column)
    order = [scale for scale in ("1/4", "1/2", "1/1") if scale in pivot.columns]
    pivot = pivot.reindex(columns=order)
    fig, ax = plt.subplots(figsize=(7, max(4, 0.42 * len(pivot))), constrained_layout=True)
    image = ax.imshow(pivot.to_numpy(dtype=float), cmap="viridis", aspect="auto")
    ax.set_xticks(range(len(pivot.columns)), pivot.columns)
    ax.set_yticks(range(len(pivot.index)), pivot.index)
    for row in range(pivot.shape[0]):
        for col in range(pivot.shape[1]):
            value = pivot.iloc[row, col]
            if np.isfinite(value):
                ax.text(col, row, f"{value:.2f}", ha="center", va="center", color="white", fontsize=8)
    ax.set_title(title)
    fig.colorbar(image, ax=ax)
    fig.savefig(output, dpi=180)
    plt.close(fig)


def collect(args: argparse.Namespace) -> None:
    shard_paths = sorted(args.output_dir.glob("attention_per_finding_shard_*.csv"))
    if not shard_paths:
        raise RuntimeError("No attention diagnostic shards found")
    metrics = pd.concat([pd.read_csv(path) for path in shard_paths], ignore_index=True)
    metrics.to_csv(args.output_dir / "attention_per_finding_all_scales.csv", index=False)
    summary = (
        metrics.groupby(["attention_scale", "category"], sort=True)
        .agg(
            n=("attention_enrichment", "size"),
            mean_segmentation_dice=("segmentation_dice", "mean"),
            median_attention_enrichment=("attention_enrichment", "median"),
            mean_attention_enrichment=("attention_enrichment", "mean"),
            median_inside_minus_outside=("attention_inside_minus_outside", "median"),
            median_inside_outside_ratio=("attention_inside_outside_ratio", "median"),
            pointing_accuracy=("attention_pointing_hit", "mean"),
            median_gt_sized_topk_precision=("attention_gt_sized_topk_precision", "median"),
            median_voxel_auroc=("attention_voxel_auroc", "median"),
            median_voxel_auprc=("attention_voxel_auprc", "median"),
        )
        .reset_index()
    )
    summary.to_csv(args.output_dir / "attention_by_category_and_scale.csv", index=False)
    overall = (
        metrics.groupby("attention_scale", sort=True)
        .agg(
            n=("attention_enrichment", "size"),
            median_attention_enrichment=("attention_enrichment", "median"),
            median_inside_minus_outside=("attention_inside_minus_outside", "median"),
            pointing_accuracy=("attention_pointing_hit", "mean"),
            median_voxel_auroc=("attention_voxel_auroc", "median"),
            median_voxel_auprc=("attention_voxel_auprc", "median"),
        )
        .reset_index()
    )
    overall.to_csv(args.output_dir / "attention_overall_by_scale.csv", index=False)
    make_heatmap(summary, "median_attention_enrichment", "Median GT attention enrichment", args.output_dir / "attention_enrichment_by_category_and_scale.png")
    make_heatmap(summary, "median_voxel_auroc", "Median attention voxel AUROC", args.output_dir / "attention_auroc_by_category_and_scale.png")
    make_heatmap(summary, "median_inside_minus_outside", "Median attention inside minus outside GT", args.output_dir / "attention_contrast_by_category_and_scale.png")

    lines = ["# S3 Multiscale Attention Diagnostic", "", "All metrics compare each native-scale map after independent upsampling to the preprocessed full-volume GT grid.", "", "## Overall By Scale", "", overall.to_csv(index=False), "", "## Focus Categories", ""]
    focus = summary.loc[summary["category"].isin(["2b", "2c", "2d"])].copy()
    lines.append(focus.to_csv(index=False))
    lines.extend([
        "## Interpretation",
        "",
        "- Enrichment > 1 and positive inside-minus-outside indicate concentration in GT.",
        "- AUROC > 0.5 indicates that a lesion voxel tends to receive higher attention than a non-lesion voxel.",
        "- A low pointing accuracy or GT-sized top-k precision indicates weak focal localization, especially relevant to nodules.",
        "- The trained model has S3 gates at 1/4, 1/2, and 1/1. It has no 1/8 S3 gate.",
    ])
    (args.output_dir / "report.md").write_text("\n".join(lines))
    print((args.output_dir / "report.md").read_text())


def main() -> int:
    args = parse_args()
    if args.collect:
        collect(args)
    else:
        run_shard(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
