#!/usr/bin/env python3
"""Collect the paired ReX native-vs-in-plane-resampled inference audit."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-shards", type=int, default=4)
    parser.add_argument("--bootstrap-samples", type=int, default=20_000)
    parser.add_argument("--seed", type=int, default=20260801)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open() as handle:
        return list(csv.DictReader(handle))


def as_bool(value: str | bool) -> bool:
    return value if isinstance(value, bool) else value.lower() == "true"


def case_bootstrap_ci(
    rows: list[dict], field: str, samples: int, seed: int
) -> tuple[float, float]:
    by_case: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        value = float(row[field])
        if np.isfinite(value):
            by_case[str(row["case"])].append(value)
    cases = sorted(by_case)
    if not cases:
        return float("nan"), float("nan")
    sums = np.asarray([np.sum(by_case[case]) for case in cases], dtype=np.float64)
    counts = np.asarray([len(by_case[case]) for case in cases], dtype=np.float64)
    rng = np.random.default_rng(seed)
    values = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 500):
        count = min(500, samples - start)
        chosen = rng.integers(0, len(cases), size=(count, len(cases)))
        values[start : start + count] = sums[chosen].sum(axis=1) / counts[chosen].sum(axis=1)
    return tuple(float(value) for value in np.quantile(values, [0.025, 0.975]))


def enrich(row: dict[str, str]) -> dict:
    output: dict = dict(row)
    float_fields = [
        "threshold",
        "native_dice",
        "resampled_dice",
        "sham_dice",
        "native_voxel_average_precision",
        "resampled_voxel_average_precision",
        "sham_voxel_average_precision",
        "source_mean_inplane_spacing_mm",
        "spacing_z_mm",
        "maximum_measurement_mm",
        "resampled_probability_correlation_to_native",
        "resampled_probability_mad_to_native",
        "sham_probability_correlation_to_native",
        "sham_probability_mad_to_native",
        "resampled_prediction_dice_to_native",
        "sham_prediction_dice_to_native",
    ]
    for field in float_fields:
        output[field] = float(output[field])
    for field in ("native_hit", "resampled_hit", "sham_hit", "has_explicit_measurement", "exact_3mm"):
        output[field] = as_bool(output[field])
    output["resampled_dice_delta"] = output["resampled_dice"] - output["native_dice"]
    output["sham_dice_delta"] = output["sham_dice"] - output["native_dice"]
    output["resampled_ap_delta"] = (
        output["resampled_voxel_average_precision"] - output["native_voxel_average_precision"]
    )
    output["sham_ap_delta"] = (
        output["sham_voxel_average_precision"] - output["native_voxel_average_precision"]
    )
    output["model_dice_delta_beyond_sham"] = output["resampled_dice"] - output["sham_dice"]
    output["model_ap_delta_beyond_sham"] = (
        output["resampled_voxel_average_precision"] - output["sham_voxel_average_precision"]
    )
    output["resampled_hit_delta"] = float(output["resampled_hit"]) - float(output["native_hit"])
    output["sham_hit_delta"] = float(output["sham_hit"]) - float(output["native_hit"])
    output["model_hit_delta_beyond_sham"] = (
        float(output["resampled_hit"]) - float(output["sham_hit"])
    )
    return output


def aggregate(
    group: str, rows: list[dict], args: argparse.Namespace, offset: int
) -> dict:
    if not rows:
        raise ValueError(f"Cannot aggregate empty subgroup {group}")
    dice_delta = np.asarray([row["resampled_dice_delta"] for row in rows], dtype=np.float64)
    sham_dice_delta = np.asarray([row["sham_dice_delta"] for row in rows], dtype=np.float64)
    ap_delta = np.asarray([row["resampled_ap_delta"] for row in rows], dtype=np.float64)
    sham_ap_delta = np.asarray([row["sham_ap_delta"] for row in rows], dtype=np.float64)
    model_dice_delta = np.asarray(
        [row["model_dice_delta_beyond_sham"] for row in rows], dtype=np.float64
    )
    model_ap_delta = np.asarray(
        [row["model_ap_delta_beyond_sham"] for row in rows], dtype=np.float64
    )
    hit_delta = np.asarray([row["resampled_hit_delta"] for row in rows], dtype=np.float64)
    dice_ci = case_bootstrap_ci(rows, "resampled_dice_delta", args.bootstrap_samples, args.seed + offset)
    sham_dice_ci = case_bootstrap_ci(
        rows, "sham_dice_delta", args.bootstrap_samples, args.seed + 10_000 + offset
    )
    ap_ci = case_bootstrap_ci(rows, "resampled_ap_delta", args.bootstrap_samples, args.seed + 20_000 + offset)
    sham_ap_ci = case_bootstrap_ci(
        rows, "sham_ap_delta", args.bootstrap_samples, args.seed + 30_000 + offset
    )
    model_dice_ci = case_bootstrap_ci(
        rows, "model_dice_delta_beyond_sham", args.bootstrap_samples, args.seed + 35_000 + offset
    )
    model_ap_ci = case_bootstrap_ci(
        rows, "model_ap_delta_beyond_sham", args.bootstrap_samples, args.seed + 37_500 + offset
    )
    hit_ci = case_bootstrap_ci(
        rows, "resampled_hit_delta", args.bootstrap_samples, args.seed + 40_000 + offset
    )
    by_case: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        by_case[str(row["case"])].append(float(row["resampled_dice_delta"]))
    case_deltas = np.asarray([np.mean(values) for values in by_case.values()])
    trim = int(np.floor(0.05 * len(dice_delta)))
    sorted_dice_delta = np.sort(dice_delta)
    trimmed_dice_delta = sorted_dice_delta[trim:-trim] if trim else sorted_dice_delta
    return {
        "group": group,
        "findings": len(rows),
        "cases": len(by_case),
        "native_dice": float(np.mean([row["native_dice"] for row in rows])),
        "resampled_dice": float(np.mean([row["resampled_dice"] for row in rows])),
        "resampled_dice_delta": float(np.mean(dice_delta)),
        "median_resampled_dice_delta": float(np.median(dice_delta)),
        "five_percent_trimmed_resampled_dice_delta": float(np.mean(trimmed_dice_delta)),
        "resampled_dice_ci95_low_case_bootstrap": dice_ci[0],
        "resampled_dice_ci95_high_case_bootstrap": dice_ci[1],
        "sham_dice_delta": float(np.mean(sham_dice_delta)),
        "sham_dice_ci95_low_case_bootstrap": sham_dice_ci[0],
        "sham_dice_ci95_high_case_bootstrap": sham_dice_ci[1],
        "native_ap": float(np.nanmean([row["native_voxel_average_precision"] for row in rows])),
        "resampled_ap": float(np.nanmean([row["resampled_voxel_average_precision"] for row in rows])),
        "resampled_ap_delta": float(np.nanmean(ap_delta)),
        "resampled_ap_ci95_low_case_bootstrap": ap_ci[0],
        "resampled_ap_ci95_high_case_bootstrap": ap_ci[1],
        "sham_ap_delta": float(np.nanmean(sham_ap_delta)),
        "sham_ap_ci95_low_case_bootstrap": sham_ap_ci[0],
        "sham_ap_ci95_high_case_bootstrap": sham_ap_ci[1],
        "model_dice_delta_beyond_sham": float(np.mean(model_dice_delta)),
        "model_dice_beyond_sham_ci95_low_case_bootstrap": model_dice_ci[0],
        "model_dice_beyond_sham_ci95_high_case_bootstrap": model_dice_ci[1],
        "model_ap_delta_beyond_sham": float(np.nanmean(model_ap_delta)),
        "model_ap_beyond_sham_ci95_low_case_bootstrap": model_ap_ci[0],
        "model_ap_beyond_sham_ci95_high_case_bootstrap": model_ap_ci[1],
        "native_hit_rate": float(np.mean([row["native_hit"] for row in rows])),
        "resampled_hit_rate": float(np.mean([row["resampled_hit"] for row in rows])),
        "resampled_hit_delta": float(np.mean(hit_delta)),
        "resampled_hit_ci95_low_case_bootstrap": hit_ci[0],
        "resampled_hit_ci95_high_case_bootstrap": hit_ci[1],
        "improved_findings": int(np.sum(dice_delta > 1e-8)),
        "tied_findings": int(np.sum(np.abs(dice_delta) <= 1e-8)),
        "worse_findings": int(np.sum(dice_delta < -1e-8)),
        "improved_cases": int(np.sum(case_deltas > 1e-8)),
        "tied_cases": int(np.sum(np.abs(case_deltas) <= 1e-8)),
        "worse_cases": int(np.sum(case_deltas < -1e-8)),
        "mean_source_inplane_spacing_mm": float(np.mean([
            row["source_mean_inplane_spacing_mm"] for row in rows
        ])),
        "mean_probability_correlation": float(np.mean([
            row["resampled_probability_correlation_to_native"] for row in rows
        ])),
        "mean_probability_mad": float(np.mean([
            row["resampled_probability_mad_to_native"] for row in rows
        ])),
        "mean_prediction_dice_between_branches": float(np.mean([
            row["resampled_prediction_dice_to_native"] for row in rows
        ])),
    }


def write_rows(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def case_summaries(rows: list[dict]) -> list[dict]:
    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        grouped[str(row["case"])].append(row)
    summaries = []
    for case, subset in grouped.items():
        summaries.append({
            "case": case,
            "findings": len(subset),
            "source_mean_inplane_spacing_mm": subset[0]["source_mean_inplane_spacing_mm"],
            "spacing_z_mm": subset[0]["spacing_z_mm"],
            "explicit_measurement_findings": sum(row["has_explicit_measurement"] for row in subset),
            "category_2d_findings": sum(row["category"] == "2d" for row in subset),
            "native_mean_dice": float(np.mean([row["native_dice"] for row in subset])),
            "resampled_mean_dice": float(np.mean([row["resampled_dice"] for row in subset])),
            "resampled_dice_delta": float(np.mean([row["resampled_dice_delta"] for row in subset])),
            "sham_dice_delta": float(np.mean([row["sham_dice_delta"] for row in subset])),
            "model_dice_delta_beyond_sham": float(np.mean([
                row["model_dice_delta_beyond_sham"] for row in subset
            ])),
            "resampled_ap_delta": float(np.nanmean([row["resampled_ap_delta"] for row in subset])),
            "sham_ap_delta": float(np.nanmean([row["sham_ap_delta"] for row in subset])),
            "model_ap_delta_beyond_sham": float(np.nanmean([
                row["model_ap_delta_beyond_sham"] for row in subset
            ])),
        })
    return sorted(summaries, key=lambda row: row["resampled_dice_delta"], reverse=True)


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    raw: list[dict] = []
    manifests = []
    for shard in range(args.expected_shards):
        shard_dir = args.input_dir / f"shard_{shard:02d}"
        manifests.append(json.loads((shard_dir / "manifest.json").read_text()))
        raw.extend(read_csv(shard_dir / "per_finding_threshold_metrics.csv"))
    rows = [enrich(row) for row in raw]
    keys = [(row["case"], row["finding_idx"], row["threshold"]) for row in rows]
    if len(keys) != len(set(keys)):
        raise RuntimeError("Duplicate case/finding/threshold rows in collected shards")
    cohort = json.loads((args.input_dir / "cohort.json").read_text())
    expected_cases = set(cohort["cases"])
    found_cases = {row["case"] for row in rows}
    if found_cases != expected_cases:
        raise RuntimeError(
            f"Cohort mismatch: missing={sorted(expected_cases-found_cases)}, extra={sorted(found_cases-expected_cases)}"
        )

    thresholds = sorted({float(row["threshold"]) for row in rows})
    threshold_rows = []
    for index, threshold in enumerate(thresholds):
        subset = [row for row in rows if abs(row["threshold"] - threshold) < 1e-9]
        item = aggregate(f"all_coarse_cases@{threshold:.2f}", subset, args, index)
        item["threshold"] = threshold
        threshold_rows.append(item)
    primary = [row for row in rows if abs(row["threshold"] - 0.5) < 1e-9]
    if not primary:
        raise RuntimeError("Threshold 0.5 is required for the primary analysis")
    coarse_median = float(np.median([row["source_mean_inplane_spacing_mm"] for row in primary]))
    subgroup_specs = [
        ("all_coarse_cases", primary),
        ("category_2d", [row for row in primary if row["category"] == "2d"]),
        ("explicit_measurement", [row for row in primary if row["has_explicit_measurement"]]),
        ("exact_3mm", [row for row in primary if row["exact_3mm"]]),
        ("measurement_max_le_3mm", [
            row for row in primary
            if row["has_explicit_measurement"] and row["maximum_measurement_mm"] <= 3
        ]),
        ("lower_half_of_coarse_spacing", [
            row for row in primary if row["source_mean_inplane_spacing_mm"] <= coarse_median
        ]),
        ("upper_half_of_coarse_spacing", [
            row for row in primary if row["source_mean_inplane_spacing_mm"] > coarse_median
        ]),
        ("z_le_1mm", [row for row in primary if row["spacing_z_mm"] <= 1]),
        ("z_ge_1p25mm", [row for row in primary if row["spacing_z_mm"] >= 1.25]),
    ]
    subgroup_rows = [
        aggregate(name, subset, args, 100 + index)
        for index, (name, subset) in enumerate(subgroup_specs)
        if subset
    ]

    write_rows(args.output_dir / "paired_per_finding_all_thresholds.csv", rows)
    write_rows(args.output_dir / "threshold_summary.csv", threshold_rows)
    write_rows(args.output_dir / "subgroup_summary_at_0p5.csv", subgroup_rows)
    write_rows(args.output_dir / "paired_per_case_at_0p5.csv", case_summaries(primary))
    summary = {
        "design": (
            "Frozen checkpoint and prompt; paired native inference versus X/Y-only upsampling "
            "to training median spacing. Resampled probabilities are mapped back and evaluated "
            "against untouched native-grid GT."
        ),
        "checkpoint": manifests[0]["checkpoint"],
        "cohort": cohort,
        "thresholds": thresholds,
        "primary_threshold": 0.5,
        "primary": subgroup_rows[0],
        "coarse_cohort_median_spacing_mm": coarse_median,
        "sham_control": {
            "description": "Native probability map upsampled to the intervention grid and mapped back, with no second model inference.",
            "dice_delta": subgroup_rows[0]["sham_dice_delta"],
            "dice_ci95": [
                subgroup_rows[0]["sham_dice_ci95_low_case_bootstrap"],
                subgroup_rows[0]["sham_dice_ci95_high_case_bootstrap"],
            ],
            "ap_delta": subgroup_rows[0]["sham_ap_delta"],
            "ap_ci95": [
                subgroup_rows[0]["sham_ap_ci95_low_case_bootstrap"],
                subgroup_rows[0]["sham_ap_ci95_high_case_bootstrap"],
            ],
        },
        "model_effect_beyond_sham": {
            "description": "Resampled-model prediction minus interpolation-only sham prediction.",
            "dice_delta": subgroup_rows[0]["model_dice_delta_beyond_sham"],
            "dice_ci95": [
                subgroup_rows[0]["model_dice_beyond_sham_ci95_low_case_bootstrap"],
                subgroup_rows[0]["model_dice_beyond_sham_ci95_high_case_bootstrap"],
            ],
            "ap_delta": subgroup_rows[0]["model_ap_delta_beyond_sham"],
            "ap_ci95": [
                subgroup_rows[0]["model_ap_beyond_sham_ci95_low_case_bootstrap"],
                subgroup_rows[0]["model_ap_beyond_sham_ci95_high_case_bootstrap"],
            ],
        },
    }
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")

    headline = subgroup_rows[0]
    report = [
        "# ReX inference-only in-plane resampling paired ablation",
        "",
        summary["design"],
        "",
        "## Pre-registered cohort and intervention",
        "",
        f"- Coarse cutoff: mean native X/Y spacing > {cohort['coarse_cutoff_mm']:.6f} mm",
        f"- Target X/Y spacing: {cohort['target_spacing_xy_mm'][0]:.6f} mm",
        f"- Selected validation cases: {cohort['selected_cases']} / {cohort['validation_cases']}",
        "- Z spacing: unchanged",
        "- Evaluation: resampled probabilities mapped back to untouched native GT grid",
        "",
        "## Primary result at threshold 0.50",
        "",
        "| Findings | Native Dice | Resampled Dice | Delta | Case-bootstrap 95% CI | AP delta | Hit delta | Improved/tied/worse |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|",
        f"| {headline['findings']} | {headline['native_dice']:.6f} | "
        f"{headline['resampled_dice']:.6f} | {headline['resampled_dice_delta']:+.6f} | "
        f"[{headline['resampled_dice_ci95_low_case_bootstrap']:+.6f}, "
        f"{headline['resampled_dice_ci95_high_case_bootstrap']:+.6f}] | "
        f"{headline['resampled_ap_delta']:+.6f} | {headline['resampled_hit_delta']:+.2%} | "
        f"{headline['improved_findings']}/{headline['tied_findings']}/{headline['worse_findings']} |",
        "",
        "## Subgroups",
        "",
        "| Group | n findings | n cases | Dice delta | 95% CI | AP delta | Improved/tied/worse |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in subgroup_rows[1:]:
        report.append(
            f"| {row['group']} | {row['findings']} | {row['cases']} | "
            f"{row['resampled_dice_delta']:+.6f} | "
            f"[{row['resampled_dice_ci95_low_case_bootstrap']:+.6f}, "
            f"{row['resampled_dice_ci95_high_case_bootstrap']:+.6f}] | "
            f"{row['resampled_ap_delta']:+.6f} | "
            f"{row['improved_findings']}/{row['tied_findings']}/{row['worse_findings']} |"
        )
    report.extend([
        "",
        "## Interpolation-only sham control",
        "",
        f"- Dice delta: {headline['sham_dice_delta']:+.6f} "
        f"[{headline['sham_dice_ci95_low_case_bootstrap']:+.6f}, "
        f"{headline['sham_dice_ci95_high_case_bootstrap']:+.6f}]",
        f"- AP delta: {headline['sham_ap_delta']:+.6f} "
        f"[{headline['sham_ap_ci95_low_case_bootstrap']:+.6f}, "
        f"{headline['sham_ap_ci95_high_case_bootstrap']:+.6f}]",
        "",
        "## Model effect beyond interpolation sham",
        "",
        f"- Dice delta (resampled - sham): {headline['model_dice_delta_beyond_sham']:+.6f} "
        f"[{headline['model_dice_beyond_sham_ci95_low_case_bootstrap']:+.6f}, "
        f"{headline['model_dice_beyond_sham_ci95_high_case_bootstrap']:+.6f}]",
        f"- AP delta (resampled - sham): {headline['model_ap_delta_beyond_sham']:+.6f} "
        f"[{headline['model_ap_beyond_sham_ci95_low_case_bootstrap']:+.6f}, "
        f"{headline['model_ap_beyond_sham_ci95_high_case_bootstrap']:+.6f}]",
        "",
    ])
    (args.output_dir / "report.md").write_text("\n".join(report))
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
