#!/usr/bin/env python3
"""Collect paired full-volume diagnostics for one category-adaptive S3 arm."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "outputs/controlled_v11_selected_full200/s3_update9000"


def case_bootstrap(frame: pd.DataFrame, samples: int = 10_000) -> list[float]:
    rng = np.random.default_rng(2026)
    cases = sorted(frame["file"].unique())
    by_case = {
        case: frame.loc[frame["file"] == case, "delta"].to_numpy(float)
        for case in cases
    }
    means = np.empty(samples)
    for index in range(samples):
        selected = rng.choice(cases, len(cases), replace=True)
        means[index] = np.concatenate([by_case[case] for case in selected]).mean()
    return np.quantile(means, [0.025, 0.975]).tolist()


def compare(baseline: pd.DataFrame, candidate: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    keys = ["file", "finding_idx"]
    paired = baseline.merge(candidate, on=keys, suffixes=("_base", "_candidate"))
    paired["delta"] = paired["global_dice_candidate"] - paired["global_dice_base"]
    tolerance = 1e-12
    summary = {
        "findings": len(paired),
        "baseline_dice": float(paired["global_dice_base"].mean()),
        "candidate_dice": float(paired["global_dice_candidate"].mean()),
        "mean_delta": float(paired["delta"].mean()),
        "improved": int((paired["delta"] > tolerance).sum()),
        "degraded": int((paired["delta"] < -tolerance).sum()),
        "tied": int((paired["delta"].abs() <= tolerance).sum()),
        "baseline_hits": int(paired["global_hit_base"].sum()),
        "candidate_hits": int(paired["global_hit_candidate"].sum()),
        "new_hits": int(
            ((~paired["global_hit_base"]) & paired["global_hit_candidate"]).sum()
        ),
        "lost_hits": int(
            (paired["global_hit_base"] & (~paired["global_hit_candidate"])).sum()
        ),
        "case_bootstrap_delta_95ci": case_bootstrap(paired),
        "top_positive_delta": float(paired["delta"].max()),
        "top_negative_delta": float(paired["delta"].min()),
        "mean_delta_without_top_two_improvements": float(
            paired.nsmallest(max(1, len(paired) - 2), "delta")["delta"].mean()
        ),
    }
    return paired, summary


def gates(path: Path) -> dict[str, float]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    values = payload["router_state"]["g_raw"].float().clamp(0, 1)
    return dict(zip(payload["router_config"]["categories"], values.tolist()))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--mode", choices=["router", "adapter"], required=True)
    parser.add_argument("--target-category")
    parser.add_argument("--checkpoint-stem", required=True)
    args = parser.parse_args()
    baseline = pd.read_csv(BASELINE / "per_finding_metrics.csv")
    selection = json.loads((args.run_dir / "selection.json").read_text())
    variants = {
        "best": args.run_dir / "full_validation/best/per_finding_metrics.csv",
        "final": args.run_dir / "full_validation/final/per_finding_metrics.csv",
    }
    results = {}
    for name, path in variants.items():
        candidate = pd.read_csv(path)
        if args.mode == "adapter":
            baseline_scope = baseline.loc[
                baseline["category"].astype(str) == str(args.target_category)
            ].copy()
        else:
            baseline_scope = baseline
        paired, summary = compare(baseline_scope, candidate)
        paired.to_csv(args.run_dir / f"paired_{name}.csv", index=False)
        if args.mode == "adapter":
            replacement = candidate[
                ["file", "finding_idx", "global_dice", "global_hit"]
            ].rename(
                columns={
                    "global_dice": "replacement_global_dice",
                    "global_hit": "replacement_global_hit",
                }
            )
            combined = baseline.merge(replacement, on=["file", "finding_idx"], how="left")
            target = combined["category"].astype(str) == str(args.target_category)
            combined["source"] = np.where(target, f"adapter_{name}", "s3_exact_reuse")
            combined["combined_global_dice"] = combined[
                "replacement_global_dice"
            ].where(target, combined["global_dice"])
            combined["combined_global_hit"] = combined[
                "replacement_global_hit"
            ].where(target, combined["global_hit"])
            non_target = combined.loc[~target]
            assert non_target["replacement_global_dice"].isna().all()
            summary.update(
                {
                    "combined_overall_dice": float(
                        combined["combined_global_dice"].mean()
                    ),
                    "combined_hits": int(combined["combined_global_hit"].sum()),
                    "non_target_findings_exactly_reused": int((~target).sum()),
                    "non_target_findings_changed": 0,
                }
            )
            combined.to_csv(
                args.run_dir / f"combined_per_finding_{name}.csv", index=False
            )
        results[name] = summary
    if args.mode == "router":
        checkpoint_updates = [0, 100, 200, 400, 600, 800]
        results["gate_stability"] = {
            str(update): gates(
                args.run_dir
                / "checkpoints"
                / f"{args.checkpoint_stem}_update_{update}.pth"
            )
            for update in checkpoint_updates
        }
    result = {
        "mode": args.mode,
        "target_category": args.target_category,
        "selection": selection,
        "comparisons": results,
    }
    (args.run_dir / "full_results.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
